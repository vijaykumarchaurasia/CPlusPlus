#pragma once
#include "SimpleEventModel.h"

namespace DaqApp
{
class EventsManagerModel;

class SimpleEventModelEvDynamicXcp final: public SimpleEventModel
{
    public:
        explicit SimpleEventModelEvDynamicXcp(EventConfigMessage, EventsManagerModel *, AppManager * );
        ~SimpleEventModelEvDynamicXcp();
        SimpleEventModelEvDynamicXcp(const SimpleEventModelEvDynamicXcp&)            = delete;
        SimpleEventModelEvDynamicXcp& operator=(const SimpleEventModelEvDynamicXcp&) = delete;
        SimpleEventModelEvDynamicXcp(SimpleEventModelEvDynamicXcp&&)                 = delete;
        void Evaluate() override;
    private:
        typedef bool(SimpleEventModelEvDynamicXcp::*CallBacks)();
        void SetOperatorCallBackIndex();
        bool IsEqual();
        bool IsNotEqual();
        bool IsLargerThan();
        bool IsLargerThanOrEqualTo();
        bool IsLessThan();
        bool IsLessThanOrEqualTo();
        bool IsSameAsPrevious();

        AppManager*         mAppManagerHandlePtr;
        EventsManagerModel* mEventsManagerHandlerPtr;
        const std::string   mSource;
        const std::string   mOperator;
        float               mSecondArg;
        short int           mCallBackIndex;
        float               mFirstArg;
        ConfigIds           mConfigId;
        //Avoids runtime string comparison for operators.
        const CallBacks mCallBacks[7] = {&SimpleEventModelEvDynamicXcp::IsEqual     , &SimpleEventModelEvDynamicXcp::IsNotEqual,
                                         &SimpleEventModelEvDynamicXcp::IsLargerThan, &SimpleEventModelEvDynamicXcp::IsLargerThanOrEqualTo,
                                         &SimpleEventModelEvDynamicXcp::IsLessThan  , &SimpleEventModelEvDynamicXcp::IsLessThanOrEqualTo,
                                         &SimpleEventModelEvDynamicXcp::IsSameAsPrevious} ;

};
}//End of DaqApp NS
