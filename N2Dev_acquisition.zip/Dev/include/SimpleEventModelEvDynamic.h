#pragma once
#include "SimpleEventModel.h"

namespace DaqApp
{
class EventsManagerModel;

class SimpleEventModelEvDynamic final: public SimpleEventModel
{
    public:
        explicit SimpleEventModelEvDynamic(EventConfigMessage, EventsManagerModel *, AppManager * );
        ~SimpleEventModelEvDynamic();
        SimpleEventModelEvDynamic(const SimpleEventModelEvDynamic& )            = delete;
        SimpleEventModelEvDynamic& operator=(const SimpleEventModelEvDynamic& ) = delete;
        SimpleEventModelEvDynamic(SimpleEventModelEvDynamic&&)                  = delete;
        void Evaluate() override;
    private:
        typedef bool(SimpleEventModelEvDynamic::*CallBacks)();
        void SetOperatorCallBackIndex();
        bool IsEqual();
        bool IsNotEqual();
        bool IsLargerThan();
        bool IsLargerThanOrEqualTo();
        bool IsLessThan();
        bool IsLessThanOrEqualTo();

        AppManager*         mAppManagerHandlePtr;
        EventsManagerModel* mEventsManagerHandlerPtr;
        const std::string   mSource;
        const std::string   mOperator;
        const float         mSecondArg;
        short int           mCallBackIndex;
        float               mFirstArg;
        ConfigIds           mConfigId;
        //Avoids runtime string comparison for operators.
        const CallBacks mCallBacks[6] = {&SimpleEventModelEvDynamic::IsEqual     , &SimpleEventModelEvDynamic::IsNotEqual,
                                         &SimpleEventModelEvDynamic::IsLargerThan, &SimpleEventModelEvDynamic::IsLargerThanOrEqualTo,
                                         &SimpleEventModelEvDynamic::IsLessThan  , &SimpleEventModelEvDynamic::IsLessThanOrEqualTo} ;

};
}//End of DaqApp NS
