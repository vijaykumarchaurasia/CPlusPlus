#include <vector>
#include <string>
#include <ecu/logging.h>
#include "json/json.h"
#include "Utils.h"

namespace DaqApp
{
class ValidationModel
{
    public:
        explicit ValidationModel();
        ~ValidationModel();
        ValidationModel(const ValidationModel&)            = delete;
        ValidationModel& operator=(const ValidationModel&) = delete;
        ValidationModel(ValidationModel&&)                 = delete;
        bool IsValidConfig(const Json::Value&);
        std::pair<std::string, std::string>& getConfigReasonCodeDescription();
        std::string protocol = "InvalidProtocol";

    private:
        std::pair<std::string, std::string> mReasonCode_Reason;
        bool IsValidDataContentSpec(const Json::Value&);
        bool IsValidConfigCommand(const Json::Value&);
        bool IsValidDataSamplingSpec(const Json::Value&);
        bool IsValidSimpleEventConfig(const Json::Value&);
        bool IsValidJ1939Config(const Json::Value& json_j1939_config);
        void setConfigReasonCodeDescription(const std::pair<std::string, std::string>&);
        bool IsValidCCPConfig(const Json::Value&);
};
}
