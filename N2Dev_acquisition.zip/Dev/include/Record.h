# pragma once
#include <string>
#include <deque>

namespace DaqApp
{
struct Record
    {
        std::string TimeStamp;
        std::string Location; // Will be removed next sprint
        std::string Latitude;
        std::string Longitude;
        std::string Altitude;
        std::string DirectionHeading;
        std::string VehicleDistance;
        std::string LocationTextDescription;
        std::string GPSVehicleSpeed;

        std::deque< std::pair<std::string /*Source "First" */,
                     std::string /* Value" Second" */ > > Data;
        Record():
        TimeStamp ("NA"),
        Location  ("NA"),
        Latitude  ("NA"),
        Longitude("NA"),
        Altitude("NA"),
        DirectionHeading("NA"),
        VehicleDistance("NA"),
        LocationTextDescription("NA"),
        GPSVehicleSpeed("NA")
        {}
    };
}//End of DaqApp NS
