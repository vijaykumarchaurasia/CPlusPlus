#pragma once
#include <memory>
#include <fstream>
#include <unordered_map>
#include <boost/filesystem.hpp>
#include <boost/iostreams/filtering_streambuf.hpp>
#include <boost/iostreams/copy.hpp>
#include <boost/iostreams/filter/gzip.hpp>
#include "ConfigMessage.h"
#include "CloudServicesModel.h"

namespace DaqApp
{
namespace boostfs = boost::filesystem;
class AppManager;
class FilesHandlingModel
{
    public:
        explicit FilesHandlingModel(AppManager*);
        ~FilesHandlingModel();
        FilesHandlingModel(const FilesHandlingModel&)             = delete;
        FilesHandlingModel& operator=(const FilesHandlingModel&)  = delete;
        FilesHandlingModel(FilesHandlingModel&&)                        = delete;
        void SetUpFilesHandlingModel();
        std::string GetConfigFilePath();
        std::string GetJ1939TopicListFilePath();
        std::string GetOutputFilePath(Priority);
        std::string GetLatestReceivedConfigFilePath();
        void OnNotifyFileWritingCompleted();
        void OnNotifyReceivedActivateDataCollectionMessage(const std::string&);
        void ForgetConfig(const std::string&);
        void InvalidConfigReceived(const std::string&);
        CloudServicesModel* GetCloudServicesPtr();
        void ActivateConfig(const std::string&);
        void DeActivateConfig();
        void DeActivateConfig(const std::string&);
        bool CheckForAvailableSpace();
        uintmax_t GetCurrentFreeSpace();
        void SetMinThreshold(uintmax_t);
        void SetMaxThreshold(uintmax_t);
        void DecompressDownloadedConfigFile(const std::string&);
        void NewDownloadedConfigFileValidationResponse(const std::string&, bool);
        void SetNewlyDownloadedJSONConfig(const std::string&);
        void RemoveJsonAndZipFromDir(const std::string&);
        bool IsSuffciceintSpace();
        std::vector<std::string> GetMultiConfigs();
        void ResetConfig();
        std::string GetCorrelationID(const std::string& configID);
        void SetConfigCorrelationId(const std::string&);

    private:
        void InitializeDirectoryStructure();
        bool IsDirExists(std::string const &);
        bool CreateDirectory(std::string const &);
        void CompressFile(const std::string&, const std::string&);
        void CompressFiles(const boostfs::path&);
        void CreateEntireCommonDirectoryStructure();
        void CreateConfigDirectoryStructure();
        void CreateDataLoggingDirectoryStructure();
        void DeleteFilesOnLowSpace(const std::function<std::string(int)>&);
        void AddUploadFilesToContainer(const boostfs::path&);
        void UploadFileToCloud();
        std::string ExtractConfigIDFromLogFile(const std::string&);
        std::string GetCorrelationIDFromTxtFile(const std::string&);
        void CreateCorrelationIdTxtFile(const std::string&, const std::string&);
        std::string GetJsonFileName(const std::string&, const std::string&);

        AppManager* mAppManHandlePtr;
        std::unique_ptr<CloudServicesModel> mCloudServicesPtr;
        DataConnectivityModel* mDataConnectivityPtr;
        uintmax_t mTotalSpace;
        uintmax_t mMinThreshold;
        uintmax_t mMaxThreshold;
        int mMinThresholdPercentage{3};
        int mMaxThresholdPercentage{4};
        bool mLowSpaceDetected = false;
        bool mUploadReady      = false;
        std::string mNewDownloadedConfigFile{""};
        std::set<std::string> mUploadfiles;
        TickId mTickId;
        std::mutex mMutexUpload;
        std::mutex mMutexFreeUpSpace;
        std::condition_variable mConditionVar;
        std::vector<std::string> mActiveConfigFiles;
        std::unordered_map<std::string, std::string> mActiveConfigFilesCorrelationID;
        std::string mCorrelationId;
};
}//End of DaqApp NS

