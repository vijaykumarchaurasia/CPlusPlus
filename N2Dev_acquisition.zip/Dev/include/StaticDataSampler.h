#pragma once
#include <ecu/sysparams.h>
#include <ecu/variables.h>
#include "SamplerModel.h"
#include "J1939RequesterModel.h"

namespace DaqApp
{
class AppManager;
class DataAccessModel;

class StaticDataSampler : public SamplerModel, public ISubscriptionObserver
{
    public:
        explicit StaticDataSampler(AppManager*, ITransportClient_ptr);
        virtual ~StaticDataSampler();
        StaticDataSampler(const StaticDataSampler&)            = delete;
        StaticDataSampler& operator=(const StaticDataSampler&) = delete;
        StaticDataSampler(StaticDataSampler&&)                 = delete;
    private:
        void message(const std::string& , const Message& ) override;
        void WriteSystemParameterValuesInMisc();        
		void WriteDM20ValueInMisc(const SignalGroup& );
		void WriteDeviceParametersToFile(void);
		void WriteDeviceParametersFromFile(void);

        AppManager*                             mAppManagerPtr;
        DataAccessModel*                        mDataAccessModelPtr;
        ecu::lapi::var::SysParamsClient_ptr     mSysParamsClientPtr;
        ecu::lapi::var::VariablesClient_ptr     mVarClientPtr;
        ISubscriptionObserver_ptr               mSdkCallBackPtr;
        ITransportClient_ptr                    mTransportClientPtr;
        PgnRequestClient_ptr 				    mPgnReqClientPtr;
        TimeUtilities*                          mTimeUtilitiesHandlePtr;
        std::vector<std::unique_ptr<J1939RequesterModel>> mJ1939RequesterModel;
        const std::string                       mTopicCi = "rt/telcan/ci";
        const std::string                       mTopicVi = "rt/telcan/e_vi";
        const std::string                       mSignalVi= "vehicleid";
        const std::string						mTopicDM20 = "rt/telcan/dm20";
        const std::string                       mSignalData= "data";
        const std::string						mSourceAddrName = "j1939_source_address";
        const std::string						mDeviceParamFileName = MISC_DIR + "/DeviceParameters.txt";
        const double							mDM20PGN = 49664;
        const uint8_t							mECMAddr = 0x00;
        const uint8_t							mGlobalRqstAddr = 0xFF;
        const std::string						mESNMiscID = "588";
        const std::string						mESNFileID = "ESN";
        const std::string						mVINMiscID = "237";
        const std::string						mVINFileID = "VIN";
        const std::string						mN2DevIDMiscID = "8207";
        const std::string						mN2DevIDFileID = "N2DeviceID";
};
}//End of DaqApp NS
