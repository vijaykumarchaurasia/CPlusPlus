#pragma once
#include <string>
#include <ecu/com/observer.h>

using namespace ecu::lapi::com;
namespace DaqApp
{
class SamplerModel
{
    public:
        explicit SamplerModel();
        virtual ~SamplerModel();
        SamplerModel(const SamplerModel&)            = delete;
        SamplerModel& operator=(const SamplerModel&) = delete;
        SamplerModel(SamplerModel&&)                 = delete;
};

class CallBackHelper : public ecu::lapi::com::ISubscriptionObserver
{
public:
   explicit CallBackHelper(ecu::lapi::com::ISubscriptionObserver* passedSamplerPtr) :
      mSamplerObjectPtr(passedSamplerPtr) {};
      ~CallBackHelper() = default;
   void message(const std::string& topic, const ecu::lapi::com::Message& message) override
    {
      mSamplerObjectPtr->message(topic, message);
    }
private:
   ISubscriptionObserver* mSamplerObjectPtr;
};
}//End of DaqApp NS
