#pragma once
#define DO_PRAGMA(text) _Pragma (#text)
#define JenkinsCatch(text) DO_PRAGMA(message ("JenkinsCatch - " #text))

#include <memory>
#include "TimeUtilities.h"

using namespace DaqTime;
namespace DaqApp
{
class ConfigurationManagerModel;
class SamplersManagerModel;
class DataAccessModel;
class DataLoggerModel;
class EventsManagerModel;
class FileWriterModel;
class FilesHandlingModel;
class SystemStateReceiver;
class ClientManagerModel;

class AppManager
{
    public:
        AppManager();
        AppManager(const AppManager&)              = delete ;
        AppManager& operator = (const AppManager&) = delete ;
        AppManager(AppManager&&)                       = delete ;
        ~AppManager();
        void StartApp();
        TimeUtilities*             GetTimeUtilities();
        FilesHandlingModel*        GetFilesHandlingModel();
        SamplersManagerModel*      GetSamplersManagerModel();
        DataAccessModel*           GetDataAccessModel();
        EventsManagerModel*        GetEventsManagerModel();
        FileWriterModel*           GetFileWriterModel();
        std::vector <std::unique_ptr<DataLoggerModel>>& GetDataLoggerModel();
        ConfigurationManagerModel* GetConfigurationModel();
        SystemStateReceiver*       GetSystemStateReceiver();
        ClientManagerModel*        GetClientManagerModel();

        const std::string NOSUFFICIENTSPACE = "No_Sufficeint_Space";

    private:
        std::unique_ptr <TimeUtilities>             mTimeUtilitiesPtr;
        std::unique_ptr <ClientManagerModel>        mClientManagerModelPtr;
        std::unique_ptr <EventsManagerModel>        mEventsManagerModelPtr;
        std::unique_ptr <SystemStateReceiver>       mSystemStateReceiverPtr;
        std::unique_ptr <DataAccessModel>           mDataAccessModelPtr;
        std::unique_ptr <FilesHandlingModel>        mFilesHandlingModelPtr;
        std::unique_ptr <FileWriterModel>           mFileWriterModelPtr;
        std::unique_ptr <ConfigurationManagerModel> mConfigurationManagerPtr;
        std::unique_ptr <SamplersManagerModel>      mSamplersManagerModelPtr;
        std::vector < std::unique_ptr<DataLoggerModel> > mDataLoggerModels;
        void HandleLowSpacescenario();
};
}//End of DaqApp NS

