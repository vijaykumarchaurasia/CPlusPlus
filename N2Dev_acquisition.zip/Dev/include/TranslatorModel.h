#pragma once
#include <vector>
#include <unordered_map>
#include "ConfigMessage.h"
#include "FilesHandlingModel.h"

namespace DaqApp
{
class TranslatorModel
{
    public:
        explicit TranslatorModel(FilesHandlingModel*);
        ~TranslatorModel();
        TranslatorModel(const TranslatorModel&)            = delete;
        TranslatorModel& operator=(const TranslatorModel&) = delete;
        TranslatorModel(TranslatorModel&&)                 = delete;
        void SetUpTranslatorModel();
        bool Translate(std::vector<J1939ConfigMessage>*);
    private:
        bool ReadMappedSPNDataFromCSV(const std::string&);
        FilesHandlingModel* mFilesHandlingModelPtr;
        //Map will be filled through Topic List.csv
        std::unordered_multimap<std::string, J1939ConfigMessage> mSpnMap;
};
}//End of DaqApp NS
