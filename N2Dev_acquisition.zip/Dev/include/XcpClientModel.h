#pragma once
#include <unordered_map>
#include <ecu/diag/cp.h>
#include "ConfigMessage.h"

using namespace ecu::lapi::diag;
namespace DaqApp
{
class AppManager;

class XcpClientModel
{
    public:
        explicit XcpClientModel(AppManager*);
        XcpClientModel(const XcpClientModel&)            = delete;
        XcpClientModel& operator=(const XcpClientModel&) = delete;
        XcpClientModel(XcpClientModel&&)                 = delete;
        virtual ~XcpClientModel();
        std::unordered_map<uint16_t, std::vector<XCPSignalDetails>> CreateDaqList();
        std::unordered_map<uint16_t, std::vector<XCPSignalDetails>> GetXCPSignalDetails();
        ecu::lapi::diag::DaqList GetDaqList();
    private:
        XCPEcuPropertiesConfigMessage           mXCPEcuPropertiesConfigMessage;
        std::vector<XCPConfigMessage>           mXCPConfiguration;
        ecu::lapi::diag::DaqList                mDaqlist;
        static uint16_t                         mDaqIdCounter;
        std::map<std::string, uint32_t>         mXCPSignalSize;
        std::unordered_map<uint16_t, std::vector<XCPSignalDetails>> mXCPSignalDetails;
        void CreateDataEntryStaticData(ecu::lapi::diag::DaqEntry&);
        void InitSizeMap();
};
}//End of DaqApp NS
