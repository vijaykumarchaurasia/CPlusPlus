#pragma once
#include <memory>
#include <vector>
#include <boost/filesystem.hpp>
#include <ecu/com/client.h>
#include <ecu/com/backend.h>
#include "TimeUtilities.h"
#include "AppManager.h"
#include "ConfigMessage.h"

using namespace ecu::lapi::config;
using namespace ecu::lapi::com;
using namespace DaqTime;

namespace DaqApp
{
class AppManager;
class DataConnectivityModel;
class DaqContentHandler;
namespace boostfs = boost::filesystem;
enum class ResponseCode:long
{
    IntiUploadSuccess  = 200,
    UploadSuccess      = 201,
    NotifyIOTHubSuccess= 204,
    AuthTokenSuccess   = 200,
    BadRequest         = 400,
    UnAuthorized       = 401,
    Forbidden          = 403,
    NotFound           = 404,
    NotAcceptable      = 406,
    InternalServerError= 500,
    CumminsAccessToken = 200
};

enum class ConfigStatus:short int
{
    Acknowledged =  0,
    Processing   =  1,
    Success      =  2,
    Failed       = -1
};

class CloudServicesModel
{
    public:
        explicit CloudServicesModel(AppManager*);
        ~CloudServicesModel();
        CloudServicesModel(const CloudServicesModel&)            = delete;
        CloudServicesModel& operator=(const CloudServicesModel&) = delete;
        CloudServicesModel(CloudServicesModel&&)                 = delete;
        void SetUpCloudServicesModel();
        DaqContentHandler* GetDaqContentHandler();
        DataConnectivityModel* GetDataConnectivityModel();
        bool UploadFile(const std::string&, const std::string&);
        void SetConfigStatus(ConfigStatus, const std::string&,const std::pair<std::string, std::string>& passedPairCodeReason = std::make_pair("",""));
        void SetConfigCorrelationId(const std::string&);
        BackendClient_ptr GetBackendClient();
        std::string GetBlobName();
        CumminsAccessTokenResponse CumminsAccessToken(uint64_t, const std::string&);//uint64_t

    private:
        AppManager*                             mAppManagerHandlePtr;
        std::string                             mClientId;
        std::string                             mClientSecret;
        std::string                             mSubscriptionKey;
        std::string                             mVersion;
        std::string                             mAuthToken;
        std::string                             mBlobName;
        std::string                             mCorrelationId;
        std::string								mFileUploadCorrelationId;
        std::string                             mDeviceSerialNo;
        std::string                             mEquipmentId;
        std::string                             mEngineSerialNo;
        std::string                             mEngineVIN;
        std::string                             mFilePath;
        const std::pair<std::string,int>        mContentIdAppMap{"CloudServices",112};
        std::map<std::string, int>              mMapFilePendingToUpload;
        static BackendClient::ConnectionState   mBackendState;
        std::unique_ptr<DataConnectivityModel>  mDataConnectivityPtr;
        std::unique_ptr<DaqContentHandler>      mDaqContentHandlerPtr;
        ITransportClient_ptr                    mTransportClientPtr;
        BackendClient_ptr                       mBackendClientPtr;
        TimeUtilities*                          mTimeUtilitiesPtr;
        TickId                                  mNotifyConfigStatusTickId;
        std::string                             mConfigCorrelationId;
        ConfigFrom                              mConfigReceivedFrom;
        std::pair<int,std::string>              mUploadCodeReason;
        static size_t CurlWrite(void *, size_t , size_t , std::string *);
        static size_t CurlPutWrite(void *, size_t , size_t , std::string *);
        bool InitiateUpload(const std::string&);
        bool UploadFileToBlob(const std::string&);
        bool NotifyIotHub();
        std::string GetAuthToken();
        std::string GetResponse(const long&);
        bool UploadFileWrapper(const std::string&);
        void SendConfigStatusNotification(ConfigStatus, const std::string&, const std::string&, const std::string&);
};
}//End of DaqApp NS

