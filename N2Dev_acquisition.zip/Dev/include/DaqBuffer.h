#pragma once
#include <boost/circular_buffer.hpp>

namespace DaqApp
{
struct Record;
class DaqBuffer
{
    public:
        explicit DaqBuffer();
        ~DaqBuffer();
        boost::circular_buffer<Record>  mPreBuffer;
        std::vector<Record>             mSampledBuffer;
};
}//End of DaqApp NS
