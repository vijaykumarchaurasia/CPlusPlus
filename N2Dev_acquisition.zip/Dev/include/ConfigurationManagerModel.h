#pragma once
#include <memory>
#include <vector>
#include <string>
#include "JsonParserModel.h"
#include "ConfigMessage.h"
#include "EventsManagerModel.h"
#include "ClientManagerModel.h"

namespace DaqApp
{
class AppManager;
class FilesHandlingModel;
class TranslatorModel;
class ValidationModel;

class ConfigurationManagerModel
{
    public:
        explicit ConfigurationManagerModel(AppManager*);
        ~ConfigurationManagerModel();
        ConfigurationManagerModel(const ConfigurationManagerModel&)            = delete;
        ConfigurationManagerModel& operator=(const ConfigurationManagerModel&) = delete;
        ConfigurationManagerModel(ConfigurationManagerModel&&)                 = delete;
        std::vector<UDSConfigMessage>&          GetUdsConfig ();
        std::vector<XCPParameterConfigMessage>& GetXcpParameterConfig();
        std::vector<XCPConfigMessage>&          GetXCPConfig();
        XCPEcuPropertiesConfigMessage           GetXcpEcuPropertiesConfig();
        std::vector<J1939ConfigMessage>&        GetJ1939Config ();
        std::vector<EventConfigMessage>&        GetEventsConfig();
        std::vector<CompositeEventConfig>&      GetCompositeEventsConfig();
        std::vector<DataLoggerConfig>&          GetDataLoggerConfig();
        std::vector<GpsSamplerConfig>           GetGpsSamplerConfig();
        std::vector<ActivateDataConfig>&        GetActivateDataConfig();
        DeActivateDataConfig                    GetDeActivateDataConfig();
        std::vector<ForgetConfig>               GetForgetConfig();
        int                                     GetPreBufferCount();
        TranslatorModel*                        GetTranslatorModel();
        void ParseJson(const Json::Value&);
        void SetUpConfigurationManager();
        ConfigFrom                              GetActivatedConfigFrom();

    private:
        std::unique_ptr<JsonParserModel>        mJsonParserPtr;
        std::unique_ptr<TranslatorModel>        mTranslatorPtr;
        std::unique_ptr<ValidationModel>        mValidationPtr;
        FilesHandlingModel*                     mFilesHandlingModelPtr;
        EventsManagerModel*                     mEventsManagerHandlePtr;
        ClientManagerModel*						mClientsManagerModelPtr;
        std::vector<J1939ConfigMessage>         mJ1939Configuration;
        std::vector<XCPParameterConfigMessage>  mXcpParameterConfiguration;
        std::vector<XCPConfigMessage>           mXCPConfiguration;
        XCPEcuPropertiesConfigMessage           mXcpEcuPropertiesConfiguration;
        std::vector<UDSConfigMessage>           mUdsConfiguration;
        std::vector<EventConfigMessage>         mEventsConfiguration;
        std::vector<CompositeEventConfig>       mCompositeEventConfiguration;
        std::vector<DataLoggerConfig>           mDataLoggerConfiguration;
        std::vector<GpsSamplerConfig>           mGpsSamplerConfiguration;
        std::vector<ActivateDataConfig>         mActivateDataConfiguration;
        DeActivateDataConfig                    mDeActivateDataConfiguration;
        std::vector<ForgetConfig>               mForgetConfiguration;
        SamplingProtocols                       mProtocol;
        ConfigIds                               mConfigIds;
        ConfigFrom                              mActivatedConfigFrom;
        int mFileCounter {0}                                        ;
        std::set<std::string>                   mProtocols;

        void ParseJ1939Config(const Json::Value&);
        void ParseXCPParameterConfig(const Json::Value&);
        void ParseXCPEcuPropertiesConfig(const Json::Value&);
        std::string GetEcuParameterBaudRate(const Json::Value&);
        void ParseEventConfig(const Json::Value&);
        void ParseCompositeEventConfig(const Json::Value&);
        void ParseEALConfig(const Json::Value& uds_config,const std::string&);
        void ParseDataLoggerConfig(const Json::Value&);
        void ParseDataSamplingConfig(const Json::Value&);
        void ParseActivateDataConfig(const Json::Value&);
        void ParseGPSConfig(const Json::Value&);
        void AddSourceForJ1939();
        void ResetConfigValues();
        void NewConfigurationReceived();
        void ParseTripDataConfig(const Json::Value&,const std::string&);
        void SetSamplingRateForEAL();
        void SetSamplingRateForTripData(uint32_t TransmissionRate);
        uint32_t getTransmissionRateForTripData(const Json::Value&);
        void ParseDeActivateDataConfig(const Json::Value&);
        void ParseForgetConfig(const Json::Value&);
        void SetActivatedConfigFrom(ConfigFrom);
        std::string GetSamplingConfigId(const Json::Value&);

};
}//End of DaqApp NS
