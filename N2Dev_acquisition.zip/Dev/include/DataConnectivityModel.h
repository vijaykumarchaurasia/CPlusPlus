#pragma once
#include <ecu/com/client.h>
#include <ecu/pb/modem.pb.h>
#include <ecu/com/messageadapter.h>
#include <SamplerModel.h>

using namespace ecu::lapi::pb;
using namespace ecu::lapi::com;
namespace DaqApp
{
class AppManager;
class DataConnectivityModel: public SamplerModel, public ISubscriptionObserver
{
    public:
        explicit DataConnectivityModel(AppManager*);
        ~DataConnectivityModel();
        DataConnectivityModel(const DataConnectivityModel&)            = delete;
        DataConnectivityModel& operator=(const DataConnectivityModel&) = delete;
        DataConnectivityModel(DataConnectivityModel&&)                 = delete;
        bool CheckInternetConnectivity();
        void SetUpDataConnectivityModel();
    private:
        void message(const std::string& , const Message& ) override;
        AppManager*                           mAppManagerPtr;
        ITransportClient_ptr 	              mTransportClientPtr;
        ISubscriptionObserver_ptr 			  mSdkCallBackPtr;
        const std::string mTopicModemStatus = "system/modem/status";
        ModemStatus::ModemState mModemState; // 11 Connected
};
}//End of DaqApp NS

