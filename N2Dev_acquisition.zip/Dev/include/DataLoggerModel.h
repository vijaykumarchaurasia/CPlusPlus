#pragma once
#include "AppManager.h"
#include "TimeUtilities.h"
#include "Record.h"
#include "DaqBuffer.h"
#include "ConfigMessage.h"

using namespace DaqApp;

namespace DaqApp
{
class AppManager;
class ConfigurationManagerModel;
class DataAccessModel;
class EventsManagerModel;
class SystemStateReceiver;

class DataLoggerModel
{
    public:
        explicit DataLoggerModel(AppManager*, const DataLoggerConfig&, const ActivateDataConfig&);
        ~DataLoggerModel();
        DataLoggerModel(const DataLoggerModel&)            = delete;
        DataLoggerModel& operator=(const DataLoggerModel&) = delete;
        DataLoggerModel(DataLoggerModel&&)                 = delete;
        void SetUpDataLogger();
        std::vector<Record>& GetNormalBuffer();
        boost::circular_buffer<Record>& GetPreBuffer();
        void StopSamplingOnError();

    private:
        void OnPeriodic();
        void OnStartEvent();
        void AddRecordsToNormalBuffer();
        void OnStopEvent();
        void AddRecordsToPostBuffer();
        void AttachPreBuffer();
        void AddRecordsToPreBuffer();
        void CopyPreBuffer();
        void StopPreBufferSampling();
        void SendBufferToFile();
        void PrintDataLoggerDetails();
        void OnShutdownSignalEvent();
        void WriteFileWriterMessageValues();
        void AddStartingEventTimestamp();
        void AddEndingEventTimestamp();
        Priority GetPriority(const std::string&);

        AppManager*                 mAppManagerHandle;
        EventsManagerModel*         mEventsManagerHandle;
        DataAccessModel*            mDataAccessModelHandle;
        TimeUtilities*              mTimeUtilitiesHandle;
        ConfigurationManagerModel*  mConfManagerModelHandle;
        std::unique_ptr <DaqBuffer> mDaqBuffer; //Composite class
        bool                        mCurrentlySampling;
        bool                        mStartingEventIsSet;
        bool                        mEndingEventIsSet;
        unsigned int                mBufferThresHold;//Normal Buffer size
        TickId                      mPeriodicTickId;
        TickId                      mPreBufferTickId;
        TickId                      mSamplingTickId;
        TickId                      mPostBufferTickId;
        DataLoggerConfig            mConfig;
        SystemStateReceiver*        mSystemStateReceiverPtr = nullptr;
        FileWriterMessage           mFileWriterMessage;
        ActivateDataConfig          mActivateDataConfig;
};
}//End of DaqApp NS
