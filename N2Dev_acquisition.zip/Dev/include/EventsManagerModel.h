#pragma once
#include <mutex>
#include <vector>
#include <boost/signals2.hpp>
#include "TimeUtilities.h"

using namespace DaqTime;

namespace DaqApp
{
using DaqAppSignal = boost::signals2::signal<void ()>;
class AppManager;
class SimpleEventModel;
class CompositeEventModel;

class EventsManagerModel
{
    public:
        explicit EventsManagerModel(AppManager*);
        ~EventsManagerModel();
        EventsManagerModel(const EventsManagerModel& other)            = delete;
        EventsManagerModel& operator=(const EventsManagerModel& other) = delete;
        EventsManagerModel(EventsManagerModel&&)                       = delete;
        void SetUpEventsManager();
        bool GetEventStatus(const std::string&);
        void AddSignal(const std::string&);
        bool ConnectToSignal(const std::string&,const DaqAppSignal::slot_type&);
        bool DisconnectFromSignal(const std::string&,void (*slotToDisconnect)());
        void EmitSignal(const std::string&);
        void DisconnectAll();
        void EvaluateEvents();
    private:
        AppManager*                                         mAppManagerHandlePtr;
        std::vector<std::unique_ptr<SimpleEventModel> >     mEvents;
        std::vector<std::unique_ptr<CompositeEventModel> >  mCompositeEvents;
        std::map<std::string,std::unique_ptr<DaqAppSignal>> mDynamicSignalsMap;
        TickId                                              mTickId;
        std::mutex                                          mSignalMtx;

};
} //End of DaqApp NS
