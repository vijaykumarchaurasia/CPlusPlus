#include <ecu/com/client.h>
#include <ecu/com/observer.h>

using namespace ecu::lapi::com;
namespace DaqApp
{
class AppManager;

class SystemStateReceiver : public ISubscriptionObserver
{
    public:
        SystemStateReceiver( AppManager*);
        virtual ~SystemStateReceiver();
        SystemStateReceiver(const SystemStateReceiver&)            = delete;
        SystemStateReceiver& operator=(const SystemStateReceiver&) = delete;
        SystemStateReceiver(SystemStateReceiver&&)                 = delete;
        bool RequestShutdownPostpone();
        void SetupSystemStateReceiver(ecu::lapi::com::ITransportClient_ptr);

        const std::string PostponableShutDownEvent{"PostponableShutDownEvent"};
        const std::string NonPostponableShutDownEvent{"NonPostponableShutDownEvent"};
    private:
        enum class ShutdownType
        {
            NOTDEFINED = 0,
            POSTPONABLE = 1,
            NONPOSTPONABLE = 2
        };
        void message(const std::string& , const Message& ) override;
        void PostponeShutDownOnce();
        void handleShutdownEvent(const Message&);
        ecu::lapi::com::ITransportClient_ptr mTransportClientPtr;
        AppManager*                     mAppManagerPtr;
        ISubscriptionObserver_ptr       mSdkCallBackPtr;
        static constexpr const char*    TOPIC_SHUTDOWN_POSTPONE = "rt/system/shutdown/postpone";
        ShutdownType                    mShutdownEventType{ShutdownType::NOTDEFINED};
};
}//End of DaqApp NS
