# pragma once

// Directory names
#ifdef DAQEMULATOR
    // Below paths are for Emulator.
    const std::string COMMON_DIR            = "common";
    const std::string BASE_CONFIG_DIR       = "common/ConfigFiles" ;
    const std::string ACTIVE_CONFIG_DIR     = "common/ConfigFiles/ActiveConfigFiles";
    const std::string INACTIVE_CONFIG_DIR   = "common/ConfigFiles/InActiveConfigFiles";
    const std::string MISC_DIR              = "common/Miscellaneous";
    const std::string LOG_DIR               = "common/LogFiles";
    const std::string LOG_LOW_DIR           = "common/LogFiles/LowPriority";
    const std::string LOG_NORMAL_DIR        = "common/LogFiles/NormalPriority";
    const std::string LOG_HIGH_DIR          = "common/LogFiles/HighPriority";
#else
    // Below paths are for N2 Device.
    const std::string COMMON_DIR            = "/common";
    const std::string BASE_CONFIG_DIR       = "/common/ConfigFiles" ;
    const std::string ACTIVE_CONFIG_DIR     = "/common/ConfigFiles/ActiveConfigFiles";
    const std::string INACTIVE_CONFIG_DIR   = "/common/ConfigFiles/InActiveConfigFiles";
    const std::string MISC_DIR              = "/common/Miscellaneous";
    const std::string LOG_DIR               = "/common/LogFiles";
    const std::string LOG_LOW_DIR           = "/common/LogFiles/LowPriority";
    const std::string LOG_NORMAL_DIR        = "/common/LogFiles/NormalPriority";
    const std::string LOG_HIGH_DIR          = "/common/LogFiles/HighPriority";
#endif // DAQEMULATOR

const std::string TXT_EXT   = ".txt";
const std::string CSV_EXT   = ".csv";
const std::string GZIP_EXT  = ".gz";
const std::string JSON_EXT  = ".json";

const std::string LATITUDE                  = "Latitude";
const std::string LONGITUDE                 = "Longitude";
const std::string ALTITUDE                  = "Altitude";
const std::string DIRECTION_HEADING         = "Direction_Heading";
const std::string GPS_VEHICLE_SPEED         = "GPS_Vehicle_Speed";

const std::string TOPIC_TEL_PGN_REQUEST_4A  = "rt/telcan/tel_pgn_request_4a";
const std::string TOPIC_TEL_E_CCVS1         = "rt/telcan/e_ccvs1";
const std::string TOPIC_SHUTDOWN_STATUS     = "system/shutdown/status";
const std::string NAVISTAR_TSP_NAME         = "Navistar";
const std::string CUMMINS_TSP_NAME          = "Cummins";

// File names
const std::string CONFIGURATION_FILE_NAME   = "Configuration.json";

const std::string XCP_ERROR_TRIGGERED_SIGNAL   = "XCPErrorTriggered";
const std::string FILE_WRITING_COMPLETED_SIGNAL   = "FileWritingCompleted";
