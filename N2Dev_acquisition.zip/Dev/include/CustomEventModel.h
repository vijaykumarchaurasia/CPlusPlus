#pragma once

namespace DaqApp
{
class CustomEventModel
{
    public:
        explicit CustomEventModel();
        ~CustomEventModel();
        CustomEventModel(const CustomEventModel&)            = delete;
        CustomEventModel& operator=(const CustomEventModel&) = delete;
        CustomEventModel(CustomEventModel&&)                 = delete;
};
}//End of DaqApp NS
