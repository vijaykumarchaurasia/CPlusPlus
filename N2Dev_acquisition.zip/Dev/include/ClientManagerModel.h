#pragma once
#include <ecu/com/client.h>
#include <ecu/variables.h>
#include <ecu/sysparams.h>
#include "TimeUtilities.h"

namespace DaqApp
{
class AppManager;
class ClientManagerModel
{
    public:
        explicit ClientManagerModel(AppManager* passed);
        ~ClientManagerModel();
        ClientManagerModel(const ClientManagerModel&)            = delete;
        ClientManagerModel& operator=(const ClientManagerModel&) = delete;
        ClientManagerModel(ClientManagerModel&&)                 = delete;
        void SetUpClientManager();
        ecu::lapi::com::ITransportClient_ptr getTransportClient();
        ecu::lapi::var::SysParamsClient_ptr getSystemParameterClient();
        bool ConfigureCAN2Baudrate(const std::string&);

    private:
        AppManager*							 mAppManPtr;
        ecu::lapi::config::Configuration_ptr mConfigPtr;
        ecu::lapi::com::ITransportClient_ptr mClientPtr = nullptr;
        ecu::lapi::var::SysParamsClient_ptr  mSysParamsClientPtr = nullptr;
        DaqTime::TickId						 mTick;
		const int 							 mSysParamCAN2BaudRate = 41089;		//System Parameter ID to configure CAN2 channel Baud Rate
        
		void WriteSysParameterClient(void);
};
}//End of DaqApp NS
