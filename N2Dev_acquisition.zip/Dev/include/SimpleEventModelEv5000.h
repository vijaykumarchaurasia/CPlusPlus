#pragma once
#include "SimpleEventModel.h"

namespace DaqApp
{
class EventsManagerModel;

class SimpleEventModelEv5000 final : public SimpleEventModel
{
    public:
        explicit SimpleEventModelEv5000(EventConfigMessage, EventsManagerModel *, AppManager *);
        virtual~SimpleEventModelEv5000();
        SimpleEventModelEv5000(const SimpleEventModelEv5000& )            = delete;
        SimpleEventModelEv5000& operator=(const SimpleEventModelEv5000& ) = delete;
        SimpleEventModelEv5000(SimpleEventModelEv5000&&)                  = delete;
        void Evaluate() override;
    private:
        AppManager*         mAppManagerHandlePtr;
        EventsManagerModel* mEventsManagerHandlerPtr;
        EventConfigMessage  mConfigMessage;
        std::string         mPrevVal= "";
};
}//End of DaqApp NS

