#pragma once
#include <ecu/com/client.h>
#include <ecu/com/observer.h>
#include "SamplerModel.h"

using namespace ecu::lapi::com;

namespace DaqApp
{
class AppManager;
class DataAccessModel;
struct J1939ConfigMessage;

class DtcSamplerModel : public SamplerModel, public ISubscriptionObserver
{
    public:
        explicit DtcSamplerModel(AppManager*, ITransportClient_ptr, J1939ConfigMessage);
        virtual ~DtcSamplerModel();
        DtcSamplerModel(const DtcSamplerModel&)            = delete;
        DtcSamplerModel& operator=(const DtcSamplerModel&) = delete;
        DtcSamplerModel(DtcSamplerModel&&)                 = delete;
        int FindSpnIndex(int);
        int GetFmi(int);
        int GetOc(int);
    private:
        ISubscriptionObserver_ptr   mSdkCallBackPtr;
        AppManager*                 mAppManagerPtr;
        DataAccessModel*            mDataAccessModelPtr;
        const std::string           mTopic;
        const std::string           mSignal;
        const std::string           mPgn;
        std::string                 mSourceAddress;
        std::string                 mDmStringData;
        unsigned int                mSpn19bit;
        unsigned int                mFmi;
        unsigned int                mOc;
        std::vector<int>            mDmData;
        ITransportClient_ptr        mClientPtr;
        ConfigIds                   mConfigId;
        void message(const std::string& , const Message& ) override;
};
}//End of DaqApp NS
