#pragma once
using namespace ecu::lapi::com;

namespace DaqApp
{
class AppManager;
class EventsManagerModel;
class FilesHandlingModel;

class DaqContentHandler
{
    public:
        explicit DaqContentHandler(AppManager*);
        ~DaqContentHandler();
        DaqContentHandler(const DaqContentHandler&)            = delete;
        DaqContentHandler& operator=(const DaqContentHandler&) = delete;
        DaqContentHandler(DaqContentHandler&&)                 = delete;
        void Content112Callback(const uint32_t, const Message&);
        void SetFileInProgress(bool);
    private:
        AppManager*         mAppManagerHandlePtr;
        EventsManagerModel* mEventsManagerHandlePtr;
        FilesHandlingModel* mFilesHandlingPtr;
        bool                mFileInProgress;
        std::vector<std::string> mMessageData;
        static size_t WriteData(void *, size_t , size_t , FILE *);
        void DownloadConfiguration(const std::string&);
        void WriteJsonConfigDataToFile(const Json::Value&);
};
}//End of DaqApp NS

