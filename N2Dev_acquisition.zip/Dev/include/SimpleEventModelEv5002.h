#pragma once
#include "SimpleEventModel.h"

namespace DaqApp
{
class EventsManagerModel;

class SimpleEventModelEv5002 final: public SimpleEventModel
{
    public:
        explicit SimpleEventModelEv5002(EventConfigMessage, EventsManagerModel *, AppManager * );
        virtual~SimpleEventModelEv5002();
        SimpleEventModelEv5002(const SimpleEventModelEv5002&)            = delete;
        SimpleEventModelEv5002& operator=(const SimpleEventModelEv5002&) = delete;
        SimpleEventModelEv5002(SimpleEventModelEv5002&&)                 = delete;
        void Evaluate() override;
    private:
        AppManager*         mAppManagerHandlePtr;
        EventsManagerModel* mEventsManagerHandlerPtr;
        EventConfigMessage  mConfigMessage;
        std::string         mPrevVal= "";
};
}//End of DaqApp NS
