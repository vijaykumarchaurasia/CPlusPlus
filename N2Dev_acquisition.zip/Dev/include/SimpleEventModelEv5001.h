#pragma once
#include "SimpleEventModel.h"

namespace DaqApp
{
class EventsManagerModel;

class SimpleEventModelEv5001 final: public SimpleEventModel
{
    public:
        explicit SimpleEventModelEv5001(EventConfigMessage, EventsManagerModel *, AppManager * );
        virtual~SimpleEventModelEv5001();
        SimpleEventModelEv5001(const SimpleEventModelEv5001&)            = delete;
        SimpleEventModelEv5001& operator=(const SimpleEventModelEv5001&) = delete;
        SimpleEventModelEv5001(SimpleEventModelEv5001&&)                 = delete;
        void Evaluate() override;
    private:
        AppManager* mAppManagerHandlePtr;
        EventsManagerModel *mEventsManagerHandlerPtr;
        EventConfigMessage mConfigMessage;
        std::string  mPrevVal= "";
};
}//End of DaqApp NS
