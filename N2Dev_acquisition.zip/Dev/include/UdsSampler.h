#pragma once

#include <ecu/diag/uds.h>
#include <SamplerModel.h>
#include <unordered_map>
#include "ConfigMessage.h"
#include "FilesHandlingModel.h"
#include "TimeUtilities.h"

namespace DaqApp
{
	using namespace ecu::lapi::com;
	using namespace ecu::lapi::diag;

	class DataAccessModel;
	class AppManager;
    class SystemStateReceiver;

	class UdsSampler : public SamplerModel, public IUdsClientObserver, public ISubscriptionObserver
	{
		public:
		UdsSampler(ITransportClient_ptr client, std::vector<UDSConfigMessage> &UDSconfigmessage, AppManager* app_manager_passed);
		virtual ~UdsSampler();
		UdsSampler(const UdsSampler& other) = delete;
		UdsSampler& operator=(const UdsSampler& other) = delete;
		UdsSampler(UdsSampler&&) = delete;
		void message(const std::string& , const Message& ) override;

		private:
		const uint16_t mTesterPresentRequestPeriodms = 3500;
		enum SeedID
		{
			EALSEED = 0x11,
			LALSEED = 0x13
		};
		struct UdsResponse{
			bool isPositive = false;
			bool isNegative = false;
			uint8_t subFunction = 0x00;
			uint8_t NRC = 0x00;
			std::vector<uint8_t> data;
		};
		ITransportClient_ptr m_client;
		ISubscriptionObserver_ptr mSdkCallBackPtr;
		UdsClient_ptr m_uds_client_ptr = nullptr;
		AppManager*     mApp_manager_passed;
		TimeUtilities*  mTimeUtilitiesHandlePtr;
		std::vector<UDSConfigMessage> mVecUDSConfigMessage;
		std::unordered_map<std::string, UDSConfigMessage> ConfigIDMap;
		uint16_t mEcuTarget;
		int mUDSSamplerFailedRetries;
		std::string mDeviceId;
		uint32_t mLALSeed;
		std::vector<uint8_t> mEALSeed;
		std::vector<uint8_t> mAccessKey;
		uint32_t mUnEncryptedKey[4];
		uint32_t mAccessToken[4];
		std::unordered_map<uint16_t, TickId> mEAL$22RequestTick;
		TickId mTripDataTick;
		TickId mUDSHandlerTick;
		TickId mTesterPresentTick;
		UdsInterfaceState mUDSInterfaceStatus;
		std::mutex mUDSRequestMtx;
		std::mutex mTripDataMtx;
		std::mutex mOTACallbackMutex;
		FileWriterMessage mFileWriterMessage;
        SystemStateReceiver* mSystemStateReceiverPtr;
		UdsInterfaceAllocationConfig alloc_config
		{
			UdsInterfaceAllocationConfig::UDS_TRANSPORT_PROTOCOL_ISO,
			UdsInterfaceAllocationConfig::UDS_INTERFACE_CAN2,
			mEcuTarget,
		};
		const std::string CMISessionRcvTopic = "app/daq/rcv";
		const std::string CMISessionPubTopic = "app/daq/snd";
		bool CMISessionActive = false;
		bool UDSInitInProgress = false;
		bool InitializeClient(ITransportClient_ptr client);
		void on_connection_change(UdsInterfaceState state) override;
		void on_response(UdsMessage response) override;
		void HandleUDSSampling(void);
		bool RequestSeed(SeedID rqstType);
		bool StartTelematicsSession(void);
		bool TesterPresentRequest(void);
		bool UpdateDeviceId();
		bool SendEALData$BARequest( UDSConfigMessage &requestData);
		bool EALData$22Request(UDSConfigMessage &requestData);
		bool SendTripDataRequest(bool isPartial);
		bool AuthenticateECU(void);
		bool ProcessTripDataAndCheckEOD(std::vector<uint8_t> data);
		UdsResponse SendSyncRequest(UdsMessage request);
		std::vector<uint8_t> ConvertStringToByteVector(const std::string strToConvert);
		void WriteFileWriterMessageValues(const auto&);
		Priority GetPriority(const std::string&);
		void StopPeriodicRequests(void);
		void DeleteThread(TickId& tick);
		void DeleteThread(std::unordered_map<uint16_t, TickId>& tick);
        void OnShutdownSignalEvent();
        void Publish(std::string ota_request, std::string response);
	};
}//End of DaqApp NS
