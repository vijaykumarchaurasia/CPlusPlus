#pragma once
#include <unordered_map>
#include <ecu/diag/cp.h>
#include "ConfigMessage.h"
#include "SamplerModel.h"

using namespace ecu::lapi::diag;
namespace DaqApp
{
class AppManager;
class ConfigurationManagerModel;
class DataAccessModel;
class XcpClientModel;
class DataLoggerConfig;

enum class XcpCmd : unsigned short int
{
    AddList,
    ClearList,
    StartList,
    StopList
};

std::vector<uint8_t> ComputeKeyFromSeed(std::vector<uint8_t> RawSeed);

class XcpSampler  final:public SamplerModel, public ecu::lapi::diag::ICpClientObserver
{
    public:
        virtual ~XcpSampler();
        XcpSampler(const XcpSampler&)            = delete;
        XcpSampler& operator=(const XcpSampler&) = delete;
        XcpSampler(XcpSampler&&)                       = delete;

        XcpSampler( ecu::lapi::com::ITransportClient_ptr, AppManager*);

        bool InitializeXcpInterface();
        CpInterfaceState GetXCPInterfaceState();
        bool StartAndStopDaqList(XcpCmd);
        bool AddRemoveDaqList(XcpCmd);
    private:
        union BitField
        {
            unsigned long longVal;
            float floatVal;
        };
        void WriteToDataAccess(uint32_t);
        std::string ConvertXCPData(XCPSignalDetails);
        void on_connection_change(CpInterfaceState )override;
        void on_daq_data(const DaqData&) override;
		void on_daq_error(const DaqError&) override;
        void SetEcuProperties();
        void SampleXcpData();
        bool Validate_EPK();
        void GetAndValidateChecksumFromECU();
        void InitSignalForDataAccess();

        //<Daq ID, XCPSignalDetails> needs to be filled in on_response to XCPClient
        std::unordered_map<uint16_t, std::vector<XCPSignalDetails>> mXcpData;
        ecu::lapi::com::ITransportClient_ptr    mTransportClientPtr;
        ConfigurationManagerModel*              mConfigurationManagerModel;
        XCPEcuPropertiesConfigMessage           mXCPEcuPropertiesConfigMsg;
        DataAccessModel*                        mDataAccessModelPtr = nullptr;
        std::unique_ptr<XcpClientModel>         mXCPClientModelPtr;
        CpClient_ptr                            mXCPClientPtr = nullptr;
        CpInterfaceState                        mXCPInterfaceState;
        CpParamResource                         resource{false,true,false,false};
        CpClient::XcpUnlockSeedCallback         XcpUnlockResourceResponseCB {ComputeKeyFromSeed};
        EventsManagerModel*                     mEventsManagerModelPtr;
        ecu::lapi::diag::DaqList                mDaqList;
        bool                                    mIsErrorOccurred;
};
}//End of DaqApp NS
