#pragma once
#include <vector>
#include <ecu/com/client.h>
#include <memory>
#include "ConfigMessage.h"

namespace DaqApp
{
class AppManager;
class SamplerModel;
class ConfigurationManagerModel;
class SamplersManagerModel
{
    public:
        explicit SamplersManagerModel(AppManager*);
        virtual ~SamplersManagerModel();
        SamplersManagerModel(const SamplersManagerModel&)            = delete;
        SamplersManagerModel& operator=(const SamplersManagerModel&) = delete;
        SamplersManagerModel(SamplersManagerModel&&)                 = delete;
        void InitSystemParams();
        void SetUpSamplersManager();
    private:
        AppManager*                                 mAppManHandlePtr;
        ConfigurationManagerModel*                  mConfigManagerModelPtr;
        std::vector <std::unique_ptr<SamplerModel>> mSamplers;
        ecu::lapi::com::ITransportClient_ptr        mTransportClientPtr;
		std::vector<UDSConfigMessage> mVectUDSConfigMessage;
		// NOTE- this vector is a temporary change for testing purpose,
		// in future we will get this vector from ConfigurationMangerModel for UDS config.
};
}//End of DaqApp NS
