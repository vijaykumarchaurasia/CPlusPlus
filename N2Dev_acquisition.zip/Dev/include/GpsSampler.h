#pragma once
#include <string>
#include <ecu/com/observer.h>
#include <SamplerModel.h>
#include <AppManager.h>
#include <ConfigurationManagerModel.h>
#include <ecu/com/client.h>

using namespace ecu::lapi::com;

namespace DaqApp
{
class AppManager;
class DataAccessModel;
class ConfigurationManagerModel;

class GpsSampler:public SamplerModel, public ISubscriptionObserver
{
    public:
        GpsSampler (ecu::lapi::com::ITransportClient_ptr, AppManager*);
        virtual ~GpsSampler();
        GpsSampler(const GpsSampler&)            = delete;
        GpsSampler& operator=(const GpsSampler&) = delete;
        GpsSampler(GpsSampler&&)                 = delete;
    private:
        void message(const std::string& , const ecu::lapi::com::Message& ) override;
        void WriteToDataAccess();
        AppManager*                             mAppManagerPtr;
        DataAccessModel* 						mDataAccessModelPtr;
        ecu::lapi::com::ITransportClient_ptr 	mClient;
        ISubscriptionObserver_ptr 				mSdkCallBackPtr;
        float                                   mLatitude;
        float                                   mLongitude;
        float                                   mAtitude;
        float                                   mDirection_Heading;
        float                                   mGPS_Vehicle_Speed;

        /** GNSS Data Topic Name **/
        static constexpr const char* mTopicGPSDataPtr = "system/gnss/data";
        /** Connection to gnss hardware and have a fix. Equivalent to 'A' in nmea $GPRMC message. Longitude and latitude are valid. **/
        static constexpr int mStatusGnssConnected_SC = 3;
        /** No GNSS Fix. **/
        static constexpr int mQualityGnssNoFix_SC = 0;
        /** 2D Fix. **/
        static constexpr int mGnss2DFix_SC = 2;
        /** 3D Fix. **/
        static constexpr int mGnss3DFix_SC = 3;
        /** Number of satellites required to get reliable data **/
        static constexpr int mGnssRequiredNumOfSatellites_SC = 4;
        /** Out of range values **/
        static constexpr float mOutOfRangeLatitude = -1000;
        static constexpr float mOutOfRangeLongitude = -1000;
        static constexpr float mOutOfRangeAltitude = -1000;
        static constexpr float mOutOfRangeHeading = -1000;
        static constexpr float mOutOfRangeSpeed = -1000;
};
}//End of DaqApp NS
