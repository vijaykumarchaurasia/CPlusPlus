#pragma once
#include <ecu/com/client.h>
#include <ecu/diag/pgn.h>
#include <ecu/rt/signaladapter.h>
#include "TimeUtilities.h"
#include "CommonHeader.h"

using namespace DaqTime;
using namespace ecu::lapi::rt;
using namespace ecu::lapi::diag;
using namespace ecu::lapi::com;

namespace DaqApp
{

class J1939RequesterModel
{
    public:
        explicit J1939RequesterModel(PgnRequestClient_ptr , ITransportClient_ptr, double, uint8_t, TimeUtilities*, bool DoOnce = false);
        ~J1939RequesterModel();
        J1939RequesterModel(const J1939RequesterModel&)            = delete;
        J1939RequesterModel& operator=(const J1939RequesterModel&) = delete;
        J1939RequesterModel(J1939RequesterModel&&)                 = delete;
        void RequestPGN();
    private:
        ecu::lapi::diag::PgnRequestClient_ptr   mPgnClientPtr = nullptr;
        ecu::lapi::com::ITransportClient_ptr    mTransportClientPtr = nullptr;
        TimeUtilities*                          mTimeUtilitiesHandlePtr;
        double                                  mPGN;
        TickId                                  mTickIdRequest;
        bool                                    mDoOnce;
        const std::string                       mSignalName = "parametergroupnumber";
        const std::string                       mDestAddrName = "j1939_destination_address";
        uint8_t									mDestAddr;
};
}//End of DaqApp NS
