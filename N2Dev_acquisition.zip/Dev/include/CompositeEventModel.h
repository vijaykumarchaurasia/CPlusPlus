#pragma once
#include <string>
#include "TimeUtilities.h"
#include "ConfigMessage.h"

namespace DaqApp
{
class CompositeEventModel final
{
    public:
        explicit CompositeEventModel(CompositeEventConfig, EventsManagerModel *, AppManager *);
        ~CompositeEventModel();
        CompositeEventModel(const CompositeEventModel&)            = delete;
        CompositeEventModel& operator=(const CompositeEventModel&) = delete;
        CompositeEventModel(CompositeEventModel&&)                 = delete;
        void EvaluateSimpleEvents();
    private:
        AppManager* 			mAppManPtr;
        EventsManagerModel* 	mEventsManPtr;
        CompositeEventConfig 	mConfigMsg;
        std::string             mEventID;
        bool                    mIsActive;
        bool ApplyOperator(std::string , bool , bool );
        void emit() ;
};
}//End of DaqApp NS
