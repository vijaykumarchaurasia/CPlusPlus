#pragma once
#include <memory>
#include <ecu/com/client.h>
#include "SamplerModel.h"
#include "J1939RequesterModel.h"
#include "ConfigMessage.h"

using namespace ecu::lapi::com;
using namespace ecu::lapi::diag;
namespace DaqApp
{
class AppManager         ;
class DataAccessModel    ;

class J1939Sampler final:public SamplerModel, public ISubscriptionObserver
{
    public:
        J1939Sampler(ecu::lapi::com::ITransportClient_ptr, J1939ConfigMessage, AppManager*);
        virtual ~J1939Sampler();
        J1939Sampler(const J1939Sampler&)            = delete;
        J1939Sampler& operator=(const J1939Sampler&) = delete;
        J1939Sampler(J1939Sampler&&)                 = delete;
    private:
    void message(const std::string& , const Message& ) override;
    ecu::lapi::com::ITransportClient_ptr    mTransportClientPtr;
    J1939ConfigMessage                      mJ1939ConfigMessage;
    AppManager*                             mAppManagerPtr;
    DataAccessModel*                        mDataAccessModelPtr;
    ISubscriptionObserver_ptr               mSdkCallBackPtr;
    int                                     mSpn;
    PgnRequestClient_ptr                    mPgnClientPtr;
    std::unique_ptr<J1939RequesterModel>    mJ1939RequesterModelPtr;
    const uint8_t							mECUAddr = 0x00;
};

}//End of DaqApp NS
