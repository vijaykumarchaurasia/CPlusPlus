# pragma once
#include <string>
#include <deque>

namespace DaqApp
{

    //Checks the system's endianness.
    inline bool IsSystemBigEndian()
    {
        uint32_t endian = 1;
        //Check if the MSB is 01, which would indicate little endian, or is 00, indicating big endian.
        return (*(char *) &endian == 0x01) ? false : true;
    }



    //Swaps the bytes in an integer to the other
    //endianness.
    inline uint32_t SwapEndian(uint32_t val)
    {
        uint8_t * inPtr = (uint8_t *)&val;
        uint32_t returnVal;
        uint8_t * outPtr = (uint8_t *)&returnVal;
        outPtr[0] = inPtr[3];
        outPtr[1] = inPtr[2];
        outPtr[2] = inPtr[1];
        outPtr[3] = inPtr[0];
        return returnVal;
    }

    //The TEA algorithm, modified to always encrypt
    //in big-endian format.
    inline void encipherBigEndianTEA(uint8_t key[], uint32_t *const v, uint32_t *const w)
    {
        uint32_t key1 = *((uint32_t *)&key[0]);
        uint32_t key2 = *((uint32_t *)&key[4]);
        uint32_t key3 = *((uint32_t *)&key[8]);
        uint32_t key4 = *((uint32_t *)&key[12]);
        register uint32_t y = v[0], z = v[1], sum = 0, delta = 0x9e3779b9, n = 32;
        if(!IsSystemBigEndian())
        {
            y = SwapEndian(y);
            z = SwapEndian(z);
            key1 = SwapEndian(key1);
            key2 = SwapEndian(key2);
            key3 = SwapEndian(key3);
            key4 = SwapEndian(key4);
        }

        while(n-- > 0)
        {
            sum += delta;
            y += ((z << 4) + key1) ^ (z + sum) ^ ((z >> 5) + key2);
            z += ((y << 4) + key3) ^ (y + sum) ^ ((y >> 5) + key4);
        }
        w[0]=y; w[1]=z;
        if(!IsSystemBigEndian())
        {
            w[0] = SwapEndian(w[0]);
            w[1] = SwapEndian(w[1]);
        }
    }


    inline void decipherBigEndianTEA(uint8_t key[], uint32_t *const v, uint32_t *const w)
    {
        uint32_t key1 = *((uint32_t *)&key[0]);
        uint32_t key2 = *((uint32_t *)&key[4]);
        uint32_t key3 = *((uint32_t *)&key[8]);
        uint32_t key4 = *((uint32_t *)&key[12]);

        register uint32_t y = v[0], z = v[1], sum = 0xC6EF3720, delta = 0x9e3779b9, n = 32;
        if(!IsSystemBigEndian())
        {
            y = SwapEndian(y);
            z = SwapEndian(z);
            key1 = SwapEndian(key1);
            key2 = SwapEndian(key2);
            key3 = SwapEndian(key3);
            key4 = SwapEndian(key4);
        }

        while(n-- > 0)
        {
            z -= ((y << 4) + key3) ^ (y + sum) ^ ((y >> 5) + key4);
            y -= ((z << 4) + key1) ^ (z + sum) ^ ((z >> 5) + key2);
            sum -= delta;
        }
        w[0]=y; w[1]=z;
        if(!IsSystemBigEndian())
        {
            w[0] = SwapEndian(w[0]);
            w[1] = SwapEndian(w[1]);
        }
    }

}
