#pragma once
#include "SimpleEventModel.h"

namespace DaqApp
{
class EventsManagerModel;

class SimpleEventModelEv5004 final: public SimpleEventModel
{
    public:
        explicit SimpleEventModelEv5004(EventConfigMessage, EventsManagerModel *, AppManager * );
        virtual~SimpleEventModelEv5004();
        SimpleEventModelEv5004(const SimpleEventModelEv5004&)            = delete;
        SimpleEventModelEv5004& operator=(const SimpleEventModelEv5004&) = delete;
        SimpleEventModelEv5004(SimpleEventModelEv5004&&)                 = delete;
        void Evaluate() override;
    private:
        AppManager*         mAppManagerHandlePtr;
        EventsManagerModel* mEventsManagerHandlerPtr;
        EventConfigMessage  mConfigMessage;
        bool engRunning = false;
};
}//End of DaqApp NS
