#pragma once
#include <vector>
#include <map>
#include "ConfigMessage.h"
#include "TimeUtilities.h"

namespace DaqApp
{
class  AppManager;
struct Record;

class FileWriterModel
{
    public:
        explicit FileWriterModel(AppManager*);
        ~FileWriterModel();
        FileWriterModel(const FileWriterModel&)             = delete;
        FileWriterModel& operator=(const FileWriterModel&)  = delete;
        FileWriterModel(FileWriterModel&&)                  = delete;
        void WriteOutputFile(const std::vector <Record>, FileWriterMessage);
        void WriteOutputFile(const std::vector<uint8_t>&, FileWriterMessage);
        std::string GetOuputFileName();
        int GetPriorityFolderFilesCount(Priority);
        void WriteXCPErrorLogFile(FileWriterMessage);

    private:
        AppManager*                                     mAppManagerPtr;
        static int                                      mFileCounter;
        const std::map<SamplingProtocols, std::string>  mFileExtensionType;
        std::map<Priority, std::string>                 mPriorityDirectoryPath;
        SamplingProtocols                               mPreviousProtocolType = SamplingProtocols::InvalidProtocol;
        TimeUtilities*                                  mTimeUtilitiesHandle = nullptr;
        FileWriterMessage                               mFileWriterMessage;
        std::string                                     mOutputFileName = "";
        std::ofstream                                   mFileWriterPtr;
        std::map<Priority, std::vector<std::string>>    mPriorityFolderFileNames;
        std::string                                     mKeyCycleCnt = "0";
        std::vector <uint8_t>                           mTripData;
        std::vector <Record>                            mRecordsData;
        std::vector <std::vector<Record>>               mAllDDIDRecords;
        ConfigFrom                                      mActivatedConfigFrom;
        std::mutex mMutexFileWriter;

        std::string GenerateOutputFileName(SamplingProtocols);
        void Write();
        void CreateOutputFilePtr(const std::string&);
        void CheckForValidPriorityAndProtocol();
        void WriteStaticHeaderDataInFile(const std::string&, unsigned int&);
        void WriteSourcesInFile(const std::string&);
        void WriteTripDataInFile();
        void WriteSourceValuesInFile(const std::string&);
        void SetOutputFilePath();
        void WriteEventTimestamp(const std::string&);
        void WritePeriodicTimestamp(const std::string&, unsigned int&);
        void InitPriorityFolderFileNamesMap();
        std::string GetJ1939OrXCPOutputFileName(SamplingProtocols);
        std::string GetEALOutputFileName(SamplingProtocols);
        std::string GetTripDataOutputFileName(SamplingProtocols);
        bool IsValidDeviceInformation();
};
}//End of DaqApp NS
