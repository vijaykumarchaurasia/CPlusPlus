#pragma once
#include <fstream>
#include "json/json.h"

namespace DaqApp
{
class JsonParserModel
{
    public:
        explicit JsonParserModel();
        ~JsonParserModel();
        JsonParserModel(const JsonParserModel&)            = delete;
        JsonParserModel& operator=(const JsonParserModel&) = delete;
        JsonParserModel(JsonParserModel&&)                 = delete;
        Json::Value ParseJsonFile(const std::string&);
};
}//End of DaqApp NS

