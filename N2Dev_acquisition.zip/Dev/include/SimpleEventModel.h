#pragma once
#include <string>
namespace DaqApp
{
class SimpleEventModel
{
    public:
        explicit SimpleEventModel();
        virtual ~SimpleEventModel();
        SimpleEventModel(const SimpleEventModel&)            = delete;
        SimpleEventModel& operator=(const SimpleEventModel&) = delete;
        SimpleEventModel(SimpleEventModel&&)                 = delete;
        virtual void Evaluate() = 0 ;
        bool        mIsActive;
        std::string mEventID {"NotSet"} ;
};
}//End of DaqApp NS
