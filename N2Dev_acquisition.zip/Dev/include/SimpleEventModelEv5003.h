#pragma once
#include "SimpleEventModel.h"

namespace DaqApp
{
class EventsManagerModel;

class SimpleEventModelEv5003 final: public SimpleEventModel
{
    public:
        explicit SimpleEventModelEv5003(EventConfigMessage, EventsManagerModel *, AppManager * );
        virtual~SimpleEventModelEv5003();
        SimpleEventModelEv5003(const SimpleEventModelEv5003&)            = delete;
        SimpleEventModelEv5003& operator=(const SimpleEventModelEv5003&) = delete;
        SimpleEventModelEv5003(SimpleEventModelEv5003&&)                 = delete;
        void Evaluate() override;
    private:
        AppManager*         mAppManagerHandlePtr;
        EventsManagerModel* mEventsManagerHandlerPtr;
        EventConfigMessage  mConfigMessage;
};
}//End of DaqApp NS
