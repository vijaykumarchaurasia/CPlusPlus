# pragma once
# include <string>
# include <vector>
# include <map>
# include <ecu/diag/cp.h>

using namespace ecu::lapi::diag;

namespace DaqApp
{
enum class SamplingProtocols:short int
{
    InvalidProtocol = 0 ,
    J1939               , //(.csv file)
    XCP                 , //(.csv file)
    UDS                 ,
    TRIP_DATA           , // (.txt file, "NGDI Interface.pdf"/Page 11, 1.10 section)
    EAL                  // (separate .csv file for each DID)
};

enum class ConfigIds:short int
{
    InvalidConfig = 0 ,
    ConfigOne           , //(Config from the first file)
    ConfigTwo           , //(Config from the 2nd file)
    ConfigThree         , //(Config from the 3rd file)
    ConfigFour          , //(Config from the 4th file)
};

enum class TriggerType:short int
{
    InvalidTrigger = -1,
    EventDriven        ,
    Periodic           ,
};

enum class Priority
{
    InvalidPriority = 0 ,
    HIGH                ,
    NORMAL              ,
    LOW
};

enum class EventsType:short int
{
    InvalidEvent = -1,
    EV5000           ,
    EV5001           ,
    EV5002           ,
    EV5003           ,
    EV5004           ,
    EV5005           ,
    EV5006           ,
    DynamicEvent     ,
    DynamicXcpEvent  ,
    CompositeEvent // If more than one DynamicEvent
};

enum class ConfigProtocols:short int
{
    InvalidConfig = 0,
    J1939Config      ,
    XCPConfig        ,
    UDSConfig        ,
    EventConfig      ,
    DataLoggerConfig ,
    AppConfig

};

enum class ConfigFrom:short int
{
    Cummins  = 1,
    Navistar = 2
};

struct ConfigurationMessage
{
    ConfigProtocols protocol;
    mutable bool IsNavistarConfig = false; // Whether json is supported for Navistar or Cummins, it is assumed that this information will come from json file.

    ConfigurationMessage():
    protocol(ConfigProtocols::InvalidConfig) {}

    ConfigurationMessage(ConfigProtocols passedProtocol) :
    protocol(passedProtocol) {}
};

struct J1939ConfigMessage : ConfigurationMessage
{
    mutable std::string Topic  = "Not Set";
    mutable std::string Signal = "Not Set";
    mutable std::string Spn    = "-1"     ;
    mutable std::string Pgn    = "-1"     ;
    mutable std::string SourceAddress = "Not Set";
    mutable bool IsCyclic   =     true     ;
    ConfigIds ConfigID         = (ConfigIds::InvalidConfig);
    J1939ConfigMessage(){}
    J1939ConfigMessage(std::string passedTopic,std::string passedSignal,std::string passedSpn,
                       std::string passedPgn,std::string passedSourceAddress,bool passedIsCyclic):
    Topic(passedTopic)      ,
    Signal(passedSignal)    ,
    Spn(passedSpn)          ,
    Pgn(passedPgn)          ,
    SourceAddress(passedSourceAddress),
    IsCyclic(passedIsCyclic)
    {}
};

struct XcpInterfaceAllocationConfig
{
    int32_t xcp_interface;
    uint32_t baudrate;
    uint32_t source_ecu;
    uint32_t target_ecu;
    bool xcp_secure_access_required;
    XcpInterfaceAllocationConfig():
    xcp_interface(-1),
    baudrate(0),
    source_ecu(0),
    target_ecu(0),
    xcp_secure_access_required(false)
    {}
    XcpInterfaceAllocationConfig (int32_t passed_xcp_interface ,uint32_t passed_baudrate,
                                  uint32_t passed_source_ecu , uint32_t passed_target_ecu,
                                  bool passed_xcp_secure_access_required ) :
    xcp_interface(passed_xcp_interface),
    baudrate(passed_baudrate),
    source_ecu(passed_source_ecu),
    target_ecu(passed_target_ecu),
    xcp_secure_access_required(passed_xcp_secure_access_required)
    {}
};

struct XcpChecksumConfig
{
    uint32_t      xcp_checksum_address;
    int8_t        xcp_checksum_address_extension;
    uint32_t      xcp_checksum_mem_size;
    uint32_t xcp_checksum;
    std::string xcp_checksum_method;
    XcpChecksumConfig():
    xcp_checksum_address(0),
    xcp_checksum_address_extension(-1),
    xcp_checksum_mem_size (0),
    xcp_checksum(0),
    xcp_checksum_method("Not Set")
    {}
    XcpChecksumConfig(uint32_t passed_xcp_checksum_address, int8_t passed_xcp_checksum_address_extension,
                      uint32_t passed_xcm_checksum_mem_size, uint32_t passed_xcp_checksum,
                      std::string passed_xcp_checksum_method):
    xcp_checksum_address(passed_xcp_checksum_address),
    xcp_checksum_address_extension(passed_xcp_checksum_address_extension),
    xcp_checksum_mem_size (passed_xcm_checksum_mem_size),
    xcp_checksum(passed_xcp_checksum),
    xcp_checksum_method(passed_xcp_checksum_method)
    {}
};

struct XcpEpromIdentifierConfig
{
    std::string xcp_eprom_identifier_string;
    uint32_t    xcp_eprom_identifier_address;
    int8_t      xcp_eprom_identifier_address_extension;
    uint32_t    xcp_eprom_identifier_memsize;
    XcpEpromIdentifierConfig():
    xcp_eprom_identifier_string("invalid"),
    xcp_eprom_identifier_address(0),
    xcp_eprom_identifier_address_extension(-1),
    xcp_eprom_identifier_memsize(0)
    {}
    XcpEpromIdentifierConfig(std::string passed_xcp_eprom_identifier_string,
                             uint32_t    passed_xcp_eprom_identifier_address,
                             int8_t      passed_xcp_eprom_identifier_address_extension,
                             uint32_t    passed_xcp_eprom_identifier_memsize):
    xcp_eprom_identifier_string(passed_xcp_eprom_identifier_string),
    xcp_eprom_identifier_address(passed_xcp_eprom_identifier_address),
    xcp_eprom_identifier_address_extension(passed_xcp_eprom_identifier_address_extension),
    xcp_eprom_identifier_memsize(passed_xcp_eprom_identifier_memsize)
    {}
};

struct XCPEcuPropertiesConfigMessage : ecu::lapi::diag::CpEcuProperties
{
    mutable std::string xcp_ecu_software_identifier;
    mutable int32_t xcp_ecu_category;
    mutable int32_t xcp_seed_key_algorithm_identifier;
    mutable XcpInterfaceAllocationConfig xcp_interface_allocation_configuration;
    mutable XcpChecksumConfig xcp_checksum_configuration;
    mutable XcpEpromIdentifierConfig xcp_eprom_identifier_configuration;
    ByteOrder byte_order;
    AddrGranularity address_granularity;
    uint8_t  max_cto;
    uint32_t max_dto;
    DaqListMode daq_config_type;
    uint32_t max_daq;
    uint32_t max_event_channel;
    uint32_t min_daq;
    uint32_t max_odt_entry_size;
    bool slave_block_mode_supported;

    XCPEcuPropertiesConfigMessage():
    xcp_ecu_software_identifier("invalid"),
    xcp_ecu_category(-1),
    xcp_seed_key_algorithm_identifier(-1),
    xcp_interface_allocation_configuration(),
    xcp_checksum_configuration(),
    xcp_eprom_identifier_configuration(),
    byte_order(MSB_UNKNOWN),
    address_granularity(GRANULARITY_UNKNOWN),
    max_cto(8),
    max_dto(8),
    daq_config_type(UNKNOWN),
    max_daq(65535),
    max_event_channel(5),
    min_daq(0),
    max_odt_entry_size(255),
    slave_block_mode_supported(false)
    {}

    XCPEcuPropertiesConfigMessage(std::string passed_xcp_ecu_software_identifier,
                                  int32_t passed_xcp_ecu_category,
                                  int32_t passed_xcp_seed_key_algorithm_identifier,
                                  XcpInterfaceAllocationConfig passed_xcp_interface_allocation_configuration,
                                  XcpChecksumConfig passed_xcp_checksum_configuration,
                                  XcpEpromIdentifierConfig passed_xcp_eprom_identifier_configuration):
    xcp_ecu_software_identifier(passed_xcp_ecu_software_identifier),
    xcp_ecu_category(passed_xcp_ecu_category),
    xcp_seed_key_algorithm_identifier(passed_xcp_seed_key_algorithm_identifier),
    xcp_interface_allocation_configuration(passed_xcp_interface_allocation_configuration.xcp_interface,
                                           passed_xcp_interface_allocation_configuration.baudrate,
                                           passed_xcp_interface_allocation_configuration.source_ecu,
                                           passed_xcp_interface_allocation_configuration.target_ecu,
                                           passed_xcp_interface_allocation_configuration.xcp_secure_access_required),
    xcp_checksum_configuration(passed_xcp_checksum_configuration.xcp_checksum_address,
                               passed_xcp_checksum_configuration.xcp_checksum_address_extension,
                               passed_xcp_checksum_configuration.xcp_checksum_mem_size,
                               passed_xcp_checksum_configuration.xcp_checksum,
                               passed_xcp_checksum_configuration.xcp_checksum_method),
    xcp_eprom_identifier_configuration(passed_xcp_eprom_identifier_configuration.xcp_eprom_identifier_string,
                                       passed_xcp_eprom_identifier_configuration.xcp_eprom_identifier_address,
                                       passed_xcp_eprom_identifier_configuration.xcp_eprom_identifier_address_extension,
                                       passed_xcp_eprom_identifier_configuration.xcp_eprom_identifier_memsize)
    {}
};

struct XCPParameterConfigMessage : ConfigurationMessage
{
    mutable std::string xcp_parameter_name;
    mutable uint32_t xcp_parameter_address;
    mutable int8_t xcp_parameter_address_extension;
    mutable std::string xcp_parameter_data_type;
    mutable float xcp_parameter_conversion_factor;
    mutable float xcp_parameter_conversion_offset;
    ConfigIds config_id = (ConfigIds::InvalidConfig);
    XCPParameterConfigMessage():
    xcp_parameter_name("invalid"),
    xcp_parameter_address(0),
    xcp_parameter_address_extension(-1),
    xcp_parameter_data_type("invalid"),
    xcp_parameter_conversion_factor(0.0f),
    xcp_parameter_conversion_offset(-1)
    {}
    XCPParameterConfigMessage(
                     std::string passed_xcp_parameter_name,
                     uint32_t passed_xcp_parameter_address,
                     int8_t passed_xcp_parameter_address_extension,
                     std::string passed_xcp_parameter_data_type,
                     float passed_xcp_parameter_conversion_factor,
                     float passed_xcp_parameter_conversion_offset
                     ):
    xcp_parameter_name(passed_xcp_parameter_name),
    xcp_parameter_address(passed_xcp_parameter_address),
    xcp_parameter_address_extension(passed_xcp_parameter_address_extension),
    xcp_parameter_data_type(passed_xcp_parameter_data_type),
    xcp_parameter_conversion_factor(passed_xcp_parameter_conversion_factor),
    xcp_parameter_conversion_offset(passed_xcp_parameter_conversion_offset)
    {}
};


struct XCPConfigMessage : ConfigurationMessage
{
    mutable uint16_t transmission_rate_prescaler;
    mutable uint16_t event_channel_number;
    mutable uint16_t event_channel_priority;
    ecu::lapi::diag::DaqMode sampling_mode;
    mutable uint16_t rate;
    std::vector<XCPParameterConfigMessage> xcp_parameter_config_messages;
    ConfigIds ConfigID         = (ConfigIds::InvalidConfig);
    XCPConfigMessage()
    {}
    XCPConfigMessage(uint16_t passed_transmission_rate_prescaler,
                     uint16_t passed_event_channel_number,
                     uint16_t passed_event_channel_priority,
                     ecu::lapi::diag::DaqMode passed_sampling_mode,
                     uint16_t passed_rate,
                     std::vector<XCPParameterConfigMessage> passed_xcp_parameter_config_messages
                     ):
    transmission_rate_prescaler(passed_transmission_rate_prescaler),
    event_channel_number(passed_event_channel_number),
    event_channel_priority(passed_event_channel_priority),
    sampling_mode (passed_sampling_mode),
    rate(passed_rate),
    xcp_parameter_config_messages(passed_xcp_parameter_config_messages)
    {}
};

struct XCPSignalDetails
{
    std::string xcpSignalName;
    uint32_t    xcpSignalAddress;
    uint32_t    xcpSize;
    std::vector<uint8_t>    xcpData;
    std::string conversionDataType;
    float conversionFactor;
    float conversionOffset;
    ConfigIds configid ;

};

struct UDSConfigMessage : ConfigurationMessage
{
    mutable bool IsTripData;
    mutable bool IsEALData;
    mutable uint16_t EcuTarget;	// Not being used and after discussion remove later
    mutable uint16_t DDID;
    mutable bool IsPeriodic; // Not being used and after discussion remove later
    mutable uint16_t RequestRate; // Not being used and after discussion remove later
    mutable uint16_t SecurityAccessLevel;  // Not being used and after discussion remove later
    mutable std::string Protocol;
    mutable std::string SourceAddress;
    mutable std::vector<uint8_t> dataIds;
    mutable bool isPartialExtraction;		// Can be std::string Extraction for "Partial" or "Full"
    mutable uint32_t TransmissionRate;
    ConfigIds ConfigID         ;
    std::string UdsSignalName  ;
    std::string ConfigName     ;

    UDSConfigMessage():
    IsTripData          (false),
    IsEALData          (false),
    EcuTarget           (0),
    DDID                (0),
    IsPeriodic          (false),
    RequestRate         (0),
    SecurityAccessLevel (0),
    Protocol         ("Not Set"),
    SourceAddress	("Not Set"),
    isPartialExtraction (false),
    TransmissionRate(0),
    ConfigID(ConfigIds::InvalidConfig),
    UdsSignalName("Not Set"),
    ConfigName("Not Set")
    {}
    UDSConfigMessage(   bool passedIsTripData,    bool passedIsEALData,
                        int passedEcuTarget,
                        int passedDDID,           bool passedIsPeriodic,
                        int passedRequestRate,    int passedSecurityAccessLevel,
                        std::string passedProtocol, bool passedIsPartialExtraction, uint16_t passedTransmissionRate):
    IsTripData          (passedIsTripData),
    IsEALData           (passedIsEALData),
    EcuTarget           (passedEcuTarget),
    DDID                (passedDDID),
    IsPeriodic          (passedIsPeriodic),
    RequestRate         (passedRequestRate),
    SecurityAccessLevel (passedSecurityAccessLevel),
    Protocol            (passedProtocol),
    isPartialExtraction  (passedIsPartialExtraction),
    TransmissionRate(passedTransmissionRate)
    {}
};

struct EventConfigMessage : ConfigurationMessage
{
    mutable std::string  Source   ;
    mutable std::string  SourceAddress   ;
    mutable std::string  Operator ;
    mutable float Threshold       ;
    mutable EventsType   Type     ;
    mutable std::string EventId   ;
    mutable bool IsStartingEvent  ;
    mutable bool IsEndingEvent    ;
    mutable std::string ComplexEventOperator;
    mutable std::string  Protocol ;
    mutable int EvaluationRate    ;
    ConfigIds ConfigID            ;
    EventConfigMessage():
    Source   ("Not Set"),
    SourceAddress   ("Not Set"),
    Operator ("Not Set"),
    Threshold(-1)       ,
    Type     (EventsType::InvalidEvent),
    EventId   ("Not Set"),
    IsStartingEvent (false),
    IsEndingEvent   (false),
    ComplexEventOperator ("Not Set"),
    Protocol ("Not Set"),
    EvaluationRate (250),
    ConfigID  (ConfigIds::InvalidConfig)
    {}
    EventConfigMessage( std::string passedSource, std::string passedSourceAddress  , std::string passedOperator,
                        double passedThreshold,        EventsType passedType, std::string passedEventId,
                        bool passesIsStartingEvent, bool passedIsEndingEvent, std::string passedComplexEventOperator,
                        std::string passedProtocol, int passedEvaluateRate, ConfigIds passesConfigID):
    Source   (passedSource),
    SourceAddress   (passedSourceAddress),
    Operator (passedOperator),
    Threshold(passedThreshold),
    Type     (passedType),
    EventId   (passedEventId),
    IsStartingEvent (passesIsStartingEvent),
    IsEndingEvent (passedIsEndingEvent),
    ComplexEventOperator(passedComplexEventOperator),
    Protocol(passedProtocol),
    EvaluationRate(passedEvaluateRate),
    ConfigID(passesConfigID)
    {}
};

struct CompositeEventConfig :ConfigurationMessage
{
    mutable std::string CompositeEventId                           ;
    mutable std::vector< std::pair<std::string,std::string> > LogicalExpression ;
    mutable int EvaluationRate ;
    ConfigIds ConfigID         ;
    CompositeEventConfig():
    CompositeEventId(""),
    LogicalExpression(),
    EvaluationRate(250),
    ConfigID  (ConfigIds::InvalidConfig)
    {}
};

struct AppConfigMessage :ConfigurationMessage
{
    AppConfigMessage();
};

struct DataLoggerConfig :ConfigurationMessage
{
    mutable SamplingProtocols proto              ;
    mutable TriggerType   TriggerTypeId          ;
    mutable unsigned int  SamplingRate           ;
    mutable unsigned int  PreBufferSize          ;
    mutable unsigned int  PostBufferSize         ;
    mutable unsigned int  MaxSetSize             ;
    mutable unsigned int  MaxTransmitPeriod      ;
    mutable std::string PrePostEventDurationUnit ;
    mutable std::string StartingEventId          ;
    mutable std::string EndingEventId            ;
    ConfigIds ConfigID                           ;
    std::string UdsSignalName                    ;

    mutable std::string MessageFormatVersion     ;
    mutable std::string DataSamplingConfigId     ;

    DataLoggerConfig():
    proto               (SamplingProtocols::InvalidProtocol),
    TriggerTypeId       (TriggerType::InvalidTrigger)       ,
    SamplingRate        (0)                                 ,
    PreBufferSize       (0)                                 ,
    PostBufferSize      (0)                                 ,
    MaxSetSize          (0)                                 ,
    MaxTransmitPeriod   (0)                                 ,
    PrePostEventDurationUnit("Not Set")                     ,
    StartingEventId     ("")                                ,
    EndingEventId       ("")                                ,
    ConfigID  (ConfigIds::InvalidConfig)                    ,
    UdsSignalName("Not Set")                                ,
    MessageFormatVersion     ("")                           ,
    DataSamplingConfigId     ("")
    {}

    DataLoggerConfig(SamplingProtocols protocol, TriggerType passedtriggerType,int samplingRate, int preBufferSize,
    int postBufferSize, int maxSet,int maxTransmitPeriod, std::string passedPrePostEventDurationUnit, std::string passedStartingEventId,
    std::string passedEndingEventId, std::string passedMessageFormatVersion, std::string passedDataSamplingConfigId):
    proto           (protocol)          ,
    TriggerTypeId (passedtriggerType)   ,
    SamplingRate    (samplingRate)      ,
    PreBufferSize   (preBufferSize)     ,
    PostBufferSize  (postBufferSize)    ,
    MaxSetSize      (maxSet)            ,
    MaxTransmitPeriod(maxTransmitPeriod) ,
    PrePostEventDurationUnit(passedPrePostEventDurationUnit),
    StartingEventId (passedStartingEventId),
    EndingEventId  (passedEndingEventId),
    MessageFormatVersion (passedMessageFormatVersion),
    DataSamplingConfigId  (passedMessageFormatVersion)
    {}
};

struct FileWriterMessage : ConfigurationMessage
{
    mutable SamplingProtocols SamplingProtocolId    = SamplingProtocols::InvalidProtocol;
    mutable Priority PriorityId                     = Priority::InvalidPriority;
    mutable TriggerType TriggerTypeId               = TriggerType::InvalidTrigger; // if periodic then calculate time in filewriter
    mutable std::string MessageFormatVersion        = "MessageFormatVersion (NotSet)";
    mutable std::string DataEncryptionSchemeId      = "ES1";
    mutable std::string TelematicsBoxId             = "NA";
    mutable std::string ComponentSerialNumber       = "ComponentSerialNumber (NotSet)";
    mutable std::string DataSamplingConfigId        = "SamplingConfigId_(NotSet)";
    mutable std::vector<std::string> StartingEventDateTimestamps = {};
    mutable std::vector<std::string> EndingEventDateTimestamps = {};
    mutable std::string Description                 = "Description (NotSet)";
    // Required for output file name
    mutable std::string TSPName     = "TSPName_(NotSet)";
    mutable std::string ESN         = "NA";
    mutable std::string VIN         = "NA";
    mutable std::string DDID        = "DDID_(NotSet)";
    mutable std::string EALSourceAddr  = "SA_(NotSet)";
    ConfigIds           ConfigID    = ConfigIds::InvalidConfig;

    FileWriterMessage(){};
    FileWriterMessage(SamplingProtocols passedProtocol, Priority passedPriorityId , TriggerType passedTriggerType,
                      std::string passedMessageFormatVersion, std::string passedDataEncryptionSchemeId,
                      std::string passedTelematicsBoxId,  std::string passedComponentSerialNumber,
                      std::string passedDataSamplingConfigId, std::vector<std::string> passedStartingEventDateTimestamps,
                      std::vector<std::string> passedEndingEventDateTimestamps, std::string passedDescription,
                      std::string passedTSPName, std::string passedESN, std::string passedBoxId, std::string passedVIN, ConfigIds passConfigId):
    SamplingProtocolId(passedProtocol),
    PriorityId(passedPriorityId),
    TriggerTypeId(passedTriggerType),
    MessageFormatVersion(passedMessageFormatVersion),
    DataEncryptionSchemeId(passedDataEncryptionSchemeId),
    TelematicsBoxId(passedTelematicsBoxId),
    ComponentSerialNumber(passedComponentSerialNumber),
    DataSamplingConfigId(passedDataSamplingConfigId),
    StartingEventDateTimestamps(passedStartingEventDateTimestamps),
    EndingEventDateTimestamps(passedEndingEventDateTimestamps),
    Description(passedDescription),
    TSPName(passedTSPName),
    ESN(passedESN),
    VIN(passedVIN),
    ConfigID(passConfigId)
    {}
};

struct ActivateDataConfig
{
    mutable std::string DataSamplingConfigId;
    mutable bool ResumeMode                 ;
    mutable std::string DataPriority        ;
    mutable std::string DataTransmitMethod  ;
    ConfigIds ConfigID                      ;
    ActivateDataConfig()                    :
    DataSamplingConfigId("Not Set")         ,
    ResumeMode     (false)                  ,
    DataPriority     ("normal")             ,
    DataTransmitMethod("Not Set")           ,
    ConfigID  (ConfigIds::InvalidConfig)
    {}
    ActivateDataConfig(std::string passedDataSamplingConfigId, bool passedResumeMode, std::string passedDataPriority, std::string passedDataTransmitMethod):
    DataSamplingConfigId(passedDataSamplingConfigId),
    ResumeMode (passedResumeMode),
    DataPriority  (passedDataPriority),
    DataTransmitMethod(passedDataTransmitMethod)
    {}
};


struct DeActivateDataConfig
{
    mutable std::string DataSamplingConfigIds   ;
    mutable std::string DestinationIdType       ;
    ConfigIds ConfigID                          ;
    DeActivateDataConfig()                      :
    DataSamplingConfigIds ("Not Set")           ,
    DestinationIdType     ("Not Set")           ,
    ConfigID  (ConfigIds::InvalidConfig)
    {}
    DeActivateDataConfig(std::string passedDataSamplingConfigIds, std::string passedDestinationIdType):
    DataSamplingConfigIds (passedDataSamplingConfigIds),
    DestinationIdType  (passedDestinationIdType)
    {}
};

struct CumminsAccessTokenResponse
{
  mutable std::string APIVersion = "Not Set";
  mutable int         ProviderID = 0;
  mutable std::string TimeStamp = "Not Set";
  mutable std::string SessionKey = "Not Set";
  mutable std::string AccessKey = "Not Set";
  CumminsAccessTokenResponse() {}
  CumminsAccessTokenResponse(std::string passedAPIVersion, int passedProviderID, std::string passedTimeStamp,
    std::string passedSessionKey, std::string passedAccessKey) :
    APIVersion(passedAPIVersion), ProviderID(passedProviderID), TimeStamp(passedTimeStamp),
    SessionKey(passedSessionKey), AccessKey(passedAccessKey) {}
};

struct GpsSamplerConfig :ConfigurationMessage
{
    bool IsLatitude;
    bool IsLongitude;
    bool IsAltitude;
    bool IsDirection_Heading;
    bool IsGPS_Vehicle_Speed;
    ConfigIds ConfigID;
    GpsSamplerConfig():
    IsLatitude(false),
    IsLongitude(false),
    IsAltitude(false),
    IsDirection_Heading(false),
    IsGPS_Vehicle_Speed(false),
    ConfigID  (ConfigIds::InvalidConfig)
    {}

    GpsSamplerConfig(bool passedIsLatitude,bool passedIsLongitude, bool passedIsAltitude, bool passedIsDirection_Heading, bool passedIsGPS_Vehicle_Speed):
    IsLatitude(passedIsLatitude),
    IsLongitude(passedIsLongitude),
    IsAltitude(passedIsAltitude),
    IsDirection_Heading(passedIsDirection_Heading),
    IsGPS_Vehicle_Speed(passedIsGPS_Vehicle_Speed)
    {}
};

struct ForgetConfig
{
    mutable std::string DefinitionType  ;
    mutable std::string DefinitionId    ;
    ConfigIds ConfigID                  ;
    ForgetConfig():
    DefinitionType    ("Not Set")       ,
    DefinitionId    ("Not Set")         ,
    ConfigID  (ConfigIds::InvalidConfig)
    {}

    ForgetConfig(std::string passedDefinitionType,std::string passedDefinitionId):
    DefinitionType   (passedDefinitionType),
    DefinitionId   (passedDefinitionId)
    {}
};

}//End of DaqApp NS
