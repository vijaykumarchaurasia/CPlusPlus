/************************************************************************************************************
*
*                                   (c) Copyright, 2018 Navistar, Inc
*
*                    All rights reserved.  This file is the intellectual property of
*                    Navistar, Inc.; it may not be copied, duplicated or transferred
*                    to a third party without prior written permission.
*
************************************************************************************************************/

/************************************************************************************************************
*
*       Filename        : nsk.h
*
*       Programmer(s)   : Kinjal Patel
*
*       Description     : This file contains public definitions and function prototypes for the Navistar
*                         Seed-Key (NSK) DLL and Embedded Library.
*
************************************************************************************************************/
#ifndef _NSK_H_
#define _NSK_H_

/* Make sure functions are exported with C linkage under C++ compilers. */
#ifdef __cplusplus
extern "C"
{
#endif


#if (_WIN32 || _WIN64 || __CYGWIN__) && !defined UNIT_TESTING
#define PLATFORM_WINDOWS
#elif (_unix || __unix || __unix__ || __linux__) && !defined UNIT_TESTING
#define PLATFORM_LINUX
#else
#define PLATFORM_EMBEDDED
#endif  /* #if (_WIN32 || _WIN64 || __CYGWIN__) && !defined UNIT_TESTING */


/***********************************************************************************************************/
/*                                              INCLUDE FILES                                              */
/***********************************************************************************************************/
#if defined PLATFORM_WINDOWS
    #include <windows.h>
#endif  /* #if defined PLATFORM_WINDOWS */

#include <stdint.h>

/***********************************************************************************************************/
/*                                           PUBLIC DEFINITIONS                                            */
/***********************************************************************************************************/
#define NSK_SEED_KEY_LENGTH     16  /* Length of seed and key in bytes */
#define NSK_ENTROPY_LENGTH      32  /* Length of entropy data in bytes */
#define NSK_NONCE_LENGTH        16  /* Length of nonce data in bytes */

/* Function return codes */
#define NSK_SUCCESS             0
#define NSK_ERROR               1
#define NSK_RESEED_REQD         2

/* DLL related definitions */
#if defined PLATFORM_WINDOWS
/* undef used constants */
#undef EXTERN_C

/* Enable mixing C 'n C++ */
#if defined __cplusplus || defined _cplusplus
    #define EXTERN_C extern "C"
#else   /* #if defined __cplusplus || defined _cplusplus */
    #define EXTERN_C
#endif  /* #if defined __cplusplus || defined _cplusplus */

/* Define ADD_EXPORTS *only* when building the DLL. */
#if defined ADD_EXPORTS || defined _MSC_VER
    #define DLLAPI __declspec(dllexport)
#else   /* #if defined ADD_EXPORTS || defined _MSC_VER */
    #define DLLAPI __declspec(dllimport)
#endif  /* #if defined ADD_EXPORTS || defined _MSC_VER */

/* Define calling convention */
#define DLLCALLCONV __cdecl

#endif  /* #if defined PLATFORM_WINDOWS */

/***********************************************************************************************************/
/*                                            PUBLIC DATA TYPES                                            */
/***********************************************************************************************************/


/***********************************************************************************************************/
/*                                            GLOBAL VARIABLES                                             */
/***********************************************************************************************************/


/***********************************************************************************************************/
/*                                       PUBLIC FUNCTION PROTOTYPES                                        */
/***********************************************************************************************************/
#if defined PLATFORM_WINDOWS

/************************************************************************************************************
*  Function name:   nsk1019
*
*  Description:     This function computes key from seed for the specified access level. This function is
*                   available for Windows and Linux targets only.
*
*  Return value:    NSK_SUCCESS (0): Success
*                   NSK_ERROR   (1): Error
*
*  Parameters:      accessLevel    : Security access level for which the key will be computed
*                   *ecuSerialNum  : Pointer to buffer containing ECU serial number
*                   ecuSerialNumLen: Length of serial number buffer
*                   seed           : Buffer containing seed
*                   key            : Buffer where calculated key will be stored
*
************************************************************************************************************/
/* Function Prototype(s) for DLL */
#if defined CAPL_DLL_SUPPORT_ENABLED
uint32_t CAPLEXPORT far CAPLPASCAL nsk1019(uint32_t accessLevel,
                                            const uint8_t* ecuSerialNum,
                                            uint32_t ecuSerialNumLen,
                                            const uint8_t seed[NSK_SEED_KEY_LENGTH],
                                            uint8_t key[NSK_SEED_KEY_LENGTH]);
#else  /* #if defined CAPL_DLL_SUPPORT_ENABLED */
EXTERN_C DLLAPI uint8_t DLLCALLCONV nsk1019(uint8_t accessLevel,
                                            const uint8_t* ecuSerialNum, uint8_t ecuSerialNumLen,
                                            const uint8_t seed[NSK_SEED_KEY_LENGTH],
                                            uint8_t key[NSK_SEED_KEY_LENGTH])
                                            __attribute__ ((visibility ("default")));
#endif  /* #if defined CAPL_DLL_SUPPORT_ENABLED */

/************************************************************************************************************
*  Function name:   nsk2019
*
*  Description:     This function populates version number of the DLL in the passed variables. This function
*                   is available for Windows and Linux targets only.
*
*  Return value:    None
*
*  Parameters:      *major   : Pointer to major version variable
*                   *minor   : Pointer to minor version variable
*                   *revision: Pointer to revision version variable
*                   *build   : Pointer to build version variable
*
************************************************************************************************************/
#if defined CAPL_DLL_SUPPORT_ENABLED
void CAPLEXPORT far CAPLPASCAL nsk2019(uint32_t *major,
                                         uint32_t *minor,
                                         uint32_t *revision,
                                         uint32_t *build);
#else  /* #if defined CAPL_DLL_SUPPORT_ENABLED */
EXTERN_C DLLAPI void DLLCALLCONV nsk2019(uint32_t *major,
                                         uint32_t *minor,
                                         uint32_t *revision,
                                         uint32_t *build)
                                         __attribute__ ((visibility ("default") ));
#endif  /* #if defined CAPL_DLL_SUPPORT_ENABLED */

#elif defined PLATFORM_LINUX && !defined OBJECT_FOR_N2_SECURE_UNLOCK //#if PLATFORM_WINDOWS
/************************************************************************************************************
*  Function name:   nsk1019
*
*  Description:     This function computes key from seed for the specified access level. This function is
*                   available for Windows and Linux targets only.
*
*  Return value:    NSK_SUCCESS (0): Success
*                   NSK_ERROR   (1): Error
*
*  Parameters:      accessLevel    : Security access level for which the key will be computed
*                   *ecuSerialNum  : Pointer to buffer containing ECU serial number
*                   ecuSerialNumLen: Length of serial number buffer
*                   seed           : Buffer containing seed
*                   key            : Buffer where calculated key will be stored
*
************************************************************************************************************/
#if defined N2_SHARED_OBJECT_FOR_BCM
/* Function Prototype(s) for Linux Shared Object Library */
uint8_t nsk1019(uint8_t accessLevel,
                const uint8_t* ecuSerialNum, uint8_t ecuSerialNumLen,
                const uint8_t seed[NSK_SEED_KEY_LENGTH],
                uint8_t key[NSK_SEED_KEY_LENGTH])
                __attribute__ ((visibility ("default") ));
#elif defined N2_SHARED_OBJECT_FOR_E39_MD1
uint8_t nsk1020(uint8_t accessLevel,
                const uint8_t* ecuSerialNum, uint8_t ecuSerialNumLen,
                const uint8_t seed[NSK_SEED_KEY_LENGTH],
                uint8_t key[NSK_SEED_KEY_LENGTH])
                __attribute__ ((visibility ("default") ));
#endif
/************************************************************************************************************
*  Function name:   nsk2019
*
*  Description:     This function populates version number of the DLL in the passed variables. This function
*                   is available for Windows and Linux targets only.
*
*  Return value:    None
*
*  Parameters:      *major   : Pointer to major version variable
*                   *minor   : Pointer to minor version variable
*                   *revision: Pointer to revision version variable
*                   *build   : Pointer to build version variable
*
************************************************************************************************************/
void nsk2019(uint32_t *major,
             uint32_t *minor,
             uint32_t *revision,
             uint32_t *build)
             __attribute__ ((visibility ("default") ));

#else   /* #if defined PLATFORM_LINUX && !defined OBJECT_FOR_N2_SECURE_UNLOCK */

/* Functions for Embedded Library */

/************************************************************************************************************
*  Function name:   NSK_Init
*
*  Description:     This function initializes Seed-Key module. This function is only compiled for embedded
*                   library and it must be called once at boot before using other library functions.
*
*  Return value:    NSK_SUCCESS (0): Success
*                   NSK_ERROR   (1): Error
*
*  Parameters:      *ecuSerialNum  : Pointer to buffer containing ECU serial number
*                   ecuSerialNumLen: Length of serial number buffer
*                   entropy        : Pointer to buffer of size NSK_ENTROPY_LENGTH containing entropy data
*                   nonce          : Pointer to buffer of size NSK_NONCE_LENGTH containing nonce data
*
************************************************************************************************************/
#if defined OBJECT_FOR_N2_SECURE_UNLOCK
uint8_t NSK_Init(const uint8_t* ecuSerialNum, uint8_t ecuSerialNumLen,
                 const uint8_t entropy[NSK_ENTROPY_LENGTH],
                 const uint8_t nonce[NSK_NONCE_LENGTH])
                 __attribute__ ((visibility ("default") ));
#else
uint8_t NSK_Init(const uint8_t* ecuSerialNum, uint8_t ecuSerialNumLen,
                 const uint8_t entropy[NSK_ENTROPY_LENGTH],
                 const uint8_t nonce[NSK_NONCE_LENGTH]);
#endif
/************************************************************************************************************
*  Function name:   NSK_GenerateSeed
*
*  Description:     This function generates seed for seed-key authentication. This function is only compiled
*                   for embedded library.
*
*  Return value:    NSK_SUCCESS     (0): Success
*                   NSK_ERROR       (1): Error
*                   NSK_RESEED_REQD (2): Re-seed required. NSK_ReseedSeedGenerator() must be called before
*                                        re-calling this function.
*
*  Parameters:      seed: Pointer to buffer of size NSK_SEED_KEY_LENGTH where generated seed will be stored
*
************************************************************************************************************/

#if defined OBJECT_FOR_N2_SECURE_UNLOCK
uint8_t NSK_GenerateSeed(uint8_t seed[NSK_SEED_KEY_LENGTH])
                         __attribute__ ((visibility ("default") ));
#else
uint8_t NSK_GenerateSeed(uint8_t seed[NSK_SEED_KEY_LENGTH]);
#endif

/************************************************************************************************************
*  Function name:   NSK_VerifyKey
*
*  Description:     This function verifies received key against specified seed and security access level. This
*                   function is only compiled for embedded library.
*
*  Return value:    NSK_SUCCESS (0): Success (key matches specified seed)
*                   NSK_ERROR   (1): Error   (key does not match specified seed)
*
*  Parameters:      accessLevel: Security access level for which the key will be computed
*                   seed       : Buffer of size NSK_SEED_KEY_LENGTH containing seed
*                   key        : Buffer of size NSK_SEED_KEY_LENGTH containing key
*
************************************************************************************************************/
#if defined OBJECT_FOR_N2_SECURE_UNLOCK
uint8_t NSK_VerifyKey(uint8_t accessLevel,
                      const uint8_t seed[NSK_SEED_KEY_LENGTH],
                      const uint8_t key[NSK_SEED_KEY_LENGTH])
                      __attribute__ ((visibility ("default") ));
#else
uint8_t NSK_VerifyKey(uint8_t accessLevel,
                      const uint8_t seed[NSK_SEED_KEY_LENGTH],
                      const uint8_t key[NSK_SEED_KEY_LENGTH]);
#endif

/************************************************************************************************************
*  Function name:   NSK_ReseedSeedGenerator
*
*  Description:     This function re-seeds seed generator with new entropy. This function is only compiled
*                   for embedded library.
*
*  Return value:    NSK_SUCCESS (0): Success
*                   NSK_ERROR   (1): Error
*
*  Parameters:      entropy: Buffer of size NSK_ENTROPY_LENGTH containing entropy data
*
************************************************************************************************************/
#if defined OBJECT_FOR_N2_SECURE_UNLOCK
uint8_t NSK_ReseedSeedGenerator(const uint8_t entropy[NSK_ENTROPY_LENGTH])
                               __attribute__ ((visibility ("default") ));
#else
uint8_t NSK_ReseedSeedGenerator(const uint8_t entropy[NSK_ENTROPY_LENGTH]);
#endif

/************************************************************************************************************
*  Function name:   NSK_GetVersion
*
*  Description:     This function populates version number of the library in the passed variables
*
*  Return value:    None
*
*  Parameters:      *major   : Pointer to major version variable
*                   *minor   : Pointer to minor version variable
*                   *revision: Pointer to revision version variable
*                   *build   : Pointer to build version variable
*
************************************************************************************************************/
#if defined OBJECT_FOR_N2_SECURE_UNLOCK
void NSK_GetVersion(uint32_t *major,
                    uint32_t *minor,
                    uint32_t *revision,
                    uint32_t *build)
                    __attribute__ ((visibility ("default") ));
#else
void NSK_GetVersion(uint32_t *major,
                    uint32_t *minor,
                    uint32_t *revision,
                    uint32_t *build);
#endif

#endif  /* #if defined PLATFORM_EMBEDDED */

#ifdef __cplusplus
} /* __cplusplus defined */
#endif

#endif /* _NSK_H_ */
/***********************************************************************************************************/
/*                                               END OF FILE                                               */
/***********************************************************************************************************/
