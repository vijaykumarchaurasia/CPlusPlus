#pragma once
#include "SimpleEventModel.h"

namespace DaqApp
{
class EventsManagerModel;

class SimpleEventModelEv5006 final: public SimpleEventModel
{
    public:
        explicit SimpleEventModelEv5006(EventConfigMessage, EventsManagerModel *, AppManager * );
        virtual~SimpleEventModelEv5006();
        SimpleEventModelEv5006(const SimpleEventModelEv5006& )            = delete;
        SimpleEventModelEv5006& operator=(const SimpleEventModelEv5006& ) = delete;
        SimpleEventModelEv5006(SimpleEventModelEv5006&&)                  = delete;
        void Evaluate() override;
    private:
        AppManager*         mAppManagerHandlePtr;
        EventsManagerModel* mEventsManagerHandlerPtr;
        EventConfigMessage  mConfigMessage;
        const int  mKeySwitchBatteryPotentialSPN{158};
        const int  mEV5006PredefinedThreshold{6};
//        const unsigned int mSamplingTimeForEventChecking{250}; //supposed to be (rasterrate/2)
};
}
