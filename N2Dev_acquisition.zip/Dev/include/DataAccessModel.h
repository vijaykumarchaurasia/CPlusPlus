#pragma once
#include <mutex>
#include <unordered_map>
#include "Record.h"
#include "ConfigMessage.h"

namespace DaqApp
{
using MultiMapDef = std::map<std::string,std::string> ;
using J1939MapDef = std::map<unsigned int,float> ;

enum class Protocol:short int
{
    invalid    =-1,
    J1939Proto = 0,
    XCPProto      ,
    UDSProto      ,
    EventProto    ,
    AppConfig     ,
    GPSData       ,
    EAL           ,
    TripData
};
class AppManager;
class DataAccessModel
{
    public:
        explicit DataAccessModel(AppManager*);
        virtual ~DataAccessModel();
        DataAccessModel(const DataAccessModel&)            = delete;
        DataAccessModel& operator=(const DataAccessModel&) = delete;
        DataAccessModel(DataAccessModel&&)                 = delete;


        float  Read(unsigned int, Protocol, DaqApp::ConfigIds configId);                  //J1939 only values, not in a record
        void Write(unsigned int,float,Protocol,DaqApp::ConfigIds) noexcept;              //J1939 Write

        std::string& Read(const std::string&, DaqApp::ConfigIds) noexcept;                      //XCP/UDS only values, not in a record
        void Write(const std::string, const std::string, Protocol,DaqApp::ConfigIds) noexcept; //XCP/UDS Write

        std::string  ReadMisc(const std::string&);                                             //Misc info, only values, not in a record
        void WriteMisc(const std::string&, const std::string&) noexcept;                       //Misc info Write



        Record& GetRecord(DaqApp::ConfigIds);
    private:
        void CleanRecord();
        AppManager* mAppManPtr;
        Record      mRecord;
        std::string mEmptyString;
        std::unordered_map<std::string,std::string> mMiscMap;
        std::map<ConfigIds,J1939MapDef>mJ1939Map;
        std::map<ConfigIds,MultiMapDef>mMultiMap;

        std::mutex JMapMtx;
        std::mutex MsMapMtx;
        std::mutex MmapMtx;
        std::mutex MapRecordMtx;

};
}//End of DaqApp NS
