#pragma once
#include <string>

namespace DaqApp
{
    namespace utils
    {
        bool IsNumber(const std::string&);
        uint32_t ConvertHexToInt(const std::string&);
        std::string ConvertIntToHex(int);
        uint32_t ConvertValueToInt(const std::string& );
        bool IsHexNotation(const std::string& );

    }
}
