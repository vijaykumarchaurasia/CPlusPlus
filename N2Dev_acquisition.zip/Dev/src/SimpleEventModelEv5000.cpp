#include <ecu/logging.h>
#include "AppManager.h"
#include "DataAccessModel.h"
#include "EventsManagerModel.h"
#include "SimpleEventModelEv5000.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.SimpleEventModelEv5000");
    }
using namespace DaqApp;

SimpleEventModelEv5000::SimpleEventModelEv5000(EventConfigMessage config_message, EventsManagerModel *passed_ptr, AppManager* passed_app_manger_ptr):
mAppManagerHandlePtr(passed_app_manger_ptr),
mEventsManagerHandlerPtr(passed_ptr),
mConfigMessage(config_message)
    {
        mEventID = ("EV5000");
        LOG_MOD(NOTICE, logmod)<<"Creation:"<<mEventID;
        mIsActive = false;
        mEventsManagerHandlerPtr->AddSignal(mEventID);
    }

SimpleEventModelEv5000::~SimpleEventModelEv5000()
    {
        LOG_MOD(NOTICE, logmod)<<"Destruction: EV5000";
    }

//Pre definedevent 5000 for any active event.
void SimpleEventModelEv5000::Evaluate()
    {
        LOG_MOD(INFO, logmod)<<"EV5000 Evaluating, current status is"<< mIsActive;
        std::string  dm1_curr_val = mAppManagerHandlePtr->GetDataAccessModel()->Read("activeFaultCodes", mConfigMessage.ConfigID); //Read DM1 message
        if(dm1_curr_val == "spn:0~fmi:0~count:0|") //No active faults
            {
                mPrevVal = "spn:0~fmi:0~count:0|";
                mIsActive = false;
            }
        else if((dm1_curr_val != mPrevVal) && dm1_curr_val.size()) //New active event and atleast one DM1 message received.
            {
                LOG_MOD(NOTICE, logmod)<<"EV5000 Emitted, received activeFaultCodes = "<<dm1_curr_val;
                mEventsManagerHandlerPtr->EmitSignal("EV5000");
                mPrevVal = dm1_curr_val;
                mIsActive = true;
            }
    }
