#include "SimpleEventModel.h"

using namespace DaqApp;

SimpleEventModel::SimpleEventModel():
mIsActive(false)
    {
    }

SimpleEventModel::~SimpleEventModel()
    {
    }
