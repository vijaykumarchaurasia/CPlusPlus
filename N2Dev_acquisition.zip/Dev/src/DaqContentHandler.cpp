#include <curl/curl.h>
#include <curl/easy.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <regex>
#include <ecu/com/backend_messageadapter.h>
#include <ecu/logging.h>
#include <json/json.h>
#include "AppManager.h"
#include "DaqContentHandler.h"
#include "EventsManagerModel.h"
#include "FilesHandlingModel.h"
#include "CommonHeader.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.DaqContentHandler");
    }
using namespace DaqApp;
using namespace ecu::lapi::pb;

DaqContentHandler::DaqContentHandler(AppManager* passedAppManger):
mAppManagerHandlePtr(passedAppManger),
mFileInProgress(false)
    {
        LOG_MOD(NOTICE, logmod) <<"Creation: DaqContentHandler";
        mEventsManagerHandlePtr = mAppManagerHandlePtr->GetEventsManagerModel();
        mEventsManagerHandlePtr->AddSignal("NewConfigArrived");
    }

DaqContentHandler::~DaqContentHandler()
    {
        LOG_MOD(NOTICE, logmod) <<"Destruction:DaqContentHandler";
    }

void DaqContentHandler::Content112Callback(const uint32_t cid, const Message& msg)
    {
        LOG_MOD(NOTICE, logmod) <<"DaqContentHandler::Content112Callback";
        LOG_MOD(WARNING, logmod) <<"Received call back"<<std::endl;
        PbBackendMessageAdapter<std::string> adapter;
        auto result = adapter.deserialize(msg);
        if(result.ok())
            {
                LOG_MOD(NOTICE, logmod) <<"Content ID: " << cid << " Data: " << result.val();
                mMessageData.push_back(result.val());
            }
        mFilesHandlingPtr = mAppManagerHandlePtr->GetFilesHandlingModel();
        auto iterMessageData = mMessageData.begin();
        while(iterMessageData != mMessageData.end())
        {
            if(!mFileInProgress)
                {
                    mFileInProgress = true;
                    mFilesHandlingPtr->RemoveJsonAndZipFromDir(MISC_DIR);
                    Json::Reader reader;
                    Json::Value jsonCloudData;
                    reader.parse(*iterMessageData, jsonCloudData);
                        if(jsonCloudData != Json::Value::null)
                            {
                                std::string configCorrelationid;
                                std::string fileURL;
                                Json::Value jsonConfigData;
                                if(jsonCloudData.isMember("correlationid"))
                                    {
                                        configCorrelationid = jsonCloudData["correlationid"].asString();
                                    }
                                else if(jsonCloudData.isMember("CorrelationId"))
                                    {
                                        configCorrelationid = jsonCloudData["CorrelationId"].asString();
                                    }
                                if(jsonCloudData.isMember("FileURL"))
                                    {
                                        fileURL = jsonCloudData["FileURL"].asString();
                                    }
                                else if(jsonCloudData.isMember("FileUrl"))
                                    {
                                        fileURL = jsonCloudData["FileUrl"].asString();
                                    }
                                if(!fileURL.empty())
                                    {
                                        mFilesHandlingPtr->GetCloudServicesPtr()->SetConfigCorrelationId(configCorrelationid);
                                        mFilesHandlingPtr->SetConfigCorrelationId(configCorrelationid);
                                        DownloadConfiguration(fileURL);
                                    }
                                else if(jsonCloudData.isMember("Configuration"))//Command
                                    {
                                        jsonConfigData = jsonCloudData["Configuration"];
                                    }
                                else
                                    {
                                        jsonConfigData = jsonCloudData["configuration"];
                                    }
                                if(!jsonConfigData.empty())
                                    {
                                        WriteJsonConfigDataToFile(jsonConfigData);
                                    }
                                else if(fileURL.empty())
                                    {
                                        LOG_MOD(WARNING, logmod) <<"configuration JSON object is null";
                                    }
                            }
                        else
                            {
                                LOG_MOD(WARNING, logmod) <<"Received payload Config JSON value is null";
                            }
                        mMessageData.erase(iterMessageData);
                    }
            }
    }

size_t DaqContentHandler::WriteData(void *ptr, size_t size, size_t nmemb, FILE *stream)
    {
        size_t written = fwrite(ptr, size, nmemb, stream);
        return written;
    }

void DaqContentHandler::DownloadConfiguration(const std::string& fileURL)
    {
        LOG_MOD(NOTICE, logmod) <<"DaqContentHandler::DownloadConfiguration "<<std::endl;
        CURLcode res;
        std::string strConfigFileName;
        CURL *curl = curl_easy_init();
        std::string outputFileName = MISC_DIR;
        bool fileURLWithZip = false;
        if(fileURL.find(".zip") != std::string::npos)
            {
                outputFileName.append("/Configuration.json.zip");
                fileURLWithZip = true;
            }
        else
            {
                std::regex rgx(".*2F(\\w+).json.*");
                std::smatch match;
                if(std::regex_search(fileURL.begin(),fileURL.end(),match,rgx))
                {
                    strConfigFileName = match.str(1);
                    outputFileName.append("/");
                    outputFileName.append(strConfigFileName);
                    outputFileName.append(JSON_EXT);
                    strConfigFileName.append(JSON_EXT);
                }
                else
                {
                     outputFileName.append("/");
                     outputFileName.append(CONFIGURATION_FILE_NAME);
                     strConfigFileName = CONFIGURATION_FILE_NAME;
                }
            }
        if (curl)
            {
                #ifndef DEBUGDAQ
				curl_easy_setopt(curl, CURLOPT_CAPATH, "/usr/share/ca-certificates");
				curl_easy_setopt(curl, CURLOPT_CAINFO, "/usr/share/ca-certificates/azure.pem");
				#endif // DEBUGDAQ
                FILE *fp = fopen(outputFileName.c_str(),"wb");
                curl_easy_setopt(curl, CURLOPT_URL, fileURL.c_str());
                if(fp)
                    {
                        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteData);
                        curl_easy_setopt(curl, CURLOPT_WRITEDATA, fp);
                        #ifndef DAQEMULATOR
                        curl_easy_setopt(curl, CURLOPT_PROXY, "127.0.0.1:3128");
                        #endif // DAQEMULATOR
                        res = curl_easy_perform(curl);
                        fclose(fp);
                        if(res  == CURLE_OK)
                        {
                            LOG_MOD(NOTICE, logmod)<<"Downloaded Configuration successfully "<<outputFileName;
                            if(fileURLWithZip)
                                {
                                    mFilesHandlingPtr->DecompressDownloadedConfigFile(outputFileName);
                                }
                            else
                                {
                                    mFilesHandlingPtr->SetNewlyDownloadedJSONConfig(strConfigFileName);
                                    mEventsManagerHandlePtr->EmitSignal("NewConfigArrived");
                                }
                        }
                    }
                else
                    {
                        LOG_MOD(WARNING, logmod) <<"Not able to open config file "<<outputFileName;
                    }
                curl_easy_cleanup(curl);
            }
    }

void DaqContentHandler::WriteJsonConfigDataToFile(const Json::Value& jSonData)
    {
        LOG_MOD(NOTICE, logmod) <<"DaqContentHandler::WriteJsonConfigDataToFile "<<std::endl;
        //Write Configuration file
        std::ofstream configFile;
        std::string configPath = MISC_DIR;
        configPath.append("/");
        configPath.append(CONFIGURATION_FILE_NAME);
        configFile.open (configPath);
        if(configFile.is_open())
            {
                LOG_MOD(NOTICE, logmod) <<"Opened config file for writing";
                configFile << jSonData;
                configFile.close();
                mFilesHandlingPtr->SetNewlyDownloadedJSONConfig(CONFIGURATION_FILE_NAME);
                mEventsManagerHandlePtr->EmitSignal("NewConfigArrived");
            }
        else
            {
                LOG_MOD(WARNING, logmod) <<"Not opening config file";
            }
    }

void DaqContentHandler::SetFileInProgress(bool passedValue)
    {
        mFileInProgress = passedValue;
    }
