#include <ecu/logging.h>
#include "AppManager.h"
#include "DataAccessModel.h"
#include "CommonHeader.h"
#include "ConfigurationManagerModel.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.DataAccessModel");
    }

using namespace DaqApp;

DataAccessModel::DataAccessModel(AppManager* passed):
mAppManPtr(passed),
mEmptyString(),
mMiscMap()
{

    J1939MapDef tempObj1;
    mJ1939Map= {{ConfigIds::ConfigOne,tempObj1  },
                {ConfigIds::ConfigTwo,tempObj1  },
                {ConfigIds::ConfigThree,tempObj1},
                {ConfigIds::ConfigFour,tempObj1}};

    MultiMapDef tempObj2;
    mMultiMap= {{ConfigIds::ConfigOne,tempObj2  },
                {ConfigIds::ConfigTwo,tempObj2  },
                {ConfigIds::ConfigThree,tempObj2},
                {ConfigIds::ConfigFour,tempObj2}};

    LOG_MOD(NOTICE, logmod) << "Creation: DataAccessModel";
}

DataAccessModel::~DataAccessModel()
{
    LOG_MOD(NOTICE, logmod) << "Destruction: DataAccessModel";
    mMiscMap.clear();
    mJ1939Map.clear();
    mMultiMap.clear();
}

float DataAccessModel::Read(unsigned int source, Protocol proto,DaqApp::ConfigIds configId)
{
    const std::lock_guard<std::mutex> lockJ1939(JMapMtx);
    auto J1939MapIter = mJ1939Map.at(configId).find(source) ;

    if(J1939MapIter != mJ1939Map.at(configId).end())
        {
            return J1939MapIter->second;
        }
    else
    {
            LOG_MOD(ERROR, logmod) << "DataAccess requested value cannot be found for source ="<<source <<std::endl;
    }
    return 0;

}

void DataAccessModel::Write(unsigned int source, float value, Protocol proto, DaqApp::ConfigIds configId) noexcept
{

    if(Protocol::J1939Proto == proto)
    {
        const std::lock_guard<std::mutex> lockJ1939(JMapMtx);
        auto J1939MapIter = mJ1939Map.at(configId).find(source) ;
        if( J1939MapIter != mJ1939Map.at(configId).end())
            {
                J1939MapIter->second = value;
            }
        else
            {
                mJ1939Map.at(configId).insert(std::pair< unsigned int, float >(source,value));
            }
    }
    else
        {
            LOG_MOD(ERROR, logmod) << "DataAccess wrong proto used, no data was written for source= "<<source<<std::endl;
        }
}

std::string& DataAccessModel::Read(const std::string& source, DaqApp::ConfigIds configId) noexcept
{
    const std::lock_guard<std::mutex> lockMultiMap(MmapMtx);
    auto MultiMapIter  = mMultiMap.at(configId).find(source);
    if(MultiMapIter   != mMultiMap.at(configId).end())
        {
            return MultiMapIter->second     ;
        }
    else
        {
            LOG_MOD(ERROR, logmod) << "DataAccess requested value cannot be found for source ="<<source <<std::endl;
        }
    return mEmptyString                     ;
}

void DataAccessModel::Write(const std::string source, const std::string value, Protocol proto, DaqApp::ConfigIds configId ) noexcept
{

    if((Protocol::J1939Proto != proto) && (Protocol::GPSData !=proto))
    {
        const std::lock_guard<std::mutex> lockMultiMap(MmapMtx);
        auto MultiMapIter = mMultiMap.at(configId).find(source);
        if(MultiMapIter  != mMultiMap.at(configId).end())
            {
                MultiMapIter->second = value;
            }
        else
            {
                mMultiMap.at(configId).insert({source, value});
            }
    }
    else
        {
            LOG_MOD(ERROR, logmod) << "DataAccess wrong proto used, no data was written for source= "<<source<<std::endl;
        }
}

std::string DataAccessModel::ReadMisc(const std::string& source)
{
    const std::lock_guard<std::mutex> lock(MsMapMtx);
    auto MiscMapIter = mMiscMap.find(source);
    if(MiscMapIter != mMiscMap.end())
        {
            return MiscMapIter->second;
        }
    return "";
}

void DataAccessModel::WriteMisc(const std::string& source, const std::string& value) noexcept
{
    const std::lock_guard<std::mutex> lock(MsMapMtx);
    auto MiscMapIter = mMiscMap.find(source);
    if(MiscMapIter != mMiscMap.end())
        {
            mMiscMap.at(source) = value;
        }
    else
        {
            mMiscMap.insert({source, value});
        }
}

Record& DataAccessModel::GetRecord(DaqApp::ConfigIds configId)
{
    const std::lock_guard<std::mutex> lock(MapRecordMtx);

    if(ConfigIds::InvalidConfig != configId)
        {
            const std::lock_guard<std::mutex> lockJ1939(JMapMtx);
            CleanRecord();
            for(const auto& MapPair : mJ1939Map.at(configId))
                {
                    mRecord.Data.push_back({std::to_string(MapPair.first),
                    std::to_string(MapPair.second)})  ;
                }
            const std::lock_guard<std::mutex> lockMultiMap(MmapMtx);
            for(const auto& MapPair : mMultiMap.at(configId))
                {
                    mRecord.Data.push_back({MapPair.first, MapPair.second});
                }
        }
    else
        {
            LOG_MOD(ERROR, logmod)<<"DataLogger invalid config ID received, returned Record WON'T HAVE ANY DATA !!";
        }
    return mRecord;
}

inline void DataAccessModel::CleanRecord()
{
    mRecord.Data.clear();
    #ifndef DAQEMULATOR

    JenkinsCatch("TODO:: Revisit logic for fetching 1st element from GPSSampler vector after supporting multiple configurations")

    std::vector<GpsSamplerConfig> gps_sampler_configs = mAppManagerPtr->GetConfigurationModel()->GetGpsSamplerConfig();
    if(gps_sampler_configs.size()>0)
    {
        GpsSamplerConfig gpsConfig = gps_sampler_configs.at(0);
        if(gpsConfig.IsLatitude)
        {
            mRecord.Latitude            = ReadMisc(LATITUDE);
        }
        if(gpsConfig.IsLongitude)
        {
            mRecord.Longitude           = ReadMisc(LONGITUDE);
        }
        if(gpsConfig.IsAltitude)
        {
            mRecord.Altitude            = ReadMisc(ALTITUDE);
        }
        if(gpsConfig.IsDirection_Heading)
        {
            mRecord.DirectionHeading    = ReadMisc(DIRECTION_HEADING);
        }
        if(gpsConfig.IsGPS_Vehicle_Speed)
        {
            mRecord.GPSVehicleSpeed     = ReadMisc(GPS_VEHICLE_SPEED);
        }

    }

    #endif
    mRecord.TimeStamp  = mAppManPtr->GetTimeUtilities()->GetTimeDate();
}
