#include <ecu/logging.h>
#include "AppManager.h"
#include "DataAccessModel.h"
#include "EventsManagerModel.h"
#include "SimpleEventModelEv5003.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.SimpleEventModelEv5003");
    }
using namespace DaqApp;

SimpleEventModelEv5003::SimpleEventModelEv5003(EventConfigMessage config_message, EventsManagerModel *passed_ptr, AppManager* passed_app_manger_ptr):
mAppManagerHandlePtr(passed_app_manger_ptr),
mEventsManagerHandlerPtr(passed_ptr),
mConfigMessage(config_message)
    {
        mEventID = ("EV5003");
        LOG_MOD(NOTICE, logmod)<<"Creation:"<<mEventID;
        mIsActive = false;
        mEventsManagerHandlerPtr->AddSignal(mEventID);
    }

SimpleEventModelEv5003::~SimpleEventModelEv5003()
    {
        LOG_MOD(NOTICE, logmod)<<"Destruction: EV5003";
    }

//Pre defined event EV5003, engine speed greater than 400RPM.
void SimpleEventModelEv5003::Evaluate()
    {
        LOG_MOD(INFO, logmod)<<"EV5003 Evaluating current status is"<< mIsActive;
        auto engine_speed = mAppManagerHandlePtr->GetDataAccessModel()->Read(190, Protocol::J1939Proto,mConfigMessage.ConfigID); //Read Engine Speed
        if((engine_speed > 400) && (!mIsActive))
            {
                LOG_MOD(NOTICE, logmod)<<"EV5003 Emitted at engine speed "<<engine_speed;
                mEventsManagerHandlerPtr->EmitSignal("EV5003");
                mIsActive = true;
            }
        //Emit again here again if ending event
        else if (engine_speed <= 400)
            {
                mIsActive = false;
            }
    }
