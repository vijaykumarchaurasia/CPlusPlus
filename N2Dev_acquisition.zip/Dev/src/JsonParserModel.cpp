#include <ecu/logging.h>
#include "JsonParserModel.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.JsonParserModel");
    }
using namespace DaqApp;

JsonParserModel::JsonParserModel()
    {
        LOG_MOD(NOTICE, logmod)<<"Creation: JsonParserModel";
    }

JsonParserModel::~JsonParserModel()
    {
        LOG_MOD(NOTICE, logmod)<<"Destruction: JsonParserModel";
    }

Json::Value JsonParserModel::ParseJsonFile(const std::string& file_name )
    {
        Json::Value root = root.null;
        Json::Reader reader;
        try
            {
                std::ifstream config_doc(file_name,std::ifstream::binary);
                if(!config_doc)
                    {
                        LOG_MOD(WARNING, logmod)<< "JsonParserModel::Unable to open file" << file_name;
                        throw 0;
                    }
                if ( ! reader.parse(config_doc, root) )
                    {
                        LOG_MOD(WARNING, logmod)<< "JsonParserModel::Failed to parse configuration\n"
                                                    << reader.getFormattedErrorMessages();
                        root = root.null;
                        throw 0;
                    }
            }
        catch(...)
            {
                LOG_MOD(WARNING, logmod)<< "JsonParserModel::Uncought exception";
            }
        return root;
    }
