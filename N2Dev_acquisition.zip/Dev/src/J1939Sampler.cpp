#include <ecu/logging.h>
#include <ecu/rt/signaladapter.h>
#include "AppManager.h"
#include "DataAccessModel.h"
#include "J1939Sampler.h"
#include "J1939RequesterModel.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.J1939Sampler");
    }
using namespace DaqApp;
using namespace ecu::lapi::rt;

J1939Sampler::J1939Sampler(ecu::lapi::com::ITransportClient_ptr client,J1939ConfigMessage j1939configmessage,
    AppManager* passed):
    mTransportClientPtr(client),
    mJ1939ConfigMessage(j1939configmessage),
    mAppManagerPtr(passed),
    mDataAccessModelPtr(mAppManagerPtr->GetDataAccessModel()),
    mSdkCallBackPtr(new CallBackHelper(this)),
    mSpn(std::stoi(mJ1939ConfigMessage.Spn))

    {
        LOG_MOD(NOTICE, logmod)<<"Creation: J1939Sampler created with topic= "<<mJ1939ConfigMessage.Topic
                                  <<", SPN = "<<mJ1939ConfigMessage.Spn
                                  <<" and signal= "<<mJ1939ConfigMessage.Signal;
        mTransportClientPtr->subscribe(mJ1939ConfigMessage.Topic, 0, mSdkCallBackPtr);
        if(!mJ1939ConfigMessage.IsCyclic)
            {
                mPgnClientPtr = ecu::lapi::diag::create_pgn_request_client(mTransportClientPtr);
                mJ1939RequesterModelPtr = std::make_unique<J1939RequesterModel>
               (mPgnClientPtr,mTransportClientPtr,std::atof(mJ1939ConfigMessage.Pgn.c_str()),mECUAddr,mAppManagerPtr->GetTimeUtilities(),false);
            }
        mDataAccessModelPtr->Write(mSpn,0 , Protocol::J1939Proto, mJ1939ConfigMessage.ConfigID);
    }

J1939Sampler::~J1939Sampler()
    {
        mPgnClientPtr.reset();
        mTransportClientPtr->unsubscribe(mJ1939ConfigMessage.Topic,mSdkCallBackPtr);
        LOG_MOD(NOTICE, logmod)<<"Destruction: J1939Sampler for Spn"<< mJ1939ConfigMessage.Spn;
    }

void J1939Sampler::message(const std::string &topic, const Message &message)
    {
        SignalAdapter::UnpackResult unpack = SignalAdapter::instance().unpack(mJ1939ConfigMessage.Topic, message);
		SignalGroup receivedGroup_ = unpack.take_val();
		const Signal *extracted = receivedGroup_.signal(mJ1939ConfigMessage.Signal);
		if (extracted)
            {
                Signal::ScaleResult scaledData = extracted->value_scaled();
                mDataAccessModelPtr->Write(mSpn, scaledData.take_val(), Protocol::J1939Proto, mJ1939ConfigMessage.ConfigID);
            }
		else
            {
                LOG_MOD(ERROR, logmod)<<"Signal with null value received for spn = "<<mSpn;
            }
    }
