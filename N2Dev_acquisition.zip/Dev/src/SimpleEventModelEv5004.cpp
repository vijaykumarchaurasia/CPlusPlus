#include <ecu/logging.h>
#include "AppManager.h"
#include "DataAccessModel.h"
#include "EventsManagerModel.h"
#include "SimpleEventModelEv5004.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.SimpleEventModelEv5004");
    }
using namespace DaqApp;

SimpleEventModelEv5004::SimpleEventModelEv5004(EventConfigMessage config_message, EventsManagerModel *passed_ptr, AppManager* passed_app_manger_ptr):
mAppManagerHandlePtr(passed_app_manger_ptr),
mEventsManagerHandlerPtr(passed_ptr),
mConfigMessage(config_message)
    {
        mEventID = ("EV5004");
        LOG_MOD(NOTICE, logmod)<<"Creation:"<<mEventID;
        mIsActive = false;
        mEventsManagerHandlerPtr->AddSignal(mEventID);
    }

SimpleEventModelEv5004::~SimpleEventModelEv5004()
    {
        LOG_MOD(NOTICE, logmod)<<"Destruction: EV5004";
    }

//Pre defined event EV5004, engine speed is less than 50RPM.
void SimpleEventModelEv5004::Evaluate()
    {
        LOG_MOD(INFO, logmod)<<"EV5004 Evaluating current status is"<< mIsActive;
        auto engine_speed = mAppManagerHandlePtr->GetDataAccessModel()->Read(190, Protocol::J1939Proto,mConfigMessage.ConfigID); //Read Engine Speed
        if ((engRunning) && (engine_speed < 50) && (!mIsActive))
            {
                LOG_MOD(NOTICE, logmod)<<"EV5004 Emitted at engine speed "<<engine_speed;
                mEventsManagerHandlerPtr->EmitSignal("EV5004");
                mIsActive = true;
                engRunning = false;
            }
        //Emit again here again if ending event
        else if (engine_speed >= 50)
            {
                mIsActive = false;
                engRunning = true;
            }
    }
