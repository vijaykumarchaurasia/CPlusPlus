#include <ecu/logging.h>
#include "AppManager.h"
#include "ConfigMessage.h"
#include "ConfigurationManagerModel.h"
#include "CompositeEventModel.h"
#include "EventsManagerModel.h"
#include "SimpleEventModelEv5000.h"
#include "SimpleEventModelEv5001.h"
#include "SimpleEventModelEv5002.h"
#include "SimpleEventModelEv5003.h"
#include "SimpleEventModelEv5004.h"
#include "SimpleEventModelEv5006.h"
#include "SimpleEventModelEvDynamic.h"
#include "SimpleEventModelEvDynamicXcp.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.EventsManagerModel");
    }

using namespace DaqApp;
EventsManagerModel::EventsManagerModel(AppManager* passed):
mAppManagerHandlePtr(passed)

    {
        LOG_MOD(NOTICE, logmod)<<"Creation: EventsManagerModel";
    }

EventsManagerModel::~EventsManagerModel()
    {
        LOG_MOD(NOTICE, logmod)<<"Destruction: EventsManagerModel";
        mAppManagerHandlePtr->GetTimeUtilities()->ReleaseTick(mTickId);
        DisconnectAll();
        mEvents.clear();
        mDynamicSignalsMap.clear();
        mCompositeEvents.clear();
    }

void EventsManagerModel::SetUpEventsManager()
    {
        ConfigurationManagerModel* configManagerModelPtr = mAppManagerHandlePtr->GetConfigurationModel();
        for(const auto& EventMessage :  configManagerModelPtr->GetEventsConfig())
            {
             LOG_MOD(NOTICE, logmod)<<"EventsFactory: EVENT ID " << EventMessage.EventId;
                    switch (EventMessage.Type)
                          {
                            case EventsType::EV5000:
                                 LOG_MOD(INFO, logmod)<<"EventsFactory: EV5000 object created";
                                 mEvents.emplace_back(std::make_unique <SimpleEventModelEv5000>(EventMessage, this, mAppManagerHandlePtr));
                                 break;

                            case EventsType::EV5001:
                                 LOG_MOD(INFO, logmod)<<"EventsFactory: EV5001 object created";
                                 mEvents.emplace_back(std::make_unique <SimpleEventModelEv5001>(EventMessage, this, mAppManagerHandlePtr));
                                 break;

                            case EventsType::EV5002:
                                 LOG_MOD(INFO, logmod)<<"EventsFactory: EV5002 object created";
                                 mEvents.emplace_back(std::make_unique <SimpleEventModelEv5002>(EventMessage, this, mAppManagerHandlePtr));
                                 break;

                            case EventsType::EV5003:
                                LOG_MOD(INFO, logmod)<<"EventsFactory: EV5003 object created";
                                mEvents.emplace_back(std::make_unique <SimpleEventModelEv5003>(EventMessage, this, mAppManagerHandlePtr));
                                break;

                            case EventsType::EV5004:
                                LOG_MOD(INFO, logmod)<<"EventsFactory: EV5004 object created";
                                mEvents.emplace_back(std::make_unique <SimpleEventModelEv5004>(EventMessage, this, mAppManagerHandlePtr));
                                break;

                            case EventsType::EV5005:
                                LOG_MOD(INFO, logmod)<<"EventsFactory: EV5005 Not implemented, returning NullPtr";
                                break;

                            case EventsType::EV5006:
                                LOG_MOD(INFO, logmod)<<"EventsFactory: EV5006 object created";
                                mEvents.emplace_back(std::make_unique <SimpleEventModelEv5006>(EventMessage, this, mAppManagerHandlePtr));
                                break;

                            case EventsType::DynamicEvent:
                                LOG_MOD(INFO, logmod)<<"EventsFactory:EV Dynamic object created";
                                mEvents.emplace_back(std::make_unique <SimpleEventModelEvDynamic>(EventMessage, this, mAppManagerHandlePtr));
                                break;

                            case EventsType::DynamicXcpEvent:
                                LOG_MOD(NOTICE, logmod)<<"EventsFactory:EV Dynamic Xcp object created";
                                mEvents.emplace_back(std::make_unique <SimpleEventModelEvDynamicXcp>(EventMessage, this, mAppManagerHandlePtr));
                                break;

                            case EventsType::InvalidEvent:
                                LOG_MOD(INFO, logmod)<<"EventsFactory: No event creation required, enabled for testing";
                                break;

                            default:
                                LOG_MOD(WARNING, logmod)<<"EventsFactory: can't determine event type or event configuration";
                        }
            }
            LOG_MOD(NOTICE, logmod)<<"EventsManagerModel: Total Simple Events "<<mEvents.size();
            for(const auto& CompositeEventConfig :  configManagerModelPtr->GetCompositeEventsConfig())
                {
                    mCompositeEvents.emplace_back(std::make_unique <CompositeEventModel>(CompositeEventConfig, this, mAppManagerHandlePtr));
                }
            int compositeEventSize = configManagerModelPtr->GetCompositeEventsConfig().size();
            LOG_MOD(NOTICE, logmod)<<"Received total " << compositeEventSize << " composite events ";

            #ifndef DAQEMULATOR
            if(compositeEventSize || configManagerModelPtr->GetEventsConfig().size())
            {
                EventConfigMessage eventConfigMessage;
                mTickId  = mAppManagerHandlePtr->GetTimeUtilities()->Tick(ms(eventConfigMessage.EvaluationRate), Redundancy::Infinite, &EventsManagerModel::EvaluateEvents,this); // NEW
            }
            #endif // DAQEMULATOR
    }

bool EventsManagerModel::GetEventStatus(const std::string& passedEventID)
    {
        for(const auto& Event : mEvents)
            {
                if(passedEventID == Event->mEventID)
                    {
                        LOG_MOD(DEBUG, logmod)<<"EventsManagerModel: status requested for "<<passedEventID << "returned "<<Event->mIsActive;
                        return Event->mIsActive;
                    }
            }
        LOG_MOD(ERROR, logmod)<<"EventsManagerModel: Trying to get the status for an event that doesn't exist EV = "<<passedEventID;
        return false;
    }

void EventsManagerModel::AddSignal(const std::string& SignalName)
    {
        auto Iter = mDynamicSignalsMap.find(SignalName);
        if(  Iter == mDynamicSignalsMap.end())
            {
                mDynamicSignalsMap.insert(std::pair<std::string,std::unique_ptr<DaqAppSignal>>(SignalName,std::make_unique<DaqAppSignal>()));
            }
        else
            {
                LOG_MOD(ERROR, logmod)<<"EventsManagerModel: signal " << SignalName << " has already been added";
            }
    }

bool EventsManagerModel::ConnectToSignal(const std::string& SignalName,const DaqAppSignal::slot_type& slot)
    {
        bool res{false};
        auto Iter = mDynamicSignalsMap.find(SignalName);
        if( Iter == mDynamicSignalsMap.end())
            {
                LOG_MOD(ERROR, logmod)<<"EventsManagerModel: signal " << SignalName << " not found, hence can not be connected";
                return res;
            }
        else
            {
                Iter->second->connect(slot);
                res=true;
            }
        return res;
    }

bool EventsManagerModel::DisconnectFromSignal(const std::string& SignalName,void (*slotToDisconnect)())
    {
        bool res{false};
        auto Iter = mDynamicSignalsMap.find(SignalName);
        if( Iter  == mDynamicSignalsMap.end())
            {
                LOG_MOD(ERROR, logmod)<<"EventsManagerModel: signal " << SignalName << " not found, hence can not be disconnected";
                return res;
            }
        else
            {
                Iter->second->disconnect(slotToDisconnect);
                res=true;
            }
        return res;
    }

void EventsManagerModel::EmitSignal(const std::string& SignalName)
    {
        //const std::lock_guard<std::mutex> lock(mSignalMtx);
        auto Iter = mDynamicSignalsMap.find(SignalName);
        if( Iter== mDynamicSignalsMap.end())
            {
                LOG_MOD(ERROR, logmod)<<"EventsManagerModel: signal " << SignalName << " not found, hence can not be emitted";
            }
        else
        {
            (*(Iter->second))();
        }
    }

void EventsManagerModel::DisconnectAll()
    {
        for (const auto& signalPtr : mDynamicSignalsMap)
            {
                signalPtr.second->disconnect_all_slots();
            }
    }

void EventsManagerModel::EvaluateEvents()
    {
        for(const auto& Event : mEvents)
            {
                Event->Evaluate();
            }
        for(const auto& Event : mCompositeEvents)
            {
                Event->EvaluateSimpleEvents();
            }
    }
