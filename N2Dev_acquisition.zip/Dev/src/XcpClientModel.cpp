#include <ecu/logging.h>
#include "AppManager.h"
#include "ConfigurationManagerModel.h"
#include "XcpClientModel.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.XcpClientModel");
    }
using namespace DaqApp;

XcpClientModel::XcpClientModel(AppManager* passedAppMgr):
mXCPEcuPropertiesConfigMessage(passedAppMgr->GetConfigurationModel()->GetXcpEcuPropertiesConfig()),
mXCPConfiguration(passedAppMgr->GetConfigurationModel()->GetXCPConfig()),
mDaqlist(),
mXCPSignalDetails()
    {
        LOG_MOD(NOTICE, logmod)<< "Creation: XcpClientModel";
        InitSizeMap();
    }

XcpClientModel::~XcpClientModel()
    {
        LOG_MOD(NOTICE, logmod)<< "Destruction: XcpClientModel";
    }

std::unordered_map<uint16_t, std::vector<XCPSignalDetails>> XcpClientModel::CreateDaqList()
    {
        mDaqlist.clear();
        int daq_id = 0;
        int offset = 0;
        for(const auto& xcp_config_msg: mXCPConfiguration)
            {
                if(xcp_config_msg.sampling_mode == ecu::lapi::diag::DaqMode::DAQ_MODE_SAMPLE)
                    {
                        offset++;
                    }
            }

        for(const auto& xcp_config_msg: mXCPConfiguration)
            {
                std::vector<XCPSignalDetails> xcpSignalDetailsList;
                ecu::lapi::diag::DaqEntry daqEntry;
                CreateDataEntryStaticData(daqEntry);
                daqEntry.prescaler = xcp_config_msg.transmission_rate_prescaler;
                daqEntry.rate = xcp_config_msg.rate;
                daqEntry.ev_channel_id = xcp_config_msg.event_channel_number; // rates are based on channel id and "sync", for sync we are storing magical value(111) but for 1000 we need to scale down the value as the data type is unit8_t , which can store only the maximum value 255
                daqEntry.ev_channel_prio = xcp_config_msg.event_channel_priority;
                daqEntry.mode = xcp_config_msg.sampling_mode;
                if(xcp_config_msg.sampling_mode == ecu::lapi::diag::DaqMode::DAQ_MODE_POLL)
                    {
                        daqEntry.daqid = offset;
                        offset++;
                    }
                else
                    {
                        daqEntry.daqid = daq_id;
                        daq_id++;
                    }
                for(const auto& xcp_parameter_config_msg: xcp_config_msg.xcp_parameter_config_messages)
                    {
                        ecu::lapi::diag::DaqAddress daqAddress;
                        XCPSignalDetails xcpSignalDetails;
                        if(mXCPSignalSize.find(xcp_parameter_config_msg.xcp_parameter_data_type) != mXCPSignalSize.end())
                                {
                                    // datatype found, get the size of that datatype
                                    daqAddress.address = xcp_parameter_config_msg.xcp_parameter_address;
                                    daqAddress.extension = xcp_parameter_config_msg.xcp_parameter_address_extension;
                                    daqAddress.size = mXCPSignalSize.at(xcp_parameter_config_msg.xcp_parameter_data_type);
                                    xcpSignalDetails.xcpSignalName = xcp_parameter_config_msg.xcp_parameter_name;
                                    xcpSignalDetails.xcpSignalAddress = xcp_parameter_config_msg.xcp_parameter_address;
                                    xcpSignalDetails.xcpSize = mXCPSignalSize.at(xcp_parameter_config_msg.xcp_parameter_data_type);
                                    xcpSignalDetails.conversionDataType = xcp_parameter_config_msg.xcp_parameter_data_type;
                                    xcpSignalDetails.conversionFactor = xcp_parameter_config_msg.xcp_parameter_conversion_factor;
                                    xcpSignalDetails.conversionOffset = xcp_parameter_config_msg.xcp_parameter_conversion_offset;
                                    xcpSignalDetails.configid = xcp_parameter_config_msg.config_id;
                                }
                            else
                                {
                                    LOG_MOD(WARNING, logmod)<< "XcpClientModel:: datatype is not matched with list" << std::endl;
                                }

                            xcpSignalDetailsList.push_back(xcpSignalDetails);
                            daqEntry.addrs.push_back(daqAddress);
                    }
                mXCPSignalDetails.insert(std::make_pair(daqEntry.daqid, xcpSignalDetailsList));
                mDaqlist.push_back(daqEntry);

            }
        return mXCPSignalDetails;
    }

void XcpClientModel::CreateDataEntryStaticData(ecu::lapi::diag::DaqEntry& daqEntry)
    {
        XcpInterfaceAllocationConfig xcpInterfaceAllocationConfig = mXCPEcuPropertiesConfigMessage.xcp_interface_allocation_configuration;
        // Below parameter values are fixed for all signals
        daqEntry.target_ecu = xcpInterfaceAllocationConfig.target_ecu;
        daqEntry.state      = ecu::lapi::diag::DaqState::DAQ_STATE_NEW;
    }

std::unordered_map<uint16_t, std::vector<XCPSignalDetails>> XcpClientModel::GetXCPSignalDetails()
    {
        return mXCPSignalDetails;
    }

ecu::lapi::diag::DaqList XcpClientModel::GetDaqList()
    {
      return mDaqlist;
    }

void XcpClientModel::InitSizeMap()
    {
        mXCPSignalSize.insert(std::make_pair("F32", sizeof(float)));
        mXCPSignalSize.insert(std::make_pair("S8", sizeof(int8_t)));
        mXCPSignalSize.insert(std::make_pair("U8", sizeof(uint8_t)));
        mXCPSignalSize.insert(std::make_pair("S16", sizeof(int16_t)));
        mXCPSignalSize.insert(std::make_pair("U16", sizeof(uint16_t)));
        mXCPSignalSize.insert(std::make_pair("S32", sizeof(int32_t)));
        mXCPSignalSize.insert(std::make_pair("U32", sizeof(uint32_t)));
        mXCPSignalSize.insert(std::make_pair("Invalid", 0));
    }
