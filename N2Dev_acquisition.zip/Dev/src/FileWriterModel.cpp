#include <sys/stat.h>
#include <fstream>
#include <string>
#include <iomanip>
#include <ecu/logging.h>
#include "AppManager.h"
#include "Record.h"
#include "FileWriterModel.h"
#include "EventsManagerModel.h"
#include "FilesHandlingModel.h"
#include "CommonHeader.h"
#include "ConfigurationManagerModel.h"
#include "DataAccessModel.h"
#include "Utils.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.FileWriterModel");
    }
using namespace DaqApp;

int FileWriterModel::mFileCounter = 1;

FileWriterModel::FileWriterModel(AppManager* ipAppMgr) :
mAppManagerPtr(ipAppMgr),
mFileExtensionType{ {SamplingProtocols::J1939, CSV_EXT}, {SamplingProtocols::XCP, CSV_EXT},
                    {SamplingProtocols::EAL, CSV_EXT}, {SamplingProtocols::TRIP_DATA, TXT_EXT},
                    {SamplingProtocols::InvalidProtocol, ""}},
mTimeUtilitiesHandle(ipAppMgr->GetTimeUtilities()),
mFileWriterMessage(),
mFileWriterPtr(),
mRecordsData()
    {
        LOG_MOD(NOTICE, logmod)<<"Creation: FileWriterModel";
        InitPriorityFolderFileNamesMap();
        SetOutputFilePath();
        mAppManagerPtr->GetEventsManagerModel()->AddSignal(FILE_WRITING_COMPLETED_SIGNAL);
    }

FileWriterModel::~FileWriterModel()
    {
        LOG_MOD(NOTICE, logmod)<<"Destruction: FileWriterModel";
        mPriorityFolderFileNames.clear();
        mRecordsData.clear();
        mPriorityDirectoryPath.clear();
        mTripData.clear();
        mAllDDIDRecords.clear();
    }

void FileWriterModel::InitPriorityFolderFileNamesMap()
    {
        std::vector<std::string> emptyVector;
        mPriorityFolderFileNames.insert(std::make_pair(Priority::HIGH, emptyVector));
        mPriorityFolderFileNames.insert(std::make_pair(Priority::NORMAL, emptyVector));
        mPriorityFolderFileNames.insert(std::make_pair(Priority::LOW, emptyVector));
        mPriorityFolderFileNames.insert(std::make_pair(Priority::InvalidPriority, emptyVector));
    }

void FileWriterModel::SetOutputFilePath()
    {
        mPriorityDirectoryPath.insert(std::make_pair(Priority::HIGH, mAppManagerPtr->GetFilesHandlingModel()->GetOutputFilePath(Priority::HIGH)));
        mPriorityDirectoryPath.insert(std::make_pair(Priority::NORMAL, mAppManagerPtr->GetFilesHandlingModel()->GetOutputFilePath(Priority::NORMAL)));
        mPriorityDirectoryPath.insert(std::make_pair(Priority::LOW, mAppManagerPtr->GetFilesHandlingModel()->GetOutputFilePath(Priority::LOW)));
        mPriorityDirectoryPath.insert(std::make_pair(Priority::InvalidPriority, mAppManagerPtr->GetFilesHandlingModel()->GetOutputFilePath(Priority::InvalidPriority)));
    }

void FileWriterModel::WriteOutputFile(const std::vector <Record> recordData, FileWriterMessage fileWriterMessage)
    {
        try
            {
				const std::lock_guard<std::mutex> lock(mMutexFileWriter);
				mRecordsData = std::vector<Record>();
                mRecordsData = recordData;//Error in `DaqApp': double free or corruption (fasttop): 0xf400a5f8
                mFileWriterMessage = fileWriterMessage;
                mOutputFileName = "";
                mActivatedConfigFrom = mAppManagerPtr->GetConfigurationModel()->GetActivatedConfigFrom();
                if (IsValidDeviceInformation())
                {
                    CheckForValidPriorityAndProtocol();
                    Write();
                }
                else
                {
                    LOG_MOD(ERROR, logmod)<< "Can't create output file as either Telematics Device Id / VIN / ECU serial number is Invalid.";
                }
            }
        catch(const std::invalid_argument& invalidArg)
            {
                LOG_MOD(ERROR, logmod)<< " :: " << invalidArg.what();
            };
    }

    void FileWriterModel::WriteOutputFile(const std::vector<uint8_t>& tripData, FileWriterMessage fileWriterMessage)
    {
        try
            {
                mTripData = tripData;
                mFileWriterMessage = fileWriterMessage;
                mOutputFileName = "";
                mActivatedConfigFrom = mAppManagerPtr->GetConfigurationModel()->GetActivatedConfigFrom();

                if (mFileWriterMessage.TelematicsBoxId != "NA")
                {
                    CheckForValidPriorityAndProtocol();
                    Write();
                }
                else
                {
                    LOG_MOD(ERROR, logmod)<< "Can't create output file due to invalid Telematics Device Id.";
                }
            }
        catch(const std::invalid_argument& invalidArg)
            {
                LOG_MOD(ERROR, logmod)<< " :: " << invalidArg.what();
            };
    }

void FileWriterModel::CheckForValidPriorityAndProtocol()
    {
        if (SamplingProtocols::InvalidProtocol == mFileWriterMessage.SamplingProtocolId)
            {
                throw std::invalid_argument("Invalid protocol, so output files will not be created !");
            }

        if (Priority::InvalidPriority == mFileWriterMessage.PriorityId)
            {
                throw std::invalid_argument("Invalid data priority mentioned in json, so output files will not be created !");
            }

        if (SamplingProtocols::InvalidProtocol == mPreviousProtocolType)
            {
                mPreviousProtocolType = mFileWriterMessage.SamplingProtocolId;
            }
    }

std::string FileWriterModel::GenerateOutputFileName(SamplingProtocols protocol)
    {
        if (mPreviousProtocolType != protocol)
            {
                mFileCounter = 1;
                mPreviousProtocolType = protocol;
            }

            mKeyCycleCnt = mAppManagerPtr->GetDataAccessModel()->ReadMisc("IGNCounter");

            std::string outputFileName = "";
            if (SamplingProtocols::J1939 == protocol || SamplingProtocols::XCP == protocol)
            {
                outputFileName = GetJ1939OrXCPOutputFileName(protocol);
            }
            else if(SamplingProtocols::TRIP_DATA == protocol)
            {
                outputFileName = GetTripDataOutputFileName(protocol);
            }
            else if(SamplingProtocols::EAL== protocol)
            {
                outputFileName = GetEALOutputFileName(protocol);
            }

        mFileCounter++;
        return outputFileName;
    }

void FileWriterModel::CreateOutputFilePtr(const std::string& file_Path)
    {
        struct stat buffer;
        // File exists : 0, File does not exists : 1, and on error = −1 is returned
        bool isExists = stat (file_Path.c_str(), &buffer);
        // If file already exists then remove that file & create new file for writing
        if(0 == isExists)
            {
                if (remove(file_Path.c_str()) != 0)
                    {
                        std::string errorMessage = file_Path + " file deletion failed !";
                        throw std::invalid_argument(errorMessage);
                    }
            }
        // Open csv/txt file in write mode
        mFileWriterPtr.open(file_Path, std::ios::out);
        stat (file_Path.c_str(), &buffer);
        if (!mFileWriterPtr.is_open())
            {
                std::string errorMessage = file_Path + "  file is not opened successfully for writing !";
                throw std::invalid_argument(errorMessage);
            }
    }

void FileWriterModel::Write()
    {
        SamplingProtocols protocol = mFileWriterMessage.SamplingProtocolId;
        Priority priority = mFileWriterMessage.PriorityId;

        unsigned int sizeOfRecordData;
        if(SamplingProtocols::TRIP_DATA == protocol)
            {
                sizeOfRecordData = mTripData.size();
            }
        else
            {
                sizeOfRecordData = mRecordsData.size();
            }

        if (sizeOfRecordData > 0)
            {
                std::string wordSeperator = "";
                if (SamplingProtocols::TRIP_DATA == protocol) // for .txt file
                    {
                        wordSeperator = "~";
                    }
                else if (SamplingProtocols::InvalidProtocol != protocol) // for .csv file
                    {
                        wordSeperator = ",";
                    }
                std::string startTime = "";
                if (SamplingProtocols::EAL == protocol)
                {
                    UDSConfigMessage udsConfigObj;
                    for (const auto& udsObj : mAppManagerPtr->GetConfigurationModel()->GetUdsConfig())
                    {
                        if(udsObj.ConfigID == mFileWriterMessage.ConfigID)
                        {
                            udsConfigObj = udsObj;
                            break;
                        }
                    }

                    if(udsConfigObj.IsEALData)
                    {
                        std::stringstream ss;
                        ss << std::uppercase << std::hex << udsConfigObj.DDID;
                        mFileWriterMessage.DDID = ss.str();
                        mFileWriterMessage.EALSourceAddr = std::to_string(DaqApp::utils::ConvertHexToInt(udsConfigObj.SourceAddress));
                    }
                }

                mOutputFileName = GenerateOutputFileName(protocol);
                LOG_MOD(NOTICE, logmod)<<"Writing " << mOutputFileName;
                std::string outputFileNamePath = mPriorityDirectoryPath[priority] + "/" + mOutputFileName;
                // If vector conatins data then only create file pointer with appropriate extension
                CreateOutputFilePtr(outputFileNamePath);

                mPriorityFolderFileNames.at(priority).push_back(mOutputFileName);
                startTime = mTimeUtilitiesHandle->GetTimeDate();

                if (SamplingProtocols::TRIP_DATA != protocol)
                {
                    unsigned int lineNumber;
                    WriteStaticHeaderDataInFile(wordSeperator, lineNumber);
                    WriteSourcesInFile(wordSeperator);
                    WriteSourceValuesInFile(wordSeperator);
                    // For periodic data sampling, start & end timestamp shall be populated with the DateTimestamp of the
                    // creation and closing of the data file.(Requirement from "NGDI File Upload Process.pdf",section: 1.9.2.1.1.2)
                    if(TriggerType::Periodic == mFileWriterMessage.TriggerTypeId )
                    {
                        std::string endtTime = mTimeUtilitiesHandle->GetTimeDate();
                        mFileWriterPtr.seekp(lineNumber); //write 6th row i.e. startingEventDateTimestamps	2014-08-27T14:26:32.012Z	2014-08-27T14:26:43.123Z	…etc…
                        std::string str1 = "startingEventDateTimestamps" + wordSeperator + startTime + wordSeperator + "\n";
                        mFileWriterPtr << str1;
                        mFileWriterPtr.seekp(lineNumber + str1.size()); //write 7th row i.e. endingEventDateTimestamps	2014-08-27T14:26:32.012Z	2014-08-27T14:26:43.123Z	…etc…
                        std::string str2 = "endingEventDateTimestamps" + wordSeperator + endtTime + wordSeperator + "\n";
                        mFileWriterPtr << str2;
                    }
                }
                if (SamplingProtocols::TRIP_DATA == protocol)
                {
                    WriteTripDataInFile();
                }
                mFileWriterPtr.flush();
                mFileWriterPtr.close();
                mAppManagerPtr->GetEventsManagerModel()->EmitSignal(FILE_WRITING_COMPLETED_SIGNAL);
            } // end of if
    }

void FileWriterModel::WriteStaticHeaderDataInFile(const std::string& wordSeperator, unsigned int& lineNumber)
    {
        mFileWriterPtr << "messageFormatVersion" << wordSeperator << mFileWriterMessage.MessageFormatVersion << std::endl;
        mFileWriterPtr << "dataEncryptionSchemeId" << wordSeperator << mFileWriterMessage.DataEncryptionSchemeId << std::endl;
        mFileWriterPtr << "telematicsBoxId" << wordSeperator << mFileWriterMessage.TelematicsBoxId << std::endl;
        if(ConfigFrom::Navistar == mActivatedConfigFrom)
            {
                mFileWriterPtr << "VIN" << wordSeperator << mFileWriterMessage.VIN << std::endl;
            }
        else
            {
                mFileWriterPtr << "componentSerialNumber" << wordSeperator << mFileWriterMessage.ComponentSerialNumber << std::endl;
            }

        mFileWriterPtr << "dataSamplingConfigId" << wordSeperator << mFileWriterMessage.DataSamplingConfigId << std::endl;
        if(TriggerType::EventDriven == mFileWriterMessage.TriggerTypeId)
            {
                WriteEventTimestamp(wordSeperator);
            }
        else if(TriggerType::Periodic == mFileWriterMessage.TriggerTypeId)
            {
                // This is just place holder for number of characters for periodic timestamp
                // later on this will be modified with file creation & closing timestamp.
                WritePeriodicTimestamp(wordSeperator, lineNumber);
            }
        mFileWriterPtr << mFileWriterMessage.Description << std::endl << std::endl;
    }

void FileWriterModel::WriteEventTimestamp(const std::string& wordSeperator)
    {
        std::string str1 = "startingEventDateTimestamps" + wordSeperator;
        for(const auto& time : mFileWriterMessage.StartingEventDateTimestamps)
            {
                str1 = str1 + time + wordSeperator;
            }
        str1 = str1 + "\n";
        mFileWriterPtr << str1;
        str1 = "endingEventDateTimestamps" + wordSeperator;
        for(const auto& time : mFileWriterMessage.EndingEventDateTimestamps)
            {
                str1.append(time + wordSeperator);
            }
        str1 = str1 + "\n";
        mFileWriterPtr << str1;
    }

void FileWriterModel::WritePeriodicTimestamp(const std::string& wordSeperator, unsigned int& lineNumber)
    {
        lineNumber = mFileWriterPtr.tellp(); //get the position of 6th row / line
        std::string str1 = "startingEventDateTimestamps" + wordSeperator + mTimeUtilitiesHandle->GetTimeDate() + wordSeperator + "\n";
        mFileWriterPtr << str1;
        std::string str2 = "endingEventDateTimestamps" + wordSeperator + mTimeUtilitiesHandle->GetTimeDate() + wordSeperator + "\n";
        mFileWriterPtr << str2;
    }

std::string FileWriterModel::GetOuputFileName()
    {
        return mOutputFileName;
    }

int FileWriterModel::GetPriorityFolderFilesCount(Priority priority)
    {
        return mPriorityFolderFileNames.at(priority).size();
    }

std::string FileWriterModel::GetJ1939OrXCPOutputFileName(SamplingProtocols protocol)
    {
        // As per navistar or cummins configuration received, "number" would be Vehicle Identification Number or Engine Serial Number respectively.
        std::string number = mFileWriterMessage.ESN;
        if(ConfigFrom::Navistar == mActivatedConfigFrom)
            {
                number = mFileWriterMessage.VIN;
            }

        std::string outputFileName;

        // As per "NGDI File Upload Process.pdf" document (section 2) file name should follow format as :
        // <TSPName, e.g. EDGE>_<BoxID>_<ESN>_SCxxxx_<FileCloseDateTimestamp_in_ISO8601_format>.csv
        outputFileName = mFileWriterMessage.TSPName + "_" + mFileWriterMessage.TelematicsBoxId + "_" +
                         number + "_" + mFileWriterMessage.DataSamplingConfigId + "_" +
                         mTimeUtilitiesHandle->GetTimeDate() + "_" + std::to_string(mFileCounter) +
                         mFileExtensionType.at(protocol);
        return outputFileName;
    }

std::string FileWriterModel::GetEALOutputFileName(SamplingProtocols protocol)
    {
        std::string outputFileName;
        // EAL data is specific to cummins only, so here Engine Serial Number is used
        std::string number = mFileWriterMessage.ESN;

        std::stringstream counter;
        counter << std::setfill('0') << std::setw(6) << mKeyCycleCnt;
        // As per "OEM-TSP NGDI-based Engineering & Trip Data Interface (v1.2.0)" document (section 5.2/5) file name should follow format as :
        // <TSPName>_<BoxID>_<ESN>_SCxxxx_<FileCloseDateTimestamp_in_ISO8601_format>-000000_<DDID>_<SA_xxx>.csv
        outputFileName = mFileWriterMessage.TSPName + "_" + mFileWriterMessage.TelematicsBoxId + "_" +
                         number + "_" + mFileWriterMessage.DataSamplingConfigId + "_" +
                         mTimeUtilitiesHandle->GetTimeDate() + "-" + counter.str() + "_" + mFileWriterMessage.DDID +
                         "_" + "SA_" + mFileWriterMessage.EALSourceAddr + mFileExtensionType.at(protocol);
        return outputFileName;
    }

std::string FileWriterModel::GetTripDataOutputFileName(SamplingProtocols protocol)
    {
        std::string outputFileName;
        std::stringstream counter;
        counter << std::setfill('0') << std::setw(6) << mKeyCycleCnt;
        // As per "OEM-TSP NGDI-based Engineering & Trip Data Interface (v1.2.0)" document (section 5.3/5) file name should follow format as :
        // <BoxID>-<TSPName>-<FileCloseDatestamp_in_YYYYMMDD>-<FileCloseTimestamp_in_HHMMSSsss>-000000.txt
        outputFileName = mFileWriterMessage.TelematicsBoxId + "-" + mFileWriterMessage.TSPName + "-" +
                         mTimeUtilitiesHandle->GetTimeDate(DateTime::TxtDate) + "-" + mTimeUtilitiesHandle->GetTimeDate(DateTime::TxtTime) +
                         "-" + counter.str() + mFileExtensionType.at(protocol);

        return outputFileName;
    }

void FileWriterModel::WriteTripDataInFile()
    {
        for (const auto& tripData : mTripData)
            {
				mFileWriterPtr << std::uppercase << std::hex << std::setfill('0') << std::setw(2) << static_cast<int>(tripData) << std::endl;
            }
    }

void FileWriterModel::WriteSourcesInFile(const std::string& wordSeperator)
{
    unsigned int cnt = 1;
    // Fixed the crash
    struct Record firstRecord = mRecordsData.at(0);

    // Write source id's/SPN names in individual column cell in output file
    mFileWriterPtr << "asDateTimestamp" << wordSeperator;

    std::vector<GpsSamplerConfig> gps_sampler_config_msgs = mAppManagerPtr->GetConfigurationModel()->GetGpsSamplerConfig();
    if(gps_sampler_config_msgs.size()>0)
    {
        GpsSamplerConfig gpsConfig = gps_sampler_config_msgs.at(0);
        if(gpsConfig.IsLatitude)
        {
            mFileWriterPtr << LATITUDE << wordSeperator;
        }
        if(gpsConfig.IsLongitude)
        {
            mFileWriterPtr << LONGITUDE<< wordSeperator;
        }
        if(gpsConfig.IsAltitude)
        {
            mFileWriterPtr << ALTITUDE<< wordSeperator;
        }
        if(gpsConfig.IsDirection_Heading)
        {
            mFileWriterPtr << DIRECTION_HEADING<< wordSeperator;
        }
        if(gpsConfig.IsGPS_Vehicle_Speed)
        {
            mFileWriterPtr << GPS_VEHICLE_SPEED<< wordSeperator;
        }

    }

    // If Cummins json & protocol is J1939, then write source as "converted~J1939~CAN1~0~"
    if((ConfigFrom::Cummins == mActivatedConfigFrom) && (SamplingProtocols::J1939 == mFileWriterMessage.SamplingProtocolId))
    {
        mFileWriterPtr << "converted~J1939~CAN1~0~" << wordSeperator;
    }
    else if((ConfigFrom::Cummins == mActivatedConfigFrom) && (SamplingProtocols::EAL == mFileWriterMessage.SamplingProtocolId))
    {
        // If Cummins json & protocol is EAL, then write source as "raw~EDL~CAN2~0~"
        mFileWriterPtr << "raw~EDL~CAN2~0~" << wordSeperator;
    }

    // Write source id's/SPN names in individual column cell in output file
    for (const auto& source : firstRecord.Data)
        {
            if (cnt != firstRecord.Data.size())
                {
                    mFileWriterPtr << source.first << wordSeperator;
                }
            else
                {
                    mFileWriterPtr << source.first;
                }
            cnt++;
        }
    mFileWriterPtr << std::endl;
}

void FileWriterModel::WriteSourceValuesInFile(const std::string& wordSeperator)
{
    unsigned int cnt = 1;

    for (unsigned int recordIndex=0; recordIndex<mRecordsData.size(); recordIndex++)
    {
        mFileWriterPtr << mRecordsData.at(recordIndex).TimeStamp << wordSeperator;

        std::vector<GpsSamplerConfig> gps_sampler_config_msgs = mAppManagerPtr->GetConfigurationModel()->GetGpsSamplerConfig();
        if(gps_sampler_config_msgs.size()>0)
        {
            GpsSamplerConfig gpsConfig = gps_sampler_config_msgs.at(0);

            if(gpsConfig.IsLatitude)
            {
                mFileWriterPtr << mRecordsData.at(recordIndex).Latitude << wordSeperator;
            }

            if(gpsConfig.IsLongitude)
            {
                mFileWriterPtr << mRecordsData.at(recordIndex).Longitude  << wordSeperator;
            }

            if(gpsConfig.IsAltitude)
            {
                mFileWriterPtr << mRecordsData.at(recordIndex).Altitude  << wordSeperator;
            }

            if(gpsConfig.IsDirection_Heading)
            {
                mFileWriterPtr << mRecordsData.at(recordIndex).DirectionHeading  << wordSeperator;
            }

            if(gpsConfig.IsGPS_Vehicle_Speed)
            {
                mFileWriterPtr << mRecordsData.at(recordIndex).GPSVehicleSpeed  << wordSeperator;
            }
        }

        // If Cummins json, then write empty values in column "converted~J1939~CAN1~0~"
        if((ConfigFrom::Cummins == mActivatedConfigFrom) &&
            (SamplingProtocols::J1939 == mFileWriterMessage.SamplingProtocolId || SamplingProtocols::EAL == mFileWriterMessage.SamplingProtocolId))
        {
            mFileWriterPtr << "" << wordSeperator;
        }

        std::deque <std::pair<std::string, std::string >> currentData = mRecordsData.at(recordIndex).Data;
        for (unsigned int dataIndex=0; dataIndex < currentData.size(); dataIndex++)
        {
            if (cnt != currentData.size())
            {
                mFileWriterPtr << currentData.at(dataIndex).second << wordSeperator;
            }
            else
            {
                mFileWriterPtr << currentData.at(dataIndex).second;
            }
            cnt++;
        }
        cnt = 1;
        mFileWriterPtr << std::endl;
    }
}

void FileWriterModel::WriteXCPErrorLogFile(FileWriterMessage fileWriterMessage)
{
    LOG_MOD(NOTICE, logmod)<<"WriteXCPErrorLogFile ......";

    std::string outputFileNamePath = mPriorityDirectoryPath[fileWriterMessage.PriorityId] + "/" + "XCPInvalidSignalErrorLog.txt";
    CreateOutputFilePtr(outputFileNamePath);
    LOG_MOD(NOTICE, logmod)<<"Writing ERROR file " << outputFileNamePath;
    mFileWriterPtr << "Invalid address found for XCP signal, hence terminating entire configuration file.";
    mFileWriterPtr.flush();
    mFileWriterPtr.close();
}

bool FileWriterModel::IsValidDeviceInformation()
{
	bool isValid = false;
	#ifdef DAQEMULATOR
        return true;// In order to test logged files on emulator forcefully need to pass validation.
	#endif // DAQEMULATOR
		if(mFileWriterMessage.IsNavistarConfig) // For Navistar file
		{
			if(mFileWriterMessage.TelematicsBoxId != "NA" && mFileWriterMessage.VIN != "NA")
			{
				isValid = true;
			}
		}
		else if (mFileWriterMessage.TelematicsBoxId != "NA" && mFileWriterMessage.ESN != "NA") // For Cummins file
		{
			isValid = true;
		}
	return isValid;
}
