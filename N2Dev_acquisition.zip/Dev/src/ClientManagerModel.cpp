#include <ecu/logging.h>
#include "ClientManagerModel.h"
#include "TimeUtilities.h"
#include "AppManager.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.ClientManagerModel");
    }
using namespace DaqApp;

ClientManagerModel::ClientManagerModel(AppManager* passed):
mAppManPtr(passed),
mConfigPtr(new ecu::lapi::config::Configuration())
    {
        LOG_MOD(NOTICE, logmod) << "Creation: ClientManagerModel";
    }
void ClientManagerModel::SetUpClientManager()
    {
        mConfigPtr->set("client_name", "DaqApp");
        mClientPtr = create_client(mConfigPtr,ecu::lapi::com::TransportType::TYPE_MQTT);

        if (nullptr != mClientPtr){
            mClientPtr->connect();
            mClientPtr->start();

        #ifndef DAQEMULATOR
            mSysParamsClientPtr = ecu::lapi::var::create_sysparams_client(mClientPtr);
        #endif // DAQEMULATOR
        }

    }
ClientManagerModel::~ClientManagerModel()
    {
		mAppManPtr->GetTimeUtilities()->ReleaseTick(mTick);

        if(mClientPtr)
        {
          mClientPtr->stop();
          mClientPtr->disconnect();
        }
        LOG_MOD(NOTICE, logmod) << "Destruction: ClientManagerModel";
    }

ecu::lapi::com::ITransportClient_ptr ClientManagerModel::getTransportClient()
	{
		return mClientPtr;
	}

ecu::lapi::var::SysParamsClient_ptr ClientManagerModel::getSystemParameterClient(){
	assert (nullptr != mSysParamsClientPtr);
	return mSysParamsClientPtr;
}

bool ClientManagerModel::ConfigureCAN2Baudrate(const std::string& rate){
#ifndef DAQEMULATOR
	char rate_val;

	if ((nullptr == mSysParamsClientPtr) || rate.empty() )	return false;

	if ( rate == "250000" ){
		rate_val = 0x01;
	}
	else if ( rate == "500000" ){
		rate_val = 0x02;
	}
	else if ( rate == "1000000" ){
		rate_val = 0x03;
	}
	else{
		return false;
	}

	//Get existing value for OTAID that controls CAN2 channel
	ecu::lapi::var::SysParamsClient::GetResult sysp_res = mSysParamsClientPtr->get(mSysParamCAN2BaudRate);

	if(sysp_res.nok()){
		return false;
	}
	ecu::lapi::var::SysParamsClient::ParamValue sysp_saved_val = sysp_res.take_val();

	//Check existing value, if it matches with toggle request, nothing needs to be done.
	if (sysp_saved_val.content().compare({rate_val}) == 0){
		LOG_MOD(NOTICE, logmod) << "ConfigureCAN2Baudrate(): Baud Rate matches with existing";
		return true;
	}

	//Write requested toggle value to system parameter map
	ecu::lapi::var::SysParamsClient::ParamMap sys_params_map;
	sys_params_map[mSysParamCAN2BaudRate] = sysp_saved_val;
	sys_params_map[mSysParamCAN2BaudRate].set_content({rate_val});
	mSysParamsClientPtr->set_all(sys_params_map);

	//Create a separate thread to call Write Params because this client function is blocking
	mTick = mAppManPtr->GetTimeUtilities()->Tick(ms(2), Redundancy::DoOnce, &ClientManagerModel::WriteSysParameterClient, this);
#endif
	return true;
}

/*
 * Different function so that a separate thread can call this blocking function
 */
void ClientManagerModel::WriteSysParameterClient(void){
	//Write System Parameter map to SDK
	ecu::lapi::var::SysParamsClient::WriteResult write_res = mSysParamsClientPtr->write();
	if (write_res.ok())
		LOG_MOD(NOTICE, logmod) << "CAN Channel 2 BaudRate Set Successfully";
	else
		LOG_MOD(ERROR, logmod) << "CAN Channel 2 BaudRate Failed to Write System Parameter" << (int)write_res.err_val();
}
