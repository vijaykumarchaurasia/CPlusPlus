#include "AppManager.h"
#include <chrono>
#include <execinfo.h>
#include <signal.h>
#include <unistd.h>
#include <ecu/logging.h>
#include <fstream>
#include "DataAccessModel.h"
#include "EventsManagerModel.h"

using namespace std::chrono;
namespace
    {
       static auto logmod = ecu::lapi::logging::module("DaqApp.Main");
    }
using namespace DaqApp;

void InstallCrashHandler(int sig)
    {
      void *array[35];
      size_t size;

      size = backtrace(array, 35);
      fprintf(stderr, "Error: signal %d:\n", sig);
      backtrace_symbols_fd(array, size, STDERR_FILENO);
      exit(1);
    }

int main()
    {
        std::string configPath("../app.conf"); // This path will chag
        #ifndef DAQEMULATOR
        //Actual box
        configPath = "/home/root/app.conf";
        #endif // DAQEMULATOR
        ecu::lapi::config::Configuration_ptr config(new ecu::lapi::config::Configuration());
        std::ifstream cf;
        cf.open(configPath);
        if (cf.is_open())
            {
                ecu::lapi::config::set_config_from_input(config, cf);
            }
        else
            {
                LOG(ERROR) << "Failed to find configuration file. Exiting!";
                return -1;
            }
        ecu::lapi::logging::set_from_config(config);
        #ifdef DEBUGDAQ
            signal(SIGSEGV, InstallCrashHandler);
            signal(SIGABRT, InstallCrashHandler);
            signal(SIGTERM, InstallCrashHandler);
        #endif // DEBUGDAQ

        #ifndef GTESTBUILD
        JenkinsCatch("Release build")
        std::unique_ptr<AppManager> myApp = std::make_unique<AppManager>();
        myApp->StartApp();
        for(;;){std::this_thread::sleep_for(std::chrono::seconds(1000));};
        #endif
        return 0;//no return
    }
