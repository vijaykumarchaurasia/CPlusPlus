#include <boost/algorithm/string.hpp>
#include <ecu/logging.h>
#include "AppManager.h"
#include "FilesHandlingModel.h"
#include "ConfigurationManagerModel.h"
#include "EventsManagerModel.h"
#include "DataConnectivityModel.h"
#include "CommonHeader.h"
#define LOWLOGDIR 1
#define MIDLOGDIR 2
#define HIGHLOGDIR 3

bool mFileUploadProcessed = false;

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.FilesHandlingModel");
    }
using namespace DaqApp;
FilesHandlingModel::FilesHandlingModel(AppManager* passed):
mAppManHandlePtr(passed),
mCloudServicesPtr(std::make_unique<CloudServicesModel>(passed)),
mDataConnectivityPtr(mCloudServicesPtr->GetDataConnectivityModel()),
mCorrelationId("")
    {
        LOG_MOD(NOTICE, logmod)<<"Creation: FilesHandlingModel";
    }

FilesHandlingModel::~FilesHandlingModel()
    {
        LOG_MOD(NOTICE, logmod)<<"Destruction: FilesHandlingModel";
        mUploadfiles.clear();
        mActiveConfigFiles.clear();
        mActiveConfigFilesCorrelationID.clear();
    }

/*
*This function creates sets up the fileshandlingmodel object as required for DaqApp
*/
void FilesHandlingModel::SetUpFilesHandlingModel()
    {
        EventsManagerModel* eventsManagerModelPtr = mAppManHandlePtr->GetEventsManagerModel();
        InitializeDirectoryStructure();
        eventsManagerModelPtr->AddSignal(mAppManHandlePtr->NOSUFFICIENTSPACE);
        eventsManagerModelPtr->ConnectToSignal(FILE_WRITING_COMPLETED_SIGNAL,boost::bind(&FilesHandlingModel::OnNotifyFileWritingCompleted,this));
        #ifndef GTESTBUILD
            mTickId = mAppManHandlePtr->GetTimeUtilities()->Tick(ms(2000),Redundancy::Infinite,&FilesHandlingModel::UploadFileToCloud,this);
        #endif // GTESTBUILD
        boostfs::path dirPath{LOG_DIR};
        boostfs::space_info spinfo = boostfs::space(dirPath);
        mTotalSpace = spinfo.capacity;
    	LOG_MOD(NOTICE, logmod)<<"Total Space : " << spinfo.capacity << " Bytes";
        LOG_MOD(NOTICE, logmod)<<"Free Space : " << spinfo.free << " Bytes";
        LOG_MOD(NOTICE, logmod)<<"free space in %  : " << (float)(spinfo.free*100)/spinfo.capacity;
        SetMinThreshold(((static_cast<uintmax_t> (mTotalSpace / 100))* mMinThresholdPercentage));
        SetMaxThreshold(((static_cast<uintmax_t> (mTotalSpace / 100))* mMaxThresholdPercentage));
        if(!boostfs::is_empty(LOG_HIGH_DIR) || !boostfs::is_empty(LOG_NORMAL_DIR) || !boostfs::is_empty(LOG_LOW_DIR))
            {
                LOG_MOD(NOTICE, logmod)<<"Upload pending files";
                eventsManagerModelPtr->EmitSignal(FILE_WRITING_COMPLETED_SIGNAL);
            }
    }

void FilesHandlingModel::UploadFileToCloud()
    {
        mFileUploadProcessed = false;
        mUploadReady         = false;
        std::set<std::string> st;
        st.insert({ "" });
        auto removeFromList = st.begin();
        if(mUploadfiles.size() && (!mLowSpaceDetected) && mDataConnectivityPtr->CheckInternetConnectivity())
        {
            {
				const std::lock_guard<std::mutex> lock(mMutexUpload);
				removeFromList = mUploadfiles.begin();
				mUploadReady = true;
            }

            std::unique_lock<std::mutex> locker(mMutexFreeUpSpace);
            LOG_MOD(INFO, logmod)<< "UploadFileToCloud:"<< *removeFromList;
            bool upload_result = mCloudServicesPtr->UploadFile(*removeFromList, GetCorrelationID(ExtractConfigIDFromLogFile(*removeFromList)));
            LOG_MOD(INFO, logmod)<< "UploadFileToCloud result"<<upload_result;

            if(upload_result)
                {
                    boostfs::remove(*removeFromList);
                }
            mFileUploadProcessed = true;
            locker.unlock();
            {
                const std::lock_guard<std::mutex> lock(mMutexUpload);
                if(upload_result)
                mUploadfiles.erase(removeFromList);
            }
            mConditionVar.notify_one();
        }
    }

std::string FilesHandlingModel::ExtractConfigIDFromLogFile(const std::string& log_file){
    std::vector<std::string> splittedFileName;
    std::string delimeter = "_";
    std::string config_id;
    boost::split(splittedFileName, log_file, boost::is_any_of(delimeter));     //Split file name by "_"
    for (auto splits:splittedFileName){
        if (splits.find("SC") == 0){    //Find "SCxxxx" in file name
            config_id = splits;
            break;
        }
    }
    if(config_id.empty()){      //If "SCxxxx" is not part of file name, its Trip Data File
    std::vector<UDSConfigMessage> udsConfigs = mAppManHandlePtr->GetConfigurationModel()->GetUdsConfig();
        for ( const auto& uds_config : udsConfigs )
        {
            if (uds_config.IsTripData == true)
            {
                config_id = uds_config.ConfigName;
                break;
            }
        }
    }
    return config_id;
}

/*
*This function creates directory structure if not present
*/
void FilesHandlingModel::InitializeDirectoryStructure()
    {
        LOG_MOD(NOTICE, logmod)<< "Initializing DirectoryStructure";
        try
            {
                if((IsDirExists(COMMON_DIR)))
                    {
                        LOG_MOD(INFO, logmod)<< COMMON_DIR << " directory already exists.";
                        if(( IsDirExists(BASE_CONFIG_DIR)))
                            {
                                LOG_MOD(INFO, logmod)<<  BASE_CONFIG_DIR << " directory already exists.";
                                if(( IsDirExists(ACTIVE_CONFIG_DIR)))
                                    {
                                        LOG_MOD(INFO, logmod)<< ACTIVE_CONFIG_DIR << " directory already exists.";
                                    }
                                else
                                    {
                                        if(CreateDirectory(ACTIVE_CONFIG_DIR))
                                            {
                                                LOG_MOD(INFO, logmod)<<  "Directory " << ACTIVE_CONFIG_DIR << " created succussfully";
                                            }
                                        else{LOG_MOD(ERROR, logmod) << "Error in creating directory " << ACTIVE_CONFIG_DIR << std::endl;}
                                    }
                            if(( IsDirExists(INACTIVE_CONFIG_DIR)))
                                {
                                    LOG_MOD(INFO, logmod)<< INACTIVE_CONFIG_DIR << " directory already exists.";
                                }
                            else
                                {
                                    if(CreateDirectory(INACTIVE_CONFIG_DIR))
                                        {
                                            LOG_MOD(INFO, logmod)<< "Directory " << INACTIVE_CONFIG_DIR << " created succussfully";
                                        }
                                    else{LOG_MOD(ERROR, logmod) << "Error in creating directory " << INACTIVE_CONFIG_DIR;}
                                }
                            }
                    else
                        {
                            CreateConfigDirectoryStructure();
                        }
                    if((IsDirExists(LOG_DIR)))
                        {
                            LOG_MOD(INFO, logmod)<< LOG_DIR << " directory already exists.";
                            if(( IsDirExists(LOG_LOW_DIR)))
                                {
                                    LOG_MOD(INFO, logmod)<< LOG_LOW_DIR << " directory already exists.";
                                    CompressFiles(LOG_LOW_DIR);
                                }
                            else
                                {
                                    if(CreateDirectory(LOG_LOW_DIR))
                                        {
                                            LOG_MOD(INFO, logmod)<< "Directory " << LOG_LOW_DIR << " created succussfully";
                                        }
                                    else{LOG_MOD(ERROR, logmod)<< "Error in creating directory " << LOG_LOW_DIR;}
                                }
                            if(( IsDirExists(LOG_NORMAL_DIR)))
                                {
                                    LOG_MOD(INFO, logmod)<< LOG_NORMAL_DIR << " directory already exists.";
                                    CompressFiles(LOG_NORMAL_DIR);
                                }
                            else
                                {
                                    if(CreateDirectory(LOG_NORMAL_DIR))
                                        {
                                            LOG_MOD(INFO, logmod)<< "Directory " << LOG_NORMAL_DIR << " created succussfully";
                                        }
                                    else{LOG_MOD(INFO, logmod) << "Error in creating directory " << LOG_NORMAL_DIR;}
                                }
                            if(( IsDirExists(LOG_HIGH_DIR)))
                                {
                                    LOG_MOD(INFO, logmod)<< LOG_HIGH_DIR << " directory already exists.";
                                    CompressFiles(LOG_HIGH_DIR);
                                }
                            else
                                {
                                    if(CreateDirectory(LOG_HIGH_DIR))
                                        {
                                            LOG_MOD(INFO, logmod)<< "Directory " << LOG_HIGH_DIR << " created succussfully";
                                        }
                                    else{LOG_MOD(ERROR, logmod)<< "Error in creating directory " << LOG_HIGH_DIR;}
                                }
                        }
                    else
                        {
                            CreateDataLoggingDirectoryStructure();
                        }

                    if((IsDirExists(MISC_DIR)))
                        {
                            LOG_MOD(INFO, logmod)<< MISC_DIR << " directory already exists.";
                        }
                    else
                        {
                            if(CreateDirectory(MISC_DIR))
                                {
                                    LOG_MOD(INFO, logmod)<< "Directory " << MISC_DIR << " created succussfully";
                                }
                            else{LOG_MOD(ERROR, logmod)<< "Error in creating directory " << MISC_DIR;}
                        }
                    }
                else
                    {
                        CreateEntireCommonDirectoryStructure();
                    }
             }
        catch(const boostfs::filesystem_error& e)
            {
                LOG_MOD(ERROR, logmod)<< "FileHandlingModel exception occurred in creating directory structure: " << e.code().message() << std::endl;
            }
    }

/*
*This function creates Entire directory structure, needs to be called if directory structure is not present already
*/
void FilesHandlingModel::CreateEntireCommonDirectoryStructure()
    {
        if(CreateDirectory(COMMON_DIR))
            {
                CreateConfigDirectoryStructure();
                CreateDataLoggingDirectoryStructure();
                if(CreateDirectory(MISC_DIR))
                    {
                        LOG_MOD(NOTICE, logmod)<< "Directory " << MISC_DIR << " created succussfully";
                    }
                else{LOG_MOD(ERROR, logmod)<< "Error in creating directory " << MISC_DIR;}
            }
        else{LOG_MOD(ERROR, logmod)<< "Error in creating directory " << COMMON_DIR;}
    }

/*
*This function creates directory structure for config file's storage
*/
void FilesHandlingModel::CreateConfigDirectoryStructure()
    {
        if(CreateDirectory(BASE_CONFIG_DIR))
            {
                LOG_MOD(INFO, logmod)<< "Directory " << BASE_CONFIG_DIR << " created succussfully";
                if(CreateDirectory(ACTIVE_CONFIG_DIR))
                    {
                        LOG_MOD(INFO, logmod)<< "Directory " << ACTIVE_CONFIG_DIR << " created succussfully";
                    }
                else{LOG_MOD(ERROR, logmod)<< "Error in creating directory " << ACTIVE_CONFIG_DIR;}
                if(CreateDirectory(INACTIVE_CONFIG_DIR))
                    {
                        LOG_MOD(INFO, logmod)<< "Directory " << INACTIVE_CONFIG_DIR << " created succussfully";
                    }
                else{LOG_MOD(ERROR, logmod)<< "Error in creating directory " << INACTIVE_CONFIG_DIR;}
            }
        else{LOG_MOD(ERROR, logmod)<< "Error in creating directory " << BASE_CONFIG_DIR;}
    }

/*
*This function creates directory structure for output file's storage
*/
void FilesHandlingModel::CreateDataLoggingDirectoryStructure()
    {
        if(CreateDirectory(LOG_DIR))
            {
                LOG_MOD(INFO, logmod)<< "Directory " << LOG_DIR << " created succussfully";
                if(CreateDirectory(LOG_LOW_DIR))
                    {
                        LOG_MOD(INFO, logmod)<< "Directory " << LOG_LOW_DIR << " created succussfully";
                    }
                else{LOG_MOD(ERROR, logmod)<< "Error in creating directory " << LOG_LOW_DIR;}
                if(CreateDirectory(LOG_NORMAL_DIR))
                    {
                        LOG_MOD(INFO, logmod)<< "Directory " << LOG_NORMAL_DIR << " created succussfully";
                    }
                else{LOG_MOD(ERROR, logmod)<< "Error in creating directory " << LOG_NORMAL_DIR;}
                if(CreateDirectory(LOG_HIGH_DIR))
                    {
                        LOG_MOD(INFO, logmod)<< "Directory " << LOG_HIGH_DIR << " created succussfully";
                    }
                else{LOG_MOD(ERROR, logmod)<< "Error in creating directory " << LOG_HIGH_DIR;}
            }
        else{LOG_MOD(ERROR, logmod)<< "Error in creating directory " << LOG_DIR;}
    }


bool FilesHandlingModel::IsDirExists(std::string const &fname)
    {
        boostfs::path dirName{fname};
        return (boostfs::exists(dirName));
    }

bool FilesHandlingModel::CreateDirectory(std::string const &fname)
    {
        boostfs::path dirName{fname};
        return (boostfs::create_directory(dirName));
    }

/*
*This function is a getter function to get configFilePath
*Return type: string : path name, empty if no file found
*/
std::string FilesHandlingModel::GetConfigFilePath()
    {
        std::string result = "";
        boostfs::path defaultconfigFilePath;
        defaultconfigFilePath.append("../");
        defaultconfigFilePath.append(CONFIGURATION_FILE_NAME);
        #ifndef DAQEMULATOR
            defaultconfigFilePath = "/home/root/Configuration.json";
        #endif // DAQEMULATOR

        try
            {
            if(!boostfs::is_empty(ACTIVE_CONFIG_DIR))
                {
                    const boostfs::directory_iterator end_itr;
                    const auto firstFoundJson = std::find_if(boostfs::directory_iterator(ACTIVE_CONFIG_DIR), end_itr,
                                        [](const boostfs::directory_entry& e) {
                                        return e.path().extension().string() == JSON_EXT;
                                      });
                    if (firstFoundJson == end_itr)
                    {
                        LOG_MOD(NOTICE, logmod)<< " Activating default config file" << std::endl;
                        result = defaultconfigFilePath.string();
                    }
                    else
                    {
                        LOG_MOD(NOTICE, logmod)<< " Activating file in Activate config Directory"<<firstFoundJson->path().string()<<std::endl;
                        result = firstFoundJson->path().string();
                    }
                }
            else
                {
                    if(boostfs::exists(defaultconfigFilePath))
                    {
                        if (!(boostfs::is_directory(defaultconfigFilePath) || boostfs::is_empty(defaultconfigFilePath)))
                            result = defaultconfigFilePath.string();
                    }
                }
            }
        catch(const boostfs::filesystem_error& e)
            {
                LOG_MOD(ERROR, logmod)<< "exception occurred while checking config file details : " << e.code().value() <<  e.code().message();
            }
        return result;
    }

/*
*This function is a getter function to get TopicList file
*Return type: string : path name, empty if no file found
*/
std::string FilesHandlingModel::GetJ1939TopicListFilePath()
    {
        std::string result = "";
        //boostfs::path topicListFilePath{(MISC_DIR+"/"+"Topic List.csv")};  // currently file is not being put in '/common/Miscellaneous' directory
        boostfs::path topicListFilePath{("../Topic List.csv")};		//Hence sending the '../' directory path
        #ifndef DAQEMULATOR
            //Production
            topicListFilePath = "/home/root/Topic List.csv";
        #endif // DAQEMULATOR
        try
            {
                if(boostfs::exists(topicListFilePath))
                    {
                        if (!(boostfs::is_directory(topicListFilePath) || boostfs::is_empty(topicListFilePath)))
                            result = topicListFilePath.string();
                    }
            }
        catch(const boostfs::filesystem_error& e)
            {
                LOG_MOD(ERROR, logmod)<< "exception occurred while checking Topic list file details : " << e.code().value() <<  e.code().message();
            }
        return result;
    }

/*
*This function is a getter function to get corresponding output file path
*Return type: string : path name
*Parameter : Priority, Low or Medium or High, defined in configuration.h
*/
std::string FilesHandlingModel::GetOutputFilePath(const Priority priority)
    {
        std::string result = "";
        switch (priority)
            {
                case Priority::HIGH:
                    {
                        boostfs::path dirPath{LOG_HIGH_DIR};
                        result = dirPath.string();
                        break;
                    }
                case Priority::NORMAL:
                    {
                        boostfs::path dirPath{LOG_NORMAL_DIR};
                        result = dirPath.string();
                        break;
                    }
                case Priority::LOW:
                    {
                        boostfs::path dirPath{LOG_LOW_DIR};
                        result = dirPath.string();
                        break;
                    }
                case Priority::InvalidPriority:
                    {
                        result = "";
                        break;
                    }
                default:
                    LOG_MOD(INFO, logmod) << "default condition achieved" << std::endl;
                break;
            }
        return result;
    }

/*
*This function is a getter function to get of newly downloaded config file in Misc. directory
*Return type: string : path name, empty if no file found
*/
std::string FilesHandlingModel::GetLatestReceivedConfigFilePath()
    {
        std::string result = "";
        boostfs::path NewDownloadedFilePath{(MISC_DIR +"/"+mNewDownloadedConfigFile)};
        try
            {
                if(boostfs::exists(NewDownloadedFilePath))
                    {
                        if (!(boostfs::is_directory(NewDownloadedFilePath) || boostfs::is_empty(NewDownloadedFilePath)))
                            result = NewDownloadedFilePath.string();
                    }
            }
        catch(const boostfs::filesystem_error& e)
            {
                LOG_MOD(ERROR, logmod)<<  "exception occurred while checking new downloaded config file details : " << e.code().value() <<  e.code().message();
            }
        return result;
    }

/*
*This function compresses the input file using boost gzip library
*Parameter : string : input file name(URL)
*/
void FilesHandlingModel::CompressFile(const std::string& fileToBeCompressed, const std::string& fileNameafterCompression)
    {
        std::ifstream inStream(fileToBeCompressed, std::ios_base::in | std::ios_base::binary);
        std::ofstream outStream(fileNameafterCompression, std::ios_base::out);
        boost::iostreams::filtering_streambuf< boost::iostreams::input> in;
        in.push( boost::iostreams::gzip_compressor());
        in.push( inStream );
        boost::iostreams::copy(in, outStream);
        LOG_MOD(NOTICE, logmod)<< "File name after compression :: " << fileNameafterCompression;
    }

/*
*This function will be called on signal NotifyFileWritingCompleted is thrown
*Parameter : Object of Enum class Priority defined in 'configmessage.h'
*/
void FilesHandlingModel::OnNotifyFileWritingCompleted()
    {
        boostfs::path dirPath{LOG_HIGH_DIR};
            CompressFiles(dirPath);
            AddUploadFilesToContainer(dirPath);
        dirPath = LOG_NORMAL_DIR;
            CompressFiles(dirPath);
            AddUploadFilesToContainer(dirPath);
        dirPath = LOG_LOW_DIR;
            CompressFiles(dirPath);
            AddUploadFilesToContainer(dirPath);
            #ifndef GTESTBUILD
                CheckForAvailableSpace();
            #endif // GTESTBUILD
    }

void FilesHandlingModel::AddUploadFilesToContainer(const boostfs::path& directoryName)
    {
        boostfs::directory_iterator end_iter;
            try
                {
                    for (boostfs::directory_iterator itr(directoryName); itr != end_iter; ++itr)
                        {
                            if (!(boostfs::is_directory(itr->path()) || boostfs::is_empty(itr->path())))
                                {
                                    if(GZIP_EXT == (itr->path().extension().string()))
                                        {
                                            const std::lock_guard<std::mutex> lock(mMutexUpload);
                                            if(boostfs::exists(itr->path()))
                                            {
                                            	mUploadfiles.insert(itr->path().string());
                                            }
                                        }
                                }
                        }
                }
            catch(const boostfs::filesystem_error& e)
                {
                    LOG_MOD(ERROR, logmod)<<  "exception occurred while activating given configuration file : " << e.code().value() << e.code().message();
                }
    }

/*
*This function compresses all the file in a folder
*/
void FilesHandlingModel::CompressFiles(const boostfs::path& directoryName)
    {
        try
            {
                boostfs::directory_iterator end_iter;
                for (boostfs::directory_iterator itr(directoryName); itr != end_iter; ++itr)
                    {
                        if (!(boostfs::is_directory(itr->path()) || boostfs::is_empty(itr->path())))
                            {
                                if((TXT_EXT == (itr->path().extension().string())) || (CSV_EXT == (itr->path().extension().string())))
                                {
                                    boostfs::path outputfilepath{itr->path()};
                                    CompressFile((itr->path().string()),outputfilepath.string()+ GZIP_EXT);
                                    boostfs::remove(itr->path());
                                }
                            }
                    }
             }
        catch(const boostfs::filesystem_error& e)
            {
                LOG_MOD(ERROR, logmod)<<  "exception occurred while file compression : " << e.code().value() <<  e.code().message() << std::endl;
            }
    }

/*
*This function extracts newly downloaded configuration file
*/
void FilesHandlingModel::DecompressDownloadedConfigFile(const std::string& filePath)
    {
        std::string unzipcmd = "unzip -d " + MISC_DIR + " " + filePath;
        int status = system(unzipcmd.c_str());
        if (status < 0)
            {
                LOG_MOD(ERROR, logmod)<< "error in execution of Unzip system command " << status;
            }
        else
            {
                if (WIFEXITED(status))
                {
                    LOG_MOD(WARNING, logmod)<<  "Unzip command returned successfully, exit code : " << WEXITSTATUS(status);
                }
                else
                {
                    LOG_MOD(ERROR, logmod)<<  "Unzip command exited abnormaly";
                }
            }
        const boostfs::directory_iterator end_itr;
        const auto firstFoundJson = std::find_if(boostfs::directory_iterator(MISC_DIR), end_itr,
                                [](const boostfs::directory_entry& e) {
                                return e.path().extension().string() == JSON_EXT;
                              });
        if (firstFoundJson == end_itr)
            {
                LOG_MOD(ERROR, logmod)<<  "No json file found in Misc directory" << std::endl;
            }
        else
            {
                mNewDownloadedConfigFile = firstFoundJson->path().filename().string();
            }
        #ifndef GTESTBUILD
               mAppManHandlePtr->GetEventsManagerModel()->EmitSignal("NewConfigArrived");
        #endif // GTESTBUILD
    }

/*
*This function puts given file from InActiveConfig directory to ActiveConfig directory
*Parameter : file name to be moved in std::string format
*/
void FilesHandlingModel::ActivateConfig(const std::string& jsonFileName)
    {
        LOG_MOD(INFO, logmod)<< "In ActivateConfig with file : " << jsonFileName;
        std::string correlationIdFileName = GetJsonFileName(jsonFileName,".") + TXT_EXT;
        std::vector<std::string> filesToMove;
        filesToMove.push_back(jsonFileName);
        filesToMove.push_back(correlationIdFileName);

        for(const auto& fileName : filesToMove)
        {
            boostfs::path source_directory{INACTIVE_CONFIG_DIR};
            try
                {
                    boostfs::directory_iterator end_iter;
                    for (boostfs::directory_iterator itr(source_directory); itr != end_iter; ++itr)
                        {
                            if (!(boostfs::is_directory(itr->path()) || boostfs::is_empty(itr->path())))
                                {
                                    if(fileName == (itr->path().filename().string()))
                                        {
                                            boostfs::path filePath = ACTIVE_CONFIG_DIR + "/" + fileName;
                                            if(boostfs::exists(filePath))
                                            {
                                                boostfs::remove(filePath);
                                            }
                                            boostfs::copy_file(itr->path(),(ACTIVE_CONFIG_DIR + "/" + itr->path().filename().string()));
                                            boostfs::remove(itr->path());
                                            LOG_MOD(INFO, logmod)<< "File moved from InActive to Active directory : " << fileName;
                                            break;
                                        }
                                }
                        }
                 }
            catch(const boostfs::filesystem_error& e)
                {
                    LOG_MOD(ERROR, logmod)<<  "exception occurred while activating given configuration file : " << e.code().value() << e.code().message();
                }
            }
    }

/*
*This function removes a file by searching the file in all config files directory
*Parameter : file name to be removed in std::string format
*/
void FilesHandlingModel::ForgetConfig(const std::string& jsonFileName)
    {
        LOG_MOD(INFO, logmod)<< "In ForgetConfig with file : " << jsonFileName;
        std::string correlationIdFileName = GetJsonFileName(jsonFileName,".") + TXT_EXT;
        std::vector<std::string> filesToDelete;
        filesToDelete.push_back(jsonFileName);
        filesToDelete.push_back(correlationIdFileName);

        for(const auto& fileName : filesToDelete)
        {
            try
                {
                    const boostfs::recursive_directory_iterator end_itr;
                    const auto itr = std::find_if(boostfs::recursive_directory_iterator(BASE_CONFIG_DIR), end_itr,
                                          [&fileName](const boostfs::directory_entry& e) {
                                            return e.path().filename().string() == fileName;
                                          });
                    if (itr == end_itr)
                        {
                            LOG_MOD(ERROR, logmod)<< "Config file given to forget not found : " << fileName;
                        }
                    else
                        {
                            boostfs::remove(itr->path());
                            LOG_MOD(INFO, logmod)<< "Config file given to forget is removed successfully : " << fileName;
                        }
                }
          catch(const boostfs::filesystem_error& e)
              {
                LOG_MOD(ERROR, logmod)<<  "exception occurred while trying to forget given configuration file : " << e.code().value() << e.code().message();
              }
          }
    }

/*
*This function moves the given file currentely present in ActiveConfig directory to InActiveConfig directory
*/
void FilesHandlingModel::DeActivateConfig(const std::string& jsonFileName)
{
        LOG_MOD(INFO, logmod)<< "In DeActivateConfig with file : " << jsonFileName;
        std::string correlationIdFileName = GetJsonFileName(jsonFileName,".") + TXT_EXT;
        std::vector<std::string> filesToMove;
        filesToMove.push_back(jsonFileName);
        filesToMove.push_back(correlationIdFileName);

        for(const auto& fileName : filesToMove)
        {
            try
                {
                    const boostfs::recursive_directory_iterator end_itr;
                    const auto itr = std::find_if(boostfs::recursive_directory_iterator(ACTIVE_CONFIG_DIR), end_itr,
                                          [&fileName](const boostfs::directory_entry& e) {
                                            return e.path().filename().string() == fileName;
                                          });
                    if (itr == end_itr)
                        {
                            LOG_MOD(ERROR, logmod)<<  "Config file given to deactivate not found : " << fileName;
                        }
                    else
                        {
                            boostfs::copy_file(itr->path(),(INACTIVE_CONFIG_DIR + "/" + itr->path().filename().string()),boostfs::copy_option::overwrite_if_exists);
                            boostfs::remove(itr->path());
                            LOG_MOD(INFO, logmod)<< "Config file given to deactivate is successfully moved to InActiveConfig directory : " << fileName;
                        }
                }
          catch(const boostfs::filesystem_error& e)
              {
                LOG_MOD(ERROR, logmod)<<  "exception occurred while trying to deactivate given configuration file : " << e.code().value() << e.code().message();
              }
          }
}

/*
*This function moves all the files currentely present in ActiveConfig directory to InActiveConfig directory
*/
void FilesHandlingModel::DeActivateConfig()
    {
        boostfs::path source_directory{ACTIVE_CONFIG_DIR};
        try
            {
                boostfs::directory_iterator end_iter;
                for (boostfs::directory_iterator itr(source_directory); itr != end_iter; ++itr)
                    {
                        if (!(boostfs::is_directory(itr->path())))
                            {
                                boostfs::copy_file(itr->path(),(INACTIVE_CONFIG_DIR + "/" + itr->path().filename().string()),boostfs::copy_option::overwrite_if_exists);
                                boostfs::remove(itr->path());
                            }
                        else
                            {
                                boostfs::remove_all(itr->path());
                            }
                    }
             }
        catch(const boostfs::filesystem_error& e)
            {
                LOG_MOD(ERROR, logmod)<<  "exception occurred while deactivating configuration files : " << e.code().value() << e.code().message();
            }
    }

/*
*This function is a response callback function which moves the validated file from Misc directory to Inactivate Config directory
*If file is non valid it is not moved but deleted
*Parameter : file path of the validated file and validation flag
*/
void FilesHandlingModel::NewDownloadedConfigFileValidationResponse(const std::string& filePath, bool isValid)
    {
        LOG_MOD(NOTICE, logmod)<<"NewDownloadedConfigFileValidationResponse : "<< filePath;
        boostfs::path validatedFilePath{filePath};
        try
            {
            if(isValid == true)
                {
                    boostfs::path fileToRemove = INACTIVE_CONFIG_DIR + "/" + validatedFilePath.filename().string();
                    if(boostfs::exists(fileToRemove))
                        {
                            boostfs::remove(fileToRemove);
                        }
                    boostfs::copy_file(validatedFilePath.string(),(INACTIVE_CONFIG_DIR + "/" + validatedFilePath.filename().string()));
                    //Create .txt file for Correlation ID in InActive folder
                    std::string fileNameWithExt = GetJsonFileName(filePath,"/"); // for ex. SC001.json
                    CreateCorrelationIdTxtFile(fileNameWithExt, INACTIVE_CONFIG_DIR);
                }
            #ifndef GTESTBUILD
                boostfs::remove(validatedFilePath);
            #endif // GTESTBUILD
            }
        catch(const boostfs::filesystem_error& e)
            {
                LOG_MOD(ERROR, logmod)<<  "exception occurred while removing validated file : " << e.code().value() << e.code().message();
            }
    }

void FilesHandlingModel::SetConfigCorrelationId(const std::string& correlationId)
{
    mCorrelationId = correlationId;
}

/*
description : This function will json file name without extension
input : configuration file name for ex. SCXXX.json or path for ex. /common/Miscellaneous/SC1005.json
output : json file name with / without extension
*/
std::string FilesHandlingModel::GetJsonFileName(const std::string& jsonFileName, const std::string& delimeter)
{
    std::string fileName = "";
    std::vector<std::string> result;
    boost::split(result, jsonFileName, boost::is_any_of(delimeter));
    // If SC1005.json file received as input, then after spliting the string size will be == 2,
    // then return filename without ext i.e. SC1005
    if(2 == result.size())
    {
        fileName = result.at(0);
    }
    else if (result.size() >= 3)
    {
        // If path is received as an input for ex. "/common/Miscellaneous/SC1005.json",
        // then after spliting the string return filename with ext i.e. SC1005.json
        fileName = result.at(result.size()-1);
    }

    LOG_MOD(INFO, logmod)<< "File name after split : " << fileName;
    return fileName;
}

/*
description : This function will create .txt output file in appropriate folder. This file contains correlation id number
input : 1. configuration file name for ex. SCXXX.json
        2. directory path where new correlation id file will get created
output : correlationId output file with .txt extension for ex. SCXXX.txt
*/
void FilesHandlingModel::CreateCorrelationIdTxtFile(const std::string& fileName, const std::string& dirPath)
    {
        LOG_MOD(INFO, logmod)<< "In CreateCorrelationIdTxtFile....";

        std::string filePath = dirPath + "/" + GetJsonFileName(fileName,".") + TXT_EXT;
        std::ofstream correlationIdFileStream(filePath, std::ios_base::out);
        if(correlationIdFileStream.is_open())
        {
            correlationIdFileStream << mCorrelationId << std::endl;
            LOG_MOD(INFO, logmod)<< "CorrelationId file : " << filePath << " is created successfully with CID : " << mCorrelationId;
        }
        else
        {
            LOG_MOD(ERROR, logmod)<< "CorrelationId file : " << filePath << " is not created successfully.";
        }

        correlationIdFileStream.flush();
        correlationIdFileStream.close();
    }

/*
*This function would be triggered on receiving ActivateDataCollection message
*All the files in activeconfig directory would be moved to inactiveconfig directory
*And then the given file is moved to activeconfig directory for activation
*Parameter : file name to be activated in std::string format
*/
void FilesHandlingModel::OnNotifyReceivedActivateDataCollectionMessage(const std::string& fileName)
    {
        // DeActivateConfig is commented to support UDS multiple configurations for now"
		//DeActivateConfig();             //first move all currentely active files to Inactive dir
        ActivateConfig(fileName);       // As, for now there should only be one file present in Active dir
    }

/*
*This function ensures there is always space remaing greater than max threshold
* In case low memory detected less than min threshold, filedeletion would be started
*/
bool FilesHandlingModel::CheckForAvailableSpace()
    {
        boostfs::path dirPath{LOG_DIR};
        boostfs::space_info spinfo = boostfs::space(dirPath);
        LOG_MOD(NOTICE, logmod)<<"Total Space : " << (float)spinfo.capacity/1048576 << " MB";
        LOG_MOD(NOTICE, logmod)<<"Free Space : " << (float)spinfo.free/1048576 << " MB";
        LOG_MOD(NOTICE, logmod)<<"free space in %  : " << (float)(spinfo.free*100)/spinfo.capacity;
        std::function<std::string(int)> getnxtdir{[this](int dirNumber){
            if(dirNumber == LOWLOGDIR){return LOG_LOW_DIR;}
            else if(dirNumber == MIDLOGDIR){return LOG_NORMAL_DIR;}
            else {return LOG_HIGH_DIR;}
        }};
        if(spinfo.free < mMaxThreshold)
            {
                #ifndef GTESTBUILD
                    if(mUploadReady)
                        {
                            std::unique_lock<std::mutex> locker(mMutexFreeUpSpace);
                            LOG_MOD(NOTICE, logmod)<<"Waiting for file to be uplaoded";
                            mConditionVar.wait(locker,[]{return mFileUploadProcessed;});
                            DeleteFilesOnLowSpace(getnxtdir);
                            mLowSpaceDetected = false;
                        }
                     else
                        {
                            DeleteFilesOnLowSpace(getnxtdir);
                            mLowSpaceDetected = false;
                        }
                #else
                    DeleteFilesOnLowSpace(getnxtdir);
                #endif // GTESTBUILD
            }
        else
            {
                return true;
            }
        return false;
    }

/*
*This function deletes the file unless required memory is freed
* File deletion would be stopped if memory is available greater than max threshold
*Parameter : functor object to get the next directory
*/
void FilesHandlingModel::DeleteFilesOnLowSpace(const std::function<std::string(int)>& getnxtdir)
    {
        LOG_MOD(NOTICE, logmod)<<  "Low Space Detected ";
        boostfs::path dirPath{LOG_DIR};
        boostfs::space_info spinfo;
        int dirNumber{LOWLOGDIR};
        std::time_t oldestFileWriteTime;
        bool first;
        boostfs::directory_iterator end_iter;
        mLowSpaceDetected = true;
        for (dirNumber=LOWLOGDIR;dirNumber<=HIGHLOGDIR;dirNumber++)
            {
                boostfs::path log_dir{getnxtdir(dirNumber)};
                do
                    {
                        first = true;
                        for (boostfs::directory_iterator specific_log_dir_itr(log_dir); specific_log_dir_itr != end_iter; ++specific_log_dir_itr)
                            {
                                if(first)
                                    {
                                        oldestFileWriteTime = boostfs::last_write_time(specific_log_dir_itr->path());
                                        first = false;
                                    }
                                else
                                    {
                                        if(boostfs::last_write_time(specific_log_dir_itr->path()) < oldestFileWriteTime)
                                        {oldestFileWriteTime = boostfs::last_write_time(specific_log_dir_itr->path());}
                                    }
                            }
                        try
                            {
                                const boostfs::recursive_directory_iterator end_itor;
                                const auto filetodelete = std::find_if(boostfs::recursive_directory_iterator(log_dir), end_itor,
                                                                    [&oldestFileWriteTime](const boostfs::directory_entry& e) {
                                                                return oldestFileWriteTime == boostfs::last_write_time(e.path());
                                                                });
                                if (filetodelete == end_itor)
                                    {
                                        LOG_MOD(ERROR, logmod)<<  "no file to delete";
                                    }
                                else
                                    {
                                        LOG_MOD(INFO, logmod)<<  "oldest file : " << filetodelete->path().string();
                                        boostfs::remove(filetodelete->path());
                                        mUploadfiles.erase(filetodelete->path().string());
                                        spinfo = boostfs::space(dirPath);
                                        if (spinfo.free > mMaxThreshold)
                                        {
                                            LOG_MOD(NOTICE, logmod)<<  "memory freed succssfully";
                                            return;
                                        }
                                    }
                            }
                        catch(const boostfs::filesystem_error& e)
                            {
                                LOG_MOD(ERROR, logmod)<<  "exception occurred while deleting files : " << e.code().value() << e.code().message();
                            }
                    }while(!boostfs::is_empty(log_dir));
            }
            LOG_MOD(ERROR, logmod)<<  "No memory available : " << spinfo.free << std::endl;
    }

void FilesHandlingModel::InvalidConfigReceived(const std::string& msg)
    {
        LOG_MOD(INFO, logmod)<<  "Verification Msg :" << msg;
    }

/*
*This function is a getter function to get current free space in bytes
*Return type: freespace in bytes
*/
uintmax_t FilesHandlingModel::GetCurrentFreeSpace()
    {
        boostfs::path dirPath{LOG_DIR};
        boostfs::space_info spinfo = boostfs::space(dirPath);
        return spinfo.free;
    }

/*
*This function is a setter function to set minimum threshold in bytes
*Parameter : minimum threshold in bytes
*/
void FilesHandlingModel::SetMinThreshold(uintmax_t MinThr)
    {
        mMinThreshold = MinThr;
    }

/*
*This function is a setter function to set maximum threshold in bytes
*Parameter : maximum threshold in bytes
*/
void FilesHandlingModel::SetMaxThreshold(uintmax_t MaxThr)
    {
        mMaxThreshold = MaxThr;
        LOG_MOD(NOTICE, logmod)<<"Required Space : " << mMaxThreshold << " Bytes";
    }

CloudServicesModel* FilesHandlingModel::GetCloudServicesPtr()
    {
        assert(nullptr != mCloudServicesPtr);
        return mCloudServicesPtr.get();
    }

void FilesHandlingModel::SetNewlyDownloadedJSONConfig(const std::string& fileName)
    {
        mNewDownloadedConfigFile = fileName;
    }

void FilesHandlingModel::RemoveJsonAndZipFromDir(const std::string& directory)
    {
        const boostfs::path dirPath{directory};
        boostfs::directory_iterator end_iter;
            try
            {
                for (boostfs::directory_iterator dir_itr(dirPath); dir_itr != end_iter; ++dir_itr)
                {
                    if (!(boostfs::is_directory(dir_itr->path()) || boostfs::is_empty(dir_itr->path())))
                        {
                            if(".zip" == (dir_itr->path().extension().string()) || JSON_EXT == (dir_itr->path().extension().string()))
                                {
                                    boostfs::remove(dir_itr->path().string());
                                }
                        }
                }
            }
            catch(const boostfs::filesystem_error& e)
                {
                    LOG_MOD(ERROR, logmod)<< "RemoveJsonAndZipFromMiscDir exception occurred while deleting existing configuration files : " << e.code().value() << e.code().message();
                }
    }

bool FilesHandlingModel::IsSuffciceintSpace()
    {
        bool spaceAvailable = true;
        boostfs::path dirPath{LOG_DIR};
        boostfs::space_info spinfo = boostfs::space(dirPath);

    	LOG_MOD(NOTICE, logmod)<<"Total Space : " << spinfo.capacity << " Bytes";
        LOG_MOD(NOTICE, logmod)<<"Free Space : " << spinfo.free << " Bytes";
        LOG_MOD(NOTICE, logmod)<<"free space in %  : " << (float)(spinfo.free*100)/spinfo.capacity;
        LOG_MOD(NOTICE, logmod)<<"Required Space : " << mMaxThreshold << " Bytes";

        if(spinfo.free < mMaxThreshold)
            {
                spaceAvailable = false;
                LOG_MOD(WARNING, logmod)<<"Low Space detected";
            }
            return spaceAvailable;
    }

std::string FilesHandlingModel::GetCorrelationID(const std::string& configID){
	std::string rtnValue;
	std::unordered_map<std::string, std::string>::const_iterator itr = mActiveConfigFilesCorrelationID.find(configID);

	if (itr != mActiveConfigFilesCorrelationID.end()){
		rtnValue = itr->second;
	}
	else{
		rtnValue = "";
	}
	return rtnValue;
}

std::string FilesHandlingModel::GetCorrelationIDFromTxtFile(const std::string& path){
	std::ifstream ifs(path, std::ifstream::in);
	std::string rtnValue;

	std::getline(ifs, rtnValue);
	ifs.close();
	return rtnValue;
}

std::vector<std::string> FilesHandlingModel::GetMultiConfigs()
    {
        boostfs::path source_directory{ACTIVE_CONFIG_DIR};
        try
            {
                boostfs::directory_iterator end_iter;
                for (boostfs::directory_iterator dir_itr(source_directory); dir_itr != end_iter; ++dir_itr)
                    {
                        if (!(boostfs::is_directory(dir_itr->path()) || boostfs::is_empty(dir_itr->path())))
                            {
                        		if (JSON_EXT == (dir_itr->path().extension().string())){
                        			mActiveConfigFiles.push_back(dir_itr->path().string());
                        		}
                        		else if (TXT_EXT  == (dir_itr->path().extension().string())){
                        			mActiveConfigFilesCorrelationID.insert(std::pair<std::string, std::string>(dir_itr->path().filename().replace_extension("").string(), GetCorrelationIDFromTxtFile(dir_itr->path().string())));
                        		}
                            }
                    }
             }
        catch(const boostfs::filesystem_error& e)
            {
                LOG_MOD(ERROR, logmod)<<  "exception occurred while getting configuration file from active directory: " << e.code().value() << e.code().message();
            }

        return mActiveConfigFiles;
    }

void FilesHandlingModel::ResetConfig()
{
    boostfs::path source_directory{ACTIVE_CONFIG_DIR};
    try
    {
        boostfs::directory_iterator end_iter;
        for(boostfs::directory_iterator dir_itr(source_directory); dir_itr != end_iter; ++dir_itr)
        {
            boostfs::remove(dir_itr->path());
        }

        boostfs::copy_file(GetConfigFilePath(),(ACTIVE_CONFIG_DIR + "/" + CONFIGURATION_FILE_NAME ),boostfs::copy_option::overwrite_if_exists);
    }
    catch(const boostfs::filesystem_error& e)
    {
        LOG_MOD(ERROR, logmod)<<  "exception occured while resetting configuration " << e.code().value() << e.code().message();
    }
}
