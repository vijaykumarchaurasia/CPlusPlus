#include <ecu/logging.h>
#include "AppManager.h"
#include "DataAccessModel.h"
#include "EventsManagerModel.h"
#include "SimpleEventModelEvDynamic.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.SimpleEventModelEvDynamic");
    }
using namespace DaqApp;

SimpleEventModelEvDynamic::SimpleEventModelEvDynamic(EventConfigMessage passedCfg, EventsManagerModel *passed_ptr, AppManager* passed_app_manger_ptr):
mAppManagerHandlePtr(passed_app_manger_ptr),
mEventsManagerHandlerPtr(passed_ptr),
mSource(passedCfg.Source),
mOperator(passedCfg.Operator),
mSecondArg(passedCfg.Threshold),
mConfigId(passedCfg.ConfigID)
    {
        mEventID = passedCfg.EventId;
        LOG_MOD(NOTICE, logmod)<<"Creation:"<<mEventID;
        mIsActive = false;
        SetOperatorCallBackIndex();
        mEventsManagerHandlerPtr->AddSignal(mEventID);
    }

SimpleEventModelEvDynamic::~SimpleEventModelEvDynamic()
    {
        LOG_MOD(NOTICE, logmod)<<"Destruction: EVDynamic";
    }

void SimpleEventModelEvDynamic::SetOperatorCallBackIndex()
    {
        if (mOperator == "==")
            {
                mCallBackIndex = 0;
            }
        else if (mOperator == "!=")
            {
                mCallBackIndex = 1;
            }
        else if (mOperator == ">")
            {
                mCallBackIndex = 2;
            }
        else if (mOperator == ">=")
            {
                mCallBackIndex = 3;
            }
        else if (mOperator == "<")
            {
                mCallBackIndex = 4;
            }
        else if (mOperator == "<=")
            {
                mCallBackIndex = 5;
            }
        else
            {
                LOG_MOD(ERROR, logmod)<<"Operator "<< mOperator<<" NOT supported for this J1939 DynamicEvent  "<< mEventID <<std::endl;
                throw std::invalid_argument("Operator NOT supported " + mOperator);
            }
    }

bool SimpleEventModelEvDynamic::IsEqual()
    {
        return mFirstArg == mSecondArg;
    }

bool SimpleEventModelEvDynamic::IsNotEqual()
    {
        return mFirstArg != mSecondArg;
    }

bool SimpleEventModelEvDynamic::IsLargerThan()
    {
        return mFirstArg > mSecondArg;
    }

bool SimpleEventModelEvDynamic::IsLargerThanOrEqualTo()
    {
        return mFirstArg >= mSecondArg;
    }

bool SimpleEventModelEvDynamic::IsLessThan()
{
    return mFirstArg < mSecondArg;
}

bool SimpleEventModelEvDynamic::IsLessThanOrEqualTo()
    {
        return mFirstArg <= mSecondArg;
    }

void SimpleEventModelEvDynamic::Evaluate()
    {
        LOG_MOD(DEBUG, logmod)<<"J1939 DynamicEvent evaluating, current state is"<< mIsActive<<std::endl;
        mFirstArg = mAppManagerHandlePtr->GetDataAccessModel()->Read(std::stoi(mSource),Protocol::J1939Proto,mConfigId);
        if ((!mIsActive) && ((this->*mCallBacks[mCallBackIndex])()))
            {
                mEventsManagerHandlerPtr->EmitSignal(mEventID);
                mIsActive = true;
                LOG_MOD(NOTICE, logmod)<<"J1939 DynamicEvent emitted for signal "<< mSource <<" @ "<<mFirstArg<<std::endl;
            }
        else if ((mIsActive) && (!(this->*mCallBacks[mCallBackIndex])()))
            {
                mIsActive = false;
            }
    }
