#include <fstream>
#include <sstream>
#include <ecu/logging.h>
#include "TranslatorModel.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.TranslatorModel");
    }
using namespace DaqApp;

TranslatorModel::TranslatorModel(FilesHandlingModel* passed):
mFilesHandlingModelPtr(passed)
    {
        LOG_MOD(NOTICE, logmod)<<"Creation: TranslatorModel";
    }

void TranslatorModel::SetUpTranslatorModel()
    {
        if (mFilesHandlingModelPtr->GetJ1939TopicListFilePath() == "")
            {
                LOG_MOD(ERROR, logmod)<< "TranslatorModel :: Failed to obtain Topic List File";
            }
        else
            {
                ReadMappedSPNDataFromCSV(mFilesHandlingModelPtr->GetJ1939TopicListFilePath());
            }
    }

bool TranslatorModel::ReadMappedSPNDataFromCSV(const std::string& CSVFilePath)
    {
        bool bReturn = false;
        try
            {
                std::ifstream file(CSVFilePath);
                file.exceptions ( std::ifstream::failbit | std::ifstream::badbit );
                std::string line = ".";
                int row = 0;
                std::string word;
                std::stringstream iss;
                std::vector<std::string> strRow;
                while ( getline(file, line) )
                    {
                        iss << line;
                        struct J1939ConfigMessage obj;
                        // Read the Data from the file as String Vector
                        strRow.clear();
                        while ( getline(iss, word, ',') )
                            {
                                strRow.push_back(word);
                            }
                        if(strRow.size() > 1 && row > 0)
                            {

                                obj.Spn             = strRow.at(0);
                                obj.Pgn             = strRow.at(1);
                                obj.SourceAddress   = strRow.at(2);
                                obj.Topic           = strRow.at(3);
                                obj.Signal          = strRow.at(4);
                                if( "Yes" == strRow.at(5) )
                                    {
                                        obj.IsCyclic = true;
                                    }
                                else
                                    {
                                        obj.IsCyclic = false;
                                    }
                                mSpnMap.insert(std::pair<std::string, DaqApp::J1939ConfigMessage>(obj.Spn,J1939ConfigMessage(obj.Topic,obj.Signal,obj.Spn,obj.Pgn,obj.SourceAddress,obj.IsCyclic)));
                            }
                        iss.clear();
                        row++;
                    }
                // Close the File
                file.close();
                bReturn = true;
            }
        catch(const std::exception& exe)
            {
                LOG_MOD(ERROR, logmod)<< "TranslatorModel :: " << exe.what() << std::endl;
            };
        return bReturn;
    }

bool TranslatorModel::Translate(std::vector<J1939ConfigMessage>* configList)
    {
        bool retVal = true;
        for(uint16_t i = 0; i < (*configList).size(); i ++)
            {
                // Finds a range containing all elements whose key is k.
                // pair<iterator, iterator> equal_range(const key_type& k)
                auto its = mSpnMap.equal_range(configList->at(i).Spn);
                for (auto it = its.first; it != its.second; ++it)
                    {
                        if(it->second.Spn == configList->at(i).Spn && ((it->second.SourceAddress == configList->at(i).SourceAddress) || it->second.SourceAddress == "*" ))
                            {
                                configList->at(i).Pgn = it->second.Pgn;
                                configList->at(i).Topic = it->second.Topic;
                                configList->at(i).Signal = it->second.Signal;
                                configList->at(i).IsCyclic = it->second.IsCyclic;
                                break;
                            }
                    }
                  if(mSpnMap.find((*configList).at(i).Spn) == mSpnMap.end())
                        {
                            //key not found
                            LOG_MOD(WARNING, logmod)<<"TranslatorModel, SPN "<< configList->at(i).Spn
                                                       <<" not found in PGN Def CSV file";
                            retVal = false;
                        }
            }
        return retVal;
    }

TranslatorModel::~TranslatorModel()
    {
        LOG_MOD(NOTICE, logmod)<<"Destruction: TranslatorModel";
    }
