#include <ecu/logging.h>
#include "AppManager.h"
#include "DataAccessModel.h"
#include "StaticDataSampler.h"
#include "ClientManagerModel.h"
#include "ConfigurationManagerModel.h"
#include "Utils.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.StaticDataSampler");
    }
using namespace DaqApp;

StaticDataSampler::StaticDataSampler(AppManager* ipAppMgr , ITransportClient_ptr ipClient):
mAppManagerPtr(ipAppMgr),
mDataAccessModelPtr(ipAppMgr->GetDataAccessModel()),
mSysParamsClientPtr(ipAppMgr->GetClientManagerModel()->getSystemParameterClient()),
mVarClientPtr(ecu::lapi::var::create_var_client(ipClient)),
mSdkCallBackPtr(new CallBackHelper(this)),
mTransportClientPtr(ipClient),
mPgnReqClientPtr(ecu::lapi::diag::create_pgn_request_client(ipClient)),
mTimeUtilitiesHandlePtr(ipAppMgr->GetTimeUtilities())
    {
        LOG_MOD(NOTICE, logmod)<<"Creation: StaticDataSampler";

        WriteDeviceParametersFromFile();

        mJ1939RequesterModel.emplace_back(std::make_unique<J1939RequesterModel>
           (mPgnReqClientPtr,mTransportClientPtr,65259,mECMAddr,mTimeUtilitiesHandlePtr,true));
        mTransportClientPtr->subscribe(mTopicCi,0,mSdkCallBackPtr);

		WriteSystemParameterValuesInMisc();

		mJ1939RequesterModel.emplace_back(std::make_unique<J1939RequesterModel>
			(mPgnReqClientPtr, mTransportClientPtr, mDM20PGN, mGlobalRqstAddr, mTimeUtilitiesHandlePtr, true));
        mTransportClientPtr->subscribe(mTopicDM20, 0, mSdkCallBackPtr);
        mDataAccessModelPtr->WriteMisc("IGNCounter", ""); 	//DM20 Ignition Cycle Counter
    }

StaticDataSampler::~StaticDataSampler()
    {
        LOG_MOD(NOTICE, logmod)<<"Destruction: StaticDataSampler";
        mJ1939RequesterModel.clear();
    }
void StaticDataSampler::message( const std::string& topic, const Message& message)
    {
        SignalAdapter::UnpackResult unpack = SignalAdapter::instance().unpack(topic, message);
		SignalGroup receivedGroup_ = unpack.take_val();

		if( topic.compare(mTopicDM20) == 0 ){
			WriteDM20ValueInMisc(receivedGroup_);
		}
		else if ( topic.compare(mTopicCi) == 0 )
            {
				const Signal *extracted_source_addr = receivedGroup_.signal(mSourceAddrName);
				if (nullptr == extracted_source_addr){
					LOG_MOD(ERROR, logmod)<< "Received CI response address is empty";
					return;
				}

				if ( *(extracted_source_addr->data().begin()) == mECMAddr){		//Check if the response is from ECM, else ignore
					LOG_MOD(NOTICE, logmod)<< "Received CI From Engine";
					const Signal *extracted_data = receivedGroup_.signal(mSignalData);

					if (nullptr == extracted_data){
						LOG_MOD(ERROR, logmod)<< "Received CI response data is empty";
						return;
					}

	                uint8_t whichDelimiterReached = 0;
	                std::vector<uint8_t> data = extracted_data->data();
	                std::stringstream ecuSerialNumber;
	                std::vector<uint8_t>::iterator itr = data.begin();
	                ecuSerialNumber.clear();

					while (itr != data.end())
						{
							if(*itr == 0x2A && whichDelimiterReached==3) break;
							if(whichDelimiterReached==2 && *itr != 0x2A) ecuSerialNumber << std::hex << *itr;
							if(*itr == 0x2A) whichDelimiterReached++;
							itr = itr+1;
						}

	                LOG_MOD(INFO, logmod)<<"StaticDataSampler: message received for 65259-588: "<<ecuSerialNumber.str();
	                if ( (!ecuSerialNumber.str().empty())
	                		&& (mDataAccessModelPtr->ReadMisc(mESNMiscID).compare(ecuSerialNumber.str()) != 0) ){

	                	LOG_MOD(WARNING, logmod)<< "Acquired ESN doesn't match with existing.";
	                	mDataAccessModelPtr->WriteMisc(mESNMiscID, ecuSerialNumber.str());
	                	WriteDeviceParametersToFile();
	                }
	                mTransportClientPtr->unsubscribe(mTopicCi, mSdkCallBackPtr);
	                LOG_MOD(NOTICE, logmod)<< "Unsubscribing CI PGN 65259";
				}
             }
        else if ( topic.compare(mTopicVi) == 0 )
            {
                const Signal *extracted = receivedGroup_.signal(mSignalVi);
                if (nullptr != extracted)
                    {
                        std::vector<uint8_t> data = extracted->data();
                        std::stringstream vinNumber;
                        std::vector<uint8_t>::iterator itr = data.begin();
                        while (itr != data.end())
                            {
                                if (*itr == 0x2A)   break;
                                vinNumber << std::hex << *itr;
                                itr = itr+1;
                            }

                        LOG_MOD(INFO, logmod)<<"StaticDataSampler: message received for 65260-237: "<<vinNumber.str();
                        if ( (!vinNumber.str().empty())
                        		&& (mDataAccessModelPtr->ReadMisc(mVINMiscID).compare(vinNumber.str()) != 0) ){

                        	LOG_MOD(WARNING, logmod)<< "Acquired VIN doesn't match with existing." << mDataAccessModelPtr->ReadMisc(mVINMiscID) << vinNumber.str() <<"Done";
                        	mDataAccessModelPtr->WriteMisc(mVINMiscID, vinNumber.str());
                        	WriteDeviceParametersToFile();
                        }

                        mTransportClientPtr->unsubscribe(mTopicVi, mSdkCallBackPtr);
                        LOG_MOD(NOTICE, logmod)<< "Unsubscribing VI PGN 65259";

                    }
            }
    }

void StaticDataSampler::WriteSystemParameterValuesInMisc()
    {
        LOG_MOD(NOTICE, logmod) << "Invoked WriteSystemParameterValuesInMisc";

        uint8_t counter = 0;

        //Retrieve N2 Device ID(8207). If failed, retry for 30 seconds
        do{
			ecu::lapi::var::SysParamsClient::GetResult sysParamTeleID = mSysParamsClientPtr->get(8207);
			if(sysParamTeleID.ok())
			{
				ecu::lapi::var::SysParamsClient::ParamValue val = sysParamTeleID.val();
				LOG_MOD(NOTICE, logmod)<<"Acquired N2 Device ID: " << val.content();

				//Check the Device ID is not empty and doesn't match with existing
				if( (!val.content().empty()) ){
					if ( (mDataAccessModelPtr->ReadMisc(mN2DevIDMiscID).compare(val.content()) != 0) ){

						LOG_MOD(WARNING, logmod)<< "Acquired N2 Device ID doens't match with existing.";
						mDataAccessModelPtr->WriteMisc(mN2DevIDMiscID,val.content());
						WriteDeviceParametersToFile();		//Save new Device ID to file for next key cycle
					}
					break;
				}
			}
			else
			{
				LOG_MOD(WARNING, logmod)<<"Failed to acquire N2 Device ID. Retrying in 1 second";
			}
			std::this_thread::sleep_for(std::chrono::milliseconds(1000));
			counter++;

            if (counter >= 30){
            	LOG_MOD(ERROR, logmod)<< "Failed to acquire N2 Device ID for 30 seconds";
                if (mDataAccessModelPtr->ReadMisc(mN2DevIDMiscID).empty()){
                	mDataAccessModelPtr->WriteMisc(mN2DevIDMiscID,"000000-0000");	//If Device ID is not stored in file, use dummy 000 values
                }
            }
        }while(counter < 30);

        //Check If ESN is acquired. If not, wait for max 30 seconds
        counter = 0;
        while(mDataAccessModelPtr->ReadMisc(mESNMiscID).empty())
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(250));
            counter++;
            if(counter > 120)
            {
                LOG_MOD(WARNING, logmod)<<"Failed to acquire ESN, waited for almost 30 second";
                break;
            }
        }

		//CAcquire VIN. Retry for 30 seconds if failed
        mJ1939RequesterModel.emplace_back(std::make_unique<J1939RequesterModel>
                    (mPgnReqClientPtr,mTransportClientPtr,65260,mECMAddr,mTimeUtilitiesHandlePtr,true));
        mTransportClientPtr->subscribe(mTopicVi,0,mSdkCallBackPtr);
        counter = 0;
        while(mDataAccessModelPtr->ReadMisc(mVINMiscID).empty())
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(250));
            counter++;
            if(counter > 120)
            {
                LOG_MOD(WARNING, logmod)<<"Failed to acquire VIN, waited for almost 30 second";
                break;
            }
        }
    }

void StaticDataSampler::WriteDM20ValueInMisc(const SignalGroup& dm20){

	const Signal *extracted_source_addr = dm20.signal(mSourceAddrName);
	const Signal *extracted_data = dm20.signal(mSignalData);
	if ( (nullptr == extracted_source_addr) || (nullptr == extracted_data) ){
		LOG_MOD(ERROR, logmod)<< "Received DM20 response is empty";
		return;
	}

	if ( *(extracted_source_addr->data().begin()) == mECMAddr){		//Check if the response is from ECM, else ignore
	    std::vector<uint8_t> data = extracted_data->data();
	    std::stringstream ignCounter;

	    if ( data.size() > 2){
	    	uint16_t ign_counter = (((uint16_t)(*(data.begin()+1))) << 8) | ((uint16_t)*data.begin());
	    	ignCounter << ign_counter;

	        mDataAccessModelPtr->WriteMisc("IGNCounter", ignCounter.str());
	        LOG_MOD(INFO, logmod)<<"StaticDataSampler: DM20 IGN Counter Received "<<ignCounter.str();

	        mTransportClientPtr->unsubscribe(mTopicDM20, mSdkCallBackPtr);
	        LOG_MOD(NOTICE, logmod)<< "Unsubscribing DM20";
	    }
	}
}

//Take Device Parameters from file and write them into Misc
void StaticDataSampler::WriteDeviceParametersFromFile(void){

	std::ifstream ifs(mDeviceParamFileName, std::ifstream::in);
	std::string line;

	if(ifs.is_open()){
		// Go through each line until end of file.
		while(std::getline(ifs, line)){
			std::stringstream line_stream(line);	// Convert string line into input stream

			std::string param_name;
			if (std::getline(line_stream, param_name, '=')){		// get line content until '=' encountered

				std::string value_str;
				std::getline(line_stream, value_str);

				if ( !value_str.empty() ){

					if( param_name == mESNFileID ){
						LOG_MOD(INFO, logmod)<< "ESN Saved in Previous Key Cycle: " << value_str;
						mDataAccessModelPtr->WriteMisc(mESNMiscID, value_str);
					}
					else if ( param_name == mVINFileID ){
						LOG_MOD(INFO, logmod)<< "VIN Saved in Previous Key Cycle: " << value_str;
						mDataAccessModelPtr->WriteMisc(mVINMiscID, value_str);
					}
					else if ( param_name == mN2DevIDFileID ){
						LOG_MOD(INFO, logmod)<< "N2 DeviceID Saved in Previous Key Cycle: " << value_str;
						mDataAccessModelPtr->WriteMisc(mN2DevIDMiscID, value_str);
					}
				}
			}
		}
	}
	else{
		LOG_MOD(INFO, logmod)<< "Device Parameter file is not created or opened";
	}

	ifs.close();
}

void StaticDataSampler::WriteDeviceParametersToFile(void){

    std::ofstream deviceParamFileStream(mDeviceParamFileName, std::ios_base::out | std::ofstream::trunc);	//Delete previous content

    if(deviceParamFileStream.is_open())
    {
    	deviceParamFileStream << mESNFileID << "=" << mDataAccessModelPtr->ReadMisc(mESNMiscID) << std::endl;
    	deviceParamFileStream << mVINFileID << "=" << mDataAccessModelPtr->ReadMisc(mVINMiscID) << std::endl;
    	deviceParamFileStream << mN2DevIDFileID << "=" << mDataAccessModelPtr->ReadMisc(mN2DevIDMiscID) << std::endl;

        LOG_MOD(INFO, logmod)<< "Device Parameter file : " << mDeviceParamFileName << " is edited successfully.";
    }
    else
    {
        LOG_MOD(ERROR, logmod)<< "Device ID file : " << mDeviceParamFileName << " Failed to edit.";
    }

    deviceParamFileStream.flush();
    deviceParamFileStream.close();
}




