#include "ValidationModel.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.ValidationModel");
    }
using namespace DaqApp;

ValidationModel::ValidationModel()
    {
        LOG_MOD(NOTICE, logmod)<<"Creation: ValidationModel";
    }

ValidationModel::~ValidationModel()
    {
        LOG_MOD(NOTICE, logmod)<<"Destruction: ValidationModel";
    }

/**
 * This function is used to validate defineDataContentSpec configuration.
 *
 */
bool ValidationModel::IsValidDataContentSpec(const Json::Value& data_content_spec)
    {
        bool is_valid = false;
        protocol = "InvalidProtocol";
        if(data_content_spec.size()>0)
        {
            Json::Value content_spec = data_content_spec[0];
            if(content_spec.isMember("dataContentSpecDefinition"))
            {
                Json::Value spec_def = content_spec["dataContentSpecDefinition"];
                if(spec_def.isMember("allSampleParameters"))
                {
                    Json::Value all_sample_param = spec_def["allSampleParameters"];
                    if(all_sample_param.isMember("equipmentParameters"))
                    {
                        Json::Value equip_param = all_sample_param["equipmentParameters"];
                        if(equip_param.size()>0)
                        {
                            Json::Value equipment = equip_param[0];
                            protocol = equipment["protocol"].asString();
                            if((protocol == "J1939") || (protocol == "XCP") ||
                               (protocol == "TripData") || (protocol == "EAL"))
                               {
                                 is_valid = true;
                               }
                               else
                               {
                                 LOG_MOD(NOTICE, logmod) << "ValidationModel: defineDataContentSpec doesn't have valid protocol";
                                 is_valid = false;
                               }
                            //Check duplicate SPNS
                            for ( unsigned int array_index = 0; array_index < equip_param.size(); ++array_index )
                                {
                                    Json::Value equip_obj = equip_param[array_index];
                                    std::string protocol = equip_obj["protocol"].asString().c_str();
                                    if(protocol=="J1939")
                                    {   //Check duplicate SPNS for J1939 protocol
                                        is_valid = IsValidJ1939Config(equip_obj);
                                        if(!is_valid)
                                        {
                                            break;
                                        }
                                    }
                                }
                        }
                    }
                }
            }
        }
        return is_valid;
    }

bool ValidationModel::IsValidJ1939Config(const Json::Value& json_j1939_config)
{
        Json::Value param_array = json_j1939_config["parameters"];
        Json::Value deviceIds_array = json_j1939_config["deviceIds"];
        std::set<std::string> sourceAddress;
        std::set<std::string> SPN;
        if(!param_array.size())
            {
                setConfigReasonCodeDescription(std::make_pair("501", "dataContentSpecDefinition J1939: Missing SPN entry"));
                return false;
            }
        for ( unsigned int index = 0; index < param_array.size(); ++index )
            {
                std::string parameter = param_array[index].asString();
                if(parameter.empty())
                    {
                        setConfigReasonCodeDescription(std::make_pair("501", "dataContentSpecDefinition J1939: Missing SPN entry"));
                        return false;
                    }
                else if(!SPN.insert(parameter).second)
                    {
                        setConfigReasonCodeDescription(std::make_pair("501","dataContentSpecDefinition J1939: Duplicate entry for SPN "+parameter));
                        return false;
                    }
                if(!deviceIds_array.size())
                    {
                        setConfigReasonCodeDescription(std::make_pair("503",
                        "dataContentSpecDefinition J1939: Missing source address entry against SPN "+ parameter));
                        return false;
                    }
            }
            for ( unsigned int indexId = 0; indexId < deviceIds_array.size(); ++indexId )
                {
                    std::string deviceId = deviceIds_array[indexId].asString();
                    if(deviceId.empty())
                        {
                            setConfigReasonCodeDescription(std::make_pair("503",
                            "dataContentSpecDefinition J1939: Empty source address entry"));
                            return false;
                        }
                    if( !sourceAddress.insert(deviceId).second)
                        {
                            setConfigReasonCodeDescription(std::make_pair("501","dataContentSpecDefinition J1939: Duplicate source address entry "
                            + deviceId));
                            return false;
                        }
                }
            return true;
}
/**
 *  This function is used to validate the data logger configuration.
 */
bool ValidationModel::IsValidDataSamplingSpec(const Json::Value& data_sampling_spec_array)
{
    if(protocol!="TripData")
    {
        if(data_sampling_spec_array.size()>0)
        {
            Json::Value data_sampling_spec = data_sampling_spec_array[0];
            if(data_sampling_spec.isMember("dataSamplingSpecDefinition"))
            {
                Json::Value sampling_spec_def = data_sampling_spec["dataSamplingSpecDefinition"];

                // Validation for both triggerType periodic & eventDriven
                std::string sampling_period = sampling_spec_def["samplingPeriod"].asString();
                if(DaqApp::utils::IsNumber(sampling_period))
                {
                    float sampling_rate = std::stof(sampling_period);
                    if(sampling_rate<=0)
                    {
                        LOG_MOD(WARNING, logmod) << "ValidationModel: Sampling rate cannot be 0 or less value!" ;
                        return false;
                    }
                }
                else
                {
                    LOG_MOD(WARNING, logmod) << "ValidationModel: Sampling rate is not a numeric value!" ;
                    return false;
                }
                unsigned int  MaxTransmitPeriod = 0;
                unsigned int  MaxSetSize = 0;
                unsigned int  PreBufferSize = 0;
                unsigned int  PostBufferSize = 0;
                std::string StartingEventId;
                std::string EndingEventId;
                if(sampling_spec_def.isMember("maxTransmitPeriod"))
                {
                    MaxTransmitPeriod = std::stoi(sampling_spec_def["maxTransmitPeriod"].asString());
                }
                if(sampling_spec_def.isMember("maxSetSize"))
                {
                    MaxSetSize = std::stoi(sampling_spec_def["maxSetSize"].asString());
                }
                if(sampling_spec_def.isMember("preEventSamplingDuration"))
                {
                    PreBufferSize  = std::stoi(sampling_spec_def["preEventSamplingDuration"].asString());
                }
                if(sampling_spec_def.isMember("postEventSamplingDuration"))
                {
                    PostBufferSize = std::stoi(sampling_spec_def["postEventSamplingDuration"].asString());
                }
                if(sampling_spec_def.isMember("startingEventId"))
                {
                    StartingEventId  = sampling_spec_def["startingEventId"].asString() ;
                }
                if(sampling_spec_def.isMember("endingEventId"))
                {
                    EndingEventId    = sampling_spec_def["endingEventId"].asString() ;
                }
                // Validation for periodic triggerType
                if(sampling_spec_def["triggerType"].asString() == "periodic")
                    {
                        if(MaxTransmitPeriod == MaxSetSize)
                        {
                            LOG_MOD(WARNING, logmod) << "ValidationModel: MaxTransmitPeriod and MaxSetSize cannot be equal !" ;
                            setConfigReasonCodeDescription(std::make_pair("501","MaxTransmitPeriod and MaxSetSize cannot be equal!"));
                            return false;
                        }
                        else if(PreBufferSize or PostBufferSize)
                        {
                            LOG_MOD(WARNING, logmod) << "ValidationModel: Can't use pre/post buffers with Periodic sampling settings !" ;
                            setConfigReasonCodeDescription(std::make_pair("501","Can't use pre/post buffers with Periodic sampling settings!"));
                            return false;
                        }
                        else if(StartingEventId.size() or EndingEventId.size())
                        {
                            LOG_MOD(WARNING, logmod) << "ValidationModel: Periodic sampling settings can't have events!" ;
                            setConfigReasonCodeDescription(std::make_pair("501","Periodic sampling settings can't have events!"));
                            return false;
                        }
                    }

                    // Validation for eventDriven triggertype
                else if (sampling_spec_def["triggerType"].asString() == "eventDriven")
                    {
                        unsigned int BufferThreshold = std::min(MaxSetSize,MaxTransmitPeriod);
                        if(StartingEventId.empty())
                            {
                                LOG_MOD(WARNING, logmod) << "ValidationModel: Can't use Event driven sampling without a starting event" ;
                                setConfigReasonCodeDescription(std::make_pair("501","Can't use Event driven sampling without a starting event!"));
                                return false;
                            }
                        else if(StartingEventId == EndingEventId)
                            {
                                LOG_MOD(WARNING, logmod) << "ValidationModel: Starting and ending event cannot be the same!" ;
                                setConfigReasonCodeDescription(std::make_pair("501","Starting and ending event cannot be the same!"));
                                return false;
                            }
                        else if(PostBufferSize and EndingEventId.empty())
                            {
                                LOG_MOD(WARNING, logmod) << "ValidationModel: Can't use post buffers without ending event" ;
                                setConfigReasonCodeDescription(std::make_pair("501","Can't use post buffers without ending event!"));
                                return false;
                            }
                        else if(PreBufferSize > BufferThreshold )
                            {
                                LOG_MOD(WARNING, logmod) << "ValidationModel: PreBuffer can't be greater than max set size or max transmit period" ;
                                setConfigReasonCodeDescription(std::make_pair("501","PreBuffer can't be greater than max set size or max transmit period!"));
                                return false;
                            }
                        else if(PreBufferSize and StartingEventId.empty())
                            {
                                LOG_MOD(WARNING, logmod) << "ValidationModel: Can't use pre buffers without starting event" ;
                                setConfigReasonCodeDescription(std::make_pair("501","Can't use pre buffers without starting event!"));
                                return false;
                            }
                        else if(MaxSetSize == MaxTransmitPeriod)
                            {
                                LOG_MOD(WARNING, logmod) << "ValidationModel: MaxTransmitPeriod and MaxSetSize cannot be equal !" ;
                                setConfigReasonCodeDescription(std::make_pair("501","MaxTransmitPeriod and MaxSetSize cannot be equal !"));
                                return false;
                            }
                    }
                    else
                    {
                        LOG_MOD(WARNING, logmod) << "ValidationModel: Invalid triggerType" ;
                        setConfigReasonCodeDescription(std::make_pair("501","Invalid triggerType in the configuration file !"));
                        return false;
                    }

            }
            else
            {
                LOG_MOD(WARNING, logmod) << "ValidationModel: Configuration file doesn't exist dataSamplingSpecDefinition" ;
                setConfigReasonCodeDescription(std::make_pair("501","Configuration file doesn't exist dataSamplingSpecDefinition !"));
                return false;
            }
        }
        else
        {
            LOG_MOD(WARNING, logmod) << "ValidationModel: defineDataSamplingSpec details are missing!" ;
            return false;
        }
    }
    return true;
}

/**
 *  This function is used to validate the json config command.
 */
bool ValidationModel::IsValidConfigCommand(const Json::Value& command_config)
{
    bool is_valid_command  = true;
    Json::Value command = command_config[0];
    if(command.isMember("dataSamplingConfigIds"))
    {
        Json::Value samplingIds = command["dataSamplingConfigIds"];
        if(samplingIds.size()==0)
        {
             is_valid_command = false;
             LOG_MOD(WARNING, logmod) << "Command doesn't exist dataSamplingConfigIds ";
        }
    }
    else
    {
        is_valid_command = false;
    }

    return is_valid_command;
}

/**
 *  This function is used to validate the mandatory blocks of the json configuration.
 */
bool ValidationModel::IsValidConfig(const Json::Value& root)
    {
        protocol = "InvalidProtocol";
        mReasonCode_Reason = {};
        if(root == root.null)
        {
            LOG_MOD(WARNING, logmod) << "ValidationModel : Configuration file is not Json or Empty" ;
            return false;
        }

        // Atleast one json block is mandatory
        if(!(root.isMember("defineDataContentSpec") || root.isMember("defineDataSamplingSpec") || root.isMember("activateDataCollection") ||
           root.isMember("deactivateDataCollection") || root.isMember("forgetDefinition")))
           {
                LOG_MOD(WARNING, logmod) << "ValidationModel : Configuration file doesn't exist mandatory attributes!" ;
                return false;
           }

        // Validate Data Content Spec
        if(root.isMember("defineDataContentSpec"))
        {
            if(!IsValidDataContentSpec(root["defineDataContentSpec"]))
            {
                LOG_MOD(WARNING, logmod) << "ValidationModel : Configuration file doesn't exist mandatory attributes for defineDataContentSpec " ;
                return false;
            }
        }

         // Validate DataLogger
        if(root.isMember("defineDataSamplingSpec"))
        {
            if(!IsValidDataSamplingSpec(root["defineDataSamplingSpec"]))
            {
                LOG_MOD(WARNING, logmod) << "ValidationModel : Configuration file doesn't have valid attribute's value for defineDataSamplingSpec " ;
                return false;
            }
        }

        if(root.isMember("activateDataCollection"))
        {
            if(!IsValidConfigCommand(root["activateDataCollection"]))
            {
                LOG_MOD(WARNING, logmod) << "ValidationModel : Configuration file doesn't exist mandatory attributes for activateDataCollection " ;
                return false;
            }
        }

        if(root.isMember("deactivateDataCollection"))
        {
            if(!IsValidConfigCommand(root["deactivateDataCollection"]))
            {
                LOG_MOD(WARNING, logmod) << "ValidationModel : Configuration file doesn't exist mandatory attributes for deactivateDataCollection " ;
                return false;
            }
        }

        if(root.isMember("defineSimpleEvent"))
        {
            if(!IsValidSimpleEventConfig(root["defineSimpleEvent"]))
            {
                LOG_MOD(WARNING, logmod) << "ValidationModel : Configuration file doesn't exist mandatory attributes for defineSimpleEvent " ;
                return false;
            }
        }
        return true;
    }

bool ValidationModel::IsValidSimpleEventConfig(const Json::Value& event_config_array)
{
    std::set<std::string> setEventId;
    for(unsigned int index = 0; index!=event_config_array.size(); index++)
        {
            Json::Value event_config = event_config_array[index];
            std::string event_id     = event_config["eventId"].asString();
            if(event_id.empty())
                {
                    setConfigReasonCodeDescription(std::make_pair("501", "defineSimpleEvent: Missing event entry"));
                    return false;
                }
            if(!setEventId.insert(event_id).second)
                {
                    setConfigReasonCodeDescription(std::make_pair("501", "defineSimpleEvent: Duplicate entry for "+event_id));
                    return false;
                }
            Json::Value event_def = event_config["eventDefinition"];
            if(event_def["eventType"].asString()=="parameterCompare")
                {
                for( Json::Value::const_iterator even_arg = event_def.begin() ; even_arg!= event_def.end() ; ++even_arg )
                    {
                        std::string devId;
                        std::string spn;
                        for( Json::Value::const_iterator event_data = (*even_arg).begin() ; event_data!= (*even_arg).end() ; ++event_data )
                        {
                            Json::Value event_argument = *even_arg;
                            if(event_data.key() == "parameterId")
                            {
                                 spn = event_argument["parameterId"].asString();
                                 if(spn.empty())
                                 {
                                     setConfigReasonCodeDescription(std::make_pair("501",
                                    "dataContentSpecDefinition J1939: Missing SPN entry for event: "+ event_id));
                                     return false;
                                 }
                            }
                            if(event_data.key() == "deviceIds")
                                {
                                    Json::Value deviceIds_array = event_argument["deviceIds"];
                                    if(!deviceIds_array.size())
                                        {
                                            setConfigReasonCodeDescription(std::make_pair("503",
                                            "dataContentSpecDefinition J1939: Missing source address entry for "+event_id));
                                            return false;
                                        }
                                        else
                                        {
                                            devId = deviceIds_array[0].asString();
                                            if(devId.empty())
                                                {
                                                    setConfigReasonCodeDescription(std::make_pair("503",
                                                    "dataContentSpecDefinition J1939: Empty source address entry for "+event_id));
                                                    return false;
                                                }
                                        }
                                }
                        }
                    }
                 }
         }
    return true;
}

std::pair<std::string, std::string>& ValidationModel::getConfigReasonCodeDescription()
    {
        return mReasonCode_Reason;
    }

void ValidationModel::setConfigReasonCodeDescription(const std::pair<std::string, std::string>& passedMap)
    {
        mReasonCode_Reason = passedMap;
    }

