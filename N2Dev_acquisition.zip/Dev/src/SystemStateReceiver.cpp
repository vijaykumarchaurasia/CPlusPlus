#include <ecu/com/messageadapter.h>
#include <ecu/logging.h>
#include <ecu/pb/ecu.pb.h>
#include "AppManager.h"
#include "SystemStateReceiver.h"
#include "SamplerModel.h"
#include "ClientManagerModel.h"
#include "EventsManagerModel.h"
#include "CommonHeader.h"

using namespace DaqApp;
using namespace ecu::lapi::com;
using namespace ecu::lapi::pb;

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.SystemStateReceiver");
    }

SystemStateReceiver::SystemStateReceiver(AppManager* passed):
    mAppManagerPtr(passed),
    mSdkCallBackPtr(new CallBackHelper(this))
    {
        LOG_MOD(NOTICE, logmod)<<"Creation: SystemStateReceiver subscribing for topic= "<<TOPIC_SHUTDOWN_STATUS;
        mAppManagerPtr->GetEventsManagerModel()->AddSignal(PostponableShutDownEvent);
        mAppManagerPtr->GetEventsManagerModel()->AddSignal(NonPostponableShutDownEvent);
    }

SystemStateReceiver::~SystemStateReceiver()
    {
        if(mTransportClientPtr)
            {
                mTransportClientPtr->unsubscribe(TOPIC_SHUTDOWN_STATUS,mSdkCallBackPtr);
            }
        LOG_MOD(NOTICE, logmod)<<"Destruction: SystemStateReceiver";
    }

void SystemStateReceiver::SetupSystemStateReceiver(ecu::lapi::com::ITransportClient_ptr client)
{
    mTransportClientPtr = client;
    if(mTransportClientPtr)
    {
        mTransportClientPtr->subscribe(TOPIC_SHUTDOWN_STATUS, 0, mSdkCallBackPtr);
    }
}

void SystemStateReceiver::message(const std::string &topic, const Message &message)
    {
        if ( topic == TOPIC_SHUTDOWN_STATUS )
            {
                LOG_MOD(NOTICE, logmod) << "Shutdown status changed event "<< topic;
                handleShutdownEvent(message);
            }
        else
            {
                LOG_MOD(WARNING, logmod)<<" Unspecified event reported  ";
            }
    }

void SystemStateReceiver::PostponeShutDownOnce()
    {
        EcuShutdownPostpone postponerq;
        postponerq.set_client_name("DaqApp");
        PbInternalMessageAdapter<EcuShutdownPostpone> adapter;
        auto result = adapter.serialize(postponerq);
        if (result.ok())
            {
                mTransportClientPtr->publish(TOPIC_SHUTDOWN_POSTPONE, result.val());
            }
    }

bool SystemStateReceiver::RequestShutdownPostpone()
    {
        bool res{false};
        if(mShutdownEventType == ShutdownType::POSTPONABLE)
            {
                PostponeShutDownOnce();
                res = true;
            }
        return res;
    }

void SystemStateReceiver::handleShutdownEvent(const Message &message)
    {
        PbInternalMessageAdapter<EcuShutdownStatus> adapter;
        auto result = adapter.deserialize(message);
        if ( result.nok() )
            {
                LOG_MOD(ERROR, logmod) << "Unable to deserialize!";
                return;
            }
        auto status = result.take_val();
        LOG_MOD(NOTICE, logmod) << "Received: " << EcuShutdownStatus_State_Name(status.state());
        switch(status.state())
            {
                case EcuShutdownStatus_State::EcuShutdownStatus_State_UNKNOWN :
                    LOG_MOD(NOTICE, logmod)<<"unknown shutdown event ";
                    mShutdownEventType = ShutdownType::NOTDEFINED;
                    break;

                case EcuShutdownStatus_State::EcuShutdownStatus_State_OPERATING :
                    LOG_MOD(NOTICE, logmod)<<"shutdown event Cancelled ";
                    mShutdownEventType = ShutdownType::NOTDEFINED;
                    break;

                case EcuShutdownStatus_State::EcuShutdownStatus_State_SHUTDOWN_PENDING :
                    LOG_MOD(NOTICE, logmod)<<"shutdown event pending";
					mShutdownEventType = ShutdownType::POSTPONABLE;
                    mAppManagerPtr->GetEventsManagerModel()->EmitSignal(PostponableShutDownEvent);
                    break;

                case EcuShutdownStatus_State::EcuShutdownStatus_State_SHUTDOWN_POSTPONED :
                    LOG_MOD(NOTICE, logmod)<<"shutdown event postponed";
                    break;

                case EcuShutdownStatus_State::EcuShutdownStatus_State_SHUTDOWN_IMMINENT :
                    LOG_MOD(NOTICE, logmod)<<"shutdown event imminent";
                    mShutdownEventType = ShutdownType::NONPOSTPONABLE;
                    mAppManagerPtr->GetEventsManagerModel()->EmitSignal(NonPostponableShutDownEvent);
                    break;

                    default:
                    break;
            }
    }

