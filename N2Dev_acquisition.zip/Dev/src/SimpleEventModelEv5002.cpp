#include <ecu/logging.h>
#include "AppManager.h"
#include "DataAccessModel.h"
#include "EventsManagerModel.h"
#include "SimpleEventModelEv5002.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.SimpleEventModelEv5002");
    }
using namespace DaqApp;

SimpleEventModelEv5002::SimpleEventModelEv5002(EventConfigMessage config_message, EventsManagerModel *passed_ptr, AppManager* passed_app_manger_ptr):
mAppManagerHandlePtr(passed_app_manger_ptr),
mEventsManagerHandlerPtr(passed_ptr),
mConfigMessage(config_message)
    {
        mEventID = ("EV5002");
        LOG_MOD(NOTICE, logmod)<<"Creation:"<<mEventID;
        mIsActive = false;
        mEventsManagerHandlerPtr->AddSignal(mEventID);
    }

SimpleEventModelEv5002::~SimpleEventModelEv5002()
    {
        LOG_MOD(NOTICE, logmod)<<"Destruction: EV5002";
    }

//Pre definedevent 5002 for any active event.
void SimpleEventModelEv5002::Evaluate()
    {
        std::string  dm6_curr_val = mAppManagerHandlePtr->GetDataAccessModel()->Read("pendingFaultCodes",mConfigMessage.ConfigID); //Read DM6 message"emission", using DM27 for now
        if(dm6_curr_val =="spn:0~fmi:0~count:0|")
            {
                LOG_MOD(INFO, logmod)<<"EV5002 Evaluating current status is"<< mIsActive;
                mPrevVal = "spn:0~fmi:0~count:0|";
                mIsActive = false;
            }
        else if((dm6_curr_val != mPrevVal) && dm6_curr_val.size())
            {
                LOG_MOD(NOTICE, logmod)<<"EV5002 Emitted received pendingFaultCodes = "<<dm6_curr_val;
                mEventsManagerHandlerPtr->EmitSignal("EV5002");
                mPrevVal = dm6_curr_val;
                mIsActive = true;
            }
    }
