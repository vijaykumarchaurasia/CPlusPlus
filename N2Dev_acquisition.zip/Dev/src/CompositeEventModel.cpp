#include <ecu/logging.h>
#include "AppManager.h"
#include "DataAccessModel.h"
#include "EventsManagerModel.h"
#include "CompositeEventModel.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.CompositeEventModel");
    }
using namespace DaqApp;

CompositeEventModel::CompositeEventModel(CompositeEventConfig passedConfig, EventsManagerModel *passed_ptr, AppManager* passed_app_manger_ptr):
mAppManPtr(passed_app_manger_ptr),
mEventsManPtr(passed_ptr),
mConfigMsg(passedConfig),
mIsActive(false)
    {
        mEventID  = mConfigMsg.CompositeEventId;
        LOG_MOD(NOTICE, logmod)<<"Creation: Composite Event "<<mEventID;
        mEventsManPtr->AddSignal(mEventID);
    }

CompositeEventModel::~CompositeEventModel()
    {
        LOG_MOD(NOTICE, logmod)<<"Destruction: "<<mEventID;
    }

bool CompositeEventModel::ApplyOperator(std::string opt, bool a, bool b)
    {
        if (opt== "OR")
            {
                return a||b;
            }
        else if (opt =="AND")
            {
                return a && b;
            }
        else
            {
              LOG_MOD(ERROR, logmod)<<"Unsupported operator "<<opt;
              return false;
            }
    }

void CompositeEventModel::emit()
    {
        if(!mIsActive)
            {
                LOG_MOD(NOTICE, logmod)<<" Composite Event Emitted "<<mEventID;
                mIsActive = true;
                mEventsManPtr->EmitSignal(mEventID);
            }
    }

void CompositeEventModel::EvaluateSimpleEvents()
    {
        LOG_MOD(NOTICE, logmod)<<"Composite Event "<<mEventID <<" Evaluating, current status is "<< mIsActive;
        bool InitVal = mEventsManPtr->GetEventStatus(mConfigMsg.LogicalExpression.at(0).first);
        for (unsigned int i = 1  ; i < mConfigMsg.LogicalExpression.size(); i++)
            {
                InitVal = ApplyOperator(mConfigMsg.LogicalExpression.at(i-1).second,InitVal,
                                        mEventsManPtr->GetEventStatus(mConfigMsg.LogicalExpression.at(i).first));
            }
        if((InitVal) && (!mIsActive))
            {
                emit();
            }
        else if (!InitVal && mIsActive)
            {
                mIsActive = false;
            }
        else
            {
             // skip
            }
    }
