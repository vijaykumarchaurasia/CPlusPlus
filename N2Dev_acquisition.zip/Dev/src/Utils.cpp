#include <algorithm>
#include <sstream>
#include "Utils.h"


namespace DaqApp
{
    namespace utils
    {
        /**
         *  This function returns true if s is a number else false.
         */
        bool IsNumber(const std::string& s)
            {
                return !s.empty() && std::find_if(s.begin(),s.end(), [](unsigned char c)
                {
                    return !std::isdigit(c);
                }) == s.end();
            }

            /**
             *  This function converts Hex to Integer value.
             */
            uint32_t ConvertHexToInt(const std::string& hex_str)
                {
                    uint32_t val = 0;
                    std::stringstream ss;
                    ss<<std::hex<<hex_str;
                    ss >>val;
                    return val;
                }

                /**
                 * This function is used to convert int value into Hex.
                 */
                std::string ConvertIntToHex(int str_int)
                {
                    std::string hex_val = "0x";
                    if(str_int>=0 && str_int<=15)
                        {
                            hex_val = "0x0";
                        }
                    std::stringstream ss;
                    ss<<std::uppercase<<std::hex<<str_int;
                    std::string result(ss.str());
                    return hex_val.append(result);
                }

                /**
                 * This function is used to convert numeric string into int.
                 */
                uint32_t ConvertValueToInt(const std::string& add_str)
                {
                    uint32_t val = 0;
                    if(IsHexNotation(add_str))
                    {
                        std::stringstream ss;
                        ss<<std::hex<<add_str;
                        ss >>val;
                    }
                    else if(DaqApp::utils::IsNumber(add_str))
                    {
                        val = std::stoi(add_str);
                    }
                    else
                    {
                        val = 0; // Returning default value 0, need to discuss
                    }
                    return val;
                }

                /**
                 *  This function returns true if s is a hex value.
                 */
                bool IsHexNotation(const std::string& s)
                    {
                        return s.compare(0, 2, "0x") == 0
                          && s.size() > 2
                          && s.find_first_not_of("0123456789abcdefABCDEF", 2) == std::string::npos;
                    }

    }
}
