#include <ecu/logging.h>
#include "AppManager.h"
#include "DataAccessModel.h"
#include "EventsManagerModel.h"
#include "SimpleEventModelEv5006.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.SimpleEventModelEv5006");
    }
using namespace DaqApp;

SimpleEventModelEv5006::SimpleEventModelEv5006(EventConfigMessage config_message, EventsManagerModel *passed_ptr, AppManager* passed_app_manger_ptr):
mAppManagerHandlePtr(passed_app_manger_ptr),
mEventsManagerHandlerPtr(passed_ptr),
mConfigMessage(config_message)
    {
        mEventID = ("EV5006");
        LOG_MOD(NOTICE, logmod)<<"Creation:"<<mEventID;
        mIsActive = false;
        mEventsManagerHandlerPtr->AddSignal(mEventID);
    }

SimpleEventModelEv5006::~SimpleEventModelEv5006()
    {
        LOG_MOD(NOTICE, logmod)<<"Destruction: EV5006";
    }

//Pre defined event EV5006, engine speed is less than 50RPM.
void SimpleEventModelEv5006::Evaluate()
    {
        LOG_MOD(INFO, logmod)<<"EV5006 Evaluating current status is"<< mIsActive;
        auto KeySwitch_Battery_Potential = mAppManagerHandlePtr->GetDataAccessModel()->Read(mKeySwitchBatteryPotentialSPN, Protocol::J1939Proto, mConfigMessage.ConfigID);
        if((KeySwitch_Battery_Potential >= mEV5006PredefinedThreshold) && (!mIsActive))
            {
                LOG_MOD(NOTICE, logmod)<< "EV5006 Emitted, KeySwitch_Battery_Potential : " << KeySwitch_Battery_Potential;
                mEventsManagerHandlerPtr->EmitSignal("EV5006");
                mIsActive = true;
            }
        else if (KeySwitch_Battery_Potential < mEV5006PredefinedThreshold) //could be changed after discussion
            {
                mIsActive = false;
            }
    }
