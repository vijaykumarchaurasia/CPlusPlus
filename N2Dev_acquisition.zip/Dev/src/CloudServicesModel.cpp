#include <assert.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <curl/curl.h>
#include <curl/easy.h>
#include <json/json.h>
#include <ecu/logging.h>
#include <ecu/com/backend_messageadapter.h>
#include "CloudServicesModel.h"
#include "DaqContentHandler.h"
#include "DataConnectivityModel.h"
#include "ClientManagerModel.h"
#include "DataAccessModel.h"
#include "FilesHandlingModel.h"
#include "ConfigurationManagerModel.h"
namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.CloudServicesModel");
    }
using namespace DaqApp;
bool firstTime = true;
bool isNavistarFlag = false;
//Static Variable
BackendClient::ConnectionState CloudServicesModel::mBackendState = BackendClient::ConnectionState::CON_DISCONNECTED;

CloudServicesModel::CloudServicesModel(AppManager* passedAppManger):
mAppManagerHandlePtr(passedAppManger),
mAuthToken("Not Set"),
mBlobName("Not Set"),
mCorrelationId("Not Set"),
mContentIdAppMap(std::make_pair("CloudServices",112)),
mDataConnectivityPtr(std::make_unique<DataConnectivityModel>(passedAppManger)),
mDaqContentHandlerPtr(std::make_unique<DaqContentHandler>(passedAppManger)),
mTimeUtilitiesPtr(passedAppManger->GetTimeUtilities()),
mNotifyConfigStatusTickId(0),
mUploadCodeReason(std::make_pair(0,"No reason"))
    {
        LOG_MOD(NOTICE, logmod) << "Creation: CloudServicesModel";
        mDeviceSerialNo  = "190409-0028";//N2 device that belongs to Harsh Patel
        mVersion         = "1.0.0";
        //Production API
        #ifndef DEBUGDAQ
        mClientId        = "04d9697a-f7e2-4a6b-8a7d-e8183a50ae06";
        mClientSecret    = "MHjY.JtM4fO20Ogj0V9~-1BT0c4eUV_~Y_";
        mSubscriptionKey = "929f2e25bdea4232b69eb74f4e4fa634";
        #endif // DEBUGDAQ
        //SandBox API
        #ifdef DEBUGDAQ
        mClientId        = "3f1a4d2b-6394-4396-9962-8a7eb63e8ec7";
        mClientSecret    = "5_S-b.1F~i-hA5YSTpEK.R9c1RFtE9YRg_";
        mSubscriptionKey = "3ca89c19999940059cb6f2f4db800b6d";
        #endif // DEBUGDAQ
    }

CloudServicesModel::~CloudServicesModel()
    {
        mTimeUtilitiesPtr->ReleaseTick(mNotifyConfigStatusTickId);
        mUploadCodeReason = {};
        mMapFilePendingToUpload.clear();
        LOG_MOD(NOTICE, logmod) << "Destruction:CloudServicesModel";
    }

void CloudServicesModel::SetUpCloudServicesModel()
    {
        #ifndef GTESTBUILD
        mDataConnectivityPtr->SetUpDataConnectivityModel();
        #endif // GTESTBUILD
        #ifndef DAQEMULATOR
        mDeviceSerialNo = mAppManagerHandlePtr->GetDataAccessModel()->ReadMisc("8207");
        mEquipmentId    = mAppManagerHandlePtr->GetDataAccessModel()->ReadMisc("8204");
        mEngineSerialNo = mAppManagerHandlePtr->GetDataAccessModel()->ReadMisc("588");
        mEngineVIN      = mAppManagerHandlePtr->GetDataAccessModel()->ReadMisc("237");
        #endif // DAQEMULATOR
        LOG_MOD(NOTICE, logmod)<<"CloudServicesModel::SetUpCloudServicesModel for device "<<mDeviceSerialNo;
        mTransportClientPtr = mAppManagerHandlePtr->GetClientManagerModel()->getTransportClient();
        if (mTransportClientPtr)
            {
                //Create backentclient pointer to receive JSON from Backend
                mBackendClientPtr = create_be_client(mTransportClientPtr);
                //Register a connection state callback lambda function
                mBackendClientPtr->add_connection_callback( [](BackendClient::ConnectionState cs)
                {
                LOG_MOD(NOTICE, logmod) << "Backend connection "\
                << (cs == BackendClient::ConnectionState::CON_CONNECTED ? "established" : "lost");
                    mBackendState = cs;
                });
                mBackendClientPtr->add_content_callback(mContentIdAppMap.second, bind(&DaqContentHandler::Content112Callback, mDaqContentHandlerPtr.get(), std::placeholders::_1, std::placeholders::_2));
            }
}

DaqContentHandler* CloudServicesModel::GetDaqContentHandler()
    {
        assert(nullptr != mDaqContentHandlerPtr);
        return mDaqContentHandlerPtr.get();
    }

DataConnectivityModel* CloudServicesModel::GetDataConnectivityModel()
    {
        assert(nullptr != mDataConnectivityPtr);
        return mDataConnectivityPtr.get();
    }

size_t CloudServicesModel::CurlWrite(void *contents, size_t size, size_t nmemb, std::string *messagePayload)
    {
        LOG_MOD(NOTICE, logmod)<<"CurlWrite : Started";
        size_t newLength = size*nmemb;
        try
            {
                messagePayload->append((char*)contents, newLength);
            }
        catch(std::bad_alloc &e)
            {
                LOG_MOD(ERROR, logmod)<<"CurlWrite : bad_alloc";
                //handle memory problem
                newLength = 0;
            }
        return newLength;
    }

//Please refer Device API provided by OnCommands - Post Initialize File Upload
bool CloudServicesModel::InitiateUpload(const std::string& fileName)
    {
        LOG_MOD(NOTICE, logmod)<<"CloudServicesModel::InitiateUpload statred for device "<<mDeviceSerialNo;
        char posturlString[2048];
        std::string messagePayload;
        struct curl_slist *reqheaders = NULL;
        bool result = false;
        #ifndef DEBUGDAQ
            //Request URL for Production API
            sprintf (&posturlString[0],"http://api.oncommandconnection.com/ntd/operations/fileupload/device/%s", mDeviceSerialNo.c_str());
        #elif DAQEMULATOR
            //Request URL for SandBox API
            sprintf (&posturlString[0],"https://api.sandbox.oncommandconnection.com/ntd/operations/fileupload/device/%s", mDeviceSerialNo.c_str());
        #elif DEBUGDAQ
            //Request URL for SandBox API
            sprintf (&posturlString[0],"http://api.sandbox.oncommandconnection.com/ntd/operations/fileupload/device/%s", mDeviceSerialNo.c_str());
        #endif // DEBUGDAQ
        CURL *curl = curl_easy_init();
        if (curl)
            {
                char curl_fields[300];
                /***** POST *****/
                curl_easy_setopt(curl, CURLOPT_URL, posturlString);
                curl_easy_setopt(curl, CURLOPT_TIMEOUT, 120L);
                #ifndef DEBUGDAQ
                //For Production API
                curl_easy_setopt(curl, CURLOPT_CAPATH, "/usr/share/ca-certificates");
				curl_easy_setopt(curl, CURLOPT_CAINFO, "/usr/share/ca-certificates/Navistar-APIM.pem");
                #endif // DEBUGDAQ
                curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, CurlWrite);
                curl_easy_setopt(curl, CURLOPT_WRITEDATA, &messagePayload);
                //curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
                #ifdef DAQEMULATOR
                std::string authToken = "Authorization: Bearer ";
                authToken.append(mAuthToken);
                reqheaders       = curl_slist_append(reqheaders, authToken.c_str());
                #endif // DAQEMULATOR
                reqheaders       = curl_slist_append(reqheaders, "Content-Type: application/json");
                std::string version   = "Version: ";
                version.append(mVersion);
                reqheaders       = curl_slist_append(reqheaders, version.c_str());
                std::string subKey    = "SubscriptionKey: ";
                subKey.append(mSubscriptionKey);
                reqheaders       = curl_slist_append(reqheaders, subKey.c_str());
                curl_easy_setopt(curl, CURLOPT_HTTPHEADER, reqheaders);
                snprintf(curl_fields, sizeof(curl_fields), R"({"contentid":%i, "filename":"%s"})", mContentIdAppMap.second, fileName.c_str());
                curl_easy_setopt(curl, CURLOPT_POSTFIELDS, curl_fields);
                LOG_MOD(NOTICE, logmod)<<"InitiateUpload: Request Body "<<curl_fields;
                CURLcode response = curl_easy_perform(curl);
                if (response == CURLE_OK)
                    {
                        long int response_code = 0;
                        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
                        if(response_code == (long)ResponseCode::IntiUploadSuccess) //200
                            {
                                Json::Reader reader;
                                Json::Value obj;
                                reader.parse(messagePayload, obj);
                                Json::Value responseData= obj["responsedata"];
                                mCorrelationId          = responseData["correlationid"].asString();
                                mBlobName               = responseData["bloburi"].asString();
                                mFilePath               = fileName;
                                result                  = true;
                                LOG_MOD(NOTICE, logmod)<<"InitiateUpload:"<<fileName<<" successful with response code: "<<response_code<<" Ok";
                            }
                        else
                            {
                                std::string getResDescription = GetResponse(response_code);
                                LOG_MOD(WARNING, logmod)<<"InitiateUpload failed with response code:"<<response_code<<":"<<getResDescription;
                            }
                    }
                else
                    {
                        LOG_MOD(ERROR, logmod)<<"CloudServicesModel::InitiateUpload failed "<<curl_easy_strerror(response);
                    }
            curl_easy_cleanup(curl);
            curl_slist_free_all(reqheaders);
            }
        return result;
    }

//Please refer Device API provided by OnCommands - Put Upload Blob File
bool CloudServicesModel::UploadFileToBlob(const std::string& filePath)
    {
            LOG_MOD(NOTICE, logmod)<<"CloudServicesModel::UploadFileToBlob statred from device "<<mDeviceSerialNo<<std::endl;
            long response_code;
            struct curl_slist *putheaders = nullptr;
            bool result = false;
            char hdrBuffer[250];
            FILE * hd_src;
            struct stat file_info;
            stat(filePath.c_str(), &file_info);
            hd_src = fopen(filePath.c_str(), "rb");
            if(hd_src == nullptr)
                {
                    LOG_MOD(ERROR, logmod)<<"File missing : "<<filePath;
                    return false;
                }
            CURL *putCurl = curl_easy_init();
            if (putCurl)
            {
                /***** PUT *****/
                // Enable uploading
                curl_easy_setopt(putCurl, CURLOPT_UPLOAD, 1L);
                // HTTP PUT
                curl_easy_setopt(putCurl, CURLOPT_PUT, 1L);
                #ifndef DEBUGDAQ
                //For Production API
                curl_easy_setopt(putCurl, CURLOPT_CAPATH, "/usr/share/ca-certificates");
				curl_easy_setopt(putCurl, CURLOPT_CAINFO, "/usr/share/ca-certificates/azure.pem");
                #endif // DEBUGDAQ
                curl_easy_setopt(putCurl, CURLOPT_URL, mBlobName.c_str());
                // Specify which file to upload
                curl_easy_setopt(putCurl, CURLOPT_READDATA, hd_src);
                // Provide the size of the upload, we specicially typecast the value
                // to curl_off_t since we must be sure to use the correct data size
                curl_easy_setopt(putCurl, CURLOPT_INFILESIZE_LARGE, (curl_off_t)file_info.st_size);
                sprintf (&hdrBuffer[0],"Content-Length: %ld",file_info.st_size);
                putheaders = curl_slist_append(putheaders, hdrBuffer);
                putheaders = curl_slist_append(putheaders, "x-ms-blob-type: BlockBlob");
                curl_easy_setopt(putCurl, CURLOPT_HTTPHEADER, putheaders);
                #ifndef DAQEMULATOR
                curl_easy_setopt(putCurl, CURLOPT_PROXY, "127.0.0.1:3128");
				#endif // DAQEMULATOR
                //curl_easy_setopt(putCurl, CURLOPT_VERBOSE, 1L);
                CURLcode res    = curl_easy_perform(putCurl);
                if (res == CURLE_OK)
                    {
                        curl_easy_getinfo(putCurl, CURLINFO_RESPONSE_CODE, &response_code);
                        switch(response_code)
                            {
                                case (long)ResponseCode::UploadSuccess:
                                result         = true;
                                mUploadCodeReason = std::make_pair(response_code, "Created");
                                LOG_MOD(NOTICE, logmod)<<"UploadFileToBlob successful with response code: "<<response_code<<" Created";
                                LOG_MOD(NOTICE, logmod)<<"To verify the uploaded content by downloading the same file using BlobName :"<<mBlobName;
                                break;

                                default:
                                std::string getResDescription = GetResponse(response_code);
                                mUploadCodeReason = std::make_pair(response_code, getResDescription);
                                LOG_MOD(WARNING, logmod)<<"UploadFileToBlob failed with response code:"<<response_code<<"-"<<getResDescription;
                                break;
                            }
                    }
                    else
                        {
                            mUploadCodeReason = std::make_pair(res, curl_easy_strerror(res));
                            LOG_MOD(ERROR, logmod)<<"CloudServicesModel::UploadFileToBlob failed "<< curl_easy_strerror(res);
                        }
                    curl_easy_cleanup(putCurl);
                    curl_slist_free_all(putheaders);
                }
            if (hd_src)
                {
                    fclose(hd_src);
                }
            return result;
    }

bool CloudServicesModel::UploadFileWrapper(const std::string& filePath)
    {
        #ifdef DAQEMULATOR
            while(mAuthToken.compare("Not Set") == 0 || mAuthToken.empty())
                {
                    GetAuthToken();
                }
        #endif // DAQEMULATOR
        bool fileUploaded = false;
        if(InitiateUpload(filePath))
        {
        fileUploaded = UploadFileToBlob(filePath);
        if(fileUploaded)
            {
                LOG_MOD(NOTICE, logmod)<<"File "<<filePath<<" uploaded to cloud successfully from device "<<mDeviceSerialNo <<std::endl;
            }
        else
            {
                int uploadAttempt = 1;
                std::map<std::string, int>::iterator found = mMapFilePendingToUpload.find(filePath);
                if(found != mMapFilePendingToUpload.end())
                {
                    uploadAttempt = found->second;
                    found->second = ++uploadAttempt;
                    //As per Cloud IT team suggestions, upload failed more than twice so waiting for 1 min
                    std::this_thread::sleep_for(std::chrono::milliseconds(60000));
                }
                mMapFilePendingToUpload.insert(std::make_pair(filePath, uploadAttempt));
                LOG_MOD(WARNING, logmod)<<"Failed to upload total files :"<<mMapFilePendingToUpload.size()<<
                " uploadAttempt:"<<uploadAttempt<<" FileName:"<<filePath;
            }
            while(!NotifyIotHub())
            {
                LOG_MOD(NOTICE, logmod)<<"Notify failed";
            }
        }
        return fileUploaded;
    }

bool CloudServicesModel::UploadFile(const std::string& filePath, const std::string& fileUploadCID)
    {
        bool fileUploaded;
        mFileUploadCorrelationId = fileUploadCID;
        fileUploaded = UploadFileWrapper(filePath);
        return fileUploaded;
    }

//Please refer Device API provided by OnCommands - Post Device Notifications
bool CloudServicesModel::NotifyIotHub()
    {
        LOG_MOD(NOTICE, logmod)<<"CloudServicesModel::NotifyIotHub from device "<<mDeviceSerialNo<<std::endl;
        char posturlString[2048];
        struct curl_slist *reqheaders = NULL;
        long response_code;
        bool result = false;
        CURL *curl  = curl_easy_init();
        #ifndef DEBUGDAQ
            //Request URL for Production API
            sprintf (&posturlString[0],"http://api.oncommandconnection.com/ntd/operations/fileupload/notification/device/%s",mDeviceSerialNo.c_str());
        #elif DAQEMULATOR
            while(mAuthToken.compare("Not Set") == 0 || mAuthToken.empty())
                {
                    GetAuthToken();
                }
            //Request URL for Sandbox API
            sprintf (&posturlString[0],"https://api.sandbox.oncommandconnection.com/ntd/operations/fileupload/notification/device/%s",mDeviceSerialNo.c_str());
        #elif DEBUGDAQ
            //Request URL for Sandbox API
            sprintf (&posturlString[0],"http://api.sandbox.oncommandconnection.com/ntd/operations/fileupload/notification/device/%s",mDeviceSerialNo.c_str());
        #endif // DEBUGDAQ
        if (curl)
            {
                char curl_fields[4000];
                /***** POST *****/
                curl_easy_setopt(curl, CURLOPT_URL, posturlString);
                curl_easy_setopt(curl, CURLOPT_TIMEOUT, 120L);
                #ifndef DEBUGDAQ
                //For Production API
                curl_easy_setopt(curl, CURLOPT_CAPATH, "/usr/share/ca-certificates");
				curl_easy_setopt(curl, CURLOPT_CAINFO, "/usr/share/ca-certificates/Navistar-APIM.pem");
                #endif // DEBUGDAQ
                #ifdef DAQEMULATOR
                std::string authToken = "Authorization: Bearer ";
                authToken.append(mAuthToken);
                reqheaders       	= curl_slist_append(reqheaders, authToken.c_str());
                #endif // DAQEMULATOR
                reqheaders       	= curl_slist_append(reqheaders, "Content-Type: application/json");
                std::string version = "Version: ";
                version.append(mVersion);
                reqheaders       	= curl_slist_append(reqheaders, version.c_str());
                std::string subKey  = "SubscriptionKey: ";
                subKey.append(mSubscriptionKey);
                reqheaders       	= curl_slist_append(reqheaders, subKey.c_str());
                curl_easy_setopt(curl, CURLOPT_HTTPHEADER, reqheaders);
                int contentId    	= mContentIdAppMap.second;
                if(firstTime)
                    {
                        if(mFilePath.find("Navistar") != std::string::npos )
                        {
                            isNavistarFlag = true;
                        }
                        firstTime = false;
                    }
                bool isSuccess = false;
                if(mUploadCodeReason.first == (int)ResponseCode::UploadSuccess)
                {
                    isSuccess =  true;
                }
                if(!isNavistarFlag)
                    {
                        boostfs::path filePath        = mFilePath;
                        boostfs::path fileExtension   = filePath.extension();
                        std::string fileExtensionWithoutDot = fileExtension.string().substr(1);			//Remove '.' from extension
                        boostfs::path fileWithoutExtension = filePath.filename().replace_extension("");
                        std::string fileType;
                        if(mFilePath.find("csv") != std::string::npos )
                            {
                                fileType = "CUMMINS_EDL_NGDI";
                            }
                        else
                            {
                                fileType = "CUMMINS_EFPA_NGDI";
                            }
                        snprintf(curl_fields, sizeof(curl_fields), R"({"bloburi": "%s",
                                                                      "contentid": %i,
                                                                      "configurationtype": "%s",
                                                                      "issuccess": %s,
                                                                      "statuscode": %i,
                                                                      "description": "%s",
                                                                      "correlationid": "%s",
                                                                      "additionaldata": {
                                                                                      "componentSerialNumber": "%s",
                                                                                      "equipmentId": "%s",
                                                                                      "vin": "%s",
                                                                                      "telematicsDeviceId": "%s",
                                                                                      "statuses": [
                                                                                              {
                                                                                              "statusType": "fileUpload",
                                                                                              "status": {
                                                                                                      "jobId": "%s",
                                                                                                      "status": "READY",
                                                                                                      "fileName": "%s",
                                                                                                      "fileExtension":"%s",
                                                                                                      "fileType":"%s",
                                                                                                      "reasonCode": "",
                                                                                                      "details": "%s"
                                                                                                        }
                                                                                              }   ]}})",
    mBlobName.c_str(), contentId, "cumminsdataacquisition", isSuccess?"true":"false", mUploadCodeReason.first,
    mUploadCodeReason.second.c_str(), mCorrelationId.c_str(), mEngineSerialNo.c_str(), mEquipmentId.c_str(),
    mEngineVIN.c_str(), mDeviceSerialNo.c_str(), mFileUploadCorrelationId.c_str(), fileWithoutExtension.string().c_str(),
	fileExtensionWithoutDot.c_str(), fileType.c_str(), mCorrelationId.c_str());
                    }
                else
                    {
                        //Request Body
                        snprintf(curl_fields, sizeof(curl_fields), R"({"bloburi":"%s", "contentid":%s, "configurationtype":"%s","issuccess":%s,
                                                                  "statuscode":%i,"description":"%s","correlationid":"%s","additionaldata":"{}"})",
                        mBlobName.c_str(), std::to_string(contentId).c_str(), "a26dataacquisition",isSuccess?"true":"false",
                        mUploadCodeReason.first, mUploadCodeReason.second.c_str(), mCorrelationId.c_str());
                    }

                curl_easy_setopt(curl, CURLOPT_POSTFIELDS, curl_fields);
                LOG_MOD(NOTICE, logmod)<<"NotifyIotHub: Request Body "<<curl_fields;
                //curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
                CURLcode response = curl_easy_perform(curl);
                if (response == CURLE_OK)
                    {
                        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
                        if(response_code == (long)ResponseCode::NotifyIOTHubSuccess)//204
                            {
                                result = true;
                                LOG_MOD(NOTICE, logmod)<<"NotifyIotHub successful with response code:"<<response_code<<" No Content";
                            }
                        else
                            {
                                std::string getResDescription = GetResponse(response_code);
                                LOG_MOD(WARNING, logmod)<<"NotifyIotHub failed with response code:"<<response_code<<":"<<getResDescription;
                            }
                    }
                else
                    {
                        LOG_MOD(ERROR, logmod)<<"CloudServicesModel::NotifyIotHub failed with "<<curl_easy_strerror(response);
                    }
            curl_easy_cleanup(curl);
            curl_slist_free_all(reqheaders);
            }
        return result;
    }

//Please refer Security Token API provided by OnCommands - Post Authorization
std::string CloudServicesModel::GetAuthToken()
    {
        LOG_MOD(NOTICE, logmod)<<"CloudServicesModel::GetAuthToken : Started";
        mAuthToken = "";
        #ifdef DAQEMULATOR
        struct curl_slist *headers = NULL;
        char posturlString[2048];
        std::string messagePayload;
        CURL *curl = curl_easy_init();
        //Request URL for SandBox
        snprintf(posturlString, sizeof(posturlString), "https://api.sandbox.oncommandconnection.com/authorization/oauth2/token");
        if (curl)
            {
                char curl_fields[500];
                /***** POST *****/
                curl_easy_setopt(curl, CURLOPT_URL, posturlString);
                curl_easy_setopt(curl, CURLOPT_TIMEOUT, 120L);
                curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, CurlWrite);
                curl_easy_setopt(curl, CURLOPT_WRITEDATA, &messagePayload);
                headers        = curl_slist_append(headers, "Content-Type: application/json");
                std::string subKey  = "SubscriptionKey: ";
                subKey.append(mSubscriptionKey);
                headers        = curl_slist_append(headers, subKey.c_str());
                curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
                snprintf(curl_fields, sizeof(curl_fields), R"({"client_id":"%s", "client_secret":"%s"})",
                                                            mClientId.c_str(), mClientSecret.c_str());
                curl_easy_setopt(curl, CURLOPT_POSTFIELDS, curl_fields);
                //LOG_MOD(NOTICE, logmod)<<"GetAuthToken: Request Body "<<curl_fields;
                //curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
                CURLcode res   = curl_easy_perform(curl);
                if (res == CURLE_OK)
                    {
                        long response_code;
                        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
                        if(response_code == (long)ResponseCode::AuthTokenSuccess)//200
                            {
                                Json::Reader reader;
                                Json::Value obj;
                                reader.parse(messagePayload, obj);
                                std::string access_token = obj["access_token"].asString();
                                mAuthToken          	 = access_token;
                                LOG_MOD(NOTICE, logmod)<<"GetAuthToken successful with response code: "<<response_code<<" Ok";
                            }
                        else
                            {
                                std::string getResDescription = GetResponse(response_code);
                                LOG_MOD(WARNING, logmod)<<"GetAuthToken failed with response code: "<<response_code<<":"<<getResDescription;
                            }
                    }
                else
                    {
                        LOG_MOD(ERROR, logmod)<<"CloudServicesModel::GetAuthToken failed: "<<curl_easy_strerror(res);
                    }
            }
        curl_easy_cleanup(curl);
        curl_slist_free_all(headers);
        #endif // DAQEMULATOR
        return mAuthToken;
    }

std::string CloudServicesModel::GetResponse(const long& responseCode)
    {
        std::string responseDescription;
        switch(responseCode)
            {
                case (long)ResponseCode::BadRequest:
                responseDescription = "Bad Request. The request has some invalid parameters or Invalid syntax for this request was provided.";
                break;
                case (long)ResponseCode::UnAuthorized:
                mAuthToken = "";
                responseDescription = "Unauthorized. User is unauthorized to access the requested resource.";
                break;
                case (long)ResponseCode::Forbidden:
                mAuthToken = "";
                responseDescription = "Forbidden. Token is invalid, unauthorized to access the requested resource";
                //Cloud IT teamm suggested to wait for few seconds before 2nd attempt to upload
                std::this_thread::sleep_for(std::chrono::milliseconds(2000));
                break;
                case (long)ResponseCode::NotFound:
                responseDescription = "Not Found. The requested resource was not found.";
                break;
                case (long)ResponseCode::NotAcceptable:
                responseDescription = "Not Acceptable. An incorrect content type was sent, or Acceptance header is invalid for this endpoint resource";
                break;
                case (long)ResponseCode::InternalServerError:
                responseDescription = "Internal Server Error - There was a problem with the service.";
                break;
            }
        return responseDescription;
    }

void CloudServicesModel::SetConfigStatus(ConfigStatus passedStatus, const std::string& passedDescription, const std::pair<std::string, std::string>& passedPairCodeReason)
    {
        mNotifyConfigStatusTickId = mTimeUtilitiesPtr->Tick(ms(1000), Redundancy::DoOnce, &CloudServicesModel::SendConfigStatusNotification, this, passedStatus, passedDescription, passedPairCodeReason.first, passedPairCodeReason.second);
    }

void CloudServicesModel::SendConfigStatusNotification(ConfigStatus passedStatus, const std::string& passedDescription, const std::string& passedCode, const std::string& passedReason)
    {
        LOG_MOD(NOTICE, logmod) <<"CloudServicesModel::SendConfigStatusNotification()";
        char Payload_fields[3048];
        snprintf(Payload_fields, sizeof(Payload_fields), R"({"correlationid": "%s",
                                                            "telemetrydatatype" : "configstatus",
                                                            "status": %i,
                                                            "description": "%s",
                                                            "additionaldata": {
                                                            "componentSerialNumber": "%s",
                                                            "equipmentId": "%s",
                                                            "vin": "%s",
                                                            "telematicsDeviceId": "%s",
                                                            "statuses": [
                                                                   {
                                                                    "statusType": "configSpec",
                                                                    "status": {
                                                                            "jobId": "%s",
                                                                            "status": "%s",
                                                                            "reasonCode": "%s",
                                                                            "details": "%s"
                                                                    }
                                                                   }
                                                                        ]}})",
        mConfigCorrelationId.c_str(), passedStatus, passedDescription.c_str(),mEngineSerialNo.c_str(),
        mEquipmentId.c_str(), mEngineVIN.c_str(), mDeviceSerialNo.c_str(), mConfigCorrelationId.c_str(),
        passedDescription.c_str(), passedCode.c_str(), passedReason.c_str());
        LOG_MOD(NOTICE, logmod)<<"SendConfigStatusNotification: Payload fields "<<Payload_fields;
        PbBackendMessageAdapter<std::string> adapter;
        auto serialize_result = adapter.serialize(Payload_fields);
        if(serialize_result.ok() && mBackendClientPtr)
            {
                BackendClient::TxOptions txOptions;
                // Set a callback lambda function
                txOptions.callback = [](uint64_t rid, int status)
                    {
                       LOG_MOD(NOTICE, logmod) << "Message with req_id=" << rid << " processed with status=" << status;
                    };
                LOG_MOD(WARNING, logmod) <<"Publishing message:"<<Payload_fields;
                mBackendClientPtr->publish( serialize_result.val(), mContentIdAppMap.second, txOptions);
            }
            GetDaqContentHandler()->SetFileInProgress(false);
    }

void CloudServicesModel::SetConfigCorrelationId(const std::string& passed)
    {
        mConfigCorrelationId = passed;
    }

BackendClient_ptr CloudServicesModel::GetBackendClient()
    {
        return mBackendClientPtr;
    }

std::string CloudServicesModel::GetBlobName()
    {
        return mBlobName;
    }

//Please refer Device API provided by OnCommands - Post Cummins Access Token
CumminsAccessTokenResponse CloudServicesModel::CumminsAccessToken(uint64_t seedInfo, const std::string& supplierInfo )
    {
        char posturlString[2048];
        std::string messagePayload;
        struct curl_slist *reqheaders = NULL;
        CumminsAccessTokenResponse structCumminsAccessTokenRes;

        if (!mDataConnectivityPtr->CheckInternetConnectivity()){
            LOG_MOD(ERROR, logmod)<<"CloudServicesModel::CumminsAccessToken failed due to Internet Not Connected";
			structCumminsAccessTokenRes.SessionKey = "";
            structCumminsAccessTokenRes.AccessKey  = "";
            return structCumminsAccessTokenRes;
        }

        //Production API
        #ifndef DEBUGDAQ
        //Production API
        sprintf (&posturlString[0],"http://api.oncommandconnection.com/partner/Integration/cummins/token");
        #elif DEBUGDAQ
        //Sandbox API
        sprintf (&posturlString[0],"http://api.sandbox.oncommandconnection.com/partner/Integration/cummins/token");
        #endif // DEBUGDAQ
        CURL *curl = curl_easy_init();
        if (curl)
            {
                char curl_fields[300];
                /***** POST *****/
                curl_easy_setopt(curl, CURLOPT_URL, posturlString);
                curl_easy_setopt(curl, CURLOPT_TIMEOUT, 120L);
                #ifndef DEBUGDAQ
                //For Production API
                curl_easy_setopt(curl, CURLOPT_CAPATH, "/usr/share/ca-certificates");
				curl_easy_setopt(curl, CURLOPT_CAINFO, "/usr/share/ca-certificates/Navistar-APIM.pem");
                #endif // DEBUGDAQ
                curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, CurlWrite);
                curl_easy_setopt(curl, CURLOPT_WRITEDATA, &messagePayload);
                reqheaders       = curl_slist_append(reqheaders, "Content-Type: application/json");
                std::string subKey    = "SubscriptionKey: ";
                subKey.append(mSubscriptionKey);
                reqheaders       = curl_slist_append(reqheaders, subKey.c_str());
                curl_easy_setopt(curl, CURLOPT_HTTPHEADER, reqheaders);
                snprintf(curl_fields, sizeof(curl_fields), R"({"esn":"%s", "address":0, "boxid":"%s", "seed": %llu, "supplierinfo":"%s"})",
                                                            mEngineSerialNo.c_str(), mDeviceSerialNo.c_str(), seedInfo, supplierInfo.c_str());
                curl_easy_setopt(curl, CURLOPT_POSTFIELDS, curl_fields);
                LOG_MOD(NOTICE, logmod)<<"CumminsAccessToken: Request Body "<<curl_fields;
                //curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
                CURLcode response = curl_easy_perform(curl);
                if (response == CURLE_OK)
                    {
                        long int response_code = 0;
                        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
                        if(response_code == (long)ResponseCode::CumminsAccessToken) //200
                            {
                                Json::Reader reader;
                                Json::Value obj;
                                reader.parse(messagePayload, obj);
                                Json::Value responseData= obj["responseData"];
                                structCumminsAccessTokenRes.APIVersion = responseData["apiVersion"].asString();
                                structCumminsAccessTokenRes.ProviderID = std::stoi(responseData["providerID"].asString());
                                structCumminsAccessTokenRes.TimeStamp  = responseData["timeStamp"].asString();
                                structCumminsAccessTokenRes.SessionKey = responseData["sessionKey"].asString();
                                structCumminsAccessTokenRes.AccessKey  = responseData["accessKey"].asString();
                                LOG_MOD(NOTICE, logmod)<<"CumminsAccessToken: successful with response code: "<<response_code<<" Ok";
                            }
                        else
                            {
                                std::string getResDescription = GetResponse(response_code);
                                structCumminsAccessTokenRes.SessionKey = "";
                                structCumminsAccessTokenRes.AccessKey  = "";
                                LOG_MOD(WARNING, logmod)<<"CumminsAccessToken failed with response code:"<<response_code<<":"<<getResDescription;
                            }
                    }
                else
                    {
                        LOG_MOD(ERROR, logmod)<<"CloudServicesModel::CumminsAccessToken failed "<<curl_easy_strerror(response);
						structCumminsAccessTokenRes.SessionKey = "";
                        structCumminsAccessTokenRes.AccessKey  = "";
                    }
            curl_easy_cleanup(curl);
            curl_slist_free_all(reqheaders);
            }
        return structCumminsAccessTokenRes;
    }
