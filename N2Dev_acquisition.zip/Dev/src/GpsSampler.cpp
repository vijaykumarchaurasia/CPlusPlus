#include "GpsSampler.h"
#include "DataAccessModel.h"
#include "CommonHeader.h"
#include <ecu/com/messageadapter.h>
#include <ecu/pb/gnss.pb.h>

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.GpsSampler");
    }
using namespace DaqApp;

GpsSampler::GpsSampler(ecu::lapi::com::ITransportClient_ptr client, AppManager* passed):
mAppManagerPtr(passed),
mDataAccessModelPtr(passed->GetDataAccessModel()),
mClient(client),
mSdkCallBackPtr(new CallBackHelper(this))
    {
         LOG_MOD(NOTICE, logmod)<<"Creation: GpsSampler!";
         mLatitude          = mOutOfRangeLatitude;
         mLongitude         = mOutOfRangeLongitude;
         mAtitude           = mOutOfRangeAltitude;
         mDirection_Heading = mOutOfRangeHeading;
         mGPS_Vehicle_Speed = mOutOfRangeSpeed;
         mClient->subscribe(mTopicGPSDataPtr, 0, mSdkCallBackPtr);
    }

GpsSampler::~GpsSampler()
    {
        mClient->unsubscribe(mTopicGPSDataPtr,mSdkCallBackPtr);
        LOG_MOD(NOTICE, logmod)<<"Destruction: GpsSampler";
    }

void GpsSampler::message(const std::string& topic, const ecu::lapi::com::Message& message)
    {
        if (topic == mTopicGPSDataPtr)
            {
                ecu::lapi::com::PbInternalMessageAdapter<ecu::lapi::pb::GnssData> adapter;
                if(adapter.deserialize(message).ok())
                    {
                        ecu::lapi::pb::GnssData GpsData = adapter.deserialize(message).take_val();

                        if ((GpsData.status() == mStatusGnssConnected_SC) && (GpsData.quality() != mQualityGnssNoFix_SC)
                            && ((GpsData.fix() == mGnss2DFix_SC || GpsData.fix() == mGnss3DFix_SC) && (GpsData.num_satellites() >= mGnssRequiredNumOfSatellites_SC)))
                            {
                                mLatitude          = GpsData.latitude();
                                mLongitude         = GpsData.longitude();
                                mAtitude           = GpsData.altitude();
                                mDirection_Heading = GpsData.heading();
                                mGPS_Vehicle_Speed = GpsData.speed();
                            }
                        else
                            {
                                /* data not accepted */
                                mLatitude          = mOutOfRangeLatitude;
                                mLongitude         = mOutOfRangeLongitude;
                                mAtitude           = mOutOfRangeAltitude;
                                mDirection_Heading = mOutOfRangeHeading;
                                mGPS_Vehicle_Speed = mOutOfRangeSpeed;
                                LOG_MOD(ERROR, logmod)<< "GpsSamplerModel :: GpsData out of range" << std::endl;
                            }
                        WriteToDataAccess();
                    }
            }
    }

void GpsSampler::WriteToDataAccess()
    {
        std::vector<GpsSamplerConfig> gps_sampler_config_msgs = mAppManagerPtr->GetConfigurationModel()->GetGpsSamplerConfig();
        if(gps_sampler_config_msgs.size()>0)
        {
            GpsSamplerConfig gpsConfig = gps_sampler_config_msgs.at(0);
            if(gpsConfig.IsLatitude)
            {
                mDataAccessModelPtr->WriteMisc(LATITUDE, std::to_string(mLatitude));
            }
            if(gpsConfig.IsLongitude)
            {
                mDataAccessModelPtr->WriteMisc(LONGITUDE, std::to_string(mLongitude));
            }
            if(gpsConfig.IsAltitude)
            {
                mDataAccessModelPtr->WriteMisc(ALTITUDE, std::to_string(mAtitude));
            }
            if(gpsConfig.IsDirection_Heading)
            {
                mDataAccessModelPtr->WriteMisc(DIRECTION_HEADING, std::to_string(mDirection_Heading));
            }
            if(gpsConfig.IsGPS_Vehicle_Speed)
            {
                mDataAccessModelPtr->WriteMisc(GPS_VEHICLE_SPEED, std::to_string(mGPS_Vehicle_Speed));
            }

        }

    }
