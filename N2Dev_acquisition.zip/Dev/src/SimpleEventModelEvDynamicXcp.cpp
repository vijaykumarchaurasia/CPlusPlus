#include <ecu/logging.h>
#include "AppManager.h"
#include "DataAccessModel.h"
#include "EventsManagerModel.h"
#include "SimpleEventModelEvDynamicXcp.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.SimpleEventModelEvDynamicXcp");
    }

using namespace DaqApp;

SimpleEventModelEvDynamicXcp::SimpleEventModelEvDynamicXcp(EventConfigMessage passedCfg, EventsManagerModel *passEvntMan, AppManager*passAppMan ):
mAppManagerHandlePtr(passAppMan),
mEventsManagerHandlerPtr(passEvntMan),
mSource(passedCfg.Source),
mOperator(passedCfg.Operator),
mSecondArg(passedCfg.Threshold),
mConfigId(passedCfg.ConfigID)
    {
        mEventID = passedCfg.EventId;
        LOG_MOD(NOTICE, logmod)<<"Creation:DynamicEvent Xcp Based created "<<mEventID;
        SetOperatorCallBackIndex();
        mEventsManagerHandlerPtr->AddSignal(mEventID);
    }

SimpleEventModelEvDynamicXcp::~SimpleEventModelEvDynamicXcp()
    {
        LOG_MOD(NOTICE, logmod)<<"Destruction: EVDynamic XCP";
    }

void SimpleEventModelEvDynamicXcp::SetOperatorCallBackIndex()
    {
        if (mOperator == "==")
            {
                mCallBackIndex = 0;
            }
        else if (mOperator == "!=")
            {
                mCallBackIndex = 1;
            }
        else if (mOperator == ">")
            {
                mCallBackIndex = 2;
            }
        else if (mOperator == ">=")
            {
                mCallBackIndex = 3;
            }
        else if (mOperator == "<")
            {
                mCallBackIndex = 4;
            }
        else if (mOperator == "<=")
            {
                mCallBackIndex = 5;
            }
        else if (mOperator == "<>")
            {
                mCallBackIndex = 6;
                mSecondArg = std::stod(mAppManagerHandlePtr->GetDataAccessModel()->Read(mSource,mConfigId));
            }
        else
            {
                LOG_MOD(ERROR, logmod)<<"Operator "<< mOperator<<" NOT supported for this DynamicXCPEvent  "<< mEventID <<std::endl;
                throw std::invalid_argument("Operator NOT supported " + mOperator);
            }
    }

bool SimpleEventModelEvDynamicXcp::IsEqual()
    {
        return mFirstArg == mSecondArg;
    }

bool SimpleEventModelEvDynamicXcp::IsNotEqual()
    {
        return mFirstArg != mSecondArg;
    }

bool SimpleEventModelEvDynamicXcp::IsLargerThan()
    {
        return mFirstArg > mSecondArg;
    }

bool SimpleEventModelEvDynamicXcp::IsLargerThanOrEqualTo()
    {
        return mFirstArg >= mSecondArg;
    }

bool SimpleEventModelEvDynamicXcp::IsLessThan()
{
    return mFirstArg < mSecondArg;
}

bool SimpleEventModelEvDynamicXcp::IsLessThanOrEqualTo()
    {
        return mFirstArg <= mSecondArg;
    }

bool SimpleEventModelEvDynamicXcp::IsSameAsPrevious()
{
    if(mFirstArg == mSecondArg)
    {
        return false;
    }
    else
    {
        mSecondArg = mFirstArg ;
        // mIsActive = false ; Needed if they want to emit on every change
        return true;
    }
}

void SimpleEventModelEvDynamicXcp::Evaluate()
    {
        LOG_MOD(DEBUG, logmod)<<"DynamicXCPEvent evaluating, current state is"<< mIsActive<<std::endl;
        mFirstArg = std::stof(mAppManagerHandlePtr->GetDataAccessModel()->Read(mSource,mConfigId));
        if ((!mIsActive) && ((this->*mCallBacks[mCallBackIndex])()))
            {
                mEventsManagerHandlerPtr->EmitSignal(mEventID);
                mIsActive = true;
                LOG_MOD(NOTICE, logmod)<<"DynamicXCPEvent emitted for signal "<< mSource <<" @ "<<mFirstArg<<std::endl;
            }
        else if ((mIsActive) && (!(this->*mCallBacks[mCallBackIndex])()))
            {
                mIsActive = false;
            }
    }
