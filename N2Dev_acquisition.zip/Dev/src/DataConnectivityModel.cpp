#include <string.h>
#include <curl/curl.h>
#include <curl/easy.h>
#include <ecu/logging.h>
#include "DataConnectivityModel.h"
#include "ClientManagerModel.h"
#include "AppManager.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.DataConnectivityModel");
    }
using namespace DaqApp;

DataConnectivityModel::DataConnectivityModel(AppManager* passedAppManger):
mAppManagerPtr(passedAppManger),
mSdkCallBackPtr(new CallBackHelper(this))
    {
        LOG_MOD(NOTICE, logmod)<<"Creation: DataConnectivityModel";
    }

DataConnectivityModel::~DataConnectivityModel()
    {
        LOG_MOD(NOTICE, logmod)<<"Destruction: DataConnectivityModel";
        #ifndef GTESTBUILD
        mTransportClientPtr->unsubscribe(mTopicModemStatus, mSdkCallBackPtr);
        #endif // GTESTBUILD
    }

void DataConnectivityModel::SetUpDataConnectivityModel()
    {
        #ifndef GTESTBUILD
        mTransportClientPtr = mAppManagerPtr->GetClientManagerModel()->getTransportClient();
        mTransportClientPtr->subscribe(mTopicModemStatus, 0, mSdkCallBackPtr);
        #endif // GTESTBUILD
    }

void DataConnectivityModel::message(const std::string &topic, const Message &message)
    {
        PbInternalMessageAdapter<ModemStatus> adapter;
        auto result = adapter.deserialize(message);
        if ( result.nok() )
            {
                LOG_MOD(ERROR, logmod) << "Unable to deserialize modem status!";
                return;
            }
        ModemStatus modemStatus = result.take_val();
        mModemState = modemStatus.modem_state();
		if (mModemState == ModemStatus::ModemState::ModemStatus_ModemState_Connected)
            {
                LOG_MOD(NOTICE, logmod)<<"Connected to modem";
            }
		else
            {
                LOG_MOD(WARNING, logmod)<<"Yet to be connected to modem";
            }
    }

bool DataConnectivityModel::CheckInternetConnectivity()
    {
        LOG_MOD(NOTICE, logmod)<<"CloudServicesModel::CheckInternetConnectivity";
        #ifndef DAQEMULATOR
        uint16_t counter = 0;
        while(mModemState != ModemStatus::ModemState::ModemStatus_ModemState_Connected)
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(250));
            counter++;
        }
        double_t timeInSec = static_cast<double_t>(counter*250)/1000;
        LOG_MOD(NOTICE, logmod)<<"Total time span to get modem connected: "<<timeInSec <<"seconds";
        #endif // DAQEMULATOR
        CURL *curl  = curl_easy_init();
        if (curl)
            {
                #ifndef DEBUGDAQ
				curl_easy_setopt(curl, CURLOPT_CAPATH, "/usr/share/ca-certificates");
				curl_easy_setopt(curl, CURLOPT_CAINFO, "/usr/share/ca-certificates/Navistar-APIM.pem");
				#endif
                /***** POST *****/
                curl_easy_setopt(curl, CURLOPT_URL, "http://developer.sandbox.oncommandconnection.com");
                curl_easy_setopt(curl, CURLOPT_NOBODY, 1 );
                CURLcode res = curl_easy_perform(curl);
                curl_easy_cleanup(curl);
                curl = nullptr;
                if (res == CURLE_OK)
                    {
                        LOG_MOD(INFO, logmod)<<"Internet Connection available";
                        return true;
                    }
                else
                    {
                        LOG_MOD(ERROR, logmod)<<"CloudServicesModel::CheckInternetConnectivity failed: "<<curl_easy_strerror(res);
                    }
            }
        LOG_MOD(WARNING, logmod)<<"Internet Connection not available";
        return false;
    }
