#include "DaqBuffer.h"
#include <Record.h>

using namespace DaqApp;

//This should be one container that can be extended or reset to a FIFO
DaqBuffer::DaqBuffer()
    {
        mSampledBuffer = std::vector<Record>();
        mPreBuffer = boost::circular_buffer<Record>();
    }

DaqBuffer::~DaqBuffer()
    {
    }
