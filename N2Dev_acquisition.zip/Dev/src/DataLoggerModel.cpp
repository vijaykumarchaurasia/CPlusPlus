#include <ecu/logging.h>
#include "AppManager.h"
#include "DataLoggerModel.h"
#include "EventsManagerModel.h"
#include "ConfigurationManagerModel.h"
#include "DataAccessModel.h"
#include "FileWriterModel.h"
#include "SystemStateReceiver.h"
#include "CommonHeader.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.DataLoggerModel");
    }
using namespace DaqApp;

DataLoggerModel::DataLoggerModel(AppManager* passedAppManger, const DataLoggerConfig& passedDLConfig,
                                    const ActivateDataConfig& passedActivateDataConfig):
mAppManagerHandle(passedAppManger),
mEventsManagerHandle(passedAppManger->GetEventsManagerModel()),
mDataAccessModelHandle(passedAppManger->GetDataAccessModel()),
mTimeUtilitiesHandle(passedAppManger->GetTimeUtilities()),
mConfManagerModelHandle(passedAppManger->GetConfigurationModel()),
mDaqBuffer(std::make_unique<DaqBuffer>()),
mCurrentlySampling(false),
mStartingEventIsSet(false),
mEndingEventIsSet(false),
mBufferThresHold(0),
mPeriodicTickId(0),
mPreBufferTickId(0),
mSamplingTickId(0),
mPostBufferTickId(0),
mConfig(passedDLConfig),
mSystemStateReceiverPtr(passedAppManger->GetSystemStateReceiver()),
mFileWriterMessage(),
mActivateDataConfig(passedActivateDataConfig)
    {
        LOG_MOD(NOTICE, logmod)<<"Creation: DataLoggerModel";
    }

DataLoggerModel::~DataLoggerModel()
    {
        LOG_MOD(NOTICE, logmod)<<"Destruction: DataLoggerModel";
        mTimeUtilitiesHandle->ReleaseTick(mPeriodicTickId);
        mTimeUtilitiesHandle->ReleaseTick(mPreBufferTickId);
        mTimeUtilitiesHandle->ReleaseTick(mSamplingTickId);
        mTimeUtilitiesHandle->ReleaseTick(mPostBufferTickId);
        mDaqBuffer->mPreBuffer.clear();
        mDaqBuffer->mSampledBuffer.clear();
    }

void DataLoggerModel::SetUpDataLogger()
    {
        SamplingProtocols protocol = mConfig.proto;
        if( SamplingProtocols::TRIP_DATA != protocol)   // Don't start sampling if protocol is trip data
        {
            if(SamplingProtocols::XCP == protocol)
            {
                mEventsManagerHandle->ConnectToSignal(XCP_ERROR_TRIGGERED_SIGNAL,boost::bind(&DataLoggerModel::StopSamplingOnError,this));
			}
            //initializing mconfig in ctor causes a crash, needs investigation
            mBufferThresHold = std::min(mConfig.MaxSetSize,mConfig.MaxTransmitPeriod); //whichever comes first = smallest val per req
            mStartingEventIsSet = mConfig.StartingEventId.size();
            mEndingEventIsSet   = mConfig.EndingEventId.size();
            mDaqBuffer->mPreBuffer.resize(mConfig.PreBufferSize);
            PrintDataLoggerDetails();

            WriteFileWriterMessageValues();
            switch(mConfig.TriggerTypeId)
                {
                    case TriggerType::Periodic:
                    mFileWriterMessage.TriggerTypeId = TriggerType::Periodic;
                    if( SamplingProtocols::EAL == protocol)
                        {
                            mEventsManagerHandle->ConnectToSignal(mConfig.UdsSignalName,boost::bind(&DataLoggerModel::OnPeriodic,this));
                            LOG_MOD(NOTICE, logmod)<<"DataLogger connected to EAL data signal "<<mConfig.UdsSignalName<<std::endl;
                        }
                    else
                        {
                            mPeriodicTickId = mTimeUtilitiesHandle->Tick(ms(mConfig.SamplingRate), Redundancy::Infinite, &DataLoggerModel::OnPeriodic,this);
                        }
                    break;

                    case TriggerType::EventDriven:
                    mFileWriterMessage.TriggerTypeId = TriggerType::EventDriven;
                    AttachPreBuffer();
                    if(mEventsManagerHandle->ConnectToSignal(mConfig.StartingEventId,boost::bind(&DataLoggerModel::OnStartEvent,this)))
                        {
                            LOG_MOD(NOTICE, logmod)<<"DataLogger StartSampling Event "<< mConfig.StartingEventId;
                        }
                    else
                        {
                            throw std::invalid_argument("DataLogger No such starting event signal found "+mConfig.StartingEventId);
                        }
                    if(!mEndingEventIsSet)
                        {
                            LOG_MOD(NOTICE, logmod)<<"DataLogger Ending event id is empty...";
                        }
                    else if(mEventsManagerHandle->ConnectToSignal(mConfig.EndingEventId,boost::bind(&DataLoggerModel::OnStopEvent,this)))
                        {
                           LOG_MOD(NOTICE, logmod)<<"DataLogger StopSampling Event "<< mConfig.EndingEventId;
                        }
                    else
                        {
                            throw std::invalid_argument("DataLogger No such ending event signal found "+mConfig.EndingEventId);
                        }
                    break;

                    default:
                    throw std::invalid_argument("Invalid DataLogger trigger type");
                    break;
                }
                mEventsManagerHandle->ConnectToSignal(mSystemStateReceiverPtr->PostponableShutDownEvent,boost::bind(&DataLoggerModel::OnShutdownSignalEvent,this));
            }
    }

// This should be checked at configuration manager level !, will be moved later
void DataLoggerModel::PrintDataLoggerDetails()
    {

        LOG_MOD(NOTICE, logmod)<<"___________DataLogger Received___________ \n"   <<
                                "\n PreBufferSize : "        <<mConfig.PreBufferSize    <<
                                "\n SamplingRate : "         <<mConfig.SamplingRate     <<
                                "\n PostBufSize : "          <<mConfig.PostBufferSize   <<
                                "\n MaxSetSize : "           <<mConfig.MaxSetSize       <<
                                "\n MaxTransmitPeriod : "    <<mConfig.MaxTransmitPeriod<<
                                "\n StartingEvent : "        <<mConfig.StartingEventId  <<
                                "\n EndingEvent : "          <<mConfig.EndingEventId    <<
                                "\n BufferThreshold : "      <<mBufferThresHold         <<
                                "\n ____________________________________ \n"          ;

    }

void DataLoggerModel::OnPeriodic()
    {
        mDaqBuffer->mSampledBuffer.push_back(mDataAccessModelHandle->GetRecord(mConfig.ConfigID));
        mCurrentlySampling = true;
        if (mDaqBuffer->mSampledBuffer.size() >= mBufferThresHold)
            {
                SendBufferToFile();
            }
    }

void DataLoggerModel::OnStartEvent()
    {
        LOG_MOD(NOTICE, logmod)<<"______START EVENT CALLED ______";
        if(not mCurrentlySampling)
            {
                StopPreBufferSampling();
                CopyPreBuffer();
                mCurrentlySampling = true;
                AddStartingEventTimestamp();
                mSamplingTickId= mTimeUtilitiesHandle->Tick(ms(mConfig.SamplingRate), Redundancy::Infinite, &DataLoggerModel::AddRecordsToNormalBuffer,this);
            }
        else
            {
                LOG_MOD(ERROR, logmod)<<"DataLogger: start sampling event called while sampling...call ignored";
            }
    }

void DataLoggerModel::AddRecordsToNormalBuffer()
    {
        mDaqBuffer->mSampledBuffer.push_back(mDataAccessModelHandle->GetRecord(mConfig.ConfigID));
        if (mDaqBuffer->mSampledBuffer.size() >= mBufferThresHold)
            {
                SendBufferToFile();
            }
        else if (not mEndingEventIsSet) //and (!mConfig.PostBufferSize))//stop at no ending EV and no post buf
            {
                mTimeUtilitiesHandle->ReleaseTick(mSamplingTickId);
                mSamplingTickId = 0;
                mCurrentlySampling = false;
                SendBufferToFile();
                AttachPreBuffer();
            }
        else
            {
                LOG_MOD(NOTICE, logmod)<<"DataLogger sampling in normal buffer...";
            }
    }

void DataLoggerModel::OnStopEvent()
    {
        LOG_MOD(NOTICE, logmod)<<"______STOP EVENT CALLED ______";
        if((mEndingEventIsSet and mConfig.PostBufferSize) and mCurrentlySampling)
            {
                mTimeUtilitiesHandle->ReleaseTick(mSamplingTickId);
                AddEndingEventTimestamp();
                mSamplingTickId = 0;
                mPostBufferTickId= mTimeUtilitiesHandle->Tick(ms(mConfig.SamplingRate), Redundancy::Infinite, &DataLoggerModel::AddRecordsToPostBuffer,this);
            }
        else if((mEndingEventIsSet and mCurrentlySampling) and (!mConfig.PostBufferSize))
            {
                mTimeUtilitiesHandle->ReleaseTick(mSamplingTickId);
                mSamplingTickId = 0;
                mCurrentlySampling = false;
                AddEndingEventTimestamp();
                SendBufferToFile();
                AttachPreBuffer();
            }
        else
            {
                LOG_MOD(WARNING, logmod)<<"DataLogger ending event called before starting event, call ignored";
            }
    }

void DataLoggerModel::AddRecordsToPostBuffer()
    {
        static unsigned int counter ;
        if (mDaqBuffer->mSampledBuffer.size() >= mBufferThresHold)
            {
                SendBufferToFile();
            }
        else
            {
                if(mConfig.PostBufferSize > counter)
                    {
                        LOG_MOD(NOTICE, logmod)<<"DataLogger sampling in post buffer buffer...";
                        mDaqBuffer->mSampledBuffer.push_back(mDataAccessModelHandle->GetRecord(mConfig.ConfigID));
                        counter++;
                    }
                else
                    {
                        counter = 0;
                        mCurrentlySampling = false;
                        mTimeUtilitiesHandle->ReleaseTick(mPostBufferTickId);
                        mPostBufferTickId = 0;
                        SendBufferToFile();
                        AttachPreBuffer();
                    }
            }
    }

void DataLoggerModel::SendBufferToFile()
    {
        mAppManagerHandle->GetFileWriterModel()->WriteOutputFile(mDaqBuffer->mSampledBuffer, mFileWriterMessage);
        LOG_MOD(NOTICE, logmod)<<"DataLogger buffer sent to FileWriter...";
        mDaqBuffer->mSampledBuffer.clear();
        mFileWriterMessage.StartingEventDateTimestamps.clear();
        mFileWriterMessage.EndingEventDateTimestamps.clear();
    }

void DataLoggerModel::AttachPreBuffer()
    {
        if((mConfig.PreBufferSize) and (TriggerType::Periodic not_eq mConfig.TriggerTypeId))
            {
                LOG_MOD(NOTICE, logmod)<<"DataLogger Prebuffer enabled!";
                mPreBufferTickId = mTimeUtilitiesHandle->Tick(ms(mConfig.SamplingRate), Redundancy::Infinite, &DataLoggerModel::AddRecordsToPreBuffer,this);
            }
    }

void DataLoggerModel::AddRecordsToPreBuffer()
    {
        if(not mCurrentlySampling)  //when normal sampling is active pre buffer sampling should not be active
            {
              LOG_MOD(NOTICE, logmod)<<"DataLogger sampling in Prebuffer...";
              mDaqBuffer->mPreBuffer.push_back(mDataAccessModelHandle->GetRecord(mConfig.ConfigID));
            }
    }

void DataLoggerModel::StopPreBufferSampling()
    {
        if(mPreBufferTickId)
        {   LOG_MOD(NOTICE, logmod)<<"DataLogger Prebuffer stopped!";
            mTimeUtilitiesHandle->ReleaseTick(mPreBufferTickId);
            mPreBufferTickId = 0;
        }
    }

void DataLoggerModel::CopyPreBuffer()
    {
        if((mConfig.PreBufferSize) and (TriggerType::Periodic not_eq mConfig.TriggerTypeId) and (not mCurrentlySampling))
            {
                LOG_MOD(NOTICE, logmod)<<"Prebuffer copied";
                for(const auto& preBufferData :  mDaqBuffer->mPreBuffer)
                    {
                        mDaqBuffer->mSampledBuffer.push_back(preBufferData);
                    }
            }
    }

std::vector<Record>& DataLoggerModel::GetNormalBuffer()
    {
        return mDaqBuffer->mSampledBuffer;
    }

boost::circular_buffer<Record>& DataLoggerModel::GetPreBuffer()
    {
        return mDaqBuffer->mPreBuffer;
    }

void DataLoggerModel::OnShutdownSignalEvent()
    {
        // For all types of shutdown signals / states release the tick
        if (mCurrentlySampling)
            {
                if(mSystemStateReceiverPtr->RequestShutdownPostpone())
                    {
                        // If shutdown signal is triggered in between of sampling process then, OnStopEvent() will not be invoked.
                        // So EndingEventDateTimestamps will be empty.
                        mFileWriterMessage.EndingEventDateTimestamps = {};
                        mTimeUtilitiesHandle->ReleaseTick(mPeriodicTickId);
                        SendBufferToFile();
                        mTimeUtilitiesHandle->ReleaseTick(mSamplingTickId);
                        mTimeUtilitiesHandle->ReleaseTick(mPreBufferTickId);
                        mTimeUtilitiesHandle->ReleaseTick(mPostBufferTickId);
                    }
                mTimeUtilitiesHandle->ReleaseTick(mSamplingTickId);
                mTimeUtilitiesHandle->ReleaseTick(mPreBufferTickId);
                mTimeUtilitiesHandle->ReleaseTick(mPostBufferTickId);
                mTimeUtilitiesHandle->ReleaseTick(mPeriodicTickId);
            }
    }

Priority DataLoggerModel::GetPriority(const std::string& priority)
    {
        if ("high" == priority)
            {
                return Priority::HIGH;
            }
        else if ("normal" == priority)
            {
                return Priority::NORMAL;
            }
        else if ("low" == priority)
            {
                return Priority::LOW;
            }
        else
            {
                return Priority::InvalidPriority;
            }
    }

void DataLoggerModel::WriteFileWriterMessageValues()
    {
        mFileWriterMessage.MessageFormatVersion     = mConfig.MessageFormatVersion;
        mFileWriterMessage.DataSamplingConfigId     = mConfig.DataSamplingConfigId;
        mFileWriterMessage.SamplingProtocolId       = mConfig.proto;
        mFileWriterMessage.ConfigID                 = mConfig.ConfigID;

        mFileWriterMessage.PriorityId = GetPriority(mActivateDataConfig.DataPriority);
        if(mDataAccessModelHandle->ReadMisc("8207").size())
            {
                mFileWriterMessage.TelematicsBoxId  = mDataAccessModelHandle->ReadMisc("8207"); // get product_serial_number
            }
        std::string esn = mDataAccessModelHandle->ReadMisc("588"); // Get Engine Serial Number (esn) for Cummins
        if(esn.size())
            {
                mFileWriterMessage.ComponentSerialNumber    = esn;
                mFileWriterMessage.ESN                      = esn;
            }

        std::string vin = mDataAccessModelHandle->ReadMisc("237"); // Get Vehicle Identification Number (vin) for Navistar
        if(vin.size())
            {
                mFileWriterMessage.VIN = vin;
            }

        std::string tspName = NAVISTAR_TSP_NAME;
        std::string contactNumber = "(331) 332-5000";
        mFileWriterMessage.TSPName = NAVISTAR_TSP_NAME;
        // If configuration is for Cummins, then set below paramater values
        if(ConfigFrom::Cummins == mConfManagerModelHandle->GetActivatedConfigFrom())
            {
                tspName = CUMMINS_TSP_NAME;
                contactNumber = "(331) XXX-XXXX"; // TODO: NJ: Take valid contact number for Cummins
                mFileWriterMessage.TSPName = CUMMINS_TSP_NAME;
            }

        mFileWriterMessage.Description = "This data file is the property of " + tspName + ". \
Any use or sale of the data by non-" + tspName + " employees constitutes theft which is prosecutable as \
a crime.  If this data has inadvertently come into your possession please destroy it and \
notify " + tspName + " immediately at " + contactNumber + ".";

    }

void DataLoggerModel::AddStartingEventTimestamp()
    {
        // For event driven data sampling, start & end timestamp shall be ppopulated with the DateTimestamps of each
        // instance of the starting event and ending event. (Requirement from "NGDI File Upload Process.pdf",section: 1.9.2.1.1.1)
        mFileWriterMessage.StartingEventDateTimestamps.push_back(mTimeUtilitiesHandle->GetTimeDate());
        if(!mEndingEventIsSet)
            {
                // If no ending event is specified, both rows in .csv file shall be populated with the DateTimestamp(s) of the starting event(s).
                // (Requirement from "NGDI File Upload Process.pdf",section: 1.9.2.1.1.1)
                mFileWriterMessage.EndingEventDateTimestamps = mFileWriterMessage.StartingEventDateTimestamps;
            }
    }

void DataLoggerModel::AddEndingEventTimestamp()
    {
        mFileWriterMessage.EndingEventDateTimestamps.push_back(mTimeUtilitiesHandle->GetTimeDate());
    }


void DataLoggerModel::StopSamplingOnError()
    {
        LOG_MOD(NOTICE, logmod)<<"StopSamplingOnError...";
        mAppManagerHandle->GetFileWriterModel()->WriteXCPErrorLogFile(mFileWriterMessage);
        mTimeUtilitiesHandle->ReleaseTick(mSamplingTickId);
        mTimeUtilitiesHandle->ReleaseTick(mPreBufferTickId);
        mTimeUtilitiesHandle->ReleaseTick(mPostBufferTickId);
        mTimeUtilitiesHandle->ReleaseTick(mPeriodicTickId);

        mSamplingTickId = 0;
        mPreBufferTickId = 0;
        mPostBufferTickId = 0;
        mPeriodicTickId = 0;
    }
