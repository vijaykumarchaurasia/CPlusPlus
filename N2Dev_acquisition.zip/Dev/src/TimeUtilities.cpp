#include <chrono>
#include <string>
#include <date/date.h>
#include <iomanip>
#include "TimeUtilities.h"
using namespace DaqTime;
unsigned long int TimeUtilities::mThreadID = 0;

TimeUtilities::TimeUtilities() noexcept:
mStartedAt(TimeNow())
    {
    }

TimeUtilities::~TimeUtilities()
    {
    }

void TimeUtilities::init() noexcept
    {
        mStartedAt = TimeNow();
    }

void TimeUtilities::PrintDuration() noexcept
    {
        auto timePoint = TimeNow();
        mDuration = (std::chrono::duration_cast<ms>(timePoint - mStartedAt).count());
        std::cout<< "It took "<< mDuration << "MilliSeconds to execute this operation"<<std::endl;
        mDuration = (std::chrono::duration_cast<us>(timePoint - mStartedAt).count());
        std::cout<< "It took "<< mDuration << "MicroSeconds to execute this operation"<<std::endl;
        mDuration = (std::chrono::duration_cast<ns>(timePoint - mStartedAt).count());
        std::cout<< "It took "<< mDuration << "Nano Seconds to execute this operation"<<std::endl;
    }

ms TimeUtilities::GetDuration() noexcept
    {
        const std::lock_guard<std::mutex> lock(mMutex);
        mDuration = (std::chrono::duration_cast<ms>(TimeNow() - mStartedAt).count());
        return ms(mDuration);
    }

void TimeUtilities::PrintTime()
    {
        const long int currentTime = std::chrono::system_clock::to_time_t(TimeNow());
        std::cout << ctime(&currentTime) << std::endl;
    }

const std::string TimeUtilities::GetTimeDate() noexcept
    {
        auto now = std::chrono::system_clock::now();
        return date::format("%FT%TZ", date::floor<std::chrono::milliseconds>(now)); // return YYYY-MM-DDTHH:MM:SS.sssZ
    }

void TimeUtilities::ReleaseTick(TickId passedID)
    {
		const std::lock_guard<std::mutex> lock(mMutex);
		if(passedID > 0)
			{
				mFuncRef.erase(passedID);
			}
    }

bool TimeUtilities::IsActiveCall(TickIdPtr passed)
    {
        const std::lock_guard<std::mutex> lock(mMutex);
        bool DoesExist = false;
        for(auto it = mFuncRef.begin(); it != mFuncRef.end(); ++it)
            {
                if(it->second == passed)
                    {
                        DoesExist = true;
                        break;
                    }
            }
        return DoesExist;
    }

const std::string TimeUtilities::GetTimeDate(DateTime dt)
    {
        time_t currTime;
        time (&currTime);
        struct tm* gmTime = gmtime(&currTime);
        std::stringstream iss;
        iss.fill('0');
        if (DateTime::TxtDate == dt)   // generate date string : YYYYMMDD
            {
                iss << 1900 + gmTime->tm_year << std::setw(2) << 1 + gmTime->tm_mon << std::setw(2) << gmTime->tm_mday;
            }
        else if (DateTime::TxtTime == dt)   // generate time string : HHMMSSsss
            {
                std::chrono::system_clock::time_point tPoint = std::chrono::system_clock::now();
                const std::chrono::duration<double> tse = tPoint.time_since_epoch();
                std::chrono::seconds::rep milliseconds = std::chrono::duration_cast<std::chrono::milliseconds>(tse).count() % 1000;
                iss << gmTime->tm_hour << std::setw(2) << gmTime->tm_min << std::setw(2) << gmTime->tm_sec << milliseconds;
            }
        return iss.str();
    }

std::map<TickId, TickIdPtr>* TimeUtilities::GetFunctionMap()
    {
        return &mFuncRef;
    }
