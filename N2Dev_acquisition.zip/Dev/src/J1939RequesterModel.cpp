#include <ecu/logging.h>
#include "J1939RequesterModel.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.J1939RequesterModel");
    }
using namespace DaqApp;

J1939RequesterModel::J1939RequesterModel(PgnRequestClient_ptr pgnClient, ITransportClient_ptr tClient, double pgn, uint8_t dest_addr, TimeUtilities* passed, bool passedDoOnce):
mPgnClientPtr(pgnClient),
mTransportClientPtr(tClient),
mTimeUtilitiesHandlePtr(passed),
mPGN(pgn),
mTickIdRequest(0),
mDoOnce(passedDoOnce),
mDestAddr(dest_addr)
    {
         LOG_MOD(NOTICE, logmod)<<"Creation: J1939RequesterModel for PGN"<<pgn;
         if (!passedDoOnce)
             {
                mTickIdRequest = mTimeUtilitiesHandlePtr->Tick(ms(2000), Redundancy::Infinite, &J1939RequesterModel::RequestPGN,this);
                LOG_MOD(NOTICE, logmod)<<"J1939OnRequester:  "<<mPGN<<" mTickIdRequest: "<<mTickIdRequest;
             }
         else
             {
                mTickIdRequest = mTimeUtilitiesHandlePtr->Tick(ms(1), Redundancy::DoOnce, &J1939RequesterModel::RequestPGN,this);
             }
    }

J1939RequesterModel::~J1939RequesterModel()
    {
        mTimeUtilitiesHandlePtr->ReleaseTick(mTickIdRequest);
        LOG_MOD(NOTICE, logmod)<<"Destruction: J1939RequesterModel for PGN "<<mPGN;
    }

void J1939RequesterModel::RequestPGN()
    {
        LOG_MOD(NOTICE, logmod)<<"J1939OnRequester: RequestPGN: "<<mPGN<<" mTickIdRequest: "<<mTickIdRequest;
        auto& signal_adapter = SignalAdapter::instance();
        auto sg_create_result = signal_adapter.create_sg(TOPIC_TEL_PGN_REQUEST_4A);
        if ( sg_create_result.ok() )
            {
                auto signal_group = sg_create_result.take_val();
                if ( (signal_group.set_signal_scaled_value(mSignalName, mPGN)) && (signal_group.set_signal_data(mDestAddrName, {mDestAddr})) )
                    {
                        //Pack SignalGroup into com::Message instance
                         auto pack_result = signal_adapter.pack(signal_group);
                         if ( pack_result.ok() )
                             {
                                 Message message = pack_result.take_val();
                                 if( nullptr != mTransportClientPtr )
                                     {
                                	 	 uint8_t counter = 0;
                                	 	 do{
                                             PgnRequestClient::TokenResult token_result = mPgnClientPtr->get_request_token(TOPIC_TEL_PGN_REQUEST_4A, std::chrono::seconds(2));
                                             if(token_result.ok())
                                                 {
                                                     LOG_MOD(INFO, logmod)<< "J1939RequesterModel Acquired PGN request token!!for Pgn "<<mPGN;
                                                      //Publish on J1939Sampler
                                                      if( mTransportClientPtr->publish(TOPIC_TEL_PGN_REQUEST_4A, message) != 0)
                                                          {
                                                             LOG_MOD(NOTICE, logmod)<< "J1939RequesterModel Published message successfully for Pgn "<<mPGN;
                                                             break;
                                                          }
                                                      else
                                                          {
                                                             LOG_MOD(ERROR, logmod)<< "J1939RequesterModel Failed to Publish message for Pgn "<<mPGN << " Retrying in 1 second";
                                                          }
                                                  }
                                              else
                                              {
                                                 LOG_MOD(NOTICE, logmod)<< "J1939RequesterModel PGN request token for Pgn "<<mPGN << " is busy. Retrying in 1 second";
                                              }
                                             std::this_thread::sleep_for(std::chrono::milliseconds(1000));
                                             counter++;
                                             if (counter >= 30){
                                            	 LOG_MOD(ERROR, logmod)<< "J1939RequesterModel Unable to acquire PGN request token!!for Pgn "<<mPGN << " for 30 seconds";
                                             }
                                	 	 }while(counter < 30);

                                     }
                             }
                    }
            }
        else
            {
                LOG_MOD(NOTICE, logmod) << "J1939RequesterModel Invalid Signal for topic: " << TOPIC_TEL_PGN_REQUEST_4A;
            }
    }
