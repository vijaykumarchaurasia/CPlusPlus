#include <ecu/logging.h>
#include "CustomEventModel.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.CustomEventModel");
    }
using namespace DaqApp;

CustomEventModel::CustomEventModel()
    {
        LOG_MOD(NOTICE, logmod) << "Creation: CustomEventModel";
    }

CustomEventModel::~CustomEventModel()
    {
        LOG_MOD(NOTICE, logmod) << "Creation: CustomEventModel";
    }

