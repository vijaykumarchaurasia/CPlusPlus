#include "SamplerModel.h"

using namespace DaqApp;

SamplerModel::SamplerModel()
    {
    }

SamplerModel::~SamplerModel()
    {
    }

