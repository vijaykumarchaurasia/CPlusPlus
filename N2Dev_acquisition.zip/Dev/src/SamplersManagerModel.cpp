#include <ecu/logging.h>
#include "SamplersManagerModel.h"
#include "AppManager.h"
#include "ConfigurationManagerModel.h"
#include "DataAccessModel.h"
#include "UdsSampler.h"
#include "XcpSampler.h"
#include "J1939Sampler.h"
#include "DtcSamplerModel.h"
#include "GpsSampler.h"
#include "UdsSampler.h"
#include "ClientManagerModel.h"
#include "StaticDataSampler.h"
#include "Utils.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.SamplersManagerModel");
    }
using namespace DaqApp;

SamplersManagerModel::SamplersManagerModel(AppManager* passed):
mAppManHandlePtr(passed),
mConfigManagerModelPtr(passed->GetConfigurationModel()),
mSamplers()
    {
        LOG_MOD(NOTICE, logmod)<<"Creation: SamplersManagerModel";
        mSamplers.reserve(200);//SDK J1939 sampler limit 200
    }

SamplersManagerModel::~SamplersManagerModel()
    {
        mSamplers.clear();
        LOG_MOD(NOTICE, logmod)<<"Destruction: SamplersManagerModel";
    }

void SamplersManagerModel::InitSystemParams()
{
    #ifndef DAQEMULATOR
    mSamplers.emplace_back(std::make_unique<StaticDataSampler>(mAppManHandlePtr, mAppManHandlePtr->GetClientManagerModel()->getTransportClient()));
    #endif // DAQEMULATOR
}

void SamplersManagerModel::SetUpSamplersManager()
    {
        mTransportClientPtr = mAppManHandlePtr->GetClientManagerModel()->getTransportClient();

        #ifndef DAQEMULATOR

        // TODO : NJ : Revisit logic for "fetching 1st element from GPSSasmpler vector" after supporting multiple configurations

       if(mConfigManagerModelPtr->GetGpsSamplerConfig().size()>0)
       {
            // Need to implement for supporting multiconfig
            GpsSamplerConfig gpsConfig = mAppManHandlePtr->GetConfigurationModel()->GetGpsSamplerConfig().at(0);
            if(gpsConfig.IsLatitude || gpsConfig.IsLongitude || gpsConfig.IsAltitude || gpsConfig.IsDirection_Heading || gpsConfig.IsGPS_Vehicle_Speed )
            {
                mSamplers.emplace_back(std::make_unique<GpsSampler>(mTransportClientPtr,mAppManHandlePtr));
            }
       }

        if(mConfigManagerModelPtr->GetXCPConfig().size()>0)
        {
            mSamplers.push_back(std::make_unique<XcpSampler>(mTransportClientPtr, mAppManHandlePtr));
        }


        if ( mConfigManagerModelPtr->GetUdsConfig().size() > 0)
        {
                mSamplers.emplace_back(std::make_unique<UdsSampler>(mTransportClientPtr, mConfigManagerModelPtr->GetUdsConfig(), mAppManHandlePtr));
        }

        #endif // DAQEMULATOR
        for (const auto& j1939Config : mConfigManagerModelPtr->GetJ1939Config())
            {
                if(!DaqApp::utils::IsNumber(j1939Config.Spn) && j1939Config.Pgn != "-1")
                    {
                        mSamplers.emplace_back(std::make_unique<DtcSamplerModel>(mAppManHandlePtr, mTransportClientPtr, j1939Config));
                    }
                else if (j1939Config.Topic !="Not Set" && DaqApp::utils::IsNumber(j1939Config.Pgn))
                    {
                        mSamplers.emplace_back(std::make_unique<J1939Sampler>(mTransportClientPtr,j1939Config, mAppManHandlePtr));
                    }
                else
                    {
                        LOG_MOD(WARNING, logmod)<<"SamplersManager: Invalid J1939Config Message, no sampler created for  ";
                        LOG_MOD(WARNING, logmod)<<"Topic "<<j1939Config.Topic<< ", with Signal "<<j1939Config.Signal
                                                   <<", SPN = "<<j1939Config.Spn<<" PGN= "<<j1939Config.Pgn;
                    }
            }
    }
