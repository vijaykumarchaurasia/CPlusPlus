#include <sstream>
#include <thread>
#include <iomanip>
#include <ecu/logging.h>
#include "UdsSampler.h"
#include "DataAccessModel.h"
#include "AppManager.h"
#include "TimeUtilities.h"
#include "AppManager.h"
#include "KeyAlgorithm.h"
#include "DataAccessModel.h"
#include "FileWriterModel.h"
#include "CommonHeader.h"
#include "ConfigurationManagerModel.h"
#include "SystemStateReceiver.h"
#include "EventsManagerModel.h"
#include "SamplerModel.h"

namespace {
   auto logmod = ecu::lapi::logging::module("DaqApp.UdsSampler");
}
using namespace DaqApp;
using namespace ecu::lapi::com;
using namespace ecu::lapi::diag;


UdsSampler::UdsSampler(ITransportClient_ptr client, std::vector<UDSConfigMessage> &vectUDSconfigmessage, AppManager* app_manager_passed):
m_client(client),
mSdkCallBackPtr(new CallBackHelper(this)),
mApp_manager_passed(app_manager_passed),
mTimeUtilitiesHandlePtr(app_manager_passed->GetTimeUtilities()),
mVecUDSConfigMessage(vectUDSconfigmessage),
mEcuTarget(0),
mUDSSamplerFailedRetries(0),
mLALSeed(0),
mTripDataTick(0),
mUDSHandlerTick(0),
mTesterPresentTick(0),
mUDSInterfaceStatus(UdsInterfaceState::UDS_IF_STATE_UNKNOWN),
mSystemStateReceiverPtr(app_manager_passed->GetSystemStateReceiver())
{
	for (const auto& config : mVecUDSConfigMessage){
		if(config.IsEALData == true)	//EAL Data
		{
			std::stringstream key;
			key << std::uppercase << std::hex << std::setfill('0') << std::setw(2) << static_cast<int>((uint8_t)(config.DDID >> 8));
			key << std::uppercase << std::hex << std::setfill('0') << std::setw(2) << static_cast<int>((uint8_t)(config.DDID & 0x00FF));
			mApp_manager_passed->GetDataAccessModel()->Write(key.str(), "", Protocol::EAL, config.ConfigID);
			ConfigIDMap.insert(std::pair<std::string, UDSConfigMessage>(key.str(), config));
			mApp_manager_passed->GetEventsManagerModel()->AddSignal(config.UdsSignalName);
		}
		else if(true == config.IsTripData)
        {
            WriteFileWriterMessageValues(config);
        }
	}

    if( InitializeClient(client) )
    {
    	LOG_MOD(NOTICE, logmod) << "UDSSampler::UDSSampler(): UDS Sampler created.";
    }

    // Subscribe to OTA Topic
    if (m_client != NULL)
    {
        LOG_MOD(NOTICE, logmod) << "UDSSampler::UDSSampler(): Subscribing OTA Topic";
        m_client->subscribe(CMISessionRcvTopic, 0, mSdkCallBackPtr);
    }

    //SamplingProtocols protocol = mApp_manager_passed->GetConfigurationModel()->GetDataLoggerConfig().at(0).proto;
}

UdsSampler::~UdsSampler()
{
	LOG_MOD(NOTICE, logmod)<<"UDSSampler:  UDS Sampler  Destructor.  ";

	StopPeriodicRequests();

	//Releasing UDS Interface
	if (m_uds_client_ptr != NULL ){
		m_uds_client_ptr->release_interface();
	}
}

void UdsSampler::StopPeriodicRequests(void){

	DeleteThread(mUDSHandlerTick);
	DeleteThread(mEAL$22RequestTick);
	DeleteThread(mTripDataTick);
	DeleteThread(mTesterPresentTick);
}

void UdsSampler::DeleteThread(TickId& tick){
	if (tick > 0){
		mTimeUtilitiesHandlePtr->ReleaseTick(tick);
		tick = 0;
	}
}

void UdsSampler::DeleteThread(std::unordered_map<uint16_t, TickId>& mapOfTicks){

	for (auto& pair:mapOfTicks){
		if ( pair.second > 0 ){
			mTimeUtilitiesHandlePtr->ReleaseTick(pair.second);
			pair.second = 0;
		}
	}

	mapOfTicks.clear();

}

bool UdsSampler::InitializeClient(ITransportClient_ptr client)
{
    m_uds_client_ptr = create_uds_client(client, this);
    if(m_uds_client_ptr == nullptr)
    {
        LOG_MOD(ERROR, logmod)<< "  UDSSampler::  failed  creating  m_uds_client_ptr ";
        return false;
    }
    return true;
}

/*
 * Message() Callback:
 * -Start/Stop: Check Requested status
 * 		- If match with current status; send ACK
 * 		- If doesn't match with current status;
 * 			- Start -> Stop;
 * 				- Check if HandleUDS() has finished; If not, wait and check again, if the wait takes longer than 5 seconds, kill the UDS interface
 * 				- Check if UDS client is being used (Request/response pending); If so, wait and check again
 * 				- Delete all threads, De-allocate UDS interface, send Ack
 * 				- Change internal state variable to STOP
 * 			- Stop -> Start;
 * 				- Change internal state variable to Start (HandleUDS() should start working);
 * 				- Send Ack
 *
 * - Status: Send Active = Start, Inactive = stop
 */
void UdsSampler::message(const std::string& topic, const Message& message)
{
	std::lock_guard<std::mutex> lock(mOTACallbackMutex);
	if ( topic != CMISessionRcvTopic){
		return;
	}

	//Decode received source and data string
	std::vector<uint8_t> buf = message.get_buffer();

	std::string extractedStr(buf.begin(), buf.end());

	size_t pos = extractedStr.find(",");
	std::string sender = extractedStr.substr(0, pos);
	std::string request = extractedStr.substr(pos+1, extractedStr.length());

	LOG_MOD(NOTICE, logmod) << "Message Received: Sender--> " << sender << " Request--> " << request;

	if (sender != "ota"){
		return;
	}

	if (request == "CMISessionStart"){
		if ( CMISessionActive == true ){
			Publish(request, "ACK");
		}
		else{	//Stop -> Start
			CMISessionActive = true;
			mUDSHandlerTick = mTimeUtilitiesHandlePtr->Tick(ms(250), Redundancy::DoOnce, &UdsSampler::HandleUDSSampling, this);
			Publish(request, "ACK");
		}
	}
	else if (request == "CMISessionStop"){
		if ( CMISessionActive == false ){
			Publish(request, "ACK");
		}
		else{	//Start -> Stop

			StopPeriodicRequests();
			LOG_MOD(WARNING, logmod) << "Stopping UDS Periodic Requests";

			int counter = 0;
			while ( (UDSInitInProgress == true) || (mUDSInterfaceStatus == UDS_IF_STATE_BUSY) ){
				std::this_thread::sleep_for(std::chrono::milliseconds(1000));
				LOG_MOD(WARNING, logmod) << "Failed to stop UDS Client because busy 1 sec";
				counter++;
				if(counter >= 5)
				{
					LOG_MOD(ERROR, logmod)<<"Failed to stop UDS Client for 5 sec. Killing UDS Interface";
					counter = 0;
					break;
				}
			}

			CMISessionActive = false;
			m_uds_client_ptr->release_interface_async();
			Publish(request, "ACK");
		}
	}
	else if (request == "CMISessionStatus"){
		if (CMISessionActive == true){
			Publish(request, "active");
		}
		else{
			Publish(request, "inactive");
		}
	}

}

void UdsSampler::Publish(std::string ota_request, std::string response){

	std::string str_msg = "ota," + ota_request + "," + response;
	LOG_MOD(NOTICE, logmod)<< "UdsSampler::Publish(): Publishing to OTA App -> " << str_msg;

	Message msg;
	Message::DataBuffer data_buff(str_msg.begin(), str_msg.end());
	msg.set_buffer(std::move(data_buff));

	if ( (m_client != NULL) && (m_client->publish(CMISessionPubTopic, msg) != 0)){
		LOG_MOD(NOTICE, logmod) << "Message Published Successfully";
	}
	else{
		LOG_MOD(ERROR, logmod) << "Failed to Publish Message";
	}
}

void UdsSampler::HandleUDSSampling(void)
{
	if (m_uds_client_ptr == NULL ){	return;}

	// If Status != CMISessionStart; return
	// If status == CMISessionStart; Go ahead
	if ( CMISessionActive == false ){
		LOG_MOD(ERROR, logmod) << "UDSSampler::HandleUDSSampling(): Sampler awaits for Start signal from OTA App.";
		return;
	}

	LOG_MOD(NOTICE, logmod) << "UDSSampler::HandleUDSSampling(): Allocating UDS Client.";
	UDSInitInProgress = true;
	UdsInterfaceState result = m_uds_client_ptr->allocate_interface(alloc_config);

	DeleteThread(mEAL$22RequestTick);	//Release previous periodic request tick
	DeleteThread(mTripDataTick);
	DeleteThread(mTesterPresentTick);

	mTesterPresentTick = mTimeUtilitiesHandlePtr->Tick(ms(mTesterPresentRequestPeriodms), Redundancy::Infinite, &UdsSampler::TesterPresentRequest, this);

	if( result == UdsInterfaceState::UDS_IF_STATE_READY
			&& UpdateDeviceId()
			&& StartTelematicsSession()
			&& AuthenticateECU() )
	{
		LOG_MOD(NOTICE, logmod) << "UDSSampler::HandleUDSSampling(): Telematics Session Started.";

		mUDSSamplerFailedRetries = 0;

		// Go though each data configuration from config file
		std::vector<UDSConfigMessage>::iterator itr = mVecUDSConfigMessage.begin();
		while(itr < mVecUDSConfigMessage.end())
		{
			if(itr->IsEALData)	//EAL Data
			{
				if ( SendEALData$BARequest(*itr) ){
					if (itr->TransmissionRate > 0){		//Periodic Request
						//Register Function for periodic call
						mEAL$22RequestTick.insert(std::pair<uint16_t, TickId>(itr->DDID, mTimeUtilitiesHandlePtr->Tick(ms(itr->TransmissionRate), Redundancy::Infinite, &UdsSampler::EALData$22Request, this, *itr)));
					}
					else {		//Request only once
						EALData$22Request(*itr);
					}
				}
			}
			else if (itr->IsTripData) // Trip Data
			{
				//SendTripDataRequest((*itr).isPartialExtraction);
				if (( SendTripDataRequest(itr->isPartialExtraction) ) && ( itr->TransmissionRate > 0 )){
					//Register Function for periodic call
					mTripDataTick = mTimeUtilitiesHandlePtr->Tick(ms(itr->TransmissionRate), Redundancy::Infinite, &UdsSampler::SendTripDataRequest, this, (*itr).isPartialExtraction);
				}
			}
			itr = (itr + 1);
			mApp_manager_passed->GetEventsManagerModel()->ConnectToSignal(mSystemStateReceiverPtr->PostponableShutDownEvent,boost::bind(&UdsSampler::OnShutdownSignalEvent,this));
		}
	}
	else{
		mUDSSamplerFailedRetries++;

		LOG_MOD(ERROR, logmod)<< "UDSSampler::HandleUDSSampling(): Unable to start Telematics session. UDS Interface Status--> " << result;

		if ( mUDSSamplerFailedRetries < 5 ){
			LOG_MOD(WARNING, logmod)<< "UDSSampler::Retrying Initialization # " << mUDSSamplerFailedRetries;
			mUDSHandlerTick = mTimeUtilitiesHandlePtr->Tick(ms(1000), Redundancy::DoOnce, &UdsSampler::HandleUDSSampling, this);
		}else{
			StopPeriodicRequests();
			LOG_MOD(ERROR, logmod)<< "UDSSampler:: Number of retries exceeded limit";
		}
	}

	UDSInitInProgress = false;
}


UdsSampler::UdsResponse UdsSampler::SendSyncRequest(UdsMessage request){
	UdsResponse rtnValue;
	rtnValue.data.clear();

	if (CMISessionActive == false){
		LOG_MOD(ERROR, logmod)<< "UDSSampler::SendSyncRequest(): CMI Session Stopped. ";
		return rtnValue;
	}

	if (m_uds_client_ptr == NULL){	return rtnValue;	}

	if( (mUDSInterfaceStatus == UDS_IF_STATE_BUSY) || (mUDSInterfaceStatus == UDS_IF_STATE_TIMEOUT) || (mUDSInterfaceStatus == UDS_IF_STATE_UNKNOWN) ){
		LOG_MOD(WARNING, logmod)<< "UDSSampler::SendSyncRequest(): UDS Interface Status Not Ready --> " << mUDSInterfaceStatus;

		UdsInterfaceState result = m_uds_client_ptr->allocate_interface(alloc_config);

		if( result != UDS_IF_STATE_READY){
			LOG_MOD(ERROR, logmod)<< "UDSSampler::SendSyncRequest(): Retry to Allocate Interface Failed --> " << result;
			return rtnValue;
		}
	}
	std::lock_guard<std::mutex> sync_rqst_lock(mUDSRequestMtx);
	UdsClient::RequestResult response = m_uds_client_ptr->send_request(request);
	if ( response.nok() ){
		LOG_MOD(ERROR, logmod) << "UDSSampler::SendSyncRequest(): Response Invalid - " << response.err_val();
	}
	else{
		//Check for positive response
		if ( (!response.val().data.empty()) && (*response.val().data.begin() == (*request.data.begin() + 0x40)) ){
			rtnValue.isPositive = true;
			rtnValue.data = response.val().data;
		}
		else if ( (!response.val().data.empty()) && (*response.val().data.begin() == 0x7F) ){
			rtnValue.isNegative = true;
			if ( response.val().data.size() >= 3 ){
				rtnValue.NRC = response.val().data[2];
			}
		}
		else{
			LOG_MOD(ERROR, logmod) << "UDSSampler::SendSyncRequest(): Empty Response";
		}
	}
	return rtnValue;
}


bool UdsSampler::AuthenticateECU(void){

	if ( !RequestSeed(LALSEED) ){	// LAL Seed
		LOG_MOD(ERROR, logmod) << "UDSSampler::AuthenticateECU(): LAL Seed request Failed";
		return false;
	}

	CumminsAccessTokenResponse obj = mApp_manager_passed->GetFilesHandlingModel()->GetCloudServicesPtr()->CumminsAccessToken(mLALSeed, mDeviceId);

	if ( obj.SessionKey.empty() || obj.AccessKey.empty() ){
		LOG_MOD(ERROR, logmod) << "UDSSampler::AuthenticateECU(): Session Or Access Key from Cloud Empty";
		return false;
	}
	std::vector<uint8_t> sessionKey = ConvertStringToByteVector(obj.SessionKey);
	mAccessKey = ConvertStringToByteVector(obj.AccessKey);

	UdsMessage request;
	UdsResponse response;

	//Send Session Key from Cloud to ECU
	request.data.clear();
	request.address = mEcuTarget;
	request.data.push_back(0x27);
	request.data.push_back(0x14);
	request.data.insert(request.data.end(), sessionKey.begin(), sessionKey.end());

	response = SendSyncRequest(request);

	if ( response.isPositive != true ){
		LOG_MOD(ERROR, logmod) << "UDSSampler::AuthenticateECU(): ECU Rejected Session Key";
		return false;
	}

	if ( !RequestSeed(EALSEED) ){	//EAL Seed
		LOG_MOD(ERROR, logmod) << "UDSSampler::AuthenticateECU(): EAL Seed request Failed";
		return false;
	}


	//Add Tool ID, version, Instance to EAL Seed
	mEALSeed.push_back(0x00);
	mEALSeed.push_back(0x30);
	for(int i = 6; i < 16; i++)
	   mEALSeed.push_back('\0');

	// Add EAL Seed to UnEncrypted 32-bit Session Key
	mUnEncryptedKey[0] = mEALSeed[0] + (mEALSeed[1] << 8) + (mEALSeed[2] << 16) + (mEALSeed[3] << 24);
	mUnEncryptedKey[1] = mEALSeed[4] + (mEALSeed[5] << 8) + (mEALSeed[6] << 16) + (mEALSeed[7] << 24);
	mUnEncryptedKey[2] = mEALSeed[8] + (mEALSeed[9] << 8) + (mEALSeed[10] << 16) + (mEALSeed[11] << 24);
	mUnEncryptedKey[3] = mEALSeed[12] + (mEALSeed[13] << 8) + (mEALSeed[14] << 16) + (mEALSeed[15] << 24);


	encipherBigEndianTEA(mAccessKey.data(), &mUnEncryptedKey[0], &mAccessToken[0]);
	encipherBigEndianTEA(mAccessKey.data(), &mUnEncryptedKey[2], &mAccessToken[2]);

	std::vector<uint8_t> AccessToken;

	// Convert 32-bit to 8 bit and push in AccessToken
	AccessToken.push_back( (uint8_t)(mAccessToken[0] & 0x000000FF) );
	AccessToken.push_back( (uint8_t)((mAccessToken[0] & 0x0000FF00) >>  8) );
	AccessToken.push_back( (uint8_t)((mAccessToken[0] & 0x00FF0000) >>  16) );
	AccessToken.push_back( (uint8_t)((mAccessToken[0] & 0xFF000000) >>  24) );

	AccessToken.push_back( (uint8_t)(mAccessToken[1] & 0x000000FF) );
	AccessToken.push_back( (uint8_t)((mAccessToken[1] & 0x0000FF00) >>  8) );
	AccessToken.push_back( (uint8_t)((mAccessToken[1] & 0x00FF0000) >>  16) );
	AccessToken.push_back( (uint8_t)((mAccessToken[1] & 0xFF000000) >>  24) );

	AccessToken.push_back( (uint8_t)(mAccessToken[2] & 0x000000FF) );
	AccessToken.push_back( (uint8_t)((mAccessToken[2] & 0x0000FF00) >>  8) );
	AccessToken.push_back( (uint8_t)((mAccessToken[2] & 0x00FF0000) >>  16) );
	AccessToken.push_back( (uint8_t)((mAccessToken[2] & 0xFF000000) >>  24) );

	AccessToken.push_back( (uint8_t)(mAccessToken[3] & 0x000000FF) );
	AccessToken.push_back( (uint8_t)((mAccessToken[3] & 0x0000FF00) >>  8) );
	AccessToken.push_back( (uint8_t)((mAccessToken[3] & 0x00FF0000) >>  16) );
	AccessToken.push_back( (uint8_t)((mAccessToken[3] & 0xFF000000) >>  24) );

	request.data.clear();
	request.address = mEcuTarget;
	request.data.push_back(0x27);
	request.data.push_back(0x12);
	request.data.insert(request.data.end(), AccessToken.begin(), AccessToken.end());

	response = SendSyncRequest(request);

	if ( response.isPositive != true ){
		LOG_MOD(ERROR, logmod) << "UDSSampler::AuthenticateECU(): ECU Rejected Access Token for EAL Access";
		return false;
	}

	return true;

}

std::vector<uint8_t> UdsSampler::ConvertStringToByteVector(const std::string strToConvert){
	std::vector<uint8_t> rtnValue;
	uint16_t i = 0;

	while (i < strToConvert.size()){
		rtnValue.push_back( (uint8_t)std::stoi(strToConvert.substr(i, 2), nullptr, 16) );
		i+= 2;
	}
	return rtnValue;
}

void UdsSampler::on_connection_change(UdsInterfaceState state)
{
	mUDSInterfaceStatus = state;
}

void UdsSampler::on_response(UdsMessage resultMsg)
{

}

bool UdsSampler::UpdateDeviceId()
{
	UdsMessage deviceIDRequest;
	UdsResponse response;

	deviceIDRequest.address = 0;

	deviceIDRequest.data.push_back(0x22);
	deviceIDRequest.data.push_back(0xC5);
	deviceIDRequest.data.push_back(0x12);

	std::stringstream buff;

	response = SendSyncRequest(deviceIDRequest);

	if ( response.isPositive == true ){
		//Erase existing Device Id
		mDeviceId.clear();

		std::vector<uint8_t>::iterator itr = response.data.begin();
		itr+=3;

		//Update Device Id
		while ( itr < response.data.end() ){
			buff << std::setfill('0') << std::setw(2) << static_cast<int>(*itr);
			itr = itr +1;
		}

		mDeviceId = buff.str();
		return true;
	}

	return false;
}


bool UdsSampler::StartTelematicsSession(void)
{
	UdsMessage request;
	UdsResponse response;

	request.data.clear();
	request.address = mEcuTarget;
	request.data.push_back(0x10);
	request.data.push_back(0x40);

	response = SendSyncRequest(request);

	if ( response.isPositive != true ){
		LOG_MOD(ERROR, logmod)<< "UDSSampler::StartTelematicsSession(): Request Failed";
		return false;
	}

	return true;
}

bool UdsSampler::TesterPresentRequest(void){
	UdsMessage request;
	UdsResponse response;

	request.data.clear();
	request.address = mEcuTarget;
	request.data.push_back(0x3E);
	request.data.push_back(0x00);

	response = SendSyncRequest(request);

	if ( response.isPositive != true ){
		LOG_MOD(ERROR, logmod)<< "UDSSampler::TesterPresentRequest(): Request Failed";
		return false;
	}

	return true;
}

bool UdsSampler::RequestSeed(SeedID rqstType)
{
	bool rtnValue = false;
	UdsMessage request;
	UdsResponse response;

	request.data.clear();
	request.address = mEcuTarget;
	request.data.push_back( 0x27);
	request.data.push_back((uint8_t)rqstType);

	response = SendSyncRequest(request);

	if ( response.isPositive == true ){
		std::vector<uint8_t>::iterator itr = response.data.begin();
		itr+=2;

		if ( rqstType == LALSEED ){	//LAL Seed
			mLALSeed = 0;
			while(itr < response.data.end()){
				mLALSeed = ((uint32_t)*itr) | (mLALSeed << 8);
				itr = (itr + 1);
			}
		}
		else{	//EAL Seed
			mEALSeed.clear();
			while(itr < response.data.end()){
				mEALSeed.push_back(*itr);
				itr = itr + 1;
			}
		}
		rtnValue = true;

	}
	else{
		rtnValue = false;
		LOG_MOD(ERROR, logmod)<< "UDSSampler::RequestSeed(): Request Failed";
	}

	return rtnValue;
}

bool UdsSampler::SendTripDataRequest(const bool isPartial)
{
	std::lock_guard<std::mutex> lock(mTripDataMtx);		//If periodic request timer tick calls this function before it is finished executing previous call
	UdsMessage request;
	UdsResponse response;
	uint8_t extraction = isPartial ? 0x00 : 0x01;
	UdsMessage resultMsg;
	bool endOfData = false;
	int NRC22RetryCounter = 0;
	int NRC72RetryCounter = 0;

	request.address = mEcuTarget;
	request.data = { 0x31, 0x01, 0xF0, 0xCA, extraction };

	do{

		response = SendSyncRequest(request);

		if ( (response.isPositive == true) && (response.data.size() > 4)){
			endOfData = ProcessTripDataAndCheckEOD(response.data);

			NRC22RetryCounter = 0;		//Reset counters
			NRC72RetryCounter = 0;
		}
		else{
			switch (response.NRC){
				case 0x21:		//ECU Busy
				{
					LOG_MOD(WARNING, logmod)<< "UDSSampler::SendTripDataRequest(): ECU Busy. Retrying in 100 ms";
					std::chrono::milliseconds ms(100);
					std::this_thread::sleep_for(ms);
					break;
				}
				case 0x22:		//Conditions Not Correct: Retry request 3 times
				{
					NRC22RetryCounter++;

					if( NRC22RetryCounter > 3 ){
						LOG_MOD(ERROR, logmod)<< "UDSSampler::SendTripDataRequest(): NRC-22. Max retries reached. Killing Trip Data Requests";

						DeleteThread(mTripDataTick);

						if (mEAL$22RequestTick.empty()){		//if there is no EAL thread open, kill Tester Present requests too
							DeleteThread(mTesterPresentTick);
						}
						return false;
					}

					LOG_MOD(ERROR, logmod)<< "UDSSampler::SendTripDataRequest(): NRC-22. Retrying # " << NRC22RetryCounter;
					break;
				}
				case 0x33:		//Authentication Failed: Retry Authentication
				{
					LOG_MOD(ERROR, logmod)<< "UDSSampler::SendTripDataRequest(): Authentication Failed";
					StopPeriodicRequests();

					LOG_MOD(ERROR, logmod)<< "UDSSampler: Retrying Authentication in 1 Sec";
					mUDSHandlerTick = mTimeUtilitiesHandlePtr->Tick(ms(1000), Redundancy::DoOnce, &UdsSampler::HandleUDSSampling, this);

					return false;
				}
				case 0x72:		//Programming Failure: Retry once
				{
					NRC72RetryCounter++;

					if( NRC72RetryCounter > 1 ){
						LOG_MOD(ERROR, logmod)<< "UDSSampler::SendTripDataRequest(): NRC-72. Max retries reached. Killing Trip Data Requests";

						DeleteThread(mTripDataTick);

						if (mEAL$22RequestTick.empty()){		//if there is no EAL thread open, kill Tester Present requests too
							DeleteThread(mTesterPresentTick);
						}
						return false;
					}

					LOG_MOD(ERROR, logmod)<< "UDSSampler::SendTripDataRequest(): NRC-72. Retrying # " << NRC72RetryCounter;
					break;
				}
				default:
				{
					LOG_MOD(ERROR, logmod)<< "UDSSampler::SendTripDataRequest(): Killing Trip Data Request Due to Negative Response - " << std::hex << static_cast<int>(response.NRC);
					DeleteThread(mTripDataTick);

					if (mEAL$22RequestTick.empty()){		//if there is no EAL thread open, kill Tester Present requests too
						DeleteThread(mTesterPresentTick);
					}
					return false;
				}
			}
		}
	}while(endOfData != true);

	return true;
}

bool UdsSampler::ProcessTripDataAndCheckEOD(std::vector<uint8_t> data){
	std::vector<uint8_t>::iterator itr = data.begin();
    std::stringstream key;
    bool isTripData = false;
 	std::vector<uint8_t> receivedData;

	receivedData.clear();

    while (itr < data.end()){
    	if (itr < (data.begin() + 2)){	//Skip first 2 bytes
    		itr = itr + 1;
    		continue;
    	}
    	else if ((itr >= (data.begin() + 2)) && (itr < (data.begin() + 6))){
    		if ( (*itr == 0xF0) && (itr+1 <= data.end()) && ((*(itr+1) == 0xCA))){
    			key << std::hex << *itr;
    			itr = itr + 1;
    			key << std::hex << *itr;
    			isTripData = true;
    		}
    	}
    	else if ((itr >= (data.begin() + 6))){
    		receivedData.push_back(*itr);
    	}
    	itr = itr + 1;
    }

    if(isTripData == true){
    	//Checking if last 2 bytes are 0xFF
    	uint8_t secondToLastBytePos = receivedData.size()-2;
    	uint8_t lastBytePos = receivedData.size()-1;

		if ((receivedData[secondToLastBytePos] == 0xFF) && (receivedData[lastBytePos] == 0xFF)){
			return true;		//Skip writing this data to file
    	}
    	else
    	{
            mApp_manager_passed->GetFileWriterModel()->WriteOutputFile(receivedData, mFileWriterMessage);
    	}
    }

    return false;
}

bool UdsSampler::SendEALData$BARequest(UDSConfigMessage &requestData)
{
	UdsMessage request;
	request.address = mEcuTarget;

	request.data = { 0xBA, 0x02 };
	request.data.push_back((uint8_t)(requestData.DDID >> 8));
	request.data.push_back((uint8_t)(requestData.DDID & 0x00FF));
	request.data.insert(request.data.end(), requestData.dataIds.begin(), requestData.dataIds.end());

	UdsResponse response = SendSyncRequest(request);

	if ( response.isPositive != true ){
		switch (response.NRC){
			case 0x22:		//Retry 3 times
			{
				LOG_MOD(ERROR, logmod)<< "UDSSampler::SendEALData$BARequest(): NRC-22 Retrying 3 times";
				for (int i = 0; i < 3; i++){
					UdsResponse response = SendSyncRequest(request);
					if ( response.isPositive == true ){	return true;}
				}
				return false;
			}
			case 0x33:
			{
				LOG_MOD(ERROR, logmod)<< "UDSSampler::SendEALData$BARequest(): NRC-33 Authentication Failed";
				StopPeriodicRequests();

				LOG_MOD(ERROR, logmod)<< "UDSSampler: Retrying Authentication in 1 Sec";
				mUDSHandlerTick = mTimeUtilitiesHandlePtr->Tick(ms(1000), Redundancy::DoOnce, &UdsSampler::HandleUDSSampling, this);

				break;
			}
			case 0x72:		//Retry Once
			{
				LOG_MOD(ERROR, logmod)<< "UDSSampler::SendEALData$BARequest(): NRC-72 Retrying 3 times";
				UdsResponse response = SendSyncRequest(request);
				return response.isPositive;
			}
			default:
				return false;
		}
	}

	return true;
}

bool UdsSampler::EALData$22Request(UDSConfigMessage &requestData){
	UdsMessage request;
	request.address = mEcuTarget;
	std::stringstream key;
	std::stringstream recordData;

	request.data.push_back(0x22);
	request.data.push_back((uint8_t)(requestData.DDID >> 8));
	request.data.push_back((uint8_t)(requestData.DDID & 0x00FF));

	key << std::uppercase << std::hex << std::setfill('0') << std::setw(2) << static_cast<int>((uint8_t)(requestData.DDID >> 8));
	key << std::uppercase << std::hex << std::setfill('0') << std::setw(2) << static_cast<int>((uint8_t)(requestData.DDID & 0x00FF));

	UdsResponse response = SendSyncRequest(request);

	static int NRC22RetryCounter = 0;
	static int NRC72RetryCounter = 0;

	if ( response.isPositive != true ){
		switch (response.NRC){
			case 0x22:		//Retry 3 times
			{
				if (NRC22RetryCounter >= 3){
					LOG_MOD(ERROR, logmod)<< "UDSSampler::EALData$22Request(): NRC-22 Max Attempts exceeded limit. Killing EDL requests for DDID: " << std::hex << static_cast<int>(requestData.DDID);

					DeleteThread(mEAL$22RequestTick.at(requestData.DDID));
					mEAL$22RequestTick.erase(requestData.DDID);
					if (mEAL$22RequestTick.empty() && mTripDataTick == 0){
						DeleteThread(mTesterPresentTick);
					}
				}

				NRC22RetryCounter++;
				LOG_MOD(ERROR, logmod)<< "UDSSampler::EALData$22Request(): NRC-22 Retrying # " << NRC22RetryCounter;
				return false;
			}
			case 0x33:
			{
				LOG_MOD(ERROR, logmod)<< "UDSSampler::SendEALData$BARequest(): NRC-33 Authentication Failed";
				StopPeriodicRequests();

				LOG_MOD(ERROR, logmod)<< "UDSSampler: Retrying Authentication in 1 Sec";
				mUDSHandlerTick = mTimeUtilitiesHandlePtr->Tick(ms(1000), Redundancy::DoOnce, &UdsSampler::HandleUDSSampling, this);

				return false;
			}
			case 0x72:		//Retry Once
			{
				if (NRC72RetryCounter >= 1){
					LOG_MOD(ERROR, logmod)<< "UDSSampler::EALData$22Request(): NRC-72 Max Attempts exceeded limit. Killing EDL requests for DDID: " << std::hex << static_cast<int>(requestData.DDID);

					DeleteThread(mEAL$22RequestTick.at(requestData.DDID));
					mEAL$22RequestTick.erase(requestData.DDID);
					if (mEAL$22RequestTick.empty() && mTripDataTick == 0){
						DeleteThread(mTesterPresentTick);
					}
				}

				NRC72RetryCounter++;
				LOG_MOD(ERROR, logmod)<< "UDSSampler::EALData$22Request(): NRC-72 Retrying # " << NRC72RetryCounter;
				return false;
			}
			default:
			{
				LOG_MOD(ERROR, logmod)<< "UDSSampler::EALData$22Request(): Failed Request. Killing EDL requests for DDID: " << std::hex << static_cast<int>(requestData.DDID);

				DeleteThread(mEAL$22RequestTick.at(requestData.DDID));
				mEAL$22RequestTick.erase(requestData.DDID);
				if (mEAL$22RequestTick.empty() && mTripDataTick == 0){
					DeleteThread(mTesterPresentTick);
				}
				return false;
			}
		}
	}
	else{
		NRC22RetryCounter = 0;
		NRC72RetryCounter = 0;
	}

	std::vector<uint8_t>::iterator itr = response.data.begin();

	if ( response.data.size() < 10){
		LOG_MOD(ERROR, logmod)<< "UDSSampler::EALData$22Request(): Response Size is less than expected";
		return false;
	}

	uint8_t encKeySize = response.data[1];

	itr = itr + 1;

	if ( itr < response.data.end() ){

		//Copy the size of encryption key first
		recordData << std::uppercase << std::hex << std::setfill('0') << std::setw(2) << static_cast<int>(encKeySize);

		if ( encKeySize != 0x00 ){	//Encryption Key embedded in EAL data
			itr = itr + 1;

			//Copy the encryption key itself
			while ( (itr < response.data.end()) && (itr < (response.data.begin() + encKeySize + 2)) ) {
				recordData << std::uppercase << std::hex << std::setfill('0') << std::setw(2) << static_cast<int>(*itr);
				itr = itr + 1;
			}

			//Encryption Key saved. Skip DDID and save rest of data
			if ( (*itr == (uint8_t)(requestData.DDID >> 8)) && (*(itr + 1) == (uint8_t)(requestData.DDID & 0x00FF)) ){
				itr+= 2;	//Skip DDID

				//Save rest of data
				while ( itr < response.data.end() ){
					recordData << std::uppercase << std::hex << std::setfill('0') << std::setw(2) << static_cast<int>(*itr);
					itr = itr + 1;
				}

				mApp_manager_passed->GetDataAccessModel()->Write(key.str(), recordData.str(), Protocol::EAL, ConfigIDMap.at(key.str()).ConfigID);
				mApp_manager_passed->GetEventsManagerModel()->EmitSignal(ConfigIDMap.at(key.str()).UdsSignalName);
			}
			else{
				LOG_MOD(ERROR, logmod)<< "UDSSampler::EALData$22Request(): Response DDID does not match request DDID";
				return false;
			}
		}
		else{	//No Key embedded in EAL data

			//Verify DDID is same as request
			if ( (*(itr + 1) == (uint8_t)(requestData.DDID >> 8)) && (*(itr + 2) == (uint8_t)(requestData.DDID & 0x00FF))){
				itr+= 3;	//Skip DDID
			}
			else{
				LOG_MOD(ERROR, logmod)<< "UDSSampler::EALData$22Request(): Response DDID does not match request DDID";
				return false;
			}

			while (itr < response.data.end()){
				recordData << std::uppercase << std::hex << std::setfill('0') << std::setw(2) << static_cast<int>(*itr);
				itr = itr + 1;
			}

			mApp_manager_passed->GetDataAccessModel()->Write(key.str(), recordData.str(), Protocol::EAL, ConfigIDMap.at(key.str()).ConfigID);
			mApp_manager_passed->GetEventsManagerModel()->EmitSignal(ConfigIDMap.at(key.str()).UdsSignalName);
		}
	}
	else{

		LOG_MOD(ERROR, logmod)<< "UDSSampler::EALData$22Request(): Response Empty/Invalid";
		return false;
	}

	return true;
}

void UdsSampler::WriteFileWriterMessageValues(const auto& udsConfig)
{
    mFileWriterMessage.SamplingProtocolId = SamplingProtocols::TRIP_DATA;

    for(const auto& activateDataConfig : mApp_manager_passed->GetConfigurationModel()->GetActivateDataConfig())
    {
        if ( udsConfig.ConfigID == activateDataConfig.ConfigID )
        {
            mFileWriterMessage.PriorityId = GetPriority(activateDataConfig.DataPriority);
            break;
        }
    }

    if(mApp_manager_passed->GetDataAccessModel()->ReadMisc("8207").size())
    {
        mFileWriterMessage.TelematicsBoxId  = mApp_manager_passed->GetDataAccessModel()->ReadMisc("8207"); // get product_serial_number
    }

    mFileWriterMessage.TSPName = CUMMINS_TSP_NAME;  // Since Cummins is supporting EAL & TRIP_DATA (UDS protocol) , TSP name would be "Cummins"
}

Priority UdsSampler::GetPriority(const std::string& priority)
{
    if ("high" == priority)
        {
            return Priority::HIGH;
        }
    else if ("normal" == priority)
        {
            return Priority::NORMAL;
        }
    else if ("low" == priority)
        {
            return Priority::LOW;
        }
    else
        {
            return Priority::InvalidPriority;
        }
}

void UdsSampler::OnShutdownSignalEvent()
    {
        StopPeriodicRequests();
    }
