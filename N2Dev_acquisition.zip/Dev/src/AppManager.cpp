#include <assert.h>
#include <chrono>
#include <ecu/logging.h>
#include "AppManager.h"
#include "ConfigurationManagerModel.h"
#include "SamplersManagerModel.h"
#include "DataAccessModel.h"
#include "DataLoggerModel.h"
#include "EventsManagerModel.h"
#include "FileWriterModel.h"
#include "FilesHandlingModel.h"
#include "SystemStateReceiver.h"
#include "ClientManagerModel.h"
#include "CloudServicesModel.h"
#include "CommonHeader.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.AppManager");
    }
using namespace DaqApp;

AppManager::AppManager():
mTimeUtilitiesPtr       (std::make_unique<TimeUtilities>()),
mClientManagerModelPtr  (std::make_unique<ClientManagerModel>(this)),
mEventsManagerModelPtr  (std::make_unique<EventsManagerModel>(this)),
mSystemStateReceiverPtr (std::make_unique<SystemStateReceiver>(this)),
mDataAccessModelPtr     (std::make_unique<DataAccessModel>(this)),
mFilesHandlingModelPtr  (std::make_unique<FilesHandlingModel>(this)),
mFileWriterModelPtr     (std::make_unique<FileWriterModel>(this)),
mConfigurationManagerPtr(std::make_unique<ConfigurationManagerModel>(this)),
mSamplersManagerModelPtr(std::make_unique<SamplersManagerModel>(this)),
mDataLoggerModels()
    {
        LOG_MOD(NOTICE, logmod) << "Creation: AppManager done creating models";
        // Reserved space for only 4 objects because as of now we are supporting maximum 4 configuration files only.
        mDataLoggerModels.reserve(4);
    }

AppManager::~AppManager()
    {
        LOG_MOD(NOTICE, logmod) << "Destruction: AppManager";
    }

void AppManager::StartApp()
    {
        GetClientManagerModel()->SetUpClientManager();
        GetSamplersManagerModel()->InitSystemParams();
        GetSystemStateReceiver()->SetupSystemStateReceiver(GetClientManagerModel()->getTransportClient());
        GetFilesHandlingModel()->SetUpFilesHandlingModel();
        GetFilesHandlingModel()->GetCloudServicesPtr()->SetUpCloudServicesModel();
        GetEventsManagerModel()->ConnectToSignal(NOSUFFICIENTSPACE,boost::bind(&AppManager::HandleLowSpacescenario,this));
        if(!GetFilesHandlingModel()->IsSuffciceintSpace())
            {
                //Low disk space prerequisite
                GetEventsManagerModel()->EmitSignal(NOSUFFICIENTSPACE);
                LOG_MOD(WARNING, logmod) << "Free space is not sufficient to run the app ";
            }
        GetConfigurationModel()->SetUpConfigurationManager();
        std::vector<DataLoggerConfig> dataLoggerConfig = GetConfigurationModel()->GetDataLoggerConfig();
        std::vector<ActivateDataConfig> activateDataConfig = GetConfigurationModel()->GetActivateDataConfig();
        // For whatever number of config received from cloud, create that much number of instances for DataLoggerModel
        // No need to handle for UDS - TripData, already handled in UDSSampler
        for(uint index=0; index < dataLoggerConfig.size(); index++)
        {
            for(ActivateDataConfig& ActivateConfig:activateDataConfig)
            {
                if(dataLoggerConfig.at(index).ConfigID == ActivateConfig.ConfigID)
                {
                    mDataLoggerModels.emplace_back(std::make_unique<DataLoggerModel>(this, dataLoggerConfig.at(index), activateDataConfig.at(index)));
                }
            }
        }
        GetSamplersManagerModel()->SetUpSamplersManager();
        GetEventsManagerModel()->SetUpEventsManager();
        // For each instance of DataLoggerModel, invoke SetUpDataLogger() function
        for(uint index=0; index < mDataLoggerModels.size(); index++)
        {
            mDataLoggerModels.at(index)->SetUpDataLogger();
        }
    }

TimeUtilities* AppManager::GetTimeUtilities()
    {
        assert (nullptr != mTimeUtilitiesPtr);
        return mTimeUtilitiesPtr.get();
    }

FilesHandlingModel* AppManager::GetFilesHandlingModel()
{
        assert(nullptr != mFilesHandlingModelPtr);
        return mFilesHandlingModelPtr.get();
}

DataAccessModel* AppManager::GetDataAccessModel()
    {
        assert(nullptr != mDataAccessModelPtr);
        return mDataAccessModelPtr.get();
    }

FileWriterModel* AppManager::GetFileWriterModel()
    {
        assert(nullptr != mFileWriterModelPtr);
        return mFileWriterModelPtr.get();
    }

ConfigurationManagerModel* AppManager::GetConfigurationModel()
    {
        assert(nullptr != mConfigurationManagerPtr);
        return mConfigurationManagerPtr.get();
    }

SamplersManagerModel* AppManager::GetSamplersManagerModel()
    {
        assert(nullptr != mSamplersManagerModelPtr);
        return mSamplersManagerModelPtr.get();
    }

EventsManagerModel* AppManager::GetEventsManagerModel()
    {
        assert(nullptr != mEventsManagerModelPtr);
        return mEventsManagerModelPtr.get();
    }

std::vector <std::unique_ptr<DataLoggerModel>>& AppManager::GetDataLoggerModel()
    {
        return mDataLoggerModels;
    }

SystemStateReceiver* AppManager::GetSystemStateReceiver()
    {
        assert(nullptr != mSystemStateReceiverPtr);
        return mSystemStateReceiverPtr.get();
    }

ClientManagerModel* AppManager::GetClientManagerModel()
    {
        assert(nullptr != mClientManagerModelPtr);
        return mClientManagerModelPtr.get();
    }

void AppManager::HandleLowSpacescenario()
{
    while(!GetFilesHandlingModel()->IsSuffciceintSpace())
    {
        LOG_MOD(ERROR, logmod) << "Free space is not sufficient to run the app";
        GetEventsManagerModel()->EmitSignal(FILE_WRITING_COMPLETED_SIGNAL);
        std::this_thread::sleep_for(std::chrono::seconds(5));
    }
}
