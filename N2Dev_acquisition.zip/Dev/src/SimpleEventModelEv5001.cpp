#include <ecu/logging.h>
#include "AppManager.h"
#include "DataAccessModel.h"
#include "EventsManagerModel.h"
#include "SimpleEventModelEv5001.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.SimpleEventModelEv5001");
    }
using namespace DaqApp;
using namespace DaqTime;

SimpleEventModelEv5001::SimpleEventModelEv5001(EventConfigMessage config_message, EventsManagerModel *passed_ptr, AppManager* passed_app_manger_ptr):
mAppManagerHandlePtr(passed_app_manger_ptr),
mEventsManagerHandlerPtr(passed_ptr),
mConfigMessage(config_message)
    {
        mEventID = ("EV5001");
        LOG_MOD(NOTICE, logmod)<<"Creation:"<<mEventID;
        mIsActive = false;
        mEventsManagerHandlerPtr->AddSignal(mEventID);
    }

SimpleEventModelEv5001::~SimpleEventModelEv5001()
    {
        LOG_MOD(NOTICE, logmod)<<"Destruction: EV5001";
    }

//Pre definedevent 5001 for any active event.
void SimpleEventModelEv5001::Evaluate()
    {
        LOG_MOD(INFO, logmod)<<"EV5001 Evaluating current status is"<< mIsActive;
        std::string  dm2_curr_val = mAppManagerHandlePtr->GetDataAccessModel()->Read("inactiveFaultCodes",mConfigMessage.ConfigID); //Read DM2 message
        if((!dm2_curr_val.empty()) && (dm2_curr_val == "spn:0~fmi:0~count:0|"))
            {
                mPrevVal = "spn:0~fmi:0~count:0|";
                mIsActive = false;
            }
        else if((dm2_curr_val != mPrevVal) && (dm2_curr_val.size()))
            {
                LOG_MOD(NOTICE, logmod)<<"EV5001 Emitted received inactiveFaultCodes = "<<dm2_curr_val<<std::endl;
                mEventsManagerHandlerPtr->EmitSignal("EV5001");
                mPrevVal = dm2_curr_val;
                mIsActive = true;
            }
    }
