#define N2_SHARED_OBJECT_FOR_E39_MD1
#include <sstream>
#include <iomanip>
#include <ecu/logging.h>
#include "nsk.h"
#include "AppManager.h"
#include "CommonHeader.h"
#include "ConfigurationManagerModel.h"
#include "DataAccessModel.h"
#include "XcpSampler.h"
#include "XcpClientModel.h"
#include "DataLoggerModel.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.XcpSampler");
    }
using namespace DaqApp;
using namespace ecu::lapi::diag;

XcpSampler::XcpSampler(ecu::lapi::com::ITransportClient_ptr client,
                       AppManager* app_manager_passed):
mTransportClientPtr(client),
mXCPEcuPropertiesConfigMsg(app_manager_passed->GetConfigurationModel()->GetXcpEcuPropertiesConfig()),
mDataAccessModelPtr(app_manager_passed->GetDataAccessModel()),
mEventsManagerModelPtr(app_manager_passed->GetEventsManagerModel()),
mIsErrorOccurred(false)
    {
        LOG_MOD(NOTICE, logmod)<< "Creation: XcpSampler";
        mEventsManagerModelPtr->AddSignal(XCP_ERROR_TRIGGERED_SIGNAL);
        mXCPClientModelPtr = std::make_unique<XcpClientModel>(app_manager_passed);
        mXCPInterfaceState = ecu::lapi::diag::CP_IF_STATE_UNKNOWN;
        InitializeXcpInterface();
        SetEcuProperties();
        SampleXcpData();
    }

XcpSampler::~XcpSampler()
    {
        LOG_MOD(NOTICE, logmod)<< "Destruction: XcpSampler";
        StartAndStopDaqList(XcpCmd::StopList);
    }

bool XcpSampler::InitializeXcpInterface()
    {
        bool return_value = false;
        CpInterfaceState xcp_interface_state = ecu::lapi::diag::CP_IF_STATE_UNKNOWN;
        XcpInterfaceAllocationConfig xcp_interface_configuration = mXCPEcuPropertiesConfigMsg.xcp_interface_allocation_configuration;
        mXCPClientPtr = create_xcp_client(mTransportClientPtr,this);
        if(mXCPClientPtr)
            {
                ecu::lapi::diag::CpInterfaceAllocationConfig xcp_alloc_config
                    {
                        ecu::lapi::diag::CpInterfaceAllocationConfig::CP_IF_CAN2,
                        xcp_interface_configuration.baudrate,
                        xcp_interface_configuration.source_ecu,
                        xcp_interface_configuration.target_ecu,
                        0  // As per new SDK 6.8.0, 5th parameter is station_address which is used for CCP only, so adding 0 here
                    };
                xcp_interface_state = mXCPClientPtr->allocate_interface(xcp_alloc_config,2000);
            }
        switch(xcp_interface_state)
            {
                case CP_IF_STATE_READY:
                {
                    return_value = true;
                    LOG_MOD(NOTICE, logmod)<<"Xcp Interface allocated and request can be issued.";
                    ecu::lapi::diag::CpClient::CpResult result = mXCPClientPtr->connect(1000);
                    if (result.ok())
                    {
                        if(xcp_interface_configuration.xcp_secure_access_required){
                        mXCPClientPtr->unlock_resource(resource,XcpUnlockResourceResponseCB,1000);
                        }
                        LOG_MOD(NOTICE, logmod)<<"connect and unlock command sent to target ECU";
                    }
                    break;
                }
                case CP_IF_STATE_UNKNOWN:
                    LOG_MOD(NOTICE, logmod)<< "XCP Interface could not be determined.";
                    break;

                case CP_IF_STATE_FREE:
                    LOG_MOD(NOTICE, logmod)<< "XCP Interface is free to be allocated to a client.";
                    break;

                case CP_IF_STATE_BUSY:
                    LOG_MOD(NOTICE, logmod)<< "XCP Interface is currently allocated to another client.";
                    break;

                case CP_IF_STATE_TIMEOUT:
                    LOG_MOD(NOTICE, logmod)<< "XCP Interface allocation timed out for current client.";
                    break;

                case CP_IF_STATE_PROCESSING:
                    return_value = true;
                    LOG_MOD(NOTICE, logmod)<< "XCP Interface is allocated by current client and a request is currently processing.";
                    break;

                case CP_IF_STATE_ERROR:
                    LOG_MOD(NOTICE, logmod)<< "An error prevented the XCP interface allocationdaqList request to succeed or invalid configuration provided.";
                    break;

                default:
                    break;
            }
        return return_value;
    }

void XcpSampler::WriteToDataAccess(uint32_t daqid)
    {
        std::vector<XCPSignalDetails> xcpSignals = mXcpData.at(daqid);
        for(auto signal : xcpSignals)
        {
            std::string sendData = ConvertXCPData(signal);
            mDataAccessModelPtr->Write(signal.xcpSignalName, sendData, Protocol::XCPProto,signal.configid);
        }
    }


std::string XcpSampler::ConvertXCPData(XCPSignalDetails xcpSignal)
    {
        std::string retVal = "-1";
        if(xcpSignal.xcpData.size() != 0)
            {
                float ConvertedValue ;
                if(xcpSignal.conversionDataType == "F32")
                    {
                        std::stringstream ss;
                        ss << std::hex << std::setfill('0');
                        for(int i = 3 ;i >=0; i--) //MSB
                            {
                                ss << std::setw(2) << static_cast<unsigned>(xcpSignal.xcpData[i]);
                            }
                        BitField temp;
                        ss >> std::hex >> temp.longVal;
                        ConvertedValue =  temp.floatVal;
                        ConvertedValue = (ConvertedValue - xcpSignal.conversionOffset) / xcpSignal.conversionFactor;
                        ss.str("");
                        ss.clear();
                        ss << ConvertedValue;
                        retVal = ss.str();
                    }
                else if("S8" == xcpSignal.conversionDataType)
                    {
                        int8_t concatenatedNum = int8_t(xcpSignal.xcpData[0]);
                        ConvertedValue = (concatenatedNum - xcpSignal.conversionOffset) / xcpSignal.conversionFactor;
                        retVal = std::to_string(ConvertedValue);
                    }
                else if("U8" == xcpSignal.conversionDataType)
                    {
                        uint8_t concatenatedNum = uint8_t(xcpSignal.xcpData[0]);
                        ConvertedValue = (concatenatedNum - xcpSignal.conversionOffset) / xcpSignal.conversionFactor;
                        retVal = std::to_string(ConvertedValue);
                    }
                else if("S16" == xcpSignal.conversionDataType)
                    {
                        int16_t concatenatedNum = (xcpSignal.xcpData[1] << 8) + xcpSignal.xcpData[0];
                        ConvertedValue = (concatenatedNum - xcpSignal.conversionOffset) / xcpSignal.conversionFactor;
                        retVal = std::to_string(ConvertedValue);
                    }
                else if("U16" == xcpSignal.conversionDataType)
                    {
                        uint16_t concatenatedNum = (xcpSignal.xcpData[1] << 8) + xcpSignal.xcpData[0];
                      ConvertedValue = (concatenatedNum - xcpSignal.conversionOffset) / xcpSignal.conversionFactor;
                        retVal = std::to_string(ConvertedValue);
                    }
                else if("S32" == xcpSignal.conversionDataType)
                    {
                        int32_t concatenatedNum =  (xcpSignal.xcpData[3] << 24) + (xcpSignal.xcpData[2] << 16) + (xcpSignal.xcpData[1] << 8) + xcpSignal.xcpData[0];
                        ConvertedValue = (concatenatedNum - xcpSignal.conversionOffset) / xcpSignal.conversionFactor;
                        retVal = std::to_string(ConvertedValue);
                    }
                else if("U32" == xcpSignal.conversionDataType)
                    {
                        uint32_t concatenatedNum =  (xcpSignal.xcpData[3] << 24) + (xcpSignal.xcpData[2] << 16) + (xcpSignal.xcpData[1] << 8) + xcpSignal.xcpData[0];
                        ConvertedValue = (concatenatedNum - xcpSignal.conversionOffset) / xcpSignal.conversionFactor;
                        retVal = std::to_string(ConvertedValue);
                    }
                else
                    {
                        LOG_MOD(ERROR, logmod)<<"unknown type  = "<< retVal <<" with type =  "<<xcpSignal.conversionDataType <<std::endl;
                    }

            LOG_MOD(NOTICE, logmod)<<"returning back converted value as = "<< retVal <<" with type =  "<<xcpSignal.conversionDataType <<std::endl;
            }
        else
            {
               LOG_MOD(WARNING, logmod)<<"NO RAW DATA, zero bytes received, no conversion done"<<std::endl;
            }
        return retVal;
    }

void XcpSampler::on_connection_change(ecu::lapi::diag::CpInterfaceState interface_state)
    {
        mXCPInterfaceState = interface_state;
    }

void XcpSampler::on_daq_data(const DaqData& response)
    {
		// If daq error has not yet occurred then proceed with execution of functionality.
        // If daq error has already occurred, then app will reject entire configuration file.
        if(mIsErrorOccurred)
        {
            if(StartAndStopDaqList(XcpCmd::StopList))
            {
                AddRemoveDaqList(XcpCmd::ClearList);
                mEventsManagerModelPtr->EmitSignal(XCP_ERROR_TRIGGERED_SIGNAL);
            }
        }
		else
		{
        auto XcpDataIter = mXcpData.find(response.daqid);
        if ( XcpDataIter != mXcpData.end())
            {
                std::vector<XCPSignalDetails> xcpSignals = mXcpData.at(response.daqid); // get list of signals in daq list
                uint32_t currentCount = 0;
                std::vector<uint8_t> eachSignalData ;
                uint16_t numOfSignals = xcpSignals.size();
                uint32_t daqListSize = 0;

                for (auto signal : xcpSignals)
                {
                   daqListSize += signal.xcpSize;
                }

                if (response.data.size() != daqListSize)
                {
                   LOG_MOD(ERROR, logmod)<< " Received DAQ List size does not match DAQ Configuration" ;
                   return;
                }

                for(uint16_t i = 0; i < numOfSignals; i++)//loop through each signal in daq list
                    {
                        uint16_t numOfBytes = xcpSignals.at(i).xcpSize;
                        for(uint16_t j = 0; j < numOfBytes; j++) //loop through xcpSize number of bytes in response data for each signal
                            {
                                eachSignalData.push_back(response.data.at(currentCount+j));
                            }
                        currentCount += xcpSignals.at(i).xcpSize;
                        mXcpData.at(response.daqid).at(i).xcpData = eachSignalData;
                        eachSignalData.clear();
                    }
                    WriteToDataAccess(response.daqid);
            }
        else
            {
                LOG_MOD(ERROR, logmod)<< " XCPSampler, DaqId not supported" ;
            }
		}
    }

bool XcpSampler::Validate_EPK()
    {
        bool bReturn = false ;
        const ecu::lapi::diag::DaqAddress daqaddr
            {
                mXCPEcuPropertiesConfigMsg.xcp_eprom_identifier_configuration.xcp_eprom_identifier_address,
                (uint8_t)mXCPEcuPropertiesConfigMsg.xcp_eprom_identifier_configuration.xcp_eprom_identifier_address_extension,
                mXCPEcuPropertiesConfigMsg.xcp_eprom_identifier_configuration.xcp_eprom_identifier_memsize
            };
        ecu::lapi::diag::CpClient::CpResponseResult result = mXCPClientPtr->upload(daqaddr,ecu::lapi::diag::CpClient::CP_REQUEST_TIMEOUT_MS);
        if(result.ok())
            {
                ecu::lapi::diag::CpMessage xcpmessage = result.take_val();
                std::string epk_string(xcpmessage.data.begin(), xcpmessage.data.end());
                if(epk_string == mXCPEcuPropertiesConfigMsg.xcp_eprom_identifier_configuration.xcp_eprom_identifier_string)
                    {
                        bReturn = true;
                    }
                    else
                    {
                        LOG_MOD(NOTICE, logmod)<< "Validate_EPK() : EPK String validation failed";
                    }
            }
        else
            {
                LOG_MOD(NOTICE, logmod)<< "Validate_EPK() failed code : " << result.err_val();
            }
        return bReturn;
    }

void XcpSampler::GetAndValidateChecksumFromECU()
    {
        const ecu::lapi::diag::DaqAddress daqAddr
            {
                mXCPEcuPropertiesConfigMsg.xcp_checksum_configuration.xcp_checksum_address,
                (uint8_t)mXCPEcuPropertiesConfigMsg.xcp_checksum_configuration.xcp_checksum_address_extension,
                mXCPEcuPropertiesConfigMsg.xcp_checksum_configuration.xcp_checksum_mem_size
            };
        if(mXCPClientPtr)
            {
                ecu::lapi::diag::CpClient::CpChecksumResult result =
                mXCPClientPtr->checksum(daqAddr,ecu::lapi::diag::CpEcuChecksumType::CST_CP_ADD_11);
                if(result.ok())
                    {
            /*            if(result.val() == mXCPEcuPropertiesConfigMsg.xcp_checksum_configuration.xcp_checksum)
                        {
                            ecu::lapi::logging::INFO << "XcpSampler:: DAQ has connected to correct N2 device ..." << std::endl;
                        }
                        else
                        {
                            ecu::lapi::logging::WARNING << "XcpSampler:: DAQ has not connected to correct N2 device ..." << std::endl;
                        }*/
                    }
                else
                    {
                        LOG_MOD(NOTICE, logmod)<< "XcpSampler:: Checksum failed with error code " << result.err_val();
                    }
            }
        else
            {
                LOG_MOD(NOTICE, logmod)<< "XcpSampler:: XCP client is invalid...";
            }
    }

CpInterfaceState XcpSampler::GetXCPInterfaceState()
    {
        return mXCPInterfaceState;
    }

bool XcpSampler::AddRemoveDaqList(XcpCmd cmd)
    {
        bool bReturn = false ;
        switch (cmd)
            {
                case XcpCmd::AddList :
                    {
                        auto result = mXCPClientPtr->daq_add(mDaqList, ecu::lapi::diag::CpClient::CP_REQUEST_TIMEOUT_MS);
                        if(result.ok())
                            {
                                bReturn = true ;
                            }
                        else
                            {
                                LOG_MOD(NOTICE, logmod)<< "XcpSampler::daq_add failed with error code " << result.err_val();
                            }
                    }
                break;

                case XcpCmd::ClearList :
                    {
                        for(const auto &daqlist : mDaqList)
                            {
                                auto result = mXCPClientPtr->daq_clear(daqlist.daqid,ecu::lapi::diag::CpClient::CP_REQUEST_TIMEOUT_MS);
                                if(result.ok())
                                    {
                                        bReturn = true ;
                                    }
                                else
                                    {
                                        LOG_MOD(NOTICE, logmod)<< "XcpSampler::daq_clear failed with error code " << result.err_val();
                                    }
                            }
                    }
                break ;

                default:
                    LOG_MOD(NOTICE, logmod)<< "XcpSampler::Invalid Command ";
                break;
            }
        return bReturn;
    }

bool XcpSampler::StartAndStopDaqList(XcpCmd cmd)
    {
        bool bReturn = false; // In all failure cases below, this function will return false
        switch (cmd)
            {
                case XcpCmd::StartList :
                    {
                        for(const auto &listItem : mDaqList)
                            {
                                auto result = mXCPClientPtr->daq_start(listItem.daqid, 2000);
                                if(result.ok())
                                    {
                                        bReturn = true ;
                                    }
                                else
                                    {
                                        LOG_MOD(NOTICE, logmod)<< "XcpClient::daq_start failed with error code " << result.err_val();
                                    }
                            } // end of for loop
                    } // end of StartList switch case
                break;

                case XcpCmd::StopList :
                    {
                        for(const auto &listItem : mDaqList)
                            {
                                auto result = mXCPClientPtr->daq_stop(listItem.daqid,
                                                                ecu::lapi::diag::CpClient::CP_REQUEST_TIMEOUT_MS);
                                if(result.ok())
                                    {
                                        bReturn = true ;
                                    }
                                else
                                    {
                                        LOG_MOD(NOTICE, logmod)<< "XcpClient::daq_stop failed with error code " << result.err_val();
                                    }
                            } // end of for loop
                    } // end of StopList switch case
                break ;

                default :
                    LOG_MOD(NOTICE, logmod)<< "XcpClient::Invalid Command";
                break ;
            }
        return bReturn;
    }

void  XcpSampler::SetEcuProperties()
    {
		ecu::lapi::diag::CpEcuProperties ecu_properties;
        ecu_properties.addr_granularity   = mXCPEcuPropertiesConfigMsg.address_granularity;
        ecu_properties.byte_order         = mXCPEcuPropertiesConfigMsg.byte_order;
        ecu_properties.slave_block_mode   = mXCPEcuPropertiesConfigMsg.slave_block_mode_supported;
        ecu_properties.min_daq            = mXCPEcuPropertiesConfigMsg.min_daq;
        ecu_properties.max_ev_channel     = mXCPEcuPropertiesConfigMsg.max_event_channel;
        ecu_properties.max_odt_entry_size = mXCPEcuPropertiesConfigMsg.max_odt_entry_size;
        ecu_properties.mode               = mXCPEcuPropertiesConfigMsg.daq_config_type;
        ecu_properties.max_daq            = mXCPEcuPropertiesConfigMsg.max_daq;
        ecu_properties.max_cto            = mXCPEcuPropertiesConfigMsg.max_cto;
        ecu_properties.max_dto            = mXCPEcuPropertiesConfigMsg.max_dto;
        mXCPClientPtr->set_ecu_properties(ecu_properties);
    }

void XcpSampler::SampleXcpData()
    {
        if(true == Validate_EPK())
            {
                mXcpData = mXCPClientModelPtr->CreateDaqList();
                InitSignalForDataAccess();
				mDaqList = mXCPClientModelPtr->GetDaqList();
                auto add_daqlist = AddRemoveDaqList(XcpCmd::AddList);
                if(add_daqlist)
                    {
                        StartAndStopDaqList(XcpCmd::StartList);
                    }
            }
        else
            {
                LOG_MOD(NOTICE, logmod)<< "EPK String verification failed";
            }
    }

void XcpSampler::InitSignalForDataAccess()
    {
        for (auto signalsvector : mXcpData)
            {
                for(auto signal : signalsvector.second)
                    {
                        mDataAccessModelPtr->Write(signal.xcpSignalName, "0.0", Protocol::XCPProto, signal.configid);
                    }
            }
    }

void XcpSampler::on_daq_error(const DaqError& error)
{
    LOG_MOD(NOTICE, logmod)<< "Invalid address exception thrown for daqId " << error.daqid << " & address is " << error.addr;
    mIsErrorOccurred = true;
}

std::vector<uint8_t> DaqApp::ComputeKeyFromSeed(std::vector<uint8_t> RawSeed)
{
   uint8_t Key[NSK_SEED_KEY_LENGTH]{};
   uint8_t Seed[NSK_SEED_KEY_LENGTH]{};
   uint8_t ecuSerialNmuberLength = 0;
   uint8_t ecuSerialNumber[ecuSerialNmuberLength]{};
   std::vector<uint8_t> computed_key;
   computed_key.assign(NSK_SEED_KEY_LENGTH,0);

    if(RawSeed.size() > NSK_SEED_KEY_LENGTH)
    {
        ecuSerialNmuberLength = RawSeed.size() - NSK_SEED_KEY_LENGTH;
    }
    else
    {
        ecuSerialNmuberLength = 0;
        LOG_MOD(ERROR, logmod)<< "NSK Error: Invalid ECU Serial number";
    }

    uint8_t	accesslevel = 3;
    for(int i=0; i<NSK_SEED_KEY_LENGTH; i++)
    { Seed[i] = RawSeed[i];}
    for(int j=0; j<ecuSerialNmuberLength; j++)
    { ecuSerialNumber[j] = RawSeed[j+NSK_SEED_KEY_LENGTH];}


    if(NSK_SUCCESS == nsk1020(accesslevel,ecuSerialNumber,ecuSerialNmuberLength,Seed,Key)){
        std::vector<uint8_t> key(Key,Key+NSK_SEED_KEY_LENGTH);
        computed_key = key;
    }else{
           LOG_MOD(ERROR, logmod)<< "NSK Error: nsk returned error in computing key ";
    }

	return computed_key;
}
