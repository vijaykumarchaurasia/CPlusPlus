#include <algorithm>
#include <ecu/rt/signaladapter.h>
#include <ecu/logging.h>
#include "AppManager.h"
#include "DataAccessModel.h"
#include "DtcSamplerModel.h"
#include "ConfigurationManagerModel.h"
#include "Utils.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.DtcSamplerModel");
    }
using namespace DaqApp;
using namespace ecu::lapi::rt;
using namespace ecu::lapi::com;

DtcSamplerModel::DtcSamplerModel(AppManager* ipAppMgr , ITransportClient_ptr ipClient,
                                 J1939ConfigMessage ipJ1939ConfigMessage):
mSdkCallBackPtr(new CallBackHelper(this)),
mAppManagerPtr(ipAppMgr),
mDataAccessModelPtr(ipAppMgr->GetDataAccessModel()),
mTopic(ipJ1939ConfigMessage.Topic),
mSignal(ipJ1939ConfigMessage.Signal),
mPgn(ipJ1939ConfigMessage.Pgn),
mSourceAddress(ipJ1939ConfigMessage.SourceAddress),
mDmData(),
mClientPtr(ipClient),
mConfigId(ipJ1939ConfigMessage.ConfigID)
    {
        LOG_MOD(NOTICE, logmod)<<"Creation: DtcSampler Topic="<<mTopic<<" SourceAddress = "<< mSourceAddress <<std::endl;
        mClientPtr->subscribe(mTopic,0,mSdkCallBackPtr);

        mDataAccessModelPtr->Write(mPgn,"spn:0~fmi:0~count:0|",Protocol::EventProto,mConfigId);
    }

DtcSamplerModel::~DtcSamplerModel()
    {
        mClientPtr->unsubscribe(mTopic,mSdkCallBackPtr);
        LOG_MOD(NOTICE, logmod)<<"Destruction: DtcSampler";
    }

void DtcSamplerModel::message( const std::string& topic, const Message& message)
    {
        SignalAdapter::UnpackResult unpack = SignalAdapter::instance().unpack(topic, message);
        SignalGroup receivedGroup_  = unpack.take_val();
        const Signal* SourceAddressPtr = receivedGroup_.signal("j1939_source_address");
        int SourceAddress = int (SourceAddressPtr->data().at(0));
        if(DaqApp::utils::ConvertIntToHex(SourceAddress) == mSourceAddress)
            {
                LOG_MOD(INFO, logmod)<<"DtcSampler: message received for PGN = "<< mPgn <<"and SourceAddress = "<< SourceAddress;
                mDmStringData.clear();
                mDmData.clear();
                const Signal* SizePtr = receivedGroup_.signal("nof_bytes");
                int dm_msg_size = 0;
                for(const auto& byte :SizePtr->data())
                    {
                        dm_msg_size += int(byte);
                    }
                dm_msg_size -= 2;
                const Signal* SignalPtr  = receivedGroup_.signal(mSignal);
                if((nullptr != SignalPtr || !SignalPtr->is_enum()))
                    {
                        int byteIndex = 2;
                        while (4 <= dm_msg_size)
                            {
                                mSpn19bit  = SignalPtr->data().at(byteIndex)+
                                        ((SignalPtr->data().at(byteIndex+1))<<8) +
                                        (((SignalPtr->data().at(byteIndex+2)) & 0xE0) << 11);
                                mFmi       = (SignalPtr->data().at(byteIndex+2)) &0x1F;
                                mOc        = (SignalPtr->data().at(byteIndex+3)) &0x7F;
                                byteIndex = byteIndex+4;
                                dm_msg_size = dm_msg_size-4;
                                mDmStringData += "spn:" + std::to_string(mSpn19bit) +
                                                "~fmi:"   + std::to_string(mFmi) +
                                                "~count:" + std::to_string(mOc) +
                                                "|";
                                mDmData.push_back(mSpn19bit);
                                mDmData.push_back(mFmi)     ;
                                mDmData.push_back(mOc)      ;
                                mDataAccessModelPtr->Write(mPgn, mDmStringData,Protocol::EventProto,mConfigId);
                            }
                    }
                else
                    {
                        LOG_MOD(WARNING, logmod)<<"DtcSampler: Invalid Signal Data "<<SizePtr->status();
                    }
        }
        else
            {
                LOG_MOD(WARNING, logmod)<<"DtcSampler: data not logged, config SourceAddress = "<<mSourceAddress << "received SourceAddress = "<<SourceAddress<<std::endl;
            }
    }

int DtcSamplerModel::GetFmi(int spn)
    {
        return mDmData.at(FindSpnIndex(spn)+1);
    }

int DtcSamplerModel::GetOc(int spn)
    {
        return mDmData.at(FindSpnIndex(spn)+2);
    }

int DtcSamplerModel::FindSpnIndex(int spn)
    {
        auto SpnIndex = std::find(mDmData.begin(), mDmData.end(), spn);
        if (SpnIndex != mDmData.cend())
            {
                return std::distance(mDmData.begin(), SpnIndex);
            }
    }
