#include <algorithm>
#include <regex>
#include <ecu/logging.h>
#include "AppManager.h"
#include "ConfigurationManagerModel.h"
#include "TranslatorModel.h"
#include "ValidationModel.h"
#include "CommonHeader.h"
#include "ClientManagerModel.h"
#include "Utils.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("DaqApp.ConfigurationManagerModel");
    }
using namespace DaqApp;

ConfigurationManagerModel::ConfigurationManagerModel(AppManager* passed):
    mJsonParserPtr(std::make_unique<JsonParserModel>()),
    mTranslatorPtr(std::make_unique<TranslatorModel>(passed->GetFilesHandlingModel())),
    mValidationPtr(std::make_unique<ValidationModel>()),
    mFilesHandlingModelPtr(passed->GetFilesHandlingModel()),
    mEventsManagerHandlePtr(passed->GetEventsManagerModel()),
	mClientsManagerModelPtr(passed->GetClientManagerModel())
    {
        LOG_MOD(NOTICE, logmod) << "Creation: ConfigurationManagerModel";
        mJ1939Configuration            = std::vector<J1939ConfigMessage>();
        mXCPConfiguration              = std::vector<XCPConfigMessage>();
        mXcpEcuPropertiesConfiguration = XCPEcuPropertiesConfigMessage();
        mUdsConfiguration              = std::vector<UDSConfigMessage>();
        mEventsConfiguration           = std::vector<EventConfigMessage>();
        mCompositeEventConfiguration   = std::vector<CompositeEventConfig>();
        mDataLoggerConfiguration       = std::vector<DataLoggerConfig>();
        mGpsSamplerConfiguration	   = std::vector<GpsSamplerConfig>();
        mActivateDataConfiguration     = std::vector<ActivateDataConfig>();
        mDeActivateDataConfiguration   = GetDeActivateDataConfig();
        mForgetConfiguration           = std::vector<ForgetConfig>();
        mProtocol                      = SamplingProtocols::InvalidProtocol;
        mConfigIds                     = ConfigIds::InvalidConfig;
        mEventsManagerHandlePtr->ConnectToSignal("NewConfigArrived",boost::bind(&ConfigurationManagerModel::NewConfigurationReceived,this));
    }

ConfigurationManagerModel::~ConfigurationManagerModel()
    {
        mJ1939Configuration.clear();
        mXCPConfiguration.clear();
        mUdsConfiguration.clear();
        mEventsConfiguration.clear();
        mDataLoggerConfiguration.clear();
        mCompositeEventConfiguration.clear();
        mGpsSamplerConfiguration.clear();
        mForgetConfiguration.clear();
	mActivateDataConfiguration.clear();
	mProtocols.clear();
        LOG_MOD(NOTICE, logmod) << "Destruction: ConfigurationManagerModel" ;
    }

/**
 * This fuction will be called once the signal "NewConfigArrived" is detected.
 * Also, it calls the functions to validate all the mandatory blocks and parse the json values.
 */
void ConfigurationManagerModel::NewConfigurationReceived()
    {
        Json::Value root = mJsonParserPtr->ParseJsonFile(mFilesHandlingModelPtr->GetLatestReceivedConfigFilePath());
        CloudServicesModel* CloudServicesModelPtr = mFilesHandlingModelPtr->GetCloudServicesPtr();

        if(mValidationPtr->IsValidConfig(root))
            {
                mFilesHandlingModelPtr->NewDownloadedConfigFileValidationResponse(mFilesHandlingModelPtr->GetLatestReceivedConfigFilePath(),true);
                if(root.isMember("activateDataCollection"))
                    {
                        LOG_MOD(NOTICE, logmod) << "The Configuration File has activateDataCollection command";
                        Json::Value activate_data_collection_array = root["activateDataCollection"];
                        Json::Value activate_data_collection_obj = activate_data_collection_array[0];
                        Json::Value sampling_config_id_array = activate_data_collection_obj["dataSamplingConfigIds"];
                        std::string dataSamplingConfigID = sampling_config_id_array[0].asString();
                        std::smatch matchFlag;
                        if(std::regex_search(dataSamplingConfigID, matchFlag, std::regex("[A-Za-z0-9]")))
                            {
                                if (boostfs::exists(INACTIVE_CONFIG_DIR + "/" + CONFIGURATION_FILE_NAME))
                                  {
                                    boost::filesystem::rename(INACTIVE_CONFIG_DIR + "/" + CONFIGURATION_FILE_NAME, INACTIVE_CONFIG_DIR + "/" + dataSamplingConfigID + JSON_EXT);
                                  }
                                mFilesHandlingModelPtr->OnNotifyReceivedActivateDataCollectionMessage(dataSamplingConfigID + JSON_EXT);
                                CloudServicesModelPtr->SetConfigStatus(ConfigStatus::Success,"ACCEPTED");
                                if((activate_data_collection_obj["messageFormatVersion"].asString().at(0) == 'N'))
                                    {
                                        if (root.isMember("defineECUParameterSpecification"))
                                            {
                                                std::string baud_rate = GetEcuParameterBaudRate(root["defineECUParameterSpecification"]);
                                                if ( !baud_rate.empty() )
                                                    {
                                                        mClientsManagerModelPtr->ConfigureCAN2Baudrate(baud_rate);		//Set baud rate as defined by config
                                                    }
                                            }
                                    }
                                else
                                    {
                                        mClientsManagerModelPtr->ConfigureCAN2Baudrate("500000");//Set baud rate to 500k if not Navistar Config
                                    }
                            }
                            else
                                {
                                    mFilesHandlingModelPtr->NewDownloadedConfigFileValidationResponse(mFilesHandlingModelPtr->GetLatestReceivedConfigFilePath(),false);
                                    CloudServicesModelPtr->SetConfigStatus(ConfigStatus::Acknowledged, "REJECTED", std::make_pair("501","Missing dataSamplingConfigId from activateDataCollection"));
                                    return;
                                }
                    }

             if(root.isMember("deactivateDataCollection"))
                {
                    LOG_MOD(NOTICE, logmod) << "The Configuration File has deactivateDataCollection command";
                    Json::Value deactivate_config_array = root["deactivateDataCollection"];
                     if(deactivate_config_array.size()>0)
                        {
                            Json::Value deactivate_config = deactivate_config_array[0];
                            Json::Value config_ids = deactivate_config["dataSamplingConfigIds"];
                            if (config_ids.size()>0)
                            {
                                // This function is yet to implement in FileHandlingModel
                                mFilesHandlingModelPtr->ForgetConfig(config_ids[0].asString()+ JSON_EXT);
                                CloudServicesModelPtr->SetConfigStatus(ConfigStatus::Success,"ACCEPTED");
                            }
                            else
                            {
                                LOG_MOD(WARNING, logmod) << "deactivateDataCollection doesn't have dataSamplingConfigIds" ;
                                return;
                            }
                        }
                }

            }
            else
            {

                mFilesHandlingModelPtr->NewDownloadedConfigFileValidationResponse(mFilesHandlingModelPtr->GetLatestReceivedConfigFilePath(),false);
                CloudServicesModelPtr->SetConfigStatus(ConfigStatus::Acknowledged, "REJECTED", mValidationPtr->getConfigReasonCodeDescription());
                return;
            }

    }

/*
 * This function takes ECM Parameter Spec Json Object and returns Baud rate specified in it as string
 */
std::string ConfigurationManagerModel::GetEcuParameterBaudRate(const Json::Value& ecu_prop){

    for( unsigned int index = 0; index!=ecu_prop.size(); index++)
        {
    		Json::Value ecu_param_spec = ecu_prop[index];
			if (ecu_param_spec.isMember("ecuParameters")){

				Json::Value ecu_param_array = ecu_param_spec["ecuParameters"];
				for( unsigned int param_index = 0; param_index!=ecu_param_array.size(); param_index++)
					{
						Json::Value ecu_param_obj = ecu_param_array[param_index];
						if (ecu_param_obj.isMember("BaudRate")){
							return ecu_param_obj["BaudRate"].asString();
						}
					}
			}
        }

	return "";
}

/**
 *  This function is used to set up the translation and configuration manager.
 */
void ConfigurationManagerModel::SetUpConfigurationManager()
    {
        ResetConfigValues();
        mTranslatorPtr->SetUpTranslatorModel();
        std::vector<std::string> config_files = mFilesHandlingModelPtr->GetMultiConfigs();
        if(!config_files.size())
        {
            config_files.push_back(mFilesHandlingModelPtr->GetConfigFilePath());
        }
        mConfigIds = ConfigIds::InvalidConfig;
        for(const std::string& config_file : config_files)
        {
            Json::Value root = mJsonParserPtr->ParseJsonFile(config_file);
            if(mValidationPtr->IsValidConfig(root))
            {
                mFileCounter++;
                switch (mFileCounter)  {
                case 1:
                    mConfigIds = ConfigIds::ConfigOne;
                    break;

                case 2:
                    mConfigIds = ConfigIds::ConfigTwo;
                    break;

                 case 3:
                    mConfigIds = ConfigIds::ConfigThree;
                    break;

                 case 4:
                    mConfigIds = ConfigIds::ConfigFour;
                    break;

                default:
                    mConfigIds = ConfigIds::InvalidConfig;

            }

                ParseJson(root);
            }
            else
            {
                mFilesHandlingModelPtr->ResetConfig();
                throw std::invalid_argument("ConfigurationManagerModel: Configuration file is not valid");
            }

        }

        if(!mTranslatorPtr->Translate(&mJ1939Configuration))
            {
                LOG_MOD(WARNING, logmod) << "TranslatorModel might have failed to parse all J1939 config, check config and CSV" ;
            };
        LOG_MOD(NOTICE, logmod)<<"Total config in J1939 "<< mJ1939Configuration.size();
        LOG_MOD(NOTICE, logmod)<<"Total config in XCP " << mXCPConfiguration.size();
        LOG_MOD(NOTICE, logmod)<<"Total config in UDS "<< mUdsConfiguration.size();

    }


/**
 *  This function is used to return UDS Configuration.
 */
std::vector<UDSConfigMessage>& ConfigurationManagerModel::GetUdsConfig()
    {
        return mUdsConfiguration;
    }

/**
 *  This function is used to return XcpEcuProperties Configuration.
 */
XCPEcuPropertiesConfigMessage ConfigurationManagerModel::GetXcpEcuPropertiesConfig()
    {
        return mXcpEcuPropertiesConfiguration;
    }

/**
 *  This function is used to return Xcp Parameter Configuration.
 */
std::vector<XCPParameterConfigMessage>& ConfigurationManagerModel::GetXcpParameterConfig()
    {
        return mXcpParameterConfiguration;
    }

/**
 *  This function is used to return XCP Configuration.
 */
std::vector<XCPConfigMessage>& ConfigurationManagerModel::GetXCPConfig()
    {
        return mXCPConfiguration;
    }

/**
 *  This function is used to return J1939 Configuration.
 */
std::vector<J1939ConfigMessage>& ConfigurationManagerModel::GetJ1939Config()
    {
        return mJ1939Configuration;
    }

/**
 *  This function is used to return Events Configuration.
 */
std::vector<EventConfigMessage>& ConfigurationManagerModel::GetEventsConfig()
    {
        return mEventsConfiguration;
    }

/**
 *  This function is used to return composite events Configuration.
 */
std::vector<CompositeEventConfig>& ConfigurationManagerModel::GetCompositeEventsConfig()
    {
        return mCompositeEventConfiguration;
    }

/**
 *  This function is used to return DataLogger Configuration.
 */
std::vector<DataLoggerConfig>& ConfigurationManagerModel::GetDataLoggerConfig()
    {
        return mDataLoggerConfiguration;
    }

/**
 *  This function is used to return Activate Data configuration.
 */
std::vector<ActivateDataConfig>& ConfigurationManagerModel::GetActivateDataConfig()
    {
        return mActivateDataConfiguration;
    }

 /**
 *  This function is used to return DeActivate Data configuration.
 */
DeActivateDataConfig ConfigurationManagerModel::GetDeActivateDataConfig()
    {
        return mDeActivateDataConfiguration;
    }

/**
 *  This function is used to return Forget Data configuration.
 */
std::vector<ForgetConfig> ConfigurationManagerModel::GetForgetConfig()
    {
        return mForgetConfiguration;
    }


 /**
 *  This function is used to return GPS Sampler configuration.
 */
std::vector<GpsSamplerConfig> ConfigurationManagerModel::GetGpsSamplerConfig()
{
    return mGpsSamplerConfiguration;
}

/**
 *  This function is used to return prebuffer count.
 */
int ConfigurationManagerModel::GetPreBufferCount()
    {
        int totalPreBufferSize = 0;
        for(const auto& DataLoggerConfigMessage : mDataLoggerConfiguration)
            {
                totalPreBufferSize = DataLoggerConfigMessage.PreBufferSize;
            }
        return totalPreBufferSize;
    }

/**
 *  This function is used to return Translator Model.
 */
TranslatorModel* ConfigurationManagerModel::GetTranslatorModel()
    {
        assert(nullptr != mTranslatorPtr);
        return mTranslatorPtr.get();
    }

/**
 *  This function is used to reset the values when new configuration file is received.
 */
void ConfigurationManagerModel::ResetConfigValues()
    {
        mJ1939Configuration.clear();
        mXCPConfiguration.clear();
        mXcpEcuPropertiesConfiguration = XCPEcuPropertiesConfigMessage();
        mUdsConfiguration.clear();
        mEventsConfiguration.clear();
        mDataLoggerConfiguration.clear();
        mCompositeEventConfiguration.clear();
        mActivateDataConfiguration.clear();
        mDeActivateDataConfiguration    = DeActivateDataConfig();
        mForgetConfiguration.clear();
        mProtocol                       = SamplingProtocols::InvalidProtocol;
        mProtocols.clear();
    }


/**
 *  This function is used to parse all the Json configuration.
 */
void ConfigurationManagerModel::ParseJson(const Json::Value& root)
    {
        if(root.isMember("defineDataContentSpec" ))
            {
            Json::Value data_content_spec_array = root["defineDataContentSpec"];
            for( unsigned int index = 0; index!=data_content_spec_array.size(); index++)
                {
                Json::Value data_content_spec = data_content_spec_array[index];
                Json::Value data_cont_spec_def = data_content_spec["dataContentSpecDefinition"];
                Json::Value all_sample_param = data_cont_spec_def["allSampleParameters"];
                if(all_sample_param.isMember("telematicsDeviceParameters"))
                {
                    Json::Value tele_param_array = all_sample_param["telematicsDeviceParameters"];
                    ParseGPSConfig(tele_param_array);
                }
                Json::Value equip_param_array = all_sample_param["equipmentParameters"];
                for ( unsigned int array_index = 0; array_index < equip_param_array.size(); ++array_index )
                    {
                        Json::Value equip_obj = equip_param_array[array_index];
                        std::string protocol = equip_obj["protocol"].asString().c_str();
                        mProtocols.insert(protocol);
                        if(protocol=="J1939")
                            {
                                mProtocol = SamplingProtocols::J1939;
                                ParseJ1939Config(equip_obj);
                            }
                        else if(protocol=="XCP")
                            {
                                mProtocol = SamplingProtocols::XCP;
                                ParseXCPParameterConfig(equip_obj);
                            }
                        else if(protocol=="TripData")
                            {
                                std::string SamplingConfigId;
                                if(root.isMember("activateDataCollection"))
                                {
                                    SamplingConfigId = GetSamplingConfigId(root["activateDataCollection"]);
                                }
                                mProtocol = SamplingProtocols::TRIP_DATA;
                                ParseTripDataConfig(equip_obj,SamplingConfigId);
                            }
                        else if(protocol=="EAL")
                            {
                                std::string SamplingConfigId;
                                if(root.isMember("activateDataCollection"))
                                {
                                    SamplingConfigId = GetSamplingConfigId(root["activateDataCollection"]);
                                }
                                mProtocol = SamplingProtocols::EAL;
                                ParseEALConfig(equip_obj,SamplingConfigId);
                            }
                        else
                        {
                            mProtocol = SamplingProtocols::InvalidProtocol;
                        }
                    }
                }
            }

        if(root.isMember("defineECUParameterSpecification"))
        {
            Json::Value ecu_properties_array = root["defineECUParameterSpecification"];
            if(ecu_properties_array.size()>0)
            {
              if(mProtocols.find("XCP") != mProtocols.end())
                {
                    ParseXCPEcuPropertiesConfig(ecu_properties_array);
                }
            }
        }
        if(root.isMember("defineSimpleEvent" ))
            {
                ParseEventConfig(root);
            }

        if(root.isMember("defineDataSamplingSpec") && (mProtocol != SamplingProtocols::TRIP_DATA))
            {
                ParseDataLoggerConfig(root["defineDataSamplingSpec"]);
            }
        if(root.isMember("defineDataSamplingConfig"))
            {
                ParseDataSamplingConfig(root["defineDataSamplingConfig"]);
            }
        if(root.isMember("activateDataCollection"))
            {
                ParseActivateDataConfig(root["activateDataCollection"]);
            }
        if(root.isMember("deactivateDataCollection"))
            {
                ParseDeActivateDataConfig(root["deactivateDataCollection"]);
            }
        if(root.isMember("forgetDefinition"))
            {
                ParseForgetConfig(root["forgetDefinition"]);
            }

        AddSourceForJ1939();//Adding the source
        if(mUdsConfiguration.size()>0)
        {
            if(mProtocol == SamplingProtocols::TRIP_DATA)
            {
                uint32_t TransmissionRate = getTransmissionRateForTripData(root);
                SetSamplingRateForTripData(TransmissionRate);
            }
            else
            {
                SetSamplingRateForEAL();
            }
        }

    }

  /**
   * This function is used to parse GPS configuration.
   */
void ConfigurationManagerModel::ParseGPSConfig(const Json::Value& tele_param_array)
{
    GpsSamplerConfig gps_sampler_config;
    for (unsigned int array_index = 0; array_index < tele_param_array.size(); ++array_index )
        {
            if(tele_param_array[array_index].asString()=="Latitude")
            {
                gps_sampler_config.IsLatitude = true;
            }
            else if(tele_param_array[array_index].asString()=="Longitude")
            {
                gps_sampler_config.IsLongitude = true;
            }
            else if(tele_param_array[array_index].asString()=="Altitude")
            {
                gps_sampler_config.IsAltitude = true;
            }
            else if(tele_param_array[array_index].asString()=="Direction_Heading")
            {
                gps_sampler_config.IsDirection_Heading = true;
            }
            else if(tele_param_array[array_index].asString()=="GPS_Vehicle_Speed")
            {
                gps_sampler_config.IsGPS_Vehicle_Speed = true;
            }
        }
        mGpsSamplerConfiguration.push_back(gps_sampler_config);

}

/**
 *This function is used to parse and save data logger configuration using the pre-defined config message.
 */
void ConfigurationManagerModel::ParseDataLoggerConfig(const Json::Value& data_sampling_spec_array)
    {
        for( unsigned int index = 0; index!= data_sampling_spec_array.size(); index++)
            {
                DataLoggerConfig data_logger_config;
                data_logger_config.ConfigID = mConfigIds;
                data_logger_config.UdsSignalName = "UDSSignal" + std::to_string(mFileCounter);
                Json::Value data_sampling_spec = data_sampling_spec_array[index];
                data_logger_config.proto = mProtocol;
                Json::Value data_sampling_spec_def = data_sampling_spec["dataSamplingSpecDefinition"];
                std::string triggerType = data_sampling_spec_def["triggerType"].asString();
                if(triggerType == "periodic")
                    {
                        data_logger_config.TriggerTypeId = TriggerType::Periodic;
                    }
                //triggerType == "eventDriven" and DataLogger config should have corresponding CompositeEvent
                else if(triggerType == "eventDriven")
                    {
                        data_logger_config.TriggerTypeId = TriggerType::EventDriven;
                        if(data_sampling_spec_def.isMember("preEventSamplingDuration"))
                        {
                            data_logger_config.PreBufferSize = std::stoi(data_sampling_spec_def["preEventSamplingDuration"].asString());
                        }
                        if(data_sampling_spec_def.isMember("postEventSamplingDuration"))
                        {
                            data_logger_config.PostBufferSize = std::stoi(data_sampling_spec_def["postEventSamplingDuration"].asString());
                        }
                        if(data_sampling_spec_def.isMember("prePostEventDurationUnit"))
                        {
                            data_logger_config.PrePostEventDurationUnit = data_sampling_spec_def["prePostEventDurationUnit"].asString();
                        }
                        data_logger_config.StartingEventId  = data_sampling_spec_def["startingEventId"].asString()  ;
                        if(data_sampling_spec_def.isMember("endingEventId"))
                        {
                            data_logger_config.EndingEventId    = data_sampling_spec_def["endingEventId"].asString()  ;
                        }
                    }
                else
                    {
                        LOG_MOD(ERROR, logmod) << "ConfigurationManagerModel: InvalidTrigger";
                        data_logger_config.TriggerTypeId = TriggerType::InvalidTrigger;
                    }
                float sampling_rate = std::stof(data_sampling_spec_def["samplingPeriod"].asString());
                std::string sampling_period_unit = data_sampling_spec_def["samplingTransmitPeriodUnit"].asString();
                // If sampling period unit is ms then no conversion is needed
                if(sampling_period_unit == "sec")
                    {
                        sampling_rate = sampling_rate*1000;
                    }
                else if(sampling_period_unit == "min")
                    {
                        sampling_rate = sampling_rate*60*1000;
                    }
                else if(sampling_period_unit == "hr")
                    {
                        sampling_rate = sampling_rate*60*60*1000;
                    }
                data_logger_config.SamplingRate = sampling_rate;
                data_logger_config.MaxSetSize = std::stoi(data_sampling_spec_def["maxSetSize"].asString());
                data_logger_config.MaxTransmitPeriod = std::stoi(data_sampling_spec_def["maxTransmitPeriod"].asString());
                mDataLoggerConfiguration.push_back(data_logger_config);
            }
    }

/**
 *  This function is used to parse XCP ECU properties configuration.
 */
void ConfigurationManagerModel::ParseXCPEcuPropertiesConfig(const Json::Value& ecu_properties_array)
    {
        for( unsigned int index = 0; index!=ecu_properties_array.size(); index++)
            {
                Json::Value ecu_param_spec = ecu_properties_array[index];
                mXcpEcuPropertiesConfiguration.xcp_ecu_software_identifier = ecu_param_spec["ECUParameterSpecId"].asString();
                Json::Value ecu_param_array = ecu_param_spec["ecuParameters"];
                for( unsigned int param_index = 0; param_index!=ecu_param_array.size(); param_index++)
                    {
                        XcpInterfaceAllocationConfig xcp_interface_allocation_config;
                        XcpChecksumConfig xcp_checksum_config;
                        XcpEpromIdentifierConfig xcp_eprom_identifier_config;
                        Json::Value ecu_param_obj = ecu_param_array[param_index];
                        xcp_interface_allocation_config.baudrate = std::stoi(ecu_param_obj["BaudRate"].asString());

                        xcp_interface_allocation_config.source_ecu = DaqApp::utils::ConvertValueToInt(ecu_param_obj["CANidentifierTx"].asString());
                        xcp_interface_allocation_config.target_ecu = DaqApp::utils::ConvertValueToInt(ecu_param_obj["CANidentifierRx"].asString());
                        xcp_interface_allocation_config.xcp_secure_access_required = ecu_param_obj["XCPSecureAccessRequired"].asBool();

                        xcp_checksum_config.xcp_checksum_address = DaqApp::utils::ConvertValueToInt(ecu_param_obj["XcpMemStartAddress"].asString());

                        xcp_checksum_config.xcp_checksum_address_extension = DaqApp::utils::ConvertValueToInt(ecu_param_obj["XcpMemAddressExtension"].asString());
                        xcp_checksum_config.xcp_checksum_mem_size = DaqApp::utils::ConvertValueToInt(ecu_param_obj["XcpMemorySize"].asString());
                        xcp_checksum_config.xcp_checksum = std::stoi(ecu_param_obj["XcpMemoryChecksum"].asString());
                        xcp_checksum_config.xcp_checksum_method = ecu_param_obj["XcpChecksumMethod"].asString();
                        xcp_eprom_identifier_config.xcp_eprom_identifier_string = ecu_param_obj["EPROMIdentifier"].asString();
                        xcp_eprom_identifier_config.xcp_eprom_identifier_address = DaqApp::utils::ConvertValueToInt(ecu_param_obj["EPROMIdentifierAddress"].asString());
                        xcp_eprom_identifier_config.xcp_eprom_identifier_address_extension = DaqApp::utils::ConvertValueToInt(ecu_param_obj["EPROMIdAddressExtension"].asString());

                       // xcp_eprom_identifier_config.xcp_eprom_identifier_memsize = std::stoi(ecu_param_obj["EPROMIdMemorySize"].asString());
                       xcp_eprom_identifier_config.xcp_eprom_identifier_memsize = xcp_eprom_identifier_config.xcp_eprom_identifier_string.size();

                        mXcpEcuPropertiesConfiguration.xcp_interface_allocation_configuration = xcp_interface_allocation_config;
                        mXcpEcuPropertiesConfiguration.xcp_checksum_configuration = xcp_checksum_config;
                        mXcpEcuPropertiesConfiguration.xcp_eprom_identifier_configuration = xcp_eprom_identifier_config;
                    }

					//In-case if the baudrate is not already set when the Config was downloaded, calling this function to set the baud rate based on config
                	mClientsManagerModelPtr->ConfigureCAN2Baudrate(std::to_string(mXcpEcuPropertiesConfiguration.xcp_interface_allocation_configuration.baudrate));

                    Json::Value daq_param_array = ecu_param_spec["daqParameters"];
                    for( unsigned int param_index = 0; param_index!=daq_param_array.size(); param_index++)
                        {
                           Json::Value daq_param_obj = daq_param_array[param_index];
                           std::string tempByte = daq_param_obj["ByteOrder"].asString();
                            if(tempByte == "BYTE_ORDER_MSB_LAST")
                                {
                                    mXcpEcuPropertiesConfiguration.byte_order = ecu::lapi::diag::CpEcuProperties::MSB_LAST;
                                }
                            else if(tempByte == "BYTE_ORDER_MSB_FIRST")
                                {
                                    mXcpEcuPropertiesConfiguration.byte_order = ecu::lapi::diag::CpEcuProperties::MSB_FIRST;
                                }
                            else
                                {
                                    mXcpEcuPropertiesConfiguration.byte_order = ecu::lapi::diag::CpEcuProperties::MSB_UNKNOWN;
                                }
                            std::string tempAddress = daq_param_obj["AddressGranularity"].asString();
                            if(tempAddress == "ADDRESS_GRANULARITY_BYTE")
                                {
                                    mXcpEcuPropertiesConfiguration.address_granularity = ecu::lapi::diag::CpEcuProperties::GRANULARITY_BYTE;
                                }
                            else if (tempAddress == "ADDRESS_GRANULARITY_WORD")
                                {
                                    mXcpEcuPropertiesConfiguration.address_granularity = ecu::lapi::diag::CpEcuProperties::GRANULARITY_WORD;
                                }
                            else if (tempAddress == "ADDRESS_GRANULARITY_DWORD")
                                {
                                    mXcpEcuPropertiesConfiguration.address_granularity = ecu::lapi::diag::CpEcuProperties::GRANULARITY_DWORD;
                                }
                            else
                                {
                                    mXcpEcuPropertiesConfiguration.address_granularity = ecu::lapi::diag::CpEcuProperties::GRANULARITY_UNKNOWN;
                                }
                            mXcpEcuPropertiesConfiguration.max_cto = std::stoi(daq_param_obj["MaxCTO"].asString());
                            mXcpEcuPropertiesConfiguration.max_dto = std::stoi(daq_param_obj["MaxDTO"].asString());
                            std::string tempConfig = daq_param_obj["DaqConfigType"].asString();
                            if(tempConfig == "STATIC")
                                {
                                    mXcpEcuPropertiesConfiguration.daq_config_type = ecu::lapi::diag::CpEcuProperties::STATIC;
                                }
                            else if (tempConfig == "DYNAMIC")
                                {
                                    mXcpEcuPropertiesConfiguration.daq_config_type = ecu::lapi::diag::CpEcuProperties::DYNAMIC;
                                }
                            else
                                {
                                    mXcpEcuPropertiesConfiguration.daq_config_type = ecu::lapi::diag::CpEcuProperties::UNKNOWN;
                                }
                            mXcpEcuPropertiesConfiguration.max_daq=std::stoi(daq_param_obj["MaxDaq"].asString());
                            mXcpEcuPropertiesConfiguration.max_event_channel=std::stoi(daq_param_obj["MaxEventChannel"].asString());
                            mXcpEcuPropertiesConfiguration.min_daq=std::stoi(daq_param_obj["MinDaq"].asString());
                            mXcpEcuPropertiesConfiguration.max_odt_entry_size=std::stoi(daq_param_obj["MaxOdtEntrySize"].asString());
                            std::string tempSlave = daq_param_obj["SlaveBlockModeSupported"].asString();
                            if (tempSlave == "TRUE")
                                {
                                    mXcpEcuPropertiesConfiguration.slave_block_mode_supported = true;
                                }
                            else
                                {
                                    mXcpEcuPropertiesConfiguration.slave_block_mode_supported = false;
                                }
                        }
            }
    }

/**
 *  This function is used to parse XCP parameter configuration.
 */
void ConfigurationManagerModel::ParseXCPParameterConfig(const Json::Value& xcp_param_config)
    {
        XCPConfigMessage xcp_config_message;
        std::vector<XCPParameterConfigMessage>   XcpParameterConfiguration ;
        std::string tempMode  = xcp_param_config["sampling_mode"].asString();
        if (tempMode == "DAQ")
            {
                xcp_config_message.transmission_rate_prescaler = std::stoi(xcp_param_config["transmission_rate_prescaler"].asString());
                std::string temp_event_channel_number          = xcp_param_config["event_channel_number"].asString();
                if(DaqApp::utils::IsNumber(temp_event_channel_number))
                {
                    xcp_config_message.event_channel_number  = std::stoi(temp_event_channel_number);
                }
                else
                {
                    xcp_config_message.event_channel_number    = 111; // Magical Value for non-numeric value "sync"
                }
                xcp_config_message.event_channel_priority      = std::stoi(xcp_param_config["event_channel_priority"].asString());
                xcp_config_message.sampling_mode               = ecu::lapi::diag::DaqMode::DAQ_MODE_SAMPLE;
                xcp_config_message.rate                        = 0;
            }
        else if (tempMode == "POLLING")
            {
                xcp_config_message.transmission_rate_prescaler = 0;
                xcp_config_message.event_channel_number        = 0;
                xcp_config_message.event_channel_priority      = 0;
                xcp_config_message.sampling_mode               = ecu::lapi::diag::DaqMode::DAQ_MODE_POLL;
                xcp_config_message.rate                        = std::stoi(xcp_param_config["rate"].asString());
            }
        else
            {
                throw std::invalid_argument("ConfigurationManagerModel: invalid sampling mode for XCP !");
            }
        Json::Value param_array = xcp_param_config["parameters"];
        for (unsigned int index = 0; index < param_array.size(); ++index )
            {
                XCPParameterConfigMessage xcp_param_config_msg;
                Json::Value xcp_parameters = param_array[index];
                xcp_param_config_msg.xcp_parameter_name = xcp_parameters["name"].asString();
                xcp_param_config_msg.xcp_parameter_address = DaqApp::utils::ConvertValueToInt(xcp_parameters["address"].asString());
                xcp_param_config_msg.config_id = mConfigIds;
                xcp_param_config_msg.xcp_parameter_address_extension = DaqApp::utils::ConvertValueToInt(xcp_parameters["addressExtension"].asString());

                xcp_param_config_msg.xcp_parameter_data_type = xcp_parameters["datatype"].asString();
                if(xcp_parameters["factor"].asString().size())
                    xcp_param_config_msg.xcp_parameter_conversion_factor = std::stof(xcp_parameters["factor"].asString());
                else
                    xcp_param_config_msg.xcp_parameter_conversion_factor = 1;

                if (xcp_parameters["offset"].asString().size())
                    xcp_param_config_msg.xcp_parameter_conversion_offset = std::stof(xcp_parameters["offset"].asString());
                else
                    xcp_param_config_msg.xcp_parameter_conversion_offset = 0;
                XcpParameterConfiguration.push_back(xcp_param_config_msg);
            }
            xcp_config_message.xcp_parameter_config_messages = XcpParameterConfiguration;
            mXCPConfiguration.push_back(xcp_config_message);
    }

/**
 *  This function is used to parse UDS configuration.
 */
void ConfigurationManagerModel::ParseEALConfig(const Json::Value& uds_config,const std::string& config_name)
{
    Json::Value param_array = uds_config["parameters"];
    Json::Value deviceIds_array = uds_config["deviceIds"];

    for ( unsigned int index = 0; index < param_array.size(); ++index )
        {
            std::string parameter = param_array[index].asString();
            std::string data_id_string = parameter.substr(parameter.find(":")+1);
            for ( unsigned int indexId = 0; indexId < deviceIds_array.size(); ++indexId )
            {
                struct UDSConfigMessage udsconfig_msg;
                udsconfig_msg.ConfigID = mConfigIds;
                udsconfig_msg.DDID = std::stoi(parameter, 0, 16);
                udsconfig_msg.Protocol = uds_config["protocol"].asString();
                udsconfig_msg.IsEALData = true;
                udsconfig_msg.UdsSignalName = "UDSSignal" + std::to_string(mFileCounter);
                udsconfig_msg.SourceAddress = DaqApp::utils::ConvertIntToHex(std::stoi(deviceIds_array[indexId].asString()));
                udsconfig_msg.dataIds.reserve((data_id_string.length()/2));
                while(data_id_string.length() != 0)
                {
                    std::string sDataID = data_id_string.substr(0,2);
                    uint8_t dataID = std::stoi(sDataID, 0, 16);
                    udsconfig_msg.dataIds.push_back(dataID);
                    data_id_string.erase(0,2);
                }
                udsconfig_msg.ConfigName = config_name;
                mUdsConfiguration.push_back(udsconfig_msg);
            }
        }
}

/**
 * This function is used to parse TripData configuration.
*/
void ConfigurationManagerModel::ParseTripDataConfig(const Json::Value& trip_data_config,const std::string& config_name)
{
    UDSConfigMessage uds_tripdata_config_msg;
    uds_tripdata_config_msg.ConfigID = mConfigIds;
    uds_tripdata_config_msg.Protocol = trip_data_config["protocol"].asString();
    if(uds_tripdata_config_msg.Protocol == "TripData")
    {
        uds_tripdata_config_msg.IsTripData = true;
    }
    Json::Value param_array = trip_data_config["parameters"];
    std::string parameter = param_array[0].asString();
    if(parameter == "Partial")
    {
        uds_tripdata_config_msg.isPartialExtraction = true;
    }
    else{
        uds_tripdata_config_msg.isPartialExtraction = false;
    }
    uds_tripdata_config_msg.ConfigName = config_name;
    mUdsConfiguration.push_back(uds_tripdata_config_msg);

}

/**
 *  This function is used to parse J1939 configuration.
 */
void ConfigurationManagerModel::ParseJ1939Config(const Json::Value& json_j1939_config)
    {
        Json::Value param_array = json_j1939_config["parameters"];
        Json::Value deviceIds_array = json_j1939_config["deviceIds"];
        for ( unsigned int index = 0; index < param_array.size(); ++index )
            {
                std::string parameter = param_array[index].asString();
                for ( unsigned int indexId = 0; indexId < deviceIds_array.size(); ++indexId )
                    {
                        struct J1939ConfigMessage j1939config_msg;
                        j1939config_msg.ConfigID = mConfigIds;
                        //This is just work around, in future hex value will be coming fron config so that it will easily map with topiclist.csv source address
                        j1939config_msg.SourceAddress = DaqApp::utils::ConvertIntToHex(std::stoi(deviceIds_array[indexId].asString()));
                        if(DaqApp::utils::IsNumber(parameter))
                            {
                                j1939config_msg.Spn = parameter;
                                mJ1939Configuration.push_back(j1939config_msg);
                            }
                        else if(parameter == "activeFaultCodes" || parameter == "inactiveFaultCodes" || parameter == "pendingFaultCodes")
                            {
                                j1939config_msg.Pgn = parameter;
                                if(parameter == "activeFaultCodes"){j1939config_msg.Spn   = "dm1";}
                                if(parameter == "inactiveFaultCodes"){j1939config_msg.Spn = "dm2";}
                                if(parameter == "pendingFaultCodes"){j1939config_msg.Spn  = "dm27";}
                                mJ1939Configuration.push_back(j1939config_msg);
                            }
                        else
                            {
                                LOG_MOD(ERROR, logmod) << "ConfigurationManagerModel: Invalid SPN/PGN: " << parameter;
                            }

                    }
            }
    }

/**
 *  This function is used to parse Event configuration.
 */
void ConfigurationManagerModel::ParseEventConfig(const Json::Value& root)
    {
    Json::Value event_config_array =  root["defineSimpleEvent"];
    if(root.isMember("defineCompositeEvent"))
        {
            ParseCompositeEventConfig(root["defineCompositeEvent"]);
        }
    for(unsigned int index = 0; index!=event_config_array.size(); index++)
        {
        struct EventConfigMessage event_message;
        event_message.ConfigID = mConfigIds;
        Json::Value event_config = event_config_array[index];
        std::string event_id= event_config["eventId"].asString();
        event_message.EventId = event_config["eventId"].asString();
        if(event_id== "InvalidEvent")
            {
                LOG_MOD(WARNING, logmod)<<"ConfigurationManagerModel:'invalid event enabled for testing'";
                event_message.Type = EventsType::InvalidEvent;
            }
        else if(event_id== "EV5000")
            {
                LOG_MOD(INFO, logmod)<<"ConfigurationManagerModel: EV5000 event";
                event_message.Type = EventsType::EV5000;
            }
        else if(event_id== "EV5001")
            {
                LOG_MOD(INFO, logmod)<<"ConfigurationManagerModel: EV5001 event";
                event_message.Type = EventsType::EV5001;
            }
        else if(event_id== "EV5002")
            {
                LOG_MOD(INFO, logmod)<<"ConfigurationManagerModel: EV5002 event";
                event_message.Type = EventsType::EV5002;
            }
        else if(event_id== "EV5003")
            {
                LOG_MOD(INFO, logmod)<<"ConfigurationManagerModel: EV5003 event";
                event_message.Type = EventsType::EV5003;
            }
        else if(event_id== "EV5004")
            {
                LOG_MOD(INFO, logmod)<<"ConfigurationManagerModel: EV5004 event";
                event_message.Type = EventsType::EV5004;
            }
        else if(event_id== "EV5005")
            {
                LOG_MOD(INFO, logmod)<<"ConfigurationManagerModel: EV5005 event";
                event_message.Type = EventsType::EV5005;
            }
        else if(event_id== "EV5006")
            {
                LOG_MOD(INFO, logmod)<<"ConfigurationManagerModel: EV5006 event";
                event_message.Type = EventsType::EV5006;
            }
        else
            {
            LOG_MOD(INFO, logmod)<<"ConfigurationManagerModel: DynamicEvent";
            event_message.Type = EventsType::DynamicEvent;
            for(CompositeEventConfig& composite_event_config : mCompositeEventConfiguration)
                {
                for(const auto& LogicExprPair : composite_event_config.LogicalExpression)
                    {
                    if(LogicExprPair.first == event_id)
                        {
                            event_message.ComplexEventOperator = LogicExprPair.second;
                            break;
                        }
                    }
                }
            }
            Json::Value event_def = event_config["eventDefinition"];
            if(event_def["eventType"].asString()=="parameterCompare")
                {
                event_message.Operator = event_def["eventOperator"].asString();
                for( Json::Value::const_iterator even_arg = event_def.begin() ; even_arg!= event_def.end() ; ++even_arg )
                    {
                    for( Json::Value::const_iterator event_data = (*even_arg).begin() ; event_data!= (*even_arg).end() ; ++event_data )
                        {
                        Json::Value event_argument = *even_arg;
                        if(event_data.key() == "deviceIds")
                            {
                                Json::Value deviceIds_array = event_argument["deviceIds"];
                                if(deviceIds_array.size()>0)
                                {
                                    event_message.SourceAddress = DaqApp::utils::ConvertIntToHex(std::stoi(deviceIds_array[0].asString()));
                                }
                            }
                        if(event_data.key() == "parameterId")
                            {
                                event_message.Source = event_argument["parameterId"].asString();
                            }
                        if(event_data.key() == "protocol")
                            {
                                event_message.Protocol = event_argument["protocol"].asString();
                            }
                        if(event_data.key() == "argumentValue")
                            {
                                event_message.Threshold = std::stof(event_argument["argumentValue"].asString());
                            }
                        }
                    }
            }
            if(event_message.Protocol == "XCP")
                {
                    event_message.Type = EventsType::DynamicXcpEvent;
                }
            mEventsConfiguration.push_back(event_message);
        }
    }

/**
 *  This function is used to parse Composite Event configuration.
 */
void ConfigurationManagerModel::ParseCompositeEventConfig(const Json::Value& composite_event_array)
    {
    for(unsigned int index = 0; index!=composite_event_array.size(); index++)
        {
            CompositeEventConfig composite_event_config;
            composite_event_config.ConfigID = mConfigIds;
            Json::Value composite_event = composite_event_array[index];
            composite_event_config.CompositeEventId = composite_event["eventId"].asString();
            Json::Value logical_expression_array = composite_event["logicalExpression"];
            for(unsigned int array_index = 0; array_index != logical_expression_array.size(); array_index++)
                {
                    Json::Value logical_expression = logical_expression_array[array_index];
                    composite_event_config.LogicalExpression.push_back
                    ({logical_expression["eventId"].asString(),logical_expression["eventOperator"].asString()});
                }
            mCompositeEventConfiguration.push_back(composite_event_config);
        }
    }

/**
 *  This function is used to add the SPN value if the SPN is not duplicate.
 */
void ConfigurationManagerModel::AddSourceForJ1939()
    {
    for(EventConfigMessage & event_config : mEventsConfiguration)
        {
        bool is_source = false;
        for(J1939ConfigMessage & j1939_config : mJ1939Configuration)
            {
            if((j1939_config.ConfigID == event_config.ConfigID) && (j1939_config.Spn == event_config.Source) && (j1939_config.SourceAddress == event_config.SourceAddress))
                {
                    is_source = true;
                    break;
                }
            }
        if(!is_source && (event_config.Protocol == "J1939"))
            {
                J1939ConfigMessage j1939_config_msg;
                j1939_config_msg.Spn = event_config.Source;
                j1939_config_msg.SourceAddress = event_config.SourceAddress;
                j1939_config_msg.ConfigID = event_config.ConfigID;
                mJ1939Configuration.push_back(j1939_config_msg);
            }
        }
    }

/**
 *  This function is used to parse Data Sampling configuration.
 */
void ConfigurationManagerModel::ParseDataSamplingConfig(const Json::Value& data_sampling_config_array)
    {
        for( unsigned int index = 0; index!= data_sampling_config_array.size(); index++)
            {
				for( auto& dlConfObj : mDataLoggerConfiguration)
                {
					if( dlConfObj.ConfigID == mConfigIds)
                    {
						Json::Value data_sampling_config = data_sampling_config_array[index];
						dlConfObj.MessageFormatVersion = data_sampling_config["messageFormatVersion"].asString();
						if(dlConfObj.MessageFormatVersion.length()>0)
						{
							char version = dlConfObj.MessageFormatVersion.at(0);
							ConfigFrom activeConfigFrom;
							if(version == 'N')
							{
								dlConfObj.IsNavistarConfig = true;
								activeConfigFrom = ConfigFrom::Navistar;
							}
							else
							{
								dlConfObj.IsNavistarConfig = false;
								activeConfigFrom = ConfigFrom::Cummins;
								mClientsManagerModelPtr->ConfigureCAN2Baudrate("500000");		//Set baud rate for CAN 2 to 500k if not Navistar Config
							}
							SetActivatedConfigFrom(activeConfigFrom);
						}
						dlConfObj.DataSamplingConfigId = data_sampling_config["dataSamplingConfigId"].asString();
					}
				}
			}
	}

/**
 * This function is used to parse Activate Data configuration.
*/
void ConfigurationManagerModel::ParseActivateDataConfig(const Json::Value& activate_data_config)
    {
    for( unsigned int index = 0; index!= activate_data_config.size(); index++)
        {
			ActivateDataConfig activateDataConfig;
            Json::Value activate_data = activate_data_config[index];
            activateDataConfig.DataSamplingConfigId = activate_data["dataSamplingConfigIds"][0].asString();
            activateDataConfig.ConfigID = mConfigIds;
            activateDataConfig.ResumeMode = activate_data["resumeMode"].asBool();
            activateDataConfig.DataTransmitMethod = activate_data["dataTransmitMethod"].asString();
            std::string priority = activate_data["dataPriority"].asString();
            if(!priority.empty())
            {
                activateDataConfig.DataPriority = priority;
            }
			mActivateDataConfiguration.push_back(activateDataConfig);
        }
    }

/**
 * This function is used to add sampling rate for EAL configuration.
 */
void ConfigurationManagerModel::SetSamplingRateForEAL()
    {
        for (DataLoggerConfig& data_logger_config : mDataLoggerConfiguration)
        {
            for (UDSConfigMessage& uds_config : mUdsConfiguration)
            {
                if(uds_config.IsEALData && (uds_config.ConfigID == data_logger_config.ConfigID))
                {
                    uds_config.TransmissionRate = data_logger_config.SamplingRate;
                }
            }
        }
    }

/**
 * This function is used to add sampling rate for TripData configuration.
 */
void ConfigurationManagerModel::SetSamplingRateForTripData(uint32_t TransmissionRate)
    {
        for (UDSConfigMessage& uds_config : mUdsConfiguration)
        {
            if(uds_config.IsTripData && (uds_config.ConfigID == mConfigIds))
            {
                uds_config.TransmissionRate = TransmissionRate;
            }
        }

    }

/**
 * This function is used to get transmission rate for TripData configuration.
 */
uint32_t ConfigurationManagerModel::getTransmissionRateForTripData(const Json::Value& root)
    {
        Json::Value data_sampling_spec_array = root["defineDataSamplingSpec"];
        uint32_t  sampling_rate = 0;
        if( data_sampling_spec_array.size()>0)
            {
                Json::Value data_sampling_spec = data_sampling_spec_array[0];
                Json::Value data_sampling_spec_def = data_sampling_spec["dataSamplingSpecDefinition"];
                sampling_rate = std::stof(data_sampling_spec_def["samplingPeriod"].asString());
                std::string sampling_period_unit = data_sampling_spec_def["samplingTransmitPeriodUnit"].asString();
                // If sampling period unit is ms then no conversion is needed
                if(sampling_period_unit == "sec")
                    {
                        sampling_rate = sampling_rate*1000;
                    }
                else if(sampling_period_unit == "min")
                    {
                        sampling_rate = sampling_rate*60*1000;
                    }
                else if(sampling_period_unit == "hr")
                    {
                        sampling_rate = sampling_rate*60*60*1000;
                    }
            }
            return sampling_rate;
    }

/**
 * This function is used to parse DeActivate Data collection configuration.
 */
void ConfigurationManagerModel::ParseDeActivateDataConfig(const Json::Value& deactivate_config_array)
    {
        if(deactivate_config_array.size()>0)
        {
            Json::Value deactivate_config = deactivate_config_array[0];
            Json::Value config_ids = deactivate_config["dataSamplingConfigIds"];
            if (config_ids.size()>0)
            {
                mDeActivateDataConfiguration.DataSamplingConfigIds = config_ids[0].asString();
            }
            mDeActivateDataConfiguration.ConfigID = mConfigIds;
            mDeActivateDataConfiguration.DestinationIdType = deactivate_config["destinationIdType"].asString();
        }
    }

/**
 * This function is used to parse Forget configuration.
 */
void ConfigurationManagerModel::ParseForgetConfig(const Json::Value& forget_definition_array)
    {
        for (unsigned int index = 0; index < forget_definition_array.size(); ++index )
        {
            Json::Value forget_definition = forget_definition_array[index];
            ForgetConfig forgetConfig;
            if(forget_definition.isMember("forgetDefinition"))
            {
                Json::Value forget_def = forget_definition["forgetDefinition"];
                forgetConfig.DefinitionType = forget_def["definitionType"].asString();
                forgetConfig.DefinitionId = forget_def["definitionId"].asString();
                forgetConfig.ConfigID = mConfigIds;
                mForgetConfiguration.push_back(forgetConfig);
            }
        }
    }

/**
 * This function is used to set the activated config either from Cummins or Navistar.
 */
void ConfigurationManagerModel::SetActivatedConfigFrom(ConfigFrom passedConfigFrom)
    {
        mActivatedConfigFrom = passedConfigFrom;
    }

/**
 * This function is used to get the activated config is from Cummins or Navistar.
 */
ConfigFrom ConfigurationManagerModel::GetActivatedConfigFrom()
    {
        return mActivatedConfigFrom;
    }


/**
 * This function is used to get dataSamplingConfigId from activateDataCollection.
 */
std::string ConfigurationManagerModel::GetSamplingConfigId(const Json::Value& activate_config)
{
    if(activate_config.size()>0)
    {
        return activate_config[0]["dataSamplingConfigIds"][0].asString();
    }
    else
    {
        return "";
    }
}

