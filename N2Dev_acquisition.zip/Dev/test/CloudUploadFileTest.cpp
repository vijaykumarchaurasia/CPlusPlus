#include <ecu/com/backend_messageadapter.h>
#include <ecu/com/client.h>
#include "gtest/gtest.h"
#include "AppManager.h"
#include "ClientManagerModel.h"
#include "FilesHandlingModel.h"
#include "CloudServicesModel.h"
#include "DataConnectivityModel.h"
#include "CommonHeader.h"

using namespace DaqApp;

class CloudServicesModelTest : public testing::Test
 {
protected:
    std::shared_ptr<AppManager> mAppManagerPtr;
    CloudServicesModel*   mCloudServiceModelPtr;
    FilesHandlingModel*   mFilesHandlingPtr;
    bool                  mCheckConnectivity;
    const std::string 	  mCorrelationID = "3ee408d4-cd4c-4fc5-b439-8ce171764e82";
	void SetUp() override
	{
        boostfs::remove_all(COMMON_DIR);
        mAppManagerPtr        = std::make_shared<AppManager>();
        mFilesHandlingPtr     = mAppManagerPtr->GetFilesHandlingModel();
        mCloudServiceModelPtr = mFilesHandlingPtr->GetCloudServicesPtr();
        mCheckConnectivity    = mCloudServiceModelPtr->GetDataConnectivityModel()->CheckInternetConnectivity();
        if(mCheckConnectivity)
            {
                mAppManagerPtr->GetClientManagerModel()->SetUpClientManager();
                mFilesHandlingPtr->SetUpFilesHandlingModel();
                mCloudServiceModelPtr->SetUpCloudServicesModel();
            }
    }
	void TearDown() override
	{
       mCloudServiceModelPtr = nullptr;
       mFilesHandlingPtr     = nullptr;
	}
};

// Need to check the internet connectivity is there or not
TEST_F(CloudServicesModelTest, CheckInternetConnectivity)
{
    if(mCheckConnectivity)
    EXPECT_TRUE(mCheckConnectivity);
}

//Uploading the txt file to Navistar cloud which will cover REST API's testing for Initialize, Upload to Blob
//and Notify cloud that file is uploaded successfully
TEST_F(CloudServicesModelTest, CheckFileUploadedToCloud)
{
    //Make sure TestUploadToCloud.txt is present in bin
    std::string fileToUpload = "TestUploadToCloud.txt";
    if(mCheckConnectivity)
    {
        bool boolVal = mCloudServiceModelPtr->UploadFile(fileToUpload, mCorrelationID);
        if(boolVal)
        {
            EXPECT_TRUE(boolVal);
        }
    }
}

//Uploading the txt file which is having spaces in the file name path, supposed to be failed
TEST_F(CloudServicesModelTest, CheckInvalidFileNameFailedToUploadToCloud)
{
    std::string fileToUpload = "TestUploadToCloud(not set).txt";
    if(mCheckConnectivity)
    {
        bool boolVal = mCloudServiceModelPtr->UploadFile(fileToUpload, mCorrelationID);
        EXPECT_FALSE(boolVal);
    }
}

//Uploading the txt file which is not preset at provided file path
TEST_F(CloudServicesModelTest, CheckDeletedFileNameFailedToUploadToCloud)
{
    std::string fileToUpload = "TestUploadToCloud_(not set).txt";
    if(mCheckConnectivity)
    {
        bool boolVal = mCloudServiceModelPtr->UploadFile(fileToUpload, mCorrelationID);
        EXPECT_FALSE(boolVal);
    }
 }

//Upload the configuration file URL and get the uploaded URL blob path from cloud,and use that blobname
//to download the JSON FileURL as input through payload message. Make sure the file get downloaded successfully
TEST_F(CloudServicesModelTest, DownloadZipConfigFileFromFileURL)
{
    if(mCheckConnectivity)
    {
        bool boolVal = mCloudServiceModelPtr->UploadFile("SC1234.zip", mCorrelationID);
        if(boolVal)
        {
            char Payload_fields[2024];
            //JSON string as per schema mentioned in DeviceCommunicationAPI_v1.pdf
            snprintf(Payload_fields, sizeof(Payload_fields), R"({
            "CorrelationId": "75180c5d-c199-4ab2-bd28-eb3f4ce5c1fe",
            "Application": "cumminsa26dataacquisition",
            "PackageType": "configuration",
            "ContentType": "file",
            "ConfigurationType": "cumminsdataacquisition",
            "FileUrl": "%s"})", mCloudServiceModelPtr->GetBlobName().c_str());
            ecu::lapi::config::Configuration_ptr ptrConfig(new ecu::lapi::config::Configuration());
            ecu::lapi::com::ITransportClient_ptr ptrClient;
            PbInternalMessageAdapter<std::string> adapter;
            auto serialize_result = adapter.serialize(Payload_fields);
            if(serialize_result.ok())
            {
                ptrConfig->set("client_name", "DaqCloudTest");
                ptrClient = create_client(ptrConfig,ecu::lapi::com::TransportType::TYPE_MQTT);
                ptrClient->connect();
                ptrClient->start();
                std::this_thread::sleep_for(std::chrono::seconds(5));
                ptrClient->publish("app/cid/112", serialize_result.val());
                std::this_thread::sleep_for(std::chrono::seconds(5));
                ptrClient->stop();
                ptrClient->disconnect();
            }
            EXPECT_TRUE(boostfs::exists(MISC_DIR + "/SC1234.json"));
        }
    }
}

/*Publish the configuration JSON string and make sure the publised JSON content downloaded through
  Backend callback function at path common/Miscellaneous/Configuration.json*/

TEST_F(CloudServicesModelTest, DownloadJsonConfigData)
{
    if(mCheckConnectivity)
    {
        char Payload_fields[1024];
        //JSON string as per schema mentioned in DeviceCommunicationAPI_v1.pdf
        snprintf(Payload_fields, sizeof(Payload_fields), R"({"correlationid": "84f04051-fdd1-477a-91e9-b7992f1ac2ff",
        "configurationtype": "cumminsdataacquisition", "configuration": { "defineECUParameterSpecification": [
        { "ECUParameterSpecId": "XCP_ECU_SPEC_ID", "ecuParameters": [ { "ECUIdentifier": "", "NetworkId": "",
        "BaudRate": "500000", "CANidentifierTx": "100000", "CANidentifierRx": "20000" } ] } ] } })");
        ecu::lapi::config::Configuration_ptr ptrConfig(new ecu::lapi::config::Configuration());
        ecu::lapi::com::ITransportClient_ptr ptrClient;
        PbInternalMessageAdapter<std::string> adapter;
        auto serialize_result = adapter.serialize(Payload_fields);
        if(serialize_result.ok())
        {
            ptrConfig->set("client_name", "DaqCloudTest");
            ptrClient = create_client(ptrConfig,ecu::lapi::com::TransportType::TYPE_MQTT);
            ptrClient->connect();
            ptrClient->start();
            std::this_thread::sleep_for(std::chrono::seconds(5));
            ptrClient->publish("app/cid/112", serialize_result.val());
            std::this_thread::sleep_for(std::chrono::seconds(5));
            ptrClient->stop();
            ptrClient->disconnect();
        }
        EXPECT_TRUE(boostfs::exists(MISC_DIR + "/" + CONFIGURATION_FILE_NAME));
    }
}
