#include <fstream>
#include <boost/filesystem.hpp>
#include <boost/algorithm/string.hpp>
#include <ecu/test/mock_transportclient.h>
#include "gtest/gtest.h"
#include "AppManager.h"
#include "FileWriterModel.h"
#include "Record.h"
#include "FilesHandlingModel.h"
#include "CommonHeader.h"
#include "ConfigurationManagerModel.h"

using namespace DaqApp;

class TestFileWriterModel : public testing::Test
{
protected:
    AppManager*         mAppManager = nullptr;
    FileWriterModel *   mFileWriterModel = nullptr;
    TimeUtilities*      mTimeUtilities = nullptr;
    FilesHandlingModel* mFilesHandlingModel = nullptr;
    std::vector<Record> mRecordDataVect;
    static int          valueCounter;
    FileWriterMessage   mFileWriterMessage;
	void SetUp() override
	{
        boostfs::remove_all(COMMON_DIR);
        mAppManager         = new AppManager();
        mFileWriterModel    = mAppManager->GetFileWriterModel();
        mTimeUtilities      = mAppManager->GetTimeUtilities();
        mFilesHandlingModel = mAppManager->GetFilesHandlingModel();
        mFilesHandlingModel->SetUpFilesHandlingModel();
        CreateMultipleRecordObjects(10,5);
        SetFileWriterMessageData();
	}

	void SetFileWriterMessageData()
	{
        mFileWriterMessage.SamplingProtocolId    = SamplingProtocols::J1939;
        mFileWriterMessage.PriorityId            = Priority::NORMAL;
        mFileWriterMessage.TriggerTypeId         = TriggerType::Periodic;
        mFileWriterMessage.MessageFormatVersion  = "1.1.1";
        mFileWriterMessage.TelematicsBoxId       = "123456";
        mFileWriterMessage.ComponentSerialNumber = "77887788";
        mFileWriterMessage.DataSamplingConfigId  = "SC100";
        mFileWriterMessage.Description           = "Dummy description for testing.";
        mFileWriterMessage.ESN                   = "ESN001";
        mFileWriterMessage.VIN                   = "VIN001";
        mFileWriterMessage.DDID                  = "F201";
        mFileWriterMessage.EALSourceAddr         = "21";
        mFileWriterMessage.IsNavistarConfig      = true;
        mFileWriterMessage.ConfigID              = ConfigIds::ConfigOne;
	}

	void CreateMultipleRecordObjects(int numOfRecords, int numOfSources)
	{
        mRecordDataVect.clear();

        for(int recordIndex=0; recordIndex<numOfRecords; recordIndex++)
        {
            struct Record recordData;
            recordData.TimeStamp = mTimeUtilities->GetTimeDate();

            for(int sourceIndex=0; sourceIndex < numOfSources; sourceIndex++)
            {
                std::string sourceName = "Source_" + std::to_string(sourceIndex+1);
                std::string value = std::to_string(valueCounter + recordIndex);
                recordData.Data.push_back(std::make_pair(sourceName, value));
                valueCounter++;
            }
            mRecordDataVect.push_back(recordData);
        }
	}

	std::string SplitString(const std::string& filePath)
	{
        std::vector<std::string> result;
        boost::split(result, filePath, boost::is_any_of("."));
        return result.at(result.size()-1);
	}

	void TearDown() override
	{
        delete mAppManager;
        mFileWriterModel = nullptr;
        mTimeUtilities = nullptr;
	}
};

// TODO ::  Commenting these test cases because FWM tries to read "KeyCycleCounter.txt" file from N2 device's /root/common folder
// which is not present on VM, thats why test cases are failing

int TestFileWriterModel::valueCounter = 1;
// Check for J1939 / XCP / EAL protocols .csv files get created
// Check for TRIP_DATA protocols .txt file get created
TEST_F(TestFileWriterModel, CheckOutputFileExtension)
{
    boostfs::copy_file("../test/Test_Configuration_EAL.json",(ACTIVE_CONFIG_DIR + "/" + "Test_Configuration_EAL.json"),boostfs::copy_option::overwrite_if_exists);
    EXPECT_TRUE(boostfs::exists(ACTIVE_CONFIG_DIR + "/" + "Test_Configuration_EAL.json"));

    mAppManager->GetConfigurationModel()->SetUpConfigurationManager();

    std::string extension = "";
    mFileWriterMessage.SamplingProtocolId    = SamplingProtocols::J1939;
    mFileWriterModel->WriteOutputFile(mRecordDataVect, mFileWriterMessage);
    extension = SplitString(mFileWriterModel->GetOuputFileName());
    EXPECT_EQ("csv", extension);

    mFileWriterMessage.SamplingProtocolId    = SamplingProtocols::XCP;
    mFileWriterModel->WriteOutputFile(mRecordDataVect, mFileWriterMessage);
    extension = SplitString(mFileWriterModel->GetOuputFileName());
    EXPECT_EQ("csv", extension);

    std::vector<Record> udsDataVect;
    Record record1;
    record1.Data.push_back({"F100","AABBCCDD"});
    udsDataVect.push_back(record1);

    std::vector <uint8_t> tripData = {11,12};
    mFileWriterMessage.SamplingProtocolId    = SamplingProtocols::TRIP_DATA;
    mFileWriterModel->WriteOutputFile(tripData, mFileWriterMessage);
    extension = SplitString(mFileWriterModel->GetOuputFileName());
    EXPECT_EQ("txt", extension);

    Record record2;
    record2.Data.push_back({"F100","ZZXXYYOOPP"});
    Record record3;
    record3.Data.push_back({"F100","VVCCBB"});
    udsDataVect.push_back(record2);
    udsDataVect.push_back(record3);

    mFileWriterMessage.SamplingProtocolId    = SamplingProtocols::EAL;
    mFileWriterModel->WriteOutputFile(udsDataVect, mFileWriterMessage);
    extension = SplitString(mFileWriterModel->GetOuputFileName());
    EXPECT_EQ("csv", extension);
    mFileWriterMessage.SamplingProtocolId    = SamplingProtocols::InvalidProtocol;
    mFileWriterModel->WriteOutputFile(mRecordDataVect, mFileWriterMessage);
    extension = SplitString(mFileWriterModel->GetOuputFileName());
    EXPECT_EQ("", extension);
    // Purposely added use case for TRIP_DATA twice, just to check after invalid protocol whether
    // GetOuputFileName() returns old extension or new correct extension.
    mFileWriterMessage.SamplingProtocolId    = SamplingProtocols::TRIP_DATA;
    mFileWriterModel->WriteOutputFile(tripData, mFileWriterMessage);
    extension = SplitString(mFileWriterModel->GetOuputFileName());
    EXPECT_EQ("txt", extension);
}

// Check if output file is getting created in LOW priority folder
TEST_F(TestFileWriterModel, CheckOutputFileGeneratedInLowPriorityFolder)
{
    mFileWriterMessage.SamplingProtocolId    = SamplingProtocols::J1939;
    mFileWriterMessage.PriorityId            = Priority::LOW;
    mFileWriterModel->WriteOutputFile(mRecordDataVect, mFileWriterMessage);
    EXPECT_EQ(1, mFileWriterModel->GetPriorityFolderFilesCount(Priority::LOW));
}

// Check if output file is getting created in HIGH priority folder
TEST_F(TestFileWriterModel, CheckOutputFileGeneratedInHighPriorityFolder)
{
    mFileWriterMessage.PriorityId            = Priority::HIGH;
    mFileWriterModel->WriteOutputFile(mRecordDataVect, mFileWriterMessage);
    mFileWriterModel->WriteOutputFile(mRecordDataVect, mFileWriterMessage);
    EXPECT_EQ(2, mFileWriterModel->GetPriorityFolderFilesCount(Priority::HIGH));
}

// Check if output file is not getting created for invalid priority
TEST_F(TestFileWriterModel, CheckOutputFileNotGeneratedForInvalidPriority)
{
    mFileWriterMessage.SamplingProtocolId    = SamplingProtocols::J1939;
    mFileWriterMessage.PriorityId            = Priority::InvalidPriority;
    mFileWriterModel->WriteOutputFile(mRecordDataVect, mFileWriterMessage);
    EXPECT_EQ(0, mFileWriterModel->GetPriorityFolderFilesCount(Priority::InvalidPriority));
}

// Check if output file is getting created in NORMAL priority folder
TEST_F(TestFileWriterModel, CheckOutputFileGeneratedInNormalPriorityFolder)
{
    mFileWriterMessage.PriorityId            = Priority::NORMAL;
    mFileWriterModel->WriteOutputFile(mRecordDataVect, mFileWriterMessage);
    mFileWriterModel->WriteOutputFile(mRecordDataVect, mFileWriterMessage);
    mFileWriterModel->WriteOutputFile(mRecordDataVect, mFileWriterMessage);
    EXPECT_EQ(3, mFileWriterModel->GetPriorityFolderFilesCount(Priority::NORMAL));
}

