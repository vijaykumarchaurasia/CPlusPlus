
#include <gtest/gtest.h>
#include <ecu/test/mock_transportclient.h>
#include <ecu/rt/signaladapter.h>
#include "AppManager.h"
#include "DataAccessModel.h"
#include "DtcSamplerModel.h"
#include "ConfigMessage.h"

using namespace DaqApp;
using namespace ecu::lapi;

class DtcSamplerModelTest : public testing::Test
{
protected:
    AppManager*         mAppManagerPtr;
    DtcSamplerModel*    mDtcSamplerModelPtr;
    std::shared_ptr<ecu::lapi::MockSubOnlyTransportClient> mFakeTransportClientPtr;
    void SetUp() override
    {
        mFakeTransportClientPtr = std::make_shared<ecu::lapi::MockSubOnlyTransportClient>();
        mAppManagerPtr = new AppManager();
    }

    void TearDown() override
    {
        delete mDtcSamplerModelPtr;
        delete mAppManagerPtr;
    }
public:
    ecu::lapi::com::Message GetFakeMessage(const std::string& topic,const std::string& signal_name, ecu::lapi::rt::Signal::DATA scaled_value)
    {
        auto& signal_adapter = ecu::lapi::rt::SignalAdapter::instance();
        auto sg_create_result = signal_adapter.create_sg(topic);
        if ( sg_create_result.ok() )
            {
                auto signal_group = sg_create_result.take_val();
                ecu::lapi::rt::Signal::DATA nof_bytesData({0x00,static_cast<unsigned char>(scaled_value.size())});
                if ( signal_group.set_signal_data(signal_name, scaled_value) &&
                     signal_group.set_signal_data("nof_bytes",nof_bytesData))
                    {
                        auto pack_result = signal_adapter.pack(signal_group);
                        if ( pack_result.ok() )
                            {
                                return pack_result.take_val();
                            }
                        else
                            {
                                throw std::invalid_argument("Pack Not Okay!");
                            }
                    }
                else
                    {
                        throw std::invalid_argument("Couldn't set signal data");
                    }
            }
        else
            {
                throw std::invalid_argument("Couldn't create, result not okay !");
            }
    }
};

// Description : Check whether FMI & OC values are correct for single SPNs for DM1 message
TEST_F(DtcSamplerModelTest, SingleSPNsTest)
{
    ecu::lapi::rt::Signal::DATA data = {64, 255, 102, 00, 18, 01, 255, 255};
                                        //40  FF   66  00  12  01   FF   FF
                                        //SPN:102 FMI:18 Count:1
    J1939ConfigMessage j1939ConfigMessage;
    j1939ConfigMessage.Topic   = "rt/telcan/dm1";
    j1939ConfigMessage.Signal  = "data";
    j1939ConfigMessage.Pgn     = "activeFaultCodes";
    j1939ConfigMessage.SourceAddress     = "0x00";
    j1939ConfigMessage.ConfigID = ConfigIds::ConfigOne;
    mDtcSamplerModelPtr = new DtcSamplerModel(mAppManagerPtr,mFakeTransportClientPtr, j1939ConfigMessage);
    auto DataSet = GetFakeMessage(j1939ConfigMessage.Topic, j1939ConfigMessage.Signal, data);
    mFakeTransportClientPtr->message_arrived(j1939ConfigMessage.Topic, DataSet);
    EXPECT_EQ("spn:102~fmi:18~count:1|", mAppManagerPtr->GetDataAccessModel()->Read("activeFaultCodes",j1939ConfigMessage.ConfigID));
    EXPECT_EQ(18, mDtcSamplerModelPtr->GetFmi(102));
    EXPECT_EQ(1, mDtcSamplerModelPtr->GetOc(102));
    EXPECT_CALL(*mFakeTransportClientPtr, unsubscribe(j1939ConfigMessage.Topic, testing::_)).WillOnce(testing::Return());
}

// Description : Check whether FMI & OC values are correct for multiple SPNs for DM1 message
TEST_F(DtcSamplerModelTest, DM1MultipleFaults)
{
    // 3 Faults (1378/31-1) (132/13-1)  (5246/0-1)
    // 0.798000 1  18FECA00x       Rx   d  14   15 FF 62 05 1F 01 84 00 0D 01 7E 14 00 01
    ecu::lapi::rt::Signal::DATA data = {0x15, 0xFF, 0x62, 0x05, 0x1F, 0x01, 0x84, 0x00, 0x0D, 0x01, 0x7E, 0x14, 0x00, 0x01};
    J1939ConfigMessage j1939ConfigMessage;
    j1939ConfigMessage.Topic   = "rt/telcan/dm1";
    j1939ConfigMessage.Signal  = "data";
    j1939ConfigMessage.Pgn     = "activeFaultCodes";
    j1939ConfigMessage.SourceAddress     = "0x00";
    j1939ConfigMessage.ConfigID = ConfigIds::ConfigOne;
    mDtcSamplerModelPtr = new DtcSamplerModel(mAppManagerPtr,mFakeTransportClientPtr, j1939ConfigMessage);;
    auto DataSet = GetFakeMessage(j1939ConfigMessage.Topic, j1939ConfigMessage.Signal, data);
    mFakeTransportClientPtr->message_arrived(j1939ConfigMessage.Topic, DataSet);
    EXPECT_EQ(31, mDtcSamplerModelPtr->GetFmi(1378));
    EXPECT_EQ(1, mDtcSamplerModelPtr->GetOc(1378));
    EXPECT_EQ(13, mDtcSamplerModelPtr->GetFmi(132));
    EXPECT_EQ(1, mDtcSamplerModelPtr->GetOc(132));
    EXPECT_EQ(0, mDtcSamplerModelPtr->GetFmi(5246));
    EXPECT_EQ(1, mDtcSamplerModelPtr->GetOc(5246));
    EXPECT_EQ("spn:1378~fmi:31~count:1|spn:132~fmi:13~count:1|spn:5246~fmi:0~count:1|", mAppManagerPtr->GetDataAccessModel()->Read("activeFaultCodes",j1939ConfigMessage.ConfigID));
    EXPECT_CALL(*mFakeTransportClientPtr, unsubscribe(j1939ConfigMessage.Topic, testing::_)).WillOnce(testing::Return());
}

// Description : Check whether FMI & OC values are correct for multiple SPNs for DM2 message
TEST_F(DtcSamplerModelTest, DM2MultipleFaults)
{
    // 3 Faults (1378/31-1) (132/13-1)  (5246/0-1)
    // 0.798000 1  18FECA00x       Rx   d  14   15 FF 62 05 1F 01 84 00 0D 01 7E 14 00 01
    ecu::lapi::rt::Signal::DATA data = {0x15, 0xFF, 0x62, 0x05, 0x1F, 0x01, 0x84, 0x00, 0x0D, 0x01, 0x7E, 0x14, 0x00, 0x01};
    J1939ConfigMessage j1939ConfigMessage;
    j1939ConfigMessage.Topic   = "rt/telcan/dm2";
    j1939ConfigMessage.Signal  = "data";
    j1939ConfigMessage.Pgn     = "inactiveFaultCodes";
    j1939ConfigMessage.SourceAddress     = "0x00";
    j1939ConfigMessage.ConfigID = ConfigIds::ConfigOne;
    mDtcSamplerModelPtr = new DtcSamplerModel(mAppManagerPtr,mFakeTransportClientPtr, j1939ConfigMessage);;
    auto DataSet = GetFakeMessage(j1939ConfigMessage.Topic, j1939ConfigMessage.Signal, data);
    mFakeTransportClientPtr->message_arrived(j1939ConfigMessage.Topic, DataSet);
    EXPECT_EQ(31, mDtcSamplerModelPtr->GetFmi(1378));
    EXPECT_EQ(1, mDtcSamplerModelPtr->GetOc(1378));
    EXPECT_EQ(13, mDtcSamplerModelPtr->GetFmi(132));
    EXPECT_EQ(1, mDtcSamplerModelPtr->GetOc(132));
    EXPECT_EQ(0, mDtcSamplerModelPtr->GetFmi(5246));
    EXPECT_EQ(1, mDtcSamplerModelPtr->GetOc(5246));
    EXPECT_EQ("spn:1378~fmi:31~count:1|spn:132~fmi:13~count:1|spn:5246~fmi:0~count:1|", mAppManagerPtr->GetDataAccessModel()->Read("inactiveFaultCodes",j1939ConfigMessage.ConfigID));
    EXPECT_CALL(*mFakeTransportClientPtr, unsubscribe(j1939ConfigMessage.Topic, testing::_)).WillOnce(testing::Return());
}

// Description : Check whether FMI & OC values are correct for multiple SPNs for DM27 message
TEST_F(DtcSamplerModelTest, DM27MultipleFaults)
{
    // 3 Faults (1378/31-1) (132/13-1)  (5246/0-1)
    // 0.798000 1  18FECA00x       Rx   d  14   15 FF 62 05 1F 01 84 00 0D 01 7E 14 00 01
    ecu::lapi::rt::Signal::DATA data = {0x15, 0xFF, 0x62, 0x05, 0x1F, 0x01, 0x84, 0x00, 0x0D, 0x01, 0x7E, 0x14, 0x00, 0x01};
    J1939ConfigMessage j1939ConfigMessage;
    j1939ConfigMessage.Topic   = "rt/telcan/dm27";
    j1939ConfigMessage.Signal  = "data";
    j1939ConfigMessage.Pgn     = "pendingFaultCodes";
    j1939ConfigMessage.SourceAddress     = "0x00";
    j1939ConfigMessage.ConfigID = ConfigIds::ConfigOne;
    mDtcSamplerModelPtr = new DtcSamplerModel(mAppManagerPtr,mFakeTransportClientPtr, j1939ConfigMessage);;
    auto DataSet = GetFakeMessage(j1939ConfigMessage.Topic, j1939ConfigMessage.Signal, data);
    mFakeTransportClientPtr->message_arrived(j1939ConfigMessage.Topic, DataSet);
    EXPECT_EQ(31, mDtcSamplerModelPtr->GetFmi(1378));
    EXPECT_EQ(1, mDtcSamplerModelPtr->GetOc(1378));
    EXPECT_EQ(13, mDtcSamplerModelPtr->GetFmi(132));
    EXPECT_EQ(1, mDtcSamplerModelPtr->GetOc(132));
    EXPECT_EQ(0, mDtcSamplerModelPtr->GetFmi(5246));
    EXPECT_EQ(1, mDtcSamplerModelPtr->GetOc(5246));
    EXPECT_EQ("spn:1378~fmi:31~count:1|spn:132~fmi:13~count:1|spn:5246~fmi:0~count:1|", mAppManagerPtr->GetDataAccessModel()->Read("pendingFaultCodes",j1939ConfigMessage.ConfigID));
    EXPECT_CALL(*mFakeTransportClientPtr, unsubscribe(j1939ConfigMessage.Topic, testing::_)).WillOnce(testing::Return());
}

// Description : Check whether spn string & its values are correct for multiple SPNs
TEST_F(DtcSamplerModelTest, MultipleFaults)
{
    J1939ConfigMessage j1939ConfigMessage;
    j1939ConfigMessage.Topic   = "rt/telcan/dm1";
    j1939ConfigMessage.Signal  = "data";
    j1939ConfigMessage.Pgn     = "activeFaultCodes";
    j1939ConfigMessage.SourceAddress     = "0x00";
    j1939ConfigMessage.ConfigID = ConfigIds::ConfigOne;
    ecu::lapi::rt::Signal::DATA data = {0x11, 0xFF, 0x0A, 0x1B, 0x1F, 0x01, 0x72, 0x11, 0x0C, 0x02, 0x1D, 0x84, 0x0A, 0x04};
    mDtcSamplerModelPtr = new DtcSamplerModel(mAppManagerPtr,mFakeTransportClientPtr, j1939ConfigMessage);
    auto DataSet = GetFakeMessage(j1939ConfigMessage.Topic, j1939ConfigMessage.Signal, data);
    mFakeTransportClientPtr->message_arrived(j1939ConfigMessage.Topic, DataSet);
    EXPECT_EQ(31, mDtcSamplerModelPtr->GetFmi(6922));
    EXPECT_EQ(1, mDtcSamplerModelPtr->GetOc(6922));
    EXPECT_EQ(12, mDtcSamplerModelPtr->GetFmi(4466));
    EXPECT_EQ(2, mDtcSamplerModelPtr->GetOc(4466));
    EXPECT_EQ(10, mDtcSamplerModelPtr->GetFmi(33821));
    EXPECT_EQ(4, mDtcSamplerModelPtr->GetOc(33821));
    EXPECT_EQ("spn:6922~fmi:31~count:1|spn:4466~fmi:12~count:2|spn:33821~fmi:10~count:4|", mAppManagerPtr->GetDataAccessModel()->Read("activeFaultCodes",j1939ConfigMessage.ConfigID));
    EXPECT_CALL(*mFakeTransportClientPtr, unsubscribe(j1939ConfigMessage.Topic, testing::_)).WillOnce(testing::Return());
}

// Description : Check whether spn string & its values are correct for different execution order of multiple SPNs
TEST_F(DtcSamplerModelTest, MultipleFaultsWithDiffConditions)
{
    J1939ConfigMessage j1939ConfigMessage;
    j1939ConfigMessage.Topic   = "rt/telcan/dm1";
    j1939ConfigMessage.Signal  = "data";
    j1939ConfigMessage.Pgn     = "activeFaultCodes";
    j1939ConfigMessage.SourceAddress     = "0x00";
    j1939ConfigMessage.ConfigID = ConfigIds::ConfigOne;
    ecu::lapi::rt::Signal::DATA singleSPNData = {64, 255, 102, 00, 18, 01, 255, 255};
    ecu::lapi::rt::Signal::DATA emptyData = {00, 00, 00, 00, 00, 00, 00, 00};
    ecu::lapi::rt::Signal::DATA threeSPNData = {0x15, 0xFF, 0x62, 0x05, 0x1F, 0x01, 0x84, 0x00, 0x0D, 0x01, 0x7E, 0x14, 0x00, 0x01};
    mDtcSamplerModelPtr = new DtcSamplerModel(mAppManagerPtr,mFakeTransportClientPtr, j1939ConfigMessage);
    //Send DM1 with one active fault (1 SPN)
    auto DataSet = GetFakeMessage(j1939ConfigMessage.Topic, j1939ConfigMessage.Signal, singleSPNData);
    mFakeTransportClientPtr->message_arrived(j1939ConfigMessage.Topic, DataSet);
    EXPECT_EQ(18, mDtcSamplerModelPtr->GetFmi(102));
    EXPECT_EQ(1, mDtcSamplerModelPtr->GetOc(102));
    EXPECT_EQ("spn:102~fmi:18~count:1|", mAppManagerPtr->GetDataAccessModel()->Read("activeFaultCodes",j1939ConfigMessage.ConfigID));

    //Send DM1 with no active faults (all zeros)
    DataSet = GetFakeMessage(j1939ConfigMessage.Topic, j1939ConfigMessage.Signal, emptyData);
    mFakeTransportClientPtr->message_arrived(j1939ConfigMessage.Topic, DataSet);
    EXPECT_EQ("spn:0~fmi:0~count:0|", mAppManagerPtr->GetDataAccessModel()->Read("activeFaultCodes",j1939ConfigMessage.ConfigID));

    //Send DM1 with multiple active faults (3 SPNs)
    DataSet = GetFakeMessage(j1939ConfigMessage.Topic, j1939ConfigMessage.Signal, threeSPNData);
    mFakeTransportClientPtr->message_arrived(j1939ConfigMessage.Topic, DataSet);
    EXPECT_EQ(31, mDtcSamplerModelPtr->GetFmi(1378));
    EXPECT_EQ(1, mDtcSamplerModelPtr->GetOc(1378));
    EXPECT_EQ(13, mDtcSamplerModelPtr->GetFmi(132));
    EXPECT_EQ(1, mDtcSamplerModelPtr->GetOc(132));
    EXPECT_EQ(0, mDtcSamplerModelPtr->GetFmi(5246));
    EXPECT_EQ(1, mDtcSamplerModelPtr->GetOc(5246));
    EXPECT_EQ("spn:1378~fmi:31~count:1|spn:132~fmi:13~count:1|spn:5246~fmi:0~count:1|",mAppManagerPtr->GetDataAccessModel()->Read("activeFaultCodes",j1939ConfigMessage.ConfigID));

    //Send DM1 with one active fault (1 SPN)
    DataSet = GetFakeMessage(j1939ConfigMessage.Topic, j1939ConfigMessage.Signal, singleSPNData);
    mFakeTransportClientPtr->message_arrived(j1939ConfigMessage.Topic, DataSet);
    EXPECT_EQ(18, mDtcSamplerModelPtr->GetFmi(102));
    EXPECT_EQ(1, mDtcSamplerModelPtr->GetOc(102));
    EXPECT_EQ("spn:102~fmi:18~count:1|",mAppManagerPtr->GetDataAccessModel()->Read("activeFaultCodes",j1939ConfigMessage.ConfigID));

    //Send DM1 with no active faults (all zeros)
    DataSet = GetFakeMessage(j1939ConfigMessage.Topic, j1939ConfigMessage.Signal, emptyData);
    mFakeTransportClientPtr->message_arrived(j1939ConfigMessage.Topic, DataSet);
    EXPECT_EQ("spn:0~fmi:0~count:0|", mAppManagerPtr->GetDataAccessModel()->Read("activeFaultCodes",j1939ConfigMessage.ConfigID));
    EXPECT_CALL(*mFakeTransportClientPtr, unsubscribe(j1939ConfigMessage.Topic, testing::_)).WillOnce(testing::Return());
}

// Description : Check whether spn string & its values is correct for valid & empty data SPNs
TEST_F(DtcSamplerModelTest, NoFaults)
{
    J1939ConfigMessage j1939ConfigMessage;
    j1939ConfigMessage.Topic   = "rt/telcan/dm1";
    j1939ConfigMessage.Signal  = "data";
    j1939ConfigMessage.Pgn     = "activeFaultCodes";
    j1939ConfigMessage.SourceAddress     = "0x00";
    j1939ConfigMessage.ConfigID = ConfigIds::ConfigOne;
    ecu::lapi::rt::Signal::DATA EmptyData = {00, 00, 00, 00, 00, 00, 00, 00};

    mDtcSamplerModelPtr = new DtcSamplerModel(mAppManagerPtr,mFakeTransportClientPtr, j1939ConfigMessage);
    auto DataSet = GetFakeMessage(j1939ConfigMessage.Topic, j1939ConfigMessage.Signal, EmptyData);
    mFakeTransportClientPtr->message_arrived(j1939ConfigMessage.Topic, DataSet);
    EXPECT_EQ(0, mDtcSamplerModelPtr->GetFmi(0));
    EXPECT_EQ(0, mDtcSamplerModelPtr->GetOc(0));
    EXPECT_EQ("spn:0~fmi:0~count:0|", mAppManagerPtr->GetDataAccessModel()->Read("activeFaultCodes",j1939ConfigMessage.ConfigID));
    EXPECT_CALL(*mFakeTransportClientPtr, unsubscribe(j1939ConfigMessage.Topic, testing::_)).WillOnce(testing::Return());
}

// Test whether app is not crashing / producing unwanted behavior when there is no raw data present
TEST_F(DtcSamplerModelTest, NoRawData)
{
    J1939ConfigMessage j1939ConfigMessage;
    j1939ConfigMessage.Topic   = "rt/telcan/dm1";
    j1939ConfigMessage.Signal  = "data";
    j1939ConfigMessage.Pgn     = "activeFaultCodes";
    j1939ConfigMessage.SourceAddress     = "0x00";
    j1939ConfigMessage.ConfigID = ConfigIds::ConfigOne;
    ecu::lapi::rt::Signal::DATA EmptyRawData = {};
    mDtcSamplerModelPtr = new DtcSamplerModel(mAppManagerPtr,mFakeTransportClientPtr, j1939ConfigMessage);
    auto DataSet = GetFakeMessage(j1939ConfigMessage.Topic, j1939ConfigMessage.Signal, EmptyRawData);
    mFakeTransportClientPtr->message_arrived(j1939ConfigMessage.Topic, DataSet);
    EXPECT_EQ("spn:0~fmi:0~count:0|", mAppManagerPtr->GetDataAccessModel()->Read("activeFaultCodes",ConfigIds::ConfigOne));
    EXPECT_CALL(*mFakeTransportClientPtr, unsubscribe(j1939ConfigMessage.Topic, testing::_)).WillOnce(testing::Return());

}

