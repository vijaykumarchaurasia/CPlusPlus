#include <gtest/gtest.h>
#include "AppManager.h"
#include "DataAccessModel.h"
#include "EventsManagerModel.h"
#include "SimpleEventModelEv5004.h"

using namespace DaqApp;

class SimpleEventModelEv5004Test : public testing::Test
{
protected:

    AppManager*             mAppManagerPtr;
    SimpleEventModelEv5004* mSimpleEv5004Ptr;
    EventConfigMessage      mEventConfigMsg;

    void SetUp() override
    {
        mEventConfigMsg.ConfigID = ConfigIds::ConfigOne;
        mAppManagerPtr = new AppManager();
        mSimpleEv5004Ptr = new SimpleEventModelEv5004(mEventConfigMsg, mAppManagerPtr->GetEventsManagerModel(),mAppManagerPtr);
    }

    void TearDown() override
    {
       delete mSimpleEv5004Ptr;
       delete mAppManagerPtr;
    }
};

TEST_F(SimpleEventModelEv5004Test, EngineSpeedBelow50)
{

    bool WasEv5004SignalEmitted ;
    mAppManagerPtr->GetEventsManagerModel()->ConnectToSignal("EV5004",[&]() {WasEv5004SignalEmitted = true;});
    mSimpleEv5004Ptr->Evaluate();

    // Not active before engine speed is written to the DataAccess
    EXPECT_EQ(false,mSimpleEv5004Ptr->mIsActive);

    // Not active after engine speed is written to the DataAccess without meeting event threshold
    mAppManagerPtr->GetDataAccessModel()->Write(190, 600, Protocol::J1939Proto,mEventConfigMsg.ConfigID);
    mSimpleEv5004Ptr->Evaluate();
    EXPECT_EQ(false,mSimpleEv5004Ptr->mIsActive);

    // Activating event
    mAppManagerPtr->GetDataAccessModel()->Write(190, 35, Protocol::J1939Proto,mEventConfigMsg.ConfigID); // Active when enginespeed is < 50
    mSimpleEv5004Ptr->Evaluate();
    EXPECT_EQ(true,WasEv5004SignalEmitted);   //signal emission check
    EXPECT_EQ(true, mSimpleEv5004Ptr->mIsActive);        //Internal state check

    // DeActiving again
    mAppManagerPtr->GetDataAccessModel()->Write(190, 1000, Protocol::J1939Proto,mEventConfigMsg.ConfigID);
    mSimpleEv5004Ptr->Evaluate();
    EXPECT_EQ(false,mSimpleEv5004Ptr->mIsActive);

    // Activating event with Zero RPM
    mAppManagerPtr->GetDataAccessModel()->Write(190, 0, Protocol::J1939Proto,mEventConfigMsg.ConfigID); // Active when enginespeed is < 50
    mSimpleEv5004Ptr->Evaluate();
    EXPECT_EQ(true,WasEv5004SignalEmitted);   //signal emission check
    EXPECT_EQ(true, mSimpleEv5004Ptr->mIsActive);        //Internal state check
}
