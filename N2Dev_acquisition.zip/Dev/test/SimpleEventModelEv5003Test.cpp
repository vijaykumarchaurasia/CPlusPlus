#include <gtest/gtest.h>
#include "AppManager.h"
#include "DataAccessModel.h"
#include "EventsManagerModel.h"
#include "SimpleEventModelEv5003.h"

using namespace DaqApp;

class SimpleEventModelEv5003Test : public testing::Test
{
protected:

    AppManager*             mAppManagerPtr;
    SimpleEventModelEv5003* mSimpleEv5003Ptr;
    EventConfigMessage      mEventConfigMsg;

    void SetUp() override
    {
        mEventConfigMsg.ConfigID = ConfigIds::ConfigOne;
        mAppManagerPtr = new AppManager();
        mSimpleEv5003Ptr = new SimpleEventModelEv5003(mEventConfigMsg, mAppManagerPtr->GetEventsManagerModel(),mAppManagerPtr);
    }

    void TearDown() override
    {
      delete mSimpleEv5003Ptr;
      delete mAppManagerPtr;
    }
};

TEST_F(SimpleEventModelEv5003Test, EngineSpeedAbove400)
{
    bool WasEv5003SignalEmitted ;
    mAppManagerPtr->GetEventsManagerModel()->ConnectToSignal("EV5003",[&]() {WasEv5003SignalEmitted = true;});

    // Not active before engine speed is written to the DataAccess
    EXPECT_EQ(false,mSimpleEv5003Ptr->mIsActive);

    // Not active after engine speed is written to the DataAccess without meeting event threshold
    mAppManagerPtr->GetDataAccessModel()->Write(190, 200, Protocol::J1939Proto, mEventConfigMsg.ConfigID);
    mSimpleEv5003Ptr->Evaluate();
    EXPECT_EQ(false,mSimpleEv5003Ptr->mIsActive);

    // Activating event
    mAppManagerPtr->GetDataAccessModel()->Write(190, 450, Protocol::J1939Proto,mEventConfigMsg.ConfigID); // Active when enginespeed is > 400
    mSimpleEv5003Ptr->Evaluate();
    EXPECT_EQ(true,WasEv5003SignalEmitted);   //signal emission check
    EXPECT_EQ(true, mSimpleEv5003Ptr->mIsActive);        //Internal state check

    // Activating event
    mAppManagerPtr->GetDataAccessModel()->Write(190, 400, Protocol::J1939Proto,mEventConfigMsg.ConfigID); // Active when enginespeed is > 400
    mSimpleEv5003Ptr->Evaluate();
    EXPECT_EQ(false,mSimpleEv5003Ptr->mIsActive);

    // DeActiving again
    mAppManagerPtr->GetDataAccessModel()->Write(190, 20, Protocol::J1939Proto,mEventConfigMsg.ConfigID);
    mSimpleEv5003Ptr->Evaluate();
    EXPECT_EQ(false,mSimpleEv5003Ptr->mIsActive);
}
