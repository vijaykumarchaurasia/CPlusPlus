
#include "gtest/gtest.h"
#include <ecu/test/mock_transportclient.h>
#include <ecu/test/mock_pgnrequestclient.h>
#include "AppManager.h"
#include "J1939RequesterModel.h"

using namespace DaqApp;

class J1939RequeterTest : public testing::Test
{
protected:
        const double                    mPGN = 65258;
        const uint8_t                   mECMAddr = 0x00;
        AppManager*                     mAppManPtr;
        DaqApp::J1939RequesterModel*    myRequesterPtr;
        std::shared_ptr<ecu::lapi::MockSubOnlyTransportClient> mFakeTransportClientPtr;
        std::shared_ptr<ecu::lapi::diag::MockPgnRequestClient> mFakePGNClientPtr;

	void SetUp() override
	{
        mAppManPtr = new AppManager();
        mFakeTransportClientPtr = std::make_shared<ecu::lapi::MockSubOnlyTransportClient>();
        mFakePGNClientPtr = std::make_shared<ecu::lapi::diag::MockPgnRequestClient>();
        myRequesterPtr = new DaqApp::J1939RequesterModel(mFakePGNClientPtr, mFakeTransportClientPtr, mPGN, mECMAddr, mAppManPtr->GetTimeUtilities(), true);
	}

	void TearDown() override
    {
       delete myRequesterPtr;
       delete mAppManPtr;
    }
};

//----------------------------Actual Test Cases------------------------------
//Requesting parametergroupnumber and sending PGN 65258 for VW request
TEST_F(J1939RequeterTest, J1939_PGN_OnRequester)
{
    EXPECT_CALL(*mFakePGNClientPtr, get_request_token(TOPIC_TEL_PGN_REQUEST_4A,std::chrono::seconds(2))).WillRepeatedly(testing::Return(true));
    EXPECT_CALL(*mFakeTransportClientPtr, publish(TOPIC_TEL_PGN_REQUEST_4A, testing::_)).WillRepeatedly(testing::Return(true));
    std::this_thread::sleep_for(std::chrono::seconds(3));
}
