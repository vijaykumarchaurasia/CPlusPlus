#include "gtest/gtest.h"
#include "AppManager.h"
#include "ConfigurationManagerModel.h"

using namespace DaqApp;

class AppManagerModelTest : public testing::Test
 {

protected:
    std::shared_ptr<AppManager> mAppManagerPtr;
	void SetUp() override
	{
        mAppManagerPtr = std::make_shared<AppManager>();
	}

	void TearDown() override {	}
};

TEST_F(AppManagerModelTest, CheckAllHandels)
{
    EXPECT_NE(nullptr, mAppManagerPtr->GetTimeUtilities());
    EXPECT_NE(nullptr, mAppManagerPtr->GetFilesHandlingModel());
    EXPECT_NE(nullptr, mAppManagerPtr->GetDataAccessModel());
    EXPECT_NE(nullptr, mAppManagerPtr->GetFileWriterModel());
    EXPECT_NE(nullptr, mAppManagerPtr->GetConfigurationModel());
    EXPECT_NE(nullptr, mAppManagerPtr->GetSamplersManagerModel());
    EXPECT_NE(nullptr, mAppManagerPtr->GetEventsManagerModel());
    EXPECT_NE(nullptr, mAppManagerPtr->GetClientManagerModel());
    EXPECT_NE(nullptr, mAppManagerPtr->GetSystemStateReceiver());
}
