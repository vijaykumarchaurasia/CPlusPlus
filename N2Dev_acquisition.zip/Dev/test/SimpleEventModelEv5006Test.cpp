#include <gtest/gtest.h>
#include "AppManager.h"
#include "DataAccessModel.h"
#include "EventsManagerModel.h"
#include "SimpleEventModelEv5006.h"

using namespace DaqApp;

class SimpleEventModelEv5006Test : public testing::Test
{
protected:

    AppManager*             mAppManagerPtr;
    SimpleEventModelEv5006* mSimpleEv5006Ptr;
    EventConfigMessage      mEventConfigMsg;

    void SetUp() override
    {
        mEventConfigMsg.ConfigID = ConfigIds::ConfigOne;
        mAppManagerPtr = new AppManager();
        mSimpleEv5006Ptr = new SimpleEventModelEv5006(mEventConfigMsg, mAppManagerPtr->GetEventsManagerModel(),mAppManagerPtr);
    }

    void TearDown() override
    {
       delete mSimpleEv5006Ptr;
       delete mAppManagerPtr;
    }
};

TEST_F(SimpleEventModelEv5006Test, VerifyEV5006)
{

    bool WasEv5006SignalEmitted ;
    mAppManagerPtr->GetEventsManagerModel()->ConnectToSignal("EV5006",[&]() {WasEv5006SignalEmitted = true;});
    mSimpleEv5006Ptr->Evaluate();

    // Not active before Battery Potential is written to the DataAccess
    EXPECT_EQ(false,mSimpleEv5006Ptr->mIsActive);

    // Not active after Battery Potential is written to the DataAccess without meeting event threshold
    mAppManagerPtr->GetDataAccessModel()->Write(158, 5, Protocol::J1939Proto,mEventConfigMsg.ConfigID);
    mSimpleEv5006Ptr->Evaluate();
    EXPECT_EQ(false,mSimpleEv5006Ptr->mIsActive);

    // Activating event
    mAppManagerPtr->GetDataAccessModel()->Write(158, 7, Protocol::J1939Proto,mEventConfigMsg.ConfigID); // Active when Battery_Potential is >= 6
    mSimpleEv5006Ptr->Evaluate();               //Events evaluated at250ms rate
    EXPECT_EQ(true,WasEv5006SignalEmitted);   //signal emission check
    EXPECT_EQ(true, mSimpleEv5006Ptr->mIsActive);        //Internal state check

    // DeActiving again
    mAppManagerPtr->GetDataAccessModel()->Write(158, 5, Protocol::J1939Proto,mEventConfigMsg.ConfigID);
    mSimpleEv5006Ptr->Evaluate();
    EXPECT_EQ(false,mSimpleEv5006Ptr->mIsActive);
}
