#include <gtest/gtest.h>
#include <ecu/test/mock_transportclient.h>
#include <ecu/rt/signaladapter.h>
#include "J1939Sampler.h"
#include "ConfigMessage.h"
#include "AppManager.h"
#include "DataAccessModel.h"
#include "CommonHeader.h"

using namespace DaqApp;
using namespace ecu::lapi;

class J1939SamplerTest : public testing::Test
{
protected:
    DaqApp::J1939Sampler*   mWheelSpeedSamplerPtr ;
    DaqApp::J1939Sampler*   mPTOSwitchSamplerPtr;
    J1939ConfigMessage      mJ1939Msg1 ;
    J1939ConfigMessage      mJ1939Msg2;
    AppManager*             mAppManagerPtr;
    std::shared_ptr<ecu::lapi::MockSubOnlyTransportClient> mFakeTransportClientPtr;

    void SetUp() override
    {
        mJ1939Msg1.Topic = TOPIC_TEL_E_CCVS1;
        mJ1939Msg1.Signal = "wheelbasedvehiclespeed";
        mJ1939Msg1.Spn = "100";
        mJ1939Msg1.ConfigID = ConfigIds::ConfigOne;

        mJ1939Msg2.Topic = "rt/telcan/e_pto";
        mJ1939Msg2.Signal = "pto_gov_pre_spd_cntrl_switch_a";
        mJ1939Msg2.Spn = "101";
        mJ1939Msg2.ConfigID = ConfigIds::ConfigOne;

        mAppManagerPtr = new AppManager();
        mFakeTransportClientPtr = std::make_shared<ecu::lapi::MockSubOnlyTransportClient>();
        mWheelSpeedSamplerPtr     = new DaqApp::J1939Sampler(mFakeTransportClientPtr,mJ1939Msg1,mAppManagerPtr);
        mPTOSwitchSamplerPtr = new DaqApp::J1939Sampler(mFakeTransportClientPtr,mJ1939Msg2,mAppManagerPtr);
    }

    void TearDown() override
    {
        delete mAppManagerPtr;
        delete mPTOSwitchSamplerPtr;
        delete mWheelSpeedSamplerPtr;

    }

public:

    ecu::lapi::com::Message getFakeMessage(const std::string& topic,const std::string& signal_name, double scaled_value)
    {
        ecu::lapi::com::Message msg;
        //create a signal to mock
        auto& signal_adapter = ecu::lapi::rt::SignalAdapter::instance();
        auto sg_create_result = signal_adapter.create_sg(topic);
        if ( sg_create_result.ok() )
            {
                auto signal_group = sg_create_result.take_val();

                if ( signal_group.set_signal_scaled_value(signal_name, scaled_value) )
                    {

                        // pack SignalGroup into com::Message instance
                        auto pack_result = signal_adapter.pack(signal_group);
                        if ( pack_result.ok() )
                            {

                                return pack_result.take_val();
                            }

                    }

            }

        else
            {
                ecu::lapi::logging::WARNING << "Invalid Signal for topic: " << topic
                                            << std::endl;

            }
            return msg;
    }
};


TEST_F(J1939SamplerTest, TakingLatestSample)
{

    // take the wheel based speed message from result!
    auto whlspd_fake_message1 = getFakeMessage(mJ1939Msg1.Topic,mJ1939Msg1.Signal,200);
    auto whlspd_fake_message2 = getFakeMessage(mJ1939Msg1.Topic,mJ1939Msg1.Signal,144);

    mFakeTransportClientPtr->message_arrived(mJ1939Msg1.Topic, whlspd_fake_message1);

    EXPECT_EQ(200, mAppManagerPtr->GetDataAccessModel()->Read(100,Protocol::J1939Proto,ConfigIds::ConfigOne));

    mFakeTransportClientPtr->message_arrived(mJ1939Msg1.Topic, whlspd_fake_message2);
    mFakeTransportClientPtr->message_arrived(mJ1939Msg1.Topic, whlspd_fake_message1);

    EXPECT_EQ(200, mAppManagerPtr->GetDataAccessModel()->Read(100,Protocol::J1939Proto,ConfigIds::ConfigOne));
    EXPECT_NE(144, mAppManagerPtr->GetDataAccessModel()->Read(100,Protocol::J1939Proto,ConfigIds::ConfigOne));
    EXPECT_CALL(*mFakeTransportClientPtr, unsubscribe(mJ1939Msg1.Topic, testing::_)).WillOnce(testing::Return());
    EXPECT_CALL(*mFakeTransportClientPtr, unsubscribe(mJ1939Msg2.Topic, testing::_)).WillOnce(testing::Return()); // due to calling delete in teardown
}

TEST_F(J1939SamplerTest, RunningTwoJ1939Samplers)
{

    // take fake messages from result!
    auto whlspd_fake_message = getFakeMessage(mJ1939Msg1.Topic,mJ1939Msg1.Signal,200);
    auto pto_switch_fake_message = getFakeMessage(mJ1939Msg2.Topic,mJ1939Msg2.Signal,0);

    // Sampler behave independently, should not get effected after receiving message from second
    mFakeTransportClientPtr->message_arrived(mJ1939Msg1.Topic, whlspd_fake_message);

    // Scaled value
    EXPECT_EQ(200, mAppManagerPtr->GetDataAccessModel()->Read(100,Protocol::J1939Proto,ConfigIds::ConfigOne));

    mFakeTransportClientPtr->message_arrived(mJ1939Msg2.Topic, pto_switch_fake_message);

    EXPECT_EQ(200, mAppManagerPtr->GetDataAccessModel()->Read(100,Protocol::J1939Proto,ConfigIds::ConfigOne));
    EXPECT_EQ(0, mAppManagerPtr->GetDataAccessModel()->Read(101,Protocol::J1939Proto,ConfigIds::ConfigOne));
    EXPECT_CALL(*mFakeTransportClientPtr, unsubscribe(mJ1939Msg1.Topic, testing::_)).WillOnce(testing::Return());
    EXPECT_CALL(*mFakeTransportClientPtr, unsubscribe(mJ1939Msg2.Topic, testing::_)).WillOnce(testing::Return());
}

TEST_F(J1939SamplerTest, VerifyJ1939Sampler)
{
    // take the wheel based speed message from result!
    auto whlspd_fake_message = getFakeMessage(mJ1939Msg1.Topic,mJ1939Msg1.Signal,200);
    mFakeTransportClientPtr->message_arrived(mJ1939Msg1.Topic, whlspd_fake_message);

    // Scaled value
    EXPECT_EQ(200, mAppManagerPtr->GetDataAccessModel()->Read(100,Protocol::J1939Proto,ConfigIds::ConfigOne));
    EXPECT_CALL(*mFakeTransportClientPtr, unsubscribe(mJ1939Msg1.Topic, testing::_)).WillOnce(testing::Return());
    EXPECT_CALL(*mFakeTransportClientPtr, unsubscribe(mJ1939Msg2.Topic, testing::_)).WillOnce(testing::Return()); // due to calling delete in teardown
}
