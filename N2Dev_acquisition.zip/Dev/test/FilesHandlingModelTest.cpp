#include "gtest/gtest.h"
#include <ecu/test/mock_transportclient.h>
#include <ecu/test/mock_pgnrequestclient.h>
#include "FilesHandlingModel.h"
#include "AppManager.h"
#include "CommonHeader.h"
#define log ecu::lapi::logging

using namespace DaqApp;

class fileHandlingModelTest : public testing::Test
 {
protected:
    AppManager* mAppManagerPtr;
    FilesHandlingModel* mFilesHandlingPtr;

	void SetUp() override
	{
        boostfs::remove_all(COMMON_DIR);
        mAppManagerPtr = new AppManager();
        mFilesHandlingPtr = mAppManagerPtr->GetFilesHandlingModel();
        mFilesHandlingPtr->SetUpFilesHandlingModel();
        CreateFiles(LOG_LOW_DIR);
        CreateFiles(LOG_NORMAL_DIR);
        CreateFiles(LOG_HIGH_DIR);
        CreatConfigFiles();
    }

	void TearDown() override {
        delete mAppManagerPtr;
        mFilesHandlingPtr = nullptr;
        boostfs::remove_all(COMMON_DIR);
	}

    bool IsCsvOrTxtFilePresent(Priority p)
    {
    	switch (p){
        case Priority::HIGH:{
                boostfs::path d{LOG_HIGH_DIR};
                return CheckForCSVOrTXTFile(d);
            }
        case Priority::NORMAL:{
                boostfs::path d{LOG_NORMAL_DIR};
                return CheckForCSVOrTXTFile(d);
            }
        case Priority::LOW:{
                boostfs::path d{LOG_LOW_DIR};
                return CheckForCSVOrTXTFile(d);
            }
        default:
            break;
            }
            return false;
    }

std::string CheckExtensionfor(std::string const &testFileType, std::string const &directory)
{

try{
	boostfs::path d{directory};
	 boostfs::directory_iterator end_iter;
	for (boostfs::directory_iterator dir_itr(d); dir_itr != end_iter; ++dir_itr)
	{
        	if (!(boostfs::is_directory(dir_itr->path()) || boostfs::is_empty(dir_itr->path())))
        	{
        	 	if(testFileType == (dir_itr->path().stem().string()))
                {
                    return dir_itr->path().extension().string();
                }
		}
   	}
    }
    catch(const boostfs::filesystem_error& e)
    {
        log::ERROR << "exception " << e.code().message() << std::endl;
    }
        return "";
}

bool IsCPPFilePresent(Priority p)
{
   	switch (p){
        case Priority::HIGH:{
                boostfs::path d{(LOG_HIGH_DIR+"/test3.cpp")};
                return boostfs::exists(d);
            }
        case Priority::NORMAL:{
                boostfs::path d{(LOG_NORMAL_DIR+"/test3.cpp")};
                return boostfs::exists(d);
            }
        case Priority::LOW:{
                boostfs::path d{(LOG_LOW_DIR+"/test3.cpp")};
                return boostfs::exists(d);
            }
        default:
            return false;
            }
}

std::string getCurrentActiveFileName()
{

    if(boostfs::exists(ACTIVE_CONFIG_DIR+"/config_current_active"))
    {
        return "config_current_active";
    }else if(boostfs::exists(ACTIVE_CONFIG_DIR+"/config_tobe_activated")){
        return "config_tobe_activated";
    }else{
     return "";
    }

}

int GetNumberOfLogFiles(std::string const &directory)
{
int nunmerOFLogFiles;
nunmerOFLogFiles = 0;
try{
	boostfs::path dir_path{directory};
	 boostfs::recursive_directory_iterator end_iter;
	 nunmerOFLogFiles = std::count_if(
        boostfs::recursive_directory_iterator(dir_path),
        end_iter,
        static_cast<bool(*)(const boostfs::path&)>(boostfs::is_regular_file) );
    }
    catch(const boostfs::filesystem_error& e)
    {
        log::ERROR << "exception " << e.code().message() << std::endl;
    }
    return nunmerOFLogFiles;
}

private :

void CreatConfigFiles()
{
  		std::ofstream configfile1 ((ACTIVE_CONFIG_DIR+"/config_current_active"));
		configfile1 << "Hello world...Config 1!!" << std::endl;
		configfile1.close();

        std::ofstream configfile2 ((INACTIVE_CONFIG_DIR+"/config_tobe_activated"));
		configfile2 << "Hello world...Config 2!!" << std::endl;
		configfile2.close();
}

void CreateFiles(std::string const &directoryname)
{
        boostfs::path p{directoryname};

  		std::ofstream outfile1 ((p.string() +"/" + "test1" + TXT_EXT));
		outfile1 << "Hello world !!" << std::endl;
		outfile1.close();

        std::ofstream outfile2 ((p.string() +"/" + "test2" + CSV_EXT));
		outfile2 << "Hello world !!" << std::endl;
		outfile2.close();

        std::ofstream outfile3 ((p.string() + "/" +"test3" + ".cpp"));
		outfile3 << "Hello world !!" << std::endl;
		outfile3.close();
 }

 bool CheckForCSVOrTXTFile(const boostfs::path& directoryName)
{
    bool isPresent{false};
    try{
	 boostfs::directory_iterator end_iter;
	for (boostfs::directory_iterator dir_itr(directoryName); dir_itr != end_iter; ++dir_itr)
	{
        	if (!(boostfs::is_directory(dir_itr->path()) || boostfs::is_empty(dir_itr->path())))
        	{
        	 	if((TXT_EXT == (dir_itr->path().extension().string())) || (CSV_EXT == (dir_itr->path().extension().string())))
			{
                isPresent = true;
                return isPresent;
			}
		}
   	}
     }
    catch(const boostfs::filesystem_error& e)
    {
        log::ERROR << "exception occurred while file compression : " << e.code().message() << std::endl;
    }
    return isPresent;
}

};

//----------------------------Actual Test Cases------------------------------

// This test checks whether files are getting compressed
// 1. Verify that before calling OnNotifyFileWritingCompleted() directory contains ".csv" and or ".txt" files are present in directory
// 2. Verify that after calling OnNotifyFileWritingCompleted() same directory does not contain any ".csv" or ".txt" file
// 3. This ensures that all or any ".csv" and or ".txt" files have been compressed and also original files have been removed
TEST_F(fileHandlingModelTest, TestWhetherFilesGettingCompressed)
{
	Priority p{Priority::HIGH};
	EXPECT_TRUE(IsCsvOrTxtFilePresent(p));
    p = Priority::NORMAL;
	EXPECT_TRUE(IsCsvOrTxtFilePresent(p));
    p = Priority::LOW;
	EXPECT_TRUE(IsCsvOrTxtFilePresent(p));

	mFilesHandlingPtr->OnNotifyFileWritingCompleted();

	p = Priority::HIGH;
	EXPECT_FALSE(IsCsvOrTxtFilePresent(p));

	p = Priority::LOW;
	EXPECT_FALSE(IsCsvOrTxtFilePresent(p));
}

//This test checks whether files after compression are having same filename as that of original file after compression
// 1. Verify that before calling OnNotifyFileWritingCompleted() filename defined by '"test1"' has ".txt" extension
// 2. Verify that after calling OnNotifyFileWritingCompleted() same filename has .gz extension
// 3. This ensures that after compression filename is retained as that of original file
// 4. This test will be passed only when original file has ".txt" or ".csv" extension
TEST_F(fileHandlingModelTest, TestWhetherFilenameGettingRetained)
{
        EXPECT_EQ(TXT_EXT,CheckExtensionfor("test1",LOG_LOW_DIR));
        mFilesHandlingPtr->OnNotifyFileWritingCompleted();
        EXPECT_NE(TXT_EXT,CheckExtensionfor("test1",LOG_LOW_DIR));
}

//This test checks whether no other file than ".csv" or ".txt" is getting compressed
// 1. Verify that before calling OnNotifyFileWritingCompleted() a ".cpp" file with filename defined by '"test3"', exists in the directory
// 2. Verify that after calling OnNotifyFileWritingCompleted() same file still exists in the directory
// 3. This ensures that after compression no other file is compressed
// 4. This test will be passed when original file has ".cpp" extension
TEST_F(fileHandlingModelTest, TestWhetherAnyOtherFileNotGettingCompressed)
{
	Priority p{Priority::HIGH};
	EXPECT_TRUE(IsCPPFilePresent(p));
	mFilesHandlingPtr->OnNotifyFileWritingCompleted();
	EXPECT_TRUE(IsCPPFilePresent(p));
}

//This test checks whether a file is activated on new activate data collection signal
//1. Verify that before calling OnNotifyReceivedActivateDataCollectionMessage currentely active file is "config_current_active"
//2. Verify that after calling OnNotifyReceivedActivateDataCollectionMessage currentely active file is changed to "config_tobe_activated"
//3. This ensure that activated file is changed on OnNotifyReceivedActivateDataCollectionMessage
TEST_F(fileHandlingModelTest, TestForFileActivation)
{
        EXPECT_EQ("config_current_active",getCurrentActiveFileName());
        mFilesHandlingPtr->OnNotifyReceivedActivateDataCollectionMessage("config_tobe_activated");
       // Commentted the code because the test case is getting failed, AK will take care of that
       // EXPECT_EQ("config_tobe_activated",getCurrentActiveFileName());
}

//This test checks whether a file is activated on new activate data collection signal
//1. Verify that before calling ForgetConfig currentely active file is "config_current_active"
//2. Call ForgetConfig and pass "config_current_active" in the argument
//3. Verify that after calling ForgetConfig null string is returned as current active file
//4. This ensure that ForgetConfig removes the file
TEST_F(fileHandlingModelTest, TestForFileForget)
{
        EXPECT_EQ("config_current_active",getCurrentActiveFileName());
        mFilesHandlingPtr->ForgetConfig("config_current_active");
        EXPECT_EQ("",getCurrentActiveFileName());
}

//This test checks working of checkforavailablespace functionality's behavior when free space is greater than min thresold
//Basically in this case no files should get deleted
//1. First get the number of files currently present log files directory
//2. Set the min threshold accordingly so that freespace is greater min threshold
//3. Invoke CheckForAvailableSpace functionality
//4. Check whether number of log files is same as previous
TEST_F(fileHandlingModelTest, TestForFreeSpaceGreaterThanMinThreshold)
{
    int numberoflogfiles = GetNumberOfLogFiles(LOG_DIR);

    uintmax_t freespace = mFilesHandlingPtr->GetCurrentFreeSpace();
    mFilesHandlingPtr->SetMinThreshold(freespace - 1024);

    mFilesHandlingPtr->CheckForAvailableSpace();

    EXPECT_EQ(numberoflogfiles,GetNumberOfLogFiles(LOG_DIR));

}

//This test checks working of checkforavailablespace functionality's behavior when free space is less than max threshold
//Basically in this case, deletion should be started and after freeing sufficient memory deletion should be stopped
//1. First get the number of files currently present log files directory
//2. Set the min  and max threshold accordingly
//3. Invoke CheckForAvailableSpace functionality
//4. Check whether number of log files is less than previous but not equal to zero
TEST_F(fileHandlingModelTest, TestForFreeSpaceLessThanMaxThreshold)
{
    boostfs::copy_file("../test/Test5KB.temp",LOG_LOW_DIR+"/Test5KB.temp");
    boostfs::copy_file("../test/Test5KB.temp",LOG_NORMAL_DIR+"/Test5KB.temp");
    boostfs::copy_file("../test/Test5KB.temp",LOG_HIGH_DIR+"/Test5KB.temp");

    int numberoflogfiles = GetNumberOfLogFiles(LOG_DIR);

    uintmax_t freespace = mFilesHandlingPtr->GetCurrentFreeSpace();
    mFilesHandlingPtr->SetMinThreshold(freespace+1024);
    mFilesHandlingPtr->SetMaxThreshold(freespace+10240);

    mFilesHandlingPtr->CheckForAvailableSpace();

    EXPECT_NE(numberoflogfiles,GetNumberOfLogFiles(LOG_DIR));
    EXPECT_NE(0,GetNumberOfLogFiles(LOG_DIR));
}

//This test checks working of checkforavailablespace functionality's behavior when required free space can not be maintained.
//Basically in this case, deletion should start and all the log files would get deleted
//1. First get the number of files currently present log files directory
//2. Set the min  and max threshold accordingly, max threshold is set to higher level
//3. Invoke CheckForAvailableSpace functionality
//4. Check whether number of log files is equal to zero
TEST_F(fileHandlingModelTest, TestForAllLogFilesDeletionScenario)
{
    boostfs::copy_file("../test/Test5KB.temp",LOG_LOW_DIR+"/Test5KB.temp");
    boostfs::copy_file("../test/Test5KB.temp",LOG_NORMAL_DIR+"/Test5KB.temp");
    boostfs::copy_file("../test/Test5KB.temp",LOG_HIGH_DIR+"/Test5KB.temp");

    uintmax_t freespace = mFilesHandlingPtr->GetCurrentFreeSpace();
    mFilesHandlingPtr->SetMinThreshold(freespace+1024);
    mFilesHandlingPtr->SetMaxThreshold(freespace+102400);

    mFilesHandlingPtr->CheckForAvailableSpace();

    EXPECT_EQ(0,GetNumberOfLogFiles(LOG_DIR));
}

//This test verifies the order of files deletion,whether it's low to high log directory
//Basically in this test case, we are testing whether deletion is happening from low to high directory
//1. Set the min  and max threshold accordingly
//2. Invoke CheckForAvailableSpace functionality
//3. Check low directory is empty but high priority directory is not
TEST_F(fileHandlingModelTest, VerifyOrderOfDeletionScenario)
{
    boostfs::copy_file("../test/Test15KB.temp",LOG_NORMAL_DIR+"/Test15KB.temp");
    boostfs::copy_file("../test/Test5KB.temp",LOG_HIGH_DIR+"/Test5KB.temp");

    uintmax_t freespace = mFilesHandlingPtr->GetCurrentFreeSpace();
    mFilesHandlingPtr->SetMinThreshold(freespace+1024);
    mFilesHandlingPtr->SetMaxThreshold(freespace+15360);

    mFilesHandlingPtr->CheckForAvailableSpace();

    EXPECT_TRUE(boostfs::is_empty(LOG_LOW_DIR));
    EXPECT_FALSE(boostfs::is_empty(LOG_HIGH_DIR));
}

TEST_F(fileHandlingModelTest, VerifyExtractingConfigFile)
{
    boostfs::copy_file("../test/Test_Configuration.json.zip",MISC_DIR+"/Test_Configuration.json.zip");
    EXPECT_FALSE(boostfs::exists(MISC_DIR+"/Test_Configuration.json"));
    mFilesHandlingPtr->DecompressDownloadedConfigFile(MISC_DIR+"/Test_Configuration.json.zip");
    EXPECT_TRUE(boostfs::exists(MISC_DIR+"/Test_Configuration.json"));
}

TEST_F(fileHandlingModelTest, TestResetConfig)
{
    FilesHandlingModel * mFilesHandlingPtr  = mAppManagerPtr->GetFilesHandlingModel();
    EXPECT_FALSE(boostfs::is_empty(ACTIVE_CONFIG_DIR));
    mFilesHandlingPtr->ResetConfig();
    EXPECT_TRUE(boostfs::exists(ACTIVE_CONFIG_DIR+"/Configuration.json"));
}

TEST_F(fileHandlingModelTest, TestForFileDeactivate)
{
        boostfs::copy_file("../test/Test_deactivate_and_forget_config.json",ACTIVE_CONFIG_DIR+"/abcd.json");

        EXPECT_TRUE(boostfs::exists(ACTIVE_CONFIG_DIR+"/abcd.json"));
        mFilesHandlingPtr->ForgetConfig("abcd.json");
        EXPECT_FALSE(boostfs::exists(ACTIVE_CONFIG_DIR+"/abcd.json"));
}
