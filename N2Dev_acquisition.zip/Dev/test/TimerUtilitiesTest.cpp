#include "gtest/gtest.h"
#include "AppManager.h"
#include "TimeUtilities.h"
using namespace DaqApp;

class TimerTest : public testing::Test
 {
protected:
    std::shared_ptr<AppManager> mAppManagerPtr;
    TimeUtilities*              mTimeUtilitiesPtr;
	void SetUp() override
	  {
        mAppManagerPtr    = std::make_shared<AppManager>();
        mTimeUtilitiesPtr = mAppManagerPtr->GetTimeUtilities();
	  }
	void TearDown() override
    {
        mTimeUtilitiesPtr = nullptr;
    }
public:
    void Function1()
    {
        std::cout<<"Function1 called\n";
    }

    void Function2()
    {
        std::cout<<"Function2 called\n";
    }

    void Function3()
    {
        std::cout<<"Function3 called\n";
    }

    TickId CallTickForRequestTimerFunction1()
    {
        return mTimeUtilitiesPtr->Tick(ms(1500), Redundancy::DoOnce, &TimerTest::Function1,this);
    }

    TickId CallTickForRequestTimerFunction2()
    {
        return mTimeUtilitiesPtr->Tick(ms(1000), Redundancy::Infinite, &TimerTest::Function2,this);
    }

    TickId CallTickForRequestTimerFunction3()
    {
        return mTimeUtilitiesPtr->Tick(ms(2000), Redundancy::Infinite, &TimerTest::Function3,this);
    }
};

void PrintMap(std::map<TickId, TickIdPtr> *funcRefMap)
{
    std::cout<<"Size of map is "<< funcRefMap->size()<<std::endl;
    for (auto it = funcRefMap->begin(); it != funcRefMap->end(); it++ )
    {
        std::cout<<"Key :"<<it->first <<" Value :"<< it->second<<std::endl;
    }
}

//----------------------------Actual Test Cases------------------------------
TEST_F(TimerTest, VerifyReleaseTick)
{
    TickId tickIdFunction1 = CallTickForRequestTimerFunction1();
    TickId tickIdFunction2 = CallTickForRequestTimerFunction2();
    TickId tickIdFunction3 = CallTickForRequestTimerFunction3();
    std::cout<<"TickId of Function1="<<tickIdFunction1<<std::endl;
    std::cout<<"TickId of Function2="<<tickIdFunction2<<std::endl;
    std::cout<<"TickId of Function3="<<tickIdFunction3<<std::endl;
    std::this_thread::sleep_for(std::chrono::seconds(5));
    std::map<TickId,TickIdPtr> *funcRefMultimap;
    mTimeUtilitiesPtr->ReleaseTick(tickIdFunction1);
    //Get map and print the data
    funcRefMultimap = mTimeUtilitiesPtr->GetFunctionMap();
    PrintMap(funcRefMultimap);
    EXPECT_FALSE(funcRefMultimap->empty());
    mTimeUtilitiesPtr->ReleaseTick(tickIdFunction2);
    mTimeUtilitiesPtr->ReleaseTick(tickIdFunction3);
    std::this_thread::sleep_for(std::chrono::seconds(2));
}
