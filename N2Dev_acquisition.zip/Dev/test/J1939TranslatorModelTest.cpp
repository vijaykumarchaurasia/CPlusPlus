#include "gtest/gtest.h"
#include "AppManager.h"
#include "ConfigurationManagerModel.h"
#include "ConfigMessage.h"
#include "TranslatorModel.h"
#include "CommonHeader.h"

using namespace DaqApp;
class J1939TranslatorTest : public testing::Test
{
protected:
    std::shared_ptr<AppManager>             mAppManagerPtr;
    std::unique_ptr<JsonParserModel>        mJsonParserPtr;
    std::unique_ptr<TranslatorModel>        mTranslatorPtr;
    ConfigurationManagerModel*          mConfigManagerPtr;
    FilesHandlingModel*              mFilesHandlingModelPtr;

	void SetUp() override
	{
        mAppManagerPtr = std::make_shared<AppManager>();
        mJsonParserPtr = std::make_unique<JsonParserModel>();
        mFilesHandlingModelPtr = mAppManagerPtr->GetFilesHandlingModel();
        mConfigManagerPtr = mAppManagerPtr->GetConfigurationModel();
        mTranslatorPtr = std::make_unique<TranslatorModel>(mFilesHandlingModelPtr);
        mFilesHandlingModelPtr->SetUpFilesHandlingModel();
        mTranslatorPtr->SetUpTranslatorModel();
    }

	void TearDown() override
	 {
        mConfigManagerPtr = nullptr;
        mFilesHandlingModelPtr = nullptr;
     }
};

//----------------------------Actual Test Case------------------------------
//Requesting 190 SPN to get PGN, Topic and Onrequest data.
TEST_F(J1939TranslatorTest, J1939_Translator_PGN_OnRequester)
{
    std::vector<J1939ConfigMessage> configList;
    struct J1939ConfigMessage J1939ConfigStr;
    configList.push_back(J1939ConfigMessage("","","2791","","0x00",false));
    //Get 2791 SPN's information like Topic name, PGN and OnRequest information
    bool retVal = mTranslatorPtr->Translate(&configList);
    EXPECT_EQ(true, retVal);
    if(retVal)
    {
        J1939ConfigStr = configList.at(0);
        EXPECT_EQ("64981", J1939ConfigStr.Pgn);
        EXPECT_EQ("rt/telcan/e_eec5", J1939ConfigStr.Topic);
        EXPECT_EQ(false, J1939ConfigStr.IsCyclic);
    }
}

TEST_F(J1939TranslatorTest, Same_SPN_Diff_Sourceaddress_and_signal)
{
    Json::Value parsed_json_val =  mJsonParserPtr->ParseJsonFile("../test/Test_Configuration_Same_SPN_Different_with_SourceAddress.json");
    mConfigManagerPtr->ParseJson(parsed_json_val);
    std::vector<J1939ConfigMessage> J1939Configuration = mConfigManagerPtr->GetJ1939Config();
    mTranslatorPtr->Translate(&J1939Configuration);

    EXPECT_EQ("84",J1939Configuration.at(1).Spn);
    EXPECT_EQ("0x00",J1939Configuration.at(1).SourceAddress);
    EXPECT_EQ("rt/telcan/e_ccvs1",J1939Configuration.at(1).Topic);
    EXPECT_EQ("65265",J1939Configuration.at(1).Pgn);
    EXPECT_EQ("wheelbasedvehiclespeed",J1939Configuration.at(1).Signal);
    EXPECT_TRUE(J1939Configuration.at(1).IsCyclic);
    EXPECT_EQ("84",J1939Configuration.at(2).Spn);
    EXPECT_EQ("0x21",J1939Configuration.at(2).SourceAddress);
    EXPECT_EQ("rt/telcan/e_ccvs1_21",J1939Configuration.at(2).Topic);
    EXPECT_EQ("65265",J1939Configuration.at(2).Pgn);
    EXPECT_EQ("wheelbasedvehiclespeed_21",J1939Configuration.at(2).Signal);
    EXPECT_TRUE(J1939Configuration.at(2).IsCyclic);
}

TEST_F(J1939TranslatorTest, SameSPNDifferentSARangeDecimal10To15)
{
    Json::Value parsed_json_val =  mJsonParserPtr->ParseJsonFile("../test/Test_ConfigSameSPNDifferentSARangeDecimal10To15.json");
    mConfigManagerPtr->ParseJson(parsed_json_val);
    std::vector<J1939ConfigMessage> J1939Configuration = mConfigManagerPtr->GetJ1939Config();
    mTranslatorPtr->Translate(&J1939Configuration);
    //Decimal Source address in config is 33
    EXPECT_EQ("1792",J1939Configuration.at(0).Spn);
    EXPECT_EQ("0x21",J1939Configuration.at(0).SourceAddress);
    EXPECT_EQ("rt/telcan/bc_ebc1_1",J1939Configuration.at(0).Topic);
    EXPECT_EQ("61441",J1939Configuration.at(0).Pgn);
    EXPECT_EQ("trailer_abs",J1939Configuration.at(0).Signal);
    EXPECT_TRUE(J1939Configuration.at(0).IsCyclic);
    //Decimal Source address in config is 11
    EXPECT_EQ("1792",J1939Configuration.at(1).Spn);
    EXPECT_EQ("0x0B",J1939Configuration.at(1).SourceAddress);
    EXPECT_EQ("rt/telcan/bc_ebc1_1_b",J1939Configuration.at(1).Topic);
    EXPECT_EQ("61441",J1939Configuration.at(1).Pgn);
    EXPECT_EQ("trailer_abs_b",J1939Configuration.at(1).Signal);
    EXPECT_TRUE(J1939Configuration.at(1).IsCyclic);
}


