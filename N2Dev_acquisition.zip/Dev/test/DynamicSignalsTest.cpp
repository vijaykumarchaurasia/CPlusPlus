#include "gtest/gtest.h"
#include "EventsManagerModel.h"
#include "AppManager.h"

using namespace DaqApp;

class DynamicSignalsTest : public testing::Test
{
protected:
    AppManager*         mAppManagerPtr;
    EventsManagerModel* mEventManagerPtr;
    bool                mIsSlotFunctionCalled{false};
    std::string         mSignalName{"SomeSignalName"};

    void SetUp() override
    {
        mAppManagerPtr    = new AppManager();
    	mEventManagerPtr  = mAppManagerPtr->GetEventsManagerModel();
    }

    void TearDown() override
    { }

 /*   void requestDisconnect()
    {
        mEventManagerPtr->DisconnectFromSignal(mSignalName,reinterpret_cast<void (*)()> (&DynamicSignalsTest::MySlot));
    } */
public:
    void MySlot ()
    {
        mIsSlotFunctionCalled = true;
    }
};

TEST_F(DynamicSignalsTest, TestEventManagerModel)
{
    mEventManagerPtr->AddSignal(mSignalName);
    std::cout<<"test signal added"<<std::endl;
    bool isSlotConnectedToSignal = mEventManagerPtr->ConnectToSignal(mSignalName,boost::bind(&DynamicSignalsTest::MySlot,this));
    std::cout<<"test Signal connected" << std::endl;
    EXPECT_TRUE(isSlotConnectedToSignal);

    EXPECT_FALSE(mIsSlotFunctionCalled);
    mEventManagerPtr->EmitSignal(mSignalName);
    std::cout<<"test Signal emitted" << std::endl;
    EXPECT_TRUE(mIsSlotFunctionCalled);

/*    requestDisconnect();
   mIsSlotFunctionCalled = false;
   mEventManagerPtr->EmitSignal(mSignalName);
   EXPECT_FALSE(mIsSlotFunctionCalled);*/  //test case to check disconnection of signal
}