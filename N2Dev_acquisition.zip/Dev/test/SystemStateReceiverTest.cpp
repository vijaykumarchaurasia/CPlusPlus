#include <gtest/gtest.h>
#include <ecu/test/mock_transportclient.h>
#include <ecu/rt/signaladapter.h>
#include <ecu/com/messageadapter.h>
#include <ecu/pb/ecu.pb.h>
#include "EventsManagerModel.h"
#include "AppManager.h"
#include "SystemStateReceiver.h"
#include "CommonHeader.h"

using namespace DaqApp;
using namespace ecu::lapi;
using namespace ecu::lapi::pb;
using namespace ecu::lapi::com;

class SystemStateReceiverTest : public testing::Test
{
protected:
    AppManager*                                             mAppManagerPtr;
    std::shared_ptr<ecu::lapi::MockSubOnlyTransportClient>  mFakeTransportClientPtr;
	DaqApp::SystemStateReceiver*                            mSysShutdownReceiver;

    void SetUp() override
    {
        mAppManagerPtr = new AppManager();
        mFakeTransportClientPtr = std::make_shared<ecu::lapi::MockSubOnlyTransportClient>();
        mSysShutdownReceiver = new DaqApp::SystemStateReceiver(mAppManagerPtr);
        mSysShutdownReceiver->SetupSystemStateReceiver(mFakeTransportClientPtr);
    }

    void TearDown() override
    {
        delete mAppManagerPtr;
        delete mSysShutdownReceiver;
    }

public :
void RequestShutDown()
{
	EcuShutdownStatus shutdownst;
	shutdownst.set_state(EcuShutdownStatus_State::EcuShutdownStatus_State_SHUTDOWN_PENDING);
	PbInternalMessageAdapter<EcuShutdownStatus> adapter;
	auto result = adapter.serialize(shutdownst);
	if (result.ok()) {
	mFakeTransportClientPtr->message_arrived(TOPIC_SHUTDOWN_STATUS, result.val());
   }
}
};

TEST_F(SystemStateReceiverTest, TestShutDownSignal)
{
    bool WasEv5004SignalEmitted ;
    mAppManagerPtr->GetEventsManagerModel()->ConnectToSignal("PostponableShutDownEvent",[&]() {WasEv5004SignalEmitted = true;});
	RequestShutDown();
	EXPECT_EQ(true,WasEv5004SignalEmitted);
    EXPECT_CALL(*mFakeTransportClientPtr, unsubscribe(TOPIC_SHUTDOWN_STATUS, testing::_)).WillOnce(testing::Return());
}
