#include "gtest/gtest.h"
#include "AppManager.h"
#include "ConfigurationManagerModel.h"
#include "FilesHandlingModel.h"
#include "ClientManagerModel.h"
#include "TranslatorModel.h"
#include "CommonHeader.h"

using namespace DaqApp;

class ConfigurationManagerModelTest : public testing::Test
 {

protected:
        std::shared_ptr<AppManager>      mAppManagerPtr;
	std::unique_ptr<JsonParserModel> mJsonParserPtr;
	ConfigurationManagerModel*       mConfigurationManagerPtr;
	FilesHandlingModel*              mFilesHandlingModelPtr;
	EventsManagerModel*              mEventsManagerHandler;
	TranslatorModel*                 mTranslatorPtr;

	void SetUp() override
	{
        boostfs::remove_all(BASE_CONFIG_DIR);
        boostfs::remove_all(MISC_DIR);
        mAppManagerPtr = std::make_shared<AppManager>();
        mFilesHandlingModelPtr = mAppManagerPtr->GetFilesHandlingModel();
        mEventsManagerHandler = mAppManagerPtr->GetEventsManagerModel();
        mConfigurationManagerPtr = mAppManagerPtr->GetConfigurationModel();
        mTranslatorPtr = mConfigurationManagerPtr->GetTranslatorModel();
        mAppManagerPtr->GetClientManagerModel()->SetUpClientManager();
        mFilesHandlingModelPtr->SetUpFilesHandlingModel();
        mFilesHandlingModelPtr->GetCloudServicesPtr()->SetUpCloudServicesModel();
        mJsonParserPtr = std::make_unique<JsonParserModel>();
	}

	void TearDown() override
	{
		mFilesHandlingModelPtr = nullptr;
		mEventsManagerHandler = nullptr;
		mConfigurationManagerPtr = nullptr;
		mTranslatorPtr = nullptr;
    }
};

//----------------------------Actual Test Cases------------------------------
// Same SPN with 2 different addresses should generate J1939Config messages
TEST_F(ConfigurationManagerModelTest, same_SPN_different_sourceaddress)
{
    Json::Value parsed_json_val =  mJsonParserPtr->ParseJsonFile("../test/Test_Configuration_Same_SPN_Different_with_SourceAddress.json");
    mConfigurationManagerPtr->ParseJson(parsed_json_val);
    std::vector<J1939ConfigMessage> J1939Configuration = mConfigurationManagerPtr->GetJ1939Config();
    EXPECT_EQ("activeFaultCodes",J1939Configuration.at(0).Pgn);
    EXPECT_EQ("dm1",J1939Configuration.at(0).Spn);
    EXPECT_EQ("0x00",J1939Configuration.at(0).SourceAddress);
    EXPECT_EQ("84",J1939Configuration.at(1).Spn);
    EXPECT_EQ("0x00",J1939Configuration.at(1).SourceAddress);
    EXPECT_EQ("84",J1939Configuration.at(2).Spn);
    EXPECT_EQ("0x21",J1939Configuration.at(2).SourceAddress);
}

// This test checks configuration parsing for all the JSON config blocks for the protocols J1939 & XCP  along with "activateDataCollection" command
TEST_F(ConfigurationManagerModelTest, parse_json_configuration)
{
    Json::Value parsed_json_val =  mJsonParserPtr->ParseJsonFile("../test/Test_Configuration.json");
    mConfigurationManagerPtr->ParseJson(parsed_json_val);
    std::vector<GpsSamplerConfig> gpsSamplerConfig = mConfigurationManagerPtr->GetGpsSamplerConfig();
    EXPECT_TRUE(gpsSamplerConfig.at(0).IsLatitude);
    EXPECT_TRUE(gpsSamplerConfig.at(0).IsLongitude);
    EXPECT_TRUE(gpsSamplerConfig.at(0).IsAltitude);
    EXPECT_TRUE(gpsSamplerConfig.at(0).IsDirection_Heading);
    EXPECT_TRUE(gpsSamplerConfig.at(0).IsGPS_Vehicle_Speed);

    // Test J1939 configuration
    std::vector<J1939ConfigMessage>& J1939Configuration = mConfigurationManagerPtr->GetJ1939Config();
    EXPECT_EQ(3,J1939Configuration.size());
    EXPECT_EQ("190",J1939Configuration.at(0).Spn);
    EXPECT_EQ("activeFaultCodes",J1939Configuration.at(1).Pgn);
    EXPECT_EQ("dm1",J1939Configuration.at(1).Spn);
    EXPECT_EQ("158",J1939Configuration.at(2).Spn);

    // Test Event Configuration
    std::vector<EventConfigMessage>& EventsConfiguration = mConfigurationManagerPtr->GetEventsConfig();
    EXPECT_EQ(2,EventsConfiguration.size());
    EventConfigMessage& event_config_message =  EventsConfiguration.at(0);
    EXPECT_EQ(300,event_config_message.Threshold);
    EXPECT_EQ("190",event_config_message.Source);
    EXPECT_EQ(">=",event_config_message.Operator);
    EXPECT_EQ(EventsType::DynamicEvent,event_config_message.Type);
    EXPECT_EQ("AND",event_config_message.ComplexEventOperator);

    event_config_message =  EventsConfiguration.at(1);
    EXPECT_EQ(3,event_config_message.Threshold);
    EXPECT_EQ("158",event_config_message.Source);
    EXPECT_EQ(">=",event_config_message.Operator);
    EXPECT_EQ(EventsType::DynamicEvent,event_config_message.Type);
    EXPECT_EQ("NONE",event_config_message.ComplexEventOperator);

    // Test Data Logger Configuration
    std::vector<DataLoggerConfig>& DataLoggerConfiguration = mConfigurationManagerPtr->GetDataLoggerConfig();
    EXPECT_EQ(1,DataLoggerConfiguration.size());
    DataLoggerConfig& data_logger_config =  DataLoggerConfiguration.at(0);
    EXPECT_EQ(SamplingProtocols::XCP,data_logger_config.proto);
    EXPECT_EQ(0.252*1000,data_logger_config.SamplingRate);
    EXPECT_EQ(5,data_logger_config.PreBufferSize);
    EXPECT_EQ(2,data_logger_config.PostBufferSize);
    EXPECT_EQ(1,data_logger_config.MaxSetSize);
    EXPECT_EQ(60,data_logger_config.MaxTransmitPeriod);
    EXPECT_EQ("EV5004",data_logger_config.StartingEventId);
    EXPECT_EQ("EV_DTC_Event",data_logger_config.EndingEventId);
    EXPECT_EQ("1.1.1",data_logger_config.MessageFormatVersion);
    EXPECT_EQ("SCXXXX",data_logger_config.DataSamplingConfigId);

    // Test SCP Configuration
    XCPEcuPropertiesConfigMessage XCP_Ecu_properties_config_message =  mConfigurationManagerPtr->GetXcpEcuPropertiesConfig();
    EXPECT_EQ("XCP_ECU_SPEC_ID",XCP_Ecu_properties_config_message.xcp_ecu_software_identifier);
    EXPECT_EQ(ecu::lapi::diag::CpEcuProperties::MSB_LAST,XCP_Ecu_properties_config_message.byte_order);
    EXPECT_EQ(ecu::lapi::diag::CpEcuProperties::GRANULARITY_BYTE,XCP_Ecu_properties_config_message.address_granularity);
    EXPECT_EQ(8,XCP_Ecu_properties_config_message.max_cto);
    EXPECT_EQ(8,XCP_Ecu_properties_config_message.max_dto);
    EXPECT_EQ(ecu::lapi::diag::CpEcuProperties::DYNAMIC,XCP_Ecu_properties_config_message.daq_config_type);
    EXPECT_EQ(65535,XCP_Ecu_properties_config_message.max_daq);
    EXPECT_EQ(5,XCP_Ecu_properties_config_message.max_event_channel);
    EXPECT_EQ(0,XCP_Ecu_properties_config_message.min_daq);
    EXPECT_EQ(255,XCP_Ecu_properties_config_message.max_odt_entry_size);
    EXPECT_EQ(false,XCP_Ecu_properties_config_message.slave_block_mode_supported);

    XcpInterfaceAllocationConfig xcp_interface_allocation_config = XCP_Ecu_properties_config_message.xcp_interface_allocation_configuration;
    EXPECT_EQ(500000,xcp_interface_allocation_config.baudrate);
    EXPECT_EQ(1000,xcp_interface_allocation_config.source_ecu);
    EXPECT_EQ(2000,xcp_interface_allocation_config.target_ecu);
    EXPECT_TRUE(xcp_interface_allocation_config.xcp_secure_access_required);

    XcpChecksumConfig xcp_checksum_config = XCP_Ecu_properties_config_message.xcp_checksum_configuration;
    EXPECT_EQ(1610722502,xcp_checksum_config.xcp_checksum_address);
    EXPECT_EQ(0x0,xcp_checksum_config.xcp_checksum_address_extension);
    EXPECT_EQ(100000,xcp_checksum_config.xcp_checksum_mem_size);
    EXPECT_EQ(2048,xcp_checksum_config.xcp_checksum);
    EXPECT_EQ("XCP_CRC_32",xcp_checksum_config.xcp_checksum_method);

    XcpEpromIdentifierConfig xcp_eprom_identifier_config = XCP_Ecu_properties_config_message.xcp_eprom_identifier_configuration;
    EXPECT_EQ("ABCDE",xcp_eprom_identifier_config.xcp_eprom_identifier_string);
    EXPECT_EQ(1610722230,xcp_eprom_identifier_config.xcp_eprom_identifier_address);
    EXPECT_EQ(0x0,xcp_eprom_identifier_config.xcp_eprom_identifier_address_extension);
    EXPECT_EQ(5,xcp_eprom_identifier_config.xcp_eprom_identifier_memsize); // This is the size of -> "EPROMIdentifier": "ABCDE" which is 5 chars

    std::vector<XCPConfigMessage>   XCPConfiguration = mConfigurationManagerPtr->GetXCPConfig();
    EXPECT_EQ(1,XCPConfiguration.at(0).transmission_rate_prescaler);
    EXPECT_EQ(2,XCPConfiguration.at(0).event_channel_number);
    EXPECT_EQ(4,XCPConfiguration.at(0).event_channel_priority);
    EXPECT_EQ(0,XCPConfiguration.at(0).rate);

    std::vector<XCPParameterConfigMessage>& xcp_parameter_configuration = XCPConfiguration.at(0).xcp_parameter_config_messages;
    XCPParameterConfigMessage& XCP_parameter_config_message = xcp_parameter_configuration.at(0);
    EXPECT_EQ("BattU_u_mV",XCP_parameter_config_message.xcp_parameter_name);
    EXPECT_EQ(1610722502,XCP_parameter_config_message.xcp_parameter_address);
    EXPECT_EQ(0x0,XCP_parameter_config_message.xcp_parameter_address_extension);
    EXPECT_EQ("S16",XCP_parameter_config_message.xcp_parameter_data_type);
    EXPECT_EQ(20,XCP_parameter_config_message.xcp_parameter_conversion_factor);
    EXPECT_EQ(0,XCP_parameter_config_message.xcp_parameter_conversion_offset);

    // Test Activate Command configuration
    std::vector<ActivateDataConfig> activateDataConfig =  mConfigurationManagerPtr->GetActivateDataConfig();
    for(const auto& obj : activateDataConfig)
    {
        EXPECT_TRUE(obj.ResumeMode);
        EXPECT_EQ("high",obj.DataPriority);
    }
}

// This test checks UDS - TripData Configuration
TEST_F(ConfigurationManagerModelTest, parse_TripData_configuration)
{
    Json::Value parsed_json_val =  mJsonParserPtr->ParseJsonFile("../test/Configuration_TripData.json");
    mConfigurationManagerPtr->ParseJson(parsed_json_val);
    std::vector<UDSConfigMessage>& UDSConfiguration = mConfigurationManagerPtr->GetUdsConfig();
    if(UDSConfiguration.size()>0)
    {
        EXPECT_TRUE(UDSConfiguration.at(0).IsTripData);
        EXPECT_TRUE(UDSConfiguration.at(0).isPartialExtraction);
        EXPECT_EQ("TripData",UDSConfiguration.at(0).Protocol);
    }
}

// This test checks EAL - TripData Configuration
TEST_F(ConfigurationManagerModelTest, parse_EAL_configuration)
{
    Json::Value parsed_json_val =  mJsonParserPtr->ParseJsonFile("../test/Test_EAL_Configuration.json");
    mConfigurationManagerPtr->ParseJson(parsed_json_val);
    std::vector<UDSConfigMessage>& UDSConfiguration = mConfigurationManagerPtr->GetUdsConfig();
    if(UDSConfiguration.size()>0)
    {
        EXPECT_TRUE(UDSConfiguration.at(0).IsEALData);
        EXPECT_EQ("EAL",UDSConfiguration.at(0).Protocol);
        EXPECT_EQ("0x00",UDSConfiguration.at(0).SourceAddress);
        EXPECT_EQ(61953,UDSConfiguration.at(0).DDID);
        EXPECT_EQ(32,UDSConfiguration.at(0).dataIds.size());
    }
}

// This test checks whether after emitting the signal if "activateDataCollection" command is present then the file will be copied into "ActiveConfigFiles" directory
TEST_F(ConfigurationManagerModelTest, Test_FileActivationWithConfigID)
{
    std::string filePath = MISC_DIR + "/" + CONFIGURATION_FILE_NAME;
    boostfs::copy_file("../test/Test_Valid_Configuration.json",(filePath),boostfs::copy_option::overwrite_if_exists);
    EXPECT_TRUE(boostfs::exists(MISC_DIR + "/" +CONFIGURATION_FILE_NAME));
    mFilesHandlingModelPtr->SetNewlyDownloadedJSONConfig(CONFIGURATION_FILE_NAME);
    mEventsManagerHandler->EmitSignal("NewConfigArrived");
    std::this_thread::sleep_for(std::chrono::seconds(3));
    EXPECT_TRUE(boostfs::exists(ACTIVE_CONFIG_DIR + "/SCXXXX.json"));
    boostfs::remove(ACTIVE_CONFIG_DIR + "/SCXXXX.json");
    boostfs::remove(MISC_DIR + "/" + CONFIGURATION_FILE_NAME);

}


// This test checks whether after emitting the signal if "deactivateDataCollection" command is present then the file will be deleted from all the folders.
TEST_F(ConfigurationManagerModelTest, Test_DeactivateConfigWithConfigID)
{
    boostfs::copy_file("../test/Test_deactivate_and_forget_config.json",(MISC_DIR + "/" + CONFIGURATION_FILE_NAME),boostfs::copy_option::overwrite_if_exists);
    EXPECT_TRUE(boostfs::exists(MISC_DIR + "/" + CONFIGURATION_FILE_NAME));
    mFilesHandlingModelPtr->SetNewlyDownloadedJSONConfig(CONFIGURATION_FILE_NAME);
    mEventsManagerHandler->EmitSignal("NewConfigArrived");
    std::this_thread::sleep_for(std::chrono::seconds(3));
    EXPECT_FALSE(boostfs::exists(ACTIVE_CONFIG_DIR + "/SCXXXX.json"));
    EXPECT_FALSE(boostfs::exists(MISC_DIR + CONFIGURATION_FILE_NAME));
}

// This test validates "deactivateDataCollection" and "forgetDefinition" config command parsing.
TEST_F(ConfigurationManagerModelTest, Test_DeActivation_and_Forget)
{
    boostfs::copy_file("../test/Test_deactivate_and_forget_config.json",(ACTIVE_CONFIG_DIR + "/" + "Test_deactivate_and_forget_config.json"),boostfs::copy_option::overwrite_if_exists);
    EXPECT_TRUE(boostfs::exists(ACTIVE_CONFIG_DIR + "/" + "Test_deactivate_and_forget_config.json"));

    mConfigurationManagerPtr->SetUpConfigurationManager();

    DeActivateDataConfig DeActivateConfig = mConfigurationManagerPtr->GetDeActivateDataConfig();
    EXPECT_EQ("SCXXXX",DeActivateConfig.DataSamplingConfigIds);
    EXPECT_EQ("componentSerialNumber",DeActivateConfig.DestinationIdType);

    std::vector<ForgetConfig> forget_config = mConfigurationManagerPtr->GetForgetConfig();
    EXPECT_EQ(ConfigIds::ConfigOne,forget_config.at(0).ConfigID);
    EXPECT_EQ("SCXXXX",forget_config.at(0).DefinitionId);
    EXPECT_EQ("dataContentSpec",forget_config.at(0).DefinitionType);
    boostfs::remove(ACTIVE_CONFIG_DIR + "/Test_deactivate_and_forget_config.json");
}

// This test validates the multiple configuration parsing for the protocols UDS - TripData & EAL.
TEST_F(ConfigurationManagerModelTest, Test_Multi_Config)
{
    boostfs::copy_file("../test/Test_Configuration_EAL.json",(ACTIVE_CONFIG_DIR + "/" + "Test_Configuration_EAL.json"),boostfs::copy_option::overwrite_if_exists);
    EXPECT_TRUE(boostfs::exists(ACTIVE_CONFIG_DIR + "/" + "Test_Configuration_EAL.json"));

    boostfs::copy_file("../test/Test_Configuration_TripData.json",(ACTIVE_CONFIG_DIR + "/" + "Test_Configuration_TripData.json"),boostfs::copy_option::overwrite_if_exists);
    EXPECT_TRUE(boostfs::exists(ACTIVE_CONFIG_DIR + "/" + "Test_Configuration_TripData.json"));

    mConfigurationManagerPtr->SetUpConfigurationManager();
    std::vector<UDSConfigMessage>& UDSConfiguration = mConfigurationManagerPtr->GetUdsConfig();

    EXPECT_EQ(2,UDSConfiguration.size());
    EXPECT_EQ(ConfigIds::ConfigOne,UDSConfiguration.at(0).ConfigID);
    EXPECT_EQ(ConfigIds::ConfigTwo,UDSConfiguration.at(1).ConfigID);
    for(UDSConfigMessage uds_config: UDSConfiguration)
    {
        if(uds_config.IsTripData)
        {
            EXPECT_TRUE(uds_config.isPartialExtraction);
            EXPECT_EQ("TripData",uds_config.Protocol);
            EXPECT_EQ("SCXXXX",uds_config.ConfigName);

        }
        else
        {
            EXPECT_TRUE(uds_config.IsEALData);
            EXPECT_EQ("EAL",uds_config.Protocol);
            EXPECT_EQ("0x00",uds_config.SourceAddress);
            EXPECT_EQ(62209,uds_config.DDID);
            EXPECT_EQ(49,uds_config.dataIds.size());
            EXPECT_EQ("SC0001",uds_config.ConfigName);
        }
    }

    // Deleting the configuration File from Activate directory
    mFilesHandlingModelPtr->ForgetConfig("Test_Configuration_EAL.json");
    mFilesHandlingModelPtr->ForgetConfig("Test_Configuration_TripData.json");
}

// This test checks whether the config file is valid or not if the config exists duplicate SPN.
TEST_F(ConfigurationManagerModelTest, Test_InvaidConfigWithDuplicateSPN)
{
    boostfs::copy_file("../test/Test_Invalid_ConfigurationDuplicateSPN.json",(MISC_DIR + "/" + CONFIGURATION_FILE_NAME),boostfs::copy_option::overwrite_if_exists);
    EXPECT_TRUE(boostfs::exists(MISC_DIR + "/" +CONFIGURATION_FILE_NAME));
    mFilesHandlingModelPtr->SetNewlyDownloadedJSONConfig(CONFIGURATION_FILE_NAME);
    mEventsManagerHandler->EmitSignal("NewConfigArrived");
    std::this_thread::sleep_for(std::chrono::seconds(3));
    EXPECT_FALSE(boostfs::exists(ACTIVE_CONFIG_DIR + "/SC0000.json")); //Json is not get copied to active config dir
    boostfs::remove(MISC_DIR + "/" + CONFIGURATION_FILE_NAME);
}

// This test checks whether the config file is valid or not if the config exists duplicate events.
TEST_F(ConfigurationManagerModelTest, Test_InvaidConfigWithDuplicateEvents)
{
    boostfs::copy_file("../test/Test_Invalid_ConfigurationDuplicateEvents.json",(MISC_DIR + "/" + CONFIGURATION_FILE_NAME),boostfs::copy_option::overwrite_if_exists);
    EXPECT_TRUE(boostfs::exists(MISC_DIR + "/" +CONFIGURATION_FILE_NAME));
    mFilesHandlingModelPtr->SetNewlyDownloadedJSONConfig(CONFIGURATION_FILE_NAME);
    mEventsManagerHandler->EmitSignal("NewConfigArrived");
    std::this_thread::sleep_for(std::chrono::seconds(3));
    EXPECT_FALSE(boostfs::exists(ACTIVE_CONFIG_DIR + "/SC0000.json")); //Json is not get copied to active config dir
    boostfs::remove(MISC_DIR + "/" + CONFIGURATION_FILE_NAME);
}

// This test validates multiple configurations parsing for J1939 protocol .
TEST_F(ConfigurationManagerModelTest, Test_J1939_Multi_Config)
{
    boostfs::copy_file("../test/Test_J1939ConfigOne.json",(ACTIVE_CONFIG_DIR + "/" + "Test_J1939ConfigOne.json"),boostfs::copy_option::overwrite_if_exists);
    EXPECT_TRUE(boostfs::exists(ACTIVE_CONFIG_DIR + "/" + "Test_J1939ConfigOne.json"));

    boostfs::copy_file("../test/Test_J1939ConfigTwo.json",(ACTIVE_CONFIG_DIR + "/" + "Test_J1939ConfigTwo.json"),boostfs::copy_option::overwrite_if_exists);
    EXPECT_TRUE(boostfs::exists(ACTIVE_CONFIG_DIR + "/" + "Test_J1939ConfigTwo.json"));

    mConfigurationManagerPtr->SetUpConfigurationManager();
    std::vector<J1939ConfigMessage>& J1939Configuration = mConfigurationManagerPtr->GetJ1939Config();
    std::vector<EventConfigMessage>& SimpleEventConfig = mConfigurationManagerPtr->GetEventsConfig();
    EXPECT_EQ(5,J1939Configuration.size());
    EXPECT_EQ(3,SimpleEventConfig.size());
    if(J1939Configuration.at(0).Spn == "2432")
        {
            // First Config file contains 2 Spn and 1 event source 190
            EXPECT_EQ(ConfigIds::ConfigOne,J1939Configuration.at(0).ConfigID);
            EXPECT_EQ("2432",J1939Configuration.at(0).Spn);
            EXPECT_EQ(ConfigIds::ConfigOne,J1939Configuration.at(1).ConfigID);
            EXPECT_EQ("190",J1939Configuration.at(1).Spn);
            EXPECT_EQ(ConfigIds::ConfigTwo,J1939Configuration.at(2).ConfigID);
            EXPECT_EQ("513",J1939Configuration.at(2).Spn);
            EXPECT_EQ(ConfigIds::ConfigTwo,J1939Configuration.at(3).ConfigID);
            EXPECT_EQ("180",J1939Configuration.at(3).Spn);
            EXPECT_EQ(ConfigIds::ConfigTwo,J1939Configuration.at(4).ConfigID);
            EXPECT_EQ("586",J1939Configuration.at(4).Spn);
            // For event
            EXPECT_EQ(ConfigIds::ConfigOne,SimpleEventConfig.at(0).ConfigID);
            EXPECT_EQ("190",SimpleEventConfig.at(0).Source);
            EXPECT_EQ(ConfigIds::ConfigTwo,SimpleEventConfig.at(1).ConfigID);
            EXPECT_EQ("180",SimpleEventConfig.at(1).Source);
            EXPECT_EQ(ConfigIds::ConfigTwo,SimpleEventConfig.at(2).ConfigID);
            EXPECT_EQ("586",SimpleEventConfig.at(2).Source);
        }
    else
        {
            EXPECT_EQ(ConfigIds::ConfigOne,J1939Configuration.at(0).ConfigID);
            EXPECT_EQ("513",J1939Configuration.at(0).Spn);
            EXPECT_EQ(ConfigIds::ConfigOne,J1939Configuration.at(1).ConfigID);
            EXPECT_EQ("180",J1939Configuration.at(1).Spn);
            EXPECT_EQ(ConfigIds::ConfigOne,J1939Configuration.at(2).ConfigID);
            EXPECT_EQ("586",J1939Configuration.at(2).Spn);
            EXPECT_EQ(ConfigIds::ConfigTwo,J1939Configuration.at(3).ConfigID);
            EXPECT_EQ("2432",J1939Configuration.at(3).Spn);
            EXPECT_EQ(ConfigIds::ConfigTwo,J1939Configuration.at(4).ConfigID);
            EXPECT_EQ("190",J1939Configuration.at(4).Spn);
            // For event
            EXPECT_EQ(ConfigIds::ConfigOne,SimpleEventConfig.at(0).ConfigID);
            EXPECT_EQ("180",SimpleEventConfig.at(0).Source);
            EXPECT_EQ(ConfigIds::ConfigOne,SimpleEventConfig.at(1).ConfigID);
            EXPECT_EQ("586",SimpleEventConfig.at(1).Source);
            EXPECT_EQ(ConfigIds::ConfigTwo,SimpleEventConfig.at(2).ConfigID);
            EXPECT_EQ("190",SimpleEventConfig.at(2).Source);
        }
    // Deleting the configuration File from Activate directory
    mFilesHandlingModelPtr->ForgetConfig("Test_J1939ConfigOne.json");
    mFilesHandlingModelPtr->ForgetConfig("Test_J1939ConfigTwo.json");
}

TEST_F(ConfigurationManagerModelTest, Test_InvaidConfigWithMissingConfigID)
{
    boostfs::copy_file("../test/Test_Invalid_ConfigurationMissingConfigId.json",(MISC_DIR + "/" + CONFIGURATION_FILE_NAME),boostfs::copy_option::overwrite_if_exists);
    EXPECT_TRUE(boostfs::exists(MISC_DIR + "/" +CONFIGURATION_FILE_NAME));
    mFilesHandlingModelPtr->SetNewlyDownloadedJSONConfig(CONFIGURATION_FILE_NAME);
    mEventsManagerHandler->EmitSignal("NewConfigArrived");
    std::this_thread::sleep_for(std::chrono::seconds(3));
    EXPECT_TRUE(boostfs::is_empty(ACTIVE_CONFIG_DIR));
    boostfs::remove(MISC_DIR + "/" + CONFIGURATION_FILE_NAME);
}

TEST_F(ConfigurationManagerModelTest, Test_ValidConfigWithMultiSPNs)
{
    boostfs::copy_file("../test/Test_Valid_ConfigurationMultiSPN.json",(MISC_DIR + "/" + CONFIGURATION_FILE_NAME),boostfs::copy_option::overwrite_if_exists);
    EXPECT_TRUE(boostfs::exists(MISC_DIR + "/" +CONFIGURATION_FILE_NAME));
    mFilesHandlingModelPtr->SetNewlyDownloadedJSONConfig(CONFIGURATION_FILE_NAME);
    mEventsManagerHandler->EmitSignal("NewConfigArrived");
    std::this_thread::sleep_for(std::chrono::seconds(3));
    EXPECT_TRUE(boostfs::exists(ACTIVE_CONFIG_DIR + "/SC0000.json"));
    boostfs::remove(MISC_DIR + "/" + CONFIGURATION_FILE_NAME);
}

// This Test checks XCP configuration parsing.
TEST_F(ConfigurationManagerModelTest, parse_XCP_configuration)
{
    Json::Value parsed_json_val =  mJsonParserPtr->ParseJsonFile("../test/Test_XCP_Configuration.json");
    mConfigurationManagerPtr->ParseJson(parsed_json_val);

    XCPEcuPropertiesConfigMessage XCP_Ecu_properties_config_message =  mConfigurationManagerPtr->GetXcpEcuPropertiesConfig();
    EXPECT_EQ("Test",XCP_Ecu_properties_config_message.xcp_ecu_software_identifier);
    EXPECT_EQ(ecu::lapi::diag::CpEcuProperties::MSB_LAST,XCP_Ecu_properties_config_message.byte_order);
    EXPECT_EQ(ecu::lapi::diag::CpEcuProperties::GRANULARITY_BYTE,XCP_Ecu_properties_config_message.address_granularity);
    EXPECT_EQ(8,XCP_Ecu_properties_config_message.max_cto);
    EXPECT_EQ(8,XCP_Ecu_properties_config_message.max_dto);
    EXPECT_EQ(ecu::lapi::diag::CpEcuProperties::DYNAMIC,XCP_Ecu_properties_config_message.daq_config_type);
    EXPECT_EQ(65535,XCP_Ecu_properties_config_message.max_daq);
    EXPECT_EQ(5,XCP_Ecu_properties_config_message.max_event_channel);
    EXPECT_EQ(0,XCP_Ecu_properties_config_message.min_daq);
    EXPECT_EQ(255,XCP_Ecu_properties_config_message.max_odt_entry_size);
    EXPECT_EQ(false,XCP_Ecu_properties_config_message.slave_block_mode_supported);

    XcpInterfaceAllocationConfig xcp_interface_allocation_config = XCP_Ecu_properties_config_message.xcp_interface_allocation_configuration;
    EXPECT_EQ(1000000,xcp_interface_allocation_config.baudrate);
    EXPECT_EQ(2045,xcp_interface_allocation_config.source_ecu);
    EXPECT_EQ(2046,xcp_interface_allocation_config.target_ecu);

    XcpChecksumConfig xcp_checksum_config = XCP_Ecu_properties_config_message.xcp_checksum_configuration;
    EXPECT_EQ(0,xcp_checksum_config.xcp_checksum_address);
    EXPECT_EQ(0,xcp_checksum_config.xcp_checksum_address_extension);
    EXPECT_EQ(0,xcp_checksum_config.xcp_checksum_mem_size);
    EXPECT_EQ(0,xcp_checksum_config.xcp_checksum);
    EXPECT_EQ("XCP_CRC_32",xcp_checksum_config.xcp_checksum_method);

    XcpEpromIdentifierConfig xcp_eprom_identifier_config = XCP_Ecu_properties_config_message.xcp_eprom_identifier_configuration;
    EXPECT_EQ("MD1CE100_C1",xcp_eprom_identifier_config.xcp_eprom_identifier_string);
    EXPECT_EQ(2153583344,xcp_eprom_identifier_config.xcp_eprom_identifier_address);
    EXPECT_EQ(0,xcp_eprom_identifier_config.xcp_eprom_identifier_address_extension);
    EXPECT_EQ(11,xcp_eprom_identifier_config.xcp_eprom_identifier_memsize);

    std::vector<XCPConfigMessage>   XCPConfiguration = mConfigurationManagerPtr->GetXCPConfig();
    EXPECT_EQ(1,XCPConfiguration.at(0).transmission_rate_prescaler);
    EXPECT_EQ(3,XCPConfiguration.at(0).event_channel_number);
    EXPECT_EQ(6,XCPConfiguration.at(0).event_channel_priority);
    EXPECT_EQ(0,XCPConfiguration.at(0).rate);
    EXPECT_EQ(ecu::lapi::diag::DaqMode::DAQ_MODE_SAMPLE,XCPConfiguration.at(0).sampling_mode);

    std::vector<XCPParameterConfigMessage>& xcp_parameter_configuration = XCPConfiguration.at(0).xcp_parameter_config_messages;
    XCPParameterConfigMessage& XCP_parameter_config_message = xcp_parameter_configuration.at(0);
    EXPECT_EQ("rba_OsShell_Cntr10msTask",XCP_parameter_config_message.xcp_parameter_name);
    EXPECT_EQ(1610738660,XCP_parameter_config_message.xcp_parameter_address);
    EXPECT_EQ(0,XCP_parameter_config_message.xcp_parameter_address_extension);
    EXPECT_EQ("U16",XCP_parameter_config_message.xcp_parameter_data_type);
    EXPECT_EQ(1.0,XCP_parameter_config_message.xcp_parameter_conversion_factor);
    EXPECT_EQ(0,XCP_parameter_config_message.xcp_parameter_conversion_offset);

}
