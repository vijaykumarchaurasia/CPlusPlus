#include <gtest/gtest.h>
#include "AppManager.h"
#include "DataAccessModel.h"
#include "EventsManagerModel.h"
#include "SimpleEventModelEv5001.h"

using namespace DaqApp;

class SimpleEventModelEv5001Test : public testing::Test
{
protected:
    AppManager*             mAppManagerPtr;
    SimpleEventModelEv5001* mSimpleEv5001Ptr;
    EventConfigMessage      mEventConfigMsg;

    void SetUp() override
    {
        mEventConfigMsg.ConfigID = ConfigIds::ConfigOne;
        mAppManagerPtr = new AppManager();
        mSimpleEv5001Ptr = new SimpleEventModelEv5001(mEventConfigMsg, mAppManagerPtr->GetEventsManagerModel(),mAppManagerPtr);
    }

    void TearDown() override
    {
      delete mSimpleEv5001Ptr;
      delete mAppManagerPtr;
    }
};

TEST_F(SimpleEventModelEv5001Test, DM2Message)
{
    bool WasEv5001SignalEmitted ;
    mAppManagerPtr->GetEventsManagerModel()->ConnectToSignal("EV5001",[&]() {WasEv5001SignalEmitted = true;});
    mAppManagerPtr->GetDataAccessModel()->Write("inactiveFaultCodes", "spn:689~fmi:1~count:3|spn:102~fmi:18~count:1|",Protocol::EventProto,mEventConfigMsg.ConfigID);

    mSimpleEv5001Ptr->Evaluate();
    EXPECT_EQ(true,WasEv5001SignalEmitted);               //Signal emission check
    EXPECT_EQ(true, mSimpleEv5001Ptr->mIsActive); //Internal state check active

    mAppManagerPtr->GetDataAccessModel()->Write("inactiveFaultCodes", "spn:0~fmi:0~count:0|",Protocol::EventProto,mEventConfigMsg.ConfigID); //No longer active internally
    mSimpleEv5001Ptr->Evaluate();
    EXPECT_EQ(false,mSimpleEv5001Ptr->mIsActive); //Internal state check inactive
}
