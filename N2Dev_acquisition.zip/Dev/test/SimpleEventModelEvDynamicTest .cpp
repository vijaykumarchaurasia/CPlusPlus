#include <gtest/gtest.h>
#include "AppManager.h"
#include "DataAccessModel.h"
#include "EventsManagerModel.h"
#include "SimpleEventModelEvDynamic.h"

using namespace DaqApp;

class SimpleEventModelEvDynamicTest : public testing::Test
{
public:

    bool                        mWasNotifyEvDynamicSignalEmitted {false};
    AppManager*                 mAppManagerPtr;
    SimpleEventModelEvDynamic*  mSimpleEvDynamicPtr;
    EventConfigMessage          mEventConfigMsg;

    void SetUp() override
    {
        mAppManagerPtr = new AppManager();
        mEventConfigMsg.EventId = "SomeEvent";
        mEventConfigMsg.Type = EventsType::DynamicEvent;
        mEventConfigMsg.Source = "190" ;
        mEventConfigMsg.Threshold = 1000;
        mEventConfigMsg.ConfigID = ConfigIds::ConfigOne;
        //operator set in each test case
    }

    void TearDown() override
    {
       delete mSimpleEvDynamicPtr;
       delete mAppManagerPtr;

    }
    void MySlot ()
    {
        mWasNotifyEvDynamicSignalEmitted = true;
    }
};

TEST_F(SimpleEventModelEvDynamicTest, ParameterCompEventEqual)
{
    mEventConfigMsg.Operator = "==" ;

    mSimpleEvDynamicPtr = new SimpleEventModelEvDynamic(mEventConfigMsg, mAppManagerPtr->GetEventsManagerModel(),mAppManagerPtr);

    bool isSlotConnectedToSignal = mAppManagerPtr->GetEventsManagerModel()->ConnectToSignal
    (mEventConfigMsg.EventId,boost::bind(&SimpleEventModelEvDynamicTest::MySlot,this));
    EXPECT_EQ(true,isSlotConnectedToSignal);

    // Not active after engine speed is written to the DataAccess without meeting event threshold
    mAppManagerPtr->GetDataAccessModel()->Write(190, 500, Protocol::J1939Proto,mEventConfigMsg.ConfigID);
    mSimpleEvDynamicPtr->Evaluate();
    EXPECT_EQ(false,mSimpleEvDynamicPtr->mIsActive);
    EXPECT_EQ(false,mWasNotifyEvDynamicSignalEmitted);   //signal emission check

    mWasNotifyEvDynamicSignalEmitted = false;
    mAppManagerPtr->GetDataAccessModel()->Write(190, 1000, Protocol::J1939Proto,mEventConfigMsg.ConfigID); //Engine speed is equal to threshold.
    mSimpleEvDynamicPtr->Evaluate();
    EXPECT_EQ(true,mWasNotifyEvDynamicSignalEmitted);   //signal emission check
    EXPECT_EQ(true, mSimpleEvDynamicPtr->mIsActive);        //Internal state check
}

TEST_F(SimpleEventModelEvDynamicTest, ParameterCompEventNotEqual)
{
    mEventConfigMsg.Operator = "!=";
    mSimpleEvDynamicPtr = new SimpleEventModelEvDynamic(mEventConfigMsg, mAppManagerPtr->GetEventsManagerModel(),mAppManagerPtr);
    bool isSlotConnectedToSignal = mAppManagerPtr->GetEventsManagerModel()->ConnectToSignal
    (mEventConfigMsg.EventId,boost::bind(&SimpleEventModelEvDynamicTest::MySlot,this));
    EXPECT_EQ(true,isSlotConnectedToSignal);

    // Not active after engine speed is written to the DataAccess without meeting event threshold
    mAppManagerPtr->GetDataAccessModel()->Write(190, 1000, Protocol::J1939Proto,mEventConfigMsg.ConfigID);
    mSimpleEvDynamicPtr->Evaluate();
    EXPECT_EQ(false,mSimpleEvDynamicPtr->mIsActive);
    EXPECT_EQ(false,mWasNotifyEvDynamicSignalEmitted);   //signal emission check

    mWasNotifyEvDynamicSignalEmitted = false;
    mAppManagerPtr->GetDataAccessModel()->Write(190, 2000, Protocol::J1939Proto,mEventConfigMsg.ConfigID); //Engine speed is not equal to threshold.
    mSimpleEvDynamicPtr->Evaluate();
    EXPECT_EQ(true,mWasNotifyEvDynamicSignalEmitted);   //signal emission check
    EXPECT_EQ(true, mSimpleEvDynamicPtr->mIsActive);        //Internal state check
}

TEST_F(SimpleEventModelEvDynamicTest, ParameterCompEventGreater)
{
    mEventConfigMsg.Operator = ">";
    mSimpleEvDynamicPtr = new SimpleEventModelEvDynamic(mEventConfigMsg, mAppManagerPtr->GetEventsManagerModel(),mAppManagerPtr);

    bool isSlotConnectedToSignal = mAppManagerPtr->GetEventsManagerModel()->ConnectToSignal
    (mEventConfigMsg.EventId,boost::bind(&SimpleEventModelEvDynamicTest::MySlot,this));
    EXPECT_EQ(true,isSlotConnectedToSignal);

    EXPECT_EQ(false,mWasNotifyEvDynamicSignalEmitted);   //signal emission check
    // Not active after engine speed is written to the DataAccess without meeting event threshold
    mAppManagerPtr->GetDataAccessModel()->Write(190, 1000, Protocol::J1939Proto,mEventConfigMsg.ConfigID);
    mSimpleEvDynamicPtr->Evaluate();
    EXPECT_EQ(false,mSimpleEvDynamicPtr->mIsActive);
    EXPECT_EQ(false,mWasNotifyEvDynamicSignalEmitted);   //signal emission check

    mWasNotifyEvDynamicSignalEmitted = false;
    mAppManagerPtr->GetDataAccessModel()->Write(190, 2000, Protocol::J1939Proto,mEventConfigMsg.ConfigID); //Engine speed is greater than threshold.
    mSimpleEvDynamicPtr->Evaluate();
    EXPECT_EQ(true,mWasNotifyEvDynamicSignalEmitted);   //signal emission check
    EXPECT_EQ(true, mSimpleEvDynamicPtr->mIsActive);        //Internal state check
}

TEST_F(SimpleEventModelEvDynamicTest, ParameterCompEventGreaterEqual)
{
    mEventConfigMsg.Operator = ">=";
    mSimpleEvDynamicPtr = new SimpleEventModelEvDynamic(mEventConfigMsg, mAppManagerPtr->GetEventsManagerModel(),mAppManagerPtr);

    bool isSlotConnectedToSignal = mAppManagerPtr->GetEventsManagerModel()->ConnectToSignal
    (mEventConfigMsg.EventId,boost::bind(&SimpleEventModelEvDynamicTest::MySlot,this));
    EXPECT_EQ(true,isSlotConnectedToSignal);

    // Not active after engine speed is written to the DataAccess without meeting event threshold
    mAppManagerPtr->GetDataAccessModel()->Write(190, 500, Protocol::J1939Proto,mEventConfigMsg.ConfigID);
    mSimpleEvDynamicPtr->Evaluate();
    EXPECT_EQ(false,mSimpleEvDynamicPtr->mIsActive);
    EXPECT_EQ(false,mWasNotifyEvDynamicSignalEmitted);   //signal emission check

    mWasNotifyEvDynamicSignalEmitted = false;
    mAppManagerPtr->GetDataAccessModel()->Write(190, 2000, Protocol::J1939Proto,mEventConfigMsg.ConfigID); //Engine speed is greater than threshold.
    mSimpleEvDynamicPtr->Evaluate();
    EXPECT_EQ(true, mWasNotifyEvDynamicSignalEmitted);   //signal emission check
    EXPECT_EQ(true, mSimpleEvDynamicPtr->mIsActive);        //Internal state check

    mWasNotifyEvDynamicSignalEmitted = false;

    mAppManagerPtr->GetDataAccessModel()->Write(190, 500, Protocol::J1939Proto,mEventConfigMsg.ConfigID); //Reset the event to trigger again.
    mSimpleEvDynamicPtr->Evaluate();

    mAppManagerPtr->GetDataAccessModel()->Write(190, 1000, Protocol::J1939Proto,mEventConfigMsg.ConfigID); //Engine speed is equal to threshold.
    mSimpleEvDynamicPtr->Evaluate();
    EXPECT_EQ(true, mWasNotifyEvDynamicSignalEmitted);   //signal emission check
    EXPECT_EQ(true, mSimpleEvDynamicPtr->mIsActive);        //Internal state check
}

TEST_F(SimpleEventModelEvDynamicTest, ParameterCompEventLess)
{
    mEventConfigMsg.Operator = "<";
    mSimpleEvDynamicPtr = new SimpleEventModelEvDynamic(mEventConfigMsg, mAppManagerPtr->GetEventsManagerModel(),mAppManagerPtr);
    bool isSlotConnectedToSignal = mAppManagerPtr->GetEventsManagerModel()->ConnectToSignal
    (mEventConfigMsg.EventId,boost::bind(&SimpleEventModelEvDynamicTest::MySlot,this));
    EXPECT_EQ(true,isSlotConnectedToSignal);

    // Not active after engine speed is written to the DataAccess without meeting event threshold
    mAppManagerPtr->GetDataAccessModel()->Write(190, 2000, Protocol::J1939Proto,mEventConfigMsg.ConfigID);
    mSimpleEvDynamicPtr->Evaluate();
    EXPECT_EQ(false,mSimpleEvDynamicPtr->mIsActive);
    EXPECT_EQ(false,mWasNotifyEvDynamicSignalEmitted);   //signal emission check

    mWasNotifyEvDynamicSignalEmitted = false;
    mAppManagerPtr->GetDataAccessModel()->Write(190, 500, Protocol::J1939Proto,mEventConfigMsg.ConfigID); //Engine speed is less than thrshold.
    mSimpleEvDynamicPtr->Evaluate();
    EXPECT_EQ(true,mWasNotifyEvDynamicSignalEmitted);   //signal emission check
    EXPECT_EQ(true, mSimpleEvDynamicPtr->mIsActive);        //Internal state check
}

TEST_F(SimpleEventModelEvDynamicTest, ParameterCompEventLessEqual)
{
    mEventConfigMsg.Operator = "<=";
    mSimpleEvDynamicPtr = new SimpleEventModelEvDynamic(mEventConfigMsg, mAppManagerPtr->GetEventsManagerModel(),mAppManagerPtr);

    bool isSlotConnectedToSignal = mAppManagerPtr->GetEventsManagerModel()->ConnectToSignal
    (mEventConfigMsg.EventId,boost::bind(&SimpleEventModelEvDynamicTest::MySlot,this));
    EXPECT_EQ(true,isSlotConnectedToSignal);

    // Not active after engine speed is written to the DataAccess without meeting event threshold
    mAppManagerPtr->GetDataAccessModel()->Write(190, 5000, Protocol::J1939Proto,mEventConfigMsg.ConfigID);
    mSimpleEvDynamicPtr->Evaluate();
    EXPECT_EQ(false,mSimpleEvDynamicPtr->mIsActive);
    EXPECT_EQ(false,mWasNotifyEvDynamicSignalEmitted);   //signal emission check

    mWasNotifyEvDynamicSignalEmitted = false;
    mAppManagerPtr->GetDataAccessModel()->Write(190, 200, Protocol::J1939Proto,mEventConfigMsg.ConfigID); //Engine speed is less than threshold.
    mSimpleEvDynamicPtr->Evaluate();
    EXPECT_EQ(true,mWasNotifyEvDynamicSignalEmitted);   //signal emission check
    EXPECT_EQ(true, mSimpleEvDynamicPtr->mIsActive);        //Internal state check

    mWasNotifyEvDynamicSignalEmitted = false;

    mAppManagerPtr->GetDataAccessModel()->Write(190, 5000, Protocol::J1939Proto,mEventConfigMsg.ConfigID); //Reset the event to trigger again.
    mSimpleEvDynamicPtr->Evaluate();

    mAppManagerPtr->GetDataAccessModel()->Write(190, 1000, Protocol::J1939Proto,mEventConfigMsg.ConfigID); //Engine speed is equal to threshold.
    mSimpleEvDynamicPtr->Evaluate();
    EXPECT_EQ(true,mWasNotifyEvDynamicSignalEmitted);   //signal emission check
    EXPECT_EQ(true, mSimpleEvDynamicPtr->mIsActive);        //Internal state check
}

TEST_F(SimpleEventModelEvDynamicTest, ParameterCompEventLessForTemp)
{
    mEventConfigMsg.Source    = "171" ;
    mEventConfigMsg.Threshold = 20;
    mEventConfigMsg.Operator  = "<";
    mSimpleEvDynamicPtr = new SimpleEventModelEvDynamic(mEventConfigMsg, mAppManagerPtr->GetEventsManagerModel(),mAppManagerPtr);
    bool isSlotConnectedToSignal = mAppManagerPtr->GetEventsManagerModel()->ConnectToSignal
    (mEventConfigMsg.EventId,boost::bind(&SimpleEventModelEvDynamicTest::MySlot,this));
    EXPECT_EQ(true,isSlotConnectedToSignal);
    // Not active after ambient air temperature is written to the DataAccess without meeting event threshold
    mAppManagerPtr->GetDataAccessModel()->Write(171, 30, Protocol::J1939Proto,mEventConfigMsg.ConfigID);
    mSimpleEvDynamicPtr->Evaluate();
    EXPECT_EQ(false,mSimpleEvDynamicPtr->mIsActive);
    EXPECT_EQ(false,mWasNotifyEvDynamicSignalEmitted); //signal emission check

    mWasNotifyEvDynamicSignalEmitted = false;
    mAppManagerPtr->GetDataAccessModel()->Write(171, -100, Protocol::J1939Proto,mEventConfigMsg.ConfigID); //ambient air temperature is less than thrshold.
    mSimpleEvDynamicPtr->Evaluate();
    EXPECT_EQ(true,mWasNotifyEvDynamicSignalEmitted); //signal emission check
    EXPECT_EQ(true, mSimpleEvDynamicPtr->mIsActive);  //Internal state check
}

TEST_F(SimpleEventModelEvDynamicTest, ParameterCompEventEqualToFloatThreshold)
{
    mEventConfigMsg.Operator  = "==" ;
    mEventConfigMsg.Threshold = 190.500;
    mSimpleEvDynamicPtr = new SimpleEventModelEvDynamic(mEventConfigMsg, mAppManagerPtr->GetEventsManagerModel(),mAppManagerPtr);

    bool isSlotConnectedToSignal = mAppManagerPtr->GetEventsManagerModel()->ConnectToSignal
    (mEventConfigMsg.EventId,boost::bind(&SimpleEventModelEvDynamicTest::MySlot,this));
    EXPECT_EQ(true,isSlotConnectedToSignal);

    // Not active after engine speed is written to the DataAccess without meeting event threshold
    mAppManagerPtr->GetDataAccessModel()->Write(190, 100, Protocol::J1939Proto,mEventConfigMsg.ConfigID);
    mSimpleEvDynamicPtr->Evaluate();
    EXPECT_EQ(false,mSimpleEvDynamicPtr->mIsActive);
    EXPECT_EQ(false,mWasNotifyEvDynamicSignalEmitted);   //signal emission check

    mWasNotifyEvDynamicSignalEmitted = false;
    mAppManagerPtr->GetDataAccessModel()->Write(190, 190.500, Protocol::J1939Proto,mEventConfigMsg.ConfigID); //Engine speed is equal to threshold.
    mSimpleEvDynamicPtr->Evaluate();
    EXPECT_EQ(true,mWasNotifyEvDynamicSignalEmitted);   //signal emission check
    EXPECT_EQ(true, mSimpleEvDynamicPtr->mIsActive);        //Internal state check
}

TEST_F(SimpleEventModelEvDynamicTest, ParameterCompEventEqualToNegativeThreshold)
{
    mEventConfigMsg.Operator  = "==" ;
    mEventConfigMsg.Threshold = -25;
    mEventConfigMsg.Source    = "2432" ;

    mSimpleEvDynamicPtr = new SimpleEventModelEvDynamic(mEventConfigMsg, mAppManagerPtr->GetEventsManagerModel(),mAppManagerPtr);

    bool isSlotConnectedToSignal = mAppManagerPtr->GetEventsManagerModel()->ConnectToSignal
    (mEventConfigMsg.EventId,boost::bind(&SimpleEventModelEvDynamicTest::MySlot,this));
    EXPECT_EQ(true,isSlotConnectedToSignal);

    // Not active after engine torque is written to the DataAccess without meeting event threshold
    mAppManagerPtr->GetDataAccessModel()->Write(2432, 20, Protocol::J1939Proto,mEventConfigMsg.ConfigID);
    mSimpleEvDynamicPtr->Evaluate();
    EXPECT_EQ(false,mSimpleEvDynamicPtr->mIsActive);
    EXPECT_EQ(false,mWasNotifyEvDynamicSignalEmitted);   //signal emission check

    mWasNotifyEvDynamicSignalEmitted = false;
    mAppManagerPtr->GetDataAccessModel()->Write(2432, -25, Protocol::J1939Proto,mEventConfigMsg.ConfigID); //Engine speed is equal to threshold.
    mSimpleEvDynamicPtr->Evaluate();
    EXPECT_EQ(true,mWasNotifyEvDynamicSignalEmitted);   //signal emission check
    EXPECT_EQ(true, mSimpleEvDynamicPtr->mIsActive);        //Internal state check
}

