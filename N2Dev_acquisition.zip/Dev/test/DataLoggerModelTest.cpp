#include <gtest/gtest.h>
#include <ecu/test/mock_transportclient.h>
#include <ecu/rt/signaladapter.h>
#include "ConfigurationManagerModel.h"
#include "DataLoggerModel.h"
#include "EventsManagerModel.h"
#include "DataAccessModel.h"
#include "SystemStateReceiver.h"
#include "SamplersManagerModel.h"
#include "ClientManagerModel.h"
#include <chrono>
/*
using namespace std::chrono;
using namespace DaqApp;

class DataLoggerModelTest : public testing::Test
{

protected:
    AppManager* mAppManagerPtr;
    EventsManagerModel* mEventManagerPtr;
    SystemStateReceiver* mSystemStateReceiverPtr;
    std::unique_ptr<JsonParserModel> mJsonParserPtr;
    void SetUp() override
    {
        mJsonParserPtr        = std::make_unique<JsonParserModel>();
        mAppManagerPtr       = new AppManager();
        mEventManagerPtr     = mAppManagerPtr->GetEventsManagerModel();
        mSystemStateReceiverPtr = mAppManagerPtr->GetSystemStateReceiver();
    }

    void TearDown() override
    {
        delete mAppManagerPtr;
        mEventManagerPtr     = nullptr;
        mSystemStateReceiverPtr = nullptr;
    }
};

//1. Test case writes few values to dataAccess and after emitting ev5004 signal cross
//verified DataloggerModel started the recording
//2. Cross checked the pre and post buffer container adding data by cross checking written values.
TEST_F(DataLoggerModelTest, TestEV5004SignalForPeriodic)
{
    Json::Value parsed_json_val =  mJsonParserPtr->ParseJsonFile("../test/Test_EV5004_DataLogger_Configuration.json");
    mAppManagerPtr->GetConfigurationModel()->ParseJson(parsed_json_val);
    mAppManagerPtr->GetClientManagerModel()->SetUpClientManager();
    mAppManagerPtr->GetSamplersManagerModel()->SetUpSamplersManager();
    std::this_thread::sleep_for(500ms);

    mAppManagerPtr->GetEventsManagerModel()->SetUpEventsManager();
    std::this_thread::sleep_for(500ms);

    //mEventManagerPtr->AddSignal("EV5004");

    mAppManagerPtr->GetDataLoggerModel()->SetUpDataLogger();
    std::this_thread::sleep_for(200ms); // make 200 ms for periodic & 500ms for eventDriven

    mAppManagerPtr->GetDataAccessModel()->Write(190, 61, Protocol::J1939Proto);
    std::this_thread::sleep_for(1000ms);

    mAppManagerPtr->GetDataAccessModel()->Write(190, 45, Protocol::J1939Proto);
    std::this_thread::sleep_for(1000ms);

    mAppManagerPtr->GetDataAccessModel()->Write(190, 600, Protocol::J1939Proto);
    std::this_thread::sleep_for(1000ms);

    mEventManagerPtr->EmitSignal("EV5004");
    std::this_thread::sleep_for(1000ms);

    mAppManagerPtr->GetDataAccessModel()->Write(190, 100, Protocol::J1939Proto);
    std::this_thread::sleep_for(300ms);

    mAppManagerPtr->GetDataAccessModel()->Write(190, 200, Protocol::J1939Proto);
    std::this_thread::sleep_for(300ms);

    mAppManagerPtr->GetDataAccessModel()->Write(190, 70, Protocol::J1939Proto);
    std::this_thread::sleep_for(300ms);
    mEventManagerPtr->EmitSignal(mSystemStateReceiverPtr->PostponableShutDownEvent);
}

//1. For event driven trigger type, test whether output file is getting created or not
//after Shutdown signal event occurred.
TEST_F(DataLoggerModelTest, TestEV5004SignalForEventDriven)
{
    Json::Value parsed_json_val =  mJsonParserPtr->ParseJsonFile("../test/Test_EV5004_EventDriven_Configuration.json");
    mAppManagerPtr->GetConfigurationModel()->ParseJson(parsed_json_val);

    mAppManagerPtr->GetClientManagerModel()->SetUpClientManager();
    mAppManagerPtr->GetSamplersManagerModel()->SetUpSamplersManager();
    std::this_thread::sleep_for(500ms);

    mAppManagerPtr->GetEventsManagerModel()->SetUpEventsManager();
    std::this_thread::sleep_for(500ms);

    mEventManagerPtr->AddSignal("EV5004");

    mAppManagerPtr->GetDataLoggerModel()->SetUpDataLogger();
    std::this_thread::sleep_for(500ms); // make 200 ms for periodic & 500ms for eventDriven

    mAppManagerPtr->GetDataAccessModel()->Write(190, 61, Protocol::J1939Proto);
    std::this_thread::sleep_for(1000ms);

    mAppManagerPtr->GetDataAccessModel()->Write(190, 45, Protocol::J1939Proto);
    std::this_thread::sleep_for(1000ms);

    mAppManagerPtr->GetDataAccessModel()->Write(190, 600, Protocol::J1939Proto);
    std::this_thread::sleep_for(1000ms);

    mEventManagerPtr->EmitSignal("EV5004");
    std::this_thread::sleep_for(1000ms);

    mAppManagerPtr->GetDataAccessModel()->Write(190, 100, Protocol::J1939Proto);
    std::this_thread::sleep_for(300ms);

    mAppManagerPtr->GetDataAccessModel()->Write(190, 200, Protocol::J1939Proto);
    std::this_thread::sleep_for(300ms);

    mAppManagerPtr->GetDataAccessModel()->Write(190, 70, Protocol::J1939Proto);
    std::this_thread::sleep_for(300ms);
    mEventManagerPtr->EmitSignal(mSystemStateReceiverPtr->PostponableShutDownEvent);
}
*/
