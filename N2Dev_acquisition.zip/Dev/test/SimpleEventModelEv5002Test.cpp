#include <gtest/gtest.h>
#include "AppManager.h"
#include "DataAccessModel.h"
#include "EventsManagerModel.h"
#include "SimpleEventModelEv5002.h"

using namespace DaqApp;

class SimpleEventModelEv5002Test : public testing::Test
{
protected:
    AppManager*             mAppManagerPtr;
    SimpleEventModelEv5002* mSimpleEv5002Ptr;
    EventConfigMessage      mEventConfigMsg;

    void SetUp() override
    {
        mEventConfigMsg.ConfigID = ConfigIds::ConfigOne;
        mAppManagerPtr = new AppManager();
        mSimpleEv5002Ptr = new SimpleEventModelEv5002(mEventConfigMsg, mAppManagerPtr->GetEventsManagerModel(),mAppManagerPtr);
    }

    void TearDown() override
    {
        delete mSimpleEv5002Ptr;
        delete mAppManagerPtr;
    }
};


TEST_F(SimpleEventModelEv5002Test, DM6Message)
{
    bool WasEv5002SignalEmitted ;
    mAppManagerPtr->GetEventsManagerModel()->ConnectToSignal("EV5002",[&]() {WasEv5002SignalEmitted = true;});
    mAppManagerPtr->GetDataAccessModel()->Write("pendingFaultCodes", "spn:689~fmi:1~count:3|spn:102~fmi:18~count:1|",Protocol::EventProto,mEventConfigMsg.ConfigID);

    mSimpleEv5002Ptr->Evaluate();
    EXPECT_EQ(true,WasEv5002SignalEmitted);                //signal emission check
    EXPECT_EQ(true, mSimpleEv5002Ptr->mIsActive); //Internal state check

    mAppManagerPtr->GetDataAccessModel()->Write("pendingFaultCodes", "spn:0~fmi:0~count:0|",Protocol::EventProto,mEventConfigMsg.ConfigID); //No longer active internally
    mSimpleEv5002Ptr->Evaluate();
    EXPECT_EQ(false,mSimpleEv5002Ptr->mIsActive);
}
