#include <boost/filesystem.hpp>
#include "gtest/gtest.h"
#include "EventsManagerModel.h"
#include "AppManager.h"
#include "ConfigurationManagerModel.h"
#include "DataAccessModel.h"
#include "CommonHeader.h"
#include "FilesHandlingModel.h"

using namespace DaqApp;
using namespace std::chrono;

class CompositeEventModelTest : public testing::Test
{
protected:
        AppManager* mAppManagerPtr                   ;
        std::unique_ptr<JsonParserModel> mJsonParserPtr;
    	EventsManagerModel* mEventManagerPtr         ;
    	ConfigurationManagerModel* mConfigurationManagerPtr;
    	FilesHandlingModel* mFilesHandlingModel;
    	bool mIsSlotFunctionCalled{false};

    void SetUp() override
    {
        boostfs::remove_all(COMMON_DIR);
        mAppManagerPtr    = new AppManager();
        mJsonParserPtr = std::make_unique<JsonParserModel>();
    	mEventManagerPtr  = mAppManagerPtr->GetEventsManagerModel();
    	mConfigurationManagerPtr = mAppManagerPtr->GetConfigurationModel();
        mFilesHandlingModel = mAppManagerPtr->GetFilesHandlingModel();
    }

    void TearDown() override
    {
        boostfs::remove_all(COMMON_DIR);
        delete mAppManagerPtr;
    }

public:
    void MySlot ()
    {
        mIsSlotFunctionCalled = true;
    }
};

//Test case with no event ID in config file. EV6000 is not in config file.
TEST_F(CompositeEventModelTest, TestEventCompositNoEventCong)
{
    mFilesHandlingModel->SetUpFilesHandlingModel();
    boostfs::copy_file("../test/Test_CompositeEvent.json", ACTIVE_CONFIG_DIR + "/Test_CompositeEvent.json");
    mAppManagerPtr->GetConfigurationModel()->SetUpConfigurationManager();
    mAppManagerPtr->GetEventsManagerModel()->SetUpEventsManager();

    bool isSlotConnectedToSignal = mEventManagerPtr->ConnectToSignal("EV6000",boost::bind(&CompositeEventModelTest::MySlot,this));
    EXPECT_FALSE(isSlotConnectedToSignal);

    mAppManagerPtr->GetDataAccessModel()->Write("activeFaultCodes", "spn:689~fmi:1~count:3|spn:102~fmi:18~count:1|",Protocol::EventProto, ConfigIds::ConfigOne);

    mAppManagerPtr->GetDataAccessModel()->Write(190, 200, Protocol::J1939Proto, ConfigIds::ConfigOne);
    std::this_thread::sleep_for(500ms);

    // Activating event EV5003
    mAppManagerPtr->GetDataAccessModel()->Write(190, 450, Protocol::J1939Proto, ConfigIds::ConfigOne); // Active when enginespeed is > 400

    std::this_thread::sleep_for(500ms);
    //No event configured.
    EXPECT_FALSE(mIsSlotFunctionCalled);
}

//Test case with two simple Events  EV5000 and EV5003 for AND condition.
TEST_F(CompositeEventModelTest, TestEventCompositAND)
{
    mFilesHandlingModel->SetUpFilesHandlingModel();
    boostfs::copy_file("../test/Test_CompositeEvent_WithAndCondition.json",ACTIVE_CONFIG_DIR+"/Test_CompositeEvent_WithAndCondition.json");
    mAppManagerPtr->GetConfigurationModel()->SetUpConfigurationManager();
    mAppManagerPtr->GetEventsManagerModel()->SetUpEventsManager();

    bool isSlotConnectedToSignal = mEventManagerPtr->ConnectToSignal("EV5005",boost::bind(&CompositeEventModelTest::MySlot,this));
    EXPECT_TRUE(isSlotConnectedToSignal);

    //Activate EV5000
    mAppManagerPtr->GetDataAccessModel()->Write("activeFaultCodes", "spn:689~fmi:1~count:3|spn:102~fmi:18~count:1|",Protocol::EventProto, ConfigIds::ConfigOne);

    mAppManagerPtr->GetDataAccessModel()->Write(190, 200, Protocol::J1939Proto, ConfigIds::ConfigOne);
    std::this_thread::sleep_for(200ms);

    // Activating event EV5003
    mAppManagerPtr->GetDataAccessModel()->Write(190, 450, Protocol::J1939Proto, ConfigIds::ConfigOne); // Active when enginespeed is > 400
    std::this_thread::sleep_for(200ms);

    mEventManagerPtr->EvaluateEvents();
    std::this_thread::sleep_for(200ms);

    //EV5000 and EV50003 are active, AND condition
    EXPECT_TRUE(mIsSlotFunctionCalled);

    mIsSlotFunctionCalled = false;

     // Deactivate event EV5003
    mAppManagerPtr->GetDataAccessModel()->Write(190, 350, Protocol::J1939Proto, ConfigIds::ConfigOne); // Active when enginespeed is <400
    std::this_thread::sleep_for(500ms);
    //EV5000 active and EV50003 is inactive. AND condition
    EXPECT_FALSE(mIsSlotFunctionCalled);
}

//Test case with two simple Events EV5000 and EV5003 for OR condition.
TEST_F(CompositeEventModelTest, TestEventCompositOR)
{
    mFilesHandlingModel->SetUpFilesHandlingModel();

    boostfs::copy_file("../test/Test_CompositeEvent_WithOrCondition.json", ACTIVE_CONFIG_DIR + "/Test_CompositeEvent_WithOrCondition.json");
    mAppManagerPtr->GetConfigurationModel()->SetUpConfigurationManager();
    mAppManagerPtr->GetEventsManagerModel()->SetUpEventsManager();

    bool isSlotConnectedToSignal = mEventManagerPtr->ConnectToSignal("EV5010",boost::bind(&CompositeEventModelTest::MySlot,this));
    EXPECT_TRUE(isSlotConnectedToSignal);

   //EV5000 active
    mAppManagerPtr->GetDataAccessModel()->Write("activeFaultCodes", "spn:689~fmi:1~count:3|spn:102~fmi:18~count:1|",Protocol::EventProto, ConfigIds::ConfigOne);

    mAppManagerPtr->GetDataAccessModel()->Write(190, 200, Protocol::J1939Proto, ConfigIds::ConfigOne);
    std::this_thread::sleep_for(200ms);
    //EV5000 not active
    mAppManagerPtr->GetDataAccessModel()->Write(190, 350, Protocol::J1939Proto, ConfigIds::ConfigOne); // Active when enginespeed is > 400
    std::this_thread::sleep_for(200ms);

    mEventManagerPtr->EvaluateEvents();
    std::this_thread::sleep_for(200ms);

    //EV5000 is active and EV50003 is inactive, OR condition test.
    EXPECT_TRUE(mIsSlotFunctionCalled);

    mIsSlotFunctionCalled = false;
    mAppManagerPtr->GetDataAccessModel()->Write("activeFaultCodes", "spn:0~fmi:0~count:0|",Protocol::EventProto, ConfigIds::ConfigOne); //No longer active internally

    std::this_thread::sleep_for(200ms);
    //EV5000 and EV50003 is inactive, OR condition test.
    EXPECT_FALSE(mIsSlotFunctionCalled);
}

//Test case with two simple Events EV5000 and EV5003 for AND condition, EV5001 for OR condition.
TEST_F(CompositeEventModelTest, TestEventCompositANDOR)
{
    mFilesHandlingModel->SetUpFilesHandlingModel();

    boostfs::copy_file("../test/Test_CompositeEvent_WithAndOrCondition.json", ACTIVE_CONFIG_DIR + "/Test_CompositeEvent_WithAndOrCondition.json");
    mAppManagerPtr->GetConfigurationModel()->SetUpConfigurationManager();
    mAppManagerPtr->GetEventsManagerModel()->SetUpEventsManager();

    bool isSlotConnectedToSignal = mEventManagerPtr->ConnectToSignal("EV5011",boost::bind(&CompositeEventModelTest::MySlot,this));
    EXPECT_TRUE(isSlotConnectedToSignal);

   //EV5000 Active
    mAppManagerPtr->GetDataAccessModel()->Write("activeFaultCodes", "spn:689~fmi:1~count:3|spn:102~fmi:18~count:1|",Protocol::EventProto, ConfigIds::ConfigOne);

    mAppManagerPtr->GetDataAccessModel()->Write(190, 200, Protocol::J1939Proto, ConfigIds::ConfigOne);
    std::this_thread::sleep_for(200ms);

    // EV5003 Inactive
    mAppManagerPtr->GetDataAccessModel()->Write(190, 350, Protocol::J1939Proto, ConfigIds::ConfigOne); // Active when enginespeed is > 400
    std::this_thread::sleep_for(200ms);

    //EV5001 Active
    mAppManagerPtr->GetDataAccessModel()->Write("inactiveFaultCodes", "spn:689~fmi:1~count:3|spn:102~fmi:18~count:1|",Protocol::EventProto, ConfigIds::ConfigOne);
    std::this_thread::sleep_for(200ms);

    mEventManagerPtr->EvaluateEvents();
    std::this_thread::sleep_for(200ms);

    //AND condition is false and OR condtion is true.
    EXPECT_TRUE(mIsSlotFunctionCalled);

    mIsSlotFunctionCalled = false;
    //EV5001 Inactive Active
    mAppManagerPtr->GetDataAccessModel()->Write("inactiveFaultCodes", "spn:0~fmi:0~count:0|",Protocol::EventProto, ConfigIds::ConfigOne); //No longer active internally
    std::this_thread::sleep_for(200ms);
    // AND and OR conditions are false
    EXPECT_FALSE(mIsSlotFunctionCalled);
}
