#include "gtest/gtest.h"
#include "JsonParserModel.h"
#include "ValidationModel.h"

using namespace DaqApp;

class ValidationModelTest : public testing::Test
 {
protected:

	std::unique_ptr<JsonParserModel> mJsonParserPtr;
	std::unique_ptr<ValidationModel> mValidationPtr;

    void SetUp() override
    {
        mJsonParserPtr = std::make_unique<JsonParserModel>();
        mValidationPtr = std::make_unique<ValidationModel>();
    }

    void TearDown() override {  }
};

// Read the configuration file using JsonParser and validate using ValidationModel

TEST_F(ValidationModelTest, validate_activate_configuration)
{
    Json::Value root =  mJsonParserPtr->ParseJsonFile("../test/Test_activate_Configuration.json");
    EXPECT_TRUE(mValidationPtr->IsValidConfig(root));

    // Configuration with activate command
    root =  mJsonParserPtr->ParseJsonFile("../test/Test_Configuration_TripData.json");
    EXPECT_TRUE(mValidationPtr->IsValidConfig(root));
}

TEST_F(ValidationModelTest, validate_deactivate_configuration)
{
    Json::Value root =  mJsonParserPtr->ParseJsonFile("../test/Test_deactivate_and_forget_config.json");
    EXPECT_TRUE(mValidationPtr->IsValidConfig(root));
}

TEST_F(ValidationModelTest, invalid_configuration)
{
    Json::Value root =  mJsonParserPtr->ParseJsonFile("../test/Test_invalid_Configuration.json");
    EXPECT_FALSE(mValidationPtr->IsValidConfig(root));
}
