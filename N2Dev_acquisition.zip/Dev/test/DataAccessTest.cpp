
#include <algorithm>
#include "gtest/gtest.h"
#include "AppManager.h"
#include "DataAccessModel.h"
#include "TimeUtilities.h"
#include "CommonHeader.h"

using namespace DaqApp;
class DataAccessModelTest : public testing::Test
 {
protected:
    std::shared_ptr<AppManager> mAppManPtr;
    DataAccessModel*            mDataAccessModelPtr;
    TimeUtilities*              mTimeUtilitiesPtr ;
	void SetUp() override
	{
        mAppManPtr              = std::make_shared<AppManager>();
        mDataAccessModelPtr = mAppManPtr->GetDataAccessModel()   ;
        mTimeUtilitiesPtr   = mAppManPtr->GetTimeUtilities()     ;
    }

	void TearDown() override
 	{
        mDataAccessModelPtr= nullptr;
        mTimeUtilitiesPtr  = nullptr;
    };
};

//--------------------------------Misc ReadWrite Imp tests------------------------------
TEST_F(DataAccessModelTest, WritingMiscNewSource)
{
	mDataAccessModelPtr->WriteMisc("Source1","Value1")           ;
	mDataAccessModelPtr->WriteMisc("Source2","Value2")           ;
	mDataAccessModelPtr->WriteMisc("Source3","Value3")           ;
	EXPECT_EQ("Value1", mDataAccessModelPtr->ReadMisc("Source1"));
	EXPECT_EQ("Value2", mDataAccessModelPtr->ReadMisc("Source2"));
	EXPECT_EQ("Value3", mDataAccessModelPtr->ReadMisc("Source3"));
}

TEST_F(DataAccessModelTest, WritingMiscUpdatingSource)
{
	mDataAccessModelPtr->WriteMisc("Source1","Value")              ;
	mDataAccessModelPtr->WriteMisc("Source1","NewValue")           ;
	EXPECT_EQ("NewValue", mDataAccessModelPtr->ReadMisc("Source1"));
}

TEST_F(DataAccessModelTest, WritingMiscNoOverLap)
{
	mDataAccessModelPtr->WriteMisc("987","Value1")                                      ;
	mDataAccessModelPtr->WriteMisc("105","Value2")                                      ;
	EXPECT_NE(mDataAccessModelPtr->ReadMisc("987"), mDataAccessModelPtr->ReadMisc("105"));
}

TEST_F(DataAccessModelTest, WritingMiscBenchMark)
{
    mTimeUtilitiesPtr->init();
    for( int i = 0 ; i < 1000; i++)
    {
        mDataAccessModelPtr->WriteMisc("Source55" + std::to_string(i), "SomeValue"+std::to_string(i));
    }
    mTimeUtilitiesPtr->PrintDuration()                                                               ;
}

TEST_F(DataAccessModelTest, ReadingMiscBenchMark)
{
    for( int i = 0 ; i < 1000; i++)
    {
        mDataAccessModelPtr->WriteMisc("Source55" + std::to_string(i), "SomeValue"+std::to_string(i));
    }
    mTimeUtilitiesPtr->init()                                             ;
    EXPECT_EQ("SomeValue999",mDataAccessModelPtr->ReadMisc("Source55999"));
    mTimeUtilitiesPtr->PrintDuration()                                    ;
}

//--------------------------------J1939 ReadWrite Imp tests------------------------------
TEST_F(DataAccessModelTest, WritingJ1939NewSource)
{
	mDataAccessModelPtr->Write(100,200,Protocol::J1939Proto,ConfigIds::ConfigOne)             ;
	mDataAccessModelPtr->Write(200,200,Protocol::J1939Proto,ConfigIds::ConfigOne)             ;
	mDataAccessModelPtr->Write(300,200,Protocol::J1939Proto,ConfigIds::ConfigOne)             ;
	mDataAccessModelPtr->Write(400,200,Protocol::J1939Proto,ConfigIds::ConfigOne)             ;
	mDataAccessModelPtr->Write(500,200,Protocol::J1939Proto,ConfigIds::ConfigOne)             ;
	EXPECT_EQ(200, mDataAccessModelPtr->Read(100,Protocol::J1939Proto,ConfigIds::ConfigOne))  ;

	mDataAccessModelPtr->Write(300,600,Protocol::J1939Proto,ConfigIds::ConfigOne)             ;
	mDataAccessModelPtr->Write(21023,5200,Protocol::J1939Proto,ConfigIds::ConfigOne)          ;

	EXPECT_EQ(600, mDataAccessModelPtr->Read(300,Protocol::J1939Proto,ConfigIds::ConfigOne))  ;
	EXPECT_EQ(5200,mDataAccessModelPtr->Read(21023,Protocol::J1939Proto,ConfigIds::ConfigOne));

}

TEST_F(DataAccessModelTest, WritingJ1939UpdatingSource)
{
	mDataAccessModelPtr->Write(165,1250, Protocol::J1939Proto,ConfigIds::ConfigOne)          ;
	mDataAccessModelPtr->Write(165,1300, Protocol::J1939Proto,ConfigIds::ConfigOne)          ;
	EXPECT_EQ(1300, mDataAccessModelPtr->Read(165,Protocol::J1939Proto,ConfigIds::ConfigOne));
}

TEST_F(DataAccessModelTest, WritingJ1939OverLap)
{
	mDataAccessModelPtr->Write(100,200, Protocol::J1939Proto,ConfigIds::ConfigOne);
	mDataAccessModelPtr->Write(150,680, Protocol::J1939Proto,ConfigIds::ConfigOne);
	EXPECT_NE(mDataAccessModelPtr->Read(100,Protocol::J1939Proto,ConfigIds::ConfigOne), mDataAccessModelPtr->Read(150,Protocol::J1939Proto,ConfigIds::ConfigOne));
}

TEST_F(DataAccessModelTest, WritingJ1939BenchMark)
{
    mTimeUtilitiesPtr->init();
    for( int i = 0 ; i < 1000; i++)
    {
        mDataAccessModelPtr->Write(100+i,200+i, Protocol::J1939Proto,ConfigIds::ConfigOne);
    }
    mTimeUtilitiesPtr->PrintDuration()                               ;
}

TEST_F(DataAccessModelTest, ReadingJ1939BenchMark)
{
    for( int i = 0 ; i < 1000; i++)
    {
        mDataAccessModelPtr->Write(100+i,200+i, Protocol::J1939Proto,ConfigIds::ConfigOne)  ;
    }
    mTimeUtilitiesPtr->init()                                          ;
    EXPECT_EQ(1000,mDataAccessModelPtr->Read(900,Protocol::J1939Proto,ConfigIds::ConfigOne));
    mTimeUtilitiesPtr->PrintDuration();
}


//--------------------------------MultiMap ReadWrite Imp tests-----------------
TEST_F(DataAccessModelTest, WritingMultiMapNewSource)
{
	mDataAccessModelPtr->Write("F701", "877875438E654CD0B99987654AB09BDF", Protocol::UDSProto,ConfigIds::ConfigOne);
	mDataAccessModelPtr->Write("F801", "877875438E654CD0B99987654AB09BAF", Protocol::UDSProto,ConfigIds::ConfigOne);
	EXPECT_EQ("877875438E654CD0B99987654AB09BDF", mDataAccessModelPtr->Read("F701",ConfigIds::ConfigOne))  ;
	EXPECT_EQ("877875438E654CD0B99987654AB09BAF", mDataAccessModelPtr->Read("F801",ConfigIds::ConfigOne))  ;
}

TEST_F(DataAccessModelTest, WritingMultiMapUpdatingSource)
{
	mDataAccessModelPtr->Write("F701", "877875438E654CD0B99987654AB09BDF", Protocol::UDSProto,ConfigIds::ConfigOne);
	mDataAccessModelPtr->Write("F701", "576875438E654CD0B99987654AB09BEF", Protocol::UDSProto,ConfigIds::ConfigOne);
	EXPECT_EQ("576875438E654CD0B99987654AB09BEF", mDataAccessModelPtr->Read("F701",ConfigIds::ConfigOne))  ;
}

TEST_F(DataAccessModelTest, WritingMultiMapOverLap)
{
	mDataAccessModelPtr->Write("F701", "877875438E654CD0B99987654AB09BDF", Protocol::UDSProto,ConfigIds::ConfigOne);
	mDataAccessModelPtr->Write("F801", "877875438E654CD0B99987654AB09BAF", Protocol::UDSProto,ConfigIds::ConfigOne);
	EXPECT_NE(mDataAccessModelPtr->Read("F701",ConfigIds::ConfigOne), mDataAccessModelPtr->Read("F801",ConfigIds::ConfigOne));
}


TEST_F(DataAccessModelTest, WritingMultiMapBenchMark)
{
    mTimeUtilitiesPtr->init();
    for( int i = 0 ; i < 1000; i++)
    {
        mDataAccessModelPtr->Write("F701" +std::to_string(i), "877875438E654CD0B99987654AB09BDF" +std::to_string(i), Protocol::UDSProto,ConfigIds::ConfigOne);
    }
    mTimeUtilitiesPtr->PrintDuration()                               ;
}

TEST_F(DataAccessModelTest, ReadingMultiMapBenchMark)
{
    for( int i = 0 ; i < 1000; i++)
    {
        mDataAccessModelPtr->Write("F701" +std::to_string(i), "877875438E654CD0B99987654AB09BDF" +std::to_string(i), Protocol::UDSProto,ConfigIds::ConfigOne);
    }
    mTimeUtilitiesPtr->init()                                          ;
    EXPECT_EQ("877875438E654CD0B99987654AB09BDF200", mDataAccessModelPtr->Read("F701200",ConfigIds::ConfigOne));
    mTimeUtilitiesPtr->PrintDuration();
}

//--------------------------------Get Record Test------------------------------
TEST_F(DataAccessModelTest, GetRecordAllProtos)
{
    //GetRecord is used by data logger for Initial release
    //----------------------------------------Writing Data---------------------
    mDataAccessModelPtr-> Write(500  ,200 , Protocol::J1939Proto,ConfigIds::ConfigOne);// write some J1939 data
    mDataAccessModelPtr-> Write(102  ,6546 , Protocol::J1939Proto,ConfigIds::ConfigOne);// write some J1939 data
    mDataAccessModelPtr->Write("F201", "877875438E654CD0B99987654AB09BDF", Protocol::UDSProto,ConfigIds::ConfigOne); // From Cummins output example UDS
    mDataAccessModelPtr->Write("F205", "877875438E654CD0B99987677AB09BDC", Protocol::UDSProto,ConfigIds::ConfigOne); // Random
    //----------------------------------------Actual Test----------------------
    //verify GPS Data
    std::pair<std::string,std::string> UDSData1         = std::make_pair("F201", "877875438E654CD0B99987654AB09BDF");
    std::pair<std::string,std::string> UDSData2         = std::make_pair("F205", "877875438E654CD0B99987677AB09BDC");
    std::pair<std::string,std::string> J1939DataSource1 = std::make_pair("500", "200.000000")                              ;
    std::pair<std::string,std::string> J1939DataSource2 = std::make_pair("102", "6546.000000")                             ;
    //Verify UDS Data
    EXPECT_EQ(true, (std::find(mDataAccessModelPtr->GetRecord(ConfigIds::ConfigOne).Data.begin(),
                    mDataAccessModelPtr->GetRecord(ConfigIds::ConfigOne).Data.end() , UDSData1)!=mDataAccessModelPtr->GetRecord(ConfigIds::ConfigOne).Data.end()));
    EXPECT_EQ(true, (std::find(mDataAccessModelPtr->GetRecord(ConfigIds::ConfigOne).Data.begin(),
                    mDataAccessModelPtr->GetRecord(ConfigIds::ConfigOne).Data.end() , UDSData2)!=mDataAccessModelPtr->GetRecord(ConfigIds::ConfigOne).Data.end()));
    //Verify J1939Data
    EXPECT_EQ(true, (std::find(mDataAccessModelPtr->GetRecord(ConfigIds::ConfigOne).Data.begin(),
                    mDataAccessModelPtr->GetRecord(ConfigIds::ConfigOne).Data.end() , J1939DataSource1)!=mDataAccessModelPtr->GetRecord(ConfigIds::ConfigOne).Data.end()));
    EXPECT_EQ(true, (std::find(mDataAccessModelPtr->GetRecord(ConfigIds::ConfigOne).Data.begin(),
                    mDataAccessModelPtr->GetRecord(ConfigIds::ConfigOne).Data.end() , J1939DataSource2)!=mDataAccessModelPtr->GetRecord(ConfigIds::ConfigOne).Data.end()));
}

TEST_F(DataAccessModelTest, WritingJ1939NegativeValues)
{
	mDataAccessModelPtr->Write(100,-200,Protocol::J1939Proto,ConfigIds::ConfigOne)             ;
    mDataAccessModelPtr->Write(200,-300,Protocol::J1939Proto,ConfigIds::ConfigOne)             ;
    mDataAccessModelPtr->Write(300,-400,Protocol::J1939Proto,ConfigIds::ConfigOne)             ;
	EXPECT_EQ(-200, mDataAccessModelPtr->Read(100,Protocol::J1939Proto,ConfigIds::ConfigOne))  ;
	mDataAccessModelPtr->Write(300,-600,Protocol::J1939Proto,ConfigIds::ConfigOne)             ;
	mDataAccessModelPtr->Write(21023,-5200,Protocol::J1939Proto,ConfigIds::ConfigOne)          ;
	EXPECT_EQ(-600, mDataAccessModelPtr->Read(300,Protocol::J1939Proto,ConfigIds::ConfigOne))  ;
	EXPECT_EQ(-5200,mDataAccessModelPtr->Read(21023,Protocol::J1939Proto,ConfigIds::ConfigOne));
}

TEST_F(DataAccessModelTest, WritingJ1939FloatValues)
{
	mDataAccessModelPtr->Write(100,200.123,Protocol::J1939Proto,ConfigIds::ConfigOne)             ;
	mDataAccessModelPtr->Write(200,200.234,Protocol::J1939Proto,ConfigIds::ConfigOne)             ;
	mDataAccessModelPtr->Write(300,200.456,Protocol::J1939Proto,ConfigIds::ConfigOne)             ;
	mDataAccessModelPtr->Write(400,200.678,Protocol::J1939Proto,ConfigIds::ConfigOne)             ;
	mDataAccessModelPtr->Write(500,200.789,Protocol::J1939Proto,ConfigIds::ConfigOne)             ;
	EXPECT_FLOAT_EQ(200.123, mDataAccessModelPtr->Read(100,Protocol::J1939Proto,ConfigIds::ConfigOne))  ;
	mDataAccessModelPtr->Write(300,600.456,Protocol::J1939Proto,ConfigIds::ConfigOne)             ;
	mDataAccessModelPtr->Write(21023,5200.678,Protocol::J1939Proto,ConfigIds::ConfigOne)          ;
	EXPECT_FLOAT_EQ(600.456, mDataAccessModelPtr->Read(300,Protocol::J1939Proto,ConfigIds::ConfigOne))  ;
	EXPECT_FLOAT_EQ(5200.678,mDataAccessModelPtr->Read(21023,Protocol::J1939Proto,ConfigIds::ConfigOne));
}
