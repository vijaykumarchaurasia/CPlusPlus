#include <gtest/gtest.h>
#include "AppManager.h"
#include "DataAccessModel.h"
#include "EventsManagerModel.h"
#include "SimpleEventModelEvDynamicXcp.h"

using namespace DaqApp;

class SimpleEventEvDynamicXcpTest : public testing::Test
{

public:

    bool                            mWasNotifyEvDynamicSignalEmitted {false};
    AppManager*                     mAppManagerPtr;
    SimpleEventModelEvDynamicXcp*   mSimpleEvDynamicXcpPtr;
    EventConfigMessage              mEventConfigMsg;


    void SetUp() override
    {
        mAppManagerPtr = new AppManager();
        mEventConfigMsg.EventId = "XCPDynamicEvent";
        mEventConfigMsg.Type = EventsType::DynamicXcpEvent;
        mEventConfigMsg.Source = "XCPEngineSpeed" ;
        mEventConfigMsg.Protocol="XCP";
        mEventConfigMsg.Threshold = 1000;
        mEventConfigMsg.ConfigID = ConfigIds::ConfigOne;
        //operator set in each test case
    }

    void TearDown() override
    {
       delete mSimpleEvDynamicXcpPtr;
       delete mAppManagerPtr;

    }
    void MySlot ()
    {
        mWasNotifyEvDynamicSignalEmitted = true;
    }
};

TEST_F(SimpleEventEvDynamicXcpTest, ParameterCompEventEqual)
{
    mEventConfigMsg.Operator = "==" ;
    mSimpleEvDynamicXcpPtr = new SimpleEventModelEvDynamicXcp(mEventConfigMsg, mAppManagerPtr->GetEventsManagerModel(),mAppManagerPtr);
    bool isSlotConnectedToSignal = mAppManagerPtr->GetEventsManagerModel()->ConnectToSignal
    (mEventConfigMsg.EventId,boost::bind(&SimpleEventEvDynamicXcpTest::MySlot,this));
    EXPECT_EQ(true,isSlotConnectedToSignal);

    // Not active after engine speed is written to the DataAccess without meeting event threshold
    mAppManagerPtr->GetDataAccessModel()->Write("XCPEngineSpeed","500", Protocol::XCPProto,mEventConfigMsg.ConfigID);
    mSimpleEvDynamicXcpPtr->Evaluate();
    EXPECT_EQ(false,mSimpleEvDynamicXcpPtr->mIsActive);
    EXPECT_EQ(false,mWasNotifyEvDynamicSignalEmitted);   //signal emission check

    mWasNotifyEvDynamicSignalEmitted = false;
    mAppManagerPtr->GetDataAccessModel()->Write("XCPEngineSpeed","1000", Protocol::XCPProto,mEventConfigMsg.ConfigID); //Engine speed is equal to threshold.
    mSimpleEvDynamicXcpPtr->Evaluate();
    EXPECT_EQ(true,mWasNotifyEvDynamicSignalEmitted);   //signal emission check
    EXPECT_EQ(true, mSimpleEvDynamicXcpPtr->mIsActive);        //Internal state check
}

TEST_F(SimpleEventEvDynamicXcpTest, ParameterCompEventNotEqual)
{
    mEventConfigMsg.Operator = "!=";
    mSimpleEvDynamicXcpPtr = new SimpleEventModelEvDynamicXcp(mEventConfigMsg, mAppManagerPtr->GetEventsManagerModel(),mAppManagerPtr);
    bool isSlotConnectedToSignal = mAppManagerPtr->GetEventsManagerModel()->ConnectToSignal
    (mEventConfigMsg.EventId,boost::bind(&SimpleEventEvDynamicXcpTest::MySlot,this));
    EXPECT_EQ(true,isSlotConnectedToSignal);

    // Not active after engine speed is written to the DataAccess without meeting event threshold
    mAppManagerPtr->GetDataAccessModel()->Write("XCPEngineSpeed","1000", Protocol::XCPProto,mEventConfigMsg.ConfigID);
    mSimpleEvDynamicXcpPtr->Evaluate();
    EXPECT_EQ(false,mSimpleEvDynamicXcpPtr->mIsActive);
    EXPECT_EQ(false,mWasNotifyEvDynamicSignalEmitted);   //signal emission check

    mWasNotifyEvDynamicSignalEmitted = false;
    mAppManagerPtr->GetDataAccessModel()->Write("XCPEngineSpeed","2000", Protocol::XCPProto,mEventConfigMsg.ConfigID); //Engine speed is not equal to threshold.
    mSimpleEvDynamicXcpPtr->Evaluate();
    EXPECT_EQ(true,mWasNotifyEvDynamicSignalEmitted);   //signal emission check
    EXPECT_EQ(true, mSimpleEvDynamicXcpPtr->mIsActive);        //Internal state check
}

TEST_F(SimpleEventEvDynamicXcpTest, ParameterCompEventGreater)
{
    mEventConfigMsg.Operator = ">";
    mSimpleEvDynamicXcpPtr = new SimpleEventModelEvDynamicXcp(mEventConfigMsg, mAppManagerPtr->GetEventsManagerModel(),mAppManagerPtr);

    bool isSlotConnectedToSignal = mAppManagerPtr->GetEventsManagerModel()->ConnectToSignal
    (mEventConfigMsg.EventId,boost::bind(&SimpleEventEvDynamicXcpTest::MySlot,this));
    EXPECT_EQ(true,isSlotConnectedToSignal);

    EXPECT_EQ(false,mWasNotifyEvDynamicSignalEmitted);   //signal emission check
    // Not active after engine speed is written to the DataAccess without meeting event threshold
    mAppManagerPtr->GetDataAccessModel()->Write("XCPEngineSpeed","1000", Protocol::XCPProto,mEventConfigMsg.ConfigID);
    mSimpleEvDynamicXcpPtr->Evaluate();
    EXPECT_EQ(false,mSimpleEvDynamicXcpPtr->mIsActive);
    EXPECT_EQ(false,mWasNotifyEvDynamicSignalEmitted);   //signal emission check

    mWasNotifyEvDynamicSignalEmitted = false;
    mAppManagerPtr->GetDataAccessModel()->Write("XCPEngineSpeed","2000", Protocol::XCPProto,mEventConfigMsg.ConfigID); //Engine speed is greater than threshold.
    mSimpleEvDynamicXcpPtr->Evaluate();
    EXPECT_EQ(true,mWasNotifyEvDynamicSignalEmitted);   //signal emission check
    EXPECT_EQ(true, mSimpleEvDynamicXcpPtr->mIsActive);        //Internal state check
}

TEST_F(SimpleEventEvDynamicXcpTest, ParameterCompEventGreaterEqual)
{
    mEventConfigMsg.Operator = ">=";
    mSimpleEvDynamicXcpPtr = new SimpleEventModelEvDynamicXcp(mEventConfigMsg, mAppManagerPtr->GetEventsManagerModel(),mAppManagerPtr);

    bool isSlotConnectedToSignal = mAppManagerPtr->GetEventsManagerModel()->ConnectToSignal
    (mEventConfigMsg.EventId,boost::bind(&SimpleEventEvDynamicXcpTest::MySlot,this));
    EXPECT_EQ(true,isSlotConnectedToSignal);

    // Not active after engine speed is written to the DataAccess without meeting event threshold
    mAppManagerPtr->GetDataAccessModel()->Write("XCPEngineSpeed","500", Protocol::XCPProto,mEventConfigMsg.ConfigID);
    mSimpleEvDynamicXcpPtr->Evaluate();
    EXPECT_EQ(false,mSimpleEvDynamicXcpPtr->mIsActive);
    EXPECT_EQ(false,mWasNotifyEvDynamicSignalEmitted);   //signal emission check

    mWasNotifyEvDynamicSignalEmitted = false;
    mAppManagerPtr->GetDataAccessModel()->Write("XCPEngineSpeed","2000", Protocol::XCPProto,mEventConfigMsg.ConfigID); //Engine speed is greater than threshold.
    mSimpleEvDynamicXcpPtr->Evaluate();
    EXPECT_EQ(true, mWasNotifyEvDynamicSignalEmitted);   //signal emission check
    EXPECT_EQ(true, mSimpleEvDynamicXcpPtr->mIsActive);        //Internal state check

    mWasNotifyEvDynamicSignalEmitted = false;

    mAppManagerPtr->GetDataAccessModel()->Write("XCPEngineSpeed","500", Protocol::XCPProto,mEventConfigMsg.ConfigID); //Reset the event to trigger again.
    mSimpleEvDynamicXcpPtr->Evaluate();

    mAppManagerPtr->GetDataAccessModel()->Write("XCPEngineSpeed","1000", Protocol::XCPProto,mEventConfigMsg.ConfigID); //Engine speed is equal to threshold.
    mSimpleEvDynamicXcpPtr->Evaluate();
    EXPECT_EQ(true, mWasNotifyEvDynamicSignalEmitted);   //signal emission check
    EXPECT_EQ(true, mSimpleEvDynamicXcpPtr->mIsActive);        //Internal state check
}

TEST_F(SimpleEventEvDynamicXcpTest, ParameterCompEventLess)
{
    mEventConfigMsg.Operator = "<";
    mSimpleEvDynamicXcpPtr = new SimpleEventModelEvDynamicXcp(mEventConfigMsg, mAppManagerPtr->GetEventsManagerModel(),mAppManagerPtr);
    bool isSlotConnectedToSignal = mAppManagerPtr->GetEventsManagerModel()->ConnectToSignal
    (mEventConfigMsg.EventId,boost::bind(&SimpleEventEvDynamicXcpTest::MySlot,this));
    EXPECT_EQ(true,isSlotConnectedToSignal);

    // Not active after engine speed is written to the DataAccess without meeting event threshold
    mAppManagerPtr->GetDataAccessModel()->Write("XCPEngineSpeed","2000", Protocol::XCPProto,mEventConfigMsg.ConfigID);
    mSimpleEvDynamicXcpPtr->Evaluate();
    EXPECT_EQ(false,mSimpleEvDynamicXcpPtr->mIsActive);
    EXPECT_EQ(false,mWasNotifyEvDynamicSignalEmitted);   //signal emission check

    mWasNotifyEvDynamicSignalEmitted = false;
    mAppManagerPtr->GetDataAccessModel()->Write("XCPEngineSpeed","500", Protocol::XCPProto,mEventConfigMsg.ConfigID); //Engine speed is less than thrshold.
    mSimpleEvDynamicXcpPtr->Evaluate();
    EXPECT_EQ(true,mWasNotifyEvDynamicSignalEmitted);   //signal emission check
    EXPECT_EQ(true, mSimpleEvDynamicXcpPtr->mIsActive);        //Internal state check
}

TEST_F(SimpleEventEvDynamicXcpTest, ParameterCompEventLessEqual)
{
    mEventConfigMsg.Operator = "<=";
    mSimpleEvDynamicXcpPtr = new SimpleEventModelEvDynamicXcp(mEventConfigMsg, mAppManagerPtr->GetEventsManagerModel(),mAppManagerPtr);

    bool isSlotConnectedToSignal = mAppManagerPtr->GetEventsManagerModel()->ConnectToSignal
    (mEventConfigMsg.EventId,boost::bind(&SimpleEventEvDynamicXcpTest::MySlot,this));
    EXPECT_EQ(true,isSlotConnectedToSignal);

    // Not active after engine speed is written to the DataAccess without meeting event threshold
    mAppManagerPtr->GetDataAccessModel()->Write("XCPEngineSpeed","5000", Protocol::XCPProto,mEventConfigMsg.ConfigID);
    mSimpleEvDynamicXcpPtr->Evaluate();
    EXPECT_EQ(false,mSimpleEvDynamicXcpPtr->mIsActive);
    EXPECT_EQ(false,mWasNotifyEvDynamicSignalEmitted);   //signal emission check

    mWasNotifyEvDynamicSignalEmitted = false;
    mAppManagerPtr->GetDataAccessModel()->Write("XCPEngineSpeed","200", Protocol::XCPProto,mEventConfigMsg.ConfigID);
    mSimpleEvDynamicXcpPtr->Evaluate();
    EXPECT_EQ(true,mWasNotifyEvDynamicSignalEmitted);   //signal emission check
    EXPECT_EQ(true, mSimpleEvDynamicXcpPtr->mIsActive);        //Internal state check

    mWasNotifyEvDynamicSignalEmitted = false;

    mAppManagerPtr->GetDataAccessModel()->Write("XCPEngineSpeed","5000", Protocol::XCPProto,mEventConfigMsg.ConfigID); //Reset the event to trigger again.
    mSimpleEvDynamicXcpPtr->Evaluate();

    mAppManagerPtr->GetDataAccessModel()->Write("XCPEngineSpeed","1000", Protocol::XCPProto,mEventConfigMsg.ConfigID); //Engine speed is equal to threshold.
    mSimpleEvDynamicXcpPtr->Evaluate();
    EXPECT_EQ(true,mWasNotifyEvDynamicSignalEmitted);   //signal emission check
    EXPECT_EQ(true, mSimpleEvDynamicXcpPtr->mIsActive);        //Internal state check
}

TEST_F(SimpleEventEvDynamicXcpTest, IsSameAsPrevious)
{
    mEventConfigMsg.Operator = "<>";
    mAppManagerPtr->GetDataAccessModel()->Write("XCPEngineSpeed","2000", Protocol::XCPProto,mEventConfigMsg.ConfigID);
    mSimpleEvDynamicXcpPtr = new SimpleEventModelEvDynamicXcp(mEventConfigMsg, mAppManagerPtr->GetEventsManagerModel(),mAppManagerPtr);
    bool isSlotConnectedToSignal = mAppManagerPtr->GetEventsManagerModel()->ConnectToSignal
    (mEventConfigMsg.EventId,boost::bind(&SimpleEventEvDynamicXcpTest::MySlot,this));
    EXPECT_EQ(true,isSlotConnectedToSignal);

    // Still inactive since the initial value is still the same
    mSimpleEvDynamicXcpPtr->Evaluate();
    EXPECT_EQ(false,mSimpleEvDynamicXcpPtr->mIsActive);
    EXPECT_EQ(false,mWasNotifyEvDynamicSignalEmitted);   //signal emission check

    //Should change to active
    mAppManagerPtr->GetDataAccessModel()->Write("XCPEngineSpeed","500", Protocol::XCPProto,mEventConfigMsg.ConfigID); //Engine speed is less than thrshold.
    mSimpleEvDynamicXcpPtr->Evaluate();
    EXPECT_EQ(true,mWasNotifyEvDynamicSignalEmitted);   //signal emission check
    EXPECT_EQ(true, mSimpleEvDynamicXcpPtr->mIsActive);        //Internal state check

    //Should remain active without emitting twice
    mWasNotifyEvDynamicSignalEmitted = false;
    mAppManagerPtr->GetDataAccessModel()->Write("XCPEngineSpeed","2000", Protocol::XCPProto,mEventConfigMsg.ConfigID); //Engine speed is less than thrshold.
    mSimpleEvDynamicXcpPtr->Evaluate();
    EXPECT_EQ(false,mWasNotifyEvDynamicSignalEmitted);   //signal emission check
    EXPECT_EQ(true, mSimpleEvDynamicXcpPtr->mIsActive);  //Internal state check
}


TEST_F(SimpleEventEvDynamicXcpTest, ParameterCompEventEqualWithFloatThreshold)
{
    mEventConfigMsg.Threshold = 1000.450;
    mEventConfigMsg.Operator = "==";
    mSimpleEvDynamicXcpPtr = new SimpleEventModelEvDynamicXcp(mEventConfigMsg, mAppManagerPtr->GetEventsManagerModel(),mAppManagerPtr);
    bool isSlotConnectedToSignal = mAppManagerPtr->GetEventsManagerModel()->ConnectToSignal
    (mEventConfigMsg.EventId,boost::bind(&SimpleEventEvDynamicXcpTest::MySlot,this));
    EXPECT_EQ(true,isSlotConnectedToSignal);

    // Not active after engine speed is written to the DataAccess without meeting event threshold
    mAppManagerPtr->GetDataAccessModel()->Write("XCPEngineSpeed","1000.440", Protocol::XCPProto,mEventConfigMsg.ConfigID);
    mSimpleEvDynamicXcpPtr->Evaluate();
    EXPECT_EQ(false,mSimpleEvDynamicXcpPtr->mIsActive);
    EXPECT_EQ(false,mWasNotifyEvDynamicSignalEmitted);   //signal emission check

    mWasNotifyEvDynamicSignalEmitted = false;
    mAppManagerPtr->GetDataAccessModel()->Write("XCPEngineSpeed","1000.450", Protocol::XCPProto,mEventConfigMsg.ConfigID); //Engine speed is less than thrshold.
    mSimpleEvDynamicXcpPtr->Evaluate();
    EXPECT_EQ(true,mWasNotifyEvDynamicSignalEmitted);   //signal emission check
    EXPECT_EQ(true, mSimpleEvDynamicXcpPtr->mIsActive);        //Internal state check
}

TEST_F(SimpleEventEvDynamicXcpTest, ParameterCompEventEqualWithNegativeThreshold)
{
    mEventConfigMsg.Source = "XCPEngineTorque" ;
    mEventConfigMsg.Threshold = -25;
    mEventConfigMsg.Operator = "==";
    mSimpleEvDynamicXcpPtr = new SimpleEventModelEvDynamicXcp(mEventConfigMsg, mAppManagerPtr->GetEventsManagerModel(),mAppManagerPtr);
    bool isSlotConnectedToSignal = mAppManagerPtr->GetEventsManagerModel()->ConnectToSignal
    (mEventConfigMsg.EventId,boost::bind(&SimpleEventEvDynamicXcpTest::MySlot,this));
    EXPECT_EQ(true,isSlotConnectedToSignal);

    // Not active after engine torque is written to the DataAccess without meeting event threshold
    mAppManagerPtr->GetDataAccessModel()->Write("XCPEngineTorque","-24", Protocol::XCPProto,mEventConfigMsg.ConfigID);
    mSimpleEvDynamicXcpPtr->Evaluate();
    EXPECT_EQ(false,mSimpleEvDynamicXcpPtr->mIsActive);
    EXPECT_EQ(false,mWasNotifyEvDynamicSignalEmitted);   //signal emission check

    mWasNotifyEvDynamicSignalEmitted = false;
    mAppManagerPtr->GetDataAccessModel()->Write("XCPEngineTorque","-25", Protocol::XCPProto,mEventConfigMsg.ConfigID); //Engine speed is less than thrshold.
    mSimpleEvDynamicXcpPtr->Evaluate();
    EXPECT_EQ(true,mWasNotifyEvDynamicSignalEmitted);   //signal emission check
    EXPECT_EQ(true, mSimpleEvDynamicXcpPtr->mIsActive);        //Internal state check
}
