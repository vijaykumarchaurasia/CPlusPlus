#include <memory>
#include "gtest/gtest.h"
#include "JsonParserModel.h"

using namespace DaqApp;

class JsonParserModelTest : public testing::Test
{
protected:
    std::unique_ptr<JsonParserModel> mJsonParserPtr;

	void SetUp() override
	{
        mJsonParserPtr = std::make_unique<JsonParserModel>();
	}

	void TearDown() override {	}
};

//----------------------------Actual Test Cases------------------------------

TEST_F(JsonParserModelTest, validate_json_file)
{
    Json::Value parsed_val =  mJsonParserPtr->ParseJsonFile("../test/Test_Configuration_temp.json");
    EXPECT_EQ(parsed_val.null,parsed_val) << "If the file is not present in the directory" << std::endl;

    parsed_val =  mJsonParserPtr->ParseJsonFile("../test/Test_Configuration.txt");
    EXPECT_EQ(parsed_val.null,parsed_val) << "File should not be parsed except .json file" << std::endl;

    parsed_val =  mJsonParserPtr->ParseJsonFile("../test/Test_Configuration.json");
    EXPECT_NE(parsed_val.null,parsed_val);
}