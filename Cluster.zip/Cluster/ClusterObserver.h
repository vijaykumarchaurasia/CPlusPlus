#pragma once
#include <ecu/com/observer.h>
#include <ecu/config.h>
#include <ecu/com/client.h>
#include <ecu/logging.h>
#include <ecu/com/backend.h>
#include <ecu/logging.h>   
#include <ecu/com/backend_messageadapter.h>

using namespace ecu::lapi::com;

class ClusterObserver :public ISubscriptionObserver
{
    public:
        void message (const std::string& topic, const Message& message);
        //TODO correct topics
        static constexpr const char* TOPIC_Start_Info = "rt/???/startinfo";
        static constexpr const char* TOPIC_Start_Query = "rt/???/startquery";
        static constexpr const char* TOPIC_Cancel_Session = "rt/???/cancel";
        static constexpr const char* TOPIC_Session_Status = "rt/???/status";
        ClusterObserver() {}
        ~ClusterObserver() {}
}