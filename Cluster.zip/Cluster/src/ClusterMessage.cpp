#include <string.h>

using namespace ecu::lapi;
using namespace ecu::lapi::diag;
using namespace ecu::lapi::com;

#define SESSION_START_PAGE_NUM 16
#define REPLY_PAGE_NUM 17
#define STATUS_PAGE_NUM 18

int page;
int counter;
int reply_opt_count;
int screen_time;
int cancel_reply_opt;

std::string msg;
std::string opts;

std::string msg_type;

ClusterMessage(uint8_t* data){
    page = data[0];
}