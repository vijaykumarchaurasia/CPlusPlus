#ifndef IQSESSION_H
#define IQSESSION_H

#include <stdio.h>
#include <string.h>

using namespace std;

class IQSession
{
    public:

        IQSession(int sessionId, string sessionType);
        IQSession(int sessionId, string sessionType, bool running);

        int getSessionId();
        string getSessionType();
        bool isRunning();

        void setSessionRunning(bool running);

    private:

        int sessionId;
        bool running;
        string sessionType;
};

#endif