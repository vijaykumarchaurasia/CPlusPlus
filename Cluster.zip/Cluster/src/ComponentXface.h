/*
 * ComponentXface.h
 *
 *  Created on: Jan 9, 2019
 *      Author: poo
 */

#ifndef SRC_COMPONENTXFACE_H_
#define SRC_COMPONENTXFACE_H_

#include <ecu/com/client.h>

#include <string>
#include <condition_variable>
#include <mutex>
#include <atomic>
#include <vector>

using namespace ecu::lapi;

class ComponentXface :
   public com::ISubscriptionObserver
{
public:
	ComponentXface(com::ITransportClient_ptr tclient,
         const std::string& snd_topic,
         const std::string& rcv_topic) :
      m_tclient(tclient),
      m_snd_topic(snd_topic),
      m_rcv_topic(rcv_topic)
   { }
   virtual ~ComponentXface() { }

   bool sndMessage(uint8_t *data, int size);
   std::vector<uint8_t> waitForMessage(int timeout);
   std::vector<uint8_t> rcvMessage();
   void message(const std::string&, const com::Message&) override;
   void end();
   com::Message::DataBuffer getDataBuffer(uint8_t *, int);
   std::vector<uint8_t> rcvMsg;
   void updateTopics(const std::string& snd_topic, const std::string& rcv_topic);
   std::string getSendTopic();
   std::string getRcvTopic();

private:
   com::ITransportClient_ptr m_tclient;

   std::mutex m_send_mtx;
   std::condition_variable m_rcv_cv;

   std::string m_snd_topic;
   std::string m_rcv_topic;
};

#endif /* SRC_COMPONENTXFACE_H_ */
