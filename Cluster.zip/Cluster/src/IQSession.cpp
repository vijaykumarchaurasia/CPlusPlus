#include IQSession.h

IQSession::IQSession(int sessionId, string sessionType){
    this->sessionId = sessionId;
    this->sessionType = sessionType;
    this->running = false;
}

IQSession::IQSession(int sessionId, string sessionType, bool running){
    this->sessionId = sessionId;
    this->sessionType = sessionType;
    this->running = running;
}

int IQSession::getSessionId(){
    return sessionId;
}

string IQSession::getSessionType(){
    return sessionType;
}

bool IQSession::isRunning(){
    return running;
}

void IQSession::setSessionRunning(bool running){
    this->running = running;
}