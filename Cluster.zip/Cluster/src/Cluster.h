#ifndef SRC_CLUSTER_H_
#define SRC_CLUSTER_H_

#include <ecu/com/messageadapter.h>
#include <ecu/com/observer.h>
#include <ecu/com/client.h>
#include <ecu/pb/ecu.pb.h>
#include <iostream>
#include <string.h>

using namespace std;
using namespace ecu::lapi;
using namespace ecu::lapi::com;

class Cluster:public ISubscriptionObserver{

    public:
        Cluster(){}
        virtual ~Cluster(){}

        static constexpr const char* TOPIC_CLUSTER = "ota/app/cluster";
        void message(const std::string& topic, const Message& message);
        int getValueI(vector <uint8_t> sig_data);

        static constexpr const char* configFileDir = "/common/configuration";
        static constexpr const char* m_vehicle_configuration_file = "otaConfig.txt";
    
    private:
        
};

#endif
