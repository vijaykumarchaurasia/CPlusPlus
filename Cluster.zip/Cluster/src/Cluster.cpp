#include "Cluster.h"

#include <thread>
#include <string.h>
#include <mosquitto.h>
#include <stdlib.h>

#include "ComponentXface.h"
#include <ecu/config.h>
#include <ecu/com/client.h>
#include <ecu/diag/uds.h>
#include <ecu/logging.h>
#include <ecu/com/observer.h>
#include <ecu/rt/signaladapter.h>
#include <unistd.h>
#include <fstream>

using namespace ecu::lapi;
using namespace ecu::lapi::logging;

#define ERR_INVALID_NUM_REPLY_OPTS 1
#define ERR_INVALID_MSG_CHARS 2
#define ERR_INVALID_REPLY_OPT_CHARS 3
#define ERR_SESSION_ALREADY_IN_PROGRESS 4
#define ERR_CLUSTER_STATUS_NOT_RECEIVED 5
#define ERR_UNKNOWN 6

#define SESSION_START_PAGE_NUM 16
#define REPLY_PAGE_NUM 17
#define STATUS_PAGE_NUM 18

static constexpr const char* TOPIC_CLUSTER_TO_OTA = "app/cluster/ota";
static constexpr const char* TOPIC_OTA_TO_CLUSTER = "app/ota/cluster";
static constexpr const char* TOPIC_CURRENT_MODE = "rt/system/current_n2_operating_mode";
static constexpr const char* TOPIC_SER_SEND_TOPIC = "rt/sercan/prop_a_cluster_tx_4a";
static constexpr const char* TOPIC_TEL_SEND_TOPIC = "rt/telcan/prop_a_cluster_tx_4a";
static constexpr const char* TOPIC_SER_RCV_TOPIC = "rt/sercan/prop_a_cluster_rx_4a";
static constexpr const char* TOPIC_TEL_RCV_TOPIC = "rt/telcan/prop_a_cluster_rx_4a";
static const char* STATE_INFO = "info";
static const char* STATE_QUERY = "query";
static const char* STATE_ERROR = "error";
static const char* STATE_NONE = "idle";
static const char* TYPE_BASE = "base";
static const char* TYPE_PREMIUM = "premium";
static const char* TYPE_UNKNOWN = "unknown";

ComponentXface *uiXface;
com::ITransportClient_ptr intClient;
com::ITransportClient_ptr clusterIntClient;

thread *sessionThread;

uint8_t current_id = 0;
const char* current_session_type = STATE_NONE;
const char* cluster_type = TYPE_UNKNOWN;
bool running = false;
bool stop = false;

bool createTransportClient() {
    config::Configuration_ptr cfg(new config::Configuration());
    cfg->set("client_name", "CLUSTER_A");

    config::Configuration_ptr cfg_b(new config::Configuration());
    cfg_b->set("client_name", "CLUSTER_B");

    if (!cfg->verify() || !cfg_b->verify()){
        logging::ERROR << "Configuration verification failed!" << endl;
        return false;
    }

    intClient = com::create_client(cfg);
    intClient->connect();
    intClient->start();

    clusterIntClient = com::create_client(cfg_b);
    clusterIntClient->connect();
    clusterIntClient->start();

    return true;
}

void disconnectTransportClient(){
    clusterIntClient->disconnect();
    clusterIntClient->join();

    logging::DEBUG << "Disconnected from transport client." << endl;
}

com::Message::DataBuffer getDataBuffer(uint8_t *data, int size){
    com::Message::DataBuffer dataBuf;

    copy(&data[0], &data[size], back_inserter(dataBuf));

    return dataBuf;
}

void sendToOTA(uint8_t* body, int len){
    com::Message message;
    message.set_buffer(getDataBuffer(body, len));
    if (intClient->publish(TOPIC_CLUSTER_TO_OTA, message) > 0){
        //success
    } else {
        //fail
        logging::DEBUG << "Failed to send message: " << body << endl;
    }
}

//void sendOTA(const char* msg, int len){
//    char message[len];
//    strcpy(message, msg);
//    message[strlen(message)] = '\0';
//    sendOTA(message, len);
//}

void endSession(){
    stop = true;
    running = false;
    current_session_type = STATE_NONE;
    uiXface->end();
    logging::INFO << "Session ended." << endl;
}

void cancelSession(){
	if(running){
		logging::INFO << "Cancelling session." << endl;
        endSession();
		uint8_t* body = new uint8_t[2];
		body[0] = STATUS_PAGE_NUM;
		body[1] = 0x10 | (current_id & 0xF);
		uiXface->sndMessage(body, 2);
	}else{
        logging::DEBUG << "Can't cancel session, none active." << endl;
	}
}

void sendSessionStatus(int err){
    char msg[500];
    const char* type = err > 0 ? STATE_ERROR : current_session_type;
    int id = (strcasecmp(current_session_type, STATE_NONE) == 0) ? -1 : current_id;
    sprintf(msg, "clusterSessionStatus,%s,%d,%d,%s", type, id, err, "None");
    if (strcasecmp(type, STATE_ERROR) == 0){
        logging::INFO << "send msg ERROR: " << msg << endl;
    }
    sendToOTA((uint8_t *)msg, strlen(msg));
}

void sendSessionStatus(int err, char* errMsg){
    char msg[500];
    sprintf(msg, "clusterSessionStatus,%s,%d,%d,%s", STATE_ERROR, current_id, err, errMsg);
    logging::INFO << "send msg ERROR: " << msg << endl;
    sendToOTA((uint8_t *)msg, strlen(msg));
}

void sendQueryReply(int reply){
    char msg[500];
    sprintf(msg, "queryReply,%d", reply);
    sendToOTA((uint8_t *)msg, strlen(msg));
}

void sendKeepAlive(){

    uint8_t* body = new uint8_t[2];
    body[0] = STATUS_PAGE_NUM;
    body[1] = current_id & 0xF;
    uiXface->sndMessage(body, 2);
}

void sendClusterType(){
    logging::DEBUG << "Handling request for cluster type." << endl;
    char msg[100];

    //only request type if type is unknown
    if (strcasecmp(cluster_type, TYPE_UNKNOWN) == 0){
        config::Configuration_ptr cfg(new config::Configuration());
        cfg->set("client_name", "CLUSTER_UDS");

        if (!cfg->verify()){
            logging::DEBUG << "Configuration verification failed (UDS client)!" << endl;
            return;
        }

        com::ITransportClient_ptr tClient = com::create_client(cfg);
        tClient->connect();
        tClient->start();

        auto udsClient = diag::create_uds_client(tClient);

        diag::UdsInterfaceAllocationConfig alloc_config{
        	diag::UdsInterfaceAllocationConfig::UDS_TRANSPORT_PROTOCOL_ISO,
			diag::UdsInterfaceAllocationConfig::UDS_INTERFACE_CAN1,
			0x17
        };

        auto result = udsClient->allocate_interface(alloc_config);
        if (result != diag::UdsInterfaceState::UDS_IF_STATE_READY){
            //error
            logging::DEBUG << "UDS not ready: " << result << endl;
        } else {
            logging::INFO << "Created UDS client." << endl;

            diag::UdsMessage request;
            request.address = 0x17;
            request.data = {0x22, 0xF1, 0x94};

            auto response = udsClient->send_request(request, 3000);
            if (response.nok()){
                logging::DEBUG << "No response from UDS client." << endl;
            } else {
                auto data = response.take_val();
                char type = data.data[8];
                logging::DEBUG << "cluster type: " << type << endl;
                //TODO 9th char should be H if cluster is premium
                cluster_type = type == 'B' ? TYPE_BASE : TYPE_PREMIUM;
                sprintf(msg, "getClusterType,%s", type == 'B' ? TYPE_BASE : TYPE_PREMIUM);
            }
        }
        bool release = udsClient->release_interface();
        logging::DEBUG << "Released UDS client interface: " << release << endl;
        udsClient = NULL;
        tClient->disconnect();
    }

    sprintf(msg, "clusterType,%s", cluster_type);
    logging::DEBUG << msg << endl;
    sendToOTA((uint8_t *)msg, strlen(msg));
}

void runSession(int r_id, char* body, int length, bool replace){
    logging::DEBUG << "Begin session [" << r_id << "]..." << endl;
    int missed = 0;
    int total = 0;
    while(running && current_id == r_id){
        std::vector<uint8_t> resp = uiXface->waitForMessage(replace ? 350 : 580);
        if (!running){
            break;
        }
        if (resp.size() == 0){
            if (replace){
                logging::DEBUG << "Sending session start message." << endl;
                uiXface->sndMessage((uint8_t*)body, length);
                replace = false;
            } else {
                missed++;
                logging::DEBUG << "Missed stat message from cluster [" << r_id << "]." << endl;
                if (missed > 4){
                    logging::INFO << "Missed 4 consecutive messages from cluster[" << r_id << "]. [1st rcvd " << total << "]" << endl;
                    sendSessionStatus(ERR_CLUSTER_STATUS_NOT_RECEIVED);
                    endSession();
                    break;
                } else {
                    sendKeepAlive();
                }
            }
        } else {
            missed = 0;
            total++;
            if (resp[0] != REPLY_PAGE_NUM){
                logging::DEBUG << "Unexpected response number: " << resp[0] << endl;
            } else if ((resp[1] & 0x0F) != r_id){
                logging::DEBUG << "Unexpected session id: " << (resp[1] & 0x0F) << endl;
                //break;
            }else if ((resp[1] & 0xF0) == 0){
                //printf("continue... %d\n", resp[1]);
            } else if(strcasecmp(current_session_type, STATE_INFO) == 0) {
                logging::INFO << "End of info session." << endl;
                endSession();
                break;
            } else if(strcasecmp(current_session_type, STATE_QUERY) == 0){
                logging::INFO << "End of query session, reply: " << ((resp[1] & 0xF0)>>4) << endl;
                sendQueryReply((resp[1] & 0xF0)>>4);
                endSession();
                break;
            }
            sendKeepAlive();
        }
    }
    stop = false;
    logging::DEBUG << "End session [" << r_id << "]" << endl;
}

//0 if message valid
//value of invalid char otherwise
//invalid chars are:
//  control characters 1-31 and 127
//  exception for 9 (Tab) and 13 (CR)
char validateMessage(const char* msg){
    int i = 0;
    char c = msg[0];
    while (c != '\0'){
        if (c == 127 || ((c <= 31 && c >= 1) && c != 9 && c != 13)){
            logging::INFO << "INVALID CHAR: " << c << endl;
            return c;
        }
        c = msg[++i];
    }

    return 0;
}

void copyMsg(char* target, char* str, int start){
    for (int i = 0; i < (int)strlen(str); i++){
        target[start + i] = str[i];
    }
}

char* bytesToStr(char* bytes, int length){
    char* msg = new char[length * 3 + 1];
    for (int i = 0; i < length; i++){
        sprintf(msg + i*3, "%02x ", bytes[i]);
    }
    msg[length * 3 - 1] = '\0';
    return msg;
}

void startSession(const char* type, char* command){
    logging::DEBUG << "Start session: [" << type << "] " << command << endl;

    //currently need delay before sending, so always set replace to true
    //may be fixed in future Cluster release
    bool replace = true;
    if (running){
        if (strcasecmp(STATE_INFO, current_session_type) == 0){
            //allow override of info messages
            logging::DEBUG << "Info session in progress, overriding." << endl;
            cancelSession();
            //endSession();
            replace = true;
        } else {
            logging::INFO << "Cannot start new session, query session in progress." << endl;
            sendSessionStatus(ERR_SESSION_ALREADY_IN_PROGRESS);
            return;
        }
    }

    current_id += 1;
    if (current_id == 16){
        current_id = 0;
    }
    current_session_type = type;


    if (strcasecmp(type, STATE_INFO) == 0){
        strtok(command, ",");
        char* msg = strtok(NULL, ",");
        const char* time = strtok(NULL, ",");

        //replace / with \r
        char * c = strchr(msg, '/');
        while (c != NULL){
        	c[0] = '\r';
        	c = strchr(c+1, '/');
        }

        int t = atoi(time);
        t = t < 3 ? 3 : (t > 48 ? 48 : t);
        t = (t / 3) - 1;

        int valid = validateMessage(msg);
        if (valid != 0){
            char err[100];
            logging::DEBUG << "Invalid char: " << valid << endl;
            sendSessionStatus(ERR_INVALID_MSG_CHARS, err);
            return;
        }

        int length = 4 + strlen(msg);
        char* body = new char[length + 1];
        body[0] = SESSION_START_PAGE_NUM;
        body[1] = (current_id & 0xF);
        body[2] = (t & 0xF);
        copyMsg(body, (char*)msg, 3);

        body[length-1] = '\t';
        body[length] = '\0';

        if (strcasecmp("DEBUG", logging::get_log_level_name()) == 0){
            char* log_msg = bytesToStr(body, length);
            logging::DEBUG << "BODY: [" << log_msg << "]" << endl;
        }

        //uiXface->sndMessage((uint8_t*)body, length);
        if (!replace){
            uiXface->sndMessage((uint8_t*)body, length);
        }
        running = true;
        sessionThread = new thread(runSession, current_id, body, length, replace);
    } else if (strcasecmp(type, STATE_QUERY) == 0){
        strtok(command, ",");
        char* msg = strtok(NULL, ",");
        char* opts = strtok(NULL, ",");
        
        //replace / with \r in message
        char * m = strchr(msg, '/');
        while (m != NULL){
        	m[0] = '\r';
        	m = strchr(m+1, '/');
        }

        //replace / with \t in options
        char * c = strchr(opts, '/');
        while (c != NULL){
            c[0] = '\t';
            c = strchr(c+1, '/');
        }

        const char* cancelOpt = strtok(NULL, ",");

        int optCount = 1;
        for (int i = 0; i < (int)strlen(opts); i++){
            if (opts[i] == '\t'){
                optCount++;
            }
        }

        int cancel = 0;
        if (cancelOpt != NULL){
            cancel = atoi(cancelOpt);
        }

        int valid = validateMessage(msg);
        if (valid != 0){
            char err[100];
            logging::DEBUG << "Invalid char: " << valid << endl;
            sprintf(err, "Invalid char: %c", valid);
            sendSessionStatus(ERR_INVALID_MSG_CHARS, err);
            return;
        }
        valid = validateMessage(opts);
        if (valid != 0){
            char err[100];
            logging::DEBUG << "Invalid char: " << valid << endl;
            sprintf(err, "Invalid char: %c", valid);
            sendSessionStatus(ERR_INVALID_REPLY_OPT_CHARS, err);
            return;
        }

        int length = 5 + strlen(msg) + strlen(opts);
        char* body = new char[length + 1];
        body[0] = SESSION_START_PAGE_NUM;
        body[1] = (current_id & 0xF) | (optCount << 4);
        body[2] = cancel << 4;
        //copy msg, opts
        copyMsg(body, (char*)msg, 3);
        body[3 + strlen(msg)] = '\t';

        copyMsg(body, (char*)opts, 4 + strlen(msg));
        body[length - 1] = '\t';
        body[length] = '\0';

        if (strcasecmp("DEBUG", logging::get_log_level_name()) == 0){
            char* log_msg = bytesToStr(body, length);
            logging::DEBUG << "BODY: [" << log_msg << "]" << endl;
        }

        if (!replace){
            uiXface->sndMessage((uint8_t*)body, length);
        }
        running = true;
        sessionThread = new thread(runSession, current_id, body, length, replace);
    }

    //running = true;
    //sessionThread = new thread(runSession, current_id, body, length);
}

int main(int argc, char* argv[]){
    //logging::set_log_mode(ecu::lapi::logging::STDOUT);
    logging::enable("lapi.rt.signaladapter");
    //logging::set_log_level("DEBUG");

	string recorderString = "";
	string file = Cluster::configFileDir;
	file.append("/");
	file.append(Cluster::m_vehicle_configuration_file);
	std::ifstream inputStream(file);
	string line;
	string recState;
	bool foundAttr = false;
	while (std::getline(inputStream, line)) {
		recState = line.c_str();
		if(recState.rfind("logLevel", 0) == 0){
			foundAttr = true;
			break;
		}
	}
	std::stringstream ss(recState);
	std::string attribute;
	std::vector<std::string> attributes;
	if(foundAttr){
		while (std::getline(ss, attribute, '=')) {
			attributes.push_back(attribute);
		}
		int count = 0;
		for (string att : attributes) {
			count++;
			if (count == 2) {
				recorderString = att;
			}
		}
	}
	long logLevel = 4; //By default it should be 4 which signifies WARNING
	if(strcasecmp(recorderString.c_str(),"")!=0){
		logLevel = stol(recorderString);
	}
	logging::set_log_level(logLevel);

	logging::DEBUG<< "Log level is:" << logLevel << endl;
	
    logging::INFO << "Starting Cluster component. (5/6)" << std::endl;

    if (!createTransportClient()){
        logging::DEBUG << "Failed to create transport client." << endl;
        return 0;
    }
    
    uiXface = new ComponentXface(clusterIntClient, "rt/telcan/prop_a_cluster_tx_4a", "rt/telcan/prop_a_cluster_rx_4a");

    Message message;
    com::ISubscriptionObserver_ptr observer(new Cluster());
    vector<std::string> topics;
    char buf[1000] = {'\0'};

    sprintf(buf, TOPIC_CURRENT_MODE); //current mode of N2- service tool or telematics
    topics.push_back (buf);

    sprintf(buf, TOPIC_OTA_TO_CLUSTER); //current mode of N2- service tool or telematics
    topics.push_back (buf);

    intClient->subscribe_and_announce(topics, 0, observer, message);

    logging::INFO << "Subscribed: " << TOPIC_CURRENT_MODE << endl;
    logging::INFO << "Subscribed: " << TOPIC_OTA_TO_CLUSTER << endl;

    //get cluster type at program start
    sendClusterType();
    //std::chrono::seconds t(2);
    //while(true){
    //    std::this_thread::sleep_for(t);
    //}

    intClient->join();

    disconnectTransportClient();

    return 0;
}

void Cluster::message(const std::string& topic, const com::Message& message)
{
	logging::INFO << "msg: " << topic << endl;

	if(topic.compare(TOPIC_OTA_TO_CLUSTER)==0){
		std::string result;
		result.assign(message.get_buffer().begin(), message.get_buffer().end());
        logging::INFO << "MSG: " << result << endl;

		int count = 0;
		for (const char* p = result.c_str(); *p; ++p){
			if (*p == ','){
				count++;
			}
		}
		if (result.find("startInfoSession") == 0){
			if (count < 2){
                logging::DEBUG << "Not enough params for startInfoSession: " << count << endl;
				sendSessionStatus(ERR_UNKNOWN, (char*)"startInfoSession requires 3 params.");
				return;
			}
			startSession(STATE_INFO, (char*)result.c_str());
		} else if (result.find("startQuerySession") == 0){
			if (count < 2){
                logging::DEBUG << "Not enough params for startQuerySession: " << count << endl;
				sendSessionStatus(ERR_UNKNOWN, (char*)"startQuerySession requires 3 params.");
				return;
			}
			startSession(STATE_QUERY, (char*)result.c_str());
		} else if (result.find("getSessionStatus") == 0){
			sendSessionStatus(0);
		} else if (result.find("getClusterType") == 0){
			sendClusterType();
		} else if (result.find("cancelSession") == 0){
            logging::DEBUG << "Received cancelSession message." << endl;
			cancelSession();
		} else {
            logging::DEBUG << "Unexpected command." << endl;
		}
	}else if(topic.compare(TOPIC_CURRENT_MODE)==0){
		auto unpack = rt::SignalAdapter::instance().unpack(topic, message);
		if (unpack.nok())
		{
            logging::DEBUG << "Unpacking of SignalGroup from topic: " << topic << " failed" << endl;
			return;
		}
		auto signal_grp = unpack.take_val();
        auto signal = signal_grp.signal("current_n2_operating_mode");
			if (signal->is_enum()){
                auto sig_data = signal->data();
                int val = 0;
                for (unsigned int i = 0; i < sig_data.size(); i++){
                    val = val | (sig_data[i] << 8*i);
                }
                logging::DEBUG << "Current N2 mode: " << val << endl;
				if(val == 0){
					//telematics mode
					if(uiXface->getSendTopic().compare(TOPIC_TEL_SEND_TOPIC)!=0 || uiXface->getRcvTopic().compare(TOPIC_TEL_RCV_TOPIC)!=0){
                        logging::DEBUG << "Use telematics mode topics." << endl;
						uiXface -> updateTopics(TOPIC_TEL_SEND_TOPIC,TOPIC_TEL_RCV_TOPIC);
					}
				}else if(val == 1){
					//service tool mode
					if(uiXface->getSendTopic().compare(TOPIC_SER_SEND_TOPIC)!=0 || uiXface->getRcvTopic().compare(TOPIC_SER_RCV_TOPIC)!=0){
						logging::DEBUG << "Use service tool mode topics." << endl;
						uiXface -> updateTopics(TOPIC_SER_SEND_TOPIC,TOPIC_SER_RCV_TOPIC);
					}
				} else {
                    logging::DEBUG << "Unexpected N2 operating mode!" << endl;
                }
			} else {
                logging::DEBUG << "Expected current_n2_operating_mode to be enum value." << endl;
            }
	}
}


