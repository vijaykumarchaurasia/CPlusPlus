/*
 * ComponentXface.cpp
 *
 *  Created on: Jan 9, 2019
 *      Author: poo
 */

#include "ComponentXface.h"
#include <ecu/rt/signaladapter.h>

using namespace ecu::lapi;
using namespace ecu::lapi::rt;

//------------------------------------------------------------------------------

namespace
{
   class SubscriptionWrapper :
      public com::ISubscriptionObserver
   {
      public:
         explicit SubscriptionWrapper(ISubscriptionObserver* r) :
            m_real(r)
      {}

         void message(
               const std::string& topic,
               const com::Message& message) override
         {
            if ( !m_real ) return;
            m_real->message(topic, message);
         }

      private:
         ecu::lapi::com::ISubscriptionObserver* m_real = nullptr;
   };
}

//------------------------------------------------------------------------------

bool ComponentXface::sndMessage(uint8_t *data, int size) {

   if (!m_tclient){
      printf("Error! client invalid.\n");
      return false;
   }

   auto& signal_adapter = rt::SignalAdapter::instance();
   auto sg_create_result = signal_adapter.create_sg(m_snd_topic.c_str());
   if (sg_create_result.nok()){
      //error
      printf("Unable to create SignalGroup for topic: %s\n", m_snd_topic.c_str());
      return (false);
   }
   auto signal_group = sg_create_result.take_val();

   Signal::DATA dataCopy{};
   std::copy(&data[0], &data[size], std::back_inserter(dataCopy));
   if (!signal_group.set_signal_data("data", dataCopy)){
      printf("Failed to set data!\n");
   }

   char bytes[2];
   bytes[0] = (size&0xFF);
   bytes[1] = (size>>8 & 0xFF);
   
   Signal::DATA nof_bytes;
   std::copy(&bytes[0], &bytes[2], std::back_inserter(nof_bytes));
   if (!signal_group.set_signal_data("nof_bytes", nof_bytes)){
      printf("Failed to set nof_bytes!\n");
   }

  Signal::DATA dest_address{0x17};
   //printf("da[0x%x]\n", dest_address[0]);
  if (!signal_group.set_signal_data("j1939_destination_address", dest_address)){
      printf("Failed to set DA!\n");
   }

   auto pack_result = signal_adapter.pack(signal_group);
   if (pack_result.nok()){
      printf("Packing failed: [%d] [%s]\n", pack_result.err_val().code, pack_result.err_val().details.c_str());
      return false;
   }

   auto message = pack_result.take_val();

   //std::unique_lock<decltype(m_send_mtx)> lock(m_send_mtx);
   if (m_tclient->publish(m_snd_topic.c_str(), message) > 0){
      //printf("Successfully sent msg '%s'.\n", m_snd_topic.c_str());
      return (true);
   } else {
      printf("Failed to send '%s'.\n", m_snd_topic.c_str());
      return (false);
   }
}

com::Message::DataBuffer ComponentXface::getDataBuffer(uint8_t *data, int size) {
	com::Message::DataBuffer dataBuf;

	copy(&data[0], &data[size], back_inserter(dataBuf));

	return dataBuf;
}

std::vector<uint8_t> ComponentXface:: rcvMessage() {
	auto subwrap = std::make_shared<SubscriptionWrapper>(this);
	m_tclient->subscribe(m_rcv_topic, 1, subwrap);

	rcvMsg.clear();
	std::unique_lock<decltype(m_send_mtx)> lock(m_send_mtx);
	m_rcv_cv.wait(lock);

	m_tclient->unsubscribe(m_rcv_topic, subwrap);

	return(rcvMsg);
}

std::vector<uint8_t> ComponentXface::waitForMessage(int timeout) {
   //m_rcv_topic can change while we wait
   std::string rcv_topic = m_rcv_topic;
  
   auto subwrap = std::make_shared<SubscriptionWrapper>(this);
   m_tclient->subscribe(rcv_topic, 1, subwrap);

   rcvMsg.clear();

   std::chrono::milliseconds ms(timeout);

   std::unique_lock<decltype(m_send_mtx)> lock(m_send_mtx);
   std::cv_status status=m_rcv_cv.wait_for(lock, ms);

   m_tclient->unsubscribe(rcv_topic, subwrap);

   if (status == std::cv_status::timeout)
	   rcvMsg.clear();

   return(rcvMsg);
}

void ComponentXface::end(){
   printf("end wait.\n");
   m_rcv_cv.notify_all();
}

//------------------------------------------------------------------------------
void ComponentXface::message(const std::string& topic, const com::Message& msg) {
   if ( topic != m_rcv_topic )
      throw std::runtime_error(
            "Unexpected message on topic received: " + topic);

   //std::unique_lock<decltype(m_send_mtx)> lock(m_send_mtx);

   auto& signal_adapter = rt::SignalAdapter::instance();
   auto unpack_result = signal_adapter.unpack(topic, msg);
   if (unpack_result.nok()){
      printf("Unpack failed.\n");

   }
   auto sig_group = unpack_result.take_val();

   auto sig = sig_group.signal("data");
   auto sig_data = sig->data();

   copy(&sig_data[0], &sig_data[2], back_inserter(rcvMsg));
   //printf("RCV DATA: %02x %02x\n", rcvMsg[0], rcvMsg[1]);

#if 0
   printf("rcvMessage: Got message..\n");
#endif

   m_rcv_cv.notify_all();
}

void ComponentXface::updateTopics(const std::string& snd_topic, const std::string& rcv_topic){
	m_snd_topic = snd_topic;
	m_rcv_topic = rcv_topic;
}

std::string ComponentXface::getSendTopic(){
	return m_snd_topic;
}

std::string ComponentXface::getRcvTopic(){
	return m_rcv_topic;
}

