//from Cluster DRD

//PGN       0x1EF00
//message contents vary based on page #:
//          16: IQ Session Start
//          17: IQ Cluster Status
//          18: IQ Requestor Status

//0-7       Page #
//          16: IQ Session Start
//8-11      msg counter
//12-15     # of reply opts
//16-19     info display time
//          value: 0-15
//          cluster displays info msg for (value + 1) * 3 seconds
//20-23     cancel reply opt #
//          only applies to premium clusters
//24...     msg strings
//          UTF-8 chars
//          CR (13): new line char
//          Tab (9): eo-string char
//          1st string is infoString or queryString
//          up to 15 reply option strings

//0-7       Page #
//          17: IQ Cluster Status
//8-11      msg counter
//12-15     reply data
//          Info sessions:
//          0:      msg still displaying
//          1:      done
//          Query sessions:
//          0:      cluster still waiting for user response
//          1-15:   selected option

//0-7       Page #
//          18: IQ Requestor Status
//8-11      msg counter
//12        session cancel flag
//          0: no change   1: cancel

#include "ClusterObserver.h"
#include <ecu/com/messageadapter.h>
#include <ecu/com/observer.h>
#include <ecu/logging.h>
#include <cluster.pb.h>
#include <iostream>
#include "Constants.h" 
#include "TriggerEvent.h" 

using namespace std;

using namespace ecu::lapi; 
using namespace ecu::lapi::com;

#define SESSION_START_PAGE_NUM 16
#define REPLY_PAGE_NUM 17
#define STATUS_PAGE_NUM 18
#define PGN_CLUSTER_MSG 0x1EF00;

byte curr_id = 0;
bool session_running = false;
string session_type = "";

thread *thr;

int main(int argc, char *argv[])
{
    printf("ClusterObserver starting.\n");


    return 0;
}

void run(){
    while(session_running){
        send_keep_alive(curr_id);
        Sleep(500);
    }
}

void ClusterObserver::message (const std::string& topic, const Message& message)
{
    if (topic != TOPIC_Start_Info && topic != TOPIC_Start_Query && topic != TOPIC_Cancel_Session && topic != TOPIC_Session_Status){
        logging::INFO << "Unexpected reception of message on topic: "<< topic << std::endl;
      return;
    }

    if (topic == TOPIC_Start_Info){
        if (session_running){
            //fail or cancel current session?
            return;
        }

        com::PbInternalMessageAdapter<pb::Cluster> adapter;

        auto result = adapter.deserialize(message);
        if ( result.nok() )
        {
            logging::ERROR << "Unable to deserialize!" << std::endl;
            return;
        }
        auto info = result.take_val();
        session_running = true;

        //TODO vary size based on message
        byte[] body = new byte[4];
        body[0] = SESSION_START_PAGE_NUM;
        curr_id++;
        body[1] = curr_id << 4;
        body[2] = ((info.display_time / 3) - 1) << 4;//TODO check value within range
        //body[3]... = info.message in bytes

        //send display message
        //start run() thread
    } else if (topic == TOPIC_Start_Query){
        if (session_running){
            //fail or cancel current session?
            return;
        }

        com::PbInternalMessageAdapter<pb::Cluster> adapter;

        auto result = adapter.deserialize(message);
        if ( result.nok() )
        {
            logging::ERROR << "Unable to deserialize!" << std::endl;
            return;
        }

        auto query = result.take_val();

        int opt_count = 1;//TODO count options

        //TODO vary size based on message
        byte[] body = new byte[4];
        body[0] = SESSION_START_PAGE_NUM;
        curr_id++;
        body[1] = curr_id << 4 | opt_count;
        body[2] = query.cancel_option;
        //body[3]... = info.message + info.options in bytes

        //send display message
        session_running = true;
        thr = new thread(&run);

    } else if (topic == TOPIC_Cancel_Session){
        cancel(curr_id);
    } else if (topic == TOPIC_Session_Status){
        send_status();
    } else {
        logging::INFO << "Unexpected reception of message on topic: "<< topic << std::endl;
      return;
    }
}

//!
void cancel(byte msg_id){
    printf("CANCEL msg");

    session_running = false;
    byte[] body = new byte[2];
    body[0] = STATUS_PAGE_NUM;
    body[1] = msg_id << 4 | 0x1;
    //TODO send cancel session
}

//!
void send_keep_alive(byte msg_id){
    byte[] body = new byte[2];
    body[0] = STATUS_PAGE_NUM;
    body[1] = msg_id << 4;

    //TODO send
}

//!
void send_status(){
    printf("send status");
    clusterSessionStatus status = new clusterSessionStatus();
    if (session_running){
        status.set_session_type(session_type == "INFO" ? SessionType.INFO : SessionType.QUERY);
        status.set_session_id(curr_id);
    } else {
        status.set_session_type(SessionType.NONE);
        status.set_session_id(-1);
    }
    //send clusterSessionStatus message to OTA
}

void process_response(byte[] body){
    //TODO
}

}