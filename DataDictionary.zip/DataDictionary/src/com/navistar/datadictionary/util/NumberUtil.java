package com.navistar.datadictionary.util;

public class NumberUtil {

	 /**
     * Method to check newValue is valid int8 or not
     * @param newValue
     * @return
     */
    public static boolean validateInt8(Object newValue){
    	boolean validInt8Status = false;
    	if(((Integer.parseInt((String)newValue) >= -128) &&((Integer.parseInt((String)newValue) <= 127)))){
    		validInt8Status = true;
        }else{
        	validInt8Status = false;
        }
    	return validInt8Status;
    }
    
    /**
     * Method to check newValue is valid unsigned int8 or not
     * @param newValue
     * @return
     */
    public static boolean validateUInt8(Object newValue){
    	boolean validUInt8Status = false;
    	if(((Integer.parseInt((String)newValue) >= 0) &&((Integer.parseInt((String)newValue) <= 255)))){
    		validUInt8Status = true;
        }else{
        	validUInt8Status = false;
        }
    	return validUInt8Status;
    }
    
    /**
     * Method to check newValue is valid int16 or not
     * @param newValue
     * @return
     */
    public static boolean validateInt16(Object newValue){
    	boolean validInt16Status = false;
    	if(((Integer.parseInt((String)newValue) >= -32768) &&((Integer.parseInt((String)newValue) <= 32767)))){
    		validInt16Status = true;
        }else{
        	validInt16Status = false;
        }
    	return validInt16Status;
    }
    
    /**
     * Method to check newValue is valid unsigned int16 or not
     * @param newValue
     * @return
     */
    public static boolean validateUInt16(Object newValue){
    	boolean validUInt16Status = false;
    	if(((Integer.parseInt((String)newValue) >= 0) &&((Integer.parseInt((String)newValue) <= 65535)))){
    		validUInt16Status = true;
        }else{
        	validUInt16Status = false;
        }
    	return validUInt16Status;
    }
    
    /**
     * Method to check newValue is valid int32 or not
     * @param newValue
     * @return
     */
    public static boolean validateInt32(Object newValue){
    	boolean validInt32Status = false;
    	if(((Integer.parseInt((String)newValue) >= -2147483648) &&((Integer.parseInt((String)newValue) <= 2147483647)))){
    		validInt32Status = true;
        }else{
        	validInt32Status = false;
        }
    	return validInt32Status;
    }
    
    /**
     * Method to check newValue is valid unsigned int32 or not
     * @param newValue
     * @return
     */
    public static boolean validateUInt32(Object newValue){
    	boolean validUInt32Status = false;
    	long maxValue = 4294967295L;
    	if(((Long.parseLong((String)newValue) >= 0) &&((Long.parseLong((String)newValue) <= maxValue)))){
    		validUInt32Status = true;
        }else{
        	validUInt32Status = false;
        }
    	return validUInt32Status;
    }
}
