package com.navistar.datadictionary.util;

import java.util.Comparator;

import com.navistar.datadictionary.model.Node;
/**
 * This class is used to sort the project list visible in the Project
 * Explorer in alphabetical order.
 * @author nikitak1    
 *
 */
public class NodeComparator implements Comparator<Node>{

	/**
	 * Comparator to compare node objects using name of the node
	 * @param node1
	 * @param node2
	 */
	@Override
	public int compare(Node node1, Node node2) {
		return (node1.getName().toLowerCase()).compareTo(node2.getName().toLowerCase());
	}

}
