package com.navistar.datadictionary.util;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import com.navistar.datadictionary.constant.MatlabQueryConstant;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.model.CategoryAttributesIo;

/**
 * The class is used to parse JSON data and convert into List. 
 * @author 
 *
 */
public class JsontoList {

	/**
	 * This function is used to parse the JsonArray, validate as per the DAO class and convert it into List of DAO.
	 * 
	 * @param jsonArray
	 * @return
	 */
	public static List<CategoryAttributes> listInputs(JsonArray jsonArray) {

		Gson gson = new Gson();
		JsonArray newJsonArray = new JsonArray();
		JsonArray updateJsonArray = jsonArray;
		JsonParser parser = new JsonParser();
		JsonObject jsonObject = new JsonObject();
		JsonElement jsonElement = null;

		String newArray = jsonArray.toString().replace("NULL", "");
		updateJsonArray = (JsonArray)parser.parse(newArray);

		// parsing a category JSON array and replacing the unwanted characters.
		for(int i=0;i<updateJsonArray.size();i++)
		{
			jsonObject = (JsonObject)updateJsonArray.get(i);
			Set<Map.Entry<String,JsonElement>> entries = jsonObject.entrySet();
			JsonElement valuesElement = null;
			JsonElement dimensionElement = null;
			JsonElement maxDimElement = null;
			
			for(Map.Entry<String, JsonElement>entry:entries)
			{
				jsonElement = jsonObject.get(entry.getKey());					  
				jsonObject = getValue(entry, jsonElement, jsonObject);
				
				if(entry.getKey().equals(MatlabQueryConstant.VALUE))
				{
					valuesElement = jsonObject.get(MatlabQueryConstant.VALUE);

				}

				if(entry.getKey().equals(MatlabQueryConstant.DIMENSIONS))
				{
					dimensionElement = jsonObject.get(MatlabQueryConstant.DIMENSIONS);

				}		
				
				if(entry.getKey().equals(MatlabQueryConstant.MAX_DIMENSION))
				{
					maxDimElement = jsonObject.get(MatlabQueryConstant.MAX_DIMENSION);

				}
			}

			//JsonParser parser = new JsonParser();
			String data = valuesElement.toString().replaceAll("\"", "");
			valuesElement = parser.parse(data);
			
			// Conditions to check Values and Dimensions attributes
			if(valuesElement!=null && dimensionElement != null && (!valuesElement.toString().equals("") && valuesElement.isJsonArray()))
			{
				Type type = new TypeToken<List<Double>>(){}.getType();
				List<Double> dimensionArray = gson.fromJson(dimensionElement.toString().replace("\"", ""), type);
				List<Double> valueArray = gson.fromJson(valuesElement.toString().replace("\"", ""),type);
				int maxDimofComp = maxDimElement.getAsInt();
				
				// Condition to check the Dimension should have Row and Column value
				if(dimensionArray.size()>1) {
					StringBuffer values = new StringBuffer();				

					// Iterating the elements and converting into [] as per the Dimensions
					values  = createdValueData(dimensionArray,values,valueArray,maxDimofComp);
					jsonObject.addProperty(MatlabQueryConstant.VALUE,values.toString());
				}

			}		


			newJsonArray.add(jsonObject);
		}	

		Type type = new TypeToken<ArrayList<CategoryAttributes>>(){}.getType();
		return gson.fromJson(newJsonArray, type);
	}
	
	/**
	 * Method used to format a value from json to display in table
	 * @param dimensionArray
	 * @param values
	 * @param valueArray
	 * @param maxDimensionofComponent
	 * @return
	 */
	public static StringBuffer createdValueData(List<Double> dimensionArray,StringBuffer values,List<Double> valueArray,int maxDimofComp)
	{
		int lastIndex = 0;
		for (int row = 0; row < dimensionArray.get(0); row++) {
			if((dimensionArray.get(0)>=1) || (dimensionArray.get(1)>1))
			{
				values.append("[");
			}
								
			// Iterating as per the maximum dimension value
			for (int col = 0; col < maxDimofComp; col++) 
			{
				
				// Check for Column dimension value
				if(col < dimensionArray.get(1))
				{
					values.append(valueArray.get(lastIndex));
					
					// Condition to add the separator between the elements							
					if(col < dimensionArray.get(1)-1)
					{
						values.append(",");  
					}
				}
				lastIndex++;											  
			}
			if((dimensionArray.get(0)>=1) || (dimensionArray.get(1)>=1))
			{
				values.append("]");
			}						
			
		}
		return values;
	}

	/**
	 * Method used to replace the Null and double quote(") from the JSON.
	 * 
	 * @param entry
	 * @param jsonElement
	 * @param jsonObject
	 * @return
	 */
	private static JsonObject getValue(Map.Entry<String, JsonElement>entry,JsonElement jsonElement,JsonObject jsonObject) {

		if(jsonElement.isJsonArray()) {	
			jsonObject.addProperty(entry.getKey(), jsonElement.toString().replace("\"", ""));

		}
		else {
			jsonObject.addProperty(entry.getKey(),jsonElement.getAsString().replace("Null", "").replace("null",""));
		}
		return jsonObject;
	}
	
	/**
	 * Method to handle [ ] value in Min and Max for Check I/O comp and Check Comp ips feature
	 * @param jsonStr
	 * @return
	 */
	public static List<CategoryAttributesIo> replaceEmptyBracketsMinMax(String jsonStr){
		//JsonElement jsonElement = new JsonParser().parse(jsonStr);
		
		Gson gson = new Gson();
		JsonArray newJsonArray = new JsonArray();
		JsonArray updateJsonArray;
		JsonParser parser = new JsonParser();
		JsonObject jsonObject = new JsonObject();
		JsonElement jsonElement = null;

		//String newArray = jsonStr.replace("NULL", "");
		updateJsonArray = (JsonArray)parser.parse(jsonStr);

		// parsing a category JSON array and replacing the unwanted characters.
		for(int i=0;i<updateJsonArray.size();i++)
		{
			jsonObject = (JsonObject)updateJsonArray.get(i);
			Set<Map.Entry<String,JsonElement>> entries = jsonObject.entrySet();
			JsonElement minElement = null;
			JsonElement maxElement = null;
			
			for(Map.Entry<String, JsonElement>entry:entries)
			{
				jsonElement = jsonObject.get(entry.getKey());					  
				jsonObject = getValue(entry, jsonElement, jsonObject);
				
				if(entry.getKey().equals("Min"))
				{
					minElement = jsonObject.get("Min");

				}

				if(entry.getKey().equals("Max"))
				{
					maxElement = jsonObject.get("Max");

				}		
				
				
			}

			//JsonParser parser = new JsonParser();
			if(minElement!=null) {
			String mindata = minElement.toString().replaceAll("\"", "");
			minElement = parser.parse(mindata);
			}
			if(maxElement!=null) {
			String maxdata = maxElement.toString().replaceAll("\"", "");
			maxElement = parser.parse(maxdata);
			}
			// Conditions to check Values and Dimensions attributes
			if(minElement!=null && maxElement != null && (!minElement.toString().equals("") && minElement.isJsonArray()))
			{
			//	Type type = new TypeToken<List<Double>>(){}.getType();
			//	List<Double> maxArray = gson.fromJson(maxElement.toString().replace("\"", ""), type);
			//	List<Double> minArray = gson.fromJson(minElement.toString().replace("\"", ""),type);		

					// Iterating the elements and converting into [] as per the Dimensions
					jsonObject.addProperty("Min","");
					jsonObject.addProperty("Max", "");
				//}

			}	

			newJsonArray.add(jsonObject);
		}	

		Type type = new TypeToken<ArrayList<CategoryAttributesIo>>(){}.getType();
		return gson.fromJson(newJsonArray, type);

		
	}

}