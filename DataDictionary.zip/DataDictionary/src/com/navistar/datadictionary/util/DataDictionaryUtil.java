package com.navistar.datadictionary.util;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Stack;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.model.CategoryAttributesIo;
import com.navistar.datadictionary.model.Project;
import com.navistar.datadictionary.serviceimpl.ImportProjectServiceImpl;
import com.navistar.datadictionary.ui.views.ProjectExplorerView;

/**
 * This class is used to find the index from the list and return component path
 * based on component name
 * 
 * @author vijayk13
 *
 */
public class DataDictionaryUtil {

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(DataDictionaryUtil.class); 
	
	/**
	 * Method is used to find the row index for highlighting it in the table
	 * 
	 * @param dataObject
	 * @param componentName
	 * @param categoryName
	 * @param categoryAttributesList
	 * @return
	 */
	public static int searchIndex(String dataObject, String componentName, String categoryName,
			List<CategoryAttributes> catAttributesList) {
		Iterator<CategoryAttributes> iterator = catAttributesList.iterator();
		int index = 0;
		while (iterator.hasNext()) {
			CategoryAttributes category = iterator.next();
			++index;
			if (category.getName()!=null && category.getName().trim().equals(dataObject.trim()) && category.getComponent().equals(componentName)
					&& category.getCategory().equals(categoryName)) {
				return index - 1;
			}
		}
		return -1;
	}

	/**
	 * Method used to get component path based on component name
	 * 
	 * @param componentName
	 * @return
	 */
	public static String getComponentPathByName(String componentName) {
		String componentPath = "";
		Project project = ProjectExplorerView.getActiveProject();
		String activeProject = project.getPath().substring(project.getPath().lastIndexOf("\\") + 1,
				project.getPath().length());
		Map<String, String> activeCompMap = ImportProjectServiceImpl.projectMap.get(activeProject);

		// using for-each loop for iteration over Map.entrySet()
		for (Map.Entry<String, String> entry : activeCompMap.entrySet()) {

			if (entry.getValue().equals(componentName)) {
				componentPath = entry.getKey();
				if(componentPath.contains((project.getPath()))){
					break;
				}
			}
		}
		return componentPath;
	}

	/**
	 * Method used to get project name from path
	 * 
	 * @param projectPath
	 * @return
	 */
	public static String getProjectNameFromPath(String projectPath) {

		String projectName = projectPath.substring(projectPath.lastIndexOf("\\") + 1, projectPath.length());

		return projectName;
	}

	/**
	 * This method is used to get min max range
	 * @param baseType
	 * @param offset
	 * @param slope
	 * @return CategoryAttributes
	 */
	public static CategoryAttributes getMinMaxRange(String baseType, float offset, float slope) {
		String value = "";
		String outputMinimum = getOutputMinimum(baseType, slope);
		String outputMaximum = getOutputMaximum(baseType, slope);
		double fractionLength = (Math.log(1 / slope)) / Math.log(2);
		// Check for signed and unsigned
		if(baseType!=null && !baseType.equals("")) {
			if (!baseType.equals("single") && !baseType.equals("boolean")) {
				if (baseType.startsWith("u")) {
					value = "0";
				} else {
					value = "1";
				}
			} else if (baseType.equals("single")) {
				outputMinimum = Double.toString(-3.40282e+38);
				outputMaximum = Double.toString(3.40282e+38);
			} else if (baseType.equals("boolean")) {
				outputMinimum = "0";
				outputMaximum = "1";
			}
		}
		if (offset == 0 && slope == 1) {
			LOGGER.log(Level.INFO, "Selected data object contains offset as 0 and slope as 1");
			//outputMinimum = getOutputMinimum(baseType, slope);
			//outputMaximum = getOutputMaximum(baseType, slope);
		} else if (offset==0 && fractionLength%1 == 0) {
			double precision = 1 / (Math.pow(2, Math.round(fractionLength)));
			outputMinimum = DataDictionaryUtil.getOutputMinimumFdt3(baseType, precision);
			outputMaximum = DataDictionaryUtil.getOutputMaximumFdt3(baseType, precision);
		} else {
			outputMinimum = DataDictionaryUtil.getOutputMinimumFdt4(baseType, slope, offset);
			outputMaximum = DataDictionaryUtil.getOutputMaximumFdt4(baseType, slope, offset);
		}

		CategoryAttributes valuerange = new CategoryAttributes();
		valuerange.setMin(outputMinimum);
		valuerange.setMax(outputMaximum);
		valuerange.setValue(value);

		return valuerange;
	}
	
	/**
	 * Method is to get the minimum range
	 * 
	 * @param baseType
	 * @param slope
	 * @return
	 */
	public static String getOutputMinimum(String baseType, float slope) {
		String outputMinimum = "";
		if(baseType!=null && !baseType.equals("")) {
		if (baseType.equals("int8")) {

			outputMinimum = Float.toString(-128 * slope);
		} else if (baseType.equals("uint8") || baseType.equals("uint16") || baseType.equals("uint32")) {

			outputMinimum = "0.0";
		} else if (baseType.equals("int16")) {

			outputMinimum = Float.toString(-32768 * slope);
		} else if (baseType.equals("int32")) {

			outputMinimum = Float.toString(-2147483648 * slope);
		}else {
			outputMinimum = "Not defined";
		}
		}else {
			outputMinimum = "Not defined";
		}
		return outputMinimum;
	}

	/**
	 * Method used to return maximum range
	 * 
	 * @param baseType
	 * @param slope
	 * @return
	 */
	public static String getOutputMaximum(String baseType, float slope) {
		String outputMaximum = "";
		if(baseType!=null && !baseType.equals("")) {
		if (baseType.equals("int8")) {

			outputMaximum = Float.toString(127 * slope);
		} else if (baseType.equals("uint8")) {

			outputMaximum = Float.toString(255 * slope);
		} else if (baseType.equals("uint16")) {

			outputMaximum = Float.toString(65535 * slope);
		} else if (baseType.equals("uint32")) {

			outputMaximum = Double.toString(4294967295D * slope);
		} else if (baseType.equals("int16")) {

			outputMaximum = Float.toString(32767 * slope);
		} else if (baseType.equals("int32")) {

			outputMaximum = Float.toString(2147483647 * slope);
		} else {
			outputMaximum = "Not defined";
		}
		}else {
			outputMaximum = "Not defined";
		}
		return outputMaximum;
	}

	/**
	 * Method is to get the minimum range when fraction dt has 4 parameter
	 * 
	 * @param baseType
	 * @param slope
	 * @return outputMinimum
	 * @author JAYSHRIVISHB
	 */
	public static String getOutputMinimumFdt4(String baseType, float slope, float offset) {
		String outputMinimum = "";
		if (baseType.equals("int8")) {

			outputMinimum = Float.toString((-128 * slope) + offset);
		} else if (baseType.equals("uint8") || baseType.equals("uint16") || baseType.equals("uint32")) {

			outputMinimum = Float.toString(offset);
		} else if (baseType.equals("int16")) {

			outputMinimum = Float.toString((-32768 * slope) + offset);
		} else if (baseType.equals("int32")) {

			outputMinimum = Float.toString((-2147483648 * slope) + offset);
		}
		return outputMinimum;
	}

	/**
	 * Method is to get the minimum range when fraction dt has 3 parameter
	 * 
	 * @param baseType
	 * @param precision
	 * @return outputMinimum
	 * @author JAYSHRIVISHB
	 */
	public static String getOutputMinimumFdt3(String baseType, double precision) {
		String outputMinimum = "";
		if (baseType.equals("int8")) {

			outputMinimum = Double.toString(-128 * precision);
		} else if (baseType.equals("uint8") || baseType.equals("uint16") || baseType.equals("uint32")) {

			outputMinimum = "0.0";
		} else if (baseType.equals("int16")) {

			outputMinimum = Double.toString(-32768 * precision);
		} else if (baseType.equals("int32")) {

			outputMinimum = Double.toString(-2147483648 * precision);
		}
		return outputMinimum;
	}

	/**
	 * Method is to get the maximum range when fraction dt has 3 parameter
	 * 
	 * @param baseType
	 * @param precision
	 * @return outputMaximum
	 * @author JAYSHRIVISHB
	 */
	public static String getOutputMaximumFdt3(String baseType, double precision) {
		String outputMaximum = "";
		if (baseType.equals("int8")) {

			outputMaximum = Double.toString(127 * precision);
		} else if (baseType.equals("uint8")) {

			outputMaximum = Double.toString(255 * precision);
		} else if (baseType.equals("uint16")) {

			outputMaximum = Double.toString(65535 * precision);
		} else if (baseType.equals("uint32")) {

			outputMaximum = Double.toString(4294967295D * precision);
		} else if (baseType.equals("int16")) {

			outputMaximum = Double.toString(32767 * precision);
		} else if (baseType.equals("int32")) {

			outputMaximum = Double.toString(2147483647 * precision);
		}
		return outputMaximum;
	}

	/**
	 * Method is to get the maximum range when fraction dt has 4 parameter
	 * 
	 * @param baseType
	 * @param slope
	 * @return outputMaximum
	 * @author JAYSHRIVISHB
	 */
	public static String getOutputMaximumFdt4(String baseType, float slope, float offset) {
		String outputMaximum = "";
		if (baseType.equals("int8")) {		
			outputMaximum = Float.toString((127 * slope) + offset);
		
		} else if (baseType.equals("uint8")) {
			outputMaximum = Float.toString((255 * slope) + offset);
		
		} else if (baseType.equals("uint16")) {		
			outputMaximum = Float.toString((65535 * slope) + offset);
	
		} else if (baseType.equals("uint32")) {
			outputMaximum = Double.toString((4294967295D * slope) + offset);
		
		} else if (baseType.equals("int16")) {	
			outputMaximum = Float.toString((32767 * slope) + offset);
		
		} else if (baseType.equals("int32")) {
			outputMaximum = Float.toString((2147483647 * slope) + offset);
		}
		return outputMaximum;
	}

	/**
	 * Method used to get row count
	 * 
	 * @param dimension
	 * @return int
	 */
	public static int getRowCountFromDimension(String category, String dimension) {
		int rowCount = 0;
		if (!dimension.equals("")) {
			if (category.equals(ApplicationConstant.CATEGORY_INPUT)
					|| category.equals(ApplicationConstant.CATEGORY_OUTPUT)
					|| category.equals(ApplicationConstant.CATEGORY_LOCAL)
					|| category.equals(ApplicationConstant.CATEGORY_NVM)) {
				rowCount = 1;
			} else {
				String newDim = dimension.substring(dimension.indexOf('[') + 1, dimension.lastIndexOf(']'));
				String[] dim = newDim.split(",");
				rowCount = Integer.parseInt(dim[0]);
			}
		}
		return rowCount;
	}

	/**
	 * Method used to get value in proper format in table view
	 * 
	 * @param tableValue
	 * @return String[]
	 */
	public static String[] parseValue(String tableValue, String category, String dimension) {
		String values[] = null;
		if (tableValue != null) {
			String newVal1 = null;
			int rowCount = getRowCountFromDimension(category, dimension);

			if (rowCount > 1) {
				String newVal = tableValue.substring(tableValue.indexOf('[') + 1, tableValue.lastIndexOf(']'));
				newVal1 = newVal.replace("][", ",").replace("[", "").replace("]", "");

			} else {
				newVal1 = tableValue.replace("[", "").replace("]", "");
			}

			values = newVal1.split(",");
			return values;
		}
		return values;
	}

	public static int countNumbers(String string) {
		char[] character = string.toCharArray();
		int num = 0;
		for (int i = 0; i < string.length(); i++) {
			if (Character.isDigit(character[i])) {
				num++;
			}
		}
		return num;
	}

	public static boolean checkBalancedParentesis(String expr) {
		if (expr.isEmpty()) {
			return true;
		}

		Stack<Character> stack = new Stack<Character>();
		for (int i = 0; i < expr.length(); i++) {
			char current = expr.charAt(i);
			if (current == '[') {
				stack.push(current);
			}
			if (current == ']') {
				if (stack.isEmpty()) {
					return false;
				}
				char last = stack.peek();
				if (current == ']' && last == '[') {
					stack.pop();
				} else {
					return false;
				}
			}
		}
		return stack.isEmpty() ? true : false;
	}

	public static int searchIndexIo(String dataObject, String componentName, String categoryName,
			List<CategoryAttributesIo> ioCompatList) {

		Iterator<CategoryAttributesIo> iterator = ioCompatList.iterator();
		int index = 0;
		while (iterator.hasNext()) {
			CategoryAttributes category = iterator.next();
			++index;
			if (category.getName().trim().equals(dataObject.trim()) && category.getComponent().equals(componentName)
					&& category.getCategory().equals(categoryName)) {
				return index - 1;
			}
		}
		return -1;
	}
}
