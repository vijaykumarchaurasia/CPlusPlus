package com.navistar.datadictionary.util;

import javax.annotation.Nonnull;
import org.eclipse.ui.PlatformUI;

import com.google.gson.JsonElement;
import com.navistar.datadictionary.action.UpdateCompParaTypeAction;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.MatlabQueryConstant;
import com.navistar.datadictionary.constant.MatlabResponseConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.ui.config.Application;
import com.navistar.datadictionary.ui.views.CustomMessageDialog;

/**
 * Class used to read the json object given by matlab for error code
 * 
 * @author shubhangim1
 *
 */
public class JSONUtil {

	/**
	 * This method is used to check for error code in matlab response.
	 * 
	 * @param jsonElement
	 * @return
	 */

	public static boolean checkForErrorCode(@Nonnull JsonElement jsonElement) {
		
		UpdateCompParaTypeAction updateComp = new UpdateCompParaTypeAction();
		
		
		if (jsonElement != null && jsonElement.isJsonArray()) {
			JsonElement jsonElement1 = jsonElement.getAsJsonArray().get(0);

			if (jsonElement1.isJsonObject()) {
				if (jsonElement1.getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)) {
					String errorCode = jsonElement1.getAsJsonObject().get(MatlabQueryConstant.ERROR_CODE).getAsString();

					if (errorCode.equals(MatlabResponseConstant.EMPTYDATAERRCODE)) {
						ViewUtil.dispInfoInMsgDialog(MessageConstant.FETCH_SLDD_ERROR);
						return false;
					} else if (errorCode.equals(MatlabResponseConstant.NO_DATA_OBJ_FOUND)) {
						return false;
					}
					else if(errorCode.equals("1006")) {
						ViewUtil.dispInfoInMsgDialog("Program specific sheet is not present in configuration file");
						return false;
					}else if(errorCode.equals("1007")) {
						ViewUtil.dispInfoInMsgDialog("No data present in program specific sheet in configuration file");
						return false;
					}
						else if(errorCode.equals("300")) {
							ViewUtil.dispInfoInMsgDialog("MemorySection column is not found in ConfigObjectType excel sheet for E95. Please use the minimum version 10.3 of Navistar toolbox.");
							return false;
					}else if(errorCode.equals("301"))
					{
						if(Application.programName.equals("E95"))
						{
							String paraTypeMessage = "Parameter type for Calibration, Axis, Curve or Map is different than AUTOSAR4.Parameter. Do you want to update it into AUTOSAR4.Parameter ?";
								CustomMessageDialog messageDialog = new CustomMessageDialog(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(),
										ApplicationConstant.WARNING, null, paraTypeMessage, 0, new String[] { "Update", "Ignore" },
										0);

								int selection = messageDialog.open();
								if (selection == 0) {
									updateComp.run();									
								}
								return false;
						}
						
					}
					else if(errorCode.equals("302")) {
						ViewUtil.dispInfoInMsgDialog("Parameter type for Calibration, Axis, Curve or Map is different than AUTOSAR4.Parameter. "
								+ "Please perform \"Update Parameter Type\" operation before validate");
						return true;
					}
				} else if (jsonElement1.getAsJsonObject().has(MatlabQueryConstant.MESSAGE_CODE)) {
					String messageCode = jsonElement1.getAsJsonObject().get(MatlabQueryConstant.MESSAGE_CODE)
							.getAsString();

					if (messageCode.equals(MatlabResponseConstant.SAVEDATASUCCCODE)) {
						return true;
					}
				}
			}
			return true;
		}
		return false;
	}

	/**
	 * Method is used to check IO Compatibility error for E_44.
	 * 
	 * @param jsonElement
	 */
	public static boolean checkIOCompatibilityIsEmpty(@Nonnull JsonElement jsonElement) {
		if (jsonElement != null && jsonElement.isJsonArray()) {
			for (JsonElement jsonArray : jsonElement.getAsJsonArray()) {

				if(jsonArray.getAsJsonArray().size() > 0)
				{
				JsonElement errorJsonElement = jsonArray.getAsJsonArray().get(0);
				if (errorJsonElement.isJsonObject()) {
					if (errorJsonElement.getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)) {
						String errorCode = errorJsonElement.getAsJsonObject().get(MatlabQueryConstant.ERROR_CODE)
								.getAsString();
						if (errorCode.equals(MatlabResponseConstant.IOCOMPTERRCODE)) {
							return true;
						}

					}
				}
				}
				return false;

			}
		}
		return false;
	}
	
	/**
	 * Method is used to check IO Compatibility error for E_95.
	 * 
	 * @param jsonElement
	 */
	public static boolean checkIOCompatibilityIsEmptyE95(@Nonnull JsonElement jsonElement) {
		if (jsonElement != null && jsonElement.isJsonArray()) {
			for (JsonElement jsonArray : jsonElement.getAsJsonArray()) {

				if(jsonArray.getAsJsonArray().size() > 0)
				{
				JsonElement errorJsonElement = jsonArray.getAsJsonArray().get(0);
				if (errorJsonElement.isJsonObject()) {
					if (errorJsonElement.getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)) {
						String errorCode = errorJsonElement.getAsJsonObject().get(MatlabQueryConstant.ERROR_CODE)
								.getAsString();
						if (errorCode.equals(MatlabResponseConstant.IOCOMPTERRCODEE_95)) {
							return true;
						}

					}
				}
				}
				return false;

			}
		}
		return false;
	}

	/**
	 * This function is used to validate the search data.
	 * @param jsonElement
	 * @return boolean value
	 */
	public static boolean checkSearchError(JsonElement jsonElement)
	{
		if (jsonElement != null && jsonElement.isJsonArray()) {
			JsonElement errorJsonElement = jsonElement.getAsJsonArray().get(0);
			if (errorJsonElement.isJsonObject()) {
				if (errorJsonElement.getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)) {
					String errorCode = errorJsonElement.getAsJsonObject().get(MatlabQueryConstant.ERROR_CODE)
							.getAsString();
					if (errorCode.equals(MatlabResponseConstant.SEARCHDATANOTFND)) {
						return true;
					}

				}
			}
			return false;
		}
		return true;


	}


	/**
	 * Method is used to check no top sldd error.
	 * 
	 * @param jsonElement
	 */
	public static boolean checkErrorCodeForNoTopSldd(@Nonnull JsonElement jsonElement) {

		if (jsonElement != null && jsonElement.isJsonArray()) {
			JsonElement jsonElement1 = jsonElement.getAsJsonArray().get(0);
			if (jsonElement1.isJsonObject()) {
				if (jsonElement1.getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)) {
					String errorCode = jsonElement1.getAsJsonObject().get(MatlabQueryConstant.ERROR_CODE).getAsString();
					if (errorCode.equals(MatlabResponseConstant.NOTOPSLDDERRCODE)
							|| errorCode.equals(MatlabResponseConstant.EMPTYSLDDERRCODE)) {
						return false;
					}
				}

			}
			return true;
		}
		return false;
	}

	/**
	 * Method used for checking if no model exist for sldd
	 * 
	 * @param jsonElement
	 * @return
	 */

	public static boolean checkErrorCodeForNoModel(@Nonnull JsonElement jsonElement) {

		if (jsonElement != null && jsonElement.isJsonArray()) {
			JsonElement jsonElement1 = jsonElement.getAsJsonArray().get(0);
			if (jsonElement1.isJsonObject()) {
				if (jsonElement1.getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)) {
					String errorCode = jsonElement1.getAsJsonObject().get(MatlabQueryConstant.ERROR_CODE).getAsString();
					if (errorCode.equals(MatlabResponseConstant.NO_MODEL_FOUND)) {
						return false;
					}
				}

			}
			return true;
		}
		return false;
	}

	/**
	 * Method used for checking if data saved or not
	 * 
	 * @param jsonElement
	 * @return
	 */
	public static boolean checkForSaveErrorCode(@Nonnull JsonElement jsonElement) {
		if (jsonElement != null && jsonElement.isJsonArray()) {
			JsonElement jsonElement1 = jsonElement.getAsJsonArray().get(0);

			if (jsonElement1.isJsonObject()) {
				if (jsonElement1.getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)) {
					String errorCode = jsonElement1.getAsJsonObject().get(MatlabQueryConstant.ERROR_CODE).getAsString();

					if (errorCode.equals(MatlabResponseConstant.SAVEDATAERRCODE)) {
						return false;
					}
					if (errorCode.equals(MatlabResponseConstant.ADD_DATA_OBJ_ERROR_CODE)) {
						return false;
					}
				} else if (jsonElement1.getAsJsonObject().has(MatlabQueryConstant.MESSAGE_CODE)) {
					String messageCode = jsonElement1.getAsJsonObject().get(MatlabQueryConstant.MESSAGE_CODE)
							.getAsString();

					if (messageCode.equals(MatlabResponseConstant.SAVEDATASUCCCODE)) {
						return true;
					}
				}
			}
			return false;
		}
		return false;
	}

	/**
	 * Method is used to check if model present to resolve Inconsistency error.
	 * 
	 * @param jsonElement
	 */
	public static boolean checkInconsistencyIsEmpty(@Nonnull JsonElement jsonElement) {
		if (jsonElement != null && jsonElement.isJsonArray()) {
			for (JsonElement jsonArray : jsonElement.getAsJsonArray()) {

				JsonElement errorJsonElement = null;
				if (jsonArray.isJsonArray()) {
					errorJsonElement = jsonArray.getAsJsonArray().get(0);
				} else {
					errorJsonElement = jsonArray.getAsJsonObject();
				}

				if (errorJsonElement.isJsonObject()) {
					if (errorJsonElement.getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)) {
						String errorCode = errorJsonElement.getAsJsonObject().get(MatlabQueryConstant.ERROR_CODE)
								.getAsString();
						if (errorCode.equals(MatlabResponseConstant.NOMDLFORINCON)) {
							return false;
						}
						else if (errorCode.equals(MatlabResponseConstant.REDUNDANT_DATA_ERROR_CODE)) {
								return false;
						}else if(errorCode.equals("555")) {
							return false;
						}

					}
				}
				return true;

			}
		}
		return false;
	}
	
	/**
	 * Method is used to check if model present to resolve Inconsistency error.
	 * 
	 * @param jsonElement
	 */
	public static boolean checkUpdateParaIsEmpty(@Nonnull JsonElement jsonElement) {
		if (jsonElement != null && jsonElement.isJsonArray()) {
			for (JsonElement jsonArray : jsonElement.getAsJsonArray()) {

				JsonElement errorJsonElement = null;
				if (jsonArray.isJsonArray()) {
					errorJsonElement = jsonArray.getAsJsonArray().get(0);
				} else {
					errorJsonElement = jsonArray.getAsJsonObject();
				}

				if (errorJsonElement.isJsonObject()) {
					if (errorJsonElement.getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)) {
						String errorCode = errorJsonElement.getAsJsonObject().get(MatlabQueryConstant.ERROR_CODE)
								.getAsString();
						if (errorCode.equals("300")) {
							return false;
						}

					}
				}
				return true;

			}
		}
		return false;
	}

	/**
	 * Method used for checking if inconsistency resolved successfully
	 * 
	 * @param jsonElement
	 * @return
	 */
	public static String checkForResolveIncSuccessCode(@Nonnull JsonElement jsonElement) {
		String response = "";
		boolean dataDelSuccess = false;
		boolean dataAddedSuccess = false;
		if (jsonElement != null && jsonElement.isJsonArray()) {

			for(int count = 0 ; count<jsonElement.getAsJsonArray().size()-1;count++) {
				JsonElement jsonArray = jsonElement.getAsJsonArray().get(count);
				if(jsonArray.getAsJsonArray().toString().contains(MatlabResponseConstant.DELDATASUCCCODE) || jsonArray.getAsJsonArray().toString().contains(MatlabResponseConstant.EMPTYSLDDERRCODE)) {
					dataDelSuccess = checkForDeleteErrorCode(jsonArray);
				}
				else {
					dataDelSuccess = true;
				}
				if(jsonArray.getAsJsonArray().toString().contains(MatlabResponseConstant.SAVEDATASUCCCODE) || jsonArray.getAsJsonArray().toString().contains(MatlabResponseConstant.SAVEDATAERRCODE)) {
					dataAddedSuccess = checkForSaveErrorCode(jsonArray);
				}
				else {
					dataAddedSuccess = true;
				}
			}
		}
		if(dataDelSuccess && dataAddedSuccess) {
			response = "Incosistencies resolved successfully";
		}
		else if(dataDelSuccess && !dataAddedSuccess) {
			response = "Something went wrong while adding data object(s)";
		}
		else if(!dataDelSuccess && dataAddedSuccess) {
			response = "Something went wrong while adding data object(s)";
		}
		else {
			response = "Something went wrong while resolving inconsistencies";
		}

		return response;
	}

	/**
	 * This method is used to check error code for delete data action
	 * @param dataDeletedSuccess
	 * @param jsonElement
	 * @return
	 */
	private static boolean checkForDeleteErrorCode(JsonElement jsonElement) {
		JsonElement jsonDeleteElement = jsonElement.getAsJsonArray().get(0);
		if (jsonDeleteElement.isJsonObject()) {
			if (jsonDeleteElement.getAsJsonObject().has(MatlabQueryConstant.MESSAGE_CODE)) {
				String messageCode = jsonDeleteElement.getAsJsonObject().get(MatlabQueryConstant.MESSAGE_CODE)
						.getAsString();

				if (messageCode.equals(MatlabResponseConstant.DELDATASUCCCODE)) {
					return true;
				} 
			}
			else if(jsonDeleteElement.getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)){
				String errorCode = jsonDeleteElement.getAsJsonObject().get(MatlabQueryConstant.ERROR_CODE)
						.getAsString();

				if (errorCode.equals(MatlabResponseConstant.EMPTYSLDDERRCODE)) {
					return false;
				} 
			}
			return false;
		}
		return false;
	}
	
	/**
	 * Method used for checking if data renamed or not
	 * 
	 * @param jsonElement
	 * @return
	 */
	public static boolean checkForRenameErrorCode(@Nonnull JsonElement jsonElement) {
		if (jsonElement != null && jsonElement.isJsonArray()) {
			JsonElement jsonElement1 = jsonElement.getAsJsonArray().get(0);

			if (jsonElement1.isJsonArray()) {
				if (jsonElement1.getAsJsonArray().get(0).getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)) {
					String errorCode = jsonElement1.getAsJsonArray().get(0).getAsJsonObject().get(MatlabQueryConstant.ERROR_CODE).getAsString();

					if (errorCode.equals(MatlabResponseConstant.RENAME_ERROR_CODE)) {
						return false;
					}
				} else if (jsonElement1.getAsJsonArray().get(0).getAsJsonObject().has(MatlabQueryConstant.MESSAGE_CODE)) {
					String messageCode = jsonElement1.getAsJsonArray().get(0).getAsJsonObject().get(MatlabQueryConstant.MESSAGE_CODE)
							.getAsString();

					if (messageCode.equals(MatlabResponseConstant.RENAME_SUCC_CODE)) {
						return true;
					}
				}
			}
			return false;
		}
		return false;
	}
	
	/**
	 * Method used for checking if use this object successful or not
	 * 
	 * @param jsonElement
	 * @return
	 */
	public static boolean ifUseThisObjSuccess(@Nonnull JsonElement jsonElement) {
		if (jsonElement != null && jsonElement.isJsonArray()) {
			JsonElement jsonElement1 = jsonElement.getAsJsonArray().get(0);
			if (jsonElement1.isJsonObject()) {
				if (jsonElement1.getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)) {
					String errorCode = jsonElement1.getAsJsonObject().get(MatlabQueryConstant.ERROR_CODE).getAsString();
					if (errorCode.equals(MatlabResponseConstant.OBJ_FOR_USE_THIS)) {
						return false;
					}
				} else if (jsonElement1.getAsJsonObject().has(MatlabQueryConstant.MESSAGE_CODE)) {
					String messageCode = jsonElement1.getAsJsonObject().get(MatlabQueryConstant.MESSAGE_CODE)
							.getAsString();
					if (messageCode.equals(MatlabResponseConstant.USE_THIS_OBJ_SUCC) || messageCode.equals(MatlabResponseConstant.RES_USE_THIS_SUC)) {
						return true;
					}
				}
			}
			return false;
		}
		
		return false;
	}
	
	/**
	 * Method is used to check if module present in project for hierarchical view.
	 * 
	 * @param jsonElement
	 */
	public static boolean checkIfNoHierarchicalView(@Nonnull JsonElement jsonElement) {
		if (jsonElement != null && jsonElement.isJsonArray()) {
			JsonElement errorJsonElement = jsonElement.getAsJsonArray().get(0);
			if (errorJsonElement.isJsonObject()) {
				if (errorJsonElement.getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)) {
					String errorCode = errorJsonElement.getAsJsonObject().get(MatlabQueryConstant.ERROR_CODE)
							.getAsString();
					if (errorCode.equals(MatlabResponseConstant.NO_HIERARCHI_VIEW)) {
						return true;
					}

				}
			}
			return false;
		}
		return true;

	}
	
	/**
	 * Method used for checking if model present for rename
	 * 
	 * @param jsonElement
	 * @return
	 */
	public static boolean ifModelPresentForRename(@Nonnull JsonElement jsonElement) {
		if (jsonElement != null && jsonElement.isJsonArray()) {
			JsonElement jsonElement1 = jsonElement.getAsJsonArray().get(0);
			if (jsonElement1.isJsonArray()) {
				if (jsonElement1.getAsJsonArray().get(0).getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)) {
					String errorCode = jsonElement1.getAsJsonArray().get(0).getAsJsonObject().get(MatlabQueryConstant.ERROR_CODE).getAsString();
					if (errorCode.equals(MatlabResponseConstant.NOMDLRNMERRCODE)) {
						return false;
					}


				}
				return true;
			}
			return false;
		}
		return false;
	}

	/**
	 * Method used for checking if data object present in model for rename
	 * 
	 * @param jsonElement
	 * @return
	 */
	public static boolean checkDataObjPresentForRename(@Nonnull JsonElement jsonElement) {
		if (jsonElement != null && jsonElement.isJsonArray()) {
			JsonElement jsonElement1 = jsonElement.getAsJsonArray().get(0);

			if (jsonElement1.isJsonArray()) {
				if (jsonElement1.getAsJsonArray().get(0).getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)) {
					String errorCode = jsonElement1.getAsJsonArray().get(0).getAsJsonObject().get(MatlabQueryConstant.ERROR_CODE).getAsString();

					if (errorCode.equals(MatlabResponseConstant.NO_REN_ERR_CODE)) {
						return false;
					}
				} else if (jsonElement1.getAsJsonArray().get(0).getAsJsonObject().has(MatlabQueryConstant.MESSAGE_CODE)) {
					String messageCode = jsonElement1.getAsJsonArray().get(0).getAsJsonObject().get(MatlabQueryConstant.MESSAGE_CODE)
							.getAsString();

					if (messageCode.equals(MatlabResponseConstant.RENAME_SUCC_CODE)) {
						return true;
					}
				}
			}
			else {
				return false;
			}
			return true;
		}
		else {
			return false;
		}
	}
	
	/**
	 * Method used to check if matlab model loading exception occurred 
	 * while performing model related functionalities
	 * @param jsonElement
	 * @return
	 */
	public static boolean checkForNoMsgException(@Nonnull JsonElement jsonElement) {

		if (jsonElement != null && jsonElement.isJsonArray()) {
			JsonElement jsonElement1 = jsonElement.getAsJsonArray().get(0);
			if (jsonElement1.isJsonObject()) {
				if (jsonElement1.getAsJsonObject().has("modelData")) {
					//String errorCode = jsonElement1.getAsJsonObject().get("modelData").getAsString();
					//if (errorCode.contains("Cannot load model")) {
						return false;
					//}
				}

			}
			return true;
		}
		return false;
	}
	
	/**
	 * Method used to check if model is linked to sldd
	 * file for rename in model
	 * @param jsonElement
	 */
	public static boolean ifModelLinkedForRename(@Nonnull JsonElement jsonElement) {
		if (jsonElement != null && jsonElement.isJsonArray()) {
			JsonElement jsonElement1 = jsonElement.getAsJsonArray().get(0);
			if (jsonElement1.isJsonArray()) {
				if (jsonElement1.getAsJsonArray().get(0).getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)) {
					String errorCode = jsonElement1.getAsJsonArray().get(0).getAsJsonObject().get(MatlabQueryConstant.ERROR_CODE).getAsString();
					if (errorCode.equals("180")) {
						return false;
					}


				}
				return true;
			}
			return false;
		}
		return false;
	}
	/**
	 * Method used to check if there are no input data objects for
	 * check component inputs functionality
	 * @param jsonElement
	 */
	public static boolean checkIfNoCompInputsPresent(@Nonnull JsonElement jsonElement) {
		boolean result = false;
		if (jsonElement != null && jsonElement.isJsonArray()) {
			JsonElement errorJsonElement = jsonElement.getAsJsonArray().get(0);
			if(errorJsonElement.isJsonObject()) {

				String errorCode = errorJsonElement.getAsJsonObject().get(MatlabQueryConstant.ERROR_CODE).getAsString();
				if (errorJsonElement.getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE) && errorCode.equals("190")) {
					result = true;
				}
			}
		}
		return result;
	}

	/**
	 * Method used to check if pre-lookup block is having correct value field
	 * @param jsonElement
	 */
	public static boolean ifPreLookupValueCorrect(JsonElement jsonElement) {
		if (jsonElement != null && jsonElement.isJsonArray()) {
			JsonElement jsonElement1 = jsonElement.getAsJsonArray().get(0);
			if (jsonElement1.isJsonArray()) {
				if (jsonElement1.getAsJsonArray().get(0).getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)) {
					String errorCode = jsonElement1.getAsJsonArray().get(0).getAsJsonObject().get(MatlabQueryConstant.ERROR_CODE).getAsString();
					if (errorCode.equals("123")) {
						return false;
					}


				}
				return true;
			}
			return false;
		}
		return false;
	}
	
	/**
	 * Method used to check if data to be added or deleted from sldd is in valid format
	 * @param jsonElement
	 * @return
	 */
	public static boolean checkExcelToSlddDataIsValid(@Nonnull JsonElement jsonElement) {
		boolean status = true;
		if (jsonElement != null && jsonElement.isJsonArray()) {
			JsonElement jsonElement1 = jsonElement.getAsJsonArray().get(0);
			if (jsonElement1.isJsonObject()) {
				if (jsonElement1.getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)) {
					//String errorCode = jsonElement1.getAsJsonObject().get(MatlabQueryConstant.ERROR_CODE).getAsString();
					status = false;
				}
			}
		}
		return status;
		
	}
	
	/**
	 * Method used to check if units excel is present in Navistar MBD env
	 */
	public static boolean checkForUnitsFile(@Nonnull JsonElement jsonElement) {
		boolean status = true;
		if (jsonElement != null && jsonElement.isJsonArray()) {
			JsonElement jsonElement1 = jsonElement.getAsJsonArray().get(0);
			if (jsonElement1.isJsonObject()) {
				if (jsonElement1.getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)) {
					//String errorCode = jsonElement1.getAsJsonObject().get(MatlabQueryConstant.ERROR_CODE).getAsString();
					status = false;
				}
			}

		}else if(jsonElement==null) {
			status = false;
		}
		return status;
	}
	
	/**
	 * Method used to check if project contains just top.sldd file(s)
	 */
	public static boolean checkForValidProj(@Nonnull JsonElement jsonElement) {
		boolean status = true;
		if (jsonElement != null && jsonElement.isJsonArray()) {
			JsonElement jsonElement1 = jsonElement.getAsJsonArray().get(0);
			if (jsonElement1.isJsonObject()) {
				if (jsonElement1.getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)) {
					int errorCode = jsonElement1.getAsJsonObject().get(MatlabQueryConstant.ERROR_CODE).getAsInt();
					if(errorCode == 110) {
						status = false;
					}
				}
			}

		}
		return status;
	}
	
	/**
	 * Method to get project configuration file from Navistar MBD toolbox
	 */
	public static String getProjConfigFilePath(@Nonnull JsonElement jsonElement) {
		String path = null;
		if (jsonElement != null && jsonElement.isJsonArray()) {
			JsonElement jsonElement1 = jsonElement.getAsJsonArray().get(0);
			if (jsonElement1.isJsonObject()) {
				if (jsonElement1.getAsJsonObject().has("ConfigFilePath")) {
					path = jsonElement1.getAsJsonObject().get("ConfigFilePath").getAsString();
				}else if(jsonElement1.getAsJsonObject().has("errorCode")) {
					path = jsonElement1.getAsJsonObject().get("errorCode").getAsString();
				}
			}

		}
		return path;
	}
	
	/**
	 * Method to get program name for opened component
	 * @param jsonElement
	 * @return
	 */
	public static String getProgramNameForComp(@Nonnull JsonElement jsonElement) {
		String resp = null;
		if (jsonElement != null && jsonElement.isJsonArray()) {
			JsonElement jsonElement1 = jsonElement.getAsJsonArray().get(0);
			if (jsonElement1.isJsonObject()) {
				if (jsonElement1.getAsJsonObject().has("Name")) {
					resp = jsonElement1.getAsJsonObject().get("Name").getAsString();
				}else if(jsonElement1.getAsJsonObject().has("errorCode")) {
					resp = jsonElement1.getAsJsonObject().get("errorCode").getAsString();	
				}
			}
		}
		return resp;
	}

	/**
	 * Method used to check if opened component has program name variable in sldd file
	 * @param jsonElement
	 * @return
	 */
	public static boolean isProgNameAdded(JsonElement jsonElement) {
		String resp = null;
		if (jsonElement != null && jsonElement.isJsonArray()) {
			JsonElement jsonElement1 = jsonElement.getAsJsonArray().get(0);
			if (jsonElement1.isJsonObject()) {
				if (jsonElement1.getAsJsonObject().has("Var1")) {
					resp = jsonElement1.getAsJsonObject().get("Var1").getAsString();
					if(resp.equals(MatlabResponseConstant.PROGVAR_PRES_IN_COMP)) {
						return true;
					}
				}else if(jsonElement1.getAsJsonObject().has("errorCode")) {
					resp = jsonElement1.getAsJsonObject().get("errorCode").getAsString();
					if(resp.equals("1006")) {
						ViewUtil.dispInfoInMsgDialog("Program specific sheet for selected program is not present in configuration file");
					}else if(resp.equals("1007")) {
						ViewUtil.dispInfoInMsgDialog("No data present in program specific sheet in configuration file");
					}
				}
			}

		}
		return false;
	}
}
