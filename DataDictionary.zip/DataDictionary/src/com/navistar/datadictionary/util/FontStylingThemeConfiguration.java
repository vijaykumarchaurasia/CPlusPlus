/*package com.navistar.datadictionary.util;

import org.eclipse.nebula.widgets.nattable.style.theme.ModernNatTableThemeConfiguration;

public class FontStylingThemeConfiguration extends ModernNatTableThemeConfiguration {
    {
    	 // define font styling theme configuration
        this.defaultFont = GUIHelper.getFont(new FontData("Work Sans", 10, SWT.NORMAL));
        this.defaultSelectionFont = GUIHelper.getFont(new FontData("Work Sans", 10, SWT.NORMAL));

        this.cHeaderFont = GUIHelper.getFont(new FontData("Work Sans", 11, SWT.NORMAL));
        this.cHeaderSelectionFont = GUIHelper.getFont(new FontData("Work Sans", 11, SWT.NORMAL));

        this.rHeaderFont = GUIHelper.getFont(new FontData("Work Sans", 11, SWT.NORMAL));
        this.rHeaderSelectionFont = GUIHelper.getFont(new FontData("Work Sans", 11, SWT.NORMAL));

        this.renderCornerGridLines = true;
        this.renderColumnHeaderGridLines = true;
        
    }
}*/