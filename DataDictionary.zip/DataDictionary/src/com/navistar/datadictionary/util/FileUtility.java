package com.navistar.datadictionary.util;

import java.io.File;
import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.filefilter.DirectoryFileFilter;
import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.MessageConstant;

/**
 * Class used to read the files from the local system
 * @author minalc
 *
 */
public class FileUtility {

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(FileUtility.class);

	/** Used to maintain the sldd path */
	static public Map<String, String> slddPathMap = new LinkedHashMap<>();
	
		
	/** Used to maintain the Components of project */
	static public Map<String, List<String>> componentlist = new LinkedHashMap<>();
	
	/** Used to maintain the Components of project */
	static public Map<String, List<String>> arxmlPrjMap = new LinkedHashMap<>();

	/**
	 * Function will retrieve list of components i.e. sldd files in folder
	 * @param dirPath
	 * @return
	 * @throws IOException 
	 */
	public List<String> getComponentList(String dirPath) 
	{
		List<String> componentNameList = new ArrayList<>();		
		List<String> arxmlPathList = new ArrayList<>();
		File topDir = new File(dirPath);
		List<File> directories = new ArrayList<>();
		List<File> textFiles_Sldd = new ArrayList<>();
		List<File> textFiles_Arxml = new ArrayList<>();
		directories.add(topDir);

		List<String> filterWildcards_Sldd = new ArrayList<>();
		List<String> filterWildcards_Arxml = new ArrayList<>();
		filterWildcards_Sldd.add("*.sldd");
		FileFilter typeFilter_Sldd = new WildcardFileFilter(filterWildcards_Sldd);
		filterWildcards_Arxml.add("*.arxml");
		FileFilter typeFilter_Arxml = new WildcardFileFilter(filterWildcards_Arxml);
		String prjName =directories.get(0).getName();
		while (!directories.isEmpty())
		{
			List<File> subDirectories = new ArrayList<File>();
			for(File fi : directories)
			{
				subDirectories.addAll(Arrays.asList(fi.listFiles((FileFilter)DirectoryFileFilter.INSTANCE)));			
				textFiles_Sldd.addAll(Arrays.asList(fi.listFiles(typeFilter_Sldd)));
				if(fi.getName().contains("Architecture")) {
				textFiles_Arxml.addAll(Arrays.asList(fi.listFiles(typeFilter_Arxml)));
				}
			}
			directories.clear();
			directories.addAll(subDirectories);		
		}
		
		for(File fileName : textFiles_Sldd)
		{
			slddPathMap.put(fileName.getPath(), FilenameUtils.getBaseName(fileName.getName()));
			componentNameList.add(FilenameUtils.getBaseName(fileName.getName()));
		}
		for(File fileName : textFiles_Arxml)
		{
			arxmlPathList.add(fileName.getPath());
		}
		componentlist.put(prjName, componentNameList);
		arxmlPrjMap.put(prjName, arxmlPathList);
		return componentNameList;		
	}

	/**
	 * This method is used to write project path and status
	 * in the json file
	 * @param data
	 * @param fileName
	 * @return
	 */
	public boolean writeIntoJsonFile(String data, String fileName)
	{
		FileWriter fileWriter;
		try {
			fileWriter = new FileWriter(fileName);
			fileWriter.write(data);
			fileWriter.flush();
			fileWriter.close();
		} catch (FileNotFoundException e) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			MessageDialog.openConfirm(new Shell(), "Error Message","Erro while writing into JSON file");
			return false;
		} catch (IOException e) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			MessageDialog.openConfirm(new Shell(), "Error Message","Erro while writing into JSON file");
			return false;
		}	
		return true;
	}
	
	/**
	 * method is used to read data from JSON file to maintain project status.
	 * 
	 * @param fileName
	 * @return
	 */
	public JsonElement readFromJsonFile(String fileName)
	{
		JsonParser parser = new JsonParser();
		JsonElement jsonElement = null;
		FileReader fileReader;
		File file;
		try {
			file = new File(fileName);
			if(file.exists()) {
				fileReader = new FileReader(fileName);
				jsonElement = (JsonElement)parser.parse(fileReader);
			}		
		} catch (Exception e) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			MessageDialog.openConfirm(new Shell(), "Error Message","Error While Reading Json File");
			return null;
		}
		return jsonElement;
	}
	
	/**
	 * This method is used to get component path
	 * @param componentName
	 * @return
	 */
	public static String getComponentPathFromProject( String componentName,String projectPath) {
		String componentPath = "";
		for(String compPath : FileUtility.slddPathMap.keySet()) {
			if(compPath.contains(componentName+ApplicationConstant.SLDDFILEEXTN) && compPath.contains(projectPath)) {
				componentPath = compPath;
				break;
			}
			
		}
		return componentPath;
	}
}
