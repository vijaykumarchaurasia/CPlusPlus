package com.navistar.datadictionary.util;

import java.util.Stack;

/**
 * Class used to limit the java.util.Stack size
 * @author minalc
 *
 * @param <T>
 */
@SuppressWarnings("serial")
public class FixedStack<T> extends Stack<T> 
{
	/** Used to set maximum size of stack */
	 private int maxSize;
	 
	 /**
	  * Parameterized constructor
	  * @param size
	  */
	 public FixedStack(int size) {
	        super();
	        this.maxSize = size;
	    }

	 /**
	  * Method used to push elements into stack considering max size
	  *  @param T
	  */
	    @Override
	    public T push(T object) {
	    	
	        //If the stack is too big, remove elements until it's the right size.
	        while (this.size() >= maxSize) {
	            this.remove(0);
	        }
	        return super.push(object);
	    }   
}