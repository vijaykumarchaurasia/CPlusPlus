package com.navistar.datadictionary.util;

import java.lang.reflect.Type;
import java.util.List;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.google.gson.Gson;

/**
 *  Class is used to convert JSON data into another format.
 *  
 * @author VijayK13
 *
 */
public class GsonUtil {
	
	/** GsonUtil instance */
    private static final GsonUtil GSON_UTIL_INST = new GsonUtil();
    
    /** Gson singleton instance*/
    @Nullable
    Gson gson = null;

    /** private constructor to avoid abject creation outside the file */
    private GsonUtil() {
        gson = new Gson();
    }

    /**
     * method is used to return GSONUtil instance
     * 
     * @return instance
     */
    @Nonnull
    public static GsonUtil provider() {
        return GSON_UTIL_INST;
    }

    /**
     * Method is used to convert JSON Object/Array into JSON string.
     * 
     * @param object
     * @return
     */
    @Nonnull
    public String toJSON(Object object) {
        return gson.toJson(object);
    }

    /**
     * Method is used to convert JSON string into specified class.
     * 
     * @param jsonString JSON string
     * @param clazz Specified class
     * @return T Specified class
     */
    public <T> T fromJSON(String jsonString, @Nonnull Class<T> clazz) {
        return gson.fromJson(jsonString, clazz);
    }
    
    /**
     * method is used to 
     * 
     * @param jsonString JSON String
     * @param type``
     * @return List<T>
     */
    public <T> List<T> fromJSONToList(String jsonString, @Nonnull Type type) {
        return gson.fromJson(jsonString, type);
    }
       
}
