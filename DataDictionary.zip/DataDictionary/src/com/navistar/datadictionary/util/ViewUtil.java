package com.navistar.datadictionary.util;

import java.io.File;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Monitor;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IViewReference;
import org.eclipse.ui.PlatformUI;

import com.navistar.datadictionary.action.HierarchicalViewAction;
import com.navistar.datadictionary.action.ImportProjectAction;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.serviceimpl.EditorServiceImpl;
import com.navistar.datadictionary.serviceimpl.OpenComponentServiceImpl;
import com.navistar.datadictionary.ui.config.Application;
import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.ui.views.ActivityLogView;
import com.navistar.datadictionary.ui.views.ProjectExplorerView;

/**
 * Class used for hiding and showing the viewpart from the workspace
 * 
 * @author minalc
 *
 */
public class ViewUtil {

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(ViewUtil.class);
	
	/**
	 * This method is used to hide/show the view part
	 * 
	 * @param viewId
	 *            ViewID of the View
	 * @param status
	 *            Status of the View(Check/Uncheck)
	 */
	public static void showHideView(final String viewId, final boolean status) {

		try {
			// If the view has to be shown			
			if (status) {
				
				PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().showView(viewId);				

				// Condition to Maintain the Project Explorer State
				if (viewId.equals(ViewIDConstant.PROJ_EXPLORER)) {

					ProjectExplorerView.viewer.setInput(ImportProjectAction.nodes);
					new ImportProjectAction().resetProjectStatus();
					String openedComp="";
					openedComp = OpenComponentServiceImpl.selCompName;
					if(null!=openedComp) {
						File compFile = new File(openedComp);
						String openedCompName = FilenameUtils.getBaseName(compFile.getName());
						new EditorServiceImpl().highlightComponent(openedCompName, ProjectExplorerView.hierarchialView);
					}
					
					HierarchicalViewAction hierarchicalView = new HierarchicalViewAction();
					if(ProjectExplorerView.hierarchialView) {
						hierarchicalView.performHierarchicalAction();
					}
					ProjectExplorerView.getInstance().alphabeticalObj.setEnabled(true);
					ProjectExplorerView.getInstance().hierarchiViewObj.setEnabled(true);
				}
				if(viewId.equals(ViewIDConstant.ACTIVITY_LOG)) {
					ActivityLogView.activityLog.setText(ActivityLogView.activityLogText);
				}
				
				
			} else {
				final IViewReference[] views = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
						.getViewReferences();
				for (final IViewReference iViewReference : views) {
					if (iViewReference.getId().equals(viewId)) {
						if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
							if(ActivityLogView.activityLog != null)
							{
								ActivityLogView.activityLogText = ActivityLogView.activityLog.getText();
							}
						}
						iViewReference.getPage().hideView(iViewReference);
						break;
						
					}
				}

			}

		} catch (final Exception e) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			MessageDialog.openConfirm(new Shell(), "Error Message","Error while Showing/Hiding ViewPart");
		}
	}
	/**
	 * Method used to check if the view is open
	 * @param viewId
	 * @return
	 */
	public static boolean isViewOpen(String viewId) {
		final IViewReference[] views = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
				.getViewReferences();
		for (final IViewReference iViewReference : views) {
			if (iViewReference.getId().equals(viewId)) {						
					return true;
			}
		}
		return false;
	}
	/**
	 * Method used to close the views
	 * @param viewId
	 */
	public static void closeView(String viewId) {
		//If table editor is available at the launch of application then close it
		IViewPart view = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().findView(viewId);		
		if(view!=null)
		{
			
			ViewUtil.showHideView(viewId, false);
		}
	}

	public static void setShellPositionAtCenter(Display display, Shell shell) {
		/** take the primary monitor */
		Monitor primary = display.getPrimaryMonitor();
		
		/** get the size of the screen */
		Rectangle bounds = primary.getBounds();
		
		/** get the size of the window */
		Rectangle rect = shell.getBounds();

		/** calculate the centre */
		int horizontalPos = bounds.x + (bounds.width - rect.width) / 2;
		int verticalPosition = bounds.y + (bounds.height - rect.height) / 2;

		/** set the new location */
		shell.setLocation(horizontalPos, verticalPosition);
		
	}
	
	public static void dispInfoInMsgDialog(String message) {
		Shell shell = new Shell(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(),SWT.ON_TOP);
		ViewUtil.setShellPositionAtCenter(PlatformUI.getWorkbench().getDisplay(),shell);
		MessageDialog.openInformation(shell, ApplicationConstant.INFORMATION, message);
	}
	
	public static void dispConfirmDialog(String title,String message) {
		Shell shell = new Shell(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(),SWT.ON_TOP);
		ViewUtil.setShellPositionAtCenter(PlatformUI.getWorkbench().getDisplay(),shell);
		MessageDialog.openConfirm(shell, title, message);
		
	}
	
	/**
	 * Method used to disable I/O features if those category tabs are not displayed
	 */
	public static void disableIOFeatures() {
		if(Application.programName.equals("E95")) {
			ApplicationActionBarAdvisor.getInstance().ioCompatAction.setEnabled(true);	
			ApplicationActionBarAdvisor.getInstance().excelImportExport.setEnabled(false);
			ProjectExplorerView.getInstance().checkCompInObj.setEnabled(true);
			//ProjectExplorerView.getInstance().validateCompParaTypeAction.setEnabled(true);
			ApplicationActionBarAdvisor.getInstance().updateProjParaTypeAction.setEnabled(true);	
		}else {
			ApplicationActionBarAdvisor.getInstance().ioCompatAction.setEnabled(true);	
			ApplicationActionBarAdvisor.getInstance().excelImportExport.setEnabled(false);
			ProjectExplorerView.getInstance().checkCompInObj.setEnabled(true);
			//ProjectExplorerView.getInstance().validateCompParaTypeAction.setEnabled(false);
			ApplicationActionBarAdvisor.getInstance().updateProjParaTypeAction.setEnabled(false);	
		}
	}
	
}
