package com.navistar.datadictionary.util;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.navistar.datadictionary.constant.MatlabQueryConstant;

/**
 * Class used to create a matlab request
 * @author JAYSHRIVISHB
 *
 */
public class CreateMatlabRequest {
	
	/**
	 * This method is used to create JSON object for executing and getting response
	 * from Matlab's script(s)
	 * 
	 * @param queryName
	 *            Matlab script name
	 * @param componentName
	 *            component path
	 * @param dataObject
	 *            JSON object used as an input to the Matlab script
	 */
	
	public static String createMatlabRequest(String queryName, String componentName, String dataObject) {

		JsonParser jsonParser = new JsonParser();
		JsonObject queryJsonObject = new JsonObject();
		queryJsonObject.addProperty(MatlabQueryConstant.QUERY_NAME, queryName);

		JsonObject componentJsonObj = new JsonObject();
		componentJsonObj.addProperty(MatlabQueryConstant.COMPONENT_NAME, componentName);

		JsonArray jsonArray = new JsonArray();
		jsonArray.add(queryJsonObject);
		jsonArray.add(componentJsonObj);

		// Check dataObject because fetch query contains null and add query contains
		// newly added data object value
		if (dataObject != null && !dataObject.equals("")) {
			JsonArray dataObjectArray = jsonParser.parse(dataObject).getAsJsonArray();
			for (JsonElement object : dataObjectArray) {
				jsonArray.add(object);
			}

		}

		// String in requested json format
		String jsonStrForReq = getRequstedJSONString(jsonArray);
		return jsonStrForReq;
	}

	/**
	 * Function used to create a string in required format for Matlab
	 * 
	 * @param jsonArray
	 * @return
	 */
	private static String getRequstedJSONString(JsonArray jsonArray) {
		String jsonString = jsonArray.toString();
		String jsonSubString = jsonString.substring(1, jsonString.length() - 1);

		return "[''" + jsonSubString + "'']";
	}
	
	
	
}
