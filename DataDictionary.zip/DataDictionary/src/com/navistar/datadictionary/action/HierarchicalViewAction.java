package com.navistar.datadictionary.action;


import java.io.File;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.eclipse.jface.action.Action;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import com.navistar.datadictionary.model.Node;
import com.navistar.datadictionary.service.OpenProjectService;
import com.navistar.datadictionary.serviceimpl.OpenComponentServiceImpl;
import com.navistar.datadictionary.serviceimpl.OpenProjectServiceImpl;
import com.navistar.datadictionary.ui.views.ProjectExplorerView;

/**
 * The HierarchicalViewAction is used for changing project view to hierarchical.
 * 
 * @author nikitak1
 *
 */
public class HierarchicalViewAction extends Action implements IWorkbenchAction{

	/**  The ID used for HierarchicalViewAction class */
	private static final String HIERARCHICAL_ID = "com.navistar.datadictionary.HierarchicalViewAction";

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(HierarchicalViewAction.class);

	/**
	 * The default constructor is used to set Id of HierarchicalViewAction.
	 */
	public HierarchicalViewAction() {
		setId(HIERARCHICAL_ID);
	}

	/**
	 * run method is used handle action on clicking the option of context menu and icon click.
	 * 
	 */
	@Override
	public void run() {
		performHierarchicalAction();
	}

	/**
	 * Method used to perform Hierarchical view action
	 */
	public void performHierarchicalAction() {
		OpenProjectService openProjService = new OpenProjectServiceImpl();
		LOGGER.info("View Change Operation Performed on Hierarchical View click");
		
		String projectName = openProjService.getOpenedProjectName();  
		String componentName = null ;
		String actualCompName ="";
		ProjectExplorerView.getInstance().viewNodeList = new ArrayList<Node>();

		if(OpenComponentServiceImpl.selCompName != null && !OpenComponentServiceImpl.selCompName.equals(""))
		{
			componentName = OpenComponentServiceImpl.selCompName;
		}
		if(componentName != null) {
			String compNameWithExt = new File(componentName).getName();
			actualCompName = compNameWithExt.substring(0, compNameWithExt.lastIndexOf('.'));
			ProjectExplorerView.getInstance().previousCompName = actualCompName;
		}
		else
		{
			actualCompName = "";
			ProjectExplorerView.getInstance().previousCompName="";
		}
		ProjectExplorerView.getInstance().changeViewToHierarchical();
		ProjectExplorerView.getInstance().displayInExplorer(projectName, actualCompName);
		/*ProjectExplorerView.getInstance().hierarchiViewObj.setEnabled(false);
		ProjectExplorerView.getInstance().alphabeticalObj.setEnabled(true);*/
	}
	
	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}

}
