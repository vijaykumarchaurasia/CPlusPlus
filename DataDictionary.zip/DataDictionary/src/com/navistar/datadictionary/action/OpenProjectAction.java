package com.navistar.datadictionary.action;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.PlatformUI;

import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.model.Node;
import com.navistar.datadictionary.model.Project;
import com.navistar.datadictionary.service.OpenProjectService;
import com.navistar.datadictionary.serviceimpl.EditorServiceImpl;
import com.navistar.datadictionary.serviceimpl.OpenProjectServiceImpl;
import com.navistar.datadictionary.ui.config.Application;
import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.ui.views.ActivityLogView;
import com.navistar.datadictionary.ui.views.ProjectExplorerView;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * The OpenProjectAction class provide context menu action
 * for opening a project in project explorer. 
 * 
 * @author minalc
 *
 */
public class OpenProjectAction extends Action {

	/** The ID is used for OpenProjectAction class */
	private static final String OPEN_PROJ_ID = "com.navistar.datadictionary.action.OpenProjectAction";
	
	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(OpenProjectAction.class);
	
	/**
	 * The constructor  is used for setting ID for OpenProjectAction class.
	 */
	public OpenProjectAction() {
		setId(OPEN_PROJ_ID);
	}
	public static String openProjectName = "";
	public static boolean openProjectFlag = true;
	/**
	 * run method is used handle action on clicking the option of context menu.
	 * @return 
	 * 
	 */
	public void run() {
		try {
			OpenProjectService openProjService = new OpenProjectServiceImpl();
			//OpenComponentServiceImpl.selCompName="";
			IStructuredSelection selected = (IStructuredSelection) ProjectExplorerView.viewer.getSelection();
			Node selectNode = (Node) selected.getFirstElement();
			openProjectName = selectNode.getName();
			
			IEditorPart activeEditor = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor();
			Application.programName=null;
			boolean status = openProjService.performOpenProjectAction(activeEditor);
			if(!status) {
				Project project = ProjectExplorerView.getActiveProject();
				String prjpath=project.getPath().replace("\\", "/");
				Application.programName= new EditorServiceImpl().getConfigProjDataFrMatlab(prjpath);
				if(Application.programName == null) {
					MessageDialog.openError(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), "Error", "Program name not present in sldd file");
					PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell().setText("Data Dictionary");
					return;
				}else if(Application.programName.equals("1003")) {
					MessageDialog.openError(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), "Error", "Program name not present in sldd file");
					PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell().setText("Data Dictionary");
					return;
				}else if(Application.programName.equals("1004")) {
					MessageDialog.openError(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), "Error", "More than one program names found in sldd file");
					PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell().setText("Data Dictionary");
					return;
				}
				PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell().setText("Data Dictionary : Currently selected project is - "+Application.programName);
				ViewUtil.disableIOFeatures();
				HierarchicalViewAction hierarchicalView = new HierarchicalViewAction();
				AlphabeticalViewAction alphabeticalView = new AlphabeticalViewAction();
				
				if(ProjectExplorerView.hierarchialView) {
					hierarchicalView.performHierarchicalAction();
				}
				else
				{
					alphabeticalView.performAlphabeticalAction();
				}
				if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
					ActivityLogView.activityLog.append("\n [INFO]: Project Opened : "+ selectNode.getName());
					ActivityLogView.activityLog.append("\n [INFO]: Opened project path : "+ProjectExplorerView.getActiveProject().getPath());
				}
				ApplicationActionBarAdvisor.getInstance().excelImportExport.setEnabled(false);
				ApplicationActionBarAdvisor.getInstance().resolvInconObj.setEnabled(false);
				ApplicationActionBarAdvisor.getInstance().searchAction.setEnabled(true);
				//ApplicationActionBarAdvisor.getInstance().ioCompatAction.setEnabled(true);
				ApplicationActionBarAdvisor.getInstance().validProjAction.setEnabled(true);
				//ApplicationActionBarAdvisor.getInstance().validateProjParaTypeAction.setEnabled(true);
			}else {
				if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
					ActivityLogView.activityLog.append("\n [INFO]: Open Project operation cancelled");
				}
			}
		}
		catch(Exception exception) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, exception);
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [ERROR]: "+MessageConstant.OPEN_PROJ_ERROR);
			}
			MessageDialog.openError(new Shell(), "ERROR",MessageConstant.OPEN_PROJ_ERROR);
		}
	};	

}
