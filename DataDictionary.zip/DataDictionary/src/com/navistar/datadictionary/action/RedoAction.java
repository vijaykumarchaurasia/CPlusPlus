package com.navistar.datadictionary.action;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.core.commands.operations.IUndoContext;
import org.eclipse.core.commands.operations.IUndoableOperation;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.operation.UndoRedoOperation;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.ui.views.ActivityLogView;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * The RedoAction is used to redo the data of one category.
 * 
 * @author minalc
 *
 */
public class RedoAction extends Action implements IWorkbenchAction {

	/** The ID used for RedoAction class */
	private static final String REDO_ACTION_ID = "com.navistar.datadictionary.action.RedoAction";
	
	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(CategoryEditor.class);

	/**
	 * The constructor is used to set Id and initialize the shell for RedoAction.
	 */
	public RedoAction() {
		setId(REDO_ACTION_ID);
		setActionDefinitionId("DataDictionary.redo");
	}

	/**
	 * The run method is used to call redo 
	 *
	 */
	@Override
	public void run() {
	IUndoableOperation operation =  new UndoRedoOperation(); 
		
	    IUndoContext undoContext = PlatformUI.getWorkbench().getOperationSupport().getUndoContext();			    
	   
	    //Add the current context for operation to be redo
	    operation.addContext(undoContext);
	    
	    try {    
	    	operation.redo(null, null);
	    	if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
	    		ActivityLogView.activityLog.append("\n [INFO]: Operation Re-done");
	    	}
	    	
		} catch (Exception e) {
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
	    		ActivityLogView.activityLog.append("\n [ERROR]: "+e.getMessage());
	    	}
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			MessageDialog.openConfirm(new Shell(), "Error Message","Error while performing Redo Operation");
		}
	}
	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean
	}
}
