package com.navistar.datadictionary.action;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.service.IOCompatibilityService;
import com.navistar.datadictionary.serviceimpl.IOCompatibilityServiceImpl;
import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.ui.editors.IOCompatibilityEditor;
import com.navistar.datadictionary.ui.views.ActivityLogView;
import com.navistar.datadictionary.ui.views.IOCompatibilityView;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * The class is used to delete the data object from category of the component or I/O compatibility list.
 * 
 * @author JAYSHRIVISHB
 *
 */
public class DeleteDataObjectAction extends Action implements IWorkbenchAction{

	/**  The ID used for DeleteDataObjectAction class */
	private static final String DEL_DATA_OBJ_ID = "com.navistar.datadictionary.DeleteDataObjectAction";
	
	/** Used to access I/O Compatibility Service */
	private IOCompatibilityService ioCompatService;

	/**
	 * The default constructor is used to set Id DeleteDataObjectAction.
	 */
	public DeleteDataObjectAction() {
		setId(DEL_DATA_OBJ_ID);
		//setActionDefinitionId("DataDictionary.deleteObject");
		ioCompatService = new IOCompatibilityServiceImpl();
	}

	/**
	 * the run method is used to call delete data object.
	 *
	 */
	@Override
	public void run() {
		// Get active editor
		ApplicationActionBarAdvisor.getInstance().deleteAction.setEnabled(false);
		IWorkbenchPart activePart = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
				.getActivePart();
		if (activePart.getTitle().equals(ApplicationConstant.IO_COMPATIBILITY)) {
			IOCompatibilityView ioCompatView = IOCompatibilityView.getIOCompatibilityViewInstance();
			try {
				ioCompatService.deleteDataObjectFromView(ioCompatView.getTree());
				/*if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG_VIEW_ID)) {
					ActivityLogView.activityLog.append("\n [INFO]: Data Object Deleted");
				}*/
			} catch (MatlabCommunicatinException e) {
				if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
					ActivityLogView.activityLog.append("\n [ERROR]: "+e.getMessage());
				}
				MessageDialog.openConfirm(new Shell(), "Error Message", e.getMessage());
			}
		} else {
			IEditorPart editorPart = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
					.getActiveEditor();
			if (editorPart instanceof IOCompatibilityEditor) {
				IOCompatibilityEditor iOCompatEditor = (IOCompatibilityEditor) editorPart;
				//if(iOCompatibilityEditor.createNatTable.getSelectionLayer().hasColumnSelection()) {
				if(iOCompatEditor.getTitle().equals("Inconsistent I/Os") || iOCompatEditor.getTitle().equals("Duplicate Outputs")){
					iOCompatEditor.deleteDataObjectFromIOTable();
				}
				//}
			} else if(editorPart instanceof CategoryEditor){
				CategoryEditor categoryEditor = (CategoryEditor) editorPart;
				categoryEditor.createNatTable.getSelectionLayer().setConfigLabelAccumulator(null);
				if(categoryEditor.createNatTable.getSelectionLayer().hasColumnSelection()){
					categoryEditor.deleteDataObjectFromContextMenu();
				}
			}else {
				return;
			}
			
		}

	}

	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}
	

}
