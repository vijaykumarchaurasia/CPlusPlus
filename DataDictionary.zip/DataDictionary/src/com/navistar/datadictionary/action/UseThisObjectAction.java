package com.navistar.datadictionary.action;

import org.eclipse.jface.action.Action;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.serviceimpl.UseThisObjectServiceImpl;
import com.navistar.datadictionary.ui.views.ActivityLogView;
import com.navistar.datadictionary.ui.views.CheckComponentInputsView;
import com.navistar.datadictionary.ui.views.IOCompatibilityView;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Class used to replace inconsistent attributes for Check comp ip view
 * and I/O Compatibility view
 * @author nikitak1
 *
 */
public class UseThisObjectAction extends Action implements IWorkbenchAction{

	/**  The ID used for UseThisObjectAction class */
	private static final String USE_THIS_OBJ_ID = "com.navistar.datadictionary.UseThisObjectAction";

	/**
	 * The default constructor is used to set Id UseThisObjectAction.
	 */
	public UseThisObjectAction() {
		setId(USE_THIS_OBJ_ID);
	}

	/**
	 * the run method is used to call Use this object action
	 *
	 */
	@Override
	public void run() {
		UseThisObjectServiceImpl useThisService = new UseThisObjectServiceImpl();
		// Get active window view
		IWorkbenchPart activePart = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
				.getActivePart();
		
		if (activePart.getTitle().equals(ApplicationConstant.IO_COMPATIBILITY)) {
			IOCompatibilityView ioCompView = IOCompatibilityView.getIOCompatibilityViewInstance();
			useThisService.getObjectToUseForIOComp(ioCompView.getTree());
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
			ActivityLogView.activityLog.append("\n [INFO]: Use this Data Object performed successfully");
		}
			
		} if (activePart.getTitle().equals(ApplicationConstant.COMPONENT_INPUTS)){
			
			CheckComponentInputsView checkCompView = CheckComponentInputsView.getCompInputsViewInstance();
			useThisService.getObjectToUseForCompIp(checkCompView.getTree());
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
			ActivityLogView.activityLog.append("\n [INFO]: Use this Data Object performed successfully");
		}
			
		} 

	}

	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}


}
