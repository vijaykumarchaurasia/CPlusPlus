package com.navistar.datadictionary.action;

import org.eclipse.jface.action.Action;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

/**
 * The ActivityLogAction class is used to view activity log actions.  
 * 
 * @author vijayk13
 *
 */
public class ActivityLogAction extends Action implements IWorkbenchAction{
	
	/** The ID used for ActivityLogAction class */
	private static final String ACTIVITY_LOG_ID = "com.navistar.datadictionary.ActivityLogAction";

	/** 
	 * The default constructor is used for setting ID for ActivityLogAction class. 
	 */
	public ActivityLogAction() {
		super();
		setId(ACTIVITY_LOG_ID);
	}
	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}

}
