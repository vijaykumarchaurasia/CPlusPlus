package com.navistar.datadictionary.action;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import com.navistar.datadictionary.constant.ApplicationConstant;

/**
 * The HelpSearchAction class provides help for the tool. 
 * 
 * @author vijayk13
 *
 */
public class HelpSearchAction extends Action implements IWorkbenchAction{
	
	/**  The ID used for HelpSearchAction class */
	private static final String HELP_SEARCH_ID = "com.navistar.datadictionary.HelpSearchAction";
	
	/**
	 * The default constructor is used for setting ID for HelpSearchAction class.
	 */
	public HelpSearchAction() {
		setId(HELP_SEARCH_ID);
	}
	
	/**
	 * the run method is used to execute help action
	 *
	 */
	public void run() {
		//text file, should be opening in default text editor
        File file = new File("C:\\Program Files (x86)\\KPIT\\Data Dictionary\\Help.pdf");
        
        //first check if Desktop is supported by Platform or not
        if(!Desktop.isDesktopSupported()){
            MessageDialog.openError(new Shell(), "Error", ApplicationConstant.HELP);
            return;
        }
        
        Desktop desktop = Desktop.getDesktop();
        if(file.exists()){
			try {
				desktop.open(file);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				MessageDialog.openError(new Shell(), "Error", ApplicationConstant.HELP_ERROR);
			}
		}
        else {
        	MessageDialog.openError(new Shell(), "Error", ApplicationConstant.HELP_ERROR);
        }
	}
	
	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}

}
