package com.navistar.datadictionary.action;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.PlatformUI;

import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.service.CheckComponentInputsService;
import com.navistar.datadictionary.service.OpenComponentService;
import com.navistar.datadictionary.serviceimpl.CheckComponentInputsServiceimpl;
import com.navistar.datadictionary.serviceimpl.OpenComponentServiceImpl;
import com.navistar.datadictionary.ui.config.Application;
import com.navistar.datadictionary.ui.config.DataDictionaryApplication;
import com.navistar.datadictionary.ui.views.ActivityLogView;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * This class provides Check component inputs feature.
 * @author nikitak1
 *
 */
public class CheckComponentInputsAction extends Action{

	/**  The ID used for CheckComponentInputs class */
	private static final String CHECK_COMP_INPUTS = "com.navistar.datadictionary.action.CheckComponentInputsAction"; 
	
	/**
	 * The constructor  is used for setting ID for CheckComponentInputsAction class.
	 */
	public CheckComponentInputsAction() {
		setId(CHECK_COMP_INPUTS);
	}

	/**
	 * This method is used to get Component Inputs view.
	 */
	@Override
	public void run() {
		OpenComponentService openCompService = new OpenComponentServiceImpl();
		CheckComponentInputsService checkCompService = new CheckComponentInputsServiceimpl();
		if(Application.programName.equals("E95"))
		{
			if(checkCompService.getArxmlPath().equals("null"))
			{
				MessageDialog.openInformation(new Shell(),"Information", "No ARXML file present in selected component.");
				return;
			}
			else
			{
				IViewPart componentIPView = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().findView(ViewIDConstant.COMP_INPUTS);
				DataDictionaryApplication.getApplication().setCheckCompIpStatus(true);
				if(componentIPView != null){
					ViewUtil.closeView(ViewIDConstant.COMP_INPUTS);
				}
				ViewUtil.showHideView(ViewIDConstant.COMP_INPUTS, true);
				if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
					ActivityLogView.activityLog.append("\n [INFO]: Generated Check Component Input Data for component : "+openCompService.getOpenedComponentName());
				}
				
			}
			
		}
		else
		{
		IViewPart componentIPView = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().findView(ViewIDConstant.COMP_INPUTS);
		DataDictionaryApplication.getApplication().setCheckCompIpStatus(true);
		if(componentIPView != null){
			ViewUtil.closeView(ViewIDConstant.COMP_INPUTS);
		}
		ViewUtil.showHideView(ViewIDConstant.COMP_INPUTS, true);
		if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
			ActivityLogView.activityLog.append("\n [INFO]: Generated Check Component Input Data for component : "+openCompService.getOpenedComponentName());
		}
		}
	}
}
