package com.navistar.datadictionary.action;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.jface.preference.PreferencePage;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.nebula.widgets.nattable.layer.DataLayer;
import org.eclipse.nebula.widgets.nattable.selection.config.DefaultSelectionStyleConfiguration;
import org.eclipse.nebula.widgets.nattable.style.theme.ModernNatTableThemeConfiguration;
import org.eclipse.nebula.widgets.nattable.style.theme.ThemeConfiguration;
import org.eclipse.nebula.widgets.nattable.util.GUIHelper;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FontDialog;
import org.eclipse.swt.widgets.Link;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPreferencePage;
import org.eclipse.ui.PlatformUI;

import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.model.FontStyleDAO;
import com.navistar.datadictionary.ui.config.DataDictionaryApplication;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.ui.nattable.DefaultNatTableStyleConfiguration;
//import com.navistar.datadictionary.util.FontStylingThemeConfiguration;

public class EditorPreference extends PreferencePage implements IWorkbenchPreferencePage{

	//private static final String EDITOR_PREFERENCES_ID = "com.navistar.datadictionary.action.EditorPreference";
	public static FontDialog fontDialog ;
	public FontData newFont;
	FontStyleDAO fontStyle;
	//Flag is added to check, is font restored to default?
	public static boolean isDefFontSel = false;
	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(EditorPreference.class);
	
	public EditorPreference() {
		super();
	}
	public EditorPreference(String title) {
		super(title);
	}
	public EditorPreference(String title, ImageDescriptor image) {
		super(title, image);
	}
	public void init(IWorkbench workbench) {
		//Nothing to do
	}
	@Override
	protected Control createContents(Composite composite) {

		Composite panel = new Composite(composite, SWT.NULL);
		GridLayout layout = new GridLayout();
		layout.marginWidth = 0;
		layout.marginHeight = 0;
		layout.numColumns = 4;
		panel.setLayout(layout);
		GridData data = new GridData();
		data.horizontalSpan = 2;
		data.grabExcessHorizontalSpace = true;
		data.horizontalAlignment = SWT.CENTER;
		panel.setLayoutData(data);
		// Create a Link
		Link link = new Link(panel, SWT.NONE);
		link.setText("<a >Font and color</a>.");
		Shell shlFont = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
		// Event handling when users click on links.
		link.addSelectionListener(new SelectionAdapter()  {
			@Override
			public void widgetSelected(SelectionEvent event) {
				fontDialog = new FontDialog(shlFont, SWT.NONE);
				fontDialog.setText("Select Font");
				fontStyle = DataDictionaryApplication.getApplication().fontStyle;
				FontData defaultFont;
				if(fontStyle != null && fontStyle.getFont() != null && !EditorPreference.isDefFontSel) {
					fontDialog.setRGB(fontStyle.getFontColor());
					defaultFont = new FontData(fontStyle.getFont(), fontStyle.getSize(), fontStyle.getFontStyle());
				} else {
					fontDialog.setRGB(new RGB(0, 0, 0));
					defaultFont = new FontData("Work Sans", 10, SWT.NORMAL);
					isDefFontSel = false;
				}
				fontDialog.setFontData(defaultFont);
				newFont = fontDialog.open();
				if(newFont != null) {

					fontStyle.setFontStyle(newFont.getStyle());
					fontStyle.setFont(newFont.getName());
					fontStyle.setSize(newFont.getHeight());
					fontStyle.setFontColor(fontDialog.getRGB());
				}
				initializeValues();
			}
		});
		return panel;
	}
	/**
	 * Called when user clicks Apply or OK
	 * 
	 * @return boolean
	 */
	public boolean performOk() {
		//Editors font setting
		DefaultNatTableStyleConfiguration natTblConfig = new DefaultNatTableStyleConfiguration();
		Display parent = PlatformUI.getWorkbench().getDisplay();
		if(newFont != null && !isDefFontSel ) {
			natTblConfig.font = new Font(parent, newFont) ;
			natTblConfig.fgColor = new Color(parent,fontDialog.getRGB()) ;
			int height = newFont.getHeight();
			setFontToEditors(natTblConfig, height);
			isDefFontSel = false;
			// Project Explorer font setting
			ImportProjectAction importProjAction = new ImportProjectAction();
			int fontSize = fontStyle.getSize();
			if(fontSize>12) {
				fontSize =12;
			}
			Font openProjectFont = new Font(PlatformUI.getWorkbench().getDisplay(), fontStyle.getFont(), fontSize, SWT.BOLD);
			Font closeProjectFont = new Font(PlatformUI.getWorkbench().getDisplay(), fontStyle.getFont(), fontSize, SWT.NORMAL);
			Color openProjectColor = new Color(PlatformUI.getWorkbench().getDisplay(), fontStyle.getFontColor());
			Color closeProjectColor = new Color(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.CLOSE_PROJ_COLOR, ApplicationConstant.CLOSE_PROJ_COLOR, ApplicationConstant.CLOSE_PROJ_COLOR);
			importProjAction.setProjectStyle(openProjectFont, closeProjectFont, openProjectColor, closeProjectColor);
			initializeValues();
		}
		return super.performOk();
	}
	/**
	 * This method is used to apply default font.
	 */
	@SuppressWarnings("deprecation")
	protected void performDefaults() {
		// Get the preference store
		fontStyle = DataDictionaryApplication.getApplication().fontStyle;
		try {
			if(!isDefFontSel && fontStyle.getFont() != null && (fontStyle.getSize()!=10 || !fontStyle.getFont().equals("Work Sans"))) {
				
				DefaultNatTableStyleConfiguration natTblConfig = new DefaultNatTableStyleConfiguration();
				Display parent = PlatformUI.getWorkbench().getDisplay();
				FontData defaultFont = new FontData();
				defaultFont.setHeight(10);
				defaultFont.setName(ApplicationConstant.APP_FONT_STYLE);	
				defaultFont.setStyle(SWT.NORMAL);
				natTblConfig.font = new Font(parent, defaultFont) ;
				//natTableConfiguration.fgColor = new Color(parent,fontDialog.getRGB()) ;
				int height = defaultFont.getHeight();
				fontStyle.setFontStyle(defaultFont.getStyle());
				fontStyle.setFont(defaultFont.getName());
				fontStyle.setSize(defaultFont.getHeight());
				fontStyle.setFontColor(new RGB(0, 0, 0));
				setFontToEditors(natTblConfig, height);
				isDefFontSel = true;
				// Project Explorer font setting
				ImportProjectAction importProjAction = new ImportProjectAction();

				Font openProjectFont = new Font(PlatformUI.getWorkbench().getDisplay(), defaultFont.getName(), defaultFont.getHeight(), SWT.BOLD);
				Font closeProjectFont = new Font(PlatformUI.getWorkbench().getDisplay(), defaultFont.getName(), defaultFont.getHeight(), SWT.NORMAL);
				Color openProjectColor = new Color(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.OPEN_PROJ_COLOR, ApplicationConstant.OPEN_PROJ_COLOR, ApplicationConstant.OPEN_PROJ_COLOR);
				Color closeProjectColor = new Color(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.CLOSE_PROJ_COLOR, ApplicationConstant.CLOSE_PROJ_COLOR, ApplicationConstant.CLOSE_PROJ_COLOR);
				importProjAction.setProjectStyle(openProjectFont, closeProjectFont, openProjectColor, closeProjectColor);
				fontDialog.setFontData(defaultFont);
			}
		} catch(Exception npe) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, npe);
		}
	}
	
	/**
	 * This method is used to set font to editors.
	 * @param natTableConfiguration
	 * @param height
	 */
	private void setFontToEditors(DefaultNatTableStyleConfiguration natTbleConfig, int height) {
		IWorkbenchPage activePage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();			
		IEditorReference[] editors = activePage.getEditorReferences(); 	
		DefaultSelectionStyleConfiguration selectionStyle = new DefaultSelectionStyleConfiguration();
	       FontStyleDAO fontStyle = DataDictionaryApplication.getApplication().fontStyle;
			if(fontStyle  != null && fontStyle.getFont() != null && !EditorPreference.isDefFontSel) {
				if(fontStyle.getFont().equals(ApplicationConstant.APP_FONT_STYLE)) {
					selectionStyle.selectionFont = GUIHelper.getFont(new FontData(fontStyle.getFont(), 11, fontStyle.getFontStyle()));
				} else {
					
					selectionStyle.selectionFont = GUIHelper.getFont(new FontData(fontStyle.getFont(), fontStyle.getSize(), fontStyle.getFontStyle()));
				}
	        } else {
	        	selectionStyle.selectionFont = GUIHelper.getFont(new FontData(ApplicationConstant.APP_FONT_STYLE, 11, SWT.NORMAL));
	        }
			selectionStyle.anchorBgColor = GUIHelper.getColor(99, 127, 191);
		for (IEditorReference editor : editors) {					

			if(editor.getEditor(false) instanceof CategoryEditor)	{
				final ThemeConfiguration fontTheme = new ModernNatTableThemeConfiguration();
				CategoryEditor categoryEditor = (CategoryEditor) editor.getEditor(false);
				categoryEditor.natTable.setTheme(fontTheme);
				activePage.activate(categoryEditor);			
				categoryEditor.addNatTableConfiguration();
				categoryEditor.natTable.addConfiguration(natTbleConfig);
				DataLayer dataLayer = categoryEditor.createNatTable.getDataLayer();
				dataLayer.setDefaultRowHeight(height*2);
				GridData natTableData = new GridData(SWT.FILL, SWT.FILL, true, true);
				natTableData.horizontalSpan = 2;
				natTableData.horizontalAlignment = GridData.FILL;
				categoryEditor.natTable.setLayoutData(natTableData);
				categoryEditor.natTable.addConfiguration(selectionStyle);
				categoryEditor.natTable.addConfiguration(categoryEditor);
				categoryEditor.natTable.configure();
				categoryEditor.natTable.redraw();
			}
		}
	}
	public void initializeDefaultPreferences() {
		// These settings will show up when the preference page
		// is shown for the first time.
		/*FontData defaultFont = new FontData("Work Sans", 10, SWT.NORMAL);
		fontDialog.setFontData(defaultFont);*/
	}
	private void initializeValues() {
		/*FontData defaultFont = new FontData("Work Sans", 10, SWT.NORMAL);
		fontDialog.setFontData(defaultFont);*/
	}
	/**
	 * This method is used to perform cancel operation.
	 */
	public boolean performCancel(){

		return true;
	}
}
