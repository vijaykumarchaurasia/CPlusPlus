package com.navistar.datadictionary.action;


import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.ui.views.ExcelImportExportWindow;

/**
 * The ExcelImportExportAction is used to resolve inconsistency between sldd and excel
 * 
 * @author nikitak1
 *
 */
public class ExcelImportExportAction extends Action implements IWorkbenchAction{

	/**  The ID used for ExcelImportExportAction class */
	private static final String EXCEL_IMP_EX_ID = "com.navistar.datadictionary.ExcelImportExportAction";
	
	/** The viewer is used to set ContextMenuActions on it */
	TreeViewer viewer;
	
	ExcelImportExportWindow window = new ExcelImportExportWindow();
	
	/**
	 * The default constructor is used to set Id IOInconsistency.
	 */
	public ExcelImportExportAction() {
		setId(EXCEL_IMP_EX_ID);
	}
	public ExcelImportExportAction(TreeViewer viewer) {
		this.viewer = viewer;
	}
	/**
	 * run method is used handle action on clicking the option of context menu and icon click.
	 * 
	 */
	public void run() {
		//Checking editors - if editor is dirty then asking user to save it
		IWorkbench workbench = PlatformUI.getWorkbench();
		IWorkbenchWindow activeWindow = workbench.getActiveWorkbenchWindow();
		IWorkbenchPage activePage = activeWindow.getActivePage();
		IEditorReference[] editors = activePage.getEditorReferences();
		boolean isDirty = false;
		for (IEditorReference ref : editors) {
			IEditorPart editorPart = ref.getEditor(false);
			if(editorPart != null && editorPart.isDirty()) {
				isDirty = true;
				break;
			}
		}
		if(isDirty){
			MessageDialog.openWarning(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), ApplicationConstant.WARNING , MessageConstant.SAVE_DATA_WARNING);
		} else {
			ExcelImportExportWindow window = new ExcelImportExportWindow();
			window.open();
		}
	}
	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}

}
