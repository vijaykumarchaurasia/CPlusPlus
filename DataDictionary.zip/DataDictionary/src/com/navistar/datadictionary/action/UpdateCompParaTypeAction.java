package com.navistar.datadictionary.action;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import com.google.gson.JsonElement;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.customexception.EditorInitilizationException;
import com.navistar.datadictionary.customexception.EditorReuseException;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.service.UpdateParameterTypeService;
import com.navistar.datadictionary.serviceimpl.EditorServiceImpl;
import com.navistar.datadictionary.serviceimpl.OpenComponentServiceImpl;
import com.navistar.datadictionary.serviceimpl.UpdateParameterTypeServiceImpl;
import com.navistar.datadictionary.ui.config.Application;
import com.navistar.datadictionary.ui.views.ActivityLogView;
import com.navistar.datadictionary.ui.views.UpdatedParameterView;
import com.navistar.datadictionary.util.ViewUtil;


/**
 * The ValidateCompParaTypeAction class provides feature to update parameter
 * in opened component.
 * 
 * @author shalins
 *
 */
public class UpdateCompParaTypeAction extends Action implements IWorkbenchAction {

	/** The viewer is used to set updateCompParaTypeAction on it */
	private TreeViewer viewer;
	
	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(EditorServiceImpl.class);
	
	/** The ID used ValidateCompParaTypeAction class */
	static final String UPDCOMTYPE_ID = "com.navistar.datadictionary.UpdateCompParaTypeAction";
	
	/**
	 * The default constructor is used for setting ID for updateCompParaAction
	 * class.
	 */
	public UpdateCompParaTypeAction() {
		setId(UPDCOMTYPE_ID);
	}
	public UpdateCompParaTypeAction(TreeViewer viewer) {
			this.viewer = viewer;
		}
	

	/**
	 * This method is used to execute the update Project action.
	 * @param viewer
	 */
	@Override
	public  void run() {
		UpdateParameterTypeService vaParamService = new UpdateParameterTypeServiceImpl();
		/** Used to initiate open component service impl call */
		OpenComponentServiceImpl openCompService = new OpenComponentServiceImpl();
		UpdatedParameterView updatedParaView =new UpdatedParameterView();
		try {

				JsonElement jsonElement = vaParamService.updateValCompParaType();
				if(jsonElement!=null) {
						Application.count=0;
						openCompService.validateEditors(viewer);
						updatedParaView.setUIContents(jsonElement);		
				}
			
		} catch (MatlabCommunicatinException e) {
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [ERROR]: "+e.getMessage());
			}
			ViewUtil.dispConfirmDialog("Error Message", e.getMessage());
		
		} catch (EditorReuseException e) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
		} catch (EditorInitilizationException e) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
		}

	}


	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}
}