package com.navistar.datadictionary.action;
import org.apache.log4j.Logger;
import org.eclipse.jface.action.Action;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import com.navistar.datadictionary.ui.views.ActivityLogView;

/**
 * The ClearLogAction is used for clearing the Activity Log.
 * 
 * @author nikitak1
 *
 */
public class ClearLogAction extends Action implements IWorkbenchAction{

	/**  The ID used for ClearLogAction class */
	private static final String CLEAR_LOG_ID = "com.navistar.datadictionary.ClearLogAction";

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(ClearLogAction.class);
	
	/**
	 * The default constructor is used to set Id of ClearLogAction.
	 */
	public ClearLogAction() {
		setId(CLEAR_LOG_ID);
	}

	/**
	 * run method is used handle action on clicking the option of clear log icon.
	 * 
	 */
	@Override
	public void run() {
		ActivityLogView.activityLog.setText("");
		LOGGER.info("Clear Activity Log Operation Performed");
	}
	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}

}
