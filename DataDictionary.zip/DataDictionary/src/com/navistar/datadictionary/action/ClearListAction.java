package com.navistar.datadictionary.action;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.Separator;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.ui.config.DataDictionaryApplication;
import com.navistar.datadictionary.ui.views.ActivityLogView;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * The ClearListAction is used for clearing list of recently imported project.
 * 
 * @author vijayk13
 *
 */
public class ClearListAction extends Action implements IWorkbenchAction{
	
	/** The ID used for ClearListAction class */
	private static final String CLEAR_LIST_ID = "com.navistar.datadictionary.ClearListAction";
	
	/**
	 * The default constructor  is used for setting ID for ClearListAction class 
	 */
	public ClearListAction() {	
		setId(CLEAR_LIST_ID);
	}
	
	/**
	 * the run method is used to call clear list action.
	 *
	 */
	@Override
	public void run() {
		
		DataDictionaryApplication.getApplication().recentImpProjMap.clear();
		ApplicationActionBarAdvisor.recentimportMenu.removeAll();
		ApplicationActionBarAdvisor.pathList.clear();
		IWorkbenchAction clearListAction = new ClearListAction();
		clearListAction.setText("Clear List");
		clearListAction.setEnabled(false);
		ApplicationActionBarAdvisor.recentimportMenu.add(new Separator());
		ApplicationActionBarAdvisor.recentimportMenu.add(clearListAction);
		ApplicationActionBarAdvisor.recentimportMenu.saveWidgetState();
		if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
			ActivityLogView.activityLog.append("\n [INFO]: Cleared Recently Imported Project List");
		}
	}
	
	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}

}
