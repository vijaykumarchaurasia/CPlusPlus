package com.navistar.datadictionary.action;

import org.eclipse.jface.action.Action;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

/**
 * The DataObjectWindowAction is used to manipulate data in project.
 * 
 * @author vijayk13
 *
 */
public class DataObjectWindowAction extends Action implements IWorkbenchAction{
	
	/**  The ID used for DataObjectWindowAction class */
	private static final String DATA_OBJ_WIN_ID = "com.navistar.datadictionary.DataObjectWindowAction";
	
	/**
	 * The default constructor is used to set Id DataObjectWindowAction.
	 */
	public DataObjectWindowAction() {
		setId(DATA_OBJ_WIN_ID);
	}
	
	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}

}
