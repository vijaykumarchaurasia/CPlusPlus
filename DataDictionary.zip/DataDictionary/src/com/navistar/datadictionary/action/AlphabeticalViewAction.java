package com.navistar.datadictionary.action;
import java.io.File;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.eclipse.jface.action.Action;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import com.navistar.datadictionary.model.Node;
import com.navistar.datadictionary.service.OpenProjectService;
import com.navistar.datadictionary.serviceimpl.OpenComponentServiceImpl;
import com.navistar.datadictionary.serviceimpl.OpenProjectServiceImpl;
import com.navistar.datadictionary.ui.views.ProjectExplorerView;

/**
 * The AlphabeticalViewAction is used for changing project view to alphabetical.
 * 
 * @author nikitak1
 *
 */
public class AlphabeticalViewAction extends Action implements IWorkbenchAction{

	/**  The ID used for AlphabeticalViewAction class */
	private static final String ALPHABETICAL_ID = "com.navistar.datadictionary.AlphabeticalViewAction";

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(AlphabeticalViewAction.class);

	/**
	 * The default constructor is used to set Id of AlphabeticalViewAction.
	 */
	public AlphabeticalViewAction() {
		setId(ALPHABETICAL_ID);
	}

	/**
	 * run method is used handle action on clicking the option of context menu and icon click.
	 * 
	 */
	@Override
	public void run() {
		performAlphabeticalAction();
	}

	/**
	 * Method used to perform alphabetical view action
	 */
	public void performAlphabeticalAction() {
		OpenProjectService openProjService = new OpenProjectServiceImpl();
		LOGGER.info("View Change Operation Performed on Alphabetical View click");

		String projectName = openProjService.getOpenedProjectName();  
		String componentName = null ;
		String actualCompName ="";
		ProjectExplorerView.getInstance().viewNodeList = new ArrayList<Node>();
		if(OpenComponentServiceImpl.selCompName != null && !OpenComponentServiceImpl.selCompName.equals(""))
		{
			componentName = OpenComponentServiceImpl.selCompName;
		}
		if(componentName != null) {
			String compNameWithExt = new File(componentName).getName();
			actualCompName = compNameWithExt.substring(0, compNameWithExt.lastIndexOf('.'));
			ProjectExplorerView.getInstance().previousCompName = actualCompName;
		}
		else
		{
			actualCompName = "";
			ProjectExplorerView.getInstance().previousCompName="";
		}
		ProjectExplorerView.getInstance().changeViewToAlphabetical();
		ProjectExplorerView.getInstance().displayInExplorer(projectName, actualCompName);
		ProjectExplorerView.getInstance().hierarchiViewObj.setEnabled(true);
		ProjectExplorerView.getInstance().alphabeticalObj.setEnabled(false);
	}
	
	
	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}

}
