package com.navistar.datadictionary.action;

import org.eclipse.jface.action.Action;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.ui.config.Activator;
import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.ui.views.ActivityLogView;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * The FilterAction is used to provide Filter feature.
 * 
 * @author vijayk13
 *
 */
public class FilterAction extends Action implements IWorkbenchAction{
	
	
	/** The ID used for FilterAction class */
	private static final String FILETR_ACTION_ID = "com.navistar.datadictionary.FilterAction";
	
	/**
	 * The default constructor is used for setting ID for FilterAction class.
	 */
	public FilterAction() {
		setId(FILETR_ACTION_ID);
	}
	
	/**
	 * the run method is used to execute filter action
	 *
	 */
	public void run() {
		IEditorPart activeEditor = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
				.getActiveEditor();
		if(activeEditor instanceof CategoryEditor) {
			if(((CategoryEditor) activeEditor).createNatTable.filterRowHLayer.isFilterRowVisible()) {
				((CategoryEditor) activeEditor).createNatTable.filterRowHLayer.setFilterRowVisible(false);
				((CategoryEditor) activeEditor).createNatTable.filterRowHLayer.setAllValuesSelected();
				if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
					ActivityLogView.activityLog.append("\n [INFO]: Filter Removed");
				}
				ApplicationActionBarAdvisor.getInstance().filterAction.setImageDescriptor(Activator.getImageDescriptor("/icons/filter.png"));
				ApplicationActionBarAdvisor.getInstance().filterAction.setToolTipText(ApplicationConstant.FILTER);
			}
			else {
				((CategoryEditor) activeEditor).createNatTable.filterRowHLayer.setFilterRowVisible(true);
				if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
					ActivityLogView.activityLog.append("\n [INFO]: Filter Applied");
				}
				ApplicationActionBarAdvisor.getInstance().filterAction.setImageDescriptor(Activator.getImageDescriptor("/icons/clear-filter.png"));
				ApplicationActionBarAdvisor.getInstance().filterAction.setToolTipText("Clear Filter");
			}
		}
	}
	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}

}
