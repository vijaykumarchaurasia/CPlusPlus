package com.navistar.datadictionary.action;

import org.eclipse.jface.action.Action;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FontDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.ui.nattable.DefaultNatTableStyleConfiguration;

/**
 * The class is used to set the font style.
 * 
 * @author JAYSHRIVISHB
 *
 */
public class FontStyleAction extends Action implements IWorkbenchAction{

	/**  The ID used for DeleteDataObjectAction class */
	private static final String FONT_STYLE_ID = "com.navistar.datadictionary.FontStyleAction";
	public static FontDialog fontDialog ;
	/**
	 * The default constructor is used to set Id DeleteDataObjectAction.
	 */
	public FontStyleAction() {
		setId(FONT_STYLE_ID);
	}

	/**
	 * the run method is used to call delete data object.
	 *
	 */
	@Override
	public void run() {
		Shell shlFont = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
		fontDialog = new FontDialog(shlFont, SWT.NONE);
		fontDialog.setText("Select Font");
		fontDialog.setRGB(new RGB(0, 0, 0));
		FontData defaultFont = new FontData("Courier", 10, SWT.BOLD);
		fontDialog.setFontData(defaultFont);
		FontData newFont = fontDialog.open();
		if (newFont == null) {
			return;
		}
		// Add default style configuration to the NAT table
		DefaultNatTableStyleConfiguration natTblConfig = new DefaultNatTableStyleConfiguration();
		Display parent = PlatformUI.getWorkbench().getDisplay();
		natTblConfig.font = new Font(parent, newFont) ;
		natTblConfig.fgColor = new Color(parent,fontDialog.getRGB()) ;
		IWorkbenchPage activePage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();			
		IEditorReference[] editors = activePage.getEditorReferences(); 	
		for (IEditorReference editor : editors) {					

			if(editor.getEditor(false) instanceof CategoryEditor)	{
				CategoryEditor categoryEditor = (CategoryEditor) editor.getEditor(false);
				activePage.activate(categoryEditor);			
				categoryEditor.addNatTableConfiguration();
				categoryEditor.natTable.addConfiguration(natTblConfig);
				categoryEditor.natTable.configure();
				categoryEditor.natTable.redraw();
			}
		}
	}

	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}
}
