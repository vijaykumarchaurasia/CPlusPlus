package com.navistar.datadictionary.action;

import java.util.List;

import org.eclipse.jface.action.Action;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import com.navistar.datadictionary.serviceimpl.RemoveProjectServiceImpl;
import com.navistar.datadictionary.ui.views.ProjectExplorerView;

/**
 * The RemoveProjectAction is used to remove selected projects from workspace
 * 
 * @author JAYSHRIVISHB
 *
 */
public class RemoveProjectAction extends Action implements IWorkbenchAction {

	/** The ID used for RemoveProjectAction class */
	private static final String REMOVE_PROJ_ID = "com.navistar.datadictionary.action.RemoveProjectAction";

	/**
	 * The constructor is used to set Id for RemoveProjectAction.
	 */
	public RemoveProjectAction() {
		setId(REMOVE_PROJ_ID);
	}

	/**
	 * the run method is used to call remove project operation
	 *
	 */
	@Override
	public void run() {
		
		RemoveProjectServiceImpl removeProj = new RemoveProjectServiceImpl();
		
		List<String> removedProjList = removeProj.getProjectListForRemove(ProjectExplorerView.viewer);
		removeProj.removeProjectFromWorkspace(ProjectExplorerView.viewer,removedProjList);

	}

	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}
}
