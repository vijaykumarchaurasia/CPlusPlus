package com.navistar.datadictionary.action;

import org.eclipse.jface.action.Action;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

/**
 * The DataDictionaryAbout class provides help for the tool. 
 * 
 * @author vijayk13
 *
 */
public class DataDictionaryAbout extends Action implements IWorkbenchAction{
	
	/**  The ID used for DataDictionaryAbout class */
	private static final String DATA_DICT_ABOUT = "com.navistar.datadictionary.DataDictionaryAbout";
	
	/**
	 * The default constructor is used for setting ID for DataDictionaryAbout class.
	 */
	public DataDictionaryAbout() {
		setId(DATA_DICT_ABOUT);
	}
	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}

}
