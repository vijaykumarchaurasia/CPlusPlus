package com.navistar.datadictionary.action;

import org.eclipse.jface.action.Action;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;


/**
 * The TableEditorAction class provides table editor action. 
 * 
 * @author vijayk13
 *
 */
public class TableEditorAction extends Action implements IWorkbenchAction{

	/**  The ID used for TableEditorAction class */
	private static final String TABLE_EDITOR_ID = "com.navistar.datadictionary.TableEditorAction";
	
	/**
	 * The constructor is used for setting ID for TableEditorAction class.
	 */
	public TableEditorAction() {
		setId(TABLE_EDITOR_ID);
	}
	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}

}
