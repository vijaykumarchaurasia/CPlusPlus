package com.navistar.datadictionary.action;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.widgets.Shell;

import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.customexception.EditorInitilizationException;
import com.navistar.datadictionary.customexception.EditorReuseException;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.model.Node;
import com.navistar.datadictionary.serviceimpl.OpenComponentServiceImpl;
import com.navistar.datadictionary.ui.config.Activator;
import com.navistar.datadictionary.ui.config.Application;
import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.ui.config.DataDictionaryApplication;
import com.navistar.datadictionary.ui.views.ActivityLogView;
import com.navistar.datadictionary.util.ViewUtil;

/**
 *  The OpenComponentAction class provides open component functionality
 *  on click event. 
 * @author JAYSHRIVISHB
 *
 */
public class OpenComponentAction extends Action{

	/** The viewer is used to set OpenComponentAction on it */
	private TreeViewer viewer;
	
	/**
	 * The constructor  is used for setting ID for OpenComponentAction class.
	 */
	public OpenComponentAction() {

	}
	public OpenComponentAction(TreeViewer viewer) {
		this.viewer = viewer;
	}
	
	/**
	 * run method is used handle action on clicking the option of context menu.
	 * 
	 */
	public void run() {

		OpenComponentServiceImpl openCompService = new OpenComponentServiceImpl();
		OpenProjectAction.openProjectFlag = false;
		try {
			DataDictionaryApplication.getApplication().setSearchedHighLight(false);
	    	DataDictionaryApplication.getApplication().setSearchedHighlighted(null);
	    	Application.count=-1;
	    	openCompService.validateEditors(viewer);
			ApplicationActionBarAdvisor.getInstance().filterAction.setEnabled(true);
			ApplicationActionBarAdvisor.getInstance().filterAction.setImageDescriptor(Activator.getImageDescriptor("/icons/filter.png"));
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				IStructuredSelection selected = (IStructuredSelection) viewer.getSelection();
				Node selectNode = (Node) selected.getFirstElement();
				if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
					ActivityLogView.activityLog.append("\n [INFO]: Component Opened : "+selectNode.getName());
				}
			}
		}
		catch (MatlabCommunicatinException e){
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [ERROR]: "+e.getMessage());
			}
			MessageDialog.openConfirm(new Shell(), "Error Message", e.getMessage());
		} catch (EditorReuseException e) {
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [ERROR]: "+e.getMessage());
			}
			MessageDialog.openConfirm(new Shell(), "Error Message", e.getMessage());
		} catch (EditorInitilizationException e) {
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [ERROR]: "+e.getMessage());
			}
			MessageDialog.openConfirm(new Shell(), "Error Message", e.getMessage());
		}
		
	};	
}
