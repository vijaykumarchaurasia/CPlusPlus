package com.navistar.datadictionary.action;


import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.service.ResolveInconsistencyService;
import com.navistar.datadictionary.serviceimpl.ResolveInconsistencyServiceImpl;
import com.navistar.datadictionary.ui.views.InconsistencyWindowView;

/**
 * The IOInconsistency is used to resolve inconsistency in component.
 * 
 * @author vijayk13
 *
 */
public class IOInconsistency extends Action implements IWorkbenchAction{

	/**  The ID used for IOInconsistency class */
	private static final String IO_INCON_ID = "com.navistar.datadictionary.IOInconsistency";
	
	/** The viewer is used to set ContextMenuActions on it */
	TreeViewer viewer;
	
	InconsistencyWindowView window = new InconsistencyWindowView();
	
	/**
	 * The default constructor is used to set Id IOInconsistency.
	 */
	public IOInconsistency() {
		setId(IO_INCON_ID);
	}
	public IOInconsistency(TreeViewer viewer) {
		this.viewer = viewer;
	}
	/**
	 * run method is used handle action on clicking the option of context menu and icon click of Resolve Inconsistency.
	 * 
	 */
	public void run() {
		//Checking editors - if editor is dirty then asking user to save it
		IWorkbench workbench = PlatformUI.getWorkbench();
		IWorkbenchWindow activeWindow = workbench.getActiveWorkbenchWindow();
		IWorkbenchPage activePage = activeWindow.getActivePage();
		IEditorReference[] editors = activePage.getEditorReferences();
		boolean isDirty = false;
		for (IEditorReference ref : editors) {
			IEditorPart editorPart = ref.getEditor(false);
			if(editorPart != null && editorPart.isDirty()) {
				isDirty = true;
				break;
			}
		}
		if(isDirty){
			MessageDialog.openWarning(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), ApplicationConstant.WARNING , MessageConstant.SAVE_DATA_WARNING);
		} else {

			ResolveInconsistencyService resolveIncons = new ResolveInconsistencyServiceImpl();
			resolveIncons.openInconsistencyWindow();
		}
	}
	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}

}
