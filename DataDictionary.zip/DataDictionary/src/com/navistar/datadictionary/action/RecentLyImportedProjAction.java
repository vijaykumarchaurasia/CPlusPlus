package com.navistar.datadictionary.action;

import org.eclipse.jface.action.Action;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

/**
 * The RecentLyImportedProjAction is used for get  recentLy imported project list.
 * 
 * @author vijayk13
 *
 */
public class RecentLyImportedProjAction extends Action implements IWorkbenchAction{
	
	/**  The ID used for RecentLyImportedProjAction class */
	private static final String RECENT_PROJ_ID = "com.navistar.datadictionary.RecentLyImportedProjAction";
	
	/**
	 * The constructor is used to set Id RecentLyImportedProjAction.
	 */
	public RecentLyImportedProjAction() {
		setId(RECENT_PROJ_ID);
	}
	
	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}
}
