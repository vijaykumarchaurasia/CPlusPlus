package com.navistar.datadictionary.action;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import com.google.gson.JsonElement;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.service.ValidatProjParamService;
import com.navistar.datadictionary.serviceimpl.ValidateProjParamServiceImpl;
import com.navistar.datadictionary.ui.views.ActivityLogView;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * The ValidateCompAction class provides feature to Validate hidden
 * attribute values in opened component.
 * 
 * @author nikitak1
 *
 */
public class ValidateCompAction extends Action implements IWorkbenchAction {

	/** The ID used ValidateCompAction class */
	private static final String VAL_COMP_ID = "com.navistar.datadictionary.ValidateCompAction";
	
	/**
	 * The default constructor is used for setting ID for ValidateCompAction
	 * class.
	 */
	public ValidateCompAction() {

		setId(VAL_COMP_ID);

	}

	/**
	 * This method is used to execute the Validate Component action.
	 */
	@Override
	public void run() {
		ValidatProjParamService vaParamService = new ValidateProjParamServiceImpl();
		try {
			MessageDialog dialog = new MessageDialog
					(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), 
							ApplicationConstant.WARNING, null,
							"Are you sure you want to replace the hidden attribute values of "
									+ "data objects for opened component ? ", 
									MessageDialog.CONFIRM,
					new String[] { ApplicationConstant.BTN_YES, ApplicationConstant.BTN_NO }, 0);
			int result = dialog.open();
			if (result == 0) {
				JsonElement jsonElement = vaParamService.createValidCompParamReq();
				if(jsonElement!=null) {
					String response = jsonElement.getAsJsonArray().get(0).getAsJsonObject().get("messageCode").getAsString();
					
					if(response.equals("441")) {	
						ViewUtil.dispInfoInMsgDialog("Hidden attributes of data objects replaced successfully");
					}
				}
			}
		} catch (MatlabCommunicatinException e) {
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [ERROR]: "+e.getMessage());
			}
			ViewUtil.dispConfirmDialog("Error Message", e.getMessage());
		}
	
		
	}

	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}
}
