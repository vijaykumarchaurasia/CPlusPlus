package com.navistar.datadictionary.action;

import org.eclipse.jface.action.Action;
import org.eclipse.nebula.widgets.nattable.copy.command.CopyDataToClipboardCommand;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.ui.views.ActivityLogView;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Copy Action used to copy the data to clipboard 
 * @author raeesm
 *
 */
public class CopyAction extends Action implements IWorkbenchAction{

	/** Copy Action ID	 */
	private static final String COPY_ACTION_ID = "com.navistar.datadictionary.action.CopyAction";
	
	/** Copy Flag */
	public static int copyFlag = 0;
	
	/** Default Constructor */
	public  CopyAction() {
		setId(COPY_ACTION_ID);
		setActionDefinitionId("DataDictionary.copy");
	}
	
	/** Overridden Method (NON USE)*/
	@Override
	public void dispose() {
		// nothing to clean-up
		
	}
	
	/** Execute Copy Action*/
	@Override
	public void run() {
		//Get the active editor
		IEditorPart activeEditor = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
				.getActiveEditor();
		
		//Condition to check if editor is instance of category editor
		if(activeEditor instanceof CategoryEditor) {
			CategoryEditor categoryEditor = (CategoryEditor) activeEditor;
			if(categoryEditor.createNatTable.getSelectionLayer().hasColumnSelection()) {
				categoryEditor.natTable.doCommand(new CopyDataToClipboardCommand("\t", "\n", categoryEditor.natTable.getConfigRegistry()));
				CategoryEditor.colIndex = 0;
				CategoryEditor.rowIndex = 0;	
				copyFlag = 1;
				ApplicationActionBarAdvisor.getInstance().pasteAction.setEnabled(true);
				if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
					ActivityLogView.activityLog.append("\n [INFO]: Data Copied");
				}
			}
		}
		
	}

}
