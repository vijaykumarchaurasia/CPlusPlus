package com.navistar.datadictionary.action;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.ui.views.ActivityLogView;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * The ImportRecentlyImportedProjectAction is used for clearing list of recently imported project.
 * 
 * @author vijayk13
 *
 */
public class ImportRecentlyImportedProjectAction extends Action implements IWorkbenchAction{
	
	/** The ID used for ImportRecentlyImportedProjectAction class */
	private static final String RCNT_PROJ_LIST = "com.navistar.datadictionary.RecentlyImportedProjectsAction";
	
	/**
	 * The default constructor  is used for setting ID for ImportRecentlyImportedProjectAction class 
	 */
	public ImportRecentlyImportedProjectAction() {	
		setId(RCNT_PROJ_LIST);
	}
	
	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}
	
	/**
	 * the run method is used to import recently imported project from file system through
	 * directoryDialog box.
	 *
	 */
	@Override
	public void run() {
		ImportProjectAction importProjAction = new ImportProjectAction();
		boolean result = false;
		result = MessageDialog.openConfirm(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), "Confirm", "Are you sure, you want to import the project?");
		if(result) {
			if (this.getText() != null) {
				Object objArr[] = importProjAction.createImportProjectStructure(this.getText(), 0, "");
				if(objArr!=null) {
					TreeViewer treeViewer = (TreeViewer) objArr[1];
					boolean checkImpProjErr = (boolean) objArr[0];
					if(!checkImpProjErr) {
						if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
							ActivityLogView.activityLog.append("\n [INFO]: Imported Project Path : "+this.getText());
						}
					}
					if(treeViewer==null)
					{
						MessageDialog.openInformation(new Shell(), ApplicationConstant.WARNING, ApplicationConstant.PROJECT_EXIST);
					}
				}else {
					MessageDialog.openInformation(new Shell(), ApplicationConstant.WARNING, ApplicationConstant.PROJECT_EXIST);
				}
			}
		}
	}

}
