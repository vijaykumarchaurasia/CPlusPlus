package com.navistar.datadictionary.action;

import org.eclipse.jface.action.Action;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;


/**
 * The MinMaxInfoAction class provides Min Max view action. 
 * 
 * @author JAYSHRIVISHB
 *
 */
public class MinMaxInfoAction extends Action implements IWorkbenchAction{

	/**  The ID used for TableEditorAction class */
	private static final String MIN_MAX_INFO_ID = "com.navistar.datadictionary.TableEditorAction";
	
	/**
	 * The constructor is used for setting ID for MinMaxInfoAction class.
	 */
	public MinMaxInfoAction() {
		setId(MIN_MAX_INFO_ID);
	}
	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}

}
