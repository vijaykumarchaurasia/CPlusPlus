package com.navistar.datadictionary.action;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.service.IOCompatibilityService;
import com.navistar.datadictionary.service.OpenProjectService;
import com.navistar.datadictionary.serviceimpl.IOCompatibilityServiceImpl;
import com.navistar.datadictionary.serviceimpl.OpenProjectServiceImpl;
import com.navistar.datadictionary.ui.config.Application;
import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.ui.views.ActivityLogView;
import com.navistar.datadictionary.ui.views.IOCompatibilityView;
import com.navistar.datadictionary.util.ViewUtil;


/**
 * The IoCompatibilityAction class provides IoCompatibility feature.
 * 
 * @author vijayk13
 *
 */
public class IOCompatibilityAction extends Action implements IWorkbenchAction {

	/** The ID used IoCompatibilityAction class */
	private static final String IO_COMPAT_ID = "com.navistar.datadictionary.IoCompatibilityAction";
	
	//io refresh issue after Use this object automatic call
	public static boolean ioFlag = false;
	/**
	 * The default constructor is used for setting ID for IoCompatibilityAction
	 * class.
	 */
	public IOCompatibilityAction() {

		setId(IO_COMPAT_ID);

	}

	/**
	 * This method is used to execute the Check I/O Compatibility action.
	 */
	@Override
	public void run() {
		ApplicationActionBarAdvisor.getInstance().action = ApplicationActionBarAdvisor
				.getInstance().ioCompatAction;
		OpenProjectService openProjService = new OpenProjectServiceImpl();
		String openedProject = openProjService.getOpenedProjectName();
		IOCompatibilityService iocompatibilityService = new IOCompatibilityServiceImpl();
		ioFlag = true;
		if(Application.programName.equals("E95"))
		{
			if(!iocompatibilityService.getArxmlPath())
			{
				MessageDialog.openInformation(new Shell(),"Information", "No ARXML file present in selected project.");
				return;
			}
			
			else
			{
			if (IOCompatibilityView.getIOCompatibilityViewInstance() != null) {
				IOCompatibilityView.getIOCompatibilityViewInstance().createIOPartControl();
				if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
					ActivityLogView.activityLog.append("\n [INFO]: Generated IO Compatibility Data For Project : "+openedProject);
				}
			} else {
				ViewUtil.showHideView(ViewIDConstant.CHECK_IO_COMPAT, true);
				if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
					ActivityLogView.activityLog.append("\n [INFO]: Generated IO Compatibility Data For Project : "+openedProject);
				}
			}
			}
		}
			else
			{

				if (IOCompatibilityView.getIOCompatibilityViewInstance() != null) {
					IOCompatibilityView.getIOCompatibilityViewInstance().createIOPartControl();
					if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
						ActivityLogView.activityLog.append("\n [INFO]: Generated IO Compatibility Data For Project : "+openedProject);
					}
				} else {
					ViewUtil.showHideView(ViewIDConstant.CHECK_IO_COMPAT, true);
					if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
						ActivityLogView.activityLog.append("\n [INFO]: Generated IO Compatibility Data For Project : "+openedProject);
					}
				}
				
			}
		}
	


	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}
}
