package com.navistar.datadictionary.action;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IContributionItem;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.IconsPathConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.daoimpl.MatlabEngineConnectionDaoImpl;
import com.navistar.datadictionary.model.FontStyleDAO;
import com.navistar.datadictionary.model.Node;
import com.navistar.datadictionary.model.Project;
import com.navistar.datadictionary.serviceimpl.ImportProjectServiceImpl;
import com.navistar.datadictionary.serviceimpl.OpenProjectServiceImpl;
import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.ui.config.ApplicationWorkbenchWindowAdvisor;
import com.navistar.datadictionary.ui.config.DataDictionaryApplication;
import com.navistar.datadictionary.ui.views.ActivityLogView;
import com.navistar.datadictionary.ui.views.ProjectExplorerView;
import com.navistar.datadictionary.util.NodeComparator;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * The ImportProjectAction is used to import project in project explorer.
 * 
 * @author vijayk13
 *
 */
public class ImportProjectAction extends Action implements IWorkbenchAction {

	/** The shell is used for DirectoryDialog to import project from file system */
	private Shell shell;

	/** Used to add the project in tree */
	public static List<Node> nodes = new ArrayList<>();

	/** It is used to store index of open project */
	public static int index = 0;

	/** The ID used for ImportProjectAction class */
	private static final String IMPORT_PROJ_ID = "com.navistar.datadictionary.action.ImportProjectAction";

	private ImportProjectServiceImpl importProjService;

	/** Used to get the current display */
	private Device device;

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(ImportProjectAction.class);
	
	/**
	 * The constructor is used to set Id and initialize the shell for
	 * ImportProjectAction.
	 */
	public ImportProjectAction() {
		setId(IMPORT_PROJ_ID);
		shell = new Shell();
		importProjService = new ImportProjectServiceImpl();
		device = PlatformUI.getWorkbench().getDisplay();
	}

	/**
	 * the run method is used to import project from file system through
	 * directoryDialog box.
	 *
	 */
	@Override
	public void run() {
		String path = importProjService.openDirectoryDialog(shell);
		int importProjStatus = 0;

		// This is used to check valid path is chosen or not
		if (ApplicationConstant.INVALID.equals(path)) {
			MessageDialog.openWarning(shell, ApplicationConstant.WARNING, ApplicationConstant.IMPORT_PROJ_EXCE);

		} else if (path != null) {
			// called method to create import project structure.
			Object objArr[] = createImportProjectStructure(path, importProjStatus, "");
			if(objArr!=null) {
				boolean checkImpProjErr = (boolean) objArr[0];
				TreeViewer treeViewer = (TreeViewer) objArr[1];
				if (treeViewer == null) {
					MessageDialog.openWarning(new Shell(), ApplicationConstant.WARNING, ApplicationConstant.PROJECT_EXIST);
				} else if(!checkImpProjErr){
					IWorkbenchAction projectPath = new ImportRecentlyImportedProjectAction();
					projectPath.setText(path);
					projectPath.setEnabled(true);
					boolean flag = false;
					if (ApplicationActionBarAdvisor.pathList.size() == 6) {
						if (!ApplicationActionBarAdvisor.pathList.contains(path)) {
							ApplicationActionBarAdvisor.pathList.remove(0);
							ApplicationActionBarAdvisor.pathList.add(path);
							flag = true;
						}
					} else {
						if (!ApplicationActionBarAdvisor.pathList.contains(path)) {
							ApplicationActionBarAdvisor.pathList.add(path);
							flag = true;
						}

					}
					IContributionItem[] items = ApplicationActionBarAdvisor.recentimportMenu.getItems();
					if (flag) {
						if (items.length == 2) {
							ApplicationActionBarAdvisor.recentimportMenu.removeAll();
							ApplicationActionBarAdvisor.recentimportMenu.add(projectPath);
							IWorkbenchAction clearListAction = new ClearListAction();
							clearListAction.setText("Clear List");
							clearListAction.setEnabled(true);
							ApplicationActionBarAdvisor.recentimportMenu.add(new Separator());
							ApplicationActionBarAdvisor.recentimportMenu.add(clearListAction);
							ApplicationActionBarAdvisor.recentimportMenu.saveWidgetState();
						} else {
							ApplicationActionBarAdvisor.recentimportMenu.removeAll();
							for (int i = ApplicationActionBarAdvisor.pathList.size() - 1; i >= 0; i--) {
								IWorkbenchAction itemPath = new ImportRecentlyImportedProjectAction();
								itemPath.setText(ApplicationActionBarAdvisor.pathList.get(i));
								itemPath.setEnabled(true);
								ApplicationActionBarAdvisor.recentimportMenu.add(itemPath);
							}
							IWorkbenchAction clearListAction = new ClearListAction();
							clearListAction.setText("Clear List");
							clearListAction.setEnabled(true);
							ApplicationActionBarAdvisor.recentimportMenu.add(new Separator());
							ApplicationActionBarAdvisor.recentimportMenu.add(clearListAction);
							ApplicationActionBarAdvisor.recentimportMenu.saveWidgetState();
						}
					}
					if (ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
						ActivityLogView.activityLog.append("\n [INFO]: Imported Project Path : " + path);
					}
				}
			}else {
				MessageDialog.openWarning(new Shell(), ApplicationConstant.WARNING, ApplicationConstant.PROJECT_EXIST);
			}
		}
		ApplicationWorkbenchWindowAdvisor.configurer.getWindow().getShell().forceActive();
	}

	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		// Nothing to clean-up
	}

	public void resetProjectStatus() {
		HierarchicalViewAction hierarchiViewObj = new HierarchicalViewAction();
		AlphabeticalViewAction alphabetiViewObj = new AlphabeticalViewAction();
		TreeItem itemList[] = ProjectExplorerView.viewer.getTree().getItems();
		Image projectImage = new Image(PlatformUI.getWorkbench().getDisplay(), OpenProjectServiceImpl.class.getResourceAsStream(IconsPathConstant.OPEN_PROJECT_ICON));
		Image closedProjImage = new Image(PlatformUI.getWorkbench().getDisplay(),OpenProjectServiceImpl.class.getResourceAsStream(IconsPathConstant.CLOSE_PROJ_ICON));
		Image componentImage = new Image(PlatformUI.getWorkbench().getDisplay(),OpenProjectServiceImpl.class.getResourceAsStream(IconsPathConstant.ICON_COMPONENT));
		Image moduleImage = new Image(PlatformUI.getWorkbench().getDisplay(),OpenProjectServiceImpl.class.getResourceAsStream(IconsPathConstant.ICON_MODULE));
		FontStyleDAO fontStyle = DataDictionaryApplication.getApplication().fontStyle;
		Font fontStyleNormal;
		Font fontStyleBold;
		Color openProjectColor;
		if(fontStyle != null && fontStyle.getFont() != null && !EditorPreference.isDefFontSel) {
			fontStyleNormal = new Font(device, fontStyle.getFont(), fontStyle.getSize(), SWT.NORMAL);
			fontStyleBold = new Font(device, fontStyle.getFont(),fontStyle.getSize(), SWT.BOLD);
			openProjectColor = new Color(device, fontStyle.getFontColor());
		} else {
			fontStyleNormal = new Font(device, ApplicationConstant.HIGHLIGHTFONTSTYL, ApplicationConstant.HIGHFONTSIZE, SWT.NORMAL);
			fontStyleBold = new Font(device, ApplicationConstant.HIGHLIGHTFONTSTYL,ApplicationConstant.HIGHFONTSIZE, SWT.BOLD);
			openProjectColor = new Color(device, ApplicationConstant.OPEN_PROJ_COLOR,ApplicationConstant.OPEN_PROJ_COLOR, ApplicationConstant.OPEN_PROJ_COLOR);
		}
		Color closeProjectColor = new Color(device, ApplicationConstant.CLOSE_PROJ_COLOR,ApplicationConstant.CLOSE_PROJ_COLOR, ApplicationConstant.CLOSE_PROJ_COLOR);
		for (String projectPath : DataDictionaryApplication.getApplication().projStatusMap.keySet()) {

			try {
				String folder[] = projectPath.split("\\\\");
				String projectName = folder[folder.length - 1];

				if (DataDictionaryApplication.getApplication().projStatusMap.get(projectPath).getStatus() == 0) {
					for (TreeItem treeItem1 : itemList) {

						if (projectName.equals(treeItem1.getText())) {
							treeItem1.setImage(closedProjImage);
							treeItem1.setForeground(closeProjectColor);
							treeItem1.setFont(fontStyleNormal);
							treeItem1.setItemCount(ApplicationConstant.CLOSEPROJITEMCNT);

						}
					}
				} else if (DataDictionaryApplication.getApplication().projStatusMap.get(projectPath)
						.getStatus() == 1) {
					int treeItemCount = 0;
					int indexAfterSort = 0;

					for (TreeItem item : itemList) {

						if (projectName.equals(item.getText())) {
							item.setImage(projectImage);
							indexAfterSort = treeItemCount;
							//if(Application.configCatList.contains("Input") && Application.configCatList.contains("Output")) {
								//ApplicationActionBarAdvisor.getInstance().ioCompatAction.setEnabled(true);
							//}
							//ApplicationActionBarAdvisor.getInstance().validProjAction.setEnabled(true);
							//ApplicationActionBarAdvisor.getInstance().validateProjParaTypeAction.setEnabled(true);
							item.setForeground(openProjectColor);
							item.setFont(fontStyleBold);
							item.setItemCount(nodes.get(indexAfterSort).getSubCategories().size());
							TreeItem[] treeChildItems = item.getItems();
							for (TreeItem childItem : treeChildItems) {
								if (childItem.getItems().length > 0) {
									childItem.setImage(moduleImage);
								} else {
									childItem.setImage(componentImage);
								}
								// Make the closed component un-highlighted
								childItem.setForeground(closeProjectColor);
								childItem.setFont(fontStyleNormal);

								// Make the open component highlighted
								// Change Component Highlight to blue and change color constant name
								if (ProjectExplorerView.getActiveProject().getComponentPath() != null) {
									File componentFile = new File(
											ProjectExplorerView.getActiveProject().getComponentPath());
									String openedCompName = FilenameUtils.getBaseName(componentFile.getName());
									if (openedCompName.equals(childItem.getText())) {
										childItem.setForeground(openProjectColor);
										childItem.setFont(fontStyleBold);
									}
								}
							}
						}
						treeItemCount += 1;
					}
					ProjectExplorerView.viewer.setExpandedState(nodes.get(indexAfterSort),
							!ProjectExplorerView.viewer.getExpandedState(indexAfterSort));

					if (ProjectExplorerView.hierarchialView) {
						hierarchiViewObj.performHierarchicalAction();
					} else {
						alphabetiViewObj.performAlphabeticalAction();
					}
				}
			} catch (Exception exception) {
				LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, exception);
			}

		}

	}

	/**
	 * Function used to get a project with component list and set it to TreeViewer
	 * 
	 * @param filepath
	 * @param importStatus
	 * @param componentPath
	 */
	public Object[] createImportProjectStructure(String filePath, int importStatus, String componentPath) {

		// check project already exists in the view
		boolean projExistStatus = checkForProjectExistInView(filePath);
		boolean projErr = false;
		if (!projExistStatus) {
			// Check if project exist in Workspace

			if (DataDictionaryApplication.getApplication().projStatusMap.get(filePath) == null
					|| DataDictionaryApplication.getApplication().projStatusMap.get(filePath)
							.getStatus() == ApplicationConstant.REMOVEPROJSTATUS) {

				final ImportProjectServiceImpl importUtilService = new ImportProjectServiceImpl(); // Add in constructor
				final File parentFileObject = new File(filePath); // Add in constructor

				Node category = null; // Change Variable Name
				try {
					category = importUtilService.createTreeStructure(filePath, importStatus);
					if(category!=null) {
					if (nodes.isEmpty()) {
						nodes.add(category);
					} else if (!checkNode(category.getName())) { // Check the logic
						nodes.add(category);
					}
					
					// maintain every project status
					DataDictionaryApplication.getApplication().projStatusMap = importUtilService.setProjectandStaus(
							DataDictionaryApplication.getApplication().projStatusMap, parentFileObject.getPath(),
							importStatus, componentPath);
					Collections.sort(nodes, new NodeComparator());
					ProjectExplorerView.viewer.setInput(nodes);

					HierarchicalViewAction hierarchiViewObj = new HierarchicalViewAction();
					// check if existing project is in hierarchical view
					if (ProjectExplorerView.hierarchialView) {
						hierarchiViewObj.performHierarchicalAction();
					}

					resetProjectStatus();
					
					FontStyleDAO fontStyle = DataDictionaryApplication.getApplication().fontStyle;
					Font openProjectFont;
					Font closeProjectFont;
					Color openProjectColor;
					Color closeProjectColor = new Color(device, ApplicationConstant.CLOSE_PROJ_COLOR,
							ApplicationConstant.CLOSE_PROJ_COLOR, ApplicationConstant.CLOSE_PROJ_COLOR);
					//If font is set and store default font is not set then apply the selected font else set default font
					//If user selected font greater than 12 then for project explorer set it to 12
					if (fontStyle != null && fontStyle.getFont() != null && !EditorPreference.isDefFontSel) {
						int fontSize = fontStyle.getSize();
						if (fontSize > 12) {
							fontSize = 12;
						}
						openProjectFont = new Font(device, fontStyle.getFont(), fontSize, SWT.BOLD);
						closeProjectFont = new Font(device, fontStyle.getFont(), fontSize, SWT.NORMAL);
						openProjectColor = new Color(device, fontStyle.getFontColor());
					} else {
						openProjectFont = new Font(device, ApplicationConstant.FONT_STYLE,
								ApplicationConstant.HIGHFONTSIZE, SWT.BOLD);
						closeProjectFont = new Font(device, ApplicationConstant.FONT_STYLE,
								ApplicationConstant.HIGHFONTSIZE, SWT.NORMAL);
						openProjectColor = new Color(device, ApplicationConstant.OPEN_PROJ_COLOR,
								ApplicationConstant.OPEN_PROJ_COLOR, ApplicationConstant.OPEN_PROJ_COLOR);
					}
					setProjectStyle(openProjectFont, closeProjectFont, openProjectColor, closeProjectColor);
					
					}else {
						ViewUtil.dispInfoInMsgDialog("Please import valid project");
						projErr = true;
					}
					
				} catch (MatlabCommunicatinException e) {
					projErr = true;
					MessageDialog.openConfirm(new Shell(), "Error Message", e.getMessage());
					

				}
				Object objArr[] = new Object[2];
				objArr[0] = projErr;
				objArr[1] = ProjectExplorerView.viewer;
				return objArr;
				
			} else {
				return null;
			}
		} else {
			return null;
		}
	}
	
	public void setProjectStyle(Font openProjectFont, Font closeProjectFont, Color openProjectColor,
			Color closeProjectColor) {
		Image projectImage = new Image(PlatformUI.getWorkbench().getDisplay(),
				OpenProjectServiceImpl.class.getResourceAsStream(IconsPathConstant.OPEN_PROJECT_ICON));
		Image closedProjImage = new Image(PlatformUI.getWorkbench().getDisplay(),
				OpenProjectServiceImpl.class.getResourceAsStream(IconsPathConstant.CLOSE_PROJ_ICON));
		Image componentImage = new Image(PlatformUI.getWorkbench().getDisplay(),
				OpenProjectServiceImpl.class.getResourceAsStream(IconsPathConstant.ICON_COMPONENT));
		Image moduleImage = new Image(PlatformUI.getWorkbench().getDisplay(),
				OpenProjectServiceImpl.class.getResourceAsStream(IconsPathConstant.ICON_MODULE));
		TreeItem[] items = ProjectExplorerView.viewer.getTree().getItems();
		for (TreeItem item : items) {
			if (item.getItemCount() != 0) {
				item.setImage(projectImage);
				item.setForeground(openProjectColor);
				item.setFont(openProjectFont);
				TreeItem[] treeChildItems = item.getItems();

				for (TreeItem childItem : treeChildItems) {
					if (childItem.getItems().length > 0) {
						childItem.setImage(moduleImage);
					} else {
						childItem.setImage(componentImage);
					}
					// Make the closed component un-highlighted
					childItem.setForeground(closeProjectColor);
					childItem.setFont(closeProjectFont);
					// Make the open component highlighted
					// Change Component Highlight to blue and change color constant name

					if (ProjectExplorerView.getActiveProject() != null) {
						if (ProjectExplorerView.getActiveProject().getComponentPath() != null) {
							File componentFile = new File(ProjectExplorerView.getActiveProject().getComponentPath());
							String openedCompName = FilenameUtils.getBaseName(componentFile.getName());
							if (openedCompName.equals(childItem.getText())) {
								childItem.setForeground(openProjectColor);
								childItem.setFont(openProjectFont);
							}
						}
					}
				}
			} else {
				item.setImage(closedProjImage);
				item.setForeground(closeProjectColor);
				item.setFont(closeProjectFont);
			}
		}
	}

	/**
	 * Function used to check if project exist in node
	 * 
	 * @param name
	 * @return
	 */
	private boolean checkNode(String name) {
		for (Node node : nodes) {
			if (node.getName().equals(name)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Method used to check if imported project already exists in project explorer
	 * view
	 * 
	 * @param filePath
	 * @return
	 */
	private boolean checkForProjectExistInView(String filePath) {
		boolean projExistStatus = false;
		File importedProject = new File(filePath);
		String importProjectName = importedProject.getName();

		for (String projectPath : DataDictionaryApplication.getApplication().projStatusMap.keySet()) {

			File projectObj = new File(projectPath);
			if (importProjectName.equals(projectObj.getName())
					&& DataDictionaryApplication.getApplication().projStatusMap.get(projectPath)
							.getStatus() != ApplicationConstant.REMOVEPROJSTATUS) {
				projExistStatus = true;
			}
		}
		return projExistStatus;
	}

	/**
	 * This method is used to load the project status from workspace
	 * 
	 * @param viewer
	 * @param nodes
	 */
	public void loadProjectStatusFromWorkspace(TreeViewer viewer, List<Node> nodes) {
        Map<String, Project> projectStatusMap = DataDictionaryApplication.getApplication().projStatusMap.entrySet()
                                             .stream()
                                             .sorted(Entry.comparingByValue(OpenProjectServiceImpl::compare))
                                             .collect(Collectors.toMap(Entry::getKey, Entry::getValue,
                                                     (e1, e2) -> e1, LinkedHashMap::new));    

		Tree tree = viewer.getTree();
		TreeItem[] allTreeItems = viewer.getTree().getItems();
		Image projectImage = new Image(PlatformUI.getWorkbench().getDisplay(), ImportProjectAction.class.getResourceAsStream(IconsPathConstant.OPEN_PROJECT_ICON));
		Image closedProjImage = new Image(PlatformUI.getWorkbench().getDisplay(), ImportProjectAction.class.getResourceAsStream(IconsPathConstant.CLOSE_PROJ_ICON));
		FontStyleDAO fontStyle = DataDictionaryApplication.getApplication().fontStyle;
		Font fontStyleNormal;
		Font fontStyleBold;
		Color openProjectColor;
		if(fontStyle != null && fontStyle.getFont() != null && !EditorPreference.isDefFontSel) {
			fontStyleNormal = new Font(device, fontStyle.getFont(), fontStyle.getSize(), SWT.NORMAL);
			fontStyleBold = new Font(device, fontStyle.getFont(),fontStyle.getSize(), SWT.BOLD);
			openProjectColor = new Color(device, fontStyle.getFontColor());
		} else {
			fontStyleNormal = new Font(device, ApplicationConstant.HIGHLIGHTFONTSTYL, ApplicationConstant.HIGHFONTSIZE, SWT.NORMAL);
			fontStyleBold = new Font(device, ApplicationConstant.HIGHLIGHTFONTSTYL,ApplicationConstant.HIGHFONTSIZE, SWT.BOLD);
			openProjectColor = new Color(device, ApplicationConstant.OPEN_PROJ_COLOR,ApplicationConstant.OPEN_PROJ_COLOR, ApplicationConstant.OPEN_PROJ_COLOR);
		}
		int flag = 0;
		int currentIdx = 0;
		String openProjectName = null;
		Node openNode = null;
		for (String key : projectStatusMap.keySet()) {
			if (ApplicationConstant.OPEN_PROJ_STATUS == projectStatusMap.get(key).getStatus()) {
				String folders[] = key.split("\\\\");
				openProjectName = folders[folders.length - 1];
				new MatlabEngineConnectionDaoImpl().addProjectPath(projectStatusMap.get(key).getPath());
				flag = 1;
				break;
			}
		}
		Color closeProjectColor = new Color(PlatformUI.getWorkbench().getDisplay(),ApplicationConstant.CLOSE_PROJ_COLOR, ApplicationConstant.CLOSE_PROJ_COLOR,ApplicationConstant.CLOSE_PROJ_COLOR);
		if (flag == 1) {
			for (TreeItem treeItem1 : allTreeItems) {
				if (openProjectName.equals(treeItem1.getText())) {
						
					treeItem1.setImage(projectImage);
					treeItem1.setFont(fontStyleBold);
					treeItem1.setForeground(openProjectColor);
					index = currentIdx;
					break;
				}
				currentIdx = currentIdx + 1;
			}
			openNode = nodes.get(index);

			viewer.setExpandedState(openNode, !viewer.getExpandedState(openNode));

			// Disable all the project logic start here
			for (currentIdx = 0; currentIdx < allTreeItems.length; currentIdx++) {
				if (currentIdx != index) {
					// close project image
					tree.getItem(currentIdx).setItemCount(ApplicationConstant.CLOSEPROJITEMCNT);
					tree.getItem(currentIdx).setImage(closedProjImage);
					tree.getItem(currentIdx).setFont(fontStyleNormal);
					tree.getItem(currentIdx).setForeground(closeProjectColor);
				} else {
					tree.getItem(currentIdx).setItemCount(openNode.getSubCategories().size());
				}
			}
		} else {
			for (currentIdx = 0; currentIdx < allTreeItems.length; currentIdx++) {
				tree.getItem(currentIdx).setItemCount(0);
				tree.getItem(currentIdx).setImage(closedProjImage);
				tree.getItem(currentIdx).setForeground(closeProjectColor);
				tree.getItem(currentIdx).setFont(fontStyleNormal);
			}
		}
	}
}