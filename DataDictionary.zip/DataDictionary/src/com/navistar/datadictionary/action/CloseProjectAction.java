package com.navistar.datadictionary.action;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.service.CloseProjectService;
import com.navistar.datadictionary.serviceimpl.CloseProjectServiceImpl;
import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.ui.config.DataDictionaryApplication;
import com.navistar.datadictionary.ui.views.ActivityLogView;
import com.navistar.datadictionary.ui.views.ProjectExplorerView;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * The CloseProjectAction is used for closing the project from the workspace
 * 
 * @author minalc
 *
 */
public class CloseProjectAction extends Action implements IWorkbenchAction{
	
	/** The ID is used for CloseProjectAction class */
	private static final String CLOSE_PROJ_ID = "com.navistar.datadictionary.action.CloseProjectAction";
	
	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(OpenProjectAction.class);
	
	/** 
	 * The default constructor is used for setting ID for CloseProjectAction class.
	 */
	public CloseProjectAction() {
		
		setId(CLOSE_PROJ_ID);
	}
	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}
	/**
	 * the run method is used to call close project action.
	 *
	 */
	@Override
	public void run() {
		try {
			CloseProjectService closeProjService = new CloseProjectServiceImpl();
			String projectName = "";
			String selectedProject = "";
			for (String projectPath : DataDictionaryApplication.getApplication().projStatusMap.keySet()) {
				String folder[] = projectPath.split("\\\\");
				projectName = folder[folder.length - 1];
				selectedProject = OpenProjectAction.openProjectName;
				if (DataDictionaryApplication.getApplication().projStatusMap.get(projectPath).getStatus() == 1
						&& projectName.equals(selectedProject)) {
					closeProjService.performCloseProjectAction();
				}
			}
			ProjectExplorerView.getInstance().alphabeticalObj.setEnabled(false);
			ProjectExplorerView.getInstance().hierarchiViewObj.setEnabled(false);
			
			ApplicationActionBarAdvisor.getInstance().resolvInconObj.setEnabled(false);
			ApplicationActionBarAdvisor.getInstance().excelImportExport.setEnabled(false);
			ApplicationActionBarAdvisor.getInstance().searchAction.setEnabled(false);
			ApplicationActionBarAdvisor.getInstance().ioCompatAction.setEnabled(false);
			ApplicationActionBarAdvisor.getInstance().copyAction.setEnabled(false);
			ApplicationActionBarAdvisor.getInstance().cutAction.setEnabled(false);
			ApplicationActionBarAdvisor.getInstance().deleteAction.setEnabled(false);
			ApplicationActionBarAdvisor.getInstance().validProjAction.setEnabled(false);
			ApplicationActionBarAdvisor.getInstance().updateProjParaTypeAction.setEnabled(false);
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [INFO]: Closed Project : " + selectedProject);
			}
		}
		catch(Exception exception) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, exception);
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [ERROR]: "+MessageConstant.CLOSE_PROJ_ERROR);
			}
			MessageDialog.openError(new Shell(), "ERROR",MessageConstant.CLOSE_PROJ_ERROR);
			
		}
		//Application.programName = null;
	}


}