package com.navistar.datadictionary.action;

import org.eclipse.jface.action.Action;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

/**
 * The IoCompatibilityAction class provides IoCompatibility feature for window
 * action.
 * 
 * @author vijayk13
 *
 */
public class IOCompatibilityWindowAction extends Action implements IWorkbenchAction {

	/** The ID used IOCopatibilityWindowAction class */
	private static final String IO_WINDOW_ID = "com.navistar.datadictionary.action.IOCopatibilityWindowAction";

	/**
	 * The default constructor is used for setting ID for IoCompatibilityAction
	 * class.
	 */
	public IOCompatibilityWindowAction() {
		setId(IO_WINDOW_ID);
	}

	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}
}
