package com.navistar.datadictionary.action;

import org.eclipse.jface.action.Action;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

/**
 * The ProjectExplorerAction is used for set action for ProjectExplorer actions.
 * 
 * @author vijayk13
 *
 */
public class ProjectExplorerAction extends Action implements IWorkbenchAction{

	/**  The ID used for ProjectExplorerAction class */
	private static final String PROJ_EXPLORER_ID = "com.navistar.datadictionary.ProjectExplorerAction";
	
	/**
	 * The default constructor is used to set Id ProjectExplorerActions.
	 */
	public ProjectExplorerAction() {
		setId(PROJ_EXPLORER_ID);
	}
	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}

}
