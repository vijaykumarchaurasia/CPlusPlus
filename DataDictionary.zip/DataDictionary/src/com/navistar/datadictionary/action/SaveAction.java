package com.navistar.datadictionary.action;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.ui.editors.CategoryEditor;

/**
 * The SaveAction is used to Save the data of one category from the
 * component.
 * 
 * @author JAYSHRIVISHB
 *
 */
public class SaveAction extends Action implements IWorkbenchAction {

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(CategoryEditor.class);
	
	/** The ID used for SaveAction class */
	private static final String SAVA_ACTION_ID = "com.navistar.datadictionary.action.SaveAction";

	/**
	 * The constructor is used to set Id and initialize the shell for SaveAction.
	 */
	public SaveAction() {
		setId(SAVA_ACTION_ID);
	}

	/**
	 * the run method is used to call doSave of active editor
	 *
	 */
	@Override
	public void run() {
		SaveAllAction.saveAllFlg = false;
		try {
			IEditorPart activeEditorPart = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
					.getActiveEditor();
			NullProgressMonitor monitor = new NullProgressMonitor();
			// Check dirty is enabled or not
			if(activeEditorPart != null)
			{
				if (activeEditorPart.isDirty()) {
					activeEditorPart.doSave(monitor);
				}
			}
		} 
		catch (Exception e) {
			MessageDialog.openConfirm(new Shell(), "Error Message", "Error while performing save "+e.getMessage());
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
		}
	}

	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}
}
