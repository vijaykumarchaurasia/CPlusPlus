package com.navistar.datadictionary.action;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import com.google.gson.JsonElement;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.service.UpdateParameterTypeService;
import com.navistar.datadictionary.serviceimpl.UpdateParameterTypeServiceImpl;
import com.navistar.datadictionary.ui.views.ActivityLogView;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * The UpdateProjParaTypeAction class provides feature to Update parameters
 *  in opened project.
 * 
 * @author shalins
 *
 */
public class UpdateProjParaTypeAction extends Action implements IWorkbenchAction {
	
	/** The ID used UpdateProjParaTypeAction class */
	 
	static final String UPDATE_PRJ_PARA_TYPE_ID = "com.navistar.datadictionary.UpdateProjParaTypeAction";
	
	/**
	 * The default constructor is used for setting ID for UpdateProjParaTypeAction
	 * class.
	 */
	public UpdateProjParaTypeAction() {

		setId(UPDATE_PRJ_PARA_TYPE_ID);

	}

	/**
	 * This method is used to execute the Update Project Parameter type action.
	 */
	@Override
	public void run() {
		UpdateParameterTypeService vaParamService = new UpdateParameterTypeServiceImpl();
		
			
			IWorkbench workbench = PlatformUI.getWorkbench();
			IWorkbenchWindow activeWindow = workbench.getActiveWorkbenchWindow();
			IWorkbenchPage activePage = activeWindow.getActivePage();
			IEditorReference[] editors = activePage.getEditorReferences();
			boolean isDirty = false;
			for (IEditorReference ref : editors) {
				IEditorPart editorPart = ref.getEditor(false);
				if(editorPart != null && editorPart.isDirty()) {
					isDirty = true;
					break;
				}
			}
			if(isDirty){
				MessageDialog.openWarning(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), ApplicationConstant.WARNING , MessageConstant.SAVE_DATA_WARNING + "Update Project Parameter Type.");
			} else {
			try {
			MessageDialog dialog = new MessageDialog
					(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), 
							ApplicationConstant.WARNING, null,
							"Are you sure you want to update parameter object type of Cal, Axis, Curve and Map data objects to"
									+" AUTOSAR4.Parameter for opened project ?",  
									MessageDialog.CONFIRM,
					new String[] { ApplicationConstant.BTN_YES, ApplicationConstant.BTN_NO }, 0);
			int result = dialog.open();
			if (result == 0) {
				JsonElement jsonElement = vaParamService.updateValPrjParaType();
				if(jsonElement!=null) {
					//String response = jsonElement.getAsJsonArray().get(0).getAsJsonObject().get("messageCode").getAsString();	
						ViewUtil.dispInfoInMsgDialog("Parameter object type updated successfully for Calibration, Axis, Curve and Map data objects.");
	
				}
			}
			
		} catch (MatlabCommunicatinException e) {
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [ERROR]: "+e.getMessage());
			}
			ViewUtil.dispConfirmDialog("Error Message", e.getMessage());
		}

	}
}


	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}
}

