package com.navistar.datadictionary.action;

import org.eclipse.jface.action.Action;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

/**
 * The SearchWindowAction class is used for searching feature action for window menu.
 * 
 * @author vijayk13
 *
 */
public class SearchWindowAction extends Action implements IWorkbenchAction{
	
	/**  The ID used for SearchWindowAction class */
	private static final String SEARCH_WINDOW_ID = "com.navistar.datadictionary.SearchWindowAction";
	
	/**
	 * The default constructor is used to set Id SearchWindowAction
	 */
	public SearchWindowAction() {
		setId(SEARCH_WINDOW_ID);
	}
	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}

}
