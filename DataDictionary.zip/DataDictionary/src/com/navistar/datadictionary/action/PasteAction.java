package com.navistar.datadictionary.action;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.dnd.Clipboard;
import org.eclipse.swt.dnd.TextTransfer;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.ui.views.ActivityLogView;
import com.navistar.datadictionary.util.ViewUtil;


/**
 * PasteAction used to paste the data from clipboard
 * @author raeesm
 *
 */
public class PasteAction extends Action implements IWorkbenchAction {

	/** Paste Action ID	 */
	private static final String PASTE_ACTION_ID = "com.navistar.datadictionary.action.PasteAction";
	
	/** Default Constructor */
	public PasteAction() {
		setId(PASTE_ACTION_ID);
		setActionDefinitionId("DataDictionary.paste");
	}

	/** Execute Paste Action*/
	@Override
	public void run() {
		try {
			CategoryEditor categoryEditor = null;
			IEditorPart editor = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor();
			if(editor instanceof CategoryEditor){
				categoryEditor = (CategoryEditor)editor;
				Clipboard clipboard = new Clipboard(Display.getCurrent());
				TextTransfer textTransfer = TextTransfer.getInstance();
				String data = (String) clipboard.getContents(textTransfer);
				categoryEditor.sortDataBeforePaste(data);
				if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
					ActivityLogView.activityLog.append("\n [INFO]: Data Pasted");
				}
				ApplicationActionBarAdvisor.getInstance().cutAction.setEnabled(false);
				ApplicationActionBarAdvisor.getInstance().copyAction.setEnabled(false);
			}
		}
		catch(Exception e) {
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [ERROR]: "+e.getMessage());
				MessageDialog.openInformation(new Shell(), "Information", "Error While Performing Paste Operation, please check the following condition: \n1. Please select the cell to paste the data \n    OR \n2. Invalid Data Copied ");
			}
		}
		
	}
	
	/** Overridden Method (NON USE)*/
	@Override
	public void dispose() {
		// Nothing to clean up
		
	}
}
