package com.navistar.datadictionary.action;


import org.eclipse.jface.action.Action;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import com.navistar.datadictionary.ui.views.ApplyCdfView;

/**
 * The ApplyCdfxAction is used to apply values from cdfx file in the component.
 * 
 * @author nikitak1
 *
 */
public class ApplyCdfxAction extends Action implements IWorkbenchAction{

	/**  The ID used for ApplyCdfxAction class */
	private static final String APPLY_CDFX_ID = "com.navistar.datadictionary.ApplyCdfxAction";
	
	/** The viewer is used to set ContextMenuActions on it */
	TreeViewer viewer;
	
	ApplyCdfView window = new ApplyCdfView();
	
	/**
	 * The default constructor is used to set Id ApplyCdfxAction.
	 */
	public ApplyCdfxAction() {
		setId(APPLY_CDFX_ID);
	}
	public ApplyCdfxAction(TreeViewer viewer) {
		this.viewer = viewer;
	}
	/**
	 * run method is used handle action on clicking the option of context menu and icon click of Apply CDF.
	 * 
	 */
	public void run() {
		ApplyCdfView applyCdfView = new ApplyCdfView();
		applyCdfView.open();
	}
	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}

}
