package com.navistar.datadictionary.action;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.ui.nattable.NatTableOperation;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * The SaveAllAction is used to Save All the data in all the category from the component.
 * 
 * @author JAYSHRIVISHB
 *
 */
public class SaveAllAction extends Action implements IWorkbenchAction {

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(ViewUtil.class);

	/** The ID used for SaveAllAction class */
	private static final String SAVE_ALL_ID = "com.navistar.datadictionary.action.SaveAllAction";

	/** Save all flag */
	public static boolean saveAllFlg;

	/** Save all message if empty field*/
	public static String message;

	/** Save all message if duplicate name value*/
	public static String dupNameMsg;

	/**
	 * The constructor is used to set Id and initialize the shell for
	 * SaveAllAction.
	 */
	public SaveAllAction() {
		setId(SAVE_ALL_ID);
		saveAllFlg = false;
		message = "";
		dupNameMsg = "";
	}


	/**
	 * the run method is used to call doSave of all editors 
	 *
	 */
	@Override
	public void run() {

		try {

			// Get all editors having dirty bit enable
			IEditorPart[] dirtyEditors = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
					.getDirtyEditors();
			// Thread.sleep(2000);
			//MESSAGE += MessageConstant.INPUT_FOR_ADD_OBJECT_ERROR;
			message = MessageConstant.REQUIRED_FIELDS;
			//duplicateNameMessage += MessageConstant.DUPLICATE_NMAE_ADD_OBJECT_ERROR;
			dupNameMsg = MessageConstant.DUPLICATE_NAME;

			NullProgressMonitor monitor = new NullProgressMonitor();

			/*
			 * display.asyncExec(new Runnable() { public void run() {
			 */
			boolean emptyListFlag = false;
			ArrayList<CategoryAttributes> newlyAddedObjList = new ArrayList<>();
			IEditorPart editorPart = null;
			// Get all the newly added objects of editors having dirty bit enable
			for (IEditorPart iEditorPart : dirtyEditors) {

				CategoryEditor categoryEditor = (CategoryEditor) iEditorPart;
				categoryEditor.natTable.commitAndCloseActiveCellEditor();
				// Get all edited or newly added objects
				List<CategoryAttributes> categoryList = categoryEditor.getNewObjectsList();

				if (categoryList != null
						&& !categoryList.isEmpty()) {
					//To update dimension according to value/Initial value in category while save all 
					categoryEditor.setValueNDimWithoutTab(categoryList);
					categoryEditor.setUnitSymbWithoutTab(categoryList);
					
					newlyAddedObjList.addAll(categoryList);
				} else {
					if (CategoryEditor.duplicNameFlg) {
						dupNameMsg += "\n" + "'" + categoryEditor.getTitle() + "'" + "  "
								+ NatTableOperation.duplicateNameList;
						NatTableOperation.duplicateNameList = new ArrayList<>();
						emptyListFlag = true;
					}else if(categoryEditor.invalidNameFlag)
					{
						editorPart = iEditorPart;
						break;
					}
					else {
						if(categoryEditor.emptyFieldsFlag)
						{
							message += "\n" + "'" + categoryEditor.getTitle() + "'";
							emptyListFlag = true;
						}

					}

				}
				saveAllFlg = true;
				editorPart = iEditorPart;
			}

			if (emptyListFlag) {
				newlyAddedObjList = new ArrayList<>();
				// Add all editors newly added objects into common list
				CategoryEditor.allNewObjList = newlyAddedObjList;
			}
			CategoryEditor categoryEditor = (CategoryEditor) editorPart;
			if(categoryEditor!=null && categoryEditor.invalidNameFlag)
			{
				categoryEditor.invalidNameFlag = false;
				SaveAllAction.saveAllFlg = false;
				return;
				
			}
			
			CategoryEditor.allNewObjList = newlyAddedObjList;
			if(editorPart!=null)
			{
				editorPart.doSave(monitor);
			}
			else
			{
				return;
			}
			
		} catch (Exception e) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			MessageDialog.openConfirm(new Shell(), "Error Message","Error while performing save-all "+e.getMessage());
		}
	}


	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}
}

