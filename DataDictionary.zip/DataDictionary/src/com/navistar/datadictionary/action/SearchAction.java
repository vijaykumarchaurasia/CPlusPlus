package com.navistar.datadictionary.action;

import org.eclipse.jface.action.Action;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.ui.views.SearchWindow;

/**
 * Class is used for searching feature action
 * 
 * @author vijayk13
 *
 */
public class SearchAction extends Action implements IWorkbenchAction {

	/** The ID used SearchAction class */
	private static final String SEARCH_ACTION_ID = "com.navistar.datadictionary.SearchAction";

	/**
	 * The default constructor is used for setting ID for SearchAction class.
	 */
	public SearchAction() {
		setId(SEARCH_ACTION_ID);
	}

	/**
	 * This method is used to get Search Window view.
	 */
	@Override
	public void run() {
		// Set the action instance
		ApplicationActionBarAdvisor.getInstance().action = ApplicationActionBarAdvisor.getInstance().searchAction;
		//Open search window
		SearchWindow window = new SearchWindow();
		window.open();	

	}

	/**
	 * This method is used to dispose the search action
	 */
	@Override
	public void dispose() {
		// nothing to clean up
	}
}
