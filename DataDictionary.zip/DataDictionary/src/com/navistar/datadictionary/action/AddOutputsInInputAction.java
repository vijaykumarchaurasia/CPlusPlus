package com.navistar.datadictionary.action;

import org.eclipse.jface.action.Action;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.ui.views.AddDataObjectWindow;
import com.navistar.datadictionary.ui.views.OutputDataObjectsView;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Class used to add multiple Output data objects from project and browsed sldd
 * in Input category
 * 
 * @author nikitak1
 *
 */
public class AddOutputsInInputAction extends Action implements IWorkbenchAction{

	/**  The ID used for AddOutputsInInputAction class */
	private static final String ADD_OP_IN_IP_ID = "com.navistar.datadictionary.AddOutputsInInputAction";

	/**
	 * The default constructor is used to set Id AddOutputsInInputAction.
	 */
	public AddOutputsInInputAction() {
		setId(ADD_OP_IN_IP_ID);
	}

	/**
	 * the run method is used to call AddOutputsInInputAction
	 *
	 */
	@Override
	public void run() {
		IEditorPart editorPart = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
				.getActiveEditor();
		CategoryEditor editor = (CategoryEditor)editorPart;
		java.util.List<TreeItem> selItems = OutputDataObjectsView.getCheckOpList();
		
		//to get path of opened component if deleting data object on Category Editor
		if (editorPart instanceof CategoryEditor && editorPart.getTitle().equals("Input") && AddDataObjectWindow.dataObjectAddFlag){
			for(TreeItem item: selItems) {
				editor.selOutputDataObj = item.getText();
				CategoryAttributes newCatAttributes = null;
				if(AddDataObjectWindow.isBrowseOpen) {
					newCatAttributes = new OutputDataObjectsView().setDataOfInputAttributesBrowsed(item);
				}else {
					newCatAttributes = new OutputDataObjectsView().setDataOfInputAttributesAllOps(item);
				}
				editor.setAddDataObjectDetails(newCatAttributes);
			}
			//editor.setAddDataObjectDetails(item.getText());
			AddDataObjectWindow.isBrowseOpen = false;
			AddDataObjectWindow.dataObjectAddFlag = false;
		}
		if(ViewUtil.isViewOpen(ViewIDConstant.OUTPUT_DATA_OBJ)) {
			ViewUtil.closeView(ViewIDConstant.OUTPUT_DATA_OBJ);
		}
	}

	

	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}


}
