package com.navistar.datadictionary.action;

import org.eclipse.jface.action.Action;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

/**
 * The WelcomeNoteCustomAction class provides welcome window action.
 * 
 * @author vijayk13
 *
 */
public class WelcomeNoteCustomAction extends Action implements IWorkbenchAction{

	/**  The ID used for WelcomeNoteCustomAction class */
	private static final String CUSTOM_WEL_NOTE = "com.navistar.datadictionary.WelcomeNoteCustomAction";

	/**
	 * The default constructor is used for setting ID for WelcomeNoteCustomAction class.
	 */
	public WelcomeNoteCustomAction() {
		setId(CUSTOM_WEL_NOTE);
	}
	
	/**
	 * To dispose the action
	 */
	@Override
	public void dispose() {
		//Nothing to clean-up
	}

}
