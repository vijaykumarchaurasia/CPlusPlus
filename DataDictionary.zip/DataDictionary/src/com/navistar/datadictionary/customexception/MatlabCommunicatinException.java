package com.navistar.datadictionary.customexception;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.daoimpl.MatlabCommunicationDaoImpl;

/**
 * The MatlabCommunicatinException class is for handling exception regarding
 * matlab communication.
 * 
 * @author vijayk13
 *
 */

public class MatlabCommunicatinException extends Exception {

	/**
	 * Matlab Custom Exception Class
	 * serialVersionUID 
	 */
	private static final long serialVersionUID = 1L;
	
	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(MatlabCommunicationDaoImpl.class);

	/**
	 * Parameterized Constructor
	 * @param message
	 * @param e
	 */
	public MatlabCommunicatinException(String message, Exception exception) {
		super(message);
		LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, exception);
	}
}
