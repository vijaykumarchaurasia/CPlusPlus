package com.navistar.datadictionary.customexception;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.daoimpl.MatlabCommunicationDaoImpl;

/**
 * The EditorInitilizationException class is for handling exception regarding
 * editor initialization.
 * 
 * @author vijayk13
 *
 */

public class EditorInitilizationException extends Exception{

	/**
	 * Editor Initialize Custom Exception
	 * Serial Version ID
	 */
	private static final long serialVersionUID = 420337947655873381L;
	
	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(MatlabCommunicationDaoImpl.class);
	
	/**
	 * Parameterized constructor
	 * @param message
	 * @param e
	 */
	public EditorInitilizationException(String message , Exception exception) {
		super(message);
		LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, exception);
	}

}
