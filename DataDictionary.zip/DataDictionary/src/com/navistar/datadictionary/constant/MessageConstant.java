package com.navistar.datadictionary.constant;

/**
 * This interface collected constants for messages to show in message dialog
 * @author minalc
 *
 */
public interface MessageConstant {

	/** Matlab Error Constant */
	String FETCH_SLDD_ERROR = "Selected component does not contain data";
	/** Save Error Constant */
	String SAVE_SCRIPT_ERROR = "Error occured while saving data";
	/** required field message */
	String REQUIRED_FIELDS = "Please enter required fields for ";
	/** duplicate name error message */
	String DUPLICATE_NAME = "Please change name from ";
	/** Matlab Error Constant for fail add data object */
	String SAVE_ERROR = "Saving data fail for : ";
	/** Matlab Error Constant for successful add data object */
	String SAVE_SUCCESS = "Data saved successfully";
	/** Matlab Error Constant */
	String FETCH_DATA_ERROR = "Error occured while loading the component data";
	/** Matlab Connection Message constant */
	String CONNECTION_MSG = "Matlab session is not started as shared session.\nStarting new Matlab Shared session...";
	/** Save all message */
	String SAVE_ALL_MESSAGE = "Do you want to save all categories ?";

	/** IO Compatibility Error Message */
	String IO_COMP_ERROR = "I/O Compatibility Not found.";
	String ATTR_NOT_FOUND = "Same I/O but different Attributes list not found.";
	String DATA_NOT_FOUND = "Identical data object not found.";
	String OP_SGNL_NFOUND = "Output signal not found.";
	String IN_SGNL_NOT_FOUND = "Input signal not found.";
	String DELETE_DATA = "Are you sure, you want to delete the selected data object(s)?";
	String DELETE_SUCCESS = "Data Deleted Successfully!";
	String IO_COMP_ARXML_ERROR = "No ARXML file found under current path.";
	
	/** Exception occurred message in log */
	String EXCEPTION_IN_LOG = "An Exception was thrown";
	String DELETE_DATA_ERROR = "Selected data object cannot be deleted";
	String REMOVE_PROJECT = "Please close the selected project(s) to remove";
	String REMOVE_COMPONENT = "You can not remove selected component";
	String MODEL_NOT_FOUND = "Model Not Found";
	String OBJECT_NOT_FOUND = "Data Object Not Found In Model";
	
	String SLOPE_NUMBER_VAL = "Please Enter Valid Value.\n 1. Value should be a number. \n 2. Value should be greater than or equal to zero.";
	String TABLE_VIEW_VAL = "Please Enter Valid Value. \n 1. Value should be a number.";
	String MIN_MAX_RANGE_VAL = "Please Enter Valid Value.\\n 1. Value should be a number. \n 2. Value should be within specified output minimum and output maximum range.";
	String OFFSET_NUMBER_VAL = "Please Enter Valid Value.\n 1. Value should be a number. \n 2. Value can be greater/lesser than or equal to zero."; 
	String INITIAL_VALUE_VAL = "Please Enter Valid Value. \n 1. Value should be a number. \n 2. Enter value seperated by (,) comma for multiple columns. E.g. [1,2,3]"
			+ "\n 3. Multiple Rows are not allowed.";
	String VAL_COLUMN_VAL_1 = "Please Enter Valid Value. \n 1. Value should be a number. \n 2. Enter value seperated by (,) comma for multiple columns. E.g. [1,2,3]"
			+ "\n 3. Multiple Rows are not allowed for this category.";
	String VAL_COLUMN_VAL_2 = "Please Enter Valid Value.  \n 1. Value should be a number. \n 2. Multiple Rows and Columns not allowed for this category.";
	String VAL_COLUMN_VAL_3 = "Please Enter Valid Value.   \n 1. Value should be a number. \n 2. For Multiple Rows enter value seperated by [] square bracket.\n     E.g. [1,2][1,2]"
			+ "\n 3. Enter value seperated by (,) comma for multiple columns. E.g. [1,2,3]";
	String NUMBER_RANGE_VAL = "Please enter number within the range of selected base type";
	String MIN_MAX_VAL = "Maximum must be greater than minimum value";
	
	String NAME_VAL = "Please enter valid name";;
	String UNIQUE_NAME_VAL = "Data object exist for same name";
	
	String OFFSET_VAL = "Please Enter Offset Value.";
	String SLOPE_VAL = "Please Enter Slope Value";
	String BASE_TYPE_VAL = "Please select Base Type";
	
	
	String RM_PROJ_CONFIRM = "Are you sure, you want to remove the selected project(s)?";
	
	/** Edit violation message for name */
	String EDIT_MESSAGE  = "Could not rename the variable.";
	String EDIT_MESSAGE1  = " is not a valid MATLAB variable name.";
	String EDIT_MESSAGE2  = "MATLAB variable names must : ";
	String EDIT_MESSAGE3  = "- Begin with a letter";
	String EDIT_MESSAGE4  = "- Contain only alphanumeric characters and underscores";
	String EDIT_MESSAGE5  = "- Not a MATLAB keyword";
	String EDIT_MESSAGE6  = "- Not exceed 63 characters in length";
	
	/** Edit violation message for number */
	String EDIT_VIO_FOR_NUM = "Value/Initial value must be within the range of Min and Max";
	
	/** Search Action constants */
	String SEARCH_NOT_FOUND = "0 matches in Target Search";
	String WILD_CARD_CHAR = "*";
	String CASE_SNSTV_PTRN = ".*";
	
	String NO_INCONSI_FOUND = "No inconsistencies found";
	String NAME_FOR_MODEL = "Please select data object name for find in model";
	String EMPTY_NAME_MODEL = "Data object name is empty";
	String FIND_IN_MODEL_VAL = "Please select only one data object to find in model";
	
	String REQ_FIELDS_MAP = "Name," + " " + "Value," + " " + "Min," + " " + "Max";
	String REQ_FIELDS_DEFINE = "Name," + " " + "Value"+ " " + "Min," + " " + "Max";
	String REQ_FIELDS_INPUT = "Name";
	
	String REQUIRED_FIELD = "Required fields";
	String NAME_FOR_RENAME = "Please select name cells for rename";
	String RENAME_SUCCESS= "Variables Renamed Successfully";
	
	String USE_THIS_SUCCESS = "Use this object performed successfully";
	String USE_THIS_ERROR = "No data object available to resolve the mismatch";
	
	String MENU_INIT_ERROR = "Context menu intialization error (Check Logs for More Info)";
	String MENU_FILL_ERROR = "Error while filling Category editor context menu (Check Logs for More Info)";
	//String PROJECT_VIEW_CREATION_ERROR = "Error while intializing project view (Check Logs for More Info)";
	String PROJ_HIGH_ERROR ="Error while highlighting the project (Check Logs for More Info)";
	String MENU_ENABLE_ERROR ="Error while enabling/disabling context menu (Check Logs for More Info)";
    String HIERARCHY_ERROR ="Error while switching to hierarchial view (Check Logs for More Info)";
	String DUPLICATE_PROJ = "Error while checking for duplicate projects (Check Logs for More Info)";
	
	String OPEN_PROJ_ERROR ="Error while opening project (Check Logs for More Info)";
	String CLOSE_PROJ_ERROR ="Error while closing project (Check Logs for More Info)";
	
	String CHANGE_VIEW_ERROR = "Error while changing view in Project Explorer";
			
	String FEATURES ="1.  Import multiple projects"
			+ "\n2.  Data manipulation in multiple categories"
			+ "\n3.  Resolve Inconsistency"
			+ "\n4.  Rename multiple data objects in model"
			+ "\n5.  Check I/O Compatibility"
			+ "\n6.  Check Component Inputs"
			+ "\n7.  Search data object"
			+ "\n8.  Find in model"
			+ "\n9.  Sort, Filter and Custom filter"
			+ "\n10. Support \"Save\" and \"Save All\" functionality"
			+ "\n11. Add data object in Input category manually or from Output signals";
	
	//String ADD_INPUT_DATA_OBJ = "Do you want to add data object manually";
	String SAVE_DATA_WARNING = "Please save the data before performing ";
	//Resolve Inconsistency
	String VAL_FOR_MIN_MAX = "Min and Max value must be within the range of selected base type";
	String MAX_GREATER_MIN = "Max value must be greater than Min value";
	String MIN_LESS_THAN_MAX = "Min value must be less than Max value";
	
}
