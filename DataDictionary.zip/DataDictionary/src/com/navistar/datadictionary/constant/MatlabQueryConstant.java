package com.navistar.datadictionary.constant;

/**
 * This interface collected constants for creating JSON structure to integrate
 * with MATLAB
 * 
 * @author nikitak1
 *
 */
public interface MatlabQueryConstant {
	String QUERY_NAME = "queryName";
	String PROJECT_NAME = "projectName";
	String COMPONENT_NAME = "componentName";
	String CATEGORY = "category";
	String VALUE = "Value";
	String DIMENSIONS = "Dimensions";
	String MAX_DIMENSION = "maxDimension";
	String ERROR_CODE = "errorCode";
	String MESSAGE_CODE = "messageCode";
	String SEARCH_DATA = "search_data";
	String MATCH_CASE = "match_case";
	String EXACT_WORD = "exact_word";	
	
}
