package com.navistar.datadictionary.constant;

/**
 * Class used to store the Logger messages.
 * @author JAYSHRIVISHB
 *
 */
public interface LoggerConstant {

	String OPEN_PROJ_ACTION = "Open project action started...";
}
