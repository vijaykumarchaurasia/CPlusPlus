package com.navistar.datadictionary.constant;

/**
 * Interface used for View Part ID's
 * @author minalc
 *
 */
public interface ViewIDConstant {

	String ACTIVITY_LOG = "com.navistar.datadictionary.view.ActivityLogView";
	String DATA_OBJ = "com.navistar.datadictionary.view.DataObjectView";
	String CHECK_IO_COMPAT= "com.navistar.datadictionary.view.IOCompatibilityView";
	String PROJ_EXPLORER = "com.navistar.datadictionary.view.ProjectExplorerView";
	String SEARCH_RESULT = "com.navistar.datadictionary.view.SearchResultView";
	String WELCOME_NOTE = "com.navistar.datadictionary.view.WelcomeNoteView";
	String TABLE_EDITOR= "com.navistar.datadictionary.view.TableEditiorView";
	String COMP_INPUTS = "com.navistar.datadictionary.view.CheckComponentInputsView";
	String MIN_MAX_INFO = "com.navistar.datadictionary.view.MinMaxInfoView";
	String OUTPUT_DATA_OBJ = "com.navistar.datadictionary.view.OutputDataObjectsView";
	
}
