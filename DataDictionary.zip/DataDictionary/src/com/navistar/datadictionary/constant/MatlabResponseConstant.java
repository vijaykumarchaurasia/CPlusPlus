package com.navistar.datadictionary.constant;

/**
 * This interface collected constants for the error code given by matlab script
 * 
 * @author minalc
 *
 */
public interface MatlabResponseConstant {

	String EMPTYDATAERRCODE = "101";
	String IOCOMPTERRCODE = "102";
	int NOINCONSISERRCODE = 103;
	int NOUNCONNERRCODE = 104;
	int NODUPOUTERRCODE = 105;
	int NOUNCONOUTERRCODE = 106;
	int NOINCONSISNORMALERRCODE = 201;
	int NOINCONSISSTRUCTUREDERRCODE = 202;
	String IOCOMPTERRCODEE_95 = "200";
	String NOTOPSLDDERRCODE = "107";
	String EMPTYSLDDERRCODE = "108";
	String NO_DATA_OBJ_FOUND = "109";
	String NO_MODEL_FOUND = "114";
	String SAVEDATAERRCODE = "111";
	String SAVEDATASUCCCODE = "501";
	String DELDATASUCCCODE = "502";
	String FINDMDLSUCCCODE = "503";
	String NODDINCONOBJ = "112";
	String NOMDLINCONOBJ = "113";
	String NOMDLFORINCON = "114";
	String SEARCHDATANOTFND = "115";
	String COMP_NO_INCON_IP = "116";
	String COMP_NO_UNCONN_IP = "117";
	String COMP_NO_INCON_NRML_IP= "203";
	String COMP_NO_INCON_STRUC_IP= "204";
	String REDUNDANT_DATA_ERROR_CODE= "118";
	String RENAME_ERROR_CODE = "121";
	String RENAME_SUCC_CODE = "511";
	String USE_THIS_OBJ_SUCC ="510";
	String USE_THIS_OBJ_ERR ="120";
	String OBJ_FOR_USE_THIS ="515";
	String NO_HIERARCHI_VIEW = "130";
	String NO_REN_ERR_CODE = "122";
	String NOMDLRNMERRCODE = "114";
	String RES_USE_THIS_SUC = "945";
	String ADD_DATA_OBJ_ERROR_CODE = "301";
	String NO_UNITS_FILE = "1000";
	String PROGVAR_PRES_IN_COMP = "505";
	String NO_CONFIG_FILE = "1001";
	String FOLDER_STRUC_INCOR = "1002";
	String NODUPLICOBJ = "110";
	
}
