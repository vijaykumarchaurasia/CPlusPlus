package com.navistar.datadictionary.constant;

/**
 * Interface used for icons path.
 * 
 * @author vijayk13
 *
 */
public interface IconsPathConstant {
	
	/** Data Object Icon */
	String ICON_PLUG = "/icons/plug-01.png";
	
	/** Component Category Icon*/
	String ICON_INPUT_OUTPUT = "/icons/input-output-01.png";
	
	/** Component warning Icon*//*
	String ICON_WARNING = "/icons/warning.png";*/
	
	/** Component icon*/
	String ICON_COMPONENT = "/icons/component.png";
	
	/** Component icon*/
	String ICON_MODULE = "/icons/folder.png";
	
	/** Arrow icon*/
	String ICON_ARROW = "/icons/arrow-01.png";

	/** Input Icon */
	String ICON_INPUT = "/icons/input.png";
	
	/** Search Result Icon */
	String SEARCH_RESULT = "/icons/result.png"; 
	
	/** Data Dictionary Icon */
	String DATA_DD_ICON = "/icons/application_icon_16_8_bit.png";
	
	String COMMON_WINDOW = "/icons/common-window-icon.png";

	String ICON_WARNING_NEW = "/icons/warning-small-new.png";
	
	String PROJ_EXPLORER = "/icons/project-explorer.png";
	
	String OPEN_PROJECT_ICON = "/icons/open-project.png";

	String CLOSE_PROJ_ICON = "/icons/close-project.png";

}
