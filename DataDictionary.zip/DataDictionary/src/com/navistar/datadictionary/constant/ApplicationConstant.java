package com.navistar.datadictionary.constant;

/**
 * Interface used for UI button labels.
 * @author minalc
 *
 */
public interface ApplicationConstant {

	// NatTable button name
	String BTN_ADDDATAOBJECT = "Add Data Object";
	String BTN_FINDINMODEL = "Find in Model";
	String BTN_SEARCH = "Search";

	// welcome note default text
	String WELCOME_NOTE_TEXT = "Welcome To Data Dictionary";
	String WELCOME_NOTE = "Welcome Note";
	
	//Maximum stack size used for undo and redo operation
	int MAX_STACK_SIZE = 5;
	
	// Project context menu
	String OPEN_PROJECT = "Open Project";
	String CLOSE_PROJECT = "Close Project";
	String REMOVE_PROJECT = "Remove Project";
	String IMPORT_PROJECT = "Import Project (Ctrl+I)";
	String CHECK_IOCOMPAT = "Check I/O Compatibility";
	String IO_COMPATIBILITY = "I/O Compatibility";
	String CHECK_SEARCH = "Search (Ctrl+F)";
	String FILTER = "Filter";
	String SEARCH_RESULTS = "Search Results";

	// Edit menu
	String SAVE_ALL = "Save All (Ctrl+Shift+S)";
	String SAVE = "Save (Ctrl+S)";
	String UNDO = "Undo";
	String REDO = "Redo";

	// To maintain project status
	String IMPORT_PROJ_EXCE = "Please select valid project";
	String FIRSTPROJOPEN = "firstProjectOpen";
	int OPEN_PROJ_STATUS = 1;
	int CLOSE_PROJ_STATUS = 0;
	int CLOSEPROJITEMCNT = 0;
	int EDITORDATACHANGE = 999999;
	String STATUS1 = "status=1";

	// Component context menu
	String OPEN_COMPONENT = "Open Component";
	String RESOLVEINCONSIST = "Resolve Inconsistency using Model";
	String CHECKCOMPIN = "Check Component's Inputs";
	String INVALID = "Invalid";

	// Dialogue messages
	String PROJECT_EXIST = "Project already exist in Workspace";
	String OPEN_PROJ_MSG = "Are you sure, you want to open a new project ?";
	String SAVEOPENPROJMSG = "Are you sure, you want to save the changes and open a new project?";
	String CUSTOMFILTERMSG = "Please remove other Filter before applying custom filter";

	// String constants
	String EMPTY_STRING = "";

	String MESSAGES = "messages";
	String CAT_EDITOR_ID = "com.navistar.datadictionary.categories.editor.InputEditor";
	String WELCOMENOTEEDITID = "com.navistar.datadictionary.categories.editor.WelcomeNoteEditor";
	String ERROR_CODE_STRING = "errorCode";

	// Category Names
	String CATEGORY_MAP = "Map";
	String CATEGORY_AXIS = "Axis";
	String CATCALIBRATION = "Calibration";
	String CATEGORY_DEFINE = "Define";
	String CATEGORY_INPUT = "Input";
	String CATEGORY_LOCAL = "Local";
	String CATEGORY_OUTPUT = "Output";
	String CATEGORY_NVM = "Nvm";
	String CATEGORY_CURVE = "Curve";
	String WARNING_CAPS = "WARNING: ";

	// Messagebox title for warning messagebox
	String WARNING = "Warning";
	String ERROR = "Error";
	String INFORMATION = "Information";
	String SUCCESS = "Success";
	String SAVERESWARNING = "Save Resources";
	String BTN_SAVE_ALL = "Save All";
	String BTN_DISCARD = "Discard";
	String BTN_CANCEL = "Cancel";
	String BTN_YES = "Yes";
	String BTN_NO = "No";

	String PLUGIN_ID = "DataDictionary";
	String PERSPECTIVE_ID = "DataDictionary.perspective";
	String APPLICATION_NAME = "Data Dictionary";

	// Number of columns in Values of category
	int VAL_COL_COUNT = 16;

	// Font style for highlighted and bold project which is open
	String HIGHLIGHTFONTSTYL = "Work Sans";
	
	// Font style throughout the application
	String APP_FONT_STYLE = "Work Sans";

	// Font size for highlighted project
	int HIGHFONTSIZE = 10;

	// RGB Color code for grey color
	int CLOSE_PROJ_COLOR = 105;

	// RGB Color code for black color
	int OPEN_PROJ_COLOR = 0;
	
	int REMOVEPROJSTATUS = 2;
	String IOCOMPTEDITID = "com.navistar.datadictionary.ui.editors.IOComatibilityEditor";
	String BTNDELDATAOBJ = "Delete Data Object";
	String INCONSISTENT_IOS = "Inconsistent I/Os";
	String INCONSISTENT_IOS_NORMAL = "Inconsistent Normal I/Os";
	String INCONSISTENT_IOS_STRUCTURE = "Inconsistent Structured I/Os";
	String NO_ISSUES = "(No Issues)";
	String UNCONNECTED_IP = "Unconnected Inputs";
	String DUPLICATE_OP = "Duplicate Outputs";
	String UNCONNECTED_OP = "Unconnected Outputs";
	
	//Base types
	String SINGLE = "single";
	String BOOLEAN = "boolean";
	String INT8 = "int8";
	String UINT8 = "uint8";
	String INT16 = "int16";
	String UINT16 = "uint16";
	String INT32 = "int32";
	String UINT32 = "uint32";
	
	String SLDDFILEEXTN = ".sldd";
	String PASTE_SHORTCUT = "Paste";
	String PASTE = "Paste";
	String COPY_SHORTCUT = "Copy";
	String COPY = "Copy";
	String CUT_SHORTCUT = "Cut";
	String CUT = "Cut";
	String DELETE = "Delete";
	String CHANGE_FONT = "Font and Color";
	String CUSTOM_FILTER = "Custom Filter";
	String EDIT_VIOLATION = "Editing Failed";
	int MAXNAMELEN = 63;
	
	// Search window labels
	String LBL_SEARCH_WHAT = "Search What :";
	String LBLFINDINCOMP = "Find In Component";
	String LBLSEARCHRESULT = "Results :";
	String BTN_MATCH_CASE = "Match Case";
	String BTN_EXACT_WORD = "Exact word or Phrase";
	String LBL_WHERE = "Where :";
	String BTN_CLOSE = "Close";
	String FONT_STYLE = "Work Sans";
	int FINDINMODELIDX =3;
	int DELDATAOBJIDX =4;
	String RENAMEINMODEL = "Rename In Model";
	String LBLRENAMEINMODEL = "Variables to rename";
	String COMP_IP_EDIT_ID = "com.navistar.datadictionary.ui.editors.ComponentIpEditor";
	String USE_THIS_OBJECT = "Use this Data Object";
	String COMPONENT_INPUTS = "Component Inputs";
	String CLEAR_FILTER = "Clear Filter";
	String CLEAR_SORT = "Clear Sort";
	String SAVE_MESSAGE = "Please Remove Filter's to Perform Save Operation";
	String HELP = "No Application Found to Open a PDF file";
	String HELP_ERROR = "Help Document Deleted or Corrupted from Location 'C:\\Program Files (x86)\\KPIT\\Data Dictionary'";
	String CONFIRMATION = "Confirm";
	String RESOLVEINATTRID = "com.navistar.datadictionary.ui.editors.ResolveInconAttributesEditor";
}
