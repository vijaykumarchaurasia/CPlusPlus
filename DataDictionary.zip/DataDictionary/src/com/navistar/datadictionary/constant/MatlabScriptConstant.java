package com.navistar.datadictionary.constant;

/**
 * This interface collected constants for MATLAB script names and MATLAB related commands
 * @author nikitak1
 *
 */
public interface MatlabScriptConstant {

	/** MATLAB script name to fetch data */
	String LOADCOMPDATA = "FetchSLDD_Data";

	/** MATLAB script name to add data */
	String ADD_DATA_OBJECT = "AddDataObject";

	/** MATLAB script name to parse json request */
	String QUERY_DD_MATLAB = "QueryDD2MATLAB";

	/** Command to add the exe path containing MATLAB scripts in MATLAB */
	String ADD_PATH_CMD = "addpath('C:\\Program Files (x86)\\KPIT\\Data Dictionary\\Matlab_Scripts','dir')";

	/** Command to check if path exist in MATLAB */
	String EXIST_PATH_CMD = "response = exist('C:\\Program Files (x86)\\KPIT\\Data Dictionary\\Matlab_Scripts')";

	/** Response MATLAB Workspace Variable */
	String RESPONSE = "response";

	/** Positive Path Response */
	String POSITIVE_RESPONSE = "7";
	
	/** Command to launch MATLAB in shared engine */
	String MATLAB_LAUNCH_CMD = "matlab -r \"matlab.engine.shareEngine\"";
	
	/** Command to launch MATLAB */
	String MATLAB_LAUNCH_CMD2 = "matlab";
	
	/** Query for I/O Compatibility for E44*/
	String QUERY_IO_COMPAT = "InOutCompatibility";
	
	/** Query for I/O Compatibility for E95*/
	String QUERY_IO_COMPAT_E95 = "InOutCompatibility_E95";
	
	/** Query for fetch from top.sldd */
	String QUERYTOPSLDDCOMP = "TopSlddComponent";
	
	/** Empty String */
	String EMPTY_STRING = "";

	/** Query to find a dat object in simulink model*/
	String FIND_IN_MODEL = "FindInModel";
	
	/** Query to delete data object(s) from sldd */
	String QUERYDELDATAOBJ = "DeleteDataObject";

	/** Query to remove project path */
	String QUERY_REMOVE_PATH = "rmpath";
	
	/** Query to genpath */
	String QUERY_GEN_PATH = "genpath";
	
	/** Query to fetch inconsistencies in model*/
	String QUERYDATARESOLVED = "DataToBeResolved";

	/** Query to Check Component Inputs */
	String CHECKCOMPINPUTS = "Check_Components_Inputs";
	
	/** Query to Check Component Inputs for E */
	String CHECKCOMPINPUTS_E95 = "Check_Components_Inputs_E95";
	
	/** Query to Search data object from project */
	String QUERYSEARCHOBJ = "SearchDataObject";

	/** Query to rename the data objects*/
	String RENAME_IN_MODEL = "RenameInModel";
	
	/** Query to Use this data object from project */
	String QUERYUSEDATAOBJ = "UseThisObject";

	/** Query for Hierarchical view display */
	String QUERYHIERACHIVIEW = "HierachicalView";

	/** Query to add project path */
	String QUERY_ADD_PATH = "addpath";

	/** Query to display all outputs from opened project in input category*/
	String QUERYALLOUTSIGNAL = "AllOutputSignal";

	/** JVM path from MATLAB path*/
	String JVM_PATH = "\\sys\\java\\jre\\win64\\jre\\bin\\server\\jvm.dll";

	/**Adding bin after MATLAB path folder to execute MATLAB shared engine command */
	String PRECEEDING_BIN = "\\bin\\";

	/**Query to collect all inconsistent attributes from sldd and CAN excel sheet */
	String INCONSIIOATTR = "InconsistentInOutAttributes";

	/**Query to display data objects to import from excel into sldd */
	String QUERYEXCELIMPORT = "ResolveInconsistencyImport";

	/** Query to display data objects to export into excel from sldd*/
	String QUERYEXCELOBJGET = "ResolveInconsistencyExport";

	/** Query to resolve inconsistencies for adding and deleting in excel */
	String QRYEXLRSLVINCON = "ExcelAddDeleteQuery";

	/** Query to perform use this object for resolving inconsistent attributes between sldd and excel */
	String EXCELUSETHISOBJ = "ResolveUseThisObject";

	/** Query to perform browse sldd to add outputs in Input */
	String QRYBROWSESLDD = "SingleSlddOutput";

	/** Query to get values from cdf file */
	String QRYGETCDFVAL = "ApplyCalibationValueFromCDFXfile";

	/** Query to get units symbol data from MATLAB */
	String QRYGETUNITS = "GetProjectUnits";

	/** Query to get project configured data from MATLAB */
	String QRYGETPROGRAMNAME = "GetProgramName";

	/** Query to get excel config file path from Navistar MBD toolbox */
	String QRYGETCONFIGFILEPATH = "GetConfigExcelFilePath";

	/** Query to get program name from sldd file */
	String QRYSENDPROGNAME = "GetConfigurationData";
	
}
