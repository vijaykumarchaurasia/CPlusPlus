package com.navistar.datadictionary.dao;

import com.google.gson.JsonElement;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;

/**
 * Interface used to declare methods for Matlab interaction
 * 
 * @author nikitak1
 *
 */
public interface MatlabCommunicationDao {
	/**
	 * Method used to create Matlab request
	 * 
	 * @param jsonStrForReq
	 * @return
	 */
	JsonElement executeMatlabRequest(String jsonStrForReq) throws MatlabCommunicatinException;
}
