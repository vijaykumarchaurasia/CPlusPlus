/**
 * 
 */
package com.navistar.datadictionary.dao;

import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;

import com.mathworks.engine.EngineException;
import com.mathworks.engine.MatlabEngine;
import com.mathworks.engine.MatlabExecutionException;
import com.mathworks.engine.MatlabSyntaxException;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;

/**
 * Interface used to establish matlab connection
 * @author JAYSHRIVISHB
 *
 */
public interface MatlabEngineConnectionDao {

	MatlabEngine getMatlabEngineInstance() throws MatlabCommunicatinException;
	void checkAndCreateMatlabInstance(String[] engines) throws MatlabExecutionException,
	MatlabSyntaxException, CancellationException, EngineException, InterruptedException, ExecutionException ;
}
