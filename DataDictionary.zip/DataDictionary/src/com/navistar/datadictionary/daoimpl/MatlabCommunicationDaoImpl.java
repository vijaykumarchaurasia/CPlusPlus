package com.navistar.datadictionary.daoimpl;

import java.io.StringWriter;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.mathworks.engine.EngineException;
import com.mathworks.engine.MatlabEngine;
import com.mathworks.engine.MatlabExecutionException;
import com.mathworks.engine.MatlabSyntaxException;
import com.navistar.datadictionary.constant.MatlabScriptConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.dao.MatlabCommunicationDao;

/**
 * This class used to implement methods for Matlab interaction
 * 
 * @author nikitak1
 *
 */
public class MatlabCommunicationDaoImpl implements MatlabCommunicationDao {

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(MatlabCommunicationDaoImpl.class);

	/** Store the JSON data of Matlab script's response */
	private JsonElement jsonElement;

	/**
	 * Method used to create Matlab request
	 * @param jsonStrForReq
	 * @throws MatlabCommunicatinException 
	 */
	@Override
	public JsonElement executeMatlabRequest(String jsonStrForReq) throws MatlabCommunicatinException{
	
		LOGGER.info("jsonStrForReq:"+jsonStrForReq);
		StringWriter writer = new StringWriter();
		String matlabErrorMsg = "";
		try {
			// Get the matlab connection instance
			MatlabEngine matlabEngine = new MatlabEngineConnectionDaoImpl().getMatlabEngineInstance();
			JsonParser parser = new JsonParser();
			Object resp = null;
			// if matlab connection is established then execute the request
			if (matlabEngine != null) {
				resp = matlabEngine.feval(MatlabScriptConstant.QUERY_DD_MATLAB,null,writer, (Object) jsonStrForReq);
			}
			//LOGGER.info("resp:"+resp);
			// if matlab response is not null convert it into formatted json element
			if (resp != null) {
				jsonElement = parser.parse((String) resp);
			}
		} catch (EngineException e) {
			matlabErrorMsg = getErrorMsg(writer);
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			throw new MatlabCommunicatinException("Matlab is Not Installed in the System "+"\n"+matlabErrorMsg, e);
			
		} catch (MatlabExecutionException e) {
			matlabErrorMsg = getErrorMsg(writer);
			//handled for Unknown exchange api error
			if(matlabErrorMsg.equals("")) {
				matlabErrorMsg = e.getCause().getMessage();
				if(matlabErrorMsg.contains("Unknown ExchangeApi")) {
					matlabErrorMsg = matlabErrorMsg+"\nPlease close MATLAB and try again";
				}
			}	
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			throw new MatlabCommunicatinException("Error occured in MATLAB execution "+"\n"+matlabErrorMsg, e);
			
		} catch (MatlabSyntaxException e) {
			matlabErrorMsg = getErrorMsg(writer);
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			throw new MatlabCommunicatinException("Error occured in MATLAB syntax "+"\n"+matlabErrorMsg, e);
			
		} catch (ExecutionException e) {
			matlabErrorMsg = getErrorMsg(writer);
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			throw new MatlabCommunicatinException("Error while performing matlab operation"+"\n"+matlabErrorMsg, e);
			
		} catch (CancellationException e) {
			matlabErrorMsg = getErrorMsg(writer);
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			throw new MatlabCommunicatinException("Error while performing matlab operation"+"\n"+matlabErrorMsg, e);
			
		} catch (InterruptedException e) {
			matlabErrorMsg = getErrorMsg(writer);
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			throw new MatlabCommunicatinException("Error while performing matlab operation"+"\n"+matlabErrorMsg, e);
		}
	
		return jsonElement;
	}

	/**
	 * Method used to remove html tags from error writer data came from
	 * MATLAB output stream
	 * @param writer
	 */
	private String getErrorMsg(StringWriter writer) {
		String matlabErrorMsg = "";
		matlabErrorMsg = writer.toString();
		matlabErrorMsg = matlabErrorMsg.replaceAll("\\<.*?\\>", "");
		return matlabErrorMsg;
	}

}
