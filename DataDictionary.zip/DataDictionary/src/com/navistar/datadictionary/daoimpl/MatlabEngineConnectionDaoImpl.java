package com.navistar.datadictionary.daoimpl;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.PlatformUI;

import com.mathworks.engine.EngineException;
import com.mathworks.engine.MatlabEngine;
import com.mathworks.engine.MatlabExecutionException;
import com.mathworks.engine.MatlabSyntaxException;
import com.navistar.datadictionary.constant.MatlabScriptConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.dao.MatlabEngineConnectionDao;
import com.navistar.datadictionary.ui.views.CustomMessageDialog;

/**
 * This class is used to establish the connection with Matlab.
 * Updated as per SLDD-85 req for Product Ver 3.4
 * @author nikitak1
 *
 */
public class MatlabEngineConnectionDaoImpl implements MatlabEngineConnectionDao {

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(MatlabEngineConnectionDaoImpl.class);
	/** Matlab connection instance */
	public static MatlabEngine matlabEngine = null;

	/**
	 * Default Constructor
	 */
	public MatlabEngineConnectionDaoImpl() {

	}

	/**
	 * This method is used to create and get instance of Matlab connection.
	 * 
	 * @return Matlab connection instance
	 * @throws MatlabCommunicatinException 
	 */
	public MatlabEngine getMatlabEngineInstance() throws MatlabCommunicatinException {
		try {
			String matlabPath = getMatlabPathFromFile();
			// Get list of shared Matlab session
			String[] engines = MatlabEngine.findMatlab();
			Shell shell = new Shell(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(),SWT.ON_TOP);
			
			String versionNo = matlabPath.substring(matlabPath.lastIndexOf("\\") + 1);

			if (matlabEngine != null && engines.length != 0) {
				return matlabEngine;
			} else {
				// If shared Matlab session available connect to it
				if (engines.length != 0) {
					checkAndCreateMatlabInstance(engines);
				} else {
					performActionOnDialog(matlabPath, shell, versionNo);
				}

			}
		} catch (EngineException e) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			throw new MatlabCommunicatinException("Matlab is Not Installed in the System ", e);
			
		} catch (MatlabExecutionException e) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			throw new MatlabCommunicatinException("Error while performing matlab operation ", e);
			
		} catch (MatlabSyntaxException e) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			throw new MatlabCommunicatinException("Error while performing matlab operation", e);
			
		} catch (ExecutionException e) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			throw new MatlabCommunicatinException("Error while performing matlab operation", e);
			
		} catch (CancellationException e) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			throw new MatlabCommunicatinException("Error while performing matlab operation", e);
			
		} catch (InterruptedException e) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			throw new MatlabCommunicatinException("Error while performing matlab operation", e);
			
		} catch (IOException e) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			throw new MatlabCommunicatinException("Error while performing matlab operation", e);
		}
		return matlabEngine;
	}

	/**
	 * Method used to perform action according to the option selected on startup dialog
	 * @param matlabPath
	 * @param engines
	 * @param shell
	 * @param versionNo
	 * @throws MatlabExecutionException
	 * @throws MatlabSyntaxException
	 * @throws EngineException
	 * @throws InterruptedException
	 * @throws ExecutionException
	 * @throws IOException
	 */
	private void performActionOnDialog(String matlabPath,Shell shell, String versionNo)
			throws MatlabExecutionException, MatlabSyntaxException, EngineException, InterruptedException,
			ExecutionException, IOException {
		int option = displaySharedEngDialog(shell, versionNo);
		//String engines[] = MatlabEngine.findMatlab();
		/*if(option==0) {
			//retry
			
			if(engines.length!=0) {
				checkAndCreateMatlabInstance(engines);
			}else {
				performActionOnDialog(matlabPath,shell,versionNo);
			}
		}*/
		if(option==0) {
		//	if(engines.length!=0) {
		//		checkAndCreateMatlabInstance(engines);
		//	}else {
				//performActionOnDialog(matlabPath,shell,versionNo);
				openNewMatlabInSharedEng(matlabPath);
		//	}
			
		}else {
			//exit the tool
			PlatformUI.getWorkbench().getActiveWorkbenchWindow().close();
		}
	}

	/**
	 * Method used to open new MATLAB shared instance
	 * @param matlabPath
	 * @throws IOException
	 * @throws EngineException
	 * @throws MatlabExecutionException
	 * @throws MatlabSyntaxException
	 * @throws InterruptedException
	 * @throws ExecutionException
	 */
	private void openNewMatlabInSharedEng(String matlabPath) throws IOException, EngineException,
			MatlabExecutionException, MatlabSyntaxException, InterruptedException, ExecutionException {
		String[] engines;
		String matlabCmd = matlabPath+MatlabScriptConstant.PRECEEDING_BIN + MatlabScriptConstant.MATLAB_LAUNCH_CMD2;

		Runtime.getRuntime().exec(matlabCmd);

		// Get list of created shared Matlab session
		engines = MatlabEngine.findMatlab();

		while (engines.length == 0) {
			engines = MatlabEngine.findMatlab();

		}
		checkAndCreateMatlabInstance(engines);
	}

	/**
	 * Method used to display instructions in startup dialog
	 * @param shell
	 * @param versionNo
	 * @return
	 */
	private int displaySharedEngDialog(Shell shell, String versionNo) {
		CustomMessageDialog dialog = new CustomMessageDialog(shell, "Tool requires shared MATLAB instance", null,
				"MATLAB "+versionNo+" is not opened"+"\nClick on \"Launch\" option to open MATLAB for Data Dictionary tool\n",
				MessageDialog.CONFIRM, new String[] {"Launch", "Cancel"},0);
		
		//display dialog in center position of screen
		Rectangle screenSize = PlatformUI.getWorkbench().getDisplay().getPrimaryMonitor().getBounds();
		shell.setLocation((screenSize.width - shell.getBounds().width) / 2, (screenSize.height - shell.getBounds().height) / 2);
		
		int option = dialog.open();
		return option;
	}

	/**
	 * Method used to get MATLAB exe path from DataDictionary.ini file
	 * @return
	 * @throws FileNotFoundException
	 */
	private String getMatlabPathFromFile() throws FileNotFoundException {
		Scanner scanner = new Scanner(new File("C:\\Program Files (x86)\\KPIT\\Data Dictionary\\Data Dictionary.ini"));
		List<String> lines = new ArrayList<String>();
		while (scanner.hasNextLine()) {
		  lines.add(scanner.nextLine());
		}
		scanner.close();
		String matlabPath ="";
		for (String data : lines) {
			if(data.contains(MatlabScriptConstant.JVM_PATH)) {

				matlabPath = data.replace(MatlabScriptConstant.JVM_PATH, "");
			}
		}
		return matlabPath;
	}

	/**
	 * This method is used to create and connect to the Matlab shared session.
	 * 
	 * @param engines
	 *            list of shared Matlab connections
	 * @throws MatlabExecutionException
	 * @throws MatlabSyntaxException
	 * @throws CancellationException
	 * @throws EngineException
	 * @throws InterruptedException
	 * @throws ExecutionException
	 */
	public void checkAndCreateMatlabInstance(String[] engines) throws MatlabExecutionException, MatlabSyntaxException,
			CancellationException, EngineException, InterruptedException, ExecutionException {
		if (engines.length != 0) {
			// Connect to the shared session
			matlabEngine = MatlabEngine.connectMatlab(engines[0]);

			// Check if Set Path is configured in Matlab
			matlabEngine.eval(MatlabScriptConstant.EXIST_PATH_CMD);

			// If set path not configured then configure
			if (!matlabEngine.getVariable(MatlabScriptConstant.RESPONSE).toString()
					.equals(MatlabScriptConstant.POSITIVE_RESPONSE)) {
				// Add path in the Matlab
				matlabEngine.eval(MatlabScriptConstant.ADD_PATH_CMD, null, null);
			}
		}
	}

	/**
	 * Method used to remove the project path from MATLAB
	 * @param projectPath 
	 */
	public void removeProjectPath(String projectPath){
		// Check if remove Path is configured in Matlab
		try {
			MatlabEngine matlabEngine = getMatlabEngineInstance();
			if(matlabEngine != null)
			{
				String removePathCommand = MatlabScriptConstant.QUERY_REMOVE_PATH + "(" + MatlabScriptConstant.QUERY_GEN_PATH + "('" + projectPath + "'))";
				matlabEngine.eval(removePathCommand);
			}
		} catch (CancellationException | InterruptedException | ExecutionException | MatlabCommunicatinException e) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
		}
	}
	
	/**
	 * Method used to add the project path from MATLAB
	 * @param projectPath
	 */
	public void addProjectPath(String projectPath) {
		try {
			MatlabEngine matlabEngine = getMatlabEngineInstance();
			if(matlabEngine != null)
			{
				String addPathCommand = MatlabScriptConstant.QUERY_ADD_PATH + "(" + MatlabScriptConstant.QUERY_GEN_PATH + "('" + projectPath + "'))";
				matlabEngine.eval(addPathCommand);
			}
		} catch (CancellationException | InterruptedException | ExecutionException  | MatlabCommunicatinException e) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
		}
	}
}
