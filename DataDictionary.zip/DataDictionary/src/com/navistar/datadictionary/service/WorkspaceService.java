package com.navistar.datadictionary.service;

import java.util.List;

import com.navistar.datadictionary.model.Project;

/**
 * Interface contains all the methods regarding workspace Operation.
 * @author JAYSHRIVISHB
 *
 */
public interface WorkspaceService {

	List<Project> getWorkspaceHistory(String workspacePath);
	
	boolean saveWorkspaceHistory(String workspacePath);
}
