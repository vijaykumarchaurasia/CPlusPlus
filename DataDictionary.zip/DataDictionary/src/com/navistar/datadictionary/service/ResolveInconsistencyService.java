package com.navistar.datadictionary.service;

import java.util.List;
import java.util.Map;

import com.google.gson.JsonElement;
import com.navistar.datadictionary.customexception.EditorInitilizationException;
import com.navistar.datadictionary.customexception.EditorReuseException;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.model.CategoryAttributes;
/**
 * Interface contains all the methods for resolve inconsistency functionality
 * @author JAYSHRIVISHB
 *
 */
public interface ResolveInconsistencyService {
	
	void openInconsistencyWindow();
	JsonElement getInconsistentDataObjects() throws MatlabCommunicatinException;
	Map<String, List<CategoryAttributes>> convertInconsistencyListToMap() throws MatlabCommunicatinException;
	void resolveInconsistency(List<CategoryAttributes> ddList, List<CategoryAttributes> modelList) throws MatlabCommunicatinException, EditorReuseException, EditorInitilizationException;
	void enableResolveInconAction();
}
