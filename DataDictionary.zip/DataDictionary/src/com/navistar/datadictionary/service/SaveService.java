package com.navistar.datadictionary.service;

import java.util.List;

import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.model.SaveResponseCode;

/**
 * Interface contains all the methods regarding save data Operation.
 * @author JAYSHRIVISHB
 *
 */
public interface SaveService {

	boolean saveCategoryData(String queryName, String componentName, String dataObject) throws MatlabCommunicatinException;
	
	List<SaveResponseCode> getUnsavedCategoryList();
	
	void setUnsavedCategoryList(List<SaveResponseCode> unsavedCatList);
}
