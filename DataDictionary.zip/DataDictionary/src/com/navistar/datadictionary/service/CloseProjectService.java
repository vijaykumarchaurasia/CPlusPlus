package com.navistar.datadictionary.service;

/**
 * Interface contains all the methods regarding close project operation.
 * @author JAYSHRIVISHB
 *
 */
public interface CloseProjectService {

	void performCloseProjectAction();
	
	void closeProjectFromExplorer();
	
	int closeProjectHandler(boolean saveDialogRetVal, int saveDialogSSelVal) ;
}
