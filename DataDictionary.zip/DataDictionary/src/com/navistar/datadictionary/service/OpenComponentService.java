package com.navistar.datadictionary.service;

import java.io.FileNotFoundException;
import java.util.List;

import org.eclipse.jface.viewers.TreeViewer;

import com.navistar.datadictionary.customexception.EditorInitilizationException;
import com.navistar.datadictionary.customexception.EditorReuseException;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.model.CategoryAttributesIo;

/**
 * Interface contains all the methods regarding open component Operation.
 * @author JAYSHRIVISHB
 *
 */
public interface OpenComponentService {

	void validateEditors(TreeViewer viewer) throws MatlabCommunicatinException, EditorReuseException, EditorInitilizationException;
	
	boolean openComponentInEditor(TreeViewer viewer) throws FileNotFoundException, MatlabCommunicatinException, EditorReuseException, EditorInitilizationException;
	
	void findAndOpenComponent(String dataObject,String componentName,String categoryName, List<CategoryAttributesIo> ioCompatList) throws EditorInitilizationException;
	
	String getSelectedComponentName(TreeViewer viewer);
	
	String getOpenedComponentPath();
	
	String getOpenedComponentName();

	void openComponentForCompEditor(String dataObject, String componentName, String categoryName,
			List<CategoryAttributesIo> compIpList);
}
