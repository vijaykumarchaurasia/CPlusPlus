package com.navistar.datadictionary.service;

import java.util.List;

import org.eclipse.swt.widgets.Tree;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IWorkbenchPage;

import com.navistar.datadictionary.customexception.EditorInitilizationException;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.model.CategoryAttributes;

/**
 * Interface contains all the methods regarding use this data object operation.
 * @author nikitak1
 *
 */
public interface UseThisObjectService {
	
	void getObjectToUseForCompIp(Tree tree);
	
	void getObjectToUseForIOComp(Tree tree);
	
	List<CategoryAttributes> getDataObjectListForCompIp(String dataObjectName);
	
	List<CategoryAttributes> getDataObjectListForIOComp(String dataObjectName);
	
	String getCompPathForCategory(String componentName);
	
	void createJsonRequest(List<CategoryAttributes> categoryList) throws MatlabCommunicatinException, EditorInitilizationException;	
	
	void getObjectToUseForExcelSldd(String dataObjectName,String warningName);	
	
	List<CategoryAttributes> getSameObjectListForInconAttr(String dataObjName,List<CategoryAttributes> inconAttrList);
	
	void createReqForExcelSldd(List<CategoryAttributes> categoryList) throws MatlabCommunicatinException, EditorInitilizationException;

	void updateDataObjectValuesOnUI(List<CategoryAttributes> objToRepList);
	
	void setUseThisDataInCategoryTable(IWorkbenchPage activePage, String category, CategoryAttributes object,
			IEditorPart editorPart);
}
