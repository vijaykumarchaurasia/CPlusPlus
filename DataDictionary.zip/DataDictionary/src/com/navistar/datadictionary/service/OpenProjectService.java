package com.navistar.datadictionary.service;

import org.eclipse.ui.IEditorPart;

/**
 * Interface contains all the methods regarding open project Operation.
 * @author JAYSHRIVISHB
 *
 */
public interface OpenProjectService {

	boolean performOpenProjectAction(IEditorPart categoryEditor) throws Exception;
	
	void openProjectInExplorer();
	
	String enableProject();
	
	String getOpenedProjectName();

}
