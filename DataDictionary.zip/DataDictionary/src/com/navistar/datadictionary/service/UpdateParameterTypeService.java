package com.navistar.datadictionary.service;

import java.util.List;
import java.util.Map;

import com.google.gson.JsonElement;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.model.CategoryAttributes;

public interface UpdateParameterTypeService {
	JsonElement updateValPrjParaType() throws MatlabCommunicatinException;
	JsonElement updateValCompParaType() throws MatlabCommunicatinException;
	JsonElement getUpdatedtDataObjects() throws MatlabCommunicatinException;
	Map<String, List<CategoryAttributes>> convertInconsistencyListToMap(JsonElement jsonElement) throws MatlabCommunicatinException;
	
}
