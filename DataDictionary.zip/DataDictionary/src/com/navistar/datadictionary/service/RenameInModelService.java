/**
 * 
 */
package com.navistar.datadictionary.service;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;

/**
 * Interface contains all the methods regarding Rename In Model Operation.
 * @author nikitak1
 *
 */
public interface RenameInModelService {
	
	void openRenameWindow();
	
	JsonElement createJsonForRename(JsonArray jsonArray) throws MatlabCommunicatinException;

}
