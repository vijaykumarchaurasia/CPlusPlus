package com.navistar.datadictionary.service;

import java.util.List;
import java.util.Map;

import javax.annotation.Nonnull;

import com.google.gson.JsonElement;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.model.CategoryAttributesIo;

/**
 * Interface contains all the methods required for Check Component Inputs functionality
 * @author nikitak1
 *
 */

public interface CheckComponentInputsService {

	JsonElement getComponentInputsData() throws MatlabCommunicatinException; 

	Map<String, List<CategoryAttributesIo>> convertCompIOListToMap(@Nonnull JsonElement jsonElement);

	void closeCheckCompInputsWindow();
	
	void updateCompInputsData(String warningName, String componentName, String objectName,
			String categoryName) ;
	
	String getArxmlPath();
	Map<String, List<CategoryAttributesIo>> dispE44Warng( Map<String, List<CategoryAttributesIo>> compIOListMap);
	Map<String, List<CategoryAttributesIo>> dispE95Warng( Map<String, List<CategoryAttributesIo>> compIOListMap);
	Map<String, List<CategoryAttributesIo>> checkErrNMsg (JsonElement jsonArray, Map<String, List<CategoryAttributesIo>> compIOListMap);
}
