package com.navistar.datadictionary.service;

import com.google.gson.JsonElement;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;

/**
 * Interface contains all the methods regarding validating hidden object
 * parameters for opened component and project.
 * @author nikitak1
 *
 */
public interface ValidatProjParamService {
	
	JsonElement createValidCompParamReq() throws MatlabCommunicatinException;
	JsonElement createValidProjParamReq() throws MatlabCommunicatinException;
}
