
package com.navistar.datadictionary.service;

import java.util.List;
import java.util.Map;

import org.eclipse.swt.widgets.Shell;

import com.google.gson.JsonElement;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.model.Component;
import com.navistar.datadictionary.model.Node;
import com.navistar.datadictionary.model.Project;

/**
 * Interface contains all the methods regarding Import project Operation.
 * @author JAYSHRIVISHB
 *
 */
public interface ImportProjectService {
	
	List<String> loadImportedProject(String filePath);
	
	List<String> loadImportedProjectUsingTopSldd(String filePath, JsonElement jsonElement);
	
	Map<String, Project> setProjectandStaus(Map<String,Project> projStatusMap,String projectPath,int status, String componentPath);
	
	void updateProjectStatus(String projectName, int status, String componentPath);
	
	int getProjectStatus(String projectName);
	
	Node createTreeStructure(String filePath,int importStatus) throws MatlabCommunicatinException;
	
	List<String> getNameFromComponent(List<Component> currentImpcomp);
	
	String openDirectoryDialog(Shell shell);
}
