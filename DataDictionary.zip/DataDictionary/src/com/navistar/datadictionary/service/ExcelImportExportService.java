package com.navistar.datadictionary.service;

import java.lang.reflect.Type;
import java.util.List;
import java.util.Map;

import com.google.gson.JsonElement;
import com.navistar.datadictionary.customexception.EditorInitilizationException;
import com.navistar.datadictionary.customexception.EditorReuseException;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.model.CategoryAttributesIo;

/**
 * Interface contains all the methods regarding Excel import export operations.
 * @author nikitak1
 *
 */
public interface ExcelImportExportService {

	JsonElement getDataObjectsForSldd(String excelPath) throws MatlabCommunicatinException;	
	Map<String, List<CategoryAttributes>> convertInconsistencyListToMap(JsonElement jsonElement);
	void resolveInconsistencyFromExcel(List<CategoryAttributes> ddList, List<CategoryAttributes> modelList) throws MatlabCommunicatinException, EditorReuseException, EditorInitilizationException;
	
	JsonElement getInconsistentAttributeData(String excelPath) throws MatlabCommunicatinException;
	void openInconsistentAttributeEditor(List<CategoryAttributesIo> inconAttrList) throws EditorInitilizationException;
	
	boolean checkMatlabRespCode(JsonElement jsonElement);
	
	void displayInconsistencyInBothList(Map<String, List<CategoryAttributes>> inconListMap, Type type,
			JsonElement jsonArray);
	
	void checkHashNAInNameFromExcel(Map<String, List<CategoryAttributes>> inconListMap);
	
	JsonElement getDataObjectsForExcel(String excelPath) throws MatlabCommunicatinException; 
	
	JsonElement resolveInconsistencyInToExcel(List<CategoryAttributes> addToExcelList, List<CategoryAttributes> delFromExcelList) throws MatlabCommunicatinException;
}
