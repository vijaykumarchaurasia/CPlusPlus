package com.navistar.datadictionary.service;

import java.util.List;

import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.model.CategoryAttributes;

/**
 * Interface contains all the methods regarding applying CDF to a component.
 * @author nikitak1
 *
 */
public interface ApplyCdfService {
	
	List<CategoryAttributes>getCdfDataFromMatlab() throws MatlabCommunicatinException;
	void updateDataObjectValuesOnUI(List<CategoryAttributes> objToAddList);
}
