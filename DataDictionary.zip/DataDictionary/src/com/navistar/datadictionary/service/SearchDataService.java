package com.navistar.datadictionary.service;

import java.util.List;

import com.google.gson.JsonElement;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.model.CategoryAttributes;

/**
 * Interface contains all the methods regarding search operation.
 * @author vijayk13
 *
 */
public interface SearchDataService {
	
	List<CategoryAttributes> searchDataForOpenComponent(String dataObject,boolean matchCase,boolean exactWord);
	
	JsonElement searchDataForCloseComponent(String component,String dataObject,boolean matchCase,boolean exactWord) throws MatlabCommunicatinException;
	
}
