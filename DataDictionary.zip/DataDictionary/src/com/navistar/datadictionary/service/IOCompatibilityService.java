package com.navistar.datadictionary.service;


import java.util.List;
import java.util.Map;

import javax.annotation.Nonnull;

import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;

import com.google.gson.JsonElement;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.model.CategoryAttributesIo;

/**
 * Interface contains all the methods regarding I/O Compatibility list operations.
 * @author JAYSHRIVISHB
 *
 */
public interface IOCompatibilityService {

	JsonElement getIOCompatibilityData() throws MatlabCommunicatinException; 
	
	Map<String, List<CategoryAttributesIo>> convertIOListToMap(@Nonnull JsonElement jsonElement);
	
	void deleteDataObjectFromView(Tree tree) throws MatlabCommunicatinException;
	
	void refereshEditorAndView(TreeItem treeItem);
	
	void updateIOCompatibilityData(String warningName, String componentName, String objectName, String categoryName);
	
	boolean getArxmlPath();
	
	Map<String, List<CategoryAttributesIo>> dispE44Warng( Map<String, List<CategoryAttributesIo>> ioListMap);
	
	Map<String, List<CategoryAttributesIo>> dispE95Warng( Map<String, List<CategoryAttributesIo>> ioListMap);
	
	Map<String, List<CategoryAttributesIo>> checkErrNMsg (JsonElement jsonArray, Map<String, List<CategoryAttributesIo>> ioListMap);
}
