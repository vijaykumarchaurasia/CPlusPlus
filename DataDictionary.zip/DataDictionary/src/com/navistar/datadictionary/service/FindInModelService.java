package com.navistar.datadictionary.service;

import com.navistar.datadictionary.customexception.EditorInitilizationException;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;

/**
 * Interface contains all the methods regarding Find In Model Operation.
 * @author JAYSHRIVISHB
 *
 */
public interface FindInModelService {

	void highlightInModel() throws MatlabCommunicatinException, EditorInitilizationException;
}
