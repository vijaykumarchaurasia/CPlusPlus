package com.navistar.datadictionary.service;

import java.util.List;

import org.eclipse.jface.viewers.TreeViewer;

/**
 * Interface contains all the methods regarding remove project Operation.
 * @author JAYSHRIVISHB
 *
 */
public interface RemoveProjectService {

	List<String> getProjectListForRemove(TreeViewer viewer);
	void removeProjectFromWorkspace(TreeViewer viewer, List<String> removeProjectList);
}
