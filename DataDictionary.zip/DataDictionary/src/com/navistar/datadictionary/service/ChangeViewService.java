package com.navistar.datadictionary.service;

import java.util.List;
import java.util.Map;

import com.google.gson.JsonElement;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.model.CategoryAttributes;

/**
 * Interface contains all the methods regarding change to hierarchical view operation.
 * @author nikitak1
 *
 */
public interface ChangeViewService {
	
	JsonElement createRequestForHierarchical() throws MatlabCommunicatinException;
	
	Map<String,List<String>>convertListToMap(List<CategoryAttributes> hierarchiViewList) throws Exception;
}
