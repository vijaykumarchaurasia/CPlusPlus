package com.navistar.datadictionary.service;

import java.io.FileNotFoundException;
import java.util.List;

import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.ui.IWorkbenchPage;

import com.google.gson.JsonElement;
import com.navistar.datadictionary.customexception.EditorInitilizationException;
import com.navistar.datadictionary.customexception.EditorReuseException;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.model.Project;

/**
 * Interface contains all the methods regarding editor.
 * @author JAYSHRIVISHB
 *
 */
public interface EditorService {

	boolean checkForUnsavedEditors();
	
	void closeAllEditors();
	
	boolean displayComponentCategories(String componentName, TreeViewer viewer) throws FileNotFoundException, MatlabCommunicatinException, EditorReuseException, EditorInitilizationException;
	
	void removeDirtyIndicator();
	
	boolean deleteDataObjectsFromEditor(List<CategoryAttributes> delDataObjList) throws MatlabCommunicatinException;

	void displayComponentInEditors(IWorkbenchPage activePage, JsonElement jsonElement) throws EditorReuseException, EditorInitilizationException;
	
	JsonElement getOutputDataObjects(Project project,String componentName) throws MatlabCommunicatinException;

	JsonElement getOutputsFromBrowsedSldd(String slddPath) throws MatlabCommunicatinException;

	JsonElement getUnitsDataFrMatlab() throws MatlabCommunicatinException;
	
	List<String> getUnitsList();

	String getConfigProjDataFrMatlab(String comp) throws MatlabCommunicatinException;
	
	String getConfigExcelPath() throws MatlabCommunicatinException;
	
	boolean openCompWithProgName(String program) throws MatlabCommunicatinException;

}
