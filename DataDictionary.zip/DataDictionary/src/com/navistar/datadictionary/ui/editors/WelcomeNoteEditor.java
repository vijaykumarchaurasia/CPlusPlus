package com.navistar.datadictionary.ui.editors;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.ui.PlatformUI;

import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.IconsPathConstant;
import com.navistar.datadictionary.constant.MessageConstant;

/**
 *  Class used for welcome note editor which gives brief description about the tool
 * @author vijayk13
 *
 */
public class WelcomeNoteEditor extends AbstractBaseEditor {
	
	/**
	 * Default Constructor
	 */
	public WelcomeNoteEditor() {
	}
	
	/** Used to get the welcome note editor id	 */
	public static final String WELCOME_NOTE_EDIT = ApplicationConstant.WELCOMENOTEEDITID;
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Object getAdapter(Class arg0) {
		return null;
	}

	/**
	 * Method used to show the welcome note editor data.
	 */
	@Override
	public void showData() {
		// do nothing
	}

	/**
	 * Method used to create the welcome note editor with its default setting.
	 * @param parent
	 */
	@Override
	protected void createPartControl2(Composite parent) {
		Image windowTitleImage = new Image(PlatformUI.getWorkbench().getDisplay(), WelcomeNoteEditor.class.getResourceAsStream(IconsPathConstant.COMMON_WINDOW));
		this.setTitleImage(windowTitleImage);
		
		parent.setBackground(new Color(parent.getDisplay(), 255,255,255));
		StyledText version;
		StyledText fixedIssue;
		StyledText fixedIssueList;
		StyledText whatsnewList;

	    GridLayout gridLayout = new GridLayout(1, false);
	    parent.setLayout(gridLayout);

	    version = new StyledText(parent, SWT.NONE);
	    version.setEditable(false);

	    GridData gridData = new GridData(GridData.FILL_HORIZONTAL);
	    gridData.grabExcessHorizontalSpace = true;
	    whatsnewList = new StyledText(parent, SWT.NONE);
	    //new Label(parent, SWT.NONE);
	   
	    fixedIssue = new StyledText(parent, SWT.NONE);
	    fixedIssue.setEditable(false);
	    fixedIssueList = new StyledText(parent, SWT.NONE);
	    fixedIssueList.setEditable(false);
	    
	    version.setText("Key features in Data Dictionary");
	    version.setFont(new Font(parent.getDisplay(), ApplicationConstant.FONT_STYLE, 14, SWT.BOLD));
	    version.setForeground(new Color(parent.getDisplay(), 0,0,153));
	    
	    whatsnewList.setText(MessageConstant.FEATURES);
	    whatsnewList.setFont(new Font(parent.getDisplay(), ApplicationConstant.FONT_STYLE, 12, SWT.NONE));
	    whatsnewList.setForeground(new Color(parent.getDisplay(), 0,0,0));
	    whatsnewList.setEditable(false);
	}

	/**
	 * Returns the tool tip text for this editor input
	 */
	@Override
	protected Control[] registryDirtyControls() {
		return new Control[0];
	}

	/**
	 * Returns the tool tip text for this editor input
	 */
	@Override
	public void doSave(IProgressMonitor monitor) {
		//Nothing to clean-up
	}
	@Override
	public void dispose() {
		//ApplicationActionBarAdvisor.getInstance().welcomeNoteAction.setChecked(false);
	}
	
	
}
