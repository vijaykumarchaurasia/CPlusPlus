package com.navistar.datadictionary.ui.editors;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.layout.GridDataFactory;
import org.eclipse.nebula.widgets.nattable.NatTable;
import org.eclipse.nebula.widgets.nattable.config.AbstractRegistryConfiguration;
import org.eclipse.nebula.widgets.nattable.config.CellConfigAttributes;
import org.eclipse.nebula.widgets.nattable.config.IConfigRegistry;
import org.eclipse.nebula.widgets.nattable.config.IConfiguration;
import org.eclipse.nebula.widgets.nattable.config.IEditableRule;
import org.eclipse.nebula.widgets.nattable.edit.EditConfigAttributes;
import org.eclipse.nebula.widgets.nattable.edit.editor.TextCellEditor;
import org.eclipse.nebula.widgets.nattable.layer.ILayer;
import org.eclipse.nebula.widgets.nattable.layer.LabelStack;
import org.eclipse.nebula.widgets.nattable.layer.cell.IConfigLabelAccumulator;
import org.eclipse.nebula.widgets.nattable.layer.cell.ILayerCell;
import org.eclipse.nebula.widgets.nattable.style.CellStyleAttributes;
import org.eclipse.nebula.widgets.nattable.style.DisplayMode;
import org.eclipse.nebula.widgets.nattable.style.Style;
import org.eclipse.nebula.widgets.nattable.style.theme.ModernNatTableThemeConfiguration;
import org.eclipse.nebula.widgets.nattable.style.theme.ThemeConfiguration;
import org.eclipse.nebula.widgets.nattable.ui.binding.UiBindingRegistry;
import org.eclipse.nebula.widgets.nattable.util.GUIHelper;
import org.eclipse.nebula.widgets.nattable.viewport.command.ShowRowInViewportCommand;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MenuDetectEvent;
import org.eclipse.swt.events.MenuDetectListener;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.PlatformUI;

import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.IconsPathConstant;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.model.CategoryAttributesIo;
import com.navistar.datadictionary.ui.nattable.CreateNatTable;
import com.navistar.datadictionary.ui.nattable.DefaultNatTableStyleConfiguration;
import com.navistar.datadictionary.ui.nattable.DeleteRowCommand;
import com.navistar.datadictionary.util.DataDictionaryUtil;

/**
 * Class used for ComponentIpEditor
 * @author nikitak1
 *
 */
public class ComponentIpEditor extends AbstractBaseEditor implements  IConfiguration{

	/** Used to get the Component Inputs Editor ID */
	public static final String EDITOR_ID = ApplicationConstant.COMP_IP_EDIT_ID;

	/** Used to get the deleted row list */
	public Set<Integer> deletedRowLists;

	/** Used to create the Nat Table */
	//private NatTable natTable;	

	/** It points to current shell of display */
	//private Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();

	/** Used to create the nat table service */
	private CreateNatTable createNatTable;

	/** Used to access nat table operations */
	//private NatTableOperation natTableOperation;

	/** Used to acess editor service */
	//private EditorService editorService;

	private static final String HIGHLIGHTLBL = "FOO";

	/** Search Index */
	private int searchedIndex;
	
	/** Composite */
	public Composite parent;
	
	private ComponentIpEditorInput inputEditor;

	/** Used to create the Nat Table */
	private NatTable natTable;
	
	
	private Map<ILayerCell,String> compIpCellDataMap = new HashMap<>();

	public Map<ILayerCell, String> getCompIpCellDataMap() {
		return compIpCellDataMap;
	}


	public void setCompIpCellDataMap(Map<ILayerCell, String> compIpCellDataMap) {
		this.compIpCellDataMap = compIpCellDataMap;
	}

	/**
	 * default constructor
	 */
	public ComponentIpEditor() {
		//natTableOperation = new  NatTableOperation();
		createNatTable = new CreateNatTable();
		//editorService = new  EditorServiceImpl();

	}
	
	/**
	 * Method used to get the composite
	 * 
	 * @return
	 */
	public Composite getParent() {
		return parent;
	}
	
	/**
	 * Method used to show the input editor data.
	 */
	@Override
	public void showData() {

		ComponentIpEditorInput inputEditor = (ComponentIpEditorInput) this.getEditorInput();
		// Displaying tab name
		this.setPartName(inputEditor.getName() == null ? "" : inputEditor.getName());
	}
	
	public void createUIComponent() {
		
		inputEditor = (ComponentIpEditorInput) this.getEditorInput();
		parent.setLayout(new GridLayout(2, false));

		natTable = createNatTable.displayNatTableIO(parent, inputEditor.getCompIpList());
		
		final ThemeConfiguration fontTheme = new ModernNatTableThemeConfiguration();
		natTable.setTheme(fontTheme);

		DefaultNatTableStyleConfiguration natTableConfig = new DefaultNatTableStyleConfiguration();
		natTable.addConfiguration(natTableConfig);
		natTable.addConfiguration(compIpTableConfig());
		natTable.setSize(500, 200);
		GridData natTableData = new GridData(SWT.FILL, SWT.FILL, true, true);
		natTableData.horizontalSpan = 2;
		natTableData.heightHint = 200;
		natTableData.horizontalAlignment = GridData.FILL;
		natTable.setLayoutData(natTableData);

		this.natTable.addConfiguration(this);
		this.natTable.configure();
	}

	/**
	 *  Method used to create the Component Inputs editor with its default setting.
	 */
	@Override
	protected void createPartControl2(Composite parent) {

		Image windowTitleImage = new Image(PlatformUI.getWorkbench().getDisplay(), ComponentIpEditor.class.getResourceAsStream(IconsPathConstant.COMMON_WINDOW));
		this.setTitleImage(windowTitleImage);
		this.parent = parent;
		// Create UI Components
		createUIComponent();
		addNatTableConfiguration();
		
		natTable.configure();
		GridDataFactory.fillDefaults().grab(true, true).applyTo(natTable);

	}

	/**
	 * Method used to add configurations for natTable
	 */
	public void addNatTableConfiguration() {

		List<CategoryAttributesIo> compIpList = inputEditor.getCompIpList();
		String dataObject = inputEditor.getDataObject();
		String componentName = inputEditor.getComponentName();
		String categoryName = inputEditor.getCategoryName();
		searchedIndex = DataDictionaryUtil.searchIndexIo(dataObject,componentName,categoryName, compIpList);

		// Custom label "FOO" for cell at column, row index (1, 5)
		IConfigLabelAccumulator cellLblAccum = new IConfigLabelAccumulator() {
			@Override
			public void accumulateConfigLabels(LabelStack configLabels,
					int columnPosition, int rowPosition) {

				int rowIndex = createNatTable.getDataLayer() .getRowIndexByPosition(rowPosition);

				if (rowIndex == searchedIndex) {
					configLabels.addLabel(HIGHLIGHTLBL);               	
				}
			}
		};
		createNatTable.getDataLayer().setConfigLabelAccumulator(cellLblAccum);
		this.natTable.doCommand(new ShowRowInViewportCommand(this.createNatTable.getGridLayer().getBodyLayer(), searchedIndex));

	this.natTable.addConfiguration(this);
	this.natTable.configure();
	
	}
	
	public static AbstractRegistryConfiguration ioTableConfiguration() {

		return new AbstractRegistryConfiguration() {

			@Override
			public void configureRegistry(IConfigRegistry configRegistry) {
				Style cellStyle = new Style();
				cellStyle.setAttributeValue(CellStyleAttributes.BACKGROUND_COLOR,
						GUIHelper.getColor(new RGB(135, 206, 250)));
				configRegistry.registerConfigAttribute(CellConfigAttributes.CELL_STYLE, cellStyle, DisplayMode.NORMAL,
						HIGHLIGHTLBL);	
				
				configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE,
						IEditableRule.NEVER_EDITABLE);
				
				configRegistry.registerConfigAttribute(
						EditConfigAttributes.CELL_EDITOR,
						new TextCellEditor() {
							@Override
							public Text createEditorControl(Composite parent) {
								Text textControl = super.createEditorControl(parent);
								// disable context menu in Text field
								textControl.addMenuDetectListener(new MenuDetectListener() {
									@Override
									public void menuDetected(MenuDetectEvent event) {
										//event.doit = false;
									}
								});
								return textControl;
							}
						});
			}

		};
	}

	
	public static AbstractRegistryConfiguration compIpTableConfig() {

		return new AbstractRegistryConfiguration() {

			@Override
			public void configureRegistry(IConfigRegistry configRegistry) {
				Style cellStyle = new Style();
				cellStyle.setAttributeValue(CellStyleAttributes.BACKGROUND_COLOR,
						GUIHelper.getColor(new RGB(135, 206, 250)));
				configRegistry.registerConfigAttribute(CellConfigAttributes.CELL_STYLE, cellStyle, DisplayMode.NORMAL,
						HIGHLIGHTLBL);	
				
				configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE,
						IEditableRule.NEVER_EDITABLE);
				
				configRegistry.registerConfigAttribute(
						EditConfigAttributes.CELL_EDITOR,
						new TextCellEditor() {
							@Override
							public Text createEditorControl(Composite parent) {
								Text textControl = super.createEditorControl(parent);
								// disable context menu in Text field
								textControl.addMenuDetectListener(new MenuDetectListener() {
									@Override
									public void menuDetected(MenuDetectEvent event) {
										//event.doit = false;
									}
								});
								return textControl;
							}
						});
			}

		};
	}
	
	/**
	 * This method is used to perform action after clicking on Delete Data Object
	 * context menu for category table.
	 */
	/*public void deleteDataObjectFromContextMenu() {
		boolean delDataDialogVal = MessageDialog.openConfirm(shell, ApplicationConstant.WARNING,
				MessageConstant.DELETE_DATA);
		if (delDataDialogVal) {
			deletedRowLists = new LinkedHashSet<>();
			for (Range r : createNatTable.getSelectionLayer().getSelectedRowPositions()) {
				for (int i = r.start; i < r.end; i++) {
					deletedRowLists.add(i);
				}
			}
			ArrayList<CategoryAttributes> deletedDataList = new ArrayList<>();
			for(int deletedRowIndex : deletedRowLists) {
				deletedDataList.add(natTableOperation.getCategoryForSelectedRow(deletedRowIndex,createNatTable.getJsonDataProvider()));
			}
			boolean delObjStatu = false;
			try {
				delObjStatu = editorService.deleteDataObjectsFromEditor(deletedDataList);
			} catch (MatlabCommunicatinException e) {
				MessageDialog.openConfirm(new Shell(), "Error Message", e.getMessage());
			}
			if (delObjStatu) {
				int rowCount = 0;
				for (int row : deletedRowLists) {

					createNatTable.getSelectionLayer()
					.doCommand(new DeleteRowCommand(createNatTable.getSelectionLayer(), row - rowCount));

					rowCount++;
				}
				setDirty(false);

				IConfigLabelAccumulator cellLblAccum = new IConfigLabelAccumulator() {
					@Override
					public void accumulateConfigLabels(LabelStack configLabels,
							int columnPosition, int rowPosition) {

						int rowIndex = createNatTable.getDataLayer() .getRowIndexByPosition(rowPosition);

						if (rowIndex == searchedIndex) {
							configLabels.removeLabel(HIGHLIGHTLBL);
							//natTable.doCommand(new ShowRowInViewportCommand(createNatTable.getGridLayer().getBodyLayer(), searchedIndex));
						}
					}
				};
				createNatTable.getDataLayer().setConfigLabelAccumulator(cellLblAccum);

				if(IOCompatibilityView.getIOCompatibilityViewInstance() != null) {

					IOCompatibilityService ioCompatService = new IOCompatibilityServiceImpl();
					for(CategoryAttributes category : deletedDataList) {
						ioCompatService.updateIOCompatibilityData(category.getWarning(), category.getComponent(), category.getName(), category.getCategory());

					}
				}

				if(CheckComponentInputsView.getCompInputsViewInstance() != null) {

					CheckComponentInputsServiceimpl checkCompInObj=new CheckComponentInputsServiceimpl();
					for(CategoryAttributes category : deletedDataList) {
						checkCompInObj.updateCompInputsData(category.getWarning(),  category.getComponent(), category.getName(), category.getCategory());
					}
					
					ViewUtil.closeView(ViewIDConstant.COMP_INPUTS);
					ViewUtil.showHideView(ViewIDConstant.COMP_INPUTS, true);
				}
				Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
				MessageDialog.openInformation(shell, ApplicationConstant.INFORMATION,MessageConstant.DELETE_SUCCESS);
			}
		}
		if(!deletedRowLists.isEmpty()) {
			deletedRowLists.clear();
		}

	}*/

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Object getAdapter(Class arg0) {
		return null;
	}


	@Override
	protected Control[] registryDirtyControls() {
		return new Control[0];
	}

	@Override
	public void doSave(IProgressMonitor monitor) {
		 // doSave
	}

	/**
	 * Method is used to find the row index for highlighting it in the table 
	 * @param dataObject
	 * @param componentName
	 * @param categoryName
	 * @param ioCompatibilityList
	 * @return
	 */
	private int searchIndex(String dataObject,String componentName,String categoryName, List<CategoryAttributesIo> compIpList)
	{		
		Iterator<CategoryAttributesIo> iterator = compIpList.iterator();
		int index = 0;
		while (iterator.hasNext()) {
			CategoryAttributes category = iterator.next();
			++index;
			if (category.getName().trim().equals(dataObject.trim()) && category.getComponent().equals(componentName) && category.getCategory().equals(categoryName)) {
				return index-1;
			}
		}
		return -1;
	}

	/**
	 * Method is used to update the CompIpEditor editor after deleting the data object
	 * @param warningName
	 * @param componentName
	 * @param categoryName
	 * @param objectName
	 * @param editors
	 */
	public void refreshCompIpEditor(String warningName, String componentName, String categoryName,
			String objectName, ComponentIpEditor compIpEditor) {

		ComponentIpEditorInput inputEditor = (ComponentIpEditorInput) compIpEditor.getEditorInput();
		List<CategoryAttributesIo> compIpList = inputEditor.getCompIpList();
		int searchIndex = compIpEditor.searchIndex(objectName, componentName, categoryName,
				compIpList);

		createNatTable.getSelectionLayer()
		.doCommand(new DeleteRowCommand(createNatTable.getSelectionLayer(), searchIndex));

		setDirty(false);

	}


	@Override
	public void configureLayer(ILayer arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void configureRegistry(IConfigRegistry arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void configureUiBindings(UiBindingRegistry arg0) {
		// TODO Auto-generated method stub
		
	}

}
