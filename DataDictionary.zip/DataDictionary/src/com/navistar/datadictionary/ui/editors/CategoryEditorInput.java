package com.navistar.datadictionary.ui.editors;

import java.util.List;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IPersistableElement;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.navistar.datadictionary.constant.MatlabQueryConstant;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.util.JsontoList;

/**
 * This class is used for a Corresponding Category editor
 * to send the Category data as an Input.
 * @author nikitak1
 *
 */
public class CategoryEditorInput implements IEditorInput{		
	private JsonElement jsonElement;
	public CategoryEditorInput(JsonElement jsonElement) {		
		this.jsonElement = jsonElement;
	}	

	/**
	 * This method is used to parse the Category data and return
	 * category name as a String.
	 * @return String 
	 */
	private String getCategoryName()
	{		
		JsonObject jsonObject = jsonElement.getAsJsonArray().get(0).getAsJsonObject();
		JsonElement jsonElement =  jsonObject.get(MatlabQueryConstant.CATEGORY);
		
		return jsonElement.getAsString();		
	}	
	
	/**
	 * Used to return a whole Category data as a JsonElement.
	 * @return JsonElement
	 */
	public List<CategoryAttributes> getCategoryAsJSONElement()
	{
		List<CategoryAttributes> newList = JsontoList.listInputs(jsonElement.getAsJsonArray());
		return newList;
	}
	/**
	 * Returns whether the editor input exists
	 */
	@Override
	public boolean exists() {
		return false;
	}
	/**
	 * Returns the image descriptor for this input. 
	 */
	@Override
	public ImageDescriptor getImageDescriptor() {
		return null;
	}
	/**
	 * Returns the name of this editor input for display purpose.
	 */
	@Override
	public String getName() {	
		return getCategoryName();
		
	}	
	/**
	 * Returns an object that can be used to save the state of this editor 
	 * input
	 */
	@Override
	public IPersistableElement getPersistable() {
		return null;
	}
	/**
	 * Returns the tool tip text for this editor input
	 */
	@Override
	public String getToolTipText() {
		return getCategoryName();
	}
	/**
	 * This is overridden method.
	 */
	@Override
	public Object getAdapter(@SuppressWarnings("rawtypes") Class arg0) {
		return null;
	}

}
