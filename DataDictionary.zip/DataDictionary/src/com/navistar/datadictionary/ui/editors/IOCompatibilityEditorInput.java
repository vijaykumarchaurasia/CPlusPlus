package com.navistar.datadictionary.ui.editors;

import java.util.List;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IPersistableElement;

import com.navistar.datadictionary.model.CategoryAttributesIo;

/**
 * This class is used for a Corresponding I/O Compatibility editor
 * to send the I/O Compatibility data as an Input.
 * @author nikitak1
 *
 */
public class IOCompatibilityEditorInput implements IEditorInput{

	/** I/O Compatibility list*/
	private List<CategoryAttributesIo> iOCompatList;
	/** Data Object*/
	private String dataObject;
	/** Component Name*/
	private String componentName;
	/** Category Name*/
	private String categoryName;
	
	/**
	 * Parameterized constructor
	 * @param dataObject
	 * @param componentName
	 * @param categoryName
	 * @param iOCompatibilityList
	 */
	public IOCompatibilityEditorInput(String dataObject,String componentName,String categoryName, List<CategoryAttributesIo> iOCompatList) {
		this.dataObject = dataObject;
		this.iOCompatList = iOCompatList;
		this.componentName = componentName;
		this.categoryName = categoryName;
	}
	
	/**
	 * Method is used to get category name
	 * @return
	 */
	public String getCategoryName() {
		return categoryName;
	}
	
	/**
	 * Method is used to get component name
	 * @return
	 */
	public String getComponentName()
	{
		return componentName;
	}
	
	/**
	 * Method is used to get data object
	 * @return
	 */
	public String getDataObject()
	{
		return dataObject;
	}
	
	/**
	 * Method is used to get I/O compatibility list
	 * @return
	 */
	public List<CategoryAttributesIo> getIOCompatibilityList()
	{
		return iOCompatList;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public Object getAdapter(Class arg0) {
		return null;
	}

	/**
	 * Method checks for editor data exist
	 */
	@Override
	public boolean exists() {
		return false;
	}

	/**
	 * Method is used to get Image descriptor
	 */
	@Override
	public ImageDescriptor getImageDescriptor() {
		return null;
	}

	/**
	 * Returns the name of this editor input for display purposes
	 */
	@Override
	public String getName() {
		return iOCompatList.get(0).getWarning();
	}

	/**
	 * Returns an object that can be used to save the state of this editor input.
	 */
	@Override
	public IPersistableElement getPersistable() {
		return null;
	}

	/**
	 * Returns the tool tip text for this editor input
	 */
	@Override
	public String getToolTipText() {
		return iOCompatList.get(0).getWarning();
	}

}
