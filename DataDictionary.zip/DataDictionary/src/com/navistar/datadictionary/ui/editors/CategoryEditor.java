package com.navistar.datadictionary.ui.editors;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.NavigableSet;
import java.util.Set;
import java.util.Stack;
import java.util.TreeSet;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.nebula.widgets.nattable.NatTable;
import org.eclipse.nebula.widgets.nattable.config.AbstractRegistryConfiguration;
import org.eclipse.nebula.widgets.nattable.config.CellConfigAttributes;
import org.eclipse.nebula.widgets.nattable.config.IConfigRegistry;
import org.eclipse.nebula.widgets.nattable.config.IConfiguration;
import org.eclipse.nebula.widgets.nattable.copy.command.CopyDataToClipboardCommand;
import org.eclipse.nebula.widgets.nattable.data.IDataProvider;
import org.eclipse.nebula.widgets.nattable.edit.EditConfigAttributes;
import org.eclipse.nebula.widgets.nattable.edit.editor.TextCellEditor;
import org.eclipse.nebula.widgets.nattable.grid.GridRegion;
import org.eclipse.nebula.widgets.nattable.grid.layer.GridLayer;
import org.eclipse.nebula.widgets.nattable.layer.ILayer;
import org.eclipse.nebula.widgets.nattable.layer.ILayerListener;
import org.eclipse.nebula.widgets.nattable.layer.LabelStack;
import org.eclipse.nebula.widgets.nattable.layer.LayerUtil;
import org.eclipse.nebula.widgets.nattable.layer.cell.ColumnOverrideLabelAccumulator;
import org.eclipse.nebula.widgets.nattable.layer.cell.IConfigLabelAccumulator;
import org.eclipse.nebula.widgets.nattable.layer.cell.ILayerCell;
import org.eclipse.nebula.widgets.nattable.layer.event.ILayerEvent;
import org.eclipse.nebula.widgets.nattable.layer.event.StructuralRefreshEvent;
import org.eclipse.nebula.widgets.nattable.selection.SelectionLayer;
import org.eclipse.nebula.widgets.nattable.selection.command.SelectCellCommand;
import org.eclipse.nebula.widgets.nattable.selection.event.CellSelectionEvent;
import org.eclipse.nebula.widgets.nattable.selection.event.RowSelectionEvent;
import org.eclipse.nebula.widgets.nattable.style.CellStyleAttributes;
import org.eclipse.nebula.widgets.nattable.style.DisplayMode;
import org.eclipse.nebula.widgets.nattable.style.Style;
import org.eclipse.nebula.widgets.nattable.style.theme.ModernNatTableThemeConfiguration;
import org.eclipse.nebula.widgets.nattable.style.theme.ThemeConfiguration;
import org.eclipse.nebula.widgets.nattable.ui.binding.UiBindingRegistry;
import org.eclipse.nebula.widgets.nattable.ui.matcher.MouseEventMatcher;
import org.eclipse.nebula.widgets.nattable.ui.menu.IMenuItemProvider;
import org.eclipse.nebula.widgets.nattable.ui.menu.PopupMenuAction;
import org.eclipse.nebula.widgets.nattable.ui.menu.PopupMenuBuilder;
import org.eclipse.nebula.widgets.nattable.util.GUIHelper;
import org.eclipse.nebula.widgets.nattable.viewport.command.ShowRowInViewportCommand;
import org.eclipse.nebula.widgets.nattable.viewport.event.ScrollEvent;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.MenuDetectEvent;
import org.eclipse.swt.events.MenuDetectListener;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.IReusableEditor;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPartConstants;
import org.eclipse.ui.PlatformUI;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.navistar.datadictionary.action.CopyAction;
import com.navistar.datadictionary.action.CutAction;
import com.navistar.datadictionary.action.EditorPreference;
import com.navistar.datadictionary.action.PasteAction;
import com.navistar.datadictionary.action.SaveAllAction;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.IconsPathConstant;
import com.navistar.datadictionary.constant.MatlabQueryConstant;
import com.navistar.datadictionary.constant.MatlabScriptConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.customexception.EditorInitilizationException;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.daoimpl.MatlabCommunicationDaoImpl;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.model.FontStyleDAO;
import com.navistar.datadictionary.model.NatTableRowData;
import com.navistar.datadictionary.model.NatTableRowIndex;
import com.navistar.datadictionary.model.NatTableRowIndexArray;
import com.navistar.datadictionary.model.NatTableRowIndexArrayForDelete;
import com.navistar.datadictionary.model.NatTableRowIndexDelete;
import com.navistar.datadictionary.model.SaveResponseCode;
import com.navistar.datadictionary.model.TableCell;
import com.navistar.datadictionary.model.TableCellArray;
import com.navistar.datadictionary.operation.SaveOperation;
import com.navistar.datadictionary.operation.UndoRedoOperation;
import com.navistar.datadictionary.service.EditorService;
import com.navistar.datadictionary.serviceimpl.EditorServiceImpl;
import com.navistar.datadictionary.serviceimpl.ExcelImportExportServiceImpl;
import com.navistar.datadictionary.serviceimpl.FindInModelServiceImpl;
import com.navistar.datadictionary.serviceimpl.ImportProjectServiceImpl;
import com.navistar.datadictionary.serviceimpl.OpenComponentServiceImpl;
import com.navistar.datadictionary.serviceimpl.RenameInModelServiceimpl;
import com.navistar.datadictionary.serviceimpl.ResolveInconsistencyServiceImpl;
import com.navistar.datadictionary.serviceimpl.SaveServiceImpl;
import com.navistar.datadictionary.ui.config.Activator;
import com.navistar.datadictionary.ui.config.Application;
import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.ui.config.DataDictionaryApplication;
import com.navistar.datadictionary.ui.nattable.CreateNatTable;
import com.navistar.datadictionary.ui.nattable.DefaultNatTableStyleConfiguration;
import com.navistar.datadictionary.ui.nattable.DeleteRowCommand;
import com.navistar.datadictionary.ui.nattable.NatTableEditConfiguration;
import com.navistar.datadictionary.ui.nattable.NatTableOperation;
import com.navistar.datadictionary.ui.views.ActivityLogView;
import com.navistar.datadictionary.ui.views.AddDataObjectWindow;
import com.navistar.datadictionary.ui.views.ApplyCdfView;
import com.navistar.datadictionary.ui.views.CustomMessageDialog;
import com.navistar.datadictionary.ui.views.ImportFromExcelWindowView;
import com.navistar.datadictionary.ui.views.InconsistencyWindowView;
import com.navistar.datadictionary.ui.views.MinMaxInfoView;
import com.navistar.datadictionary.ui.views.TableEditiorView;
import com.navistar.datadictionary.util.CreateMatlabRequest;
import com.navistar.datadictionary.util.DataDictionaryUtil;
import com.navistar.datadictionary.util.FixedStack;
//import com.navistar.datadictionary.util.FontStylingThemeConfiguration;
import com.navistar.datadictionary.util.JsontoList;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Class used to create the category editor and display NatTable.
 * 
 * @author minalc
 *
 */
public class CategoryEditor extends AbstractBaseEditor
implements IReusableEditor, SelectionListener, ILayerListener, IConfiguration {

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(CategoryEditor.class);

	public String data = "";

	public String data1 = "";

	public int rowidx = 0;

	public int columnindex = 0;

	/** Used to access Min Max Window */
	private MinMaxInfoView minMaxView;

	private boolean rowDeleted = false;

	/** Used to check the category editor count */
	private static int catEditorCount = 0;

	/** Used to get the Category Editor ID */
	public static final String CAT_EDI_ID = ApplicationConstant.CAT_EDITOR_ID;

	/** Used to create the Nat Table */
	public NatTable natTable;

	/** Used to create the cell selection event */
	private CellSelectionEvent cellEvent;
	
	/** Used to create the row selection event */
	private RowSelectionEvent rowEvent;

	/** Used to create the table cell list */
	public List<TableCell> tableCellList;

	/** Used to create the nat table service */
	public CreateNatTable createNatTable = new CreateNatTable();

	/** Used to create the nat table service */
	public NatTableOperation natTableOperation = new NatTableOperation();

	/** Used to perform undo redo operation */
	public UndoRedoOperation undoRedoOperation = new UndoRedoOperation();

	/** Used to access find in model service */
	public FindInModelServiceImpl findInModelSer = new FindInModelServiceImpl();

	/** Used to perform save operation */
	public SaveOperation saveOperation = new SaveOperation();

	/** Stack for undo actions */
	public Stack<Object> undoEditStack;

	/** Stack for redo actions */
	public Stack<Object> redoEditorStack;

	/** Used to get the newly added row list */
	public Set<Integer> newAddedRowList;

	/** Used to get the edited row list */
	public Set<Integer> editRowLists;

	/** Used to get the added row list */
	public Set<Integer> addedRowLists;

	/** list used when multiple row pasted */
	public List<Object> natTblRowDataList;

	/** list used when multiple table cell pasted */
	public List<Object> tableCellDataList;

	/** Used to get row for find in Model */
	private int rowForFindInModel;

	/** used to store all newly added objects in single list for all editors */
	public static List<CategoryAttributes> allNewObjList;

	/** Used to get the new row index */
	private int newRowIndex;

	/** It points to current shell of display */
	private Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();

	/** data object list from matlab */
	public List<CategoryAttributes> matlabDataObjList;

	/** updated data object list before save */
	public List<CategoryAttributes> updatDataObjList;

	/** data object list from matlab */
	public List<CategoryAttributes> savedDataObjList;

	/** Composite */
	public Composite parent;

	/** missing empty field flag */
	public boolean emptyFieldFlag;

	/** Find in Model Button */
	private Button btnFindInModel;

	/** Find in Add Data Object */
	//private Button btnAddDataObj;

	/** Nattable Row Index */
	public static int rowIndex;

	/** Nattable Column Index */
	public static int colIndex;

	/** categoryEditor */
	CategoryEditor categoryEdiObj;

	/** comboBoxCellEditor */
	//ComboBoxCellEditor comboBoxEditor;

	/** dirty listener for editor */
	private DirtyListenerImpl dirtyListener;

	/** categoryInputEditor for editor */
	CategoryEditorInput catInputEditor;

	/** pop-menu for natTable */
	private Menu bodyMenu;

	/** Nattable Grid Layer */
	private GridLayer gridLayer;

	/** Selected data object by cell event or row selection event */
	public String selDataObj;

	/** Column index required for find in model using cell or row selection */
	private int columnfindInModel;

	/** Selected Cells */
	private static Collection<ILayerCell> selectedCells;

	/** flag used if duplicate name available in opened component */
	public static boolean duplicNameFlg;

	/** flag used if duplicate name available in opened component */
	public boolean emptyFieldsFlag;

	/** flag used if user try to save invalid name */
	public boolean invalidNameFlag;

	/*** flag used if any cell is in edited mode */
	public boolean editModeFlag;

	/** Search Index */
	private int searchedIndex;

	/** High Light Label */
	private static final String HIGHLIGHTLBL = "HightLight";

	/** High Light Label */
	private static final String ADDOBJLBL = "AddObject";

	/** High Light Label */
	private static final String DELETEOBJLBL = "DeleteObject";

	/** Used to store cell data */
	public Map<ILayerCell, String> cellDataMap;

	/** Used for pop-up message */
	public String message = "";

	public static int lastSelectedRow;
	public static int lastSelCol;

	/** Used to store all category deleted data objects */
	public static Map<String, List<CategoryAttributes>> deletedListMap = new HashMap<String, List<CategoryAttributes>>();

	double minRange;
	double maxRange;
	
	double prevRowMinRange;
	double prevRowMaxRange;
	
	public String selOutputDataObj = "";

	private boolean ignorValidnFlg = false ;
	
	private List<Object> cutList;

	/** Default Constructor */
	public CategoryEditor() {
		tableCellList = new ArrayList<>();

		minMaxView = new MinMaxInfoView();

		newAddedRowList = new LinkedHashSet<>();

		editRowLists = new LinkedHashSet<>();

		addedRowLists = new LinkedHashSet<>();

		matlabDataObjList = new ArrayList<>();

		savedDataObjList = new ArrayList<>();

		updatDataObjList = new ArrayList<>();

		natTblRowDataList = new ArrayList<>();

		tableCellDataList = new ArrayList<>();

		emptyFieldFlag = false;

		emptyFieldsFlag = false;
		invalidNameFlag = false;

		duplicNameFlg = false;

		undoEditStack = new FixedStack<Object>(ApplicationConstant.MAX_STACK_SIZE);
		redoEditorStack = new FixedStack<Object>(ApplicationConstant.MAX_STACK_SIZE);
		undoRedoOperation.makeUndoRedoEnableDisable(undoEditStack, redoEditorStack);
		this.categoryEdiObj = this;

		cellDataMap = new HashMap<>();
		
		cutList = new ArrayList<>();
	}

	/**
	 * Method used to get the composite
	 * 
	 * @return
	 */
	public Composite getParent() {
		return parent;
	}

	/**
	 * Method used to show the input editor data.
	 */
	@Override
	public void showData() {
		CategoryEditorInput inputEditor = (CategoryEditorInput) this.getEditorInput();
		// Displaying tab name
		this.setPartName(inputEditor.getName() == null ? "" : inputEditor.getName());

		// Update component Data
		Map<String, List<CategoryAttributes>> componentMapList = DataDictionaryApplication.getApplication()
				.getComponentMapList();
		componentMapList.put(inputEditor.getName(), this.savedDataObjList);
		DataDictionaryApplication.getApplication().setComponentMapList(componentMapList);
	}

	/**
	 * Method used to set the UI component for editor
	 */
	public void createUIComponent() {
		Button btnAddDataObj = new Button(parent, SWT.PUSH);
		btnAddDataObj.setText(ApplicationConstant.BTN_ADDDATAOBJECT);
		btnAddDataObj.setFont(new Font(parent.getDisplay(), ApplicationConstant.APP_FONT_STYLE, 11, SWT.None));
		btnAddDataObj.addSelectionListener(this);

		GridData addDataObjgrid = new GridData();
		addDataObjgrid.grabExcessVerticalSpace = false;
		addDataObjgrid.grabExcessHorizontalSpace = true;
		addDataObjgrid.widthHint = 130;
		addDataObjgrid.heightHint = 30;
		btnAddDataObj.setLayoutData(addDataObjgrid);

		btnFindInModel = new Button(parent, SWT.PUSH);
		// btnFindInModel.setBounds(10, 20, 75, 25);
		btnFindInModel.setText(ApplicationConstant.BTN_FINDINMODEL);
		btnFindInModel.setFont(new Font(parent.getDisplay(), ApplicationConstant.APP_FONT_STYLE, 11, SWT.None));
		btnFindInModel.setEnabled(false);
		btnFindInModel.addSelectionListener(this);

		GridData findInModelData = new GridData();
		findInModelData.grabExcessVerticalSpace = false;
		findInModelData.grabExcessHorizontalSpace = true;
		findInModelData.widthHint = 120;
		findInModelData.heightHint = 30;
		findInModelData.horizontalAlignment = GridData.END;
		btnFindInModel.setLayoutData(findInModelData);

		catInputEditor = (CategoryEditorInput) this.getEditorInput();
		parent.setLayout(new GridLayout(2, false));

		natTable = createNatTable.displayNatTable(parent, catInputEditor.getCategoryAsJSONElement());
		final ThemeConfiguration fontTheme = new ModernNatTableThemeConfiguration();
		natTable.setTheme(fontTheme);
		matlabDataObjList = catInputEditor.getCategoryAsJSONElement();
		savedDataObjList = catInputEditor.getCategoryAsJSONElement();

		// Add default style configuration to the NAT table
		FontStyleDAO fontStyle = DataDictionaryApplication.getApplication().fontStyle;
		DefaultNatTableStyleConfiguration natTableConfig = new DefaultNatTableStyleConfiguration();
		//If font is set and store default font is not set then apply the selected font else set default font
		if(fontStyle != null && fontStyle.getFont() != null && !EditorPreference.isDefFontSel) {
			int height = fontStyle.getSize();
			natTableConfig.font = new Font(PlatformUI.getWorkbench().getDisplay(), fontStyle.getFont(), height,fontStyle.getFontStyle()) ;
			natTableConfig.fgColor = new Color(PlatformUI.getWorkbench().getDisplay(),fontStyle.getFontColor()) ;
			createNatTable.getDataLayer().setDefaultRowHeight(height*2);
		}
		natTable.addConfiguration(natTableConfig);
		natTable.addConfiguration(editableGridConfiguration(catInputEditor.getName(),
				createNatTable.getJsonDataProvider(), createNatTable.getColumnLabelAccumulator()));
		natTable.setSize(500, 200);
		GridData natTableData = new GridData(SWT.FILL, SWT.FILL, true, true);
		natTableData.horizontalSpan = 2;
		natTableData.heightHint = 200;
		natTableData.horizontalAlignment = GridData.FILL;
		natTable.setLayoutData(natTableData);

		dirtyListener = new DirtyListenerImpl();
		this.natTable.addLayerListener(this);
		this.natTable.addConfiguration(this);
		this.natTable.configure();
	}

	/**
	 * Method used to create the category editor with its default setting.
	 * 
	 * @param parent
	 */
	@Override
	protected void createPartControl2(Composite parent) {
		Image windowTitleImage = new Image(PlatformUI.getWorkbench().getDisplay(),
				CategoryEditor.class.getResourceAsStream(IconsPathConstant.COMMON_WINDOW));
		categoryEdiObj.setTitleImage(windowTitleImage);

		this.parent = parent;
		catEditorCount += 1;
		// Create UI Components
		createUIComponent();
		addNatTableConfiguration();
		
		natTable.addMouseListener(new MouseListener() {

			@Override
			public void mouseUp(MouseEvent event) {
				// nothing to clean-up
			}

			@Override
			public void mouseDown(MouseEvent event) {
				// nothing to clean-up
			}

			@Override
			public void mouseDoubleClick(MouseEvent event) {
				editModeFlag = true;
			}
		});

		natTable.addKeyListener(new KeyListener() {

			@Override
			public void keyReleased(KeyEvent event) {
				// nothing to clean-up
			}

			@Override
			public void keyPressed(KeyEvent event) {
				if (Character.isLetterOrDigit(event.keyCode)) {
					editModeFlag = true;
				}
			}
		});
	}

	/**
	 * Method used to add configurations for natTable
	 */
	public void addNatTableConfiguration() {

		if (DataDictionaryApplication.getApplication().isSearchedHighLight()) {
			//changed from matlabDataObjectList to updCatList because after adding and deleting data objects list was not getting updated
			List<CategoryAttributes> updCatList = categoryEdiObj.createNatTable.getJsonDataProvider().getList();
			
			// Custom label "High_Light_LABEL" for cell at column, row index (1, 5)
			IConfigLabelAccumulator cellLblAccum = new IConfigLabelAccumulator() {
				@Override
				public void accumulateConfigLabels(LabelStack configLabels, int columnPosition, int rowPosition) {

					CategoryAttributes catAttributes = DataDictionaryApplication.getApplication()
							.getSearchedHighlighted();
					if(catAttributes!=null) {
						searchedIndex = DataDictionaryUtil.searchIndex(catAttributes.getName(),
								catAttributes.getComponent(), catAttributes.getCategory(), updCatList);

						int rowIndex = createNatTable.getDataLayer().getRowIndexByPosition(rowPosition);
						if (rowIndex == searchedIndex) {
							configLabels.addLabel(HIGHLIGHTLBL);
						}
					}
				}
			};
			createNatTable.getSelectionLayer().setConfigLabelAccumulator(cellLblAccum);
			DataDictionaryApplication.getApplication().setSearchedHighLight(false);
			
			//to focus the highlighted row in category table
			CategoryAttributes catAttributes = DataDictionaryApplication.getApplication()
					.getSearchedHighlighted();
			searchedIndex = DataDictionaryUtil.searchIndex(catAttributes.getName(),
					catAttributes.getComponent(), catAttributes.getCategory(), updCatList);
			this.natTable.doCommand(new ShowRowInViewportCommand(this.createNatTable.getGridLayer().getBodyLayer(), searchedIndex));
		}

		this.natTable.addConfiguration(this);
		this.natTable.configure();
		
	}

	/**
	 * Method used when any cell event for natTable occur
	 * 
	 * @param rowIndex
	 * @param colIndex
	 */
	public void setDirtyListenerData(int rowIndex, int colIndex) {

		try {
			CategoryAttributes rangeValues = null;

			// Get the selected rowIndex using natTable
			if (rowIndex >= 0 && colIndex >= 0) {
				int selectedRowIndex = natTable.getRowIndexByPosition(rowIndex);
				GridLayer dataLayer = createNatTable.getGridLayer();

				// Get the selected columnIndex using gridLayer
				int selColIndex = dataLayer.getColumnIndexByPosition(colIndex);
				int columnAfterName = -1;
				columnAfterName = getColumnAfterNameColumn();

				if (selColIndex == columnAfterName) {
					// Check name is valid or not
					isNameValid(cellEvent);
				}

				if(selColIndex == CreateNatTable.colOffIdx) {
					if(selectedRowIndex!=-1) {
						checkBaseTypeValidation(selColIndex,selectedRowIndex);
					}
				}
				if(selColIndex == CreateNatTable.colSlopIdx) {
					if(selectedRowIndex!=-1) {
						checkOffsetValidation(selColIndex,selectedRowIndex);
					}
				}
				
				
				if(selColIndex == CreateNatTable.colMinIdx || selColIndex == CreateNatTable.colMaxIdx) {
					if(selectedRowIndex!=-1) {
						Object objSlope = this.createNatTable.getJsonDataProvider().getDataValue(CreateNatTable.colSlopIdx,
								selectedRowIndex);
						if(checkBaseTypeValidation(selColIndex,selectedRowIndex) && checkOffsetValidation(selColIndex,selectedRowIndex)
								&& checkSlopeValidation(selColIndex, objSlope)) {
							ViewUtil.showHideView(ViewIDConstant.MIN_MAX_INFO, true);
							minMaxView.setData(selectedRowIndex);
							rangeValues = updateMinMaxRange(selectedRowIndex);
						} 
					}
				}
				else {
					// Close the view part
					ViewUtil.closeView(ViewIDConstant.MIN_MAX_INFO);
				}
				if(selectedRowIndex!=-1) {
				rangeValues = updateMinMaxRange(selectedRowIndex);
				// If selected column is value or initial value table view to be shown
				showTableView(selectedRowIndex, selColIndex);

				// Change Dimensions w.r.t Initial Value
				changeDimensions();

				// Change Units dropdown value by removing its name after ":"
				changeUnitDrpDwnVal(selColIndex);

				if (selColIndex == CreateNatTable.colMinIdx) {
					setMinMaxRange(rangeValues);
				}

				if (selColIndex == CreateNatTable.colMaxIdx) {
					setMinMaxRange(rangeValues);
					/*if (!isMinValid(cellEvent)) {
						return;
					}*/
				}
				
				if(Application.valueCatList.contains(this.getTitle())) {
					checkValueValidation(selColIndex);
				}
			

				checkInitialValueValidation(selColIndex);

				//checkMinMaxValidation(selColIndex, rangeValues);

				checkUnitValidation(selColIndex, selectedRowIndex);

				updateUndo(selectedRowIndex, selColIndex);
				
				if(!ignorValidnFlg ) {
					valdteMinMaxPrevEditdRow(selColIndex, selectedRowIndex);
				}
				
				}
				

			}
		} catch (Exception e) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			MessageDialog messageDialog = new MessageDialog(null, "Error Message", null,
					"Error while data modification (Check Log for More Information)", 0, new String[] { "Change" }, 0);
			messageDialog.open();
		} 
	}

	
	/*private void removeSearchedHighlight() {
		if(SearchResultView.getSearchResultViewInstance()!=null && SearchResultView.getSearchResultViewInstance().isSearchdDtaBlue) {	
			createNatTable.getSelectionLayer().setConfigLabelAccumulator(null);
			SearchResultView.getSearchResultViewInstance().isSearchdDtaBlue = false;
		}
		this.natTable.redraw();
		//removeNatTableConfigurationForAddResolve();
	}*/

	/**
	 * Method used to validate the min max range for edited and new rows
	 * @param selColIndex
	 */
	private void valdteMinMaxPrevEditdRow(int selColIndex, int selRowIndex) {
		
			for(int editedRow : editRowLists) {
				updateMinMaxRange(editedRow);
				if(selRowIndex!=editedRow || (!(selColIndex==CreateNatTable.colMinIdx || selColIndex==CreateNatTable.colMaxIdx))) {
					isMinValid(editedRow);
					checkMinMaxAfterFocusLost(editedRow);
				}
			}
			for(int newRow : newAddedRowList) {
				updateMinMaxRange(newRow);
				if(selRowIndex!=newRow || (!(selColIndex==CreateNatTable.colMinIdx || selColIndex==CreateNatTable.colMaxIdx))) {
					isMinValid(newRow);
					checkMinMaxAfterFocusLost(newRow);
				}
			}
	}


	/**
	 * Method used to validate previously edited row Min Max value entered by user
	 * 
	 * @param rowIndex
	 * @param selColIndex
	 * @param selectedCellEvent
	 * @return
	 */
	private boolean checkMinMaxAfterFocusLost(int rowIndex) {
		
		int prevCol = 0;
		boolean focusColMax = false;
		try {
			Object minNumber = createNatTable.getJsonDataProvider().getDataValue(CreateNatTable.colMinIdx, rowIndex);
			Object maxNumber = createNatTable.getJsonDataProvider().getDataValue(CreateNatTable.colMaxIdx, rowIndex);


			if ((minNumber != null && maxNumber != null) && (maxNumber.equals("") && minNumber.equals(""))) {
				return true;
			} 
			else if ((minNumber != null && maxNumber != null) && (maxNumber.equals("") && !minNumber.equals(""))) {
				double minVal = Double.parseDouble((String) minNumber);
				if (minVal > this.prevRowMaxRange || minVal < this.prevRowMinRange) {
					prevCol = createNatTable.getSelectionLayer().getColumnPositionByIndex(CreateNatTable.colMinIdx);
					openMessageDialogForMinMaxValidation(parent.getDisplay(),
							MessageConstant.VAL_FOR_MIN_MAX, rowIndex, prevCol);

					return false;
				}
			} 
			else if (maxNumber != null && !maxNumber.equals("")) {
				focusColMax = true;
				double maxVal = Double.parseDouble((String) maxNumber);
				if (!(maxVal <= this.prevRowMaxRange)) {
					prevCol = createNatTable.getSelectionLayer().getColumnPositionByIndex(CreateNatTable.colMaxIdx);
					openMessageDialogForMinMaxValidation(parent.getDisplay(),
							MessageConstant.VAL_FOR_MIN_MAX, rowIndex, prevCol);
					return false;
				}

				return valdtMnMxRngeAfrFcsLost(rowIndex,minNumber, maxVal);

			}
			/*if (this.getTitle().equals(ApplicationConstant.CATEGORY_DEFINE)) {
				if (maxNumber == null || maxNumber.equals("")) {
					focusColMax = true;
					prevCol = createNatTable.getSelectionLayer().getColumnPositionByIndex(CreateNatTable.colMaxIdx);
					openMessageDialogForMinMaxValidation(parent.getDisplay(),
							"Maximum cannot be blank for define category", rowIndex, prevCol);
					return false;
				}
			}*/

		} catch (NumberFormatException e) {
			if(focusColMax) {
				prevCol = createNatTable.getSelectionLayer().getColumnPositionByIndex(CreateNatTable.colMaxIdx);
			}else {
				prevCol = createNatTable.getSelectionLayer().getColumnPositionByIndex(CreateNatTable.colMinIdx);
			}
			openMessageDialogForMinMaxValidation(parent.getDisplay(), "Enter Numeric value.", rowIndex , prevCol);

			return false;
		} catch(Exception e) {
			LOGGER.error(e.getMessage());
		}

		return true;
		
	}

	/**
	 * @param rowIndex
	 * @param selColIndex
	 * @param selectedCellEvent
	 * @param minNumber
	 * @param maxVal
	 * @return
	 */
	private boolean valdtMnMxRngeAfrFcsLost(int rowIndex, Object minNumber, double maxVal) {
			boolean returnFlag = true;
			int prevCol;
			if (minNumber != null && !minNumber.equals("")) {
				double minVal = Double.parseDouble((String) minNumber);
				if (maxVal < minVal) {
					//changed for PMD violation
					prevCol = createNatTable.getSelectionLayer().getColumnPositionByIndex(CreateNatTable.colMaxIdx);
					openMessageDialogForMinMaxValidation(parent.getDisplay(),
							MessageConstant.MAX_GREATER_MIN, rowIndex, prevCol);
					returnFlag = false;
				}
				if (minVal > this.prevRowMaxRange) {
					//changed for PMD violation
					prevCol = createNatTable.getSelectionLayer().getColumnPositionByIndex(CreateNatTable.colMinIdx);
					openMessageDialogForMinMaxValidation(parent.getDisplay(),
							MessageConstant.MIN_LESS_THAN_MAX, rowIndex, prevCol);
					returnFlag = false;
					
				}
				
				if (minVal < this.prevRowMinRange) {
					prevCol = createNatTable.getSelectionLayer().getColumnPositionByIndex(CreateNatTable.colMinIdx);
					openMessageDialogForMinMaxValidation(parent.getDisplay(),
							MessageConstant.VAL_FOR_MIN_MAX, rowIndex, prevCol);
					returnFlag = false;
				}
			}
			return returnFlag;
	}

	/**
	 * Method used to validate Unit Column Field
	 * 
	 * @param selectedColumnIndex
	 * @param selectedRowIndex
	 */
	private void checkUnitValidation(int selColIndex, int selectedRowIndex) {
		if (this.getTitle().equals(ApplicationConstant.CATEGORY_INPUT)
				|| this.getTitle().equals(ApplicationConstant.CATEGORY_OUTPUT)
				|| this.getTitle().equals(ApplicationConstant.CATEGORY_LOCAL)
				|| this.getTitle().equals(ApplicationConstant.CATEGORY_NVM)) {

			if (selColIndex == CreateNatTable.colIniValIdx) {
				String unitValue = (String) createNatTable.getJsonDataProvider()
						.getDataValue(CreateNatTable.colUnitIdx, selectedRowIndex);
			//	Display display = parent.getDisplay();
				if (null != unitValue && !unitValue.equals("")) {
					/*if (!unitValue.matches("^[a-zA-Z][a-zA-Z0-9_]*$")){
						openMessageboxForUnit(selColIndex - 1, display);
					}*/
					
					unitValue = unitValue.split(" : ")[0];
                	this.createNatTable.getJsonDataProvider().setDataValue(selColIndex-1, selectedRowIndex, unitValue);
				}
			}
		} else {
			if (selColIndex == CreateNatTable.colDimIdx) {
				String unitValue = (String) createNatTable.getJsonDataProvider()
						.getDataValue(CreateNatTable.colUnitIdx, selectedRowIndex);
				//Display display = parent.getDisplay();
				if (null != unitValue && !unitValue.equals("")) {
					/*if (!unitValue.matches("^[a-zA-Z][a-zA-Z0-9_]*$")) {
						openMessageboxForUnit(CreateNatTable.colUnitIdx, display);
					}*/
					unitValue = unitValue.split(" : ")[0];
                	this.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colUnitIdx, selectedRowIndex, unitValue);
				}
			}
		}
	}

	/**
	 * @param selectedColumnIndex
	 * @param display
	 */
	/*private void openMessageboxForUnit(int selColIndex, Display display) {
		display.asyncExec(new Runnable() {
			public void run() {
				MessageDialog messageDialog = new MessageDialog(null, ApplicationConstant.EDIT_VIOLATION, null,
						"Special characters and only numerics are not allowed in Units", 0, new String[] { "Change" }, 0);
				int selection = messageDialog.open();
				if (selection == 0) {
					natTable.doCommand(new SelectCellCommand(createNatTable.getGridLayer().getBodyLayer(),
							createNatTable.getSelectionLayer().getColumnPositionByIndex(selColIndex),
							cellEvent.getRowPosition() - 1, false, false));
				}
			}
		});
	}*/

	/**
	 * @param selectedColumnIndex
	 * @param selectedRowIndex
	 * @return
	 */
	private void checkValueValidation(int selColIndex) {
		if (selColIndex == CreateNatTable.colDescIdx) {

			// Change Dimensions w.r.t Value Column
			changeDimensions();
		
			if (!this.getTitle().equals(ApplicationConstant.CATEGORY_INPUT)
					&& !this.getTitle().equals(ApplicationConstant.CATEGORY_OUTPUT)
					&& !this.getTitle().equals(ApplicationConstant.CATEGORY_LOCAL)
					&& !this.getTitle().equals(ApplicationConstant.CATEGORY_NVM) && (!isValueValid(cellEvent))) {
				return;
			}
		}
	}

	/**
	 * @param selectedColumnIndex
	 * @return
	 */
	private void checkInitialValueValidation(int selColIndex) {
		if (selColIndex == CreateNatTable.colDimIdx
				&& (this.getTitle().equals(ApplicationConstant.CATEGORY_INPUT)
						|| this.getTitle().equals(ApplicationConstant.CATEGORY_OUTPUT)
						|| this.getTitle().equals(ApplicationConstant.CATEGORY_LOCAL)
						|| this.getTitle().equals(ApplicationConstant.CATEGORY_NVM))
				&& (!isIntialValueValid(cellEvent))) {
			return;
		}
	}

	/**
	 * @param selectedColumnIndex
	 * @param rangeValues
	 * @return
	 */
	/*private void checkMinMaxValidation(int selColIndex, CategoryAttributes rangeValues) {
		if (selColIndex == CreateNatTable.colUnitIdx) {
			setMinMaxRange(rangeValues);
			if (!isMinAndMaxValid(cellEvent)) {
				return;
			}
		}
	}
*/
	/**
	 * @param selectedRowIndex
	 * @return
	 */
	private CategoryAttributes updateMinMaxRange(int selectedRowIndex) {
		CategoryAttributes rangeValues = null;
		CategoryEditor activeEditor = (CategoryEditor) PlatformUI.getWorkbench().getActiveWorkbenchWindow()
				.getActivePage().getActiveEditor();
		if(selectedRowIndex < activeEditor.createNatTable.getDataLayer().getRowCount() && selectedRowIndex!=-1) {
			String baseType = (String) this.createNatTable.getJsonDataProvider()
					.getDataValue(CreateNatTable.colBaseTyIdx, selectedRowIndex);
			float offset = 0; 
			float slope = 0;
			if(this.createNatTable.getJsonDataProvider().getDataValue(CreateNatTable.colOffIdx, selectedRowIndex)!= null && 
					!this.createNatTable.getJsonDataProvider().getDataValue(CreateNatTable.colOffIdx, selectedRowIndex).equals("")) {
				String offsetObj = (String) this.createNatTable.getJsonDataProvider()
						.getDataValue(CreateNatTable.colOffIdx, selectedRowIndex);

				if(offsetObj.matches("^[-+]?[0-9]*\\.?[0-9]+([eE][-+]?[0-9]+)?$")) {
					offset = Float.parseFloat((String) this.createNatTable.getJsonDataProvider()
							.getDataValue(CreateNatTable.colOffIdx, selectedRowIndex));
				}

			}
			if(this.createNatTable.getJsonDataProvider().getDataValue(CreateNatTable.colSlopIdx, selectedRowIndex)!= null && 
					!this.createNatTable.getJsonDataProvider().getDataValue(CreateNatTable.colSlopIdx, selectedRowIndex).equals("")) {
				String slopeObj = (String) this.createNatTable.getJsonDataProvider()
						.getDataValue(CreateNatTable.colSlopIdx, selectedRowIndex);

				if(slopeObj.matches("^[-+]?[0-9]*\\.?[0-9]+([eE][-+]?[0-9]+)?$")) {

					slope = Float.parseFloat((String) this.createNatTable.getJsonDataProvider()
							.getDataValue(CreateNatTable.colSlopIdx, selectedRowIndex));
				}

			}
			rangeValues = DataDictionaryUtil.getMinMaxRange(baseType, offset, slope);
			setMinMaxRange(rangeValues);
			setPrevRowMinMaxRange(rangeValues);
		}
		return rangeValues;
	}

	/**
	 * Method used to update undo stack after changes in nattable
	 * 
	 * @param selectedRowIndex
	 * @param selectedColumnIndex
	 */
	private void updateUndo(int selectedRowIndex, int selColIndex) {
		tableCellList.add(new TableCell(rowIndex, selColIndex));
		if (selectedRowIndex >= 0 && selColIndex >= 0) {

			if (!ImportProjectServiceImpl.pasteFlag) {
				addDataIntoUndoStack(selectedRowIndex);
			}
			updatDataObjList = createNatTable.getCategoryList();
		}
		undoRedoOperation.makeUndoRedoEnableDisable(undoEditStack, redoEditorStack);
		saveOperation.makeSaveEnableDisable(categoryEdiObj);
	}

	/**
	 * Method used to change dimensions w.r.t Value and Initial Value Column
	 * 
	 * @param selectedRowIndex
	 * @param selectedColumnIndex
	 */
	private void changeDimensions() {
	List<CategoryAttributes> newList = createNatTable.getJsonDataProvider().getList();
		
		if ((this.getTitle().equals(ApplicationConstant.CATEGORY_INPUT)
				|| this.getTitle().equals(ApplicationConstant.CATEGORY_OUTPUT)
				|| this.getTitle().equals(ApplicationConstant.CATEGORY_LOCAL)
				|| this.getTitle().equals(ApplicationConstant.CATEGORY_NVM))) {
				//&& selColIndex == CreateNatTable.colDimIdx) {
			// Change Dimensions w.r.t InitialValue column
			for(int editedRow : editRowLists) {
				changeInitialValueColumnDimensions(editedRow, newList);
			}	
			for(int newRow : newAddedRowList) {
				changeInitialValueColumnDimensions(newRow, newList);
			}
		} else if ((this.getTitle().equals(ApplicationConstant.CATEGORY_AXIS)
				|| this.getTitle().equals(ApplicationConstant.CATCALIBRATION)
				|| this.getTitle().equals(ApplicationConstant.CATEGORY_CURVE)
				|| this.getTitle().equals(ApplicationConstant.CATEGORY_DEFINE)
				|| this.getTitle().equals(ApplicationConstant.CATEGORY_MAP))) {
			// Change Dimensions w.r.t value column
			for(int editedRow : editRowLists) {
				changeValueColumnDimensions(editedRow,newList);
			}
			for(int newRow : newAddedRowList) {
				changeValueColumnDimensions(newRow, newList);
			}
		}
		
	}
	
	private void changeInitialValueColumnDimensions(int selectedRowIndex,List<CategoryAttributes> newList)
	{
		try {
		if (selectedRowIndex != -1) {
			// Check if new row is added
			String initialValue = newList.get(selectedRowIndex).getInitialValue();
			String dimensions = newList.get(selectedRowIndex).getDimensions();
			if (newList.size() == savedDataObjList.size()) {
				if (!(dimensions.equals(savedDataObjList.get(selectedRowIndex).getDimensions())) || (initialValue != ""&& initialValue != null)
						&& !(initialValue.equals(savedDataObjList.get(selectedRowIndex).getInitialValue()))) {
					setInitialValueData(selectedRowIndex);
				}
			}
			// check if old data is modified after adding new row/rows
			if ((savedDataObjList.size() > selectedRowIndex && null != initialValue && !(initialValue.equals(savedDataObjList.get(selectedRowIndex).getInitialValue())))) {
				setInitialValueData(selectedRowIndex);

			}
			// Check if data is modified in new row/rows
			else if (savedDataObjList.size() - 1 <= selectedRowIndex && !dimensions.equals("-1")) {
				setInitialValueData(selectedRowIndex);
			}
			
			else if(null != initialValue && Integer.parseInt(dimensions) != -1 && initialValue.split(",").length  != Integer.parseInt(dimensions)) {
				setInitialValueData(selectedRowIndex);
			}
		}
		}catch(NumberFormatException e) {
			LOGGER.error(e.getMessage());
		}catch(Exception e) {
			LOGGER.error(e.getMessage());
		}
	}

	private void changeValueColumnDimensions(int selectedRowIndex,List<CategoryAttributes> newList)
	{
		try {
			if (selectedRowIndex != -1) {
				String dimensions = newList.get(selectedRowIndex).getDimensions();
				String value = newList.get(selectedRowIndex).getValue();
				if (newList.size() == savedDataObjList.size() && (newList.get(rowIndex - 1).getValue() != "" && newList.get(rowIndex - 1).getValue() != null)) {
					if (!(dimensions.equals(savedDataObjList.get(selectedRowIndex).getDimensions())) || !(value
							.equals(savedDataObjList.get(selectedRowIndex).getValue()))) {
						setValueData(selectedRowIndex);
					}
				}
				// check if old data is modified after adding new row/rows
				if (savedDataObjList.size() > selectedRowIndex && null != value && !(value.equals(savedDataObjList.get(selectedRowIndex).getValue()))) {
					setValueData(selectedRowIndex);

				}
				// Check if data is modified in new row/rows
				else if (savedDataObjList.size() - 1 <= selectedRowIndex) {
					setValueData(selectedRowIndex);
				} else {
					String[] colCount = dimensions.split(",");
					if(null != value  && (dimensions !="" && dimensions !=null)  && value.split(",").length != Integer.parseInt(colCount[1].replace("]", ""))) {
						setValueData(selectedRowIndex);
					}
				}
			}
		}catch(Exception e) {
			LOGGER.error(e.getMessage());
		}
	}
	
	private void setInitialValueData(int selectedRowIndex) {
		String initialValue;
		categoryEdiObj.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colDimIdx,
				selectedRowIndex, generateDimension(selectedRowIndex));
		initialValue = (String) categoryEdiObj.createNatTable.getJsonDataProvider()
				.getDataValue(CreateNatTable.colIniValIdx, selectedRowIndex);
		if ((null != initialValue && !initialValue.equals("")) && (!initialValue.contains("["))) {
			categoryEdiObj.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colIniValIdx,
					selectedRowIndex, "[" + initialValue + "]");
		}
	}

	private void setValueData(int selectedRowIndex) {
		String value;
		categoryEdiObj.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colDimIdx,
				selectedRowIndex, generateDimension(selectedRowIndex));
		value = (String) categoryEdiObj.createNatTable.getJsonDataProvider()
				.getDataValue(CreateNatTable.colValIdx, selectedRowIndex);
		if ((null != value && !value.equals("")) && (!value.contains("["))) {
			categoryEdiObj.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colValIdx,
					selectedRowIndex, "[" + value + "]");
		}
	}

	/**
	 * @param selectedColumnIndex
	 * @param objSlope
	 */
	private boolean checkSlopeValidation(int selColIndex, Object objSlope) {
		try {
			// Slope Validation
			if (objSlope != null) {
				
				if ((selColIndex == CreateNatTable.colMinIdx||selColIndex == CreateNatTable.colMaxIdx)) {
					Double.parseDouble((String) objSlope);
				/*	if(slopVal==0 || slopVal<0) {
						PlatformUI.getWorkbench().getDisplay().asyncExec(new Runnable() {
							public void run() {
								MessageDialog messageDialog = new MessageDialog(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell()
										,ApplicationConstant.EDIT_VIOLATION ,
										null, "Slope can't be 0 or negative. Enter valid slope", 0, new String[] { "Change" }, 0);
								int selection = messageDialog.open();

								if (selection == 0) {
									natTable.doCommand(new SelectCellCommand(createNatTable.getGridLayer().getBodyLayer(),
											4, cellEvent.getRowPosition() - 1, false, false));
								}

							}
						});
						return false;
					}*/
				}

			} else {
				PlatformUI.getWorkbench().getDisplay().asyncExec(new Runnable() {
					public void run() {
						MessageDialog messageDialog = new MessageDialog(null, ApplicationConstant.EDIT_VIOLATION,
								null, MessageConstant.SLOPE_VAL, 0, new String[] { "Change" }, 0);
						int selection = messageDialog.open();

						if (selection == 0) {
							natTable.doCommand(new SelectCellCommand(createNatTable.getGridLayer().getBodyLayer(),
									4, cellEvent.getRowPosition() - 1, false, false));
						}
						
					}
				});
				return false;
			}

		} catch (NumberFormatException e) {
			//int columnIndex = 0;
			int columnToBeChecked = 0;
			Display display = parent.getDisplay();
			Collection<ILayerCell> selCellFromEvent = cellEvent.getSelectionLayer().getSelectedCells();
			for (ILayerCell cell : selCellFromEvent) {
				//columnIndex = cell.getColumnIndex();
				rowIndex = cell.getRowIndex();
			}

			columnToBeChecked = createNatTable.getViewportLayer().getColumnPositionByIndex(CreateNatTable.colSlopIdx);
			openMessageDialogForNumberBaseTypeValidation(cellEvent, display, "Enter Numeric value for Slope",
					columnToBeChecked);
		
			return false;
		}
		return true;
	}

	/**
	 * @param objOffset
	 */
	private boolean checkOffsetValidation(int selColIdx, int selectedRowIndex) {
		if(selColIdx == CreateNatTable.colSlopIdx || selColIdx == CreateNatTable.colMinIdx || selColIdx == CreateNatTable.colMaxIdx) {
			Object objOffset = this.createNatTable.getJsonDataProvider().getDataValue(CreateNatTable.colOffIdx,
					selectedRowIndex);
			try {
				// Offset Validation
				if (objOffset != null) {
					Double.parseDouble((String) objOffset);
				} else {
					PlatformUI.getWorkbench().getDisplay().asyncExec(new Runnable() {
						public void run() {
							MessageDialog messageDialog = new MessageDialog(null, ApplicationConstant.EDIT_VIOLATION,
									null, MessageConstant.OFFSET_VAL, 0, new String[] { "Change" }, 0);
							int selection = messageDialog.open();

							if (selection == 0) {
								natTable.doCommand(new SelectCellCommand(createNatTable.getGridLayer().getBodyLayer(),
										3, cellEvent.getRowPosition() - 1, false, false));
							}
						}
					});
					return false;
				}
			}
			catch (NumberFormatException e) {
				
				//int columnIndex = 0;
				int columnToBeChecked = 0;
				Display display = parent.getDisplay();
				Collection<ILayerCell> selCellFromEvent = cellEvent.getSelectionLayer().getSelectedCells();
				for (ILayerCell cell : selCellFromEvent) {
					//columnIndex = cell.getColumnIndex();
					rowIndex = cell.getRowIndex();
				}

				columnToBeChecked = createNatTable.getViewportLayer().getColumnPositionByIndex(CreateNatTable.colOffIdx);
				openMessageDialogForNumberBaseTypeValidation(cellEvent, display, "Enter Numeric value for Offset.",
						columnToBeChecked);
				return false;
			}
		}
		return true;
	}

	/**
	 * @param baseType
	 */
	private boolean checkBaseTypeValidation(int selColIdx, int selectedRowIndex) {
		if(selColIdx == CreateNatTable.colOffIdx  || selColIdx == CreateNatTable.colMinIdx || selColIdx == CreateNatTable.colMaxIdx) {
			String baseType = (String) this.createNatTable.getJsonDataProvider()
					.getDataValue(CreateNatTable.colBaseTyIdx, selectedRowIndex);
			
			// Base Type Validation
			if (baseType == null) {
				PlatformUI.getWorkbench().getDisplay().asyncExec(new Runnable() {
					public void run() {
						//MessageDialog.openWarning(shell, ApplicationConstant.WARNING, MessageConstant.BASE_TYPE_VALIDATION);
						MessageDialog messageDialog = new MessageDialog(null, ApplicationConstant.EDIT_VIOLATION,
								null, MessageConstant.BASE_TYPE_VAL, 0, new String[] { "Change" }, 0);
						int selection = messageDialog.open();

						if (selection == 0) {
							natTable.doCommand(new SelectCellCommand(createNatTable.getGridLayer().getBodyLayer(),
									2, cellEvent.getRowPosition() - 1, false, false));
						}
					}
				});
				return false;
			}
		}
		return true;
	}

	public void addDataIntoUndoStack(int selectedRowIndex) {
		GridLayer dataLayer1 = createNatTable.getGridLayer();

		int selectedRowIndex1 = dataLayer1.getRowIndexByPosition(rowIndex);
		int selColIndex1 = dataLayer1.getColumnIndexByPosition(cellEvent.getColumnPosition());
		if (columnindex == 0 && rowidx == 0) {

			rowidx = selectedRowIndex1;
			columnindex = selColIndex1;
			if(selectedRowIndex1!=-1) {
				data = (String) createNatTable.getJsonDataProvider().getDataValue(selColIndex1, selectedRowIndex1);
			}
		} else if (selColIndex1 != columnindex || selectedRowIndex1 != rowidx) {
			if(rowidx!=-1) {
				data1 = (String) createNatTable.getJsonDataProvider().getDataValue(columnindex, rowidx);
				
				if (null == data1) {
					data1 = "";
				}
				if (null == data) {
					data = "";
				}
				if (!data.trim().equals(data1)) {
					undoEditStack.push(new TableCell(rowidx, columnindex, data));
					if (!isDirty()) {
						setDirty(true);
					}
					// If existing cell is editing then add into edit row list
					if (!newAddedRowList.contains(selectedRowIndex) && selectedRowIndex > -1) {
						editRowLists.add(rowidx);
					}
				}else if(data.equals("") && data1.equals("")) {
					if(!cutList.isEmpty()) {
						undoEditStack.push(new TableCell(rowidx, columnindex, data));
						if (!isDirty()) {
							setDirty(true);
						}
						// If existing cell is editing then add into edit row list
						if (!newAddedRowList.contains(selectedRowIndex) && selectedRowIndex > -1) {
							editRowLists.add(rowidx);
						}
					}
				}
			}
			//skip if row index is -1
			if(selectedRowIndex1!=-1) {
				data = (String) createNatTable.getJsonDataProvider().getDataValue(selColIndex1, selectedRowIndex1);
				rowidx = selectedRowIndex1;
				columnindex = selColIndex1;
			}
		}
	}

	private void setMinMaxRange(CategoryAttributes rangeValues) {
		try {
			if (rangeValues != null) {
				String minVal = (String) rangeValues.getMin();
				if (minVal != null && !minVal.equals("") && !minVal.equals("Not defined")) {
					this.minRange = Double.parseDouble(minVal);
				}

				String maxVal = (String) rangeValues.getMax();
				if (maxVal != null && !maxVal.equals("") && !maxVal.equals("Not defined")) {
					this.maxRange = Double.parseDouble(maxVal);
				}

			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			MessageDialog.openError(shell, ApplicationConstant.ERROR, MessageConstant.MIN_MAX_RANGE_VAL);
		}

	}
	
	private void setPrevRowMinMaxRange(CategoryAttributes rangeValues) {
		try {
			if (rangeValues != null) {
				String minVal = (String) rangeValues.getMin();
				if (minVal != null && !minVal.equals("") && !minVal.equals("Not defined")) {
					this.prevRowMinRange = Double.parseDouble(minVal);
				}

				String maxVal = (String) rangeValues.getMax();
				if (maxVal != null && !maxVal.equals("") && !maxVal.equals("Not defined")) {
					this.prevRowMaxRange = Double.parseDouble(maxVal);
				}

			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			MessageDialog.openError(shell, ApplicationConstant.ERROR, MessageConstant.MIN_MAX_RANGE_VAL);
		}

	}

	/**
	 * Method used to set dirty if any update in editor
	 */
	public void setDirtyAfterDataUpdate() {
		List<CategoryAttributes> newList = createNatTable.getJsonDataProvider().getList();

		if (!(newList.toString().trim().replace("null", "").replace("Null", "")
				.equals(savedDataObjList.toString().trim().replace("null", "").replace("Null", "")))) {
			if (undoEditStack.size() != 0 || ResolveInconsistencyServiceImpl.resolveDeleteFlag
					|| ResolveInconsistencyServiceImpl.resolveAddFlag || ExcelImportExportServiceImpl.resDdAddFlg
					|| ExcelImportExportServiceImpl.resDdDelFlg) {
				dirtyListener.fireDirty();
			} else {
				setDirty(false);
			}
		} else {
			if (undoEditStack.size() > 0 || ResolveInconsistencyServiceImpl.resolveDeleteFlag
					|| ResolveInconsistencyServiceImpl.resolveAddFlag || ExcelImportExportServiceImpl.resDdAddFlg
					|| ExcelImportExportServiceImpl.resDdDelFlg) {
				setDirty(true);
			} else {
				setDirty(false);
			}

		}
		if (categoryEdiObj.rowDeleted) {
			setDirty(false);
			categoryEdiObj.rowDeleted = false;
		}

	}

	/**
	 * Method used to handle value and initial value depending on category
	 * 
	 * @param selectedRowIndex
	 * @param selectedColumnIndex
	 */
	private void showTableView(int selectedRowIndex, int selColIdx) {
		if (!getTitle().equals(ApplicationConstant.CATEGORY_DEFINE)) {
			if (selColIdx == CreateNatTable.colValIdx
					|| selColIdx == CreateNatTable.colIniValIdx) {
				openValueTableEditor(selColIdx, selectedRowIndex);
			} else if (selColIdx != -1) {
				closeValueTableEditor();
			}
		} else {
			ViewUtil.closeView(ViewIDConstant.TABLE_EDITOR);
		}
	}

	/**
	 * Function used to generate Dimension after w.r.t value in value column
	 * 
	 * @return
	 */
	private String generateDimension(int selectedRowIndex) {
		int columnCount = 0;
		int rowCount = 0;
		String valueColumnData;
		// If selected category is INPUT/OUTPUT/LOCAL/NVM
		if (getTitle().equals(ApplicationConstant.CATEGORY_INPUT)
				|| getTitle().equals(ApplicationConstant.CATEGORY_LOCAL)
				|| getTitle().equals(ApplicationConstant.CATEGORY_OUTPUT)
				|| getTitle().equals(ApplicationConstant.CATEGORY_NVM)) {
			valueColumnData = (String) createNatTable.getJsonDataProvider()
					.getDataValue(CreateNatTable.colIniValIdx, selectedRowIndex);
		} else {
			valueColumnData = (String) createNatTable.getJsonDataProvider()
					.getDataValue(CreateNatTable.colValIdx, selectedRowIndex);
		}

		if (valueColumnData != null) {
			// Split to get column count and data
			String[] valueColumn = valueColumnData.replace("[", "").split("]");
			rowCount = valueColumn.length;

			// Get the column count
			if (rowCount > 0) {
				columnCount = valueColumn[0].split(",").length;
				for (int i = 1; i < valueColumn.length; i++) {
					if (columnCount < valueColumn[i].split(",").length) {
						columnCount = valueColumn[i].split(",").length;
					}
				}

			}
			// Default Dimension for INPUT/OUTPUT/LOCAL/NVM categories
			if (getTitle().equals(ApplicationConstant.CATEGORY_INPUT)
					|| getTitle().equals(ApplicationConstant.CATEGORY_LOCAL)
					|| getTitle().equals(ApplicationConstant.CATEGORY_OUTPUT)
					|| getTitle().equals(ApplicationConstant.CATEGORY_NVM)) {
				if (columnCount == 1 && rowCount == 1) {
					return "1";
				} else {
					return Integer.toString(columnCount);
				}
			}
			return "[" + rowCount + "," + columnCount + "]";
		}
		return (String) createNatTable.getJsonDataProvider().getDataValue(CreateNatTable.colDimIdx,
				selectedRowIndex);
	}

	/**
	 * Method used to get the column available after name column in category
	 * 
	 * @return
	 */
	private int getColumnAfterNameColumn() {
		int columnAfterName;
		if (this.getTitle().equals(ApplicationConstant.CATEGORY_INPUT)
				|| this.getTitle().equals(ApplicationConstant.CATEGORY_OUTPUT)
				|| this.getTitle().equals(ApplicationConstant.CATEGORY_LOCAL)) {
			columnAfterName = CreateNatTable.colDescIdx;
		} else {
			columnAfterName = CreateNatTable.colValIdx;
		}
		return columnAfterName;
	}

	/**
	 * Method used to check if Min entered by user is valid
	 * @param rowIndex
	 * @param columnIndex
	 * @return
	 */
	private boolean isMinValid(int rowIndex) {
		int columnToBeChecked = 0;
		Display display = parent.getDisplay();
		try {
			columnToBeChecked = createNatTable.getSelectionLayer().getColumnPositionByIndex(CreateNatTable.colMinIdx);
			Object minNumber = createNatTable.getJsonDataProvider().getDataValue(CreateNatTable.colMinIdx, rowIndex);

			/*if (this.getTitle().equals(ApplicationConstant.CATEGORY_DEFINE)) {
			if (minNumber == null || minNumber.equals("")) {
				openMessageDialogForMinMaxValidation(display,
						"Minimum cannot be blank for define category", rowIndex, columnToBeChecked);
				return false;
			}
		}*/

			if (minNumber == null) {
				return true;
			}
			//	try {

			if (minNumber != null && minNumber.equals("")) {
				return true;
			}

			double minVal = Double.parseDouble((String) minNumber);
			if (!((minVal >= this.minRange) && (minVal <= this.maxRange))) {
				openMessageDialogForMinMaxValidation(display,
						MessageConstant.VAL_FOR_MIN_MAX,rowIndex, columnToBeChecked);
				return false;
			}

		} catch (NumberFormatException e) {
			openMessageDialogForMinMaxValidation(display, "Enter Numeric value.",
					rowIndex, columnToBeChecked);
			return false;
		} catch(Exception e ) {
			LOGGER.error(e.getMessage());
		}
		return true;

	}

	private boolean isValueValid(CellSelectionEvent selectedCellEvent) {
		int rowIndex = 0;
		int columnToBeChecked = 0;
		int columnIndex = 0;
		Collection<ILayerCell> selCellFromEvent = selectedCellEvent.getSelectionLayer().getSelectedCells();
		for (ILayerCell cell : selCellFromEvent) {
			columnIndex = cell.getColumnIndex();
			rowIndex = cell.getRowIndex();
		}

		columnToBeChecked = createNatTable.getViewportLayer().getColumnPositionByIndex(columnIndex - 1);
		return validateValue(selectedCellEvent, rowIndex, columnToBeChecked);

	}

	/**
	 * @param selectedCellEvent
	 * @param rowIndex
	 * @param columnToBeChecked
	 * @return
	 */
	private boolean validateValue(CellSelectionEvent selectedCellEvent, int rowIndex, int columnToBeChecked) {
		Display display = parent.getDisplay();
		String dimension = (String) createNatTable.getJsonDataProvider()
				.getDataValue(CreateNatTable.colDimIdx, rowIndex);
		String oldTableValue = (String) createNatTable.getJsonDataProvider()
				.getDataValue(CreateNatTable.colValIdx, rowIndex);

		Object minNumber = createNatTable.getJsonDataProvider().getDataValue(CreateNatTable.colMinIdx, rowIndex);
		Object maxNumber = createNatTable.getJsonDataProvider().getDataValue(CreateNatTable.colMaxIdx, rowIndex);

		try {
			String[] valueArray = DataDictionaryUtil.parseValue(oldTableValue, this.getTitle(), dimension);
			boolean valueFlag = false;
			
			//if(null != oldTableValue && oldTableValue.equals("")) {
				validateValueColumnValidation(oldTableValue);
			//}

			if ( minNumber != null && !minNumber.equals("") && maxNumber != null && !maxNumber.equals("")) {
				double minVal = Double.parseDouble((String) minNumber);
				double maxVal = Double.parseDouble((String) maxNumber);

				for (int i = 0; i < valueArray.length; i++) {
					double valueItem = Double.parseDouble(valueArray[i]);
					if (!(valueItem >= minVal && valueItem <= maxVal)) {
						valueFlag = true;
						break;
					}

				}

				if (valueFlag) {
					openMessageDialogForNumberBaseTypeValidation(selectedCellEvent, display,
							MessageConstant.EDIT_VIO_FOR_NUM, columnToBeChecked);
					return false;
				}
			} else {
				return true;
			}

		} catch (Exception e) {
			if(this.getTitle().equals(ApplicationConstant.CATEGORY_DEFINE)) {
				openMessageDialogForNumberBaseTypeValidation(selectedCellEvent, display, MessageConstant.VAL_COLUMN_VAL_2,
						columnToBeChecked);
			}
			else if(this.getTitle().equals(ApplicationConstant.CATEGORY_MAP)) {
				openMessageDialogForNumberBaseTypeValidation(selectedCellEvent, display, MessageConstant.VAL_COLUMN_VAL_3,
						columnToBeChecked);
			}
			else {
				openMessageDialogForNumberBaseTypeValidation(selectedCellEvent, display, MessageConstant.VAL_COLUMN_VAL_1,
					columnToBeChecked);
			}
			return false;
		}

		return true;

	}
	
	private void validateValueColumnValidation(String oldTableValue) throws Exception {
		//Allow only single value or digit [Digit can be positive or negative or float]
		if (this.getTitle().equals(ApplicationConstant.CATEGORY_DEFINE)) {
			if (!(DataDictionaryUtil.checkBalancedParentesis(oldTableValue)
					&& oldTableValue.matches("^-?[0-9|[[+-]\\d*]|([Ee][+-]?[0-9]+)|\\d+.\\d+\\[|\\]]+$")
					&& oldTableValue.split("]").length == 1)) {
				throw new Exception();
			}
		}
		//Allow only multiple value or digit [Digit can be positive or negative or float] 
		else if (this.getTitle().equals(ApplicationConstant.CATEGORY_MAP)) {
			if (!(DataDictionaryUtil.checkBalancedParentesis(oldTableValue)
					&& oldTableValue.matches("^-?[0-9|[[+-]\\d*]|\\d+.\\d|([Ee][+-]?[0-9]+)|,|\\[|\\]]+$")
					&& DataDictionaryUtil.countNumbers(oldTableValue) != 0)) {
				throw new Exception();
			}
		}
		//Allow only multiple value or digit but single row [Digit can be positive or negative or float]
		else {
			if (!(DataDictionaryUtil.checkBalancedParentesis(oldTableValue)
					&& oldTableValue.matches("^-?[0-9|[[+-]\\d*]|\\d+.\\d+\\[|\\]|([Ee][+-]?[0-9]+)|,]+$")
					&& DataDictionaryUtil.countNumbers(oldTableValue) != 0
					&& oldTableValue.split("]").length == 1)) {
				throw new Exception();
			}
		}
	}

	private boolean isIntialValueValid(CellSelectionEvent selectedCellEvent) {

		int rowIndex = 0;
		int columnToBeChecked = 0;
		int columnIndex = 0;
		Display display = parent.getDisplay();
		Collection<ILayerCell> selCellFromEvent = selectedCellEvent.getSelectionLayer().getSelectedCells();
		for (ILayerCell cell : selCellFromEvent) {
			columnIndex = cell.getColumnIndex();
			rowIndex = cell.getRowIndex();
		}
		columnToBeChecked = createNatTable.getViewportLayer().getColumnPositionByIndex(columnIndex - 1);
		String dimension = (String) createNatTable.getJsonDataProvider()
				.getDataValue(CreateNatTable.colDimIdx, rowIndex);
		String oldTableValue = (String) createNatTable.getJsonDataProvider()
				.getDataValue(CreateNatTable.colIniValIdx, rowIndex);
		
		Object minNumber = createNatTable.getJsonDataProvider().getDataValue(CreateNatTable.colMinIdx, rowIndex);
		Object maxNumber = createNatTable.getJsonDataProvider().getDataValue(CreateNatTable.colMaxIdx, rowIndex);
		String[] valueArray = DataDictionaryUtil.parseValue(oldTableValue, this.getTitle(), dimension);
		boolean valueFlag = false;
		try {
			if (minNumber != null && !minNumber.equals("") && maxNumber != null && !maxNumber.equals("")) {
				double minVal = Double.parseDouble((String) minNumber);
				double maxVal = Double.parseDouble((String) maxNumber);
				if (null != oldTableValue && !oldTableValue.equals("")) {
					for (int i = 0; i < valueArray.length; i++) {
						double valueItem = Double.parseDouble(valueArray[i]);

						if (!(DataDictionaryUtil.checkBalancedParentesis(oldTableValue)
								&& oldTableValue.matches("^-?[0-9|[[+-]\\d*]|\\d+.\\d+\\[|\\]|([Ee][+-]?[0-9]+)|,]+$")
								&& oldTableValue.split("]").length == 1)) {
							throw new Exception();
						}

					/*	if (!this.getTitle().equals(ApplicationConstant.CATEGORY_MAP)) {
							String[] validateDimension = oldTableValue.replace("[", "").split("]");
							if (validateDimension.length > 1) {
								throw new Exception();
							}
						}*/

						if (!(valueItem >= minVal && valueItem <= maxVal)) {
							valueFlag = true;
							break;
						}

					}

					if (valueFlag) {
						openMessageDialogForNumberBaseTypeValidation(selectedCellEvent, display,
								MessageConstant.EDIT_VIO_FOR_NUM, columnToBeChecked);
						return false;
					}
				} else {
					return true;
				}
			}
		} catch (Exception e) {
			openMessageDialogForNumberBaseTypeValidation(selectedCellEvent, display, MessageConstant.INITIAL_VALUE_VAL,
					columnToBeChecked);
			return false;
		}
		return true;
	}

	/*private boolean isMinAndMaxValid(CellSelectionEvent selectedCellEvent) {
		int rowIndex = 0;
		int columnIndex = 0;
		int columnToBeChecked = 0;
		Display display = parent.getDisplay();
		Collection<ILayerCell> selCellFromEvent = selectedCellEvent.getSelectionLayer().getSelectedCells();
		for (ILayerCell cell : selCellFromEvent) {
			columnIndex = cell.getColumnIndex();
			rowIndex = cell.getRowIndex();
		}

		Object minNumber = createNatTable.getJsonDataProvider().getDataValue(CreateNatTable.colMinIdx, rowIndex);
		Object maxNumber = createNatTable.getJsonDataProvider().getDataValue(CreateNatTable.colMaxIdx, rowIndex);

		try {
			if ((minNumber != null && maxNumber != null) && (maxNumber.equals("") && minNumber.equals(""))) {
				return true;
			} 
			else if ((minNumber != null && maxNumber != null) && (maxNumber.equals("") && !minNumber.equals(""))) {
				double minVal = Double.parseDouble((String) minNumber);
				if (minVal > this.maxRange || minVal < this.minRange) {
					columnToBeChecked = createNatTable.getViewportLayer().getColumnPositionByIndex(columnIndex - 2);
					openMessageDialogForNumberBaseTypeValidation(selectedCellEvent, display,
							MessageConstant.VAL_FOR_MIN_MAX, columnToBeChecked);
					return false;
				}
			} 
			else if (maxNumber != null && !maxNumber.equals("")) {
				columnToBeChecked = createNatTable.getViewportLayer().getColumnPositionByIndex(columnIndex - 1);
				double maxVal = Double.parseDouble((String) maxNumber);
				if (!(maxVal <= this.maxRange)) {
					openMessageDialogForNumberBaseTypeValidation(selectedCellEvent, display,
							MessageConstant.VAL_FOR_MIN_MAX, columnToBeChecked);
					return false;
				}

				return validateMinMaxColumnRange(minNumber, maxVal, columnIndex, display, selectedCellEvent);

			}
			if (this.getTitle().equals(ApplicationConstant.CATEGORY_DEFINE)) {
				if (maxNumber == null || maxNumber.equals("")) {
					openMessageDialogForNumberBaseTypeValidation(selectedCellEvent, display,
							"Maximum cannot be blank for define category", columnToBeChecked);
					return false;
				}
			}

		} catch (NumberFormatException e) {
			openMessageDialogForNumberBaseTypeValidation(selectedCellEvent, display, "Enter Numeric value.",
					columnToBeChecked);

			return false;
		}

		return true;

	}*/

	/*private boolean validateMinMaxColumnRange(Object minNumber, double maxVal, int columnIndex, Display display,
			CellSelectionEvent selectedCellEvent) {
		boolean returnFlag = true;
		if (minNumber != null && !minNumber.equals("")) {
			double minVal = Double.parseDouble((String) minNumber);
			if (maxVal < minVal) {
				//changed for PMD violation
				int columnToChk = createNatTable.getViewportLayer().getColumnPositionByIndex(columnIndex - 1);
				openMessageDialogForNumberBaseTypeValidation(selectedCellEvent, display,
						MessageConstant.MAX_GREATER_MIN, columnToChk);
				returnFlag = false;
			}
			if (minVal > this.maxRange) {
				//changed for PMD violation
				int columnToChk = createNatTable.getViewportLayer().getColumnPositionByIndex(columnIndex - 2);
				openMessageDialogForNumberBaseTypeValidation(selectedCellEvent, display,
						MessageConstant.MIN_LESS_THAN_MAX, columnToChk);
				returnFlag = false;
			}
		}
		return returnFlag;
	}*/

	/**
	 * Method to check name is valid or not
	 * 
	 * @param selectedCellEvent
	 * @return
	 */
	private boolean isNameValid(CellSelectionEvent selectedCellEvent) {
		boolean status = false;
		String validationMessage = "";
		int columnIndex = 0;
		int rowIndex = 0;
		Display display = parent.getDisplay();

		String regex = "^[a-zA-Z][a-zA-Z0-9_]*$";

		Collection<ILayerCell> selCellFromEvent = selectedCellEvent.getSelectionLayer().getSelectedCells();
		for (ILayerCell cell : selCellFromEvent) {
			columnIndex = cell.getColumnIndex();
			rowIndex = cell.getRowIndex();
		}
		String nameValue = (String) createNatTable.getJsonDataProvider().getDataValue(CreateNatTable.colNameIdx,
				rowIndex);
		
		List<String> existingNameList = NatTableEditConfiguration.getNameList(rowIndex);

		if (columnIndex == CreateNatTable.colDescIdx || columnIndex == CreateNatTable.colValIdx) {
			if (nameValue == null || nameValue.equals("")) {
				validationMessage = MessageConstant.NAME_VAL;
				openMessageDialogForNameValidation(display, validationMessage,rowIndex);

			} else if (!((String) nameValue).matches(regex)
					|| nameValue.length() > ApplicationConstant.MAXNAMELEN) {
				validationMessage = /* MessageConstant.EDIT_VIOLATION_MESSAGE + "\n" + "\n" + "'" + */ nameValue + "'"
						+ MessageConstant.EDIT_MESSAGE1 + "\n" + MessageConstant.EDIT_MESSAGE2
						+ "\n" + MessageConstant.EDIT_MESSAGE3 + "\n"
						+ MessageConstant.EDIT_MESSAGE4 + "\n" + MessageConstant.EDIT_MESSAGE6;

				openMessageDialogForNameValidation(display, validationMessage, rowIndex);
			} else if (existingNameList.contains(nameValue)) {
				validationMessage = MessageConstant.UNIQUE_NAME_VAL;
				openMessageDialogForNameValidation(display, validationMessage, rowIndex);
			}
			status = false;
		} else {
			status = true;
		}
		return status;
	}

	/**
	 * Method used to open message dialog for name validation
	 * 
	 * @param cellEvent
	 * @param display
	 * @param validationMessage
	 */
	private void openMessageDialogForNameValidation(Display display,
			String validationMessage, int rowIndex) {
		display.asyncExec(new Runnable() {
			public void run() {
				MessageDialog messageDialog = new MessageDialog(null, ApplicationConstant.EDIT_VIOLATION, null,
						validationMessage, 0, new String[] { "Change" }, 0);
				int selection = messageDialog.open();

				if (selection == 0) {
					natTable.doCommand(new SelectCellCommand(createNatTable.getSelectionLayer(), 0,
							rowIndex, false, false));
					
					/*natTable.doCommand(new SelectCellCommand(createNatTable.getSelectionLayer(), 0,
							selectedCellEvent.getRowPosition() - 1, false, false));*/
				}
			}
		});
	}

	/**
	 * Method used to open message dialog for name validation
	 * 
	 * @param cellEvent
	 * @param display
	 * @param validationMessage
	 */
	private void openMessageDialogForNumberBaseTypeValidation(CellSelectionEvent selectedCellEvent, Display display,
			String validationMessage, int columnToBeChecked) {
		display.asyncExec(new Runnable() {
			public void run() {
				if (CustomMessageDialog.getmessagedialogInstance() == null) {
					CustomMessageDialog messageDialog = new CustomMessageDialog(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(),
							ApplicationConstant.EDIT_VIOLATION, null, validationMessage, 0, new String[] { "Change" },
							0);

					int selection = messageDialog.open();

					if (selection == 0) {
						natTable.doCommand(new SelectCellCommand(createNatTable.getGridLayer().getBodyLayer(),
								columnToBeChecked, selectedCellEvent.getRowPosition() - 1, false, false));
					}
				}

			}
			
			
		});
		
	}
	
	/**
	 * Method used to display pop-up message for Min Max validation after focus lost
	 * @param display
	 * @param validationMessage
	 * @param row
	 * @param prevCol
	 */
	private void openMessageDialogForMinMaxValidation(Display display,String validationMessage,int row, int prevCol) {
		display.asyncExec(new Runnable() {
			public void run() {
				
				if (CustomMessageDialog.getmessagedialogInstance() == null) {
					CustomMessageDialog messageDialog = new CustomMessageDialog(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(),
							ApplicationConstant.EDIT_VIOLATION, null, validationMessage, 0, new String[] { "Change", "Ignore" },
							0);

					int selection = messageDialog.open();
					if (selection == 0) {
						natTable.doCommand(new SelectCellCommand(createNatTable.getSelectionLayer(),
								prevCol, row , false, false));
					}else if (selection == 1){
						ignorValidnFlg = true;
						return;
					}
				}

			}
			
			
		});
		
	}

	/**
	 * Method used to set the pop-up menu of natTable
	 * 
	 * @param popupMenu
	 */
	public void setMenuItemDetails(Menu popupMenu) {

		MenuItem cutData = new MenuItem(popupMenu, SWT.PUSH);
		cutData.setText(ApplicationConstant.CUT);
		cutData.setEnabled(true);
		cutData.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent event) {
				new CutAction().run();
			}
		});

		MenuItem copyData = new MenuItem(popupMenu, SWT.PUSH);
		copyData.setText(ApplicationConstant.COPY);
		copyData.setEnabled(true);
		copyData.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent event) {
				new CopyAction().run();
			}
		});

		MenuItem pasteData = new MenuItem(popupMenu, SWT.PUSH);
		pasteData.setText(ApplicationConstant.PASTE);
		pasteData.setEnabled(true);
		pasteData.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent event) {
				new PasteAction().run();
			}
		});

		MenuItem findInModel = new MenuItem(popupMenu, SWT.PUSH);
		findInModel.setText(ApplicationConstant.BTN_FINDINMODEL);
		findInModel.setEnabled(false);
		findInModel.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent event) {
				findInModelFromContextMenu();
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent event) {
				// widgetDefaultsel
			}
		});

		MenuItem deleteRow = new MenuItem(popupMenu, SWT.PUSH);
		deleteRow.setText(ApplicationConstant.BTNDELDATAOBJ);
		deleteRow.setEnabled(false);
		deleteRow.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent event) {
				createNatTable.getSelectionLayer().setConfigLabelAccumulator(null);
				deleteDataObjectFromContextMenu();
			}

		});

		MenuItem renameInModel = new MenuItem(popupMenu, SWT.PUSH);
		renameInModel.setText(ApplicationConstant.RENAMEINMODEL);
		renameInModel.setEnabled(false);
		renameInModel.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent event) {
				renameInModelFromContextMenu();
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent event) {
				// Nothing to do
			}

		});

		natTable.setMenu(popupMenu);
		natTable.getMenu().getItem(ApplicationConstant.DELDATAOBJIDX).setEnabled(true);
		natTable.getMenu().getItem(ApplicationConstant.FINDINMODELIDX).setEnabled(false);
	}

	/**
	 * Method used to set the data for new row and display in natTbale
	 */
	public void setAddDataObjectDetails(CategoryAttributes object) {
		int rowPosition = natTable.getRowCount() + 1;
		rowPosition = createNatTable.getJsonDataProvider().getRowCount();

		newRowIndex = rowPosition;
		addedRowLists.add(rowPosition);
		String categoryName = getTitle();
		natTableOperation.addNewRowInNatTable(parent, newRowIndex, createNatTable, natTable, newAddedRowList,
				categoryName, object);

		natTableOperation.setFocusOnNewRow(natTable.getRowCount(), createNatTable, natTable, newRowIndex);

		IEditorPart editorPart = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor();
		if (!editorPart.getTitle().equals("Input")) {
			setDirty(true);
		}else if(editorPart.getTitle().equals("Input") && object!=null) {
			setDirty(true);	
		}

		SelectionLayer selectionLayer = createNatTable.getSelectionLayer();

		if (!ImportProjectServiceImpl.pasteFlag) {
			// Add performed action into stack for undo
			undoEditStack.push(new NatTableRowIndex(selectionLayer, newRowIndex));
		}

		updatDataObjList = createNatTable.getCategoryList();

		undoRedoOperation.makeUndoRedoEnableDisable(undoEditStack, redoEditorStack);

		saveOperation.makeSaveEnableDisable(categoryEdiObj);
	}

	/**
	 * Method used to assign fire property change
	 * 
	 * @param input
	 */
	@Override
	public void setInput(IEditorInput input) {
		super.setInput(input);
		firePropertyChange(IWorkbenchPartConstants.PROP_INPUT);
	}

	/**
	 * Method used to register dirty controls.
	 */
	@Override
	protected Control[] registryDirtyControls() {
		return new Control[0];
	}

	/**
	 * Method used to perform save operation i.e. save added/modified data from NAT
	 * table to Matlab
	 * 
	 * @param monitor
	 */
	@Override
	public void doSave(IProgressMonitor monitor) {
		cutList = new ArrayList<>();
		ignorValidnFlg = false;
		String catName = "";
		if (!categoryEdiObj.createNatTable.filterRowHLayer.isFilterRowVisible()
				&& categoryEdiObj.createNatTable.getRowHideShowLayer().getHiddenRowIndexes().size() == 0) {
			Gson gson = new Gson();
			boolean saveStatus = true;
			List<CategoryAttributes> categoryList = new ArrayList<CategoryAttributes>();
			List<CategoryAttributes> deletedDataList = new ArrayList<CategoryAttributes>();

			this.natTable.commitAndCloseActiveCellEditor();
			if (SaveAllAction.saveAllFlg) {
				categoryList = allNewObjList;
				// Get all deleted data in List
				// using for-each loop for iteration over Map.entrySet()
				for (Map.Entry<String, List<CategoryAttributes>> entry : deletedListMap.entrySet()) {
					deletedDataList.addAll(entry.getValue());
				}

			} else {
				categoryList = getNewObjectsList();
				if (!newAddedRowList.isEmpty()) {
					if (null == categoryList || categoryList.isEmpty()) {
						if (this.invalidNameFlag) {
							this.invalidNameFlag = false;
							return;
						}
						saveStatus = false;
					} else {
						setValueNDimWithoutTab(categoryList);
						setUnitSymbWithoutTab(categoryList);
					}
				}
				catName = this.getTitle();
				// get data to delete
				deletedDataList = deletedListMap.get(this.getTitle());
			}

			// Delete Data object(s) from sldd
			boolean delDataObjStatus = true;
			if (deletedDataList != null && !deletedDataList.isEmpty()) {
				delDataObjStatus = getStatusFromEditorForDeleteDataObject(deletedDataList);
					if(delDataObjStatus && SaveAllAction.saveAllFlg) {
						deletedListMap = new HashMap<String, List<CategoryAttributes>>();
					}else {
						deletedListMap.remove(catName);
					}
					
			}
			//Add data object(s) in sldd
			SaveServiceImpl saveService = new SaveServiceImpl();
			// Check if any empty fields while saving a new object
			if (categoryList != null && !categoryList.isEmpty()) {
				saveStatus = false;
				// Conversion into json string
				String originalJsonCat = gson.toJson(categoryList);
				try {

					saveStatus = saveService.saveCategoryData(MatlabScriptConstant.ADD_DATA_OBJECT,
							OpenComponentServiceImpl.selCompName, originalJsonCat);

				} catch (Exception e) {
					LOGGER.error(e.getMessage() + "\n" + MessageConstant.SAVE_SCRIPT_ERROR);
					LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);

					// Reset static values after throwing an exception from Matlab
					allNewObjList = new ArrayList<CategoryAttributes>();
					//MessageDialog.openError(shell, ApplicationConstant.ERROR, MessageConstant.SAVE_SCRIPT_ERROR);
					ViewUtil.dispConfirmDialog("Error Message", e.getMessage());
					setDirty(true);
					return;
				}

			} else {
				saveStatus = displayValidationMessage(saveStatus);
				if (!saveStatus) {
					return;
				}
			}

			
			checkSaveAndDeleteDataStatus(saveStatus, delDataObjStatus, saveService, categoryList,
					deletedDataList);
		} else {
			MessageDialog.openInformation(new Shell(), "Information", ApplicationConstant.SAVE_MESSAGE);
			monitor.setCanceled(true);
		}
	}

	/**
	 * @param deletedDataList
	 * @return
	 */
	private boolean getStatusFromEditorForDeleteDataObject(List<CategoryAttributes> deletedDataList) {
		boolean delDataObjStatus = false;
		EditorService editorService = new EditorServiceImpl();
		try {
			delDataObjStatus = editorService.deleteDataObjectsFromEditor(deletedDataList);
		} catch (MatlabCommunicatinException e) {
			// Reset static data after throwing exception
			deletedListMap = new HashMap<String, List<CategoryAttributes>>();
			MessageDialog.openConfirm(new Shell(), "Error Message", e.getMessage());
		}
		return delDataObjStatus;
	}

	/**
	 * This method is used to set Dimension and value if user does not pressed tab and directly saved data object.
	 * @param categoryList
	 */
	public void setValueNDimWithoutTab(List<CategoryAttributes> categoryList) {
		IDataProvider bodyDataProvider = createNatTable.getJsonDataProvider();
		if(newAddedRowList.contains(new Integer(-1))) {
			newAddedRowList.remove(new Integer(-1));
		}
		for (Integer editedRowIndex : newAddedRowList) {
			NatTableOperation dataServiceObject = new NatTableOperation();
			CategoryAttributes catAttributes = dataServiceObject.getSelectedRowData(editedRowIndex, bodyDataProvider);

				if ((catAttributes.getCategory().equals(ApplicationConstant.CATEGORY_MAP))|| (catAttributes.getCategory().equals(ApplicationConstant.CATCALIBRATION))||
						(catAttributes.getCategory().equals(ApplicationConstant.CATEGORY_AXIS))|| (catAttributes.getCategory().equals(ApplicationConstant.CATEGORY_CURVE))) {

					String valueData ="";
					String generateDimension = "";
					String valueAttr = "";
					//Set Dimension
					String valueColumnData = (String) createNatTable.getJsonDataProvider()
							.getDataValue(CreateNatTable.colValIdx, editedRowIndex);
					if(valueColumnData != null) {

						generateDimension = generateDimension(editedRowIndex);

						//Set value
						String[] split = generateDimension.replace("[","").replace("]", "").split(",");
						valueData = appendZerosInValue(valueColumnData, split);
						String[] newVal1 = convertValueToSend(split, valueData);
						valueAttr = Arrays.toString(newVal1).replace(" ", "");
					}

					catAttributes.setValue(valueAttr);
					catAttributes.setDimensions(generateDimension);
					categoryEdiObj.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colDimIdx,
							editedRowIndex, generateDimension);
					categoryEdiObj.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colValIdx, editedRowIndex, valueData);
				} else if(catAttributes.getCategory().equals(ApplicationConstant.CATEGORY_DEFINE)){

					String valueData = "";
					String generateDimension = "";
					//Set Dimension
					String valueColumnData = (String) createNatTable.getJsonDataProvider().getDataValue(CreateNatTable.colValIdx, editedRowIndex);
					if(valueColumnData != null) {
						generateDimension = generateDimension(editedRowIndex);

						valueData = validateBracketsForValue(valueColumnData); 
					} 
					catAttributes.setDimensions(generateDimension);
					catAttributes.setValue(valueData);
					categoryEdiObj.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colDimIdx,
							editedRowIndex, generateDimension);
					categoryEdiObj.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colValIdx, editedRowIndex, valueData);
				} else if(catAttributes.getCategory().equals(ApplicationConstant.CATEGORY_INPUT) || catAttributes.getCategory().equals(ApplicationConstant.CATEGORY_OUTPUT)
						|| catAttributes.getCategory().equals(ApplicationConstant.CATEGORY_LOCAL) || catAttributes.getCategory().equals(ApplicationConstant.CATEGORY_NVM)){

					String valueData ="";
					String generateDimension = "";
					//Set Dimension
					String valueColumnData = (String) createNatTable.getJsonDataProvider().getDataValue(CreateNatTable.colIniValIdx, editedRowIndex);

					if(valueColumnData != null) {
						generateDimension = generateDimension(editedRowIndex);

						valueData = validateBracketsForValue(valueColumnData);
					} 
					catAttributes.setDimensions(generateDimension);
					catAttributes.setInitialValue(valueData);
					if(valueData == "") {
						generateDimension = "1";
					}
					categoryEdiObj.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colDimIdx,
							editedRowIndex, generateDimension);
					categoryEdiObj.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colIniValIdx, editedRowIndex, valueData);
				}
			//To update data in actual list
			for (CategoryAttributes catAttributes1 : categoryList) {
				if(catAttributes1.getName().equals(catAttributes.getName())) {
					catAttributes1.setDimensions(catAttributes.getDimensions());
					catAttributes1.setValue(catAttributes.getValue());
					catAttributes1.setInitialValue(catAttributes.getInitialValue());
				}
			}
		}
	}
	
	/**
	 * This method is used to set Unit symbol if user does not pressed tab and directly saved data object.
	 * @param categoryList
	 */
	public void setUnitSymbWithoutTab(List<CategoryAttributes> categoryList) {
		IDataProvider bodyDataProvider = createNatTable.getJsonDataProvider();
		if(newAddedRowList.contains(new Integer(-1))) {
			newAddedRowList.remove(new Integer(-1));
		}
		for (Integer editedRowIndex : newAddedRowList) {
			NatTableOperation dataServiceObject = new NatTableOperation();
			CategoryAttributes catAttributes = dataServiceObject.getSelectedRowData(editedRowIndex, bodyDataProvider);
					String unitSym = "";
					String unitColumnData = (String) createNatTable.getJsonDataProvider()
							.getDataValue(CreateNatTable.colUnitIdx, editedRowIndex);
					if(unitColumnData != null) {
						unitSym = unitColumnData.split(" : ")[0];
					}
					catAttributes.setUnit(unitSym);
					categoryEdiObj.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colUnitIdx,
							editedRowIndex, unitSym);

			//To update data in actual list
			for (CategoryAttributes catAttributes1 : categoryList) {
				if(catAttributes1.getName().equals(catAttributes.getName())) {
					catAttributes1.setUnit(catAttributes.getUnit());
				}
			}
		}
	}

	/**
	 * @param valueColumnData
	 * @return
	 */
	private String validateBracketsForValue(String valueColumnData) {
		String valueData;
		if(!(valueColumnData.contains("[")) && !(valueColumnData.contains("]"))&& (!valueColumnData.equals(""))) {

			valueData =  "["+valueColumnData+"]";
		} else {
			valueData =  valueColumnData;
		}
		return valueData;
	}


	/**
	 * This method is used to convert "value" attribute value to send to back end.
	 * @param split
	 * @param valueData
	 * @return String[]
	 */
	private String[] convertValueToSend(String[] split, String valueData) {
		int rowCount = Integer.parseInt(split[0]);
		String newVal1 = null;
		String newTableValue = valueData;
		if (rowCount > 1) {
			String newVal = newTableValue.substring(newTableValue.indexOf('[') + 1, newTableValue.lastIndexOf(']'));
			newVal1 = newVal.replace("][", ",").replace("[", "").replace("]", "");
			
		} else {
			newVal1 = newTableValue.replace("[", "").replace("]", "");
		}
		return newVal1.split(",");
	}
	
	/**
	 * This method is used to append zeros at the end if format is not proper for value attribute
	 * @param valueColumnData
	 * @param split
	 * @return valueData
	 */
	private String appendZerosInValue(String valueColumnData, String[] split) {
		String valueData= "";
		String[] valueColumn = valueColumnData.replace("[", "").split("]");

		int columnCount = Integer.parseInt(split[1]);

		// Append 0's for blank column
		for(int i= 0 ; i<valueColumn.length ; i++) {
			String[] colCount = valueColumn[i].split(",");
			if(colCount.length < columnCount) {
				int diff = columnCount - colCount.length;
				valueColumn[i] = "["+valueColumn[i];
				for(int j = 0; j<diff; j++) {
					valueColumn[i] = valueColumn[i]+",0";
				}
				valueColumn[i] = valueColumn[i]+"]";
				valueData = valueData + valueColumn[i];
			}
			else {
				valueData = valueData + "["+valueColumn[i]+"]";
			}
		}
		return valueData;
	}

	/**
	 * Method used to display validation pop-up while saving.
	 * 
	 * @param saveStatus
	 * @return
	 */
	public boolean displayValidationMessage(boolean saveStatus) {
		//changed for PMD violation
		boolean checkSaveStatus = saveStatus;
		if (duplicNameFlg) {
			message = MessageConstant.UNIQUE_NAME_VAL;
			String nameValMsg = "";
			checkSaveStatus = false;
			showDuplicateNameValidationMessage(nameValMsg);
			// return;
		} else if (SaveAllAction.saveAllFlg) {
			if (!newAddedRowList.isEmpty()) {
				// Show dialog
				checkSaveStatus = false;
				MessageBox messageBox = new MessageBox(shell);
				messageBox.setMessage(updateSaveAllValidationMsg(SaveAllAction.message));
				messageBox.open();
				SaveAllAction.saveAllFlg = false;
			}
		} else {
			if (!newAddedRowList.isEmpty()) {
				// Show dialog
				checkSaveStatus = false;
				message = "";
				message = MessageConstant.REQUIRED_FIELDS + this.getTitle();
				MessageBox messageBox = new MessageBox(shell);
				messageBox.setMessage(updateSaveAllValidationMsg(message));
				messageBox.open();
			}
		}
		return checkSaveStatus;
	}

	/**
	 * Method used to check add and delete data status.
	 * 
	 * @param saveStatus
	 * @param deleteDataObjectStatus
	 * @param saveService
	 * @param categoryList
	 * @param deletedDataList
	 */
	public void checkSaveAndDeleteDataStatus(boolean saveStatus, boolean delDataObjStatus,
			SaveServiceImpl saveService, List<CategoryAttributes> categoryList,
			List<CategoryAttributes> deletedDataList) {
		if (saveStatus && delDataObjStatus) {
			addDeleteSuccessfulOperation();
			if (categoryList != null && !categoryList.isEmpty()) {
				displayAddDataActivityLog(categoryList);
			}
			if (deletedDataList != null && !deletedDataList.isEmpty()) {
				displayDeleteDataActivityLog(deletedDataList);
			}

			MessageDialog.openInformation(shell, ApplicationConstant.INFORMATION, MessageConstant.SAVE_SUCCESS);
			ResolveInconsistencyServiceImpl.resolveDeleteFlag = false;
			ResolveInconsistencyServiceImpl.resolveAddFlag = false;
			ExcelImportExportServiceImpl.resDdDelFlg = false;
			ExcelImportExportServiceImpl.resDdAddFlg = false;
			columnindex = 0;
			rowidx = 0;
			remModelAddLblAftrSave();
			remExcelAddLblAftrSave();
			remCdfLblAftrSave();
			if (ViewUtil.isViewOpen(ViewIDConstant.OUTPUT_DATA_OBJ)) {
				ViewUtil.closeView(ViewIDConstant.OUTPUT_DATA_OBJ);
			}
		} else if (!saveStatus && delDataObjStatus) {
			deleteSuccessfulOperation();
			if (deletedDataList != null && !deletedDataList.isEmpty()) {
				displayDeleteDataActivityLog(deletedDataList);
			}
			if(addUnsuccessfulOperation(saveService)) {
				if (ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
					ActivityLogView.activityLog.append("\n [INFO]: Error occured while adding/updating data objects.");
				}
			}
			// Added
			emptyFieldFlag = true;
			ResolveInconsistencyServiceImpl.resolveDeleteFlag = false;
			ResolveInconsistencyServiceImpl.resolveAddFlag = false;
			ExcelImportExportServiceImpl.resDdDelFlg = false;
			ExcelImportExportServiceImpl.resDdAddFlg = false;
			columnindex = 0;
			rowidx = 0;
			return;
		} else if (saveStatus && !delDataObjStatus) {
			if (ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [INFO]: Error occured while deleting data objects.");
			}
			addSuccessfulOperation();
			displayAddDataActivityLog(categoryList);
			deleteUnsuccessfulOperation();
			ResolveInconsistencyServiceImpl.resolveDeleteFlag = false;
			ResolveInconsistencyServiceImpl.resolveAddFlag = false;
			ExcelImportExportServiceImpl.resDdDelFlg = false;
			ExcelImportExportServiceImpl.resDdAddFlg = false;
			columnindex = 0;
			rowidx = 0;
			remModelAddLblAftrSave();
			remExcelAddLblAftrSave();
			remCdfLblAftrSave();
			if (ViewUtil.isViewOpen(ViewIDConstant.OUTPUT_DATA_OBJ)) {
				ViewUtil.closeView(ViewIDConstant.OUTPUT_DATA_OBJ);
			}
			return;
		} else {
			// ActivityLogView.activityLog.append("\n [INFO]: Save Unsuccessful");
			displayAddDataActivityLog(categoryList);
			addUnsuccessfulOperation(saveService);
			deleteUnsuccessfulOperation();

			// Added
			emptyFieldFlag = true;
			ResolveInconsistencyServiceImpl.resolveDeleteFlag = false;
			ResolveInconsistencyServiceImpl.resolveAddFlag = false;
			ExcelImportExportServiceImpl.resDdDelFlg = false;
			ExcelImportExportServiceImpl.resDdAddFlg = false;
			
			columnindex = 0;
			rowidx = 0;
			return;
		}
	}

	/**
	 * Method used to display activity log messages for Add data object(s).
	 * 
	 * @param categoryList
	 */
	public void displayAddDataActivityLog(List<CategoryAttributes> categoryList) {
		if (ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
			ActivityLogView.activityLog.append("\n [INFO]: Below Data Object(s) Saved Successfully:");
			ActivityLogView.activityLog.append("\n ===========================================");
			for (int i = 0; i < categoryList.size(); i++) {
				CategoryAttributes attributes = categoryList.get(i);
				ActivityLogView.activityLog
						.append("\n " + (i + 1) + ". " + attributes.getCategory() + " : " + attributes.getName());
			}
		}
	}

	/**
	 * Method used to display activity log messages for delete data object(s).
	 * 
	 * @param deletedDataList
	 */
	public void displayDeleteDataActivityLog(List<CategoryAttributes> deletedDataList) {
		if (ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
			ActivityLogView.activityLog.append("\n [INFO]: Below Data Object(s) Deleted Successfully:");
			ActivityLogView.activityLog.append("\n ===========================================");
			for (int i = 0; i < deletedDataList.size(); i++) {
				CategoryAttributes attributes = deletedDataList.get(i);
				ActivityLogView.activityLog
						.append("\n " + (i + 1) + ". " + attributes.getCategory() + " : " + attributes.getName());
			}
		}
	}

	/**
	 * Method used to show validation pop-up foe duplicate name.
	 * 
	 * @param nameValidationMessage
	 */
	public void showDuplicateNameValidationMessage(String nameValMsg) {
		//changed for PMD
		String validationMsg = nameValMsg;
		if (SaveAllAction.saveAllFlg) {
			validationMsg = SaveAllAction.dupNameMsg + "\n" + "because "
					+ MessageConstant.UNIQUE_NAME_VAL;
		} else {
			validationMsg = MessageConstant.DUPLICATE_NAME + "\n" + "'" + getTitle() + "'"
					+ "  " + NatTableOperation.duplicateNameList + "\n" + "because "
					+ MessageConstant.UNIQUE_NAME_VAL;
			NatTableOperation.duplicateNameList = new ArrayList<>();
		}
		String nameMessage = validationMsg;
		parent.getDisplay().asyncExec(new Runnable() {
			public void run() {
				MessageDialog messageDialog = new MessageDialog(null, ApplicationConstant.EDIT_VIOLATION, null,
						nameMessage, 0, new String[] { "Change" }, 0);
				messageDialog.open();
			}
		});
		duplicNameFlg = false;
	}

	/**
	 * Method used to remove resolve inconsistency using model highlight after saving.
	 */
	public void remModelAddLblAftrSave() {
		try {
			IWorkbenchPage activePage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
			IEditorReference[] editorRef = activePage.getEditorReferences();
			if (null != InconsistencyWindowView.ddCheckBoxList) {
				for (CategoryAttributes object : InconsistencyWindowView.ddCheckBoxList) {
					String categoryName = object.getCategory();
					for (IEditorReference editor : editorRef) {
						IEditorPart editorPart = editor.getEditor(false);
						if (editorPart instanceof CategoryEditor && editorPart.getTitle().equals(categoryName)) {
							CategoryEditor categoryEditor = (CategoryEditor) editorPart;
							DataDictionaryApplication.getApplication().setSearchedHighlighted(object);
							DataDictionaryApplication.getApplication().setSearchedHighLight(true);
							activePage.activate(categoryEditor);
							categoryEditor.removeNatTableConfigurationForAddResolve();
						}
					}
				}
				//added separate loop for configuring nattable because of Unhandled event loop exception
				for (IEditorReference editor : editorRef) {
					IEditorPart editorPart = editor.getEditor(false);
					if (editorPart instanceof CategoryEditor) {
						CategoryEditor categoryEditor = (CategoryEditor) editorPart;
						categoryEditor.natTable.configure();
					}
				}
			} else {
				createNatTable.getSelectionLayer().setConfigLabelAccumulator(null);
				this.natTable.refresh();
			}
			if(InconsistencyWindowView.ddCheckBoxList != null) {
				InconsistencyWindowView.ddCheckBoxList = null;
			}
		} catch (Exception e) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
		}
	}
	/**
	 * Method used to remove resolve inconsistency using excel highlight after saving.
	 */
	public void remExcelAddLblAftrSave() {
		try {
			IWorkbenchPage activePage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
			IEditorReference[] editorRef = activePage.getEditorReferences();
			if (null != ImportFromExcelWindowView.addCheckList) {
				for (CategoryAttributes object : ImportFromExcelWindowView.addCheckList) {
					String categoryName = object.getCategory();
					for (IEditorReference editor : editorRef) {
						IEditorPart editorPart = editor.getEditor(false);
						if (editorPart instanceof CategoryEditor && editorPart.getTitle().equals(categoryName)) {
							CategoryEditor categoryEditor = (CategoryEditor) editorPart;
							DataDictionaryApplication.getApplication().setSearchedHighlighted(object);
							DataDictionaryApplication.getApplication().setSearchedHighLight(true);
							activePage.activate(categoryEditor);
							categoryEditor.removeNatTableConfigurationForAddResolve();
						}
					}
				}
				//added separate loop for configuring nattable because of Unhandled event loop exception
				for (IEditorReference editor : editorRef) {
					IEditorPart editorPart = editor.getEditor(false);
					if (editorPart instanceof CategoryEditor) {
						CategoryEditor categoryEditor = (CategoryEditor) editorPart;
						categoryEditor.natTable.configure();
					}
				}
			} else {
				createNatTable.getSelectionLayer().setConfigLabelAccumulator(null);
				this.natTable.refresh();
			}
			if(ImportFromExcelWindowView.addCheckList!=null) {
				ImportFromExcelWindowView.addCheckList = null;
			}
		} catch (Exception e) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
		}
	}
	
	/**
	 * Method used to remove apply cdf values highlight after saving.
	 */
	public void remCdfLblAftrSave() {
		try {
			IWorkbenchPage activePage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
			IEditorReference[] editorRef = activePage.getEditorReferences();
			if (null != ApplyCdfView.selCdfObjList) {
				for (CategoryAttributes object : ApplyCdfView.selCdfObjList) {
					String categoryName = object.getCategory();
					for (IEditorReference editor : editorRef) {
						IEditorPart editorPart = editor.getEditor(false);
						if (editorPart instanceof CategoryEditor && editorPart.getTitle().equals(categoryName)) {
							CategoryEditor categoryEditor = (CategoryEditor) editorPart;
							DataDictionaryApplication.getApplication().setSearchedHighlighted(object);
							DataDictionaryApplication.getApplication().setSearchedHighLight(true);
							activePage.activate(categoryEditor);
							categoryEditor.removeNatTableConfigurationForAddResolve();
						}
					}
				}
				//added separate loop for configuring nattable because of Unhandled event loop exception
				for (IEditorReference editor : editorRef) {
					IEditorPart editorPart = editor.getEditor(false);
					if (editorPart instanceof CategoryEditor) {
						CategoryEditor categoryEditor = (CategoryEditor) editorPart;
						categoryEditor.natTable.configure();
					}
				}
			} else {
				createNatTable.getSelectionLayer().setConfigLabelAccumulator(null);
				this.natTable.refresh();
			}
			if(ApplyCdfView.selCdfObjList!=null) {
				ApplyCdfView.selCdfObjList = null;
			}
		} catch (Exception e) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
		}
	}

	/**
	 * Method used after delete unsuccessful
	 * 
	 * @param message
	 */
	private void deleteUnsuccessfulOperation() {
		// Need to handle error code

		// Remove dirty bits for dirty editors
		if (SaveAllAction.saveAllFlg) {

			/*
			 * IEditorPart[] dirtyEditors =
			 * ProjectExplorerView.activePage.getDirtyEditors(); for (IEditorPart
			 * iEditorPart : dirtyEditors) { CategoryEditor categoryEditor =
			 * (CategoryEditor) iEditorPart; categoryEditor.setDirty(true); }
			 */

			SaveAllAction.saveAllFlg = false;

		} else {
			this.setDirty(true);
		}

	}

	/**
	 * Method used after delete Successful and reset the data.
	 * 
	 * @param message
	 */
	private void deleteSuccessfulOperation() {

		// Remove dirty bits for dirty editors
		if (SaveAllAction.saveAllFlg) {
			IWorkbenchPage activePage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
			IEditorPart[] dirtyEditors = activePage.getDirtyEditors();
			for (IEditorPart iEditorPart : dirtyEditors) {
				CategoryEditor categoryEditor = (CategoryEditor) iEditorPart;
				if (categoryEditor.newAddedRowList.isEmpty()) {
					categoryEditor.setDirty(false);
				}
				// Update saved component data
				updateComponentData(categoryEditor);

			}

			deletedListMap = new HashMap<String, List<CategoryAttributes>>();

		} else {
			if (categoryEdiObj.newAddedRowList.isEmpty()) {
				this.setDirty(false);
			}

			deletedListMap.put(this.getTitle(), new ArrayList<CategoryAttributes>());
			// Update saved component data
			updateComponentData(this);
		}

	}

	/**
	 * Method used after save unsuccessful
	 * 
	 * @param saveService
	 */
	private boolean addUnsuccessfulOperation(SaveServiceImpl saveService) {
		String message;
		List<SaveResponseCode> unsavedCatList = saveService.getUnsavedCategoryList();
		message = MessageConstant.SAVE_ERROR;

		if (unsavedCatList != null) {
			for (SaveResponseCode saveResponseCode : unsavedCatList) {
				message += "\n" + saveResponseCode.getCategory() + " -> " + saveResponseCode.getName() + " -> "
						+ saveResponseCode.getAttribute();
			}
		}

		SaveAllAction.saveAllFlg = false;
		SaveAllAction.message = "";
		SaveAllAction.dupNameMsg = "";

		if (unsavedCatList != null && !unsavedCatList.isEmpty()) {
			MessageDialog.openWarning(shell, ApplicationConstant.WARNING, message);
			setDirty(true);
			return false;
		} else {
			return true;
		}
	}

	/**
	 * Method used after save successful
	 */
	private void addDeleteSuccessfulOperation() {
		if (!newAddedRowList.isEmpty()) {
			updateOldName();
		}

		/*
		 * // reinitialize editedRowLists after saving newly added objects
		 * newlyAddedRowLists = new LinkedHashSet<>(); matlabDataObjectList =
		 * createNatTable.getCategoryList();
		 */

		// Remove dirty bits for dirty editors
		if (SaveAllAction.saveAllFlg) {
			// reinitialize all new added object list after saving earlier added objects
			allNewObjList = new ArrayList<>();
			IWorkbenchPage activePage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
			IEditorPart[] dirtyEditors = activePage.getDirtyEditors();
			for (IEditorPart iEditorPart : dirtyEditors) {
				CategoryEditor categoryEditor = (CategoryEditor) iEditorPart;

				if (!categoryEditor.newAddedRowList.isEmpty()) {
					categoryEditor.updateOldName();
				}
				categoryEditor.emptyFieldsFlag = false;
				categoryEditor.setDirty(false);
				// SaveAllAction.SAVE_ALL_FLAG = false;
				SaveAllAction.message = "";
				SaveAllAction.dupNameMsg = "";
				categoryEditor.newAddedRowList = new LinkedHashSet<>();
				categoryEditor.editRowLists = new LinkedHashSet<>();
				// Update saved component data
				updateComponentData(categoryEditor);

			}

			deletedListMap = new HashMap<String, List<CategoryAttributes>>();
			SaveAllAction.saveAllFlg = false;

		} else {
			setDirty(false);
			this.emptyFieldsFlag = false;
			deletedListMap.put(this.getTitle(), new ArrayList<CategoryAttributes>());
			this.newAddedRowList = new LinkedHashSet<>();
			this.editRowLists = new LinkedHashSet<>();
			// Update saved component data
			updateComponentData(this);
		}

		// reinitialize editedRowLists after saving newly added objects
		// newlyAddedRowLists = new LinkedHashSet<>();
		matlabDataObjList = createNatTable.getCategoryList();

		// reinitialize undo stack and redo stack after saving newly added objects
		undoEditStack = new FixedStack<Object>(ApplicationConstant.MAX_STACK_SIZE);
		redoEditorStack = new FixedStack<Object>(ApplicationConstant.MAX_STACK_SIZE);

		undoRedoOperation.makeUndoRedoEnableDisable(undoEditStack, redoEditorStack);

		saveOperation.makeSaveEnableDisable(this);
		savedDataObjList = createNatTable.getJsonDataProvider().getList();
	}

	/**
	 * This function is used to update the saved component data.
	 * 
	 * @param categoryEditor
	 */
	private void updateComponentData(CategoryEditor categoryEditor) {
		// Update component Data
		Map<String, List<CategoryAttributes>> componentMapList = DataDictionaryApplication.getApplication()
				.getComponentMapList();
		componentMapList.put(categoryEditor.getTitle(), categoryEditor.createNatTable.getJsonDataProvider().getList());
		DataDictionaryApplication.getApplication().setComponentMapList(componentMapList);
	}

	/**
	 * Method used when add data object is successful.
	 */
	private void addSuccessfulOperation() {
		if (!newAddedRowList.isEmpty()) {
			updateOldName();
		}

		// Remove dirty bits for dirty editors
		if (SaveAllAction.saveAllFlg) {
			// reinitialize all new added object list after saving earlier added objects
			allNewObjList = new ArrayList<>();
			IWorkbenchPage activePage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
			IEditorPart[] dirtyEditors = activePage.getDirtyEditors();
			for (IEditorPart iEditorPart : dirtyEditors) {
				CategoryEditor categoryEditor = (CategoryEditor) iEditorPart;

				if (!categoryEditor.newAddedRowList.isEmpty()) {
					categoryEditor.updateOldName();
				}

				if (deletedListMap.get(categoryEditor.getTitle()) == null
						|| deletedListMap.get(categoryEditor.getTitle()).isEmpty()) {
					categoryEditor.setDirty(false);
				}

				// Update saved component data
				updateComponentData(categoryEditor);
				categoryEditor.emptyFieldsFlag = false;
				// SaveAllAction.SAVE_ALL_FLAG = false;
				SaveAllAction.message = "";
				SaveAllAction.dupNameMsg = "";
			}

			// SaveAllAction.SAVE_ALL_FLAG = false;

		} else {
			if (deletedListMap.get(this.getTitle()) == null || deletedListMap.get(this.getTitle()).isEmpty()) {
				this.setDirty(false);
			}
			this.emptyFieldsFlag = false;
			// Update saved component data
			updateComponentData(this);
		}

		// reinitialize editedRowLists after saving newly added objects
		newAddedRowList = new LinkedHashSet<>();
		matlabDataObjList = createNatTable.getCategoryList();

		// reinitialize undo stack and redo stack after saving newly added objects
		undoEditStack = new FixedStack<Object>(ApplicationConstant.MAX_STACK_SIZE);
		redoEditorStack = new FixedStack<Object>(ApplicationConstant.MAX_STACK_SIZE);

		undoRedoOperation.makeUndoRedoEnableDisable(undoEditStack, redoEditorStack);

		saveOperation.makeSaveEnableDisable(this);
		savedDataObjList = createNatTable.getJsonDataProvider().getList();
	}

	/**
	 * Method used to update old name of data objects with new names
	 */
	public void updateOldName() {
		List<CategoryAttributes> dataObjectList = createNatTable.getJsonDataProvider().getList();

		for (int i = 0; i < dataObjectList.size(); i++) {
			String newName = (String) createNatTable.getJsonDataProvider()
					.getDataValue(CreateNatTable.colNameIdx, i);
			createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colOldNamIdx, i, newName);
		}
	}

	/**
	 * Method used to update save-all validation message depending on category
	 * 
	 * @param messageToBeUpdated
	 */
	private String updateSaveAllValidationMsg(String msgToBeUpdated) {
		//changed for PMD
		String updatedMsg = msgToBeUpdated;
		if (updatedMsg.contains(ApplicationConstant.CATEGORY_INPUT)
				|| updatedMsg.contains(ApplicationConstant.CATEGORY_OUTPUT)
				|| updatedMsg.contains(ApplicationConstant.CATEGORY_LOCAL)
				|| updatedMsg.contains(ApplicationConstant.CATEGORY_NVM)) {

			updatedMsg += "\n" + "\n" + MessageConstant.REQUIRED_FIELD + " for "
					+ ApplicationConstant.CATEGORY_INPUT + " , " + ApplicationConstant.CATEGORY_OUTPUT + " , "
					+ ApplicationConstant.CATEGORY_LOCAL + " , " + ApplicationConstant.CATEGORY_NVM + " : "
					+ MessageConstant.REQ_FIELDS_INPUT;
		}
		if (updatedMsg.contains(ApplicationConstant.CATEGORY_AXIS)
				|| updatedMsg.contains(ApplicationConstant.CATCALIBRATION)
				|| updatedMsg.contains(ApplicationConstant.CATEGORY_CURVE)
				|| updatedMsg.contains(ApplicationConstant.CATEGORY_MAP)
				|| updatedMsg.contains(ApplicationConstant.CATEGORY_DEFINE)) {

			updatedMsg += "\n" + "\n" + MessageConstant.REQUIRED_FIELD + " for "
					+ ApplicationConstant.CATEGORY_AXIS + " , " + ApplicationConstant.CATCALIBRATION + " , "
					+ ApplicationConstant.CATEGORY_CURVE + " , " + ApplicationConstant.CATEGORY_MAP + " , " + ApplicationConstant.CATEGORY_DEFINE +" : "
					+ MessageConstant.REQ_FIELDS_MAP;
		}
		/*if (messageToBeUpdated.contains(ApplicationConstant.CATEGORY_DEFINE)) {

			messageToBeUpdated += "\n" + "\n" + MessageConstant.REQUIRED_FIELD + " for "
					+ ApplicationConstant.CATEGORY_DEFINE + " : " + MessageConstant.REQUIRED_FIELDS_FOR_DEFINE;

		}*/

		return updatedMsg;
	}

	/**
	 * Method is used to get list of newly added data objects
	 * 
	 * @return ArrayList<CategoryDAO>
	 */
	public List<CategoryAttributes> getNewObjectsList() {
		// Get the body data provider of natTable
		IDataProvider bodyDataProvider = createNatTable.getJsonDataProvider();

		// Data handling for save using Category (DAO)
		NatTableOperation dataServiceObject = new NatTableOperation();
		newAddedRowList.addAll(editRowLists);

		// Get all edited or newly added objects
		List<CategoryAttributes> categoryList = dataServiceObject.getNewDataofCategory(newAddedRowList,
				bodyDataProvider);
		return categoryList;
	}

	/**
	 * Method used to get category adapters.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Object getAdapter(Class arg0) {
		if (categoryEdiObj.createNatTable.getSelectionLayer().hasColumnSelection()) {
			selectedCells = categoryEdiObj.createNatTable.getSelectionLayer().getSelectedCells();
			ApplicationActionBarAdvisor.getInstance().cutAction.setEnabled(true);
			ApplicationActionBarAdvisor.getInstance().copyAction.setEnabled(true);
			ApplicationActionBarAdvisor.getInstance().deleteAction.setEnabled(true);
		} else {
			ApplicationActionBarAdvisor.getInstance().cutAction.setEnabled(false);
			ApplicationActionBarAdvisor.getInstance().copyAction.setEnabled(false);
			ApplicationActionBarAdvisor.getInstance().pasteAction.setEnabled(false);
			ApplicationActionBarAdvisor.getInstance().deleteAction.setEnabled(false);
			if (ViewUtil.isViewOpen(ViewIDConstant.MIN_MAX_INFO)) {
				ViewUtil.showHideView(ViewIDConstant.MIN_MAX_INFO, false);
			}
		}
		ViewUtil.showHideView(ViewIDConstant.MIN_MAX_INFO, false);
		return null;
	}

	/**
	 * Setter method to set the part name.
	 */
	/*@Override
	protected void setPartName(String partName) {
		super.setPartName(partName);
	}*/

	/**
	 * Setter method to set the tool tip text.
	 */
	/*@Override
	protected void setTitleToolTip(String toolTip) {
		super.setTitleToolTip(toolTip);
	}*/

	/**
	 * Setter Method used to set the content description.
	 */
	/*@Override
	protected void setContentDescription(String description) {
		super.setContentDescription(description);
	}
*/
	/**
	 * Method used to dispose/close the editor
	 */
	@Override
	public void dispose() {
		closeValueTableEditor();
		catEditorCount -= 1;
		if (catEditorCount == 0) {
			ApplicationActionBarAdvisor.getInstance().filterAction
					.setImageDescriptor(Activator.getImageDescriptor("/icons/filter.png"));
			ApplicationActionBarAdvisor.getInstance().filterAction.setEnabled(false);
			ApplicationActionBarAdvisor.getInstance().cutAction.setEnabled(false);
			ApplicationActionBarAdvisor.getInstance().copyAction.setEnabled(false);
			ApplicationActionBarAdvisor.getInstance().saveAction.setEnabled(false);
			ApplicationActionBarAdvisor.getInstance().undoAction.setEnabled(false);
			ApplicationActionBarAdvisor.getInstance().redoAction.setEnabled(false);
			ApplicationActionBarAdvisor.getInstance().saveAllAction.setEnabled(false);
			ApplicationActionBarAdvisor.getInstance().deleteAction.setEnabled(false);
			ApplicationActionBarAdvisor.getInstance().resolvInconObj.setEnabled(false);
			DataDictionaryApplication.getApplication().setOutputSignalJson(null);
			ViewUtil.closeView(ViewIDConstant.OUTPUT_DATA_OBJ);
		}

		super.dispose();

	}

	/**
	 * Method used to set the part property change.
	 */
	@Override
	public void setPartProperty(String key, String value) {
		super.setPartProperty(key, value);
	}

	/**
	 * Method used to set dirty bit status for editor
	 * 
	 * @param status
	 */
	public void setDirtyStatus(boolean status) {
		setDirty(status);
	}

	/**
	 * Method is used to update category editor after deleting data object(s)
	 * 
	 * @param categoryEditor
	 * @param warningName
	 * @param componentName
	 * @param objectName
	 */
	public void updateCategoryEditor(CategoryEditor categoryEditor, String warningName, String componentName,
			String objectName) {

		categoryEditor.createNatTable.setCategoryList(categoryEditor.matlabDataObjList);
		List<CategoryAttributes> categoryList = categoryEditor.createNatTable.getJsonDataProvider().getList();
		for (int categoryListCount = 0; categoryListCount < categoryList.size(); categoryListCount++) {
			CategoryAttributes category = categoryList.get(categoryListCount);
			if (category.getComponent().equals(componentName) && category.getName().equals(objectName)) {
				categoryList.remove(category);
				createNatTable.filterList.remove(category);
			}
		}
		categoryEditor.natTable.refresh();
		// categoryEditor.createNatTable.loadNatTable(categoryEditor.parent,
		// categoryList);

	}

	/**
	 * This method is used to perform action after clicking on Delete Data Object
	 * context menu for category table.
	 */
	public void deleteDataObjectFromContextMenu() {

		Set<Integer> deletedRowLists = new TreeSet<>();
		List<Object> natTblRowIdxList = new ArrayList<Object>();

		boolean delDataDialogVal = MessageDialog.openConfirm(shell, ApplicationConstant.WARNING,
				MessageConstant.DELETE_DATA);
		if (delDataDialogVal) {
			Collection<ILayerCell> selectedCells = createNatTable.getSelectionLayer().getSelectedCells();

			for (ILayerCell cell : selectedCells) {
				deletedRowLists.add(cell.getRowIndex());
			}

			ArrayList<CategoryAttributes> deletedDataList = new ArrayList<>();

			addSelectedRowInDeleteRowList(deletedDataList, deletedRowLists, natTblRowIdxList);
			
			if (!deletedDataList.isEmpty()) {
				//Scenario handled : If user has cut the data and tried to delete the row
				for (CategoryAttributes categoryData : deletedDataList) {
					if(categoryData.getName()==null || categoryData.getName().equals("")) {
						MessageDialog.openInformation(shell, ApplicationConstant.WARNING,
								"Cannot delete if data object name is empty, Please reload the component.");
						
						return;
					}
				}
				List<CategoryAttributes> deletedUpdateList = deletedListMap.get(this.getTitle());
				if (deletedUpdateList != null) {
					deletedUpdateList.addAll(deletedDataList);
					deletedListMap.put(this.getTitle(), deletedUpdateList);
				} else {
					deletedListMap.put(this.getTitle(), deletedDataList);
				}

			}

			DataDictionaryApplication.getApplication().setSearchedHighLight(false);
			DataDictionaryApplication.getApplication().setSearchedHighlighted(null);
			
			// Updated logic for dirty bit issue after deleting and adding new rows
			for(int deleteRowIndex : deletedRowLists){
				for(Iterator<Integer> itr = newAddedRowList.iterator(); itr.hasNext();) {
					if(itr.next() == deleteRowIndex){
						itr.remove();
					}
				}
			}
			for(int deleteRowIndex : deletedRowLists){
				for(Iterator<Integer> itr = editRowLists.iterator(); itr.hasNext();) {
					if(itr.next() == deleteRowIndex){
						itr.remove();
					}
				}
			}
			
			NavigableSet<Integer>res = ((TreeSet<Integer>) deletedRowLists).descendingSet();
            for(Iterator<Integer> itr = res.iterator(); itr.hasNext();) {

				int deletedRow = itr.next();
				//int rowCount = 0;
				boolean status = createNatTable.getSelectionLayer()
						.doCommand(new DeleteRowCommand(createNatTable.getSelectionLayer(), deletedRow));
				//rowCount++;
				updateAddedRowListIndex(status, deletedRow);
			}
			rowDeleted = true;
			Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
			MessageDialog.openInformation(shell, ApplicationConstant.INFORMATION,
					MessageConstant.DELETE_SUCCESS);
			if(ViewUtil.isViewOpen(ViewIDConstant.OUTPUT_DATA_OBJ)) {
				ViewUtil.closeView(ViewIDConstant.OUTPUT_DATA_OBJ);
			}
			
			addDataInUndoStkForDelete(deletedRowLists, natTblRowIdxList, deletedDataList);
			
			undoRedoOperation.makeUndoRedoEnableDisable(categoryEdiObj.undoEditStack,
					categoryEdiObj.redoEditorStack);
			categoryEdiObj.editModeFlag = false;

			addOrRemDirtyBitAftrDelete();
			saveOperation.makeSaveEnableDisable(categoryEdiObj);
		}

		deletedRowLists.clear();
	
	}

	/**
	 * @param deletedRowLists
	 * @param natTblRowIdxList
	 * @param deletedDataList
	 */
	private void addDataInUndoStkForDelete(Set<Integer> deletedRowLists, List<Object> natTblRowIdxList,
			List<CategoryAttributes> deletedDataList) {
		// Add data into undo stack for delete operation
		if (!ImportProjectServiceImpl.pasteFlag) {
			// add data for single row delete
			if (natTblRowIdxList.size() == 1) {
				Iterator<Integer> ite = deletedRowLists.iterator();
				Integer currentIndex = null;
				while (ite.hasNext()) {
					currentIndex = ite.next();
				}
				if(currentIndex != null) {
					categoryEdiObj.undoEditStack.push(new NatTableRowIndexDelete(
							createNatTable.getSelectionLayer(), deletedDataList.get(0), currentIndex));
				}

			} else {
				// add data for multiple row delete
				NatTableRowIndexArrayForDelete natTblRowIdxArray = new NatTableRowIndexArrayForDelete();
				natTblRowIdxArray.setNatTableRowIndexList(natTblRowIdxList);
				categoryEdiObj.undoEditStack.push(natTblRowIdxArray);
			}
		}
	}

	/**
	 * Method used to set/remove the dirty bit after deleting rows from table
	 */
	private void addOrRemDirtyBitAftrDelete() {
		try {
			if (newAddedRowList.isEmpty() && editRowLists.isEmpty()
					&& deletedListMap.get(this.getTitle()).isEmpty()) {
				setDirty(false);
				columnindex = 0;
				rowidx = 0;
			} else {
				setDirty(true);
			}
		} catch (Exception e) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
		}
	}

	private void addSelectedRowInDeleteRowList(List<CategoryAttributes> deletedDataList,
			Set<Integer> deletedRowLists, List<Object> natTblIdxList) {
		for (int deletedRow : deletedRowLists) {
			//String name = createNatTable.getJsonDataProvider().getList().get(deletedRow).getName();
			if (!newAddedRowList.contains(deletedRow)) {
				//String name = (String) createNatTable.getJsonDataProvider().getDataValue(CreateNatTable.colNameIdx, deletedRow);
				//String name = createNatTable.getJsonDataProvider().getList().get(deletedRow).getName();
				
				//if(null!=name ||!name.equals("")) {
					deletedDataList.add(createNatTable.getJsonDataProvider().getList().get(deletedRow));
					natTblIdxList.add(new NatTableRowData(
							createNatTable.getJsonDataProvider().getList().get(deletedRow), deletedRow));
				//}
				
			}
		}
	}

	private void updateAddedRowListIndex(boolean status, int deletedRow) {
		if (status) {
			// Update newlyAddedRowLists
			Iterator<Integer> newlyAddedIndexIt = newAddedRowList.iterator();
			Set<Integer> updateIdxSet = new LinkedHashSet<>();
			while (newlyAddedIndexIt.hasNext()) {
				int newlyAddedIndex = newlyAddedIndexIt.next();
				if (deletedRow <newlyAddedIndex) {
					
					newlyAddedIndexIt.remove();
					updateIdxSet.add(--newlyAddedIndex);
				}
				
			}
			newAddedRowList.addAll(updateIdxSet);

			// Update editRowLists
			Iterator<Integer> editedIndexIt = editRowLists.iterator();
			Set<Integer> updEditIdxSet = new LinkedHashSet<>();
			while (editedIndexIt.hasNext()) {
				int editedIndex = editedIndexIt.next();
				if (deletedRow < editedIndex) {
					editedIndexIt.remove();
					updEditIdxSet.add(--editedIndex);
				}
			}
			editRowLists.addAll(updEditIdxSet);

			rowidx = 0;
			columnindex = 0;
		}
	}

	/**
	 * This method is used to perform find in model after clicking on Find In Model
	 * context menu for category table.
	 */
	private void findInModelFromContextMenu() {
		int selectedRowCount = -1;
		if (cellEvent != null) {
			selectedRowCount = cellEvent.getSelectionLayer().getSelectedRowCount();
		} else if (rowEvent != null) {
			selectedRowCount = rowEvent.getRowPositionRanges().size();
		}
		if (selectedRowCount == 1) {
			if (createNatTable.getGridLayer()
					.getColumnIndexByPosition(columnfindInModel) != CreateNatTable.colNameIdx) {
				MessageDialog.openWarning(shell, ApplicationConstant.WARNING, MessageConstant.NAME_FOR_MODEL);
			} else if (selDataObj == null || selDataObj.trim().isEmpty()) {
				MessageDialog.openError(shell, ApplicationConstant.ERROR, MessageConstant.EMPTY_NAME_MODEL);
			} else {

				try {
					findInModelSer.highlightInModel();
				} catch (MatlabCommunicatinException e1) {
					MessageDialog.openConfirm(new Shell(), "Error Message", e1.getMessage());
				} catch (EditorInitilizationException e2) {
					MessageDialog.openConfirm(new Shell(), "Error Message", e2.getMessage());
				}

			}
		} else {
			MessageDialog.openInformation(shell, ApplicationConstant.INFORMATION,
					MessageConstant.FIND_IN_MODEL_VAL);
		}
	}

	/**
	 * This method is used to perform rename in model after clicking on Rename In
	 * Model context menu for category table.
	 */
	private void renameInModelFromContextMenu() {
		int selectedRowCount = -1;
		if (cellEvent != null) {
			selectedRowCount = cellEvent.getSelectionLayer().getSelectedRowCount();
		} else if (rowEvent != null) {
			selectedRowCount = rowEvent.getRowPositionRanges().size();
		}
		if (selectedRowCount > 0) {
			if (createNatTable.getGridLayer()
					.getColumnIndexByPosition(columnfindInModel) != CreateNatTable.colNameIdx) {
				MessageDialog.openWarning(shell, ApplicationConstant.WARNING, MessageConstant.NAME_FOR_RENAME);
			} else if (selDataObj == null || selDataObj.trim().isEmpty()) {
				MessageDialog.openError(shell, ApplicationConstant.ERROR, MessageConstant.EMPTY_NAME_MODEL);
			} else {

				new RenameInModelServiceimpl().openRenameWindow();
			}
		}
	}

	/**
	 * Method is used to configure NatTable
	 * 
	 * @param dataProvider
	 * @param columnLabelAccumulator
	 * @return
	 */
	public static AbstractRegistryConfiguration editableGridConfiguration(String title, IDataProvider dataProvider,
			ColumnOverrideLabelAccumulator colLblAccum) {

		return new AbstractRegistryConfiguration() {

			@Override
			public void configureRegistry(IConfigRegistry configRegistry) {
				CreateNatTable.registerColumnLabels(colLblAccum);
				NatTableEditConfiguration.registerBaseTypeComboBox(configRegistry);
				if(Application.unitsJson!=null) {
					NatTableEditConfiguration.registerUnitComboBox(configRegistry);
				}
				
				NatTableEditConfiguration.registerEditableRules(configRegistry, dataProvider);
				Style cellStyle = new Style();
				cellStyle.setAttributeValue(CellStyleAttributes.BACKGROUND_COLOR,
						GUIHelper.getColor(new RGB(135, 206, 250)));
				configRegistry.registerConfigAttribute(CellConfigAttributes.CELL_STYLE, cellStyle, DisplayMode.NORMAL,
						HIGHLIGHTLBL);

				Style addCellStyle = new Style();
				addCellStyle.setAttributeValue(CellStyleAttributes.BACKGROUND_COLOR,
						GUIHelper.getColor(new RGB(0, 128, 0)));
				configRegistry.registerConfigAttribute(CellConfigAttributes.CELL_STYLE, addCellStyle,
						DisplayMode.NORMAL, ADDOBJLBL);

				Style deleteCellStyle = new Style();
				deleteCellStyle.setAttributeValue(CellStyleAttributes.BACKGROUND_COLOR,
						GUIHelper.getColor(new RGB(255, 0, 0)));
				configRegistry.registerConfigAttribute(CellConfigAttributes.CELL_STYLE, deleteCellStyle,
						DisplayMode.NORMAL, DELETEOBJLBL);
				
				configRegistry.registerConfigAttribute(
						EditConfigAttributes.CELL_EDITOR,
						new TextCellEditor() {
							@Override
							public Text createEditorControl(Composite parent) {
								Text textControl = super.createEditorControl(parent);
								// disable context menu in Text field
								textControl.addMenuDetectListener(new MenuDetectListener() {
									@Override
									public void menuDetected(MenuDetectEvent event) {
										//event.doit = false;
									}
								});
								return textControl;
							}
						});
				
				configRegistry.registerConfigAttribute(
	                    EditConfigAttributes.SUPPORT_MULTI_EDIT,
	                    Boolean.FALSE,
	                    DisplayMode.EDIT);
			}

		};
	}

	/**
	 * Method used for widget selection
	 */
	@Override
	public void widgetSelected(SelectionEvent event) {
		Button source = (Button) event.getSource();
		AddDataObjectWindow addDataObjWindow = new AddDataObjectWindow();
		if (source.getText().equals(ApplicationConstant.BTN_ADDDATAOBJECT)) {
			if (this.getTitle().equals("Input")) {
				if (ViewUtil.isViewOpen(ViewIDConstant.OUTPUT_DATA_OBJ)) {
					ViewUtil.closeView(ViewIDConstant.OUTPUT_DATA_OBJ);
				}
				addDataObjWindow.open();

			} else {
				setAddDataObjectDetails(null);
				this.natTable.refresh();
				setDirty(true);
			}

		} else if (source.getText().equals(ApplicationConstant.BTN_FINDINMODEL)) {
			try {
				int selectedRowCount = -1;
				if (cellEvent != null) {
					selectedRowCount = cellEvent.getSelectionLayer().getSelectedRowCount();
				} else if (rowEvent != null) {
					selectedRowCount = rowEvent.getRowPositionRanges().size();
				}
				if (selectedRowCount == 1) {
					findInModelSer.highlightInModel();
				} else {
					MessageDialog.openInformation(shell, ApplicationConstant.INFORMATION,
							MessageConstant.FIND_IN_MODEL_VAL);
				}
			} catch (MatlabCommunicatinException e1) {
				MessageDialog.openConfirm(new Shell(), "Error Message", e1.getMessage());
			} catch (EditorInitilizationException e1) {
				MessageDialog.openConfirm(new Shell(), "Error Message", e1.getMessage());
			}
		}

	}

	/**
	 * Method used for default widget selection
	 */
	@Override
	public void widgetDefaultSelected(SelectionEvent event) {
		// nothing to do

	}

	/**
	 * Method used to add event listener for natTable
	 */
	@Override
	public void handleLayerEvent(ILayerEvent event) {
		//get specific opened category editor
		IEditorPart activeEditor = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
				.getActiveEditor();
		CategoryEditor specificEditor = (CategoryEditor) activeEditor;
		
		if (event instanceof ScrollEvent) {
			LOGGER.log(Level.INFO,"Scroll event performed on category table");
		} else if (event instanceof StructuralRefreshEvent) {
			setDirtyAfterDataUpdate();
		}
		if (event instanceof CellSelectionEvent) {
			performCellSelectionAction(event, specificEditor);

		}
		if (event instanceof RowSelectionEvent) {
			performRowSelectionAction(event);

		}
	}

	/**
	 * @param event
	 */
	private void performRowSelectionAction(ILayerEvent event) {
		rowEvent = (RowSelectionEvent) event;
		
		rowForFindInModel = natTable.getRowIndexByPosition(rowEvent.getRowPositionToMoveIntoViewport());
		selDataObj = (String) this.createNatTable.getJsonDataProvider()
				.getDataValue(CreateNatTable.colNameIdx, rowForFindInModel);

		// column index for find in model after row selection event
		columnfindInModel = 1;
		// Set delete row enable/disable

		if (selDataObj != null && !selDataObj.trim().isEmpty()) {

			btnFindInModel.setEnabled(true);
			if (natTable.getMenu() != null) {
				natTable.getMenu().getItem(ApplicationConstant.FINDINMODELIDX).setEnabled(true);
				natTable.getMenu().getItem(ApplicationConstant.DELDATAOBJIDX).setEnabled(true);

			}
		} else {
			btnFindInModel.setEnabled(false);
			if (natTable.getMenu() != null) {
				natTable.getMenu().getItem(ApplicationConstant.FINDINMODELIDX).setEnabled(false);
				// natTable.getMenu().getItem(ApplicationConstant.DELETE_DATA_OBJECT_INDEX).setEnabled(false);
			}

		}
	}

	/**
	 * @param event
	 * @param specificEditor
	 */
	private void performCellSelectionAction(ILayerEvent event, CategoryEditor specificEditor) {
		editModeFlag = false;
		
		cellEvent = (CellSelectionEvent) event;
		int nameColPosition=-1;
		// Find IN Model Logic
		nameColPosition = createNatTable.getGridLayer()
					.getColumnIndexByPosition(cellEvent.getColumnPosition());
		columnfindInModel = cellEvent.getColumnPosition();
		
		int rowPosition = createNatTable.getGridLayer().getRowIndexByPosition(cellEvent.getRowPosition());

		Collection<ILayerCell> cells = cellEvent.getSelectionLayer().getSelectedCells();
		int colIndexSelLayer = -1;
		int rowIdxSelLayer = -1;
		for (ILayerCell cell : cells) {
			colIndexSelLayer = cell.getColumnIndex();
			rowIdxSelLayer = cell.getRowIndex();
		}

		if (null != categoryEdiObj.createNatTable.getSelectionLayer().getLastSelectedCellPosition()) {
			lastSelectedRow = categoryEdiObj.createNatTable.getSelectionLayer()
					.getLastSelectedCellPosition().rowPosition;
			lastSelCol = categoryEdiObj.createNatTable.getSelectionLayer()
					.getLastSelectedCellPosition().columnPosition;
		}

		if (nameColPosition != -1 || columnfindInModel != -1 || rowPosition != -1) {
			selDataObj = (String) createNatTable.getJsonDataProvider()
					.getDataValue(colIndexSelLayer, rowIdxSelLayer);
			if (colIndexSelLayer == CreateNatTable.colNameIdx && selDataObj != null
					&& !selDataObj.trim().isEmpty()) {
				btnFindInModel.setEnabled(true);
				if (natTable.getMenu() != null) {
					natTable.getMenu().getItem(ApplicationConstant.FINDINMODELIDX).setEnabled(true);
					natTable.getMenu().getItem(ApplicationConstant.DELDATAOBJIDX).setEnabled(true);
				}
				rowForFindInModel = rowIdxSelLayer;

			} else {
				btnFindInModel.setEnabled(false);
				if (natTable.getMenu() != null) {
					natTable.getMenu().getItem(ApplicationConstant.FINDINMODELIDX).setEnabled(false);
					// natTable.getMenu().getItem(ApplicationConstant.DELETE_DATA_OBJECT_INDEX).setEnabled(false);
				}
			}
		} else {
			btnFindInModel.setEnabled(false);
			if (natTable.getMenu() != null) {
				natTable.getMenu().getItem(ApplicationConstant.FINDINMODELIDX).setEnabled(false);
				// natTable.getMenu().getItem(ApplicationConstant.DELETE_DATA_OBJECT_INDEX).setEnabled(false);
			}
		}

		// Copy Paste Logic
		if (cellEvent.getSelectionLayer().getSelectedRowCount() > 1) {
			// DO Nothing
			LOGGER.log(Level.INFO, "Selected row count more than 1");				
		} else {
			rowIndex = cellEvent.getRowPosition();
		}

		if (cellEvent.getSelectionLayer().getSelectedColumnPositions().length > 1) {
			// Do Nothing
			LOGGER.log(Level.INFO, "Selected column positions more than 1");	
		} else {
			colIndex = cellEvent.getColumnPosition();
		}
		if (CopyAction.copyFlag == 1) {
			ApplicationActionBarAdvisor.getInstance().pasteAction.setEnabled(true);
		}
		ApplicationActionBarAdvisor.getInstance().cutAction.setEnabled(true);
		ApplicationActionBarAdvisor.getInstance().copyAction.setEnabled(true);
		ApplicationActionBarAdvisor.getInstance().deleteAction.setEnabled(true);
		selectedCells = cellEvent.getSelectionLayer().getSelectedCells();
		
		//Handled resolve inconsistency dialog close issue
		if(specificEditor!=null && cellEvent.getRowPosition()!=-1 && cellEvent.getColumnPosition()!=-1) {
			//to get active specific category editor cell event
			setDirtyListenerData(specificEditor.cellEvent.getRowPosition(), specificEditor.cellEvent.getColumnPosition());
		}
	}

	@Override
	public void configureLayer(ILayer arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void configureRegistry(IConfigRegistry arg0) {
		bodyMenu = new PopupMenuBuilder(natTable).withMenuItemProvider(new IMenuItemProvider() {
			@Override
			public void addMenuItem(NatTable natTable, Menu popupMenu) {
				setMenuItemDetails(popupMenu);

			}

		}).build();

	}

	@Override
	public void configureUiBindings(UiBindingRegistry uiBindingRegistry) {

		uiBindingRegistry.registerMouseDownBinding(
				new MouseEventMatcher(SWT.NONE, GridRegion.BODY, MouseEventMatcher.RIGHT_BUTTON),
				new PopupMenuAction(this.bodyMenu) {

					@Override
					public void run(NatTable natTable, MouseEvent event) {
						int columnPosition = natTable.getColumnPositionByX(event.x);
						int rowPosition = natTable.getRowPositionByY(event.y);

						SelectionLayer selectionLayer = createNatTable.getSelectionLayer();
						int bodyRowPosition = LayerUtil.convertRowPosition(natTable, rowPosition, selectionLayer);

						if (!selectionLayer.isRowPositionFullySelected(bodyRowPosition)
								&& !selectionLayer.isRowPositionSelected(bodyRowPosition)) {
							natTable.doCommand(
									new SelectCellCommand(natTable, columnPosition, rowPosition, false, false));
						}

						super.run(natTable, event);
					}
				});

	}

	/**
	 * Method used to get saved data from Matlab
	 * 
	 * @param category
	 * @param componentName
	 * @throws MatlabCommunicatinException
	 */
	public JsonElement getSavedData(String componentName) {
		MatlabCommunicationDaoImpl matlabComm = new MatlabCommunicationDaoImpl();
		String matlabQuery = CreateMatlabRequest.createMatlabRequest(MatlabScriptConstant.LOADCOMPDATA,
				componentName, ApplicationConstant.EMPTY_STRING);
		JsonElement jsonElement = null;
		try {
			jsonElement = matlabComm.executeMatlabRequest(matlabQuery);
		} catch (MatlabCommunicatinException e) {
			MessageDialog.openConfirm(new Shell(), "Error Message", e.getMessage());
		}

		if (jsonElement.isJsonArray()) {
			for (JsonElement jsonElementArr : jsonElement.getAsJsonArray()) {

				JsonObject jsonObject = jsonElementArr.getAsJsonArray().get(0).getAsJsonObject();

				if ((jsonObject.get(MatlabQueryConstant.CATEGORY).getAsString()).equals(getTitle())) {
					savedDataObjList = JsontoList.listInputs(jsonElementArr.getAsJsonArray());
				}
			}
		}

		return jsonElement;
	}

	/**
	 * Method used to sort the copied data before it could be pasted in Nattable
	 * 
	 * @param data
	 */
	public void sortDataBeforePaste(String data) {
		ImportProjectServiceImpl.pasteFlag = true;
		List<Object> natTblRowIdxList = new ArrayList<>();
		List<Object> tableCellList = new ArrayList<>();
		// Get the Active Editor
		IEditorPart activeEditor = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
				.getActiveEditor();
		CategoryEditor categoryEditor = (CategoryEditor) activeEditor;

		// Get the grid layer of focused nattable
		gridLayer = categoryEditor.createNatTable.getGridLayer();

		// Copied Data Array
		String[] copiedData = null;

		// Check if proper cell is selected
		if (rowIndex != 0 && colIndex != 0) {

			// Check if multiple rows are copied
			if (data.contains("\n")) {

				// Convert the copied data in Array
				copiedData = data.split("\n");

				// Get the last row index
				int lastRowIndex = categoryEditor.createNatTable.getGridLayer().getRowIndexByPosition(rowIndex);

				// Get the column index as per grid
				colIndex = gridLayer.getColumnIndexByPosition(colIndex);

				int initialColIndex = colIndex;

				int initalRowIndex = 0;

				// Multiple Row Iteration
				for (int i = 0; i < copiedData.length; i++) {
					CategoryAttributes catAttributes = natTableOperation.getCategoryForSelectedRow(rowIndex - 1,
							categoryEditor.createNatTable.getJsonDataProvider());
					if (rowIndex <= categoryEditor.createNatTable.getJsonDataProvider().getRowCount()) {
						natTblRowIdxList.add(new NatTableRowData(catAttributes, rowIndex - 1));
					}
					// Paste the data in cells
					pasteData(categoryEditor, colIndex, rowIndex, copiedData[i].split("\t"));
					rowIndex = rowIndex + 1;
					initalRowIndex = rowIndex;
					// Check if new row has to be added
					if (lastRowIndex == categoryEditor.createNatTable.getJsonDataProvider().getRowCount() - 1
							&& i != copiedData.length - 1) {

						// Reinitialize Instance Variables for adding new row
						natTable = categoryEditor.natTable;
						createNatTable = categoryEditor.createNatTable;
						natTableOperation = categoryEditor.natTableOperation;
						// Add New Row
						setAddDataObjectDetails(null);
						rowIndex = initalRowIndex;
						natTblRowIdxList
								.add(new NatTableRowIndex(createNatTable.getSelectionLayer(), lastRowIndex));
					}
					lastRowIndex = lastRowIndex + 1;
					colIndex = initialColIndex;
				}
				NatTableRowIndexArray natTblRowIdxArray = new NatTableRowIndexArray();
				natTblRowIdxArray.setNatTableRowIndexList(natTblRowIdxList);
				categoryEditor.undoEditStack.push(natTblRowIdxArray);
				ImportProjectServiceImpl.pasteFlag = false;

				categoryEditor.data = (String) categoryEditor.createNatTable.getJsonDataProvider()
						.getDataValue(categoryEditor.columnindex, categoryEditor.rowidx);
			}
			// if Single row is copied
			else {
				List<Integer> list = CreateNatTable.hideListMap.get(categoryEditor.getPartName());
				// Convert the copied data in Array
				copiedData = data.split("\t");

				// Get the column index as per grid
				colIndex = gridLayer.getColumnIndexByPosition(colIndex);

				for (int columnCnt = colIndex; columnCnt < categoryEditor.createNatTable.getJsonDataProvider()
						.getColumnCount(); columnCnt++) {
					if (!list.contains(columnCnt)) {
						tableCellList.add(new TableCell(rowIndex - 1, columnCnt, (String) categoryEditor.createNatTable
								.getJsonDataProvider().getDataValue(columnCnt, rowIndex - 1)));
					}
				}
				TableCellArray tableCellArray = new TableCellArray();
				tableCellArray.setTableCellList(tableCellList);
				// Paste the data
				pasteData(categoryEditor, colIndex, rowIndex, copiedData);

				categoryEditor.undoEditStack.push(tableCellArray);
				ImportProjectServiceImpl.pasteFlag = false;
				categoryEditor.data = (String) categoryEditor.createNatTable.getJsonDataProvider()
						.getDataValue(categoryEditor.columnindex, categoryEditor.rowidx);
			}
			// Refresh Nattable after paste
			categoryEditor.natTable.refresh();
			setDirty(true);
			rowIndex = 0;
			colIndex = 0;
			ApplicationActionBarAdvisor.getInstance().pasteAction.setEnabled(false);
		}
	}

	/**
	 * Method used to paste the data in nattable
	 * 
	 * @param categoryEditor
	 * @param column
	 * @param row
	 * @param data
	 */
	public void pasteData(CategoryEditor categoryEditor, int column, int row, String[] data) {
		//changed for PMD
		int rowVal = row;
		ImportProjectServiceImpl.pasteFlag = true;
		// Get the row index as per grid
		rowVal = gridLayer.getRowIndexByPosition(rowVal);
		categoryEditor.editRowLists.add(rowVal);
		// Newly added row
		if (rowVal == -1) {
			rowVal = categoryEditor.createNatTable.getJsonDataProvider().getRowCount() - 1;
		}

		List<Integer> list = CreateNatTable.hideListMap.get(categoryEditor.getPartName());

		// Copied Array data index
		int dataIndex = 0;

		for (int columnIdx = column; columnIdx < categoryEditor.createNatTable.getJsonDataProvider()
				.getColumnCount(); columnIdx++) {

			// if no copied data exist
			if (dataIndex == data.length) {
				break;
			}
			// Check if index is not equal to hidden column index
			else if (!list.contains(columnIdx)) {

				// Paste the data
				categoryEditor.createNatTable.getJsonDataProvider().setDataValue(columnIdx, rowVal, data[dataIndex]);
				dataIndex += 1;
			}
		}
	}

	/**
	 * Method used to open table editor for value when value cell is selected
	 * 
	 * @param selectedRowIndex
	 * @param tableData
	 */
	private void openValueTableEditor(int selColIndex, int selectedRowIndex) {

		ViewUtil.showHideView(ViewIDConstant.TABLE_EDITOR, false);
		GridData viewerGrid = new GridData();
		viewerGrid.horizontalSpan = 2;
		viewerGrid.heightHint = 350;
		viewerGrid.horizontalAlignment = GridData.FILL;
		viewerGrid.verticalAlignment = GridData.FILL / 2;
		viewerGrid.verticalSpan = GridData.FILL / 2;
	//	ProjectExplorerView.viewer.getControl().setLayoutData(viewerGrid);
		TableEditiorView.category = getTitle();
		TableEditiorView.rowIndex = selectedRowIndex;
		TableEditiorView.columnIndex = selColIndex;
		TableEditiorView.dimension = generateDimension(selectedRowIndex);
		TableEditiorView.oldTableValue = (String) createNatTable.getJsonDataProvider().getDataValue(selColIndex,
				selectedRowIndex);
		ViewUtil.showHideView(ViewIDConstant.TABLE_EDITOR, true);
	}

	/**
	 * Method used to move the data to clipboard
	 */
	public void moveDatatoClipboard() {
		ImportProjectServiceImpl.pasteFlag = true;
		List<Object> tableCellList = new ArrayList<>();
		// Get the active editor
		IEditorPart activeEditor = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
				.getActiveEditor();
		CategoryEditor categoryEditor = (CategoryEditor) activeEditor;
		// Copy the data to clipboard
		categoryEditor.natTable
				.doCommand(new CopyDataToClipboardCommand("\t", "\n", categoryEditor.natTable.getConfigRegistry()));

		// Set the selected cells to NULL
		for (ILayerCell iLayerCell : selectedCells) {
			categoryEditor.editRowLists.add(iLayerCell.getRowIndex());
			tableCellList.add(new TableCell(iLayerCell.getRowIndex(), iLayerCell.getColumnIndex(),
					(String) categoryEditor.createNatTable.getJsonDataProvider()
							.getDataValue(iLayerCell.getColumnIndex(), iLayerCell.getRowIndex())));
			categoryEditor.createNatTable.getJsonDataProvider().setDataValue(iLayerCell.getColumnIndex(),
					iLayerCell.getRowIndex(), "");
			categoryEditor.natTable.refresh();
			categoryEditor.data = "";
		}

		TableCellArray tableCellArray = new TableCellArray();
		tableCellArray.setTableCellList(tableCellList);
		cutList.addAll(tableCellList);
		categoryEditor.undoEditStack.push(tableCellArray);

		undoRedoOperation.makeUndoRedoEnableDisable(categoryEditor.undoEditStack,
				categoryEditor.redoEditorStack);

		saveOperation.makeSaveEnableDisable(categoryEditor);
		ImportProjectServiceImpl.pasteFlag = false;

	}

	/**
	 * Method used to close table editor if opened
	 */
	private void closeValueTableEditor() {
		try {
			IViewPart view = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
					.findView(ViewIDConstant.TABLE_EDITOR);

			if (view != null && (TableEditiorView.columnIndex != CreateNatTable.colValIdx
					|| TableEditiorView.columnIndex != CreateNatTable.colIniValIdx)) {
				ViewUtil.showHideView(ViewIDConstant.TABLE_EDITOR, false);
			}

		} catch (Exception e) {
			MessageDialog.openConfirm(new Shell(), "Error Message", "Error while Closing Table Editor");
		}
	}

	/**
	 * Method used to get the selected cells for rename data object(s) functionality
	 * 
	 * @return
	 */
	public List<String> getObjectsToRename() {
		List<String> objToBeRenamed = new ArrayList<>();

		Collection<ILayerCell> selectedCells = createNatTable.getSelectionLayer().getSelectedCells();

		for (ILayerCell cell : selectedCells) {
			if (cell.getColumnIndex() == CreateNatTable.colNameIdx) {
				objToBeRenamed.add((String) cell.getDataValue());
				cellDataMap.put(cell, (String) cell.getDataValue());
			}
		}
		return objToBeRenamed;

	}

	/**
	 * Method used to display new data objects in nattable after resolve
	 * inconsistency using model
	 * 
	 * @param addObjectsAfterResolveList
	 * @param categoryName
	 */
	public void displayNewObjectsAfterResolve(CategoryAttributes addObjResList, String categoryName) {

		natTableOperation.addDataObjectsToResolveIncFrmModel(categoryEdiObj.getParent(),
				createNatTable.getJsonDataProvider().getRowCount(), createNatTable, natTable, newAddedRowList,
				addObjResList);

	}
	
	/**
	 * Method used to display new data objects in nattable after resolve
	 * inconsistency using Excel sheet
	 * 
	 * @param addObjectsAfterResolveList
	 * @param categoryName
	 */
	public void displayNewObjectsAfterResolveExcel(CategoryAttributes addObjResList, String categoryName) {

		natTableOperation.addDataObjectsToResolveIncFrmExcel(categoryEdiObj.getParent(),
				createNatTable.getJsonDataProvider().getRowCount(), createNatTable, natTable, newAddedRowList,
				addObjResList);

	}
	
	/**
	 * Method used to add configurations for natTable for newly added objects after
	 * resolve inconsistency
	 */
	public void addNatTableConfigurationForAddResolve(String categoryName, String componentName, String category,
			List<String> dataObjectList, CategoryAttributes object, List<CategoryAttributes> newResolveObjList) {
		if (DataDictionaryApplication.getApplication().isSearchedHighLight()) {
			
			IConfigLabelAccumulator addLblAccum = new IConfigLabelAccumulator() {
				
				@Override
				public void accumulateConfigLabels(LabelStack configLabels, int columnPosition, int rowPosition) {

					for (int i = 0; i < dataObjectList.size(); i++) {

						searchedIndex = DataDictionaryUtil.searchIndex(dataObjectList.get(i), componentName, category,
								createNatTable.getJsonDataProvider().getList());
						int rowIndex = createNatTable.getDataLayer().getRowIndexByPosition(rowPosition);
						if (rowIndex == searchedIndex) {
							//ResolveInconsistencyServiceImpl.resolveAddList.add(object);
							//for filling list of data objects from excel in sldd
							//newResolveObjList.add(object);
							configLabels.addLabel(HIGHLIGHTLBL);
						}
					}
				}
			};
			createNatTable.getSelectionLayer().setConfigLabelAccumulator(addLblAccum);
			DataDictionaryApplication.getApplication().setSearchedHighLight(false);
			
		}
		this.natTable.addConfiguration(this);	
		//this.natTable.configure();
	}

	/**
	 * Used to remove highlighted labels from the table
	 */
	public void removeNatTableConfigurationForAddResolve() {
		IConfigLabelAccumulator addLblAccum = new IConfigLabelAccumulator() {

			@Override
			public void accumulateConfigLabels(LabelStack configLabels, int columnPosition, int rowPosition) {
				configLabels.removeLabel(HIGHLIGHTLBL);
			}
		};
		createNatTable.getSelectionLayer().setConfigLabelAccumulator(addLblAccum);

		this.natTable.addConfiguration(this);
	//	this.natTable.configure();
		this.natTable.redraw();
	}

	/**
	 * Method used to set the data for new row and display in natTbale
	 */
	public void updateAddedDataObjectDetails(CategoryAttributes object) {
		int rowPosition = natTable.getRowCount();
		rowPosition = createNatTable.getJsonDataProvider().getRowCount();
		List<Object> tableCellList = new ArrayList<>();
		List<Integer> list = CreateNatTable.hideListMap.get(categoryEdiObj.getPartName());
		
		for (int columnCnt = colIndex; columnCnt < categoryEdiObj.createNatTable.getJsonDataProvider()
				.getColumnCount(); columnCnt++) {
			if (!list.contains(columnCnt)) {
				tableCellList.add(new TableCell(rowPosition - 1, columnCnt, (String) categoryEdiObj.createNatTable
						.getJsonDataProvider().getDataValue(columnCnt, rowPosition - 1)));
			}
		}
		TableCellArray tableCellArray = new TableCellArray();
		tableCellArray.setTableCellList(tableCellList);
		if (!ImportProjectServiceImpl.pasteFlag) {
		//	editorStackForUndo.push(new TableCell(rowPosition-1, 2, (String)createNatTable.getJsonDataProvider().getDataValue(2, rowPosition-1)));
			
			undoEditStack.push(tableCellArray);
		}
		newRowIndex = rowPosition;
		// addedRowLists.add(rowPosition-1);
		String categoryName = getTitle();
		natTableOperation.updateNewRowInNatTable(newRowIndex - 1, createNatTable, natTable, newAddedRowList,
				categoryName, object);

		natTableOperation.setFocusOnNewRow(natTable.getRowCount(), createNatTable, natTable, newRowIndex - 1);

		setDirty(true);

		updatDataObjList = createNatTable.getCategoryList();

		undoRedoOperation.makeUndoRedoEnableDisable(undoEditStack, redoEditorStack);

		saveOperation.makeSaveEnableDisable(categoryEdiObj);
	}
	
	/**
	 * Method used to update unit symbol after focus lost
	 * @param selColIndex
	 */
	private void changeUnitDrpDwnVal(int selColIndex) {

		if (selColIndex == CreateNatTable.colDimIdx || 
				selColIndex == CreateNatTable.colBaseTyIdx ||
				selColIndex == CreateNatTable.colDescIdx || 
				selColIndex == CreateNatTable.colDimIdx ||
				selColIndex == CreateNatTable.colIniValIdx ||
				selColIndex == CreateNatTable.colNameIdx || 
				selColIndex == CreateNatTable.colOffIdx ||
				selColIndex == CreateNatTable.colSlopIdx ||
				selColIndex == CreateNatTable.colValIdx || 
				selColIndex == CreateNatTable.colMinIdx || 
				selColIndex == CreateNatTable.colMaxIdx ||
				selColIndex == CreateNatTable.colUnitIdx) {

			String unitSym = "";
			for(int i=0;i<createNatTable.getJsonDataProvider().getRowCount();i++) {
				String unitColumnData = (String) createNatTable.getJsonDataProvider()
						.getDataValue(CreateNatTable.colUnitIdx, i);
				if(unitColumnData != null && unitColumnData.contains(":")) {
					unitSym = unitColumnData.split(" : ")[0];
					categoryEdiObj.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colUnitIdx,
							i, unitSym);
				}
				
			}
			
			
			
			
		} 
	}
	
}
