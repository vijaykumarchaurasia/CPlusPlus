package com.navistar.datadictionary.ui.editors;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.layout.GridDataFactory;
import org.eclipse.nebula.widgets.nattable.NatTable;
import org.eclipse.nebula.widgets.nattable.config.AbstractRegistryConfiguration;
import org.eclipse.nebula.widgets.nattable.config.AbstractUiBindingConfiguration;
import org.eclipse.nebula.widgets.nattable.config.CellConfigAttributes;
import org.eclipse.nebula.widgets.nattable.config.DefaultNatTableStyleConfiguration;
import org.eclipse.nebula.widgets.nattable.config.IConfigRegistry;
import org.eclipse.nebula.widgets.nattable.coordinate.Range;
import org.eclipse.nebula.widgets.nattable.grid.GridRegion;
import org.eclipse.nebula.widgets.nattable.layer.LabelStack;
import org.eclipse.nebula.widgets.nattable.layer.LayerUtil;
import org.eclipse.nebula.widgets.nattable.layer.cell.IConfigLabelAccumulator;
import org.eclipse.nebula.widgets.nattable.selection.SelectionLayer;
import org.eclipse.nebula.widgets.nattable.selection.command.SelectCellCommand;
import org.eclipse.nebula.widgets.nattable.selection.config.DefaultSelectionBindings;
import org.eclipse.nebula.widgets.nattable.style.CellStyleAttributes;
import org.eclipse.nebula.widgets.nattable.style.DisplayMode;
import org.eclipse.nebula.widgets.nattable.style.Style;
import org.eclipse.nebula.widgets.nattable.style.theme.ModernNatTableThemeConfiguration;
import org.eclipse.nebula.widgets.nattable.style.theme.ThemeConfiguration;
import org.eclipse.nebula.widgets.nattable.ui.binding.UiBindingRegistry;
import org.eclipse.nebula.widgets.nattable.ui.matcher.KeyEventMatcher;
import org.eclipse.nebula.widgets.nattable.ui.matcher.MouseEventMatcher;
import org.eclipse.nebula.widgets.nattable.ui.menu.IMenuItemProvider;
import org.eclipse.nebula.widgets.nattable.ui.menu.PopupMenuAction;
import org.eclipse.nebula.widgets.nattable.ui.menu.PopupMenuBuilder;
import org.eclipse.nebula.widgets.nattable.util.GUIHelper;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.ui.PlatformUI;

import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.IconsPathConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.customexception.EditorInitilizationException;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.model.CategoryAttributesIo;
import com.navistar.datadictionary.service.UseThisObjectService;
import com.navistar.datadictionary.serviceimpl.EditorServiceImpl;
import com.navistar.datadictionary.serviceimpl.ExcelImportExportServiceImpl;
import com.navistar.datadictionary.serviceimpl.UseThisObjectServiceImpl;
import com.navistar.datadictionary.ui.nattable.CreateNatTable;
import com.navistar.datadictionary.ui.nattable.NatTableOperation;
import com.navistar.datadictionary.ui.views.ActivityLogView;
import com.navistar.datadictionary.util.DataDictionaryUtil;
//import com.navistar.datadictionary.util.FontStylingThemeConfiguration;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Class used for ResolveInconAttributesEditor
 * @author JAYSHRIVISHB
 *
 */
public class ResolveInconAttributesEditor extends AbstractBaseEditor{

	/** Used to get the Category Editor ID */
	public static final String INCON_ATTR_ID = ApplicationConstant.RESOLVEINATTRID;

	/** Used to get the deleted row list */
	public Set<Integer> deletedRowLists;
	
	public Set<Integer> useThisRowLists;

	/** Used to create the nat table service */
	private CreateNatTable createNatTable;

	/** Used to access nat table operations */
	private NatTableOperation natTableOperation;

	private static final String FOO_LABEL = "FOO";

	/** Search Index */
	private int searchedIndex;
	
	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(ResolveInconAttributesEditor.class);

	/**
	 *  Method used to create the Resolve In-consistency Attributes Editor with its default setting.
	 */
	@Override
	protected void createPartControl2(Composite parent) {

		Image windowTitleImage = new Image(PlatformUI.getWorkbench().getDisplay(), ResolveInconAttributesEditor.class.getResourceAsStream(IconsPathConstant.COMMON_WINDOW));
		this.setTitleImage(windowTitleImage);
		natTableOperation = new  NatTableOperation();
		createNatTable = new CreateNatTable();

		IOCompatibilityEditorInput inputEditor = (IOCompatibilityEditorInput) this.getEditorInput();
		parent.setLayout(new GridLayout(2, false));

		List<CategoryAttributesIo> ioCompList = inputEditor.getIOCompatibilityList();
		String dataObject = inputEditor.getDataObject();
		String componentName = inputEditor.getComponentName();
		String categoryName = inputEditor.getCategoryName();
		searchedIndex = DataDictionaryUtil.searchIndexIo(dataObject,componentName,categoryName, ioCompList);
		NatTable natTable = createNatTable.displayNatTableIO(parent, ioCompList);	
		
		final ThemeConfiguration fontTheme = new ModernNatTableThemeConfiguration();
		natTable.setTheme(fontTheme);
		// Custom label "FOO" for cell at column, row index (1, 5)
		IConfigLabelAccumulator cellLbllAcc = new IConfigLabelAccumulator() {
			@Override
			public void accumulateConfigLabels(LabelStack configLabels,
					int columnPosition, int rowPosition) {

				int rowIndex = createNatTable.getDataLayer() .getRowIndexByPosition(rowPosition);

				if (rowIndex == searchedIndex) {
					configLabels.addLabel(FOO_LABEL);               	
				}
			}
		};
		createNatTable.getDataLayer().setConfigLabelAccumulator(cellLbllAcc);

		//Add default style configuration to the NAT table
		natTable.addConfiguration(new DefaultNatTableStyleConfiguration());

		// Custom style for label "FOO"
		natTable.addConfiguration(new AbstractRegistryConfiguration() {
			@Override
			public void configureRegistry(IConfigRegistry configRegistry) {
				Style cellStyle = new Style();
				cellStyle.setAttributeValue(CellStyleAttributes.BACKGROUND_COLOR,  GUIHelper.getColor(new RGB(135, 206, 250)));
				configRegistry.registerConfigAttribute(CellConfigAttributes.CELL_STYLE, cellStyle,  DisplayMode.NORMAL, FOO_LABEL);
			}
		});

		// Add UI Binding Configuration to the NAT table
		natTable.addConfiguration(new AbstractUiBindingConfiguration() {
			private final Menu bodyMenu = new PopupMenuBuilder(natTable).withMenuItemProvider(new IMenuItemProvider() {
				@Override
				public void addMenuItem(NatTable natTable, Menu popupMenu) {
					
						MenuItem useThisObj = new MenuItem(popupMenu, SWT.PUSH);
						useThisObj.setText("Use this data object");
						useThisObj.setEnabled(true);

						useThisObj.addSelectionListener(new SelectionAdapter() {
							@Override
							public void widgetSelected(SelectionEvent event) {
								performResolveUseThisObj();
							}

						});
					} 

				
			}).build();

			/**
			 * Method used to configure UI Binding for the NAT table.
			 * @param uiBindingRegistry
			 */
			@Override
			public void configureUiBindings(UiBindingRegistry uiBindingRegistry) {
				uiBindingRegistry.registerMouseDownBinding(
						new MouseEventMatcher(SWT.NONE, GridRegion.BODY, MouseEventMatcher.RIGHT_BUTTON),
						new PopupMenuAction(this.bodyMenu) {

							@Override
							public void run(NatTable natTable, MouseEvent event) {
								int columnPosition = natTable.getColumnPositionByX(event.x);
								int rowPosition = natTable.getRowPositionByY(event.y);

								SelectionLayer selectionLayer = createNatTable.getSelectionLayer();

								int bodyRowPosition = LayerUtil.convertRowPosition(natTable, rowPosition,	selectionLayer);

								if (!selectionLayer.isRowPositionFullySelected(bodyRowPosition)
										&& !selectionLayer.isRowPositionSelected(bodyRowPosition)) {
									natTable.doCommand(	new SelectCellCommand(natTable, columnPosition, rowPosition, false, false));
								}
								super.run(natTable, event);
							}
						});
			}
		});
		natTable.addConfiguration(new CustomSelectionConfig());
		createNatTable.getSelectionLayer().addConfiguration(new CustomSelectionConfig());
		natTable.configure();
		GridDataFactory.fillDefaults().grab(true, true).applyTo(natTable);
		
	}

	class CustomSelectionConfig extends DefaultSelectionBindings{
		@Override
		public void configureUiBindings(UiBindingRegistry uiBindingRegistry) {
			removeMultipleSelectionBinding(uiBindingRegistry);

		}
	}

	/**
	 * Method used to remove the multiple row/cell selection from I/O Compatibility editor for delete
	 * operation
	 * @param uiBindingRegistry
	 */
	protected void removeMultipleSelectionBinding(UiBindingRegistry uiBindingRegistry) {        
		//remove multiple selection using ctrl and shift key
		uiBindingRegistry.unregisterMouseDownBinding(MouseEventMatcher.bodyLeftClick(SWT.MOD1));
		uiBindingRegistry.unregisterMouseDownBinding(MouseEventMatcher.bodyLeftClick(SWT.MOD2));
		uiBindingRegistry.unregisterMouseDownBinding(MouseEventMatcher.bodyLeftClick(SWT.MOD2 | SWT.MOD1));
		//remove multiple selection using drag mode
		uiBindingRegistry.unregisterMouseDragMode(MouseEventMatcher.bodyLeftClick(SWT.NONE));
		uiBindingRegistry.unregisterMouseDragMode(MouseEventMatcher.bodyLeftClick(SWT.MOD2));
		uiBindingRegistry.unregisterMouseDragMode(MouseEventMatcher.bodyLeftClick(SWT.MOD1));
		uiBindingRegistry.unregisterMouseDragMode(MouseEventMatcher.bodyLeftClick(SWT.MOD2 | SWT.MOD1));
		//remove ctrl+A key binding
		uiBindingRegistry.unregisterKeyBinding(new KeyEventMatcher(SWT.MOD1, 'a'));
		//remove multiple row selection
		uiBindingRegistry.unregisterMouseDownBinding(MouseEventMatcher.rowHeaderLeftClick(SWT.NONE));
		uiBindingRegistry.unregisterMouseDownBinding(MouseEventMatcher.rowHeaderLeftClick(SWT.MOD2));
		uiBindingRegistry.unregisterMouseDownBinding(MouseEventMatcher.rowHeaderLeftClick(SWT.MOD1));
		uiBindingRegistry.unregisterMouseDownBinding(MouseEventMatcher.rowHeaderLeftClick(SWT.MOD2 | SWT.MOD1));
		//remove shift arrow bindings
		uiBindingRegistry.unregisterKeyBinding(new KeyEventMatcher(SWT.MOD2, SWT.ARROW_RIGHT));
		uiBindingRegistry.unregisterKeyBinding(new KeyEventMatcher(SWT.MOD2, SWT.ARROW_LEFT));
		uiBindingRegistry.unregisterKeyBinding(new KeyEventMatcher(SWT.MOD2, SWT.ARROW_UP));
		uiBindingRegistry.unregisterKeyBinding(new KeyEventMatcher(SWT.MOD2, SWT.ARROW_DOWN));
		//remove shift page up and shift page down bindings
		uiBindingRegistry.unregisterKeyBinding(new KeyEventMatcher(SWT.MOD2, SWT.PAGE_DOWN));
		uiBindingRegistry.unregisterKeyBinding(new KeyEventMatcher(SWT.MOD2, SWT.PAGE_UP));
		uiBindingRegistry.unregisterKeyBinding(new KeyEventMatcher(SWT.HOME, SWT.PAGE_DOWN));
		uiBindingRegistry.unregisterKeyBinding(new KeyEventMatcher(SWT.END, SWT.PAGE_DOWN)); 
		uiBindingRegistry.unregisterKeyBinding(new KeyEventMatcher(SWT.HOME, SWT.PAGE_UP));
		uiBindingRegistry.unregisterKeyBinding(new KeyEventMatcher(SWT.END, SWT.PAGE_UP));

		uiBindingRegistry.unregisterKeyBinding(new KeyEventMatcher(SWT.MOD1, SWT.CR));
		uiBindingRegistry.unregisterKeyBinding(new KeyEventMatcher(SWT.MOD2 | SWT.MOD1, SWT.CR));
	}

	/**
	 * Method used to show the input editor data.
	 */
	@Override
	public void showData() {
		// Displaying tab name
		this.setPartName("Resolve Inconsistency in Attributes");
	}


	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Object getAdapter(Class arg0) {
		return null;
	}



	@Override
	protected Control[] registryDirtyControls() {
		return new Control[0];
	}

	@Override
	public void doSave(IProgressMonitor monitor) {
		//do nothing
	}
	
	/**
	 * Method used to perform action after clicking on Use this object action
	 */
	private void performResolveUseThisObj() {
		UseThisObjectService useThisService = new UseThisObjectServiceImpl();
		useThisRowLists = new LinkedHashSet<>();
		for (Range r : createNatTable.getSelectionLayer().getSelectedRowPositions()) {
			for (int i = r.start; i < r.end; i++) {
				useThisRowLists.add(i);
			}
		}
		ArrayList<CategoryAttributes> useThisDataList = new ArrayList<>();
		for(int useThisRowIndex : useThisRowLists) {
			useThisDataList.add(natTableOperation.getCategoryForSelectedRow(useThisRowIndex,createNatTable.getJsonDataProviderIO()));
		}
		String warning="";
		String dataObjectName="";
		CategoryAttributes useObj = new CategoryAttributes();
		for(CategoryAttributes category : useThisDataList) {
			dataObjectName=category.getName();
			warning=category.getWarning();
			useObj = category;
		}
		
		useThisService.getObjectToUseForExcelSldd(dataObjectName,warning);
		
		if(UseThisObjectServiceImpl.useThisFlg) {
			try {
				refrshInconAttrAftrUseObj(useObj);
			} catch (EditorInitilizationException e) {
				LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			}
			UseThisObjectServiceImpl.useThisFlg=false;
			
		}
	}
	
	/**
	 * Method used to to remove inconsistent data objects from table after Use this object
	 * @param dataOfUseThisObj
	 * @throws EditorInitilizationException
	 */
	public void refrshInconAttrAftrUseObj(CategoryAttributes dataOfUseThisObj) throws EditorInitilizationException{
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [INFO]: Inconsistency of attributes resolved successfully");
			}
			IOCompatibilityEditorInput inputEditor = (IOCompatibilityEditorInput) this.getEditorInput();
			List<CategoryAttributesIo> usedList = inputEditor.getIOCompatibilityList();
			Iterator<CategoryAttributesIo> listIterator = usedList.iterator();						
			while(listIterator.hasNext()) {
				CategoryAttributes categoryObject = listIterator.next();
				if(categoryObject.getName().equals(dataOfUseThisObj.getName())) {
					listIterator.remove();
				}
			}
			/*JsonArray jsonArray = new JsonArray();
			JsonElement jsonElement = new JsonParser().parse(GsonUtil.provider().toJSON(usedList));
			jsonArray.add(jsonElement);*/
			
			//refresh view and editor
			//Application.inconAttrJsonElement = jsonElement;				
			new EditorServiceImpl().closeAllEditors();
			if(!usedList.isEmpty()) {
				new ExcelImportExportServiceImpl().openInconsistentAttributeEditor(usedList);
			}
			
			
		} 
	
}
