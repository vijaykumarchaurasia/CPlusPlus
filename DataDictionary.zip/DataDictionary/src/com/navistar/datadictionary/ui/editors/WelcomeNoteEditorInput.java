package com.navistar.datadictionary.ui.editors;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IPersistableElement;

import com.navistar.datadictionary.constant.ApplicationConstant;
/**
 * This class is used for a Welcome note editor
 * to send the Welcome data as an Input.
 * @author nikitak1
 *
 */
public class WelcomeNoteEditorInput implements IEditorInput{
	
	/** Welcome note */
	private String text = ApplicationConstant.WELCOME_NOTE_TEXT;
	
	/**
	 * Constructor
	 */
	public WelcomeNoteEditorInput() {
	}
	
	@Override
	public Object getAdapter(@SuppressWarnings("rawtypes") Class arg0) {
		return text;
	}
	/**
	 * Returns whether the editor input exists
	 */
	@Override
	public boolean exists() {
		return false;
	}
	/**
	 * Returns the image descriptor for this input.
	 */
	@Override
	public ImageDescriptor getImageDescriptor() {
		return null;
	}
	/**
	 * Returns the name of this editor input for display purposes.
	 */
	@Override
	public String getName() {
		return text;
	}
	/**
	 * Returns an object that can be used to save the state 
	 * of this editor input
	 */
	@Override
	public IPersistableElement getPersistable() {
		return null;
	}
	/**
	 * Returns the tool tip text for this editor input
	 */
	@Override
	public String getToolTipText() {
		return text;
	}

}
