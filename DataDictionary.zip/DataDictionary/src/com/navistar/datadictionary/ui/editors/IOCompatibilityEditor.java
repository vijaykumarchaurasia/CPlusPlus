package com.navistar.datadictionary.ui.editors;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.layout.GridDataFactory;
import org.eclipse.nebula.widgets.nattable.NatTable;
import org.eclipse.nebula.widgets.nattable.config.AbstractRegistryConfiguration;
import org.eclipse.nebula.widgets.nattable.config.CellConfigAttributes;
import org.eclipse.nebula.widgets.nattable.config.DefaultNatTableStyleConfiguration;
import org.eclipse.nebula.widgets.nattable.config.IConfigRegistry;
import org.eclipse.nebula.widgets.nattable.config.IConfiguration;
import org.eclipse.nebula.widgets.nattable.config.IEditableRule;
import org.eclipse.nebula.widgets.nattable.coordinate.Range;
import org.eclipse.nebula.widgets.nattable.edit.EditConfigAttributes;
import org.eclipse.nebula.widgets.nattable.edit.editor.TextCellEditor;
import org.eclipse.nebula.widgets.nattable.grid.GridRegion;
import org.eclipse.nebula.widgets.nattable.layer.ILayer;
import org.eclipse.nebula.widgets.nattable.layer.LabelStack;
import org.eclipse.nebula.widgets.nattable.layer.LayerUtil;
import org.eclipse.nebula.widgets.nattable.layer.cell.IConfigLabelAccumulator;
import org.eclipse.nebula.widgets.nattable.selection.SelectionLayer;
import org.eclipse.nebula.widgets.nattable.selection.command.SelectCellCommand;
import org.eclipse.nebula.widgets.nattable.selection.config.DefaultSelectionBindings;
import org.eclipse.nebula.widgets.nattable.style.CellStyleAttributes;
import org.eclipse.nebula.widgets.nattable.style.DisplayMode;
import org.eclipse.nebula.widgets.nattable.style.Style;
import org.eclipse.nebula.widgets.nattable.style.theme.ModernNatTableThemeConfiguration;
import org.eclipse.nebula.widgets.nattable.style.theme.ThemeConfiguration;
import org.eclipse.nebula.widgets.nattable.ui.binding.UiBindingRegistry;
import org.eclipse.nebula.widgets.nattable.ui.matcher.KeyEventMatcher;
import org.eclipse.nebula.widgets.nattable.ui.matcher.MouseEventMatcher;
import org.eclipse.nebula.widgets.nattable.ui.menu.IMenuItemProvider;
import org.eclipse.nebula.widgets.nattable.ui.menu.PopupMenuAction;
import org.eclipse.nebula.widgets.nattable.ui.menu.PopupMenuBuilder;
import org.eclipse.nebula.widgets.nattable.util.GUIHelper;
import org.eclipse.nebula.widgets.nattable.viewport.command.ShowRowInViewportCommand;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MenuDetectEvent;
import org.eclipse.swt.events.MenuDetectListener;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.PlatformUI;

import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.IconsPathConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.customexception.EditorInitilizationException;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.model.CategoryAttributesIo;
import com.navistar.datadictionary.service.EditorService;
import com.navistar.datadictionary.service.IOCompatibilityService;
import com.navistar.datadictionary.serviceimpl.CheckComponentInputsServiceimpl;
import com.navistar.datadictionary.serviceimpl.EditorServiceImpl;
import com.navistar.datadictionary.serviceimpl.IOCompatibilityServiceImpl;
import com.navistar.datadictionary.serviceimpl.OpenComponentServiceImpl;
import com.navistar.datadictionary.ui.nattable.CreateNatTable;
import com.navistar.datadictionary.ui.nattable.DeleteRowCommand;
import com.navistar.datadictionary.ui.nattable.NatTableOperation;
import com.navistar.datadictionary.ui.views.ActivityLogView;
import com.navistar.datadictionary.ui.views.CheckComponentInputsView;
import com.navistar.datadictionary.ui.views.IOCompatibilityView;
import com.navistar.datadictionary.util.DataDictionaryUtil;
//import com.navistar.datadictionary.util.FontStylingThemeConfiguration;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Class used for IOCompatibilityEditor
 * @author JAYSHRIVISHB
 *
 */
public class IOCompatibilityEditor extends AbstractBaseEditor
implements  IConfiguration{

	/** Used to get the Category Editor ID */
	public static final String EDITOR_ID = ApplicationConstant.IOCOMPTEDITID;

	/** Used to get the deleted row list */
	public Set<Integer> deletedRowLists;

	/** Used to create the Nat Table */
	//private NatTable natTable;	

	/** It points to current shell of display */
	private Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();

	/** Used to create the nat table service */
	private CreateNatTable createNatTable;

	/** Used to access nat table operations */
	private NatTableOperation natTableOperation;

	/** Used to acess editor service */
	private EditorService editorService;

	private static final String HIGHLIGHTLBL = "HightLight";

	/** Search Index */
	private int searchedIndex;
	
	/** Composite */
	public Composite parent;

	private IOCompatibilityEditorInput inputEditor;
	
	/** Used to create the Nat Table */
	private NatTable natTable;
	
	private List<CategoryAttributesIo> ioCompatList;
	
	/** pop-menu for natTable */
	private Menu bodyMenu;

	
	/**
	 * default constructor
	 */
	public IOCompatibilityEditor() {
		natTableOperation = new  NatTableOperation();
		createNatTable = new CreateNatTable();
		editorService = new  EditorServiceImpl();
	}
	
	/**
	 * Method used to get the composite
	 * 
	 * @return
	 */
	public Composite getParent() {
		return parent;
	}

	/**
	 * Method used to show the input editor data.
	 */
	@Override
	public void showData() {

		IOCompatibilityEditorInput inputEditor = (IOCompatibilityEditorInput) this.getEditorInput();
		// Displaying tab name
		this.setPartName(inputEditor.getName() == null ? "" : inputEditor.getName());
	}
	
	public void createUIComponent() {
		
		inputEditor = (IOCompatibilityEditorInput) this.getEditorInput();
		parent.setLayout(new GridLayout(2, false));

		natTable = createNatTable.displayNatTableIO(parent, inputEditor.getIOCompatibilityList());
		
		final ThemeConfiguration fontTheme = new ModernNatTableThemeConfiguration();
		natTable.setTheme(fontTheme);

		DefaultNatTableStyleConfiguration natTableConfig = new DefaultNatTableStyleConfiguration();
		natTable.addConfiguration(natTableConfig);
		natTable.addConfiguration(ioTableConfiguration());
		natTable.setSize(500, 200);
		GridData natTableData = new GridData(SWT.FILL, SWT.FILL, true, true);
		natTableData.horizontalSpan = 2;
		natTableData.heightHint = 200;
		natTableData.horizontalAlignment = GridData.FILL;
		natTable.setLayoutData(natTableData);

		this.natTable.addConfiguration(this);
		this.natTable.configure();
	}
	/**
	 *  Method used to create the I/O Compatibility editor with its default setting.
	 */
	@Override
	protected void createPartControl2(Composite parent) {

		Image windowTitleImage = new Image(PlatformUI.getWorkbench().getDisplay(), IOCompatibilityEditor.class.getResourceAsStream(IconsPathConstant.COMMON_WINDOW));
		this.setTitleImage(windowTitleImage);
		this.parent = parent;
		// Create UI Components
		createUIComponent();
		addNatTableConfiguration();
		
		natTable.addConfiguration(new CustomSelectionConfig());
		createNatTable.getSelectionLayer().addConfiguration(new CustomSelectionConfig());
		
		natTable.configure();
		GridDataFactory.fillDefaults().grab(true, true).applyTo(natTable);
		
	}
	
	class CustomSelectionConfig extends DefaultSelectionBindings{
		@Override
		public void configureUiBindings(UiBindingRegistry uiBindingRegistry) {
			removeMultipleSelectionBinding(uiBindingRegistry);

		}
	}
		
		/**
		 * Method used to add configurations for natTable
		 */
		public void addNatTableConfiguration() {

			ioCompatList = inputEditor.getIOCompatibilityList();
			String dataObject = inputEditor.getDataObject();
			String componentName = inputEditor.getComponentName();
			String categoryName = inputEditor.getCategoryName();
			searchedIndex = DataDictionaryUtil.searchIndexIo(dataObject,componentName,categoryName, ioCompatList);

			// Custom label "FOO" for cell at column, row index (1, 5)
			IConfigLabelAccumulator cellLblAccum = new IConfigLabelAccumulator() {
				@Override
				public void accumulateConfigLabels(LabelStack configLabels,
						int columnPosition, int rowPosition) {

					int rowIndex = createNatTable.getDataLayer() .getRowIndexByPosition(rowPosition);

					if (rowIndex == searchedIndex) {
						configLabels.addLabel(HIGHLIGHTLBL);               	
					}
				}
			};
			createNatTable.getDataLayer().setConfigLabelAccumulator(cellLblAccum);
			//searchedIndex = DataDictionaryUtil.searchIndex(dataObject,componentName,categoryName, ioCompatList);
			this.natTable.doCommand(new ShowRowInViewportCommand(this.createNatTable.getGridLayer().getBodyLayer(), searchedIndex));

		this.natTable.addConfiguration(this);
		this.natTable.configure();
		
		}
		
		public static AbstractRegistryConfiguration ioTableConfiguration() {

			return new AbstractRegistryConfiguration() {

				@Override
				public void configureRegistry(IConfigRegistry configRegistry) {
					Style cellStyle = new Style();
					cellStyle.setAttributeValue(CellStyleAttributes.BACKGROUND_COLOR,
							GUIHelper.getColor(new RGB(135, 206, 250)));
					configRegistry.registerConfigAttribute(CellConfigAttributes.CELL_STYLE, cellStyle, DisplayMode.NORMAL,
							HIGHLIGHTLBL);	
					
					configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE,
							IEditableRule.NEVER_EDITABLE);
					
					configRegistry.registerConfigAttribute(
							EditConfigAttributes.CELL_EDITOR,
							new TextCellEditor() {
								@Override
								public Text createEditorControl(Composite parent) {
									Text textControl = super.createEditorControl(parent);
									// disable context menu in Text field
									textControl.addMenuDetectListener(new MenuDetectListener() {
										@Override
										public void menuDetected(MenuDetectEvent event) {
											//event.doit = false;
										}
									});
									return textControl;
								}
							});
				}

			};
		}

		
	/**
	 * Method used to remove the multiple row/cell selection from I/O Compatibility editor for delete
	 * operation
	 * @param uiBindingRegistry
	 */
	protected void removeMultipleSelectionBinding(UiBindingRegistry uiBindingRegistry) {        
		//remove multiple selection using ctrl and shift key
		uiBindingRegistry.unregisterMouseDownBinding(MouseEventMatcher.bodyLeftClick(SWT.MOD1));
		uiBindingRegistry.unregisterMouseDownBinding(MouseEventMatcher.bodyLeftClick(SWT.MOD2));
		uiBindingRegistry.unregisterMouseDownBinding(MouseEventMatcher.bodyLeftClick(SWT.MOD2 | SWT.MOD1));
		//remove multiple selection using drag mode
		uiBindingRegistry.unregisterMouseDragMode(MouseEventMatcher.bodyLeftClick(SWT.NONE));
		uiBindingRegistry.unregisterMouseDragMode(MouseEventMatcher.bodyLeftClick(SWT.MOD2));
		uiBindingRegistry.unregisterMouseDragMode(MouseEventMatcher.bodyLeftClick(SWT.MOD1));
		uiBindingRegistry.unregisterMouseDragMode(MouseEventMatcher.bodyLeftClick(SWT.MOD2 | SWT.MOD1));
		//remove ctrl+A key binding
		uiBindingRegistry.unregisterKeyBinding(new KeyEventMatcher(SWT.MOD1, 'a'));
		//remove multiple row selection
		uiBindingRegistry.unregisterMouseDownBinding(MouseEventMatcher.rowHeaderLeftClick(SWT.NONE));
		uiBindingRegistry.unregisterMouseDownBinding(MouseEventMatcher.rowHeaderLeftClick(SWT.MOD2));
		uiBindingRegistry.unregisterMouseDownBinding(MouseEventMatcher.rowHeaderLeftClick(SWT.MOD1));
		uiBindingRegistry.unregisterMouseDownBinding(MouseEventMatcher.rowHeaderLeftClick(SWT.MOD2 | SWT.MOD1));
		//remove shift arrow bindings
		uiBindingRegistry.unregisterKeyBinding(new KeyEventMatcher(SWT.MOD2, SWT.ARROW_RIGHT));
		uiBindingRegistry.unregisterKeyBinding(new KeyEventMatcher(SWT.MOD2, SWT.ARROW_LEFT));
		uiBindingRegistry.unregisterKeyBinding(new KeyEventMatcher(SWT.MOD2, SWT.ARROW_UP));
		uiBindingRegistry.unregisterKeyBinding(new KeyEventMatcher(SWT.MOD2, SWT.ARROW_DOWN));
		//remove shift page up and shift page down bindings
		uiBindingRegistry.unregisterKeyBinding(new KeyEventMatcher(SWT.MOD2, SWT.PAGE_DOWN));
		uiBindingRegistry.unregisterKeyBinding(new KeyEventMatcher(SWT.MOD2, SWT.PAGE_UP));
		uiBindingRegistry.unregisterKeyBinding(new KeyEventMatcher(SWT.HOME, SWT.PAGE_DOWN));
		uiBindingRegistry.unregisterKeyBinding(new KeyEventMatcher(SWT.END, SWT.PAGE_DOWN)); 
		uiBindingRegistry.unregisterKeyBinding(new KeyEventMatcher(SWT.HOME, SWT.PAGE_UP));
		uiBindingRegistry.unregisterKeyBinding(new KeyEventMatcher(SWT.END, SWT.PAGE_UP));

		uiBindingRegistry.unregisterKeyBinding(new KeyEventMatcher(SWT.MOD1, SWT.CR));
		uiBindingRegistry.unregisterKeyBinding(new KeyEventMatcher(SWT.MOD2 | SWT.MOD1, SWT.CR));
	}
	/**
	 * This method is used to perform action after clicking on Delete Data Object
	 * context menu for category table.
	 */
	public void deleteDataObjectFromContextMenu() {
		boolean delDataDialogVal = MessageDialog.openConfirm(shell, ApplicationConstant.WARNING,
				MessageConstant.DELETE_DATA);
		if (delDataDialogVal) {
			deletedRowLists = new LinkedHashSet<>();
			for (Range r : createNatTable.getSelectionLayer().getSelectedRowPositions()) {
				for (int i = r.start; i < r.end; i++) {
					deletedRowLists.add(i);
				}
			}
			ArrayList<CategoryAttributes> deletedDataList = new ArrayList<>();
			for(int deletedRowIndex : deletedRowLists) {
				deletedDataList.add(natTableOperation.getCategoryForSelectedRow(deletedRowIndex,createNatTable.getJsonDataProvider()));
			}
			boolean delDataObjStatus = false;
			try {
				delDataObjStatus = editorService.deleteDataObjectsFromEditor(deletedDataList);
			} catch (MatlabCommunicatinException e) {
				MessageDialog.openConfirm(new Shell(), "Error Message", e.getMessage());
			}
			if (delDataObjStatus) {
				int rowCount = 0;
				for (int row : deletedRowLists) {
					createNatTable.getSelectionLayer().doCommand(new DeleteRowCommand(createNatTable.getSelectionLayer(), row - rowCount));
					rowCount++;
				}
				setDirty(false);

				IConfigLabelAccumulator cellLblAccum = new IConfigLabelAccumulator() {
					@Override
					public void accumulateConfigLabels(LabelStack configLabels,
							int columnPosition, int rowPosition) {

						int rowIndex = createNatTable.getDataLayer() .getRowIndexByPosition(rowPosition);
						if (rowIndex == searchedIndex) {
							configLabels.removeLabel(HIGHLIGHTLBL);
							//natTable.doCommand(new ShowRowInViewportCommand(createNatTable.getGridLayer().getBodyLayer(), searchedIndex));
						}
					}
				};
				createNatTable.getDataLayer().setConfigLabelAccumulator(cellLblAccum);

				if(IOCompatibilityView.getIOCompatibilityViewInstance() != null) {
					String compName="";
					String delDataObjName="";
					IOCompatibilityService ioCompatService = new IOCompatibilityServiceImpl();
					for(CategoryAttributes category : deletedDataList) {
						ioCompatService.updateIOCompatibilityData(category.getWarning(), category.getComponent(), category.getName(), category.getCategory());
						delDataObjName=category.getName();
						compName=category.getComponent();
					}
					if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
						ActivityLogView.activityLog.append("\n [INFO]: Below Data Object Deleted Successfully:");
						ActivityLogView.activityLog.append("\n ===========================================");
						ActivityLogView.activityLog.append("\n " + compName +" : " + delDataObjName);
					}
				}

				if(CheckComponentInputsView.getCompInputsViewInstance() != null) {

					CheckComponentInputsServiceimpl checkCompInObj = new CheckComponentInputsServiceimpl();
					for(CategoryAttributes category : deletedDataList) {
						checkCompInObj.updateCompInputsData(category.getWarning(),  category.getComponent(), category.getName(), category.getCategory());
					}

					ViewUtil.closeView(ViewIDConstant.COMP_INPUTS);
					ViewUtil.showHideView(ViewIDConstant.COMP_INPUTS, true);
				}
				Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
				MessageDialog.openInformation(shell, ApplicationConstant.INFORMATION,MessageConstant.DELETE_SUCCESS);
			}
		}
		if(!deletedRowLists.isEmpty()) {
			deletedRowLists.clear();
		}
	}
	
	
	public void deleteDataObjectFromIOTable() {
		boolean delDataDialogVal = MessageDialog.openConfirm(shell, ApplicationConstant.WARNING,
				MessageConstant.DELETE_DATA);
		if (delDataDialogVal) {
			deletedRowLists = new LinkedHashSet<>();
			for (Range r : createNatTable.getSelectionLayer().getSelectedRowPositions()) {
				for (int i = r.start; i < r.end; i++) {
					deletedRowLists.add(i);
				}
			}
			ArrayList<CategoryAttributes> deletedDataList = new ArrayList<>();
			for(int deletedRowIndex : deletedRowLists) {
				deletedDataList.add(natTableOperation.getCategoryForSelectedRow(deletedRowIndex,createNatTable.getJsonDataProviderIO()));
			}
			boolean delDataObjStatus = false;
			try {
				delDataObjStatus = editorService.deleteDataObjectsFromEditor(deletedDataList);
			} catch (MatlabCommunicatinException e) {
				MessageDialog.openConfirm(new Shell(), "Error Message", e.getMessage());
			}
			if (delDataObjStatus) {
				int rowCount = 0;
				for (int row : deletedRowLists) {
					createNatTable.getSelectionLayer().doCommand(new DeleteRowCommand(createNatTable.getSelectionLayer(), row - rowCount));
					rowCount++;
				}
				setDirty(false);

				IConfigLabelAccumulator cellLblAccum = new IConfigLabelAccumulator() {
					@Override
					public void accumulateConfigLabels(LabelStack configLabels,
							int columnPosition, int rowPosition) {

						int rowIndex = createNatTable.getDataLayer() .getRowIndexByPosition(rowPosition);
						if (rowIndex == searchedIndex) {
							configLabels.removeLabel(HIGHLIGHTLBL);
							//natTable.doCommand(new ShowRowInViewportCommand(createNatTable.getGridLayer().getBodyLayer(), searchedIndex));
						}
					}
				};
				createNatTable.getDataLayer().setConfigLabelAccumulator(cellLblAccum);

				if(IOCompatibilityView.getIOCompatibilityViewInstance() != null) {
					String compName="";
					String delDataObjName="";
					IOCompatibilityService ioCompatService = new IOCompatibilityServiceImpl();
					for(CategoryAttributes category : deletedDataList) {
						ioCompatService.updateIOCompatibilityData(category.getWarning(), category.getComponent(), category.getName(), category.getCategory());
						delDataObjName=category.getName();
						compName=category.getComponent();
					}
					if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
						ActivityLogView.activityLog.append("\n [INFO]: Below Data Object Deleted Successfully:");
						ActivityLogView.activityLog.append("\n ===========================================");
						ActivityLogView.activityLog.append("\n " + compName +" : " + delDataObjName);
					}
				}

				if(CheckComponentInputsView.getCompInputsViewInstance() != null) {

					CheckComponentInputsServiceimpl checkCompInObj = new CheckComponentInputsServiceimpl();
					for(CategoryAttributes category : deletedDataList) {
						checkCompInObj.updateCompInputsData(category.getWarning(),  category.getComponent(), category.getName(), category.getCategory());
					}

					ViewUtil.closeView(ViewIDConstant.COMP_INPUTS);
					ViewUtil.showHideView(ViewIDConstant.COMP_INPUTS, true);
				}
				Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
				MessageDialog.openInformation(shell, ApplicationConstant.INFORMATION,MessageConstant.DELETE_SUCCESS);
			}
		}
		if(!deletedRowLists.isEmpty()) {
			deletedRowLists.clear();
		}
	}

	

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Object getAdapter(Class arg0) {
		return null;
	}



	@Override
	protected Control[] registryDirtyControls() {
		return new Control[0];
	}

	@Override
	public void doSave(IProgressMonitor monitor) {
		// doSave
	}


	/**
	 * Method is used to update the I/O Compatibility editor after deleting the data object
	 * @param warningName
	 * @param componentName
	 * @param categoryName
	 * @param objectName
	 * @param editors
	 */
	public void refreshIOCompatibilityEditor(String warningName, String componentName, String categoryName,
			String objectName) {

		//commented old code because this list had old data
	//	IOCompatibilityEditorInput inputEditor = (IOCompatibilityEditorInput) ioCompatEditor.getEditorInput();
	//	List<CategoryAttributesIo> ioCompatList = inputEditor.getIOCompatibilityList();
		
	//	int searchIndex = DataDictionaryUtil.searchIndexIo(objectName, componentName, categoryName,
	//		ioCompatList);


	//	createNatTable.getSelectionLayer().doCommand(new DeleteRowCommand(createNatTable.getSelectionLayer(), searchIndex));
	//	createNatTable.getDataLayer().setConfigLabelAccumulator(null);

	//	setDirty(false);
		

		// Closing all open editors
		new EditorServiceImpl().closeAllEditors();

		//reopen the I/O warning table
		String strWarning[] = warningName.split(":");

			List<CategoryAttributesIo> ioCompatList = IOCompatibilityView.getIOCompatibilityViewInstance().ioCompatMap.get(strWarning[1].trim());
			try {
				Collections.sort(ioCompatList, new SortByName());
				new OpenComponentServiceImpl().findAndOpenComponent(objectName, componentName, categoryName, ioCompatList);
			} catch (EditorInitilizationException e) {
				MessageDialog.openConfirm(new Shell(), "Error Message",
						"Error while filling I/O compatibility context menu");
			}
	
	}
	
	/**
	 * Method used to set the pop-up menu of natTable
	 * 
	 * @param popupMenu
	 */
	public void setMenuItemDetails(Menu popupMenu) {

		if (ioCompatList.get(0).getWarning().equals(ApplicationConstant.INCONSISTENT_IOS)
				|| ioCompatList.get(0).getWarning().equals(ApplicationConstant.DUPLICATE_OP)) {
			MenuItem deleteRow = new MenuItem(popupMenu, SWT.PUSH);
			deleteRow.setText(ApplicationConstant.BTNDELDATAOBJ);
			deleteRow.setEnabled(true);

			deleteRow.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent event) {
					deleteDataObjectFromIOTable();
				}

			});
		} else {
			return;
		}
		natTable.setMenu(popupMenu);
	}

	@Override
	public void configureLayer(ILayer arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void configureRegistry(IConfigRegistry arg0) {		
		bodyMenu = new PopupMenuBuilder(natTable).withMenuItemProvider(new IMenuItemProvider() {
			@Override
			public void addMenuItem(NatTable natTable, Menu popupMenu) {
				setMenuItemDetails(popupMenu);

			}

		}).build();

	}

	@Override
	public void configureUiBindings(UiBindingRegistry arg0) {

		arg0.registerMouseDownBinding(
				new MouseEventMatcher(SWT.NONE, GridRegion.BODY, MouseEventMatcher.RIGHT_BUTTON),
				new PopupMenuAction(this.bodyMenu) {

					@Override
					public void run(NatTable natTable, MouseEvent event) {
						int columnPosition = natTable.getColumnPositionByX(event.x);
						int rowPosition = natTable.getRowPositionByY(event.y);

						SelectionLayer selectionLayer = createNatTable.getSelectionLayer();
						int bodyRowPosition = LayerUtil.convertRowPosition(natTable, rowPosition, selectionLayer);

						if (!selectionLayer.isRowPositionFullySelected(bodyRowPosition)
								&& !selectionLayer.isRowPositionSelected(bodyRowPosition)) {
							natTable.doCommand(
									new SelectCellCommand(natTable, columnPosition, rowPosition, false, false));
						}

						super.run(natTable, event);
					}
				});

	}	

}

class SortByName implements Comparator<CategoryAttributes> {
	@Override
	public int compare(CategoryAttributes o1, CategoryAttributes o2) {
		// TODO Auto-generated method stub
		return o1.getName().compareTo(o2.getName());
	}
}
