package com.navistar.datadictionary.ui.editors;

import org.eclipse.core.commands.operations.IUndoContext;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.operations.UndoRedoActionGroup;
import org.eclipse.ui.part.EditorPart;

import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.other.DirtyListener;
import com.navistar.datadictionary.other.DirtyUtils;

/**
 * Abstract class used to initiate the editor, create the control part and set the dirty indicator.
 * 
 * @author VijayK13
 *
 */
public abstract class AbstractBaseEditor extends EditorPart {

	/** Dirty indicator flag */
	private boolean dirty;

	/** Undo context */
	IUndoContext undoContext;

	/** Undo Redo Action Group */
	UndoRedoActionGroup undoRedoActionGp;

	/**
	 * Method to initialize the Base Editor
	 * @param
	 */
	@Override
	public void init(IEditorSite site, IEditorInput input)
			throws PartInitException {
		setSite(site);
		setInput(input);

		IWorkbench workbench = PlatformUI.getWorkbench();
		IUndoContext myUndoContext= workbench.getOperationSupport().getUndoContext();
		undoRedoActionGp = new UndoRedoActionGroup(getSite(), myUndoContext, false);
		undoRedoActionGp.fillActionBars(getEditorSite().getActionBars());
	}

	/**
	 * Method used to initialize the dirty property.
	 */
	@Override
	public boolean isDirty() {
		return this.dirty;
	}

	/**
	 * Method used to set the dirty property.
	 * @param dirty
	 */
	public void setDirty(boolean dirty) {
		if (this.dirty != dirty) {
			this.dirty = dirty;

			// Notify PROP_DIRTY changes to Workbench.
			this.firePropertyChange(IEditorPart.PROP_DIRTY);
		}
	}

	/**
	 * This method is used to perform save action
	 */
	@Override
	public void doSaveAs() {
		//Nothing to clean-up
	}

	/**
	 * This method check save all action is allowed or not.
	 */
	@Override
	public boolean isSaveAsAllowed() {
		return false;
	}

	/**
	 * This method asks to set the focus on component. 
	 * Workbench call this method automatically.
	 */
	@Override
	public void setFocus() {
		// nothing to clean up
	}

	/**
	 * Method used to create the editor view part and initialize default properties.
	 */
	@Override
	public final void createPartControl(Composite parent) {
		this.createPartControl2(parent);

		this.showData();
		this.setDirty(false);
		this.firePropertyChange(ApplicationConstant.EDITORDATACHANGE);

		Control[] controls = this.registryDirtyControls();
		DirtyListener listener = new DirtyListenerImpl();
		DirtyUtils.registryDirty(listener, controls);
	}

	/** Method used to show editor data */
	public abstract void showData( );

	/** Method used to create the part control */
	protected abstract void createPartControl2(Composite parent);

	/** Method used to handle control change in the workbench
	 *  @return
	 */
	protected abstract Control[] registryDirtyControls();

	/**
	 *  Class to implement Dirty Listener Interface 
	 * @author vijayk13
	 *
	 */
	public class DirtyListenerImpl implements DirtyListener {

		/**
		 *  method used to Initialize the dirty property
		 */
		@Override
		public void fireDirty() {
			// If has any change, fire to Editor.
			AbstractBaseEditor.this.setDirty(true);
		}

	}
}