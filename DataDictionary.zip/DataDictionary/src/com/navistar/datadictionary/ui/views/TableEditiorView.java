package com.navistar.datadictionary.ui.views;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.TableEditor;
import org.eclipse.swt.events.MenuDetectEvent;
import org.eclipse.swt.events.MenuDetectListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.ViewPart;

import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.daoimpl.MatlabCommunicationDaoImpl;
import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.ui.nattable.CreateNatTable;

/**
 * Class used for creating table editor ViewPart in the existing workspace
 * 
 * @author JAYSHRIVISHB
 *
 */
public class TableEditiorView extends ViewPart {

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(MatlabCommunicationDaoImpl.class);
	
	/** Used to get the table editor id */
	public static final String TABLE_EDITOR_ID = ViewIDConstant.TABLE_EDITOR;

	/** Row Count Text */
	private Text rowCountText;

	/** Row Count Text */
	private Text columnCountText;

	/** row add button */
	private Button rowAddButton;

	/** row remove button */
	private Button rowRemoveButton;

	/** column remove button */
	private Button colRemoveButton;

	/** Table for values */
	private Table valueTable;

	/** value attribute */
	public static String oldTableValue = "";

	/** category name */
	public static String category = "";

	/** row index */
	public static int rowIndex;
	
	/** columnIndex */
	public static int columnIndex;

	/** row count of value table */
	private int rowCount;

	/** column count of value table */
	private int columnCount;

	/** Dimension */
	public static String dimension = "";
	
	/** Default Constructor */
	public TableEditiorView() {

	}

	/**
	 * This method is used to create table editor viewpart with its default
	 * setting
	 * 
	 * @param parent
	 */
	@Override
	public void createPartControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NONE);
		columnCount = 1;
		rowCount = 1;
	 
		Shell shell = container.getShell();
		createBasicUI(container, columnCount, rowCount);
		
		// enable/disable buttons depending on category, attribute and column row count
		enableDisableRowAddRemoveButton();
		enableDisableColumnAddRemoveButton();

		if (oldTableValue != null && !oldTableValue.equals("")) {
			loadTableWithOldData(parseValue(oldTableValue), rowCount, columnCount);
		}
		shell.open();
	}

	@Override
	public void setFocus() {
		// nothing to clean up
	}

	/**
	 * This method is overridden to un-check the table editor view option from
	 * the file menu
	 */
	@Override
	public void dispose() {
		//nothing to clean-up
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Object getAdapter(Class arg0) {

		return null;
	}
	
	/**
	 * Method used to create basic structure of table editor
	 * @param container
	 * @param columnCount
	 * @param rowCount
	 */
	private void createBasicUI(Composite container, int columnCount, int rowCount) {
		// Rows label
		Label rowLabel = new Label(container, SWT.NONE);
		rowLabel.setBounds(0, 10, 50, 20);
		rowLabel.setAlignment(SWT.CENTER);
		rowLabel.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, true, true, 1, 1));
		rowLabel.setText("Rows:");

		// Create a read-only text field for row count
		rowCountText = new Text(container, SWT.READ_ONLY | SWT.BORDER);
		rowCountText.setBounds(50, 10, 25, 20);
		rowCountText.setLayoutData(new GridData(GridData.FILL_BOTH));
		rowCountText.setText(Integer.toString(rowCount));

		// Columns label
		Label columnLabel = new Label(container, SWT.NONE);
		columnLabel.setBounds(145, 10, 55, 20);
		columnLabel.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, true, true, 1, 1));
		columnLabel.setText("Columns:");

		// Create a read-only text field for row count
		columnCountText = new Text(container, SWT.READ_ONLY | SWT.BORDER);
		columnCountText.setBounds(205, 10, 25, 20);
		columnCountText.setLayoutData(new GridData(GridData.FILL_BOTH));
		columnCountText.setText(Integer.toString(columnCount));

		rowAddButton = new Button(container, SWT.NONE);
		rowAddButton.setBounds(80, 10, 25, 20);
		rowAddButton.setText("+");

		rowRemoveButton = new Button(container, SWT.NONE);
		rowRemoveButton.setText("-");
		rowRemoveButton.setBounds(110, 10, 25, 20);
	
		/** column add button */
		Button columnAddButton = new Button(container, SWT.NONE);
		columnAddButton.setText("+");
		columnAddButton.setBounds(235, 10, 25, 20);

		colRemoveButton = new Button(container, SWT.NONE);
		colRemoveButton.setText("-");
		colRemoveButton.setBounds(265, 10, 25, 20);

		rowAddButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent event) {
				addRow();
			}
		});

		rowRemoveButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent event) {
				removeRow();
			}
		});

		columnAddButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent event) {
				addColumn();
			}
		});

		colRemoveButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent event) {
				removeColumn();
			}
		});

		createTable(container);
	}

	/**
	 * Method used to create table
	 * @param container
	 */
	private void createTable(Composite container) {
		valueTable = new Table(container, SWT.BORDER | SWT.MULTI | SWT.RESIZE | SWT.H_SCROLL | SWT.V_SCROLL);
		valueTable.setBounds(5, 56, 1050, 200);
		GridData data = new GridData(SWT.FILL, SWT.FILL, true, true);
		data.heightHint = 100;
		valueTable.setLayoutData(data);
		valueTable.setEnabled(true);
		valueTable.setLinesVisible(true);
		valueTable.setHeaderVisible(true);

		TableColumn tableColumn = new TableColumn(valueTable, SWT.NONE);
		tableColumn.setWidth(100);

		TableColumn tableColumn0 = new TableColumn(valueTable, SWT.NONE);
		tableColumn0.setWidth(100);
		tableColumn0.setText("0");

		TableItem rowItem = new TableItem(valueTable, SWT.NONE);
		rowItem.setText(0, "0");

		// tableEditor = new TableEditor(valueTable);
		final TableEditor editor = new TableEditor(valueTable);
		editor.horizontalAlignment = SWT.LEFT;
		editor.grabHorizontal = true;
		valueTable.addListener(SWT.MouseDown, new Listener() {
			public void handleEvent(Event event) {
				CategoryEditor categoryEditor = getCategoryEditor();
				Rectangle clientArea = valueTable.getClientArea();
				Point point = new Point(event.x, event.y);
				int index = valueTable.getTopIndex();
				while (index < valueTable.getItemCount()) {
					boolean visible = false;
					final TableItem item = valueTable.getItem(index);
					for (int i = 1; i < valueTable.getColumnCount(); i++) {
						Rectangle rect = item.getBounds(i);
						if (rect.contains(point)) {
							final int column = i;
							Text text = new Text(valueTable, SWT.NONE);

							Listener textListener = new Listener() {
								public void handleEvent(final Event event) {
									handleTextEventofTableCell(container, categoryEditor, item, column, text, event);
								}								
							};
							
							text.addListener(SWT.FocusOut, textListener);
							text.addListener(SWT.Traverse, textListener);
							text.addMenuDetectListener(new MenuDetectListener() {
								@Override
								public void menuDetected(MenuDetectEvent event) {
									//event.doit = false;
									//enable copy paste on cursor selection
								}
							});
							editor.setEditor(text, item, i);
							//editor.
							text.setText(item.getText(i));
							text.selectAll();
							text.setFocus();
							return;
						}
						if (!visible && rect.intersects(clientArea)) {
							visible = true;
						}
					}
					if (!visible)
					{
						return;
					}
					index++;
				}
			}
		});
	}

	/**
	 * Method used to handle the events of Text in table cell
	 * @param container
	 * @param categoryEditor
	 * @param item
	 * @param column
	 * @param text
	 * @param event
	 */
	private void handleTextEventofTableCell(Composite container,
			CategoryEditor categoryEditor, final TableItem item, final int column,
			Text text, final Event event) {
		switch (event.type) {
	
		case SWT.FocusOut:
			if(!isTableCellValueValid(text.getText())){
				MessageDialog.openWarning(container.getShell(), ApplicationConstant.WARNING, MessageConstant.TABLE_VIEW_VAL);
				text.dispose();
			}else{
				item.setText(column, text.getText());		
				setChangedValue(categoryEditor, rowIndex, getTableData());
				categoryEditor.setDirty(true);
				text.dispose();
				ApplicationActionBarAdvisor.getInstance().saveAllAction.setEnabled(true);
				ApplicationActionBarAdvisor.getInstance().saveAction.setEnabled(true);
			}
			break;
			
		case SWT.Traverse:
			categoryEditor.setDirtyAfterDataUpdate();		
			categoryEditor.editRowLists.add(rowIndex);
			/*if(event.keyCode == SWT.TAB) {
				categoryEditor.natTable.doCommand(new SelectCellCommand(categoryEditor.createNatTable.getSelectionLayer(), CategoryEditor.lastSelectedColumn+1,CategoryEditor.lastSelectedRow, false, false));
			}*/
			break;
		
		}
	}
	
	/**
	 * Method used to add row in table
	 */
	private void addRow() {
		int itemText = valueTable.getItemCount();
		TableItem item = new TableItem(valueTable, SWT.NULL);
		item.setText(Integer.toString(itemText));

		rowCountText.setText(Integer.toString(valueTable.getItemCount()));
		enableDisableRowAddRemoveButton();
	}

	/**
	 * Method used to remove row from table
	 */
	private void removeRow() {
		TableItem item = valueTable.getItem(valueTable.getItemCount() - 1);
		item.dispose();

		rowCountText.setText(Integer.toString(valueTable.getItemCount()));
		enableDisableRowAddRemoveButton();
		setChangedValue(getCategoryEditor(), rowIndex, getTableData());
	}

	/**
	 * Method used to add column in table
	 */
	private void addColumn() {
		int columnText = valueTable.getColumnCount();
		TableColumn newTableColumn = new TableColumn(valueTable, SWT.NONE);
		newTableColumn.setWidth(100);
		newTableColumn.setText(Integer.toString(columnText - 1));

		columnCountText.setText(Integer.toString(valueTable.getColumnCount() - 1));
		enableDisableColumnAddRemoveButton();
	}

	/**
	 * Method used to remove column from table
	 */
	private void removeColumn() {
		TableColumn column = valueTable.getColumn(valueTable.getColumnCount() - 1);
		column.dispose();
		
		columnCountText.setText(Integer.toString(valueTable.getColumnCount() - 1));
		enableDisableColumnAddRemoveButton();
		setChangedValue(getCategoryEditor(), rowIndex, getTableData());
	}

	/**
	 * Method used to get instance of category editor form where Table Editor is
	 * called
	 * 
	 * @return
	 */
	private CategoryEditor getCategoryEditor() {
		CategoryEditor categoryEditor = null;
		IEditorReference[] editors = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
				.getEditorReferences();
		for (IEditorReference editorRef : editors) {
			if (editorRef.getEditor(false) instanceof CategoryEditor
					&& editorRef.getEditor(false).getTitle().equals(category)) {
				categoryEditor = (CategoryEditor) editorRef.getEditor(false);
				break;
			}
		}
		return categoryEditor;
	}

	/**
	 * Method used to get table data
	 * @return String
	 */
	private String getTableData() {
		String tableDataToShow = "";
		
		String[][] tableData = new String[valueTable.getItemCount()][valueTable.getColumnCount()];
		for (int i = 0; i < valueTable.getItemCount(); i++) {
			tableDataToShow += "[";
			for (int j = 1; j < valueTable.getColumnCount(); j++) {
				TableItem item = valueTable.getItem(i);
				tableData[i][j - 1] = item.getText(j);
				if(j > 1 && (item.getText(j)!=null && !item.getText(j).equals(ApplicationConstant.EMPTY_STRING))) {
					tableDataToShow += ",";
				}
				try {
					tableDataToShow += Double.toString((Double.parseDouble(item.getText(j))));
				} catch (NumberFormatException e) {
					LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
				}
			}
			tableDataToShow += "]";
		}
		
		return tableDataToShow;
	}

	/**
	 * Set the new value in category editor
	 * 
	 * @param categoryEditor
	 * @param rowIndex
	 * @param tableDataToShow
	 */
	private void setChangedValue(CategoryEditor categoryEditor, int rowIndex, String tableDataToShow) {

		String dimension = "";
		if(!tableDataToShow.equals("[]")) {
			categoryEditor.createNatTable.getJsonDataProvider().setDataValue(columnIndex, rowIndex, tableDataToShow);

			if (category.equals(ApplicationConstant.CATEGORY_INPUT) || category.equals(ApplicationConstant.CATEGORY_OUTPUT)
					|| category.equals(ApplicationConstant.CATEGORY_LOCAL) || category.equals(ApplicationConstant.CATEGORY_NVM)) {
				dimension = Integer.toString(getColumnCountFromValue(tableDataToShow));
			} else {
				dimension = "[" + Integer.toString(getRowCountFromValue(tableDataToShow)) + ","
						+ Integer.toString(getColumnCountFromValue(tableDataToShow)) + "]";
			}
			categoryEditor.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colDimIdx,
					rowIndex, dimension);
		}else {
			categoryEditor.createNatTable.getJsonDataProvider().setDataValue(columnIndex, rowIndex, ApplicationConstant.EMPTY_STRING);
			categoryEditor.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colDimIdx,
					rowIndex, "1");
		}
		categoryEditor.natTable.refresh();	
	}

	/**
	 * Method used to check table cell value is valid or not
	 * @param tableCellValue
	 * @return boolean
	 */
	private boolean isTableCellValueValid(String tableCellValue){
		try{
			if(tableCellValue.equals("") || tableCellValue == null) {
				return true;
			}
			else {
				Float.parseFloat(tableCellValue);
				return true;
			}
			
		}catch(NumberFormatException e){
			return false;
		}
	}
	
	/**
	 * Method used to get value in proper format in table view
	 * @param tableValue
	 * @return String[]
	 */
	public String[] parseValue(String tableValue) {
		String newVal1 = null;
		String valueData= "";
		String newTableValue = "";
		String[] valueColumn = tableValue.replace("[", "").split("]");
		
		rowCount = getRowCountFromDimension(dimension);
		columnCount = getColumnCountFromDimension(dimension);
		
		// Append 0's for blank column
		for(int i= 0 ; i<valueColumn.length ; i++) {
			String[] colCount = valueColumn[i].split(",");
			if(colCount.length < columnCount) {
				int diff = columnCount - colCount.length;
				valueColumn[i] = "["+valueColumn[i];
				for(int j = 0; j<diff; j++) {
					valueColumn[i] = valueColumn[i]+",0";
				}
				valueColumn[i] = valueColumn[i]+"]";
					valueData = valueData + valueColumn[i];
			}
			else {
				valueData = valueData + "["+valueColumn[i]+"]";
			}
		}
		//reinitialize table value
		newTableValue = valueData;
		
		
		
		if (rowCount > 1) {
			String newVal = newTableValue.substring(newTableValue.indexOf('[') + 1, newTableValue.lastIndexOf(']'));
			newVal1 = newVal.replace("][", ",").replace("[", "").replace("]", "");
			
		} else {
			newVal1 = newTableValue.replace("[", "").replace("]", "");
		}

		return newVal1.split(",");

	}

	/**
	 * Method used to get row count
	 * 
	 * @param dimension
	 * @return int
	 */
	private int getRowCountFromDimension(String dimension) {
		int rowCount = 0;
		if (!dimension.equals("")) {
			if(category.equals(ApplicationConstant.CATEGORY_INPUT) || category.equals(ApplicationConstant.CATEGORY_OUTPUT) || category.equals(ApplicationConstant.CATEGORY_LOCAL) || category.equals(ApplicationConstant.CATEGORY_NVM)) {
				rowCount = 1;
			}else {
				String newDim = dimension.substring(dimension.indexOf('[') + 1, dimension.lastIndexOf(']'));
				String[] dim = newDim.split(",");
				rowCount = Integer.parseInt(dim[0]);
			}
			
		}

		return rowCount;
	}

	/**
	 * Method used to get column count
	 * 
	 * @param dimension
	 * @return int
	 */
	private int getColumnCountFromDimension(String dimension) {
		int columnCount = 0 ;
		if (!dimension.equals("")) {
			if(category.equals(ApplicationConstant.CATEGORY_INPUT) || category.equals(ApplicationConstant.CATEGORY_OUTPUT) || category.equals(ApplicationConstant.CATEGORY_LOCAL) || category.equals(ApplicationConstant.CATEGORY_NVM)) {
				columnCount = Integer.parseInt(dimension);
			} else {
				String newDim = dimension.substring(dimension.indexOf('[') + 1, dimension.lastIndexOf(']'));
				String[] dim = newDim.split(",");
				columnCount = Integer.parseInt(dim[1]);
			}
		}
		return columnCount;
	}
	
	/**
	 * Method used to get the column count from value/initial value
	 * @param value
	 * @return int
	 */
	private int getColumnCountFromValue(String value){
		int columnCount = 0;
		if (!value.equals("")) {
			String newValue = value.substring(value.indexOf('[') + 1, value.indexOf(']'));
			String[] dim = newValue.split(",");
			columnCount = dim.length;
		}
		return columnCount;	
	}
	
	/**
	 * Method used to get the row count from value/initial value
	 * @param value
	 * @return int
	 */
	private int getRowCountFromValue(String value){
		int rowCount = 0;
		if (!value.equals("")) {
			for(int i=0;i<value.length();i++){
				if(value.charAt(i)=='['){
					rowCount++;
				}			
			}
		}
		return rowCount;
		
	}

	/**
	 * If value is available then load table with that data
	 * 
	 * @param tableData
	 * @param rowCount
	 * @param columnCount
	 */
	private void loadTableWithOldData(String[] tableData, int rowCount, int columnCount) {
		rowCountText.setText(Integer.toString(rowCount));
		columnCountText.setText(Integer.toString(columnCount));
		int dataIterator = 0;
		for (int i = 1; i < columnCount; i++) {
			addColumn();
		}

		for (int i = 1; i < rowCount; i++) {
			addRow();
		}
		for (int i = 0; i < valueTable.getItemCount(); i++) {
			for (int j = 1; j < valueTable.getColumnCount(); j++) {
				if(valueTable.getColumnCount() > 2) {
					//Check iterator length to be less than data col's
					if(dataIterator < tableData.length) {
						valueTable.getItem(i).setText(j, tableData[dataIterator]);
						dataIterator++;
					}
				}
				else {
					if(tableData.length != 0) {
						if(tableData[dataIterator].equals("0")) {
							//++ dataIterator;
							valueTable.getItem(i).setText(j, tableData[dataIterator]);
						}else {
							valueTable.getItem(i).setText(j, tableData[dataIterator]);
							dataIterator++;
						}
					}
				}
			}
		}
	}
	
	/**
	 * Method used to enable or disable row add and remove button
	 */
	private void enableDisableRowAddRemoveButton(){
		if(columnIndex == CreateNatTable.colIniValIdx){
			rowAddButton.setEnabled(false);
		}else{
			rowAddButton.setEnabled(false);
		}
		
		if(category.equals(ApplicationConstant.CATEGORY_MAP)){
			rowAddButton.setEnabled(true);
		}else{
			rowAddButton.setEnabled(false);
		}
		
		if(valueTable.getItemCount()==1){
			rowRemoveButton.setEnabled(false);
		}else{
			rowRemoveButton.setEnabled(true);
		}
	}
	
	/**
	 * Method used to enable or disable column add and remove button
	 */
	private void enableDisableColumnAddRemoveButton(){
		if((valueTable.getColumnCount()-1)==1){
			colRemoveButton.setEnabled(false);
		}else{
			colRemoveButton.setEnabled(true);
		}
	}
}