package com.navistar.datadictionary.ui.views;

import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.part.ViewPart;

import com.navistar.datadictionary.action.ClearLogAction;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.ui.config.Activator;
import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;

/**
 * Class used for creating ActionLogView ViewPart in the existing workspace
 * @author minalc
 *
 */
public class ActivityLogView extends ViewPart{

	/**
	 * Log View Text
	 */
	public static StyledText activityLog;
	
	/** Activity Log Text */
	public static  String  activityLogText= "";

	/** Interface for Call Back */
	public interface ActionCallListener
	{
		void displayViewCheck(boolean flag);
	}

	/**
	 * This method is used to create the activity log viewpart
	 * with its default setting
	 * @param parent
	 */
	@Override
	public void createPartControl(Composite parent) {
		
		activityLog = new StyledText(parent, SWT.BORDER|SWT.V_SCROLL|SWT.FOREGROUND);
		activityLog.setForeground(new Color(parent.getDisplay(), 0,0,255));
		activityLog.setFont(new Font(parent.getDisplay(), ApplicationConstant.APP_FONT_STYLE, 11, SWT.None));
		activityLog.setEditable(false);		

		ClearLogAction clearLogAction = new ClearLogAction();
		clearLogAction.setText("Clear Log");
		clearLogAction.setImageDescriptor(Activator.getImageDescriptor("/icons/clear-log16.png"));
		IActionBars actionBars = getViewSite().getActionBars();
		IToolBarManager toolBar = actionBars.getToolBarManager();
		toolBar.add(clearLogAction);
	}

	/**
	 * This method asks this part to take focus within the workbench. 
	 * Workbench will call this method automatically.
	 */
	@Override
	public void setFocus() {
		// nothing to clean up
	}

	/**
	 * This method is overridden to un-check the activity log option
	 * from the file menu
	 */
	@Override
	public void dispose() {	
		ApplicationActionBarAdvisor.getInstance().activityLogAction.setChecked(false);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Object getAdapter(Class arg0) {
		return null;
	}
}
