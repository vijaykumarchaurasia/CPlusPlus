package com.navistar.datadictionary.ui.views;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.GroupMarker;
import org.eclipse.jface.action.IMenuListener;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.layout.GridLayoutFactory;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.ViewPart;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.navistar.datadictionary.action.UseThisObjectAction;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.IconsPathConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.model.CategoryAttributesIo;
import com.navistar.datadictionary.service.OpenComponentService;
import com.navistar.datadictionary.serviceimpl.CheckComponentInputsServiceimpl;
import com.navistar.datadictionary.serviceimpl.EditorServiceImpl;
import com.navistar.datadictionary.serviceimpl.OpenComponentServiceImpl;
import com.navistar.datadictionary.ui.config.Application;
import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.ui.config.DataDictionaryApplication;
import com.navistar.datadictionary.ui.editors.ComponentIpEditor;
import com.navistar.datadictionary.util.GsonUtil;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Class used for creating Check I/OCompatibility ViewPart in the existing workspace.
 * @author VijayK13
 *
 */
public class CheckComponentInputsView extends ViewPart implements MouseListener{

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(ProjectExplorerView.class);
	
	/** Used to get the component input view ID*/
	public static final String CHECK_COMP_IPS = ViewIDConstant.COMP_INPUTS;
	
	/** Check Component Inputs view instance */
	private static CheckComponentInputsView compIpViewInst;

	/** Component IO view parent */
	private Composite parent;

	/** Component IO warning tree */
	private Tree tree;

	/** Used to access CheckComponentInputsService Service */
	private CheckComponentInputsServiceimpl checkCompInObj;

	/** Used to store Check component inputs details */
	public Map<String, List<CategoryAttributesIo>> checkCompInMap;

	/** Used to access Open Component Service */
	private OpenComponentService openCompService;

	/** constructor */
	public static CheckComponentInputsView getCompInputsViewInstance() {
		return compIpViewInst;
	}

	private org.eclipse.swt.graphics.Font fontStyle;
	/**
	 * This method is used to create Component Inputs view.
	 */
	@Override
	public void createPartControl(Composite parent) {
		
		Device device;
		JsonElement jsonElement =null;
		checkCompInObj = new CheckComponentInputsServiceimpl();
		openCompService = new OpenComponentServiceImpl();
		compIpViewInst = this;
		compIpViewInst.parent = parent;
		this.parent = parent;
		device = PlatformUI.getWorkbench().getDisplay();
		fontStyle  = new org.eclipse.swt.graphics.Font(device, ApplicationConstant.APP_FONT_STYLE,10, SWT.NORMAL);

		if(DataDictionaryApplication.getApplication().isCheckCompIpStatus()) {
			
			try {
				jsonElement = checkCompInObj.getComponentInputsData();
				
			} catch (MatlabCommunicatinException e) {
				if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
					ActivityLogView.activityLog.append("\n [ERROR]: "+e.getMessage());
				}
				MessageDialog.openConfirm(new Shell(), "Error Message", e.getMessage());
			}
		}
		else {
			   jsonElement = Application.compIpJsonElement;
			}
		
		createCompInputsPartControl(jsonElement);
		
		
	}
	
	

	/**
	 * This method is used to create parts for Component Inputs view.
	 */
	public void createCompInputsPartControl(JsonElement jsonElement) {
		
		if(jsonElement != null)
		{
			checkCompInMap = checkCompInObj.convertCompIOListToMap(jsonElement);
			if(checkCompInMap!=null) {
				List<CategoryAttributesIo> oldList = new ArrayList<>();
				List<CategoryAttributesIo> inconModiflstIo = new ArrayList<>();
				List<CategoryAttributesIo> inconModiflstIoStruc = new ArrayList<>();
				for (Entry<String, List<CategoryAttributesIo>> entry : checkCompInMap.entrySet()) {
					oldList.addAll(entry.getValue());
				}
				boolean isChanged = false;
				for(CategoryAttributesIo obj : oldList) {
					if(obj!=null) {
						if(checkInconIoORNrmlIO(obj)) {
							if(obj.getMin().equals("1.1111111111111111E+104")) {
								obj.setMin("");
							}
							if(obj.getMax().equals("1.1111111111111111E+104")) {
								obj.setMax("");
							}
							inconModiflstIo.add(obj);
							isChanged = true;
						}
						if(checkInconStructIO(obj)) {
							if(obj.getMin().equals("1.1111111111111111E+104")) {
								obj.setMin("");
							}
							if(obj.getMax().equals("1.1111111111111111E+104")) {
								obj.setMax("");
							}
							inconModiflstIoStruc.add(obj);
							isChanged = true;
						}
						
						
					}
				}
				Collections.sort(inconModiflstIo, new SortByName());
			    Collections.sort(inconModiflstIoStruc, new SortByName());
				if(isChanged) {
					if(Application.programName.equals("E44"))
					{
						checkCompInMap.replace("Inconsistent I/Os", inconModiflstIo);
					}
					else
					{
						if(!inconModiflstIo.isEmpty())
						{
							checkCompInMap.replace("Inconsistent Normal I/Os", inconModiflstIo);
						}
						if(!inconModiflstIoStruc.isEmpty())
						{
							checkCompInMap.replace("Inconsistent Structured I/Os", inconModiflstIoStruc);
						}
					}
				}
				displayCompInputDetails(parent, checkCompInMap);

				GridLayoutFactory.fillDefaults().generateLayout(parent);

				MenuManager contextMenu = new MenuManager("#ViewerMenu");
				contextMenu.setRemoveAllWhenShown(true);

				contextMenu.addMenuListener(new IMenuListener() {
					@Override
					public void menuAboutToShow(IMenuManager mgr) {
						try {
							fillContextMenu(mgr);
						} catch (Exception e) {
							if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
								ActivityLogView.activityLog.append("\n [ERROR]: "+e.getMessage());
							}
							LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
						}
					}
				});

				Menu menu = contextMenu.createContextMenu(tree);
				tree.setMenu(menu);
			}else {
				MessageDialog.openInformation(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), ApplicationConstant.INFORMATION, "No Input data objects present in this component");
				return;
			}
	  }
	}
	
	public boolean checkInconIoORNrmlIO(CategoryAttributesIo obj)
	{
		return (obj.getName()!=null && !obj.getName().equals("") && (obj.getWarning().equals("Inconsistent I/Os") || obj.getWarning().equals("Inconsistent Normal I/Os")));
	}
	
	public boolean checkInconStructIO(CategoryAttributesIo obj)
	{
		return (obj.getName()!=null && !obj.getName().equals("") && obj.getWarning().equals("Inconsistent Structured I/Os"));
	}
	
	class SortByName implements Comparator<CategoryAttributes> {
		@Override
		public int compare(CategoryAttributes o1, CategoryAttributes o2) {
			// TODO Auto-generated method stub
			return o1.getName().compareTo(o2.getName());
		}
	}


	/**
	 * This method is used to get adapter.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Object getAdapter(Class arg0) {
		return null;
	}

	/**
	 * This method is used to perform actions while disposing the IO Compatibility
	 * view.
	 */
	@Override
	public void dispose() {
		compIpViewInst = null;
		ApplicationActionBarAdvisor.getInstance().action = (Action) ApplicationActionBarAdvisor.getInstance().resetPersObj;
	}


	/**
	 * Method is used to display Check Component Inputs details.
	 * 
	 * @param parent
	 * @param checkCompIpsListMap
	 */
	private void displayCompInputDetails(final Composite parent,
			Map<String, List<CategoryAttributesIo>> checkCompIpsMap) {
		//get icon image instance for tree 
		final Display display = PlatformUI.getWorkbench().getDisplay();
		Image plugImage = new Image(display,
				CheckComponentInputsView.class.getResourceAsStream(IconsPathConstant.ICON_PLUG));
		Image inputOutputImage = new Image(display,
				CheckComponentInputsView.class.getResourceAsStream(IconsPathConstant.ICON_INPUT_OUTPUT));
		Image warningImage = new Image(display,
				CheckComponentInputsView.class.getResourceAsStream(IconsPathConstant.ICON_WARNING_NEW));

		IViewPart checkCompIPView  = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().findView(ViewIDConstant.COMP_INPUTS);
		
		// Check if view is already available
		if (tree != null && (checkCompIPView != null)) {
	
			tree.removeAll();
		} else {
			tree = new Tree(parent, SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL);
			tree.setSize(290, 260);
			parent.setSize(300, 330);
			tree.addMouseListener(this);
		}

		// Iterate IO warning List details
		for (String warning : checkCompIpsMap.keySet()) {

			List<CategoryAttributesIo> ioCompatList = checkCompIpsMap.get(warning);

			boolean warningFlag = true;
			TreeItem warningItem = null;
			TreeItem dataObjectItem = null;

			// Iterate Data object list
			for (Iterator<CategoryAttributesIo> iterator = ioCompatList.iterator(); iterator.hasNext();) {
				CategoryAttributes category = (CategoryAttributes) iterator.next();

				TreeItem compoCategory = null;
				if (warningFlag) {
					warningItem = new TreeItem(tree, 0);
					warningItem.setImage(warningImage);

					if(category.getWarning().contains(ApplicationConstant.NO_ISSUES))
					{
						warningItem.setText(category.getWarning());	
						warningItem.setFont(fontStyle);
					}
					else
					{
						warningItem.setText(ApplicationConstant.WARNING_CAPS + category.getWarning());
						warningItem.setFont(fontStyle);
					}	

					warningFlag = false;				

					if(!category.getWarning().contains(ApplicationConstant.NO_ISSUES))
					{
						dataObjectItem = new TreeItem(warningItem, 0);
						dataObjectItem.setImage(plugImage);
						dataObjectItem.setText(category.getName());
						compoCategory = new TreeItem(dataObjectItem, 0);
						compoCategory.setImage(inputOutputImage);
						compoCategory.setText(category.getComponent() + " : " + category.getCategory());
						compoCategory.setFont(fontStyle);

					}


				} else {
					if (dataObjectItem.getText().equalsIgnoreCase(category.getName())) {
						compoCategory = new TreeItem(dataObjectItem, 0);
						compoCategory.setImage(inputOutputImage);
						compoCategory.setText(
								category.getComponent() + " : " + category.getCategory());
						compoCategory.setFont(fontStyle);
					} else {
						dataObjectItem = new TreeItem(warningItem, 0);
						dataObjectItem.setImage(plugImage);
						dataObjectItem.setText(category.getName());
						dataObjectItem.setFont(fontStyle);
						compoCategory = new TreeItem(dataObjectItem, 0);
						compoCategory.setImage(inputOutputImage);
						compoCategory.setText(
								category.getComponent() + " : " + category.getCategory());
						compoCategory.setFont(fontStyle);

					}

				}

			}
		}
	}
	
	/**
	 * This Method is to get the context menu actions and disable the Open and Close
	 * project option accordingly
	 * 
	 * @param contextMenu
	 */
	protected void fillContextMenu(IMenuManager contextMenu) {

		TreeItem selectedNode = tree.getSelection()[0];
		String warningName = "";
		if(selectedNode.getParentItem()!= null){
			if(selectedNode.getParentItem().getParentItem()!=null){
				warningName = selectedNode.getParentItem().getParentItem().getText();
			}
		}
		// Check if the component : category is selected
		if (selectedNode.getItemCount() == 0 && (warningName.contains(ApplicationConstant.INCONSISTENT_IOS))) {

			contextMenu.add(new GroupMarker(IWorkbenchActionConstants.MB_ADDITIONS));
			UseThisObjectAction useThisObjAction = new UseThisObjectAction();
			useThisObjAction.setText(ApplicationConstant.USE_THIS_OBJECT);
			contextMenu.add(useThisObjAction);
			
		} 

	}


	/**
	 * Method used to set focus to this view
	 */
	@Override
	public void setFocus() {
		// nothing to clean up
	}

	/**
	 * This method is used to get tree for Component Inputs view.
	 * @return
	 */
	public Tree getTree() {
		return this.tree;
	}
	
	/**
	 * Sent when a mouse button is pressed twice within the (operating system specified) double click period
	 * @param event
	 */
	@Override
	public void mouseDoubleClick(MouseEvent event) {
		
		final TreeItem item = tree.getSelection()[0];
		
		if(item.getText().contains(ApplicationConstant.NO_ISSUES))
		{
			return;
		}
		
		if(item.getItemCount() == 0)
		{	        	  
			// Closing all open editors
			new EditorServiceImpl().closeAllEditors();
			String waringValue = item.getParentItem().getParentItem().getText();
			String dataObject = item.getParentItem().getText();
			String componentName = item.getText().split(" : ")[0];
			String categoryName = item.getText().split(" : ")[1];
			String strWarning [] = waringValue.split(":");

			if(strWarning.length>1)
			{
				List<CategoryAttributesIo> compIpList = checkCompInMap.get(strWarning[1].trim());
				openCompService.openComponentForCompEditor(dataObject,componentName,categoryName, compIpList);
			} 
		}


	}
	
	/**
	 * Method used for scroll down event of mouse
	 * @param event
	 */
	@Override
	public void mouseDown(MouseEvent event) {
		//nothing to clean-up
	}

	/**
	 * Method used for scroll up event of mouse
	 * @param event
	 */
	@Override
	public void mouseUp(MouseEvent event) {
		//nothing to clean-up
	}
	
	/**
	 * Method used for refreshing CompIpEditor and view after performing Use This Object operation
	 */
	public void refreshCompIpAfterUseThisObj(CategoryAttributes dataOfUseThisObj) {
		
		List<CategoryAttributesIo> oldList = checkCompInMap.get(dataOfUseThisObj.getWarning());
		List<CategoryAttributes> usedList = new ArrayList<>();
		
		for(CategoryAttributesIo obj : oldList) {
			usedList.add((CategoryAttributes) obj);
		}
		
		List<CategoryAttributes> inconModiflst = new ArrayList<>();
	//	boolean isChanged = false;
		for(CategoryAttributes obj : usedList) {
			if(obj!=null) {
				if(obj.getName()!=null && !obj.getName().equals("") && obj.getWarning().equals("Inconsistent I/Os")) {
					if(obj.getMin().equals("1.1111111111111111E+104")) {
						obj.setMin("");
					}
					if(obj.getMax().equals("1.1111111111111111E+104")) {
						obj.setMax("");
					}
					inconModiflst.add(obj);
				//	isChanged = true;

				}
			}
		}
		Collections.sort(inconModiflst, new SortByName());
		
		Iterator<CategoryAttributes> listIterator = usedList.iterator();			
				
		while(listIterator.hasNext()) {

			CategoryAttributes categoryObject = listIterator.next();
			//added one more condition to check if name with empty string exist in Inconsistent i/os list
			if(categoryObject.getName().equals(dataOfUseThisObj.getName()) || categoryObject.getName().equals("")) {
				listIterator.remove();
			}
		}

		if(!usedList.isEmpty()) {
			List<CategoryAttributesIo> newlist = new ArrayList<>();
			for(CategoryAttributes obj : usedList) {
				newlist.add((CategoryAttributesIo) obj);
			}
			checkCompInMap.put(dataOfUseThisObj.getWarning(),newlist);
		}else {
			CategoryAttributesIo categoryObj = new CategoryAttributesIo();
			categoryObj.setWarning(ApplicationConstant.INCONSISTENT_IOS+" "+ApplicationConstant.NO_ISSUES);
			usedList.add(categoryObj);
			List<CategoryAttributesIo> newlist = new ArrayList<>();
			for(CategoryAttributes obj : usedList) {
				newlist.add((CategoryAttributesIo) obj);
			}
			checkCompInMap.put(ApplicationConstant.INCONSISTENT_IOS,newlist);
			
		}
				
		JsonArray jsonArray = new JsonArray();
		for(String warning: checkCompInMap.keySet()) {
			JsonElement jsonElement = new JsonParser().parse(GsonUtil.provider().toJSON(checkCompInMap.get(warning)));
			jsonArray.add(jsonElement);
		}
		//refresh view and editor
		Application.compIpJsonElement = jsonArray;	
		DataDictionaryApplication.getApplication().setCheckCompIpStatus(false);

		ViewUtil.closeView(ViewIDConstant.COMP_INPUTS);
		ViewUtil.showHideView(ViewIDConstant.COMP_INPUTS, true);
		
	
		IEditorPart activeEditor = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor();
		
		if(activeEditor instanceof ComponentIpEditor) {
	
			new EditorServiceImpl().closeAllEditors();
			
			List<CategoryAttributesIo> compIpList = checkCompInMap.get(dataOfUseThisObj.getWarning());
			if(!compIpList.isEmpty() && compIpList.get(0).getName()!=null) {
				openCompService.openComponentForCompEditor(dataOfUseThisObj.getName(),dataOfUseThisObj.getComponent(),dataOfUseThisObj.getCategory(), compIpList);
			}else {
				new EditorServiceImpl().closeAllEditors();
			}
			
			
		}
	} 
}
