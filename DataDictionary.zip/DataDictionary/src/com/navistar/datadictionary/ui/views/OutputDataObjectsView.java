package com.navistar.datadictionary.ui.views;

import java.io.File;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.jface.action.IMenuListener;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.layout.GridLayoutFactory;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.ViewPart;

import com.google.gson.JsonElement;
import com.google.gson.reflect.TypeToken;
import com.navistar.datadictionary.action.AddOutputsInInputAction;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.IconsPathConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.model.Project;
import com.navistar.datadictionary.serviceimpl.EditorServiceImpl;
import com.navistar.datadictionary.serviceimpl.OpenComponentServiceImpl;
import com.navistar.datadictionary.util.GsonUtil;
import com.navistar.datadictionary.util.ViewUtil;

public class OutputDataObjectsView extends ViewPart implements MouseListener{


	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(OutputDataObjectsView.class);

	/** Output Data Objects View parent */
	private Composite parent;

	/** Output Data Objects View tree */
	private Tree tree;

	/** Output Data Objects list from browsed sldd*/
	public static List<CategoryAttributes> browsedOpsList = null;
	
	/** Output Data Objects list from all outputs in project*/
	public static List<List<CategoryAttributes>> allCompOpsList = null;
	
	/** For setting Font of the window */
	private org.eclipse.swt.graphics.Font fontStyle;
	
	private static List<TreeItem> checkOpList;

	public static List<TreeItem> getCheckOpList() {
		return checkOpList;
	}

	public static void setCheckOpList(List<TreeItem> checkOpList) {
		OutputDataObjectsView.checkOpList = checkOpList;
	}

	/**
	 * Create window for adding data object in Input category
	 * @param parent
	 */
	@Override
	public void createPartControl(Composite parent) {
		
		JsonElement outputJsonData = null;
		this.parent = parent;
		Device device = PlatformUI.getWorkbench().getDisplay();
		fontStyle  = new org.eclipse.swt.graphics.Font(device, ApplicationConstant.APP_FONT_STYLE,10, SWT.NORMAL);

		Project project = ProjectExplorerView.getActiveProject();
		String componentName = new OpenComponentServiceImpl().getOpenedComponentName();

		try {
			if(AddDataObjectWindow.isBrowseSlddSel) {
				FileDialog fileDialog = new FileDialog(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell());
				String[] filterExt = { "*.sldd;*.SLDD" };
				fileDialog.setFilterExtensions(filterExt);
				String path = fileDialog.open();
				if (path != null) {
					File file = new File(path);
				//	AddDataObjectWindow.isBrowseSlddSel = false;
					outputJsonData = new EditorServiceImpl().getOutputsFromBrowsedSldd(file.getPath());
					if(outputJsonData.getAsJsonArray().get(0).isJsonObject()) {
						if(outputJsonData.getAsJsonArray().get(0).getAsJsonObject().has("errorCode")) {
							String errorCode = outputJsonData.getAsJsonArray().get(0).getAsJsonObject().get("errorCode").getAsString();
							AddDataObjectWindow.isBrowseSlddSel = false;
							if(errorCode.equals("656")) {
								ViewUtil.dispInfoInMsgDialog("No Outputs present in the SLDD");
								return;
							}		
						}
					}

				}else {
					//fixed issue if user cancels browse sldd operation and then selects to add outputs from proj, browse window was displayed
					AddDataObjectWindow.isBrowseSlddSel = false;
					return;
				}
			}
			else {
				outputJsonData = new EditorServiceImpl().getOutputDataObjects(project, componentName);
				if(outputJsonData.getAsJsonArray().get(0).isJsonObject()) {
					if(outputJsonData.getAsJsonArray().get(0).getAsJsonObject().has("errorCode")) {
						int errorCode = outputJsonData.getAsJsonArray().get(0).getAsJsonObject().get("errorCode").getAsInt();
						if(errorCode==4444) {
							ViewUtil.dispInfoInMsgDialog("No Output signals present in the project");
							return;
						}		
					}
				}
			}
			}
			catch (Exception e) {
				if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
					ActivityLogView.activityLog.append("\n [ERROR]: "+e.getMessage());
				}
				MessageDialog.openConfirm(new Shell(), "Error Message", e.getMessage());
				LOGGER.log(Level.ERROR,MessageConstant.EXCEPTION_IN_LOG,e);
			}

		if(outputJsonData!=null)
		{
			//added condition because separate json response for browsed sldd and all outputs from project
			if(AddDataObjectWindow.isBrowseSlddSel) {
				//json response outputJsonData in single array of objects
				browsedOpsList = convertJsonToListBrowse(outputJsonData);
				if(browsedOpsList!=null)
				{
					displayDataObjectsBrowsed(browsedOpsList);
					AddDataObjectWindow.isBrowseOpen = true;
				}
				AddDataObjectWindow.isBrowseSlddSel = false;
			}else {
				//json response outputJsonData in array of array of objects
				allCompOpsList = convertJsonToListAllOps(outputJsonData);
				if(allCompOpsList!=null)
				{
					displayDataObjectsAllOps(allCompOpsList);
				}
			}
		}
				
		GridLayoutFactory.fillDefaults().generateLayout(parent);
		MenuManager contextMenu = new MenuManager("#ViewerMenu");
		contextMenu.setRemoveAllWhenShown(true);

		contextMenu.addMenuListener(new IMenuListener() {
			@Override
			public void menuAboutToShow(IMenuManager mgr) {
				try {
					fillContextMenu(mgr);
				} catch (Exception e) {
					if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
						ActivityLogView.activityLog.append("\n [ERROR]: "+e.getMessage());
					}
					LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
				}
			}
		});

		Menu menu = contextMenu.createContextMenu(tree);
		tree.setMenu(menu);
	}
	
	private void displayDataObjectsBrowsed(List<CategoryAttributes> outputDataList) {
		//get icon image instance for tree 
		checkOpList = new ArrayList<>();
		final Display display = PlatformUI.getWorkbench().getDisplay();
		Image dataObjectImage = new Image(display,
				OutputDataObjectsView.class.getResourceAsStream(IconsPathConstant.ICON_INPUT_OUTPUT));
		Image componentImage = new Image(display,
				OutputDataObjectsView.class.getResourceAsStream(IconsPathConstant.ICON_COMPONENT));
		
			tree = new Tree(parent, SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL | SWT.CHECK);
			tree.setSize(290, 260);
			parent.setSize(300, 330);
			tree.addMouseListener(this);
			
			TreeItem componentItem = null;
			//for (Iterator<CategoryAttributes> iterator = outputDataList.iterator(); iterator.hasNext();) {
			//	List<CategoryAttributes> outputList = (List<CategoryAttributes>) iterator.next();
				
				if(!outputDataList.isEmpty())
				{
					CategoryAttributes category = outputDataList.get(0); 
					componentItem = new TreeItem(tree, SWT.CHECK);
					componentItem.setImage(componentImage);
					componentItem.setText(category.getComponent());				
					componentItem.setFont(fontStyle);
					
					for (CategoryAttributes catAttributes : outputDataList) {
						
						TreeItem dataObjectItem = null;
						dataObjectItem = new TreeItem(componentItem, SWT.CHECK);
						dataObjectItem.setImage(dataObjectImage);
						dataObjectItem.setText(catAttributes.getName());
						dataObjectItem.setFont(fontStyle);
					}
				}
				
				
			//}
			
			tree.addListener(SWT.Selection, new Listener() {
			      public void handleEvent(Event event) {
			       if (event.detail == SWT.CHECK) {
			        TreeItem item = (TreeItem) event.item;
			        boolean checked = item.getChecked();
			        
			        if(checked) {
			        	if(item.getParentItem()!=null) {
			        		checkOpList.add(item);
			        	}else {
			        		for(TreeItem it : item.getItems()) {
			        			//if user manually checks the data objects and again check on select all 
			        			boolean isChecked = it.getChecked();
			        			if(!isChecked) {
			        				it.setChecked(true);
				        			checkOpList.add(it);
			        			}
			        			
			        		}
			        	}
			        }else {
			        	if(item.getParentItem()!=null) {
			        		checkOpList.remove(item);
			        	}else {
			        		for(TreeItem it : item.getItems()) {
			        			it.setChecked(false);
			        			checkOpList.remove(it);
			        		}
			        		
			        	}
			        }
			        setCheckOpList(checkOpList);
			        }
			     }
			});
	}
	
	
	private void displayDataObjectsAllOps(List<List<CategoryAttributes>> outputDataList) {
		//get icon image instance for tree 
		checkOpList = new ArrayList<>();
		final Display display = PlatformUI.getWorkbench().getDisplay();
		Image dataObjectImage = new Image(display,
				OutputDataObjectsView.class.getResourceAsStream(IconsPathConstant.ICON_INPUT_OUTPUT));
		Image componentImage = new Image(display,
				OutputDataObjectsView.class.getResourceAsStream(IconsPathConstant.ICON_COMPONENT));
		
			tree = new Tree(parent, SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL | SWT.CHECK);
			tree.setSize(290, 260);
			parent.setSize(300, 330);
			tree.addMouseListener(this);
			
			TreeItem componentItem = null;
			for (Iterator<List<CategoryAttributes>> iterator = outputDataList.iterator(); iterator.hasNext();) {
				List<CategoryAttributes> outputList = (List<CategoryAttributes>) iterator.next();
				
				if(!outputList.isEmpty())
				{
					CategoryAttributes category = (CategoryAttributes) outputList.get(0); 
					componentItem = new TreeItem(tree, SWT.CHECK);
					componentItem.setImage(componentImage);
					componentItem.setText(category.getComponent());				
					componentItem.setFont(fontStyle);
					
					for (CategoryAttributes catAttributes : outputList) {
						
						TreeItem dataObjectItem = null;
						dataObjectItem = new TreeItem(componentItem, SWT.CHECK);
						dataObjectItem.setImage(dataObjectImage);
						dataObjectItem.setText(catAttributes.getName());
						dataObjectItem.setFont(fontStyle);
					}
				}
				
				
			}
			
			tree.addListener(SWT.Selection, new Listener() {
			      public void handleEvent(Event event) {
			       if (event.detail == SWT.CHECK) {
			        TreeItem item = (TreeItem) event.item;
			        boolean checked = item.getChecked();
			        
			        if(checked) {
			        	if(item.getParentItem()!=null) {
			        		checkOpList.add(item);
			        	}else {
			        		for(TreeItem it : item.getItems()) {
			        			//if user manually checks the data objects and again check on select all 
			        			boolean isChecked = it.getChecked();
			        			if(!isChecked) {
			        				it.setChecked(true);
				        			checkOpList.add(it);
			        			}
			        			
			        		}
			        	}
			        }else {
			        	if(item.getParentItem()!=null) {
			        		checkOpList.remove(item);
			        	}else {
			        		for(TreeItem it : item.getItems()) {
			        			it.setChecked(false);
			        			checkOpList.remove(it);
			        		}
			        		
			        	}
			        }
			        setCheckOpList(checkOpList);
			        }
			     }
			});
	}


	private List<CategoryAttributes> convertJsonToListBrowse(JsonElement outputJsonData) {
		Type type = new TypeToken<List<CategoryAttributes>>(){}.getType();
		return GsonUtil.provider().fromJSONToList(outputJsonData.toString(), type);
	}
	
	private List<List<CategoryAttributes>> convertJsonToListAllOps(JsonElement outputJsonData) {
		Type type = new TypeToken<List<List<CategoryAttributes>>>(){}.getType();
		return GsonUtil.provider().fromJSONToList(outputJsonData.toString(), type);
	}


	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public Object getAdapter(Class arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	/*@Override
	public void mouseDoubleClick(MouseEvent event) {
		
		final TreeItem item;
		if(tree.getSelection().length>0)
		{
			item = tree.getSelection()[0];
		}
		else
		{
			return;
		}
		
		if(item.getItemCount() == 0)
		{
			
		}

	}*/

	/**
	 * Method used to set the Output attribute values in Input category for browsed sldd
	 * @param item
	 * @return
	 */
	public CategoryAttributes setDataOfInputAttributesBrowsed(final TreeItem item) {
		CategoryAttributes newCatAttributes = new CategoryAttributes();
		//for (Iterator<List<CategoryAttributes>> iterator = outputDataList.iterator(); iterator.hasNext();) {
		//	List<CategoryAttributes> outputList = (List<CategoryAttributes>) iterator.next();	
			if(!browsedOpsList.isEmpty())
			{
				for (CategoryAttributes catAttributes : browsedOpsList) {
					if(item.getText().equals(catAttributes.getName())){
						newCatAttributes.setName(catAttributes.getName());
						newCatAttributes.setDescription(catAttributes.getDescription());
						newCatAttributes.setBaseType(catAttributes.getBaseType());
						newCatAttributes.setCategory(catAttributes.getCategory());
						newCatAttributes.setComponent(catAttributes.getComponent());
				
						if(Integer.parseInt(catAttributes.getDimensions())==-1){
							newCatAttributes.setDimensions("1");
						}
						else {
							newCatAttributes.setDimensions(catAttributes.getDimensions());
						}
						newCatAttributes.setDimensionsMode(catAttributes.getDimensionsMode());
						newCatAttributes.setDisplayFormat(catAttributes.getDisplayFormat());
						newCatAttributes.setInitialValue(catAttributes.getInitialValue());
						if(catAttributes.getMin().equals("1.1111111111111111E+104")) {
							newCatAttributes.setMin("");
						}else {
							newCatAttributes.setMin(catAttributes.getMin());
						}
						if(catAttributes.getMax().equals("1.1111111111111111E+104")) {
							newCatAttributes.setMax("");
						}else {
							newCatAttributes.setMax(catAttributes.getMax());
						}
					    //newCatAttributes.setMax(catAttributes.getMax());
						newCatAttributes.setMaxDimension(catAttributes.getMaxDimension());
						//newCatAttributes.setMin(catAttributes.getMin());
						newCatAttributes.setOffset(catAttributes.getOffset());
						newCatAttributes.setOldName(catAttributes.getOldName());
						newCatAttributes.setMemorySection(catAttributes.getMemorySection());
						newCatAttributes.setSampleTime(catAttributes.getSampleTime());
				//		newCatAttributes.setSamplingMode(catAttributes.getSamplingMode());
						newCatAttributes.setSlope(catAttributes.getSlope());
						newCatAttributes.setSwCalAccess(catAttributes.getSwCalAccess());
						newCatAttributes.setUnit(catAttributes.getUnit());
						newCatAttributes.setValue(catAttributes.getValue());
						newCatAttributes.setStructureElementName(catAttributes.getStructureElementName());
					}
				}
				
			//}	
		}
		return newCatAttributes;
	}
	
	
	public CategoryAttributes setDataOfInputAttributesAllOps(final TreeItem item) {
		CategoryAttributes newCatAttributes = new CategoryAttributes();
		for (Iterator<List<CategoryAttributes>> iterator = allCompOpsList.iterator(); iterator.hasNext();) {
			List<CategoryAttributes> outputList = (List<CategoryAttributes>) iterator.next();	
			if(!outputList.isEmpty())
			{
				for (CategoryAttributes catAttributes : outputList) {
					if(item.getText().equals(catAttributes.getName())){
						newCatAttributes.setName(catAttributes.getName());
						newCatAttributes.setDescription(catAttributes.getDescription());
						newCatAttributes.setBaseType(catAttributes.getBaseType());
						newCatAttributes.setCategory(catAttributes.getCategory());
						newCatAttributes.setComponent(catAttributes.getComponent());
				
						if(Integer.parseInt(catAttributes.getDimensions())==-1){
							newCatAttributes.setDimensions("1");
						}
						else {
							newCatAttributes.setDimensions(catAttributes.getDimensions());
						}
						newCatAttributes.setDimensionsMode(catAttributes.getDimensionsMode());
						newCatAttributes.setDisplayFormat(catAttributes.getDisplayFormat());
						newCatAttributes.setInitialValue(catAttributes.getInitialValue());
						if(catAttributes.getMin().equals("1.1111111111111111E+104")) {
							newCatAttributes.setMin("");
						}else {
							newCatAttributes.setMin(catAttributes.getMin());
						}
						if(catAttributes.getMax().equals("1.1111111111111111E+104")) {
							newCatAttributes.setMax("");
						}else {
							newCatAttributes.setMax(catAttributes.getMax());
						}
					    //newCatAttributes.setMax(catAttributes.getMax());
						newCatAttributes.setMaxDimension(catAttributes.getMaxDimension());
						//newCatAttributes.setMin(catAttributes.getMin());
						newCatAttributes.setOffset(catAttributes.getOffset());
						newCatAttributes.setOldName(catAttributes.getOldName());
						newCatAttributes.setOldName(catAttributes.getMemorySection());
						newCatAttributes.setSampleTime(catAttributes.getSampleTime());
					//	newCatAttributes.setSamplingMode(catAttributes.getSamplingMode());
						newCatAttributes.setSlope(catAttributes.getSlope());
						newCatAttributes.setSwCalAccess(catAttributes.getSwCalAccess());
						newCatAttributes.setUnit(catAttributes.getUnit());
						newCatAttributes.setValue(catAttributes.getValue());
					}
				}
				
			}	
		}
		return newCatAttributes;
	}
	
	@Override
	public void mouseDown(MouseEvent event) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseUp(MouseEvent event) {
		// TODO Auto-generated method stub

	}



	@Override
	public void setFocus() {
		// TODO Auto-generated method stub

	}
	
	protected void fillContextMenu(IMenuManager contextMenu) {

		AddOutputsInInputAction addInIpAction = new AddOutputsInInputAction();
		addInIpAction.setText("Add selected data object(s)");
		contextMenu.add(addInIpAction);

	}

	@Override
	public void mouseDoubleClick(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}


}
