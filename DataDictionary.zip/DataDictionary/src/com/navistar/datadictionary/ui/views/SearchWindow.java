package com.navistar.datadictionary.ui.views;

import java.io.File;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.io.FilenameUtils;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.PlatformUI;

import com.google.gson.JsonElement;
import com.google.gson.reflect.TypeToken;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.IconsPathConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.model.Project;
import com.navistar.datadictionary.serviceimpl.ImportProjectServiceImpl;
import com.navistar.datadictionary.serviceimpl.OpenComponentServiceImpl;
import com.navistar.datadictionary.serviceimpl.SearchDataServiceImpl;
import com.navistar.datadictionary.ui.config.DataDictionaryApplication;
import com.navistar.datadictionary.util.GsonUtil;
import com.navistar.datadictionary.util.JSONUtil;
import com.navistar.datadictionary.util.SwtResourceManagerUtils;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Class used to view Search Window which will get the criteria for search and
 * according to search functionality will execute and gave searched component
 * list.
 * 
 * @author vijayk13
 *
 */
public class SearchWindow implements SelectionListener,DisposeListener {

	/** Shell */
	protected Shell shell;
	/** Searched text */
	private Text searchWhatText;
	/** Search button */
	private Button searchButton;
	/** Match Case check box */
	private Button matchCaseCheckBtn;
	/** Exact word or phrase check box */
	private Button exactWordCheckBtn;

	/** Combo Box */
	private Combo componentComboBox;

	/** Opened Component */
	private String component;

	/** Project */
	private Project project;

	/** Active Project */
	private String activeProject;

	/** Active Component Component Map */
	private Map<String,String> activeCompMap;

	/** Variable to Check if shell is already open **/
	private static boolean started = false;


	/**
	 * Open the window.
	 */
	public void open() {

		DataDictionaryApplication.getApplication().setSearchFlag(false);

		createUIComponents();
		Display display = Display.getDefault();
		ViewUtil.setShellPositionAtCenter(display, shell);

		if(!started)
		{
			shell.open();
			shell.layout();
			shell.setMaximized(false);
			shell.setMinimized(false);
			started = true;
			shell.addDisposeListener(this);
			while (!shell.isDisposed()) {
				if (!display.readAndDispatch()) {
					display.sleep();
				}
			}

		}

	}

	/**
	 * This method is used to create and configure UI components for Search Window.
	 * @wbp.parser.entryPoint
	 */
	private void createUIComponents() {

		Image appIconImage = new Image(PlatformUI.getWorkbench().getDisplay(),
				SearchResultView.class.getResourceAsStream(IconsPathConstant.DATA_DD_ICON));

		shell = new Shell(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell());
		shell.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		shell.setSize(450, 221);
		shell.setImage(appIconImage);

		shell.setText(ApplicationConstant.LBLFINDINCOMP);
		shell.setLayout(null);

		Composite searchComposite = new Composite(shell, SWT.BORDER);
		searchComposite.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		searchComposite.setLocation(10, 10);
		searchComposite.setSize(414, 162);

		CLabel searchWhatLabel = new CLabel(searchComposite, SWT.NONE);
		searchWhatLabel.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 10, SWT.BOLD));
		searchWhatLabel.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		searchWhatLabel.setBounds(10, 10, 106, 19);
		searchWhatLabel.setText(ApplicationConstant.LBL_SEARCH_WHAT);

		searchWhatText = new Text(searchComposite, SWT.BORDER);
		searchWhatText.setBounds(10, 34, 309, 21);

		searchButton = new Button(searchComposite, SWT.NONE);
		searchButton.setBounds(329, 32, 75, 25);
		searchButton.setText(ApplicationConstant.BTN_SEARCH);
		searchButton.setEnabled(true);
		searchButton.addSelectionListener(this);
		searchButton.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 10, SWT.BOLD));
		shell.setDefaultButton(searchButton);
		
		matchCaseCheckBtn = new Button(searchComposite, SWT.CHECK);
		matchCaseCheckBtn.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 10, SWT.NORMAL));
		matchCaseCheckBtn.setBounds(13, 65, 93, 16);
		matchCaseCheckBtn.setText(ApplicationConstant.BTN_MATCH_CASE);
		matchCaseCheckBtn.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));

		exactWordCheckBtn = new Button(searchComposite, SWT.CHECK);
		exactWordCheckBtn.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 10, SWT.NORMAL));
		exactWordCheckBtn.setBounds(115, 66, 152, 16);
		exactWordCheckBtn.setText(ApplicationConstant.BTN_EXACT_WORD);
		exactWordCheckBtn.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));

		CLabel lblWhere = new CLabel(searchComposite, SWT.NONE);
		lblWhere.setLocation(10, 119);
		lblWhere.setSize(54, 18);
		lblWhere.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		lblWhere.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 10, SWT.BOLD));
		lblWhere.setText(ApplicationConstant.LBL_WHERE);

		project = ProjectExplorerView.getActiveProject();
		component = new OpenComponentServiceImpl().getOpenedComponentName();
		activeProject = project.getPath().substring(project.getPath().lastIndexOf("\\")+1, project.getPath().length());
		activeCompMap = ImportProjectServiceImpl.projectMap.get(activeProject);
		/** Combo box for component names */

		componentComboBox = new Combo(searchComposite, SWT.READ_ONLY);
		componentComboBox.setLocation(70, 117);
		componentComboBox.setSize(243, 23);
		componentComboBox.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 10, SWT.NONE));
		int index = 0;
		componentComboBox.add(activeProject,index);	
		int openComponent = 0;
		//componentComboBox.removeAll();
		// Create a list from elements of HashMap 
		List<Map.Entry<String, String> > componentList = 
				new LinkedList<Map.Entry<String, String> >(activeCompMap.entrySet()); 

		// Sort the list 
		Collections.sort(componentList, new Comparator<Map.Entry<String, String> >() { 
			public int compare(Map.Entry<String, String> object1,  
					Map.Entry<String, String> object2) 
			{ 
				return (object1.getValue()).compareTo(object2.getValue()); 
			} 
		}); 

		for (Iterator<Map.Entry<String, String>> iterator = componentList.iterator(); iterator.hasNext();) {
			Entry<String, String> entry = (Entry<String, String>) iterator.next();
			if (entry.getValue()!=null && !entry.getValue().equals("top")) {

				if(!entry.getValue().equals(component))
				{
					
					if(entry.getKey().contains(ProjectExplorerView.getActiveProject().getPath()))
					{
						index++;
						componentComboBox.add(entry.getValue(),index);
					}
					
				}
				else
				{
					openComponent = ++index;
					componentComboBox.add(entry.getValue(),openComponent);

				}				
			}			

		}

		componentComboBox.select(openComponent);

		/** Close button */
		Button closeButton;
		closeButton = new Button(searchComposite, SWT.NONE);
		closeButton.setLocation(329, 116);
		closeButton.setSize(75, 25);
		closeButton.setText(ApplicationConstant.BTN_CLOSE);
		closeButton.addSelectionListener(this);
		closeButton.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 10, SWT.BOLD));

		searchWhatText.addKeyListener(new KeyAdapter() {
			public void keyReleased(KeyEvent event) { 
				// watch for key strokes
				if (searchWhatText.getText().length() == 0 || searchWhatText.getText().length() == 0) {
					searchButton.setEnabled(false);
				}
				else 
				{
					searchButton.setEnabled(true);
				}
			}
		});
	}


	/**
	 * This method is used to perform actions on search and close buttons
	 */
	@Override
	public void widgetSelected(SelectionEvent event) {
		Button source = (Button) event.getSource();
		List<CategoryAttributes> searchedCompList = new ArrayList<CategoryAttributes>();

		// Check for Search button
		if (source.getText().equals(ApplicationConstant.BTN_SEARCH)) {

			if(searchWhatText.getText().equals(""))
			{
				MessageDialog.openConfirm(shell, "Search Text Validation", "Please enter text");
			}
			else
			{
				DataDictionaryApplication.getApplication().setSearchFlag(true);
				String searchText = searchWhatText.getText();
				SearchDataServiceImpl searchSerImpl = new SearchDataServiceImpl();
				String selectedComponent = componentComboBox.getText();
				
				File compPath = new File(selectedComponent);
				String selectedCompName = FilenameUtils.getBaseName(compPath.getName());
				
				if(component.equals(selectedComponent.trim()))
				{
					searchedCompList = searchSerImpl.searchDataForOpenComponent(searchText,
							matchCaseCheckBtn.getSelection(), exactWordCheckBtn.getSelection());
					if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
						ActivityLogView.activityLog.append("\n [INFO]: Searched text : " + "\""+ searchText + "\""+ " for component : "+ component);
					}
				}
				else
				{				

					if(selectedComponent.trim().equals(activeProject))
					{
						selectedComponent = project.getPath();
						if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
							ActivityLogView.activityLog.append("\n [INFO]: Searched text : " + "\"" + searchText + "\""+ " for project : "+ activeProject);
						}
					}
					else
					{
						for (Entry<String, String> entry : activeCompMap.entrySet()) {
							if (selectedComponent.trim().equals(entry.getValue()) && entry.getKey().contains(ProjectExplorerView.getActiveProject().getPath())) {
								selectedComponent =  entry.getKey();
							}
						}
						if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
							ActivityLogView.activityLog.append("\n [INFO]: Searched text : " + "\"" + searchText + "\""+ " for component : "+ selectedCompName);
						}
					}

					JsonElement jsonArray = null;
					try {
						jsonArray = searchSerImpl.searchDataForCloseComponent(selectedComponent.replace("\\", "/"),searchText,
								matchCaseCheckBtn.getSelection(), exactWordCheckBtn.getSelection());
					} catch (MatlabCommunicatinException e) {
						ViewUtil.dispConfirmDialog("Error Message", e.getMessage());
					}	
					if(!JSONUtil.checkSearchError(jsonArray))
					{
						Type type = new TypeToken<List<CategoryAttributes>>() {}.getType();
						searchedCompList = GsonUtil.provider().fromJSONToList(jsonArray.toString(),type);
					}

				}

				DataDictionaryApplication.getApplication().setSearchedDataList(searchedCompList);			

				shell.dispose();
				ViewUtil.closeView(ViewIDConstant.SEARCH_RESULT);
				ViewUtil.showHideView(ViewIDConstant.SEARCH_RESULT, true);
				
			}

		} else if (source.getText().equals(ApplicationConstant.BTN_CLOSE)) {
			shell.dispose();
		}

	}	

	/**
	 * This method is used to perform actions on default selection
	 */
	@Override
	public void widgetDefaultSelected(SelectionEvent event) {
		// nothing to clean up
	}

	@Override
	public void widgetDisposed(DisposeEvent event) {
		// TODO Auto-generated method stub
		started = false;

	}

}
