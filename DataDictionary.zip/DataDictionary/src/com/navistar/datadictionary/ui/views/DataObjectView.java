package com.navistar.datadictionary.ui.views;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;

import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;

public class DataObjectView extends ViewPart {
	public static final String DATA_OBJ_VIEW_ID = "com.navistar.datadictionary.view.DataObjectView";

	public DataObjectView() {
		// nothing to clean up
	}

	@Override
	public void createPartControl(Composite parent) {
		// nothing to clean up
	}

	@Override
	public void setFocus() {
		// nothing to clean up
	}
	
	@Override
	public void dispose() {
		ApplicationActionBarAdvisor.getInstance().dataObjWindowObj.setChecked(false);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Object getAdapter(Class arg0) {
	
		return null;
	}

}
