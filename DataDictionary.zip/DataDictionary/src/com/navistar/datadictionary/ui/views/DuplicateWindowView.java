package com.navistar.datadictionary.ui.views;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.ui.PlatformUI;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.IconsPathConstant;
import com.navistar.datadictionary.constant.MatlabScriptConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.daoimpl.MatlabCommunicationDaoImpl;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.serviceimpl.OpenComponentServiceImpl;
import com.navistar.datadictionary.serviceimpl.ResolveInconsistencyServiceImpl;
import com.navistar.datadictionary.util.CreateMatlabRequest;
import com.navistar.datadictionary.util.JSONUtil;
import com.navistar.datadictionary.util.SwtResourceManagerUtils;

public class DuplicateWindowView {

	protected Shell shlDuplicateDataObjects;

	private Table table;
	/**
	 * Open the window.
	 */
	public void openWindow(List<DuplicateObjects> list) {
		Display display = Display.getDefault();
		createContents(list);
		shlDuplicateDataObjects.open();
		shlDuplicateDataObjects.layout();
		while (!shlDuplicateDataObjects.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents(List<DuplicateObjects> list) {
		Image appIconImage = new Image(PlatformUI.getWorkbench().getDisplay(),
				SearchResultView.class.getResourceAsStream(IconsPathConstant.DATA_DD_ICON));

		shlDuplicateDataObjects = new Shell(PlatformUI.getWorkbench().getDisplay(),SWT.ON_TOP | SWT.TITLE | SWT.CLOSE | SWT.MIN | SWT.MAX | SWT.RESIZE);
		shlDuplicateDataObjects.setSize(535, 255);
		shlDuplicateDataObjects.setText("Duplicate data objects");
		shlDuplicateDataObjects.setLayout(null);
		shlDuplicateDataObjects.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		shlDuplicateDataObjects.setImage(appIconImage);

		Label lblComponent = new Label(shlDuplicateDataObjects, SWT.NONE);
		lblComponent.setBounds(10, 10, 391, 22);
		lblComponent.setFont(SwtResourceManagerUtils.getFont("Work Sans", 10, SWT.NORMAL));
		lblComponent.setText("Component : "+new OpenComponentServiceImpl().getOpenedComponentName());
		lblComponent.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		final TableViewer viewer = new TableViewer(shlDuplicateDataObjects);
		table = viewer.getTable();
		table.setBounds(30, 38, 461, 127);
		table.setFont(SwtResourceManagerUtils.getFont("Work Sans", 10, SWT.NORMAL));
		viewer.getTable().setHeaderVisible(true);
		viewer.getTable().setLinesVisible(true);
		viewer.setContentProvider(new ArrayContentProvider());
		viewer.getTable().setToolTipText("");

		TableColumn column1 = new TableColumn(viewer.getTable(), SWT.NONE);
		column1.setText("             Signals           ");
		column1.setWidth(224);
		TableViewerColumn signalCol = new TableViewerColumn(viewer, column1);
		signalCol.setLabelProvider(new ColumnLabelProvider(){
			@Override
			public String getText(Object element) {
				DuplicateObjects p = (DuplicateObjects)element;
				return p.getSignals();
			}
		});
		TableColumn column2 = new TableColumn(viewer.getTable(), SWT.NONE);
		column2.setText("              Ports               ");
		column2.setWidth(216);
		TableViewerColumn portsCol = new TableViewerColumn(viewer, column2);
		portsCol.setLabelProvider(new ColumnLabelProvider(){
			@Override
			public String getText(Object element) {
				DuplicateObjects p = (DuplicateObjects)element;
				return p.getPorts();
			}
		});

		Button btnFindInModel = new Button(shlDuplicateDataObjects, SWT.NONE);
		btnFindInModel.setFont(SwtResourceManagerUtils.getFont("Work Sans", 10, SWT.NORMAL));
		btnFindInModel.setBounds(154, 181, 108, 25);
		btnFindInModel.setText("Find In Model");
		btnFindInModel.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent arg0) {
				int index = table.getSelectionIndex();
				TableItem item = table.getItem(index);
				String objName = item.getText();
				try {
					performFindInModel(objName);
				} catch (MatlabCommunicatinException e) {
					MessageDialog.openConfirm(new Shell(), "Error Message", e.getMessage());
				}
				shlDuplicateDataObjects.close();

			}

			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {
				// TODO Auto-generated method stub

			}
		});
		Button btnSkip = new Button(shlDuplicateDataObjects, SWT.NONE);
		btnSkip.setFont(SwtResourceManagerUtils.getFont("Work Sans", 10, SWT.NORMAL));
		btnSkip.setBounds(279, 181, 75, 25);
		btnSkip.setText("Skip");
		btnSkip.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent arg0) {
				shlDuplicateDataObjects.close();
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {
				// TODO Auto-generated method stub
			}
		});

		viewer.setInput(list);    
	}
	
	/**
	 * Method used to find the data object name in model
	 * @param objName
	 * @throws MatlabCommunicatinException
	 */
	private void performFindInModel(String objName) throws MatlabCommunicatinException {
		String modelPath = new OpenComponentServiceImpl().getOpenedComponentPath();
		modelPath = modelPath.replace("\\", "/");
		CategoryAttributes category = new CategoryAttributes();
		category.setName(objName);
		String projectPath = ProjectExplorerView.getActiveProject().getPath().replace("\\", "/");
		Gson gson = new Gson();
		String jsonStr = gson.toJson(category);
		jsonStr = "["+jsonStr+"]";
		String matlabQuery = CreateMatlabRequest.createMatlabRequest(MatlabScriptConstant.FIND_IN_MODEL, modelPath+","+projectPath, jsonStr);
		MatlabCommunicationDaoImpl matlabDataRequest = new MatlabCommunicationDaoImpl();
		JsonElement jsonElement = null;
		try
		{
			jsonElement = matlabDataRequest.executeMatlabRequest(matlabQuery);	
		}
		catch(MatlabCommunicatinException e)
		{
			throw new MatlabCommunicatinException(e.getMessage(), e);
		}

		Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
		if(!JSONUtil.checkErrorCodeForNoModel(jsonElement))
		{
			MessageDialog.openInformation(shell,ApplicationConstant.INFORMATION,MessageConstant.MODEL_NOT_FOUND);
		}else {
			if(!JSONUtil.checkForErrorCode(jsonElement))
			{
				MessageDialog.openInformation(shell,ApplicationConstant.INFORMATION,MessageConstant.OBJECT_NOT_FOUND);
			}
			if(!JSONUtil.checkForNoMsgException(jsonElement)) {
				if (jsonElement != null && jsonElement.isJsonArray()) {
					JsonElement jsonElement1 = jsonElement.getAsJsonArray().get(0);
					if (jsonElement1.isJsonObject()) {
						if (jsonElement1.getAsJsonObject().has("modelData")) {
							String msgException = jsonElement1.getAsJsonObject().get("modelData").getAsString();
							MessageDialog.openInformation(shell,ApplicationConstant.INFORMATION,msgException);
						}
					}
				}
			}
		}
	}

	/**
	 * Class used to distinguish the data object name into categories - Local - signal and Input/Output - port
	 * @author nikitak1
	 *
	 */
	private static class DuplicateObjects
	{
		String signals;
		String ports;

	//	DuplicateObjects(){}

		/**
		 * Getters
		 * @return
		 */
		public String getSignals() {
			return signals;
		}

		public String getPorts() {
			return ports;
		}

		/**
		 * Setters
		 * @param signals
		 */
		public void setSignals(String signals) {
			this.signals = signals;
		}

		public void setPorts(String ports) {
			this.ports = ports;
		}
	}

	/**
	 * Method used to set data for opening window for Duplicate data objects
	 * @param inconsistencyMap
	 */
	public void setUIContents(Map<String, List<CategoryAttributes>> inconsistencyMap) {
		ResolveInconsistencyServiceImpl resolveInconsObj= new ResolveInconsistencyServiceImpl();
		if(resolveInconsObj.duplObject){
			if(!inconsistencyMap.get("Duplicate data objects").isEmpty()){
				List<DuplicateObjects> list = getDupObject(inconsistencyMap);
				openWindow(list);
			}
		}
	}

	/**
	 * Method used to separate the data objects into Local and Input/Output category
	 * @param inconsistencyMap
	 */
	private List<DuplicateObjects> getDupObject(Map<String, List<CategoryAttributes>> inconsistencyMap) {
		List<DuplicateObjects> dupList = new ArrayList<>();
		
		for (String warning : inconsistencyMap.keySet()) {
			List<CategoryAttributes> inconsistencyList = inconsistencyMap.get(warning);
			boolean warningFlag = true;
			if (warningFlag && warning.equals("Duplicate data objects")) {
				for (Iterator<CategoryAttributes> iterator = inconsistencyList.iterator(); iterator.hasNext();) {
					CategoryAttributes category = (CategoryAttributes) iterator.next();
					{
						DuplicateObjects obj = new DuplicateObjects();
						String objName = category.getName();
						String categoryName = category.getCategory();
						if(categoryName.equals("Local")) {
							obj.setSignals(objName);
							obj.setPorts(objName);
							dupList.add(obj);
						}
					}
				}
			}
		}
		return dupList;
	}

}