package com.navistar.datadictionary.ui.views;

import java.util.Optional;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.ViewPart;

import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.ui.nattable.CreateNatTable;
import com.navistar.datadictionary.util.DataDictionaryUtil;
import com.navistar.datadictionary.util.SwtResourceManagerUtils;

/**
 * Class used for creating Min Max Range Info View
 * 
 * @author JAYSHRIVISHB
 *
 */
public class MinMaxInfoView extends ViewPart {
	public MinMaxInfoView() {
	}

	/** Used to get the table editor id */
	public static final String MIN_MAX_INFO_ID = ViewIDConstant.MIN_MAX_INFO;
	private static Text txtDataObjectName;
	private static Text txtDescription;
	private static Text textMinimum;
	private static Text textMaximum;
	private static Text textBaseType;
	private static Text textOpDataType;
	private static Text textSigndeness;
	private static Text textWordLength;
	private static Text textOffset;
	private static Text textSlope;
	public static Text textOuputMinimum;
	public static Text textOutputMaximum;

	/**
	 * This method is used to create the Min Max viewpart with its default setting
	 * 
	 * @param parent
	 */
	@Override
	public void createPartControl(Composite parent) {
		parent.setLayout(new FormLayout());

		Label lblDataObject = new Label(parent, SWT.NONE);
		lblDataObject.setAlignment(SWT.CENTER);
		lblDataObject.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 11, SWT.NORMAL));
		FormData formData = new FormData();
		formData.top = new FormAttachment(0, 10);
		formData.left = new FormAttachment(0, 10);
		lblDataObject.setLayoutData(formData);
		lblDataObject.setText("Data Object:");

		txtDataObjectName = new Text(parent, SWT.BORDER | SWT.WRAP);
		txtDataObjectName.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 11, SWT.NORMAL));
		txtDataObjectName.setEnabled(false);
		FormData fdDataObjNam = new FormData();
		fdDataObjNam.right = new FormAttachment(lblDataObject, 141, SWT.RIGHT);
		fdDataObjNam.top = new FormAttachment(0, 10);
		fdDataObjNam.left = new FormAttachment(lblDataObject, 6);
		txtDataObjectName.setLayoutData(fdDataObjNam);

		Label lblDescription = new Label(parent, SWT.NONE);
		lblDescription.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 11, SWT.NORMAL));
		lblDescription.setAlignment(SWT.CENTER);
		FormData fdLblDesc = new FormData();
		fdLblDesc.top = new FormAttachment(lblDataObject, 0, SWT.TOP);
		fdLblDesc.left = new FormAttachment(txtDataObjectName, 6);
		lblDescription.setLayoutData(fdLblDesc);
		lblDescription.setText("Description:");

		txtDescription = new Text(parent, SWT.BORDER | SWT.MULTI);
		txtDescription.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 11, SWT.NORMAL));
		txtDescription.setEnabled(false);
		FormData fdTextDesc = new FormData();
		fdTextDesc.top = new FormAttachment(lblDataObject, -3, SWT.TOP);
		fdTextDesc.right = new FormAttachment(100, -61);
		txtDescription.setLayoutData(fdTextDesc);

		Label lblMin = new Label(parent, SWT.NONE);
		lblMin.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 11, SWT.NORMAL));
		lblMin.setAlignment(SWT.CENTER);
		FormData fdLblMin = new FormData();
		fdLblMin.top = new FormAttachment(lblDataObject, 13);
		fdLblMin.left = new FormAttachment(lblDataObject, 0, SWT.LEFT);
		lblMin.setLayoutData(fdLblMin);
		lblMin.setText("Minimum:");

		Label lblMaximum = new Label(parent, SWT.NONE);
		lblMaximum.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 11, SWT.NORMAL));
		lblMaximum.setAlignment(SWT.CENTER);
		FormData fdLblMax = new FormData();
		fdLblMax.top = new FormAttachment(lblMin, 0, SWT.TOP);
		fdLblMax.left = new FormAttachment(lblDescription, 0, SWT.LEFT);
		lblMaximum.setLayoutData(fdLblMax);
		lblMaximum.setText("Maximum:");

		textMinimum = new Text(parent, SWT.BORDER);
		textMinimum.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 11, SWT.NORMAL));
		textMinimum.setEnabled(false);
		FormData fdTextMin = new FormData();
		fdTextMin.right = new FormAttachment(txtDataObjectName, 0, SWT.RIGHT);
		fdTextMin.top = new FormAttachment(lblMin, -3, SWT.TOP);
		fdTextMin.left = new FormAttachment(txtDataObjectName, 0, SWT.LEFT);
		textMinimum.setLayoutData(fdTextMin);

		textMaximum = new Text(parent, SWT.BORDER);
		fdTextDesc.left = new FormAttachment(textMaximum, 0, SWT.LEFT);
		textMaximum.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 11, SWT.NORMAL));
		textMaximum.setEnabled(false);
		FormData fdTextMax = new FormData();
		fdTextMax.top = new FormAttachment(lblMin, -3, SWT.TOP);
		fdTextMax.right = new FormAttachment(100, -61);
		textMaximum.setLayoutData(fdTextMax);

		Label lblBaseType = new Label(parent, SWT.NONE);
		lblBaseType.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 11, SWT.NORMAL));
		FormData fdLblBaseTy = new FormData();
		fdLblBaseTy.top = new FormAttachment(lblMin, 12);
		fdLblBaseTy.left = new FormAttachment(lblDataObject, 0, SWT.LEFT);
		lblBaseType.setLayoutData(fdLblBaseTy);
		lblBaseType.setText("Base type:");

		textBaseType = new Text(parent, SWT.BORDER);
		textBaseType.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 11, SWT.NORMAL));
		textBaseType.setEnabled(false);
		FormData fdTextBaseTy = new FormData();
		fdTextBaseTy.right = new FormAttachment(txtDataObjectName, 0, SWT.RIGHT);
		fdTextBaseTy.top = new FormAttachment(textMinimum, 6);
		fdTextBaseTy.left = new FormAttachment(txtDataObjectName, 0, SWT.LEFT);
		textBaseType.setLayoutData(fdTextBaseTy);

		Label lblOutputDataType = new Label(parent, SWT.NONE);
		lblOutputDataType.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 11, SWT.NORMAL));
		FormData fdLblOutDataTy = new FormData();
		fdLblOutDataTy.top = new FormAttachment(lblBaseType, 0, SWT.TOP);
		fdLblOutDataTy.left = new FormAttachment(lblDescription, 0, SWT.LEFT);
		lblOutputDataType.setLayoutData(fdLblOutDataTy);
		lblOutputDataType.setText("Output Data Type:");

		textOpDataType = new Text(parent, SWT.BORDER);
		fdTextMax.left = new FormAttachment(textOpDataType, 0, SWT.LEFT);
		textOpDataType.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 11, SWT.NORMAL));
		textOpDataType.setEnabled(false);
		FormData fdTextOutDataTy = new FormData();
		fdTextOutDataTy.top = new FormAttachment(lblBaseType, -3, SWT.TOP);
		fdTextOutDataTy.left = new FormAttachment(lblOutputDataType, 6);
		fdTextOutDataTy.right = new FormAttachment(100, -61);
		textOpDataType.setLayoutData(fdTextOutDataTy);

		Label lblDataTypeAssist = new Label(parent, SWT.SEPARATOR | SWT.HORIZONTAL);
		lblDataTypeAssist.setText("Data Type Assist");
		FormData fdLblDtaTypAst = new FormData();
		fdLblDtaTypAst.top = new FormAttachment(textBaseType, 6);
		fdLblDtaTypAst.left = new FormAttachment(0);
		fdLblDtaTypAst.right = new FormAttachment(100);
		lblDataTypeAssist.setLayoutData(fdLblDtaTypAst);

		Label lblSignedness = new Label(parent, SWT.NONE);
		fdLblDtaTypAst.bottom = new FormAttachment(lblSignedness, -3);
		lblSignedness.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 11, SWT.NORMAL));
		FormData fdLblSigndnes = new FormData();
		fdLblSigndnes.top = new FormAttachment(0, 112);
		fdLblSigndnes.left = new FormAttachment(lblDataObject, 0, SWT.LEFT);
		lblSignedness.setLayoutData(fdLblSigndnes);
		lblSignedness.setText("Signedness:");

		textSigndeness = new Text(parent, SWT.BORDER);
		textSigndeness.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 11, SWT.NORMAL));
		textSigndeness.setEnabled(false);
		FormData fdTextSignes = new FormData();
		fdTextSignes.top = new FormAttachment(lblSignedness, -3, SWT.TOP);
		fdTextSignes.left = new FormAttachment(lblSignedness, 11);
		fdTextSignes.right = new FormAttachment(txtDataObjectName, 0, SWT.RIGHT);
		textSigndeness.setLayoutData(fdTextSignes);

		Label lblWordLength = new Label(parent, SWT.NONE);
		lblWordLength.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 11, SWT.NORMAL));
		FormData fdLblWordLen = new FormData();
		fdLblWordLen.top = new FormAttachment(lblSignedness, 0, SWT.TOP);
		fdLblWordLen.left = new FormAttachment(lblDescription, 0, SWT.LEFT);
		lblWordLength.setLayoutData(fdLblWordLen);
		lblWordLength.setText("Word Length:");

		textWordLength = new Text(parent, SWT.BORDER);
		textWordLength.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 11, SWT.NORMAL));
		textWordLength.setEnabled(false);
		FormData fdTextWordLen = new FormData();
		fdTextWordLen.top = new FormAttachment(lblSignedness, -3, SWT.TOP);
		fdTextWordLen.right = new FormAttachment(txtDescription, 2, SWT.RIGHT);
		fdTextWordLen.left = new FormAttachment(txtDescription, 0, SWT.LEFT);
		textWordLength.setLayoutData(fdTextWordLen);

		Label lblOffset = new Label(parent, SWT.NONE);
		lblOffset.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 11, SWT.NORMAL));
		FormData fdLblOffset = new FormData();
		fdLblOffset.top = new FormAttachment(lblSignedness, 13);
		fdLblOffset.left = new FormAttachment(lblDataObject, 0, SWT.LEFT);
		lblOffset.setLayoutData(fdLblOffset);
		lblOffset.setText("Offset:");

		textOffset = new Text(parent, SWT.BORDER);
		textOffset.setEnabled(false);
		textOffset.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 11, SWT.NORMAL));
		FormData fdTextOffst = new FormData();
		fdTextOffst.top = new FormAttachment(lblOffset, -3, SWT.TOP);
		fdTextOffst.right = new FormAttachment(txtDataObjectName, -1, SWT.RIGHT);
		fdTextOffst.left = new FormAttachment(textSigndeness, 0, SWT.LEFT);
		textOffset.setLayoutData(fdTextOffst);

		Label lblNewLabel = new Label(parent, SWT.NONE);
		lblNewLabel.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 11, SWT.NORMAL));
		FormData fdlblNewLbl = new FormData();
		fdlblNewLbl.bottom = new FormAttachment(lblOffset, 0, SWT.BOTTOM);
		fdlblNewLbl.left = new FormAttachment(lblDescription, 0, SWT.LEFT);
		lblNewLabel.setLayoutData(fdlblNewLbl);
		lblNewLabel.setText("Slope:");

		textSlope = new Text(parent, SWT.BORDER);
		textSlope.setEnabled(false);
		textSlope.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 11, SWT.NORMAL));
		FormData fdTextSlope = new FormData();
		fdTextSlope.right = new FormAttachment(textWordLength, 0, SWT.RIGHT);
		fdTextSlope.top = new FormAttachment(textWordLength, 7);
		fdTextSlope.left = new FormAttachment(txtDescription, 0, SWT.LEFT);
		textSlope.setLayoutData(fdTextSlope);

		Label label = new Label(parent, SWT.SEPARATOR | SWT.HORIZONTAL);
		label.setText("Data Type Assist");
		FormData fdLabel = new FormData();
		fdLabel.bottom = new FormAttachment(textOffset, 23, SWT.BOTTOM);
		fdLabel.top = new FormAttachment(textOffset, 18);
		fdLabel.right = new FormAttachment(lblDataTypeAssist, 0, SWT.RIGHT);
		fdLabel.left = new FormAttachment(lblDataTypeAssist, 0, SWT.LEFT);
		label.setLayoutData(fdLabel);

		Label lblNewLabel1 = new Label(parent, SWT.NONE);
		lblNewLabel1.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 11, SWT.NORMAL));
		FormData fdLblNewLabel1 = new FormData();
		fdLblNewLabel1.top = new FormAttachment(label, 6);
		fdLblNewLabel1.left = new FormAttachment(lblDataObject, 0, SWT.LEFT);
		lblNewLabel1.setLayoutData(fdLblNewLabel1);
		lblNewLabel1.setText("Representable Minimum:");

		Label lblNewLabel2 = new Label(parent, SWT.NONE);
		lblNewLabel2.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 11, SWT.NORMAL));
		FormData fdLblNewLabel2 = new FormData();
		fdLblNewLabel2.top = new FormAttachment(lblNewLabel1, 12);
		fdLblNewLabel2.left = new FormAttachment(lblDataObject, 0, SWT.LEFT);
		lblNewLabel2.setLayoutData(fdLblNewLabel2);
		lblNewLabel2.setText("Representable Maximum:");

		textOuputMinimum = new Text(parent, SWT.BORDER);
		textOuputMinimum.setEnabled(false);
		textOuputMinimum.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 11, SWT.NORMAL));
		FormData fdTextOutMin = new FormData();
		fdTextOutMin.right = new FormAttachment(textWordLength, 0, SWT.RIGHT);
		fdTextOutMin.top = new FormAttachment(label, 3);
		fdTextOutMin.left = new FormAttachment(lblNewLabel1, 6);
		textOuputMinimum.setLayoutData(fdTextOutMin);

		textOutputMaximum = new Text(parent, SWT.BORDER);
		textOutputMaximum.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 11, SWT.NORMAL));
		textOutputMaximum.setEnabled(false);
		FormData fdTextOutMax = new FormData();
		fdTextOutMax.right = new FormAttachment(txtDescription, 2, SWT.RIGHT);
		fdTextOutMax.top = new FormAttachment(textOuputMinimum, 9);
		fdTextOutMax.left = new FormAttachment(lblNewLabel2, 3);
		textOutputMaximum.setLayoutData(fdTextOutMax);

	}

	/**
	 * This method asks this part to take focus within the workbench. Workbench will
	 * call this method automatically.
	 */
	@Override
	public void setFocus() {
		// nothing to clean up
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Object getAdapter(Class arg0) {
		return null;
	}

	/**
	 * Method used to set the data on min max fields
	 * 
	 * @param selectedRowIndex
	 */
	public void setData(int selectedRowIndex) {
		// Get the active Editor
		CategoryEditor activeEditor = (CategoryEditor) PlatformUI.getWorkbench().getActiveWorkbenchWindow()
				.getActivePage().getActiveEditor();
		if(selectedRowIndex < activeEditor.createNatTable.getDataLayer().getRowCount()) {
			float offset = 0; 
			float slope = 0;
			// Initialize values in variables
			String dataObjectName = Optional.ofNullable((String) activeEditor.createNatTable.getJsonDataProvider()
					.getDataValue(CreateNatTable.colNameIdx, selectedRowIndex)).orElse("");
			String description = Optional.ofNullable((String) activeEditor.createNatTable.getJsonDataProvider()
					.getDataValue(CreateNatTable.colDescIdx, selectedRowIndex)).orElse("");
			String minimum = Optional.ofNullable((String) activeEditor.createNatTable.getJsonDataProvider()
					.getDataValue(CreateNatTable.colMinIdx, selectedRowIndex)).orElse("");
			String maximum = Optional.ofNullable((String) activeEditor.createNatTable.getJsonDataProvider()
					.getDataValue(CreateNatTable.colMaxIdx, selectedRowIndex)).orElse("");
			String baseType = Optional.ofNullable((String) activeEditor.createNatTable.getJsonDataProvider()
					.getDataValue(CreateNatTable.colBaseTyIdx, selectedRowIndex)).orElse("");
			/*float offset = Float.parseFloat(Optional.ofNullable((String) activeEditor.createNatTable.getJsonDataProvider()
				.getDataValue(CreateNatTable.COLUMN_OFFSET_INDEX, selectedRowIndex)).orElse("0"));
		float slope = Float.parseFloat(Optional.ofNullable((String) activeEditor.createNatTable.getJsonDataProvider()
				.getDataValue(CreateNatTable.COLUMN_SLOPE_INDEX, selectedRowIndex)).orElse("0"));*/

			String offsetString = Optional.ofNullable((String) activeEditor.createNatTable.getJsonDataProvider()
					.getDataValue(CreateNatTable.colOffIdx, selectedRowIndex)).orElse("0");

			String slopeString = Optional.ofNullable((String) activeEditor.createNatTable.getJsonDataProvider()
					.getDataValue(CreateNatTable.colSlopIdx, selectedRowIndex)).orElse("0");

			//slope should allow only positive decimal digits and integers
			//if(slopeString.matches("[+-]?[0-9]*\\.?[0-9]*")) {
			if(slopeString.matches("^-?[0-9|[[+-]\\d*]|([Ee][+-]?[0-9]+)|\\d+.\\d+\\[|\\]]+$")) {
				slope = Float.parseFloat(Optional.ofNullable((String) activeEditor.createNatTable.getJsonDataProvider()
						.getDataValue(CreateNatTable.colSlopIdx, selectedRowIndex)).orElse("0"));
			}

			//offset should allow negative integers and decimals
			//if(offsetString.matches("[+-]?[0-9]*\\.?[0-9]*")) {
			if(offsetString.matches("^-?[0-9|[[+-]\\d*]|([Ee][+-]?[0-9]+)|\\d+.\\d+\\[|\\]]+$")) {	
				offset = Float.parseFloat(Optional.ofNullable((String) activeEditor.createNatTable.getJsonDataProvider()
						.getDataValue(CreateNatTable.colOffIdx, selectedRowIndex)).orElse("0"));
			}

			String wordLength = baseType.replaceAll("[^0-9]", "");
			String signedness = "";
			String outputDataType = "";
			String value = "";
			String outputMinimum = DataDictionaryUtil.getOutputMinimum(baseType, slope);
			String outputMaximum = DataDictionaryUtil.getOutputMaximum(baseType, slope);
			double fractionLength = (Math.log(1 / slope)) / Math.log(2);
			// Check for signed and unsigned
			if (!baseType.equals("single") && !baseType.equals("boolean")) {
				if (baseType.startsWith("u")) {
					signedness = "Unsigned";
					value = "0";
				} else {
					signedness = "Signed";
					value = "1";
				}
			} else if (baseType.equals("single")) {
				outputMinimum = "-3.40282e+38";
				outputMaximum = "3.40282e+38";
			} else if (baseType.equals("boolean")) {
				outputMinimum = "0";
				outputMaximum = "1";
			}

			if (offset == 0 && slope == 1) {
				outputDataType = baseType;
			} else if (offset==0 && fractionLength%1 == 0 ) {
				//String fractionLengthStr = Double.toString(Math.round(fractionLength));
				outputDataType = "fixdt(" + value + "," + wordLength + "," + fractionLength + ")";

				double precision = 1 / (Math.pow(2, Math.round(fractionLength)));
				if(Double.isNaN(fractionLength)) {
					outputMinimum = "cannot evaluate";
					outputMaximum = "cannot evaluate";
				} else {
					outputMinimum = DataDictionaryUtil.getOutputMinimumFdt3(baseType, precision);
					outputMaximum = DataDictionaryUtil.getOutputMaximumFdt3(baseType, precision);
				}
			} else {
				outputDataType = "fixdt(" + value + "," + wordLength + "," + slope + "," + offset + ")";
				if(slope <= 0) {
					outputMinimum = "cannot evaluate";
					outputMaximum = "cannot evaluate";
				} else {
					outputMinimum = DataDictionaryUtil.getOutputMinimumFdt4(baseType, slope, offset);
					outputMaximum = DataDictionaryUtil.getOutputMaximumFdt4(baseType, slope, offset);
				}
			}

			txtDataObjectName.setText(dataObjectName);
			txtDescription.setText(description);
			textMinimum.setText(minimum);
			textMaximum.setText(maximum);
			textBaseType.setText(baseType);
			textOffset.setText(Float.toString(offset));
			textSlope.setText(Float.toString(slope));

			textSigndeness.setText(signedness);
			textWordLength.setText(wordLength);
			textOpDataType.setText(outputDataType);

			textOuputMinimum.setText(outputMinimum);
			textOutputMaximum.setText(outputMaximum);
		}

	}
}