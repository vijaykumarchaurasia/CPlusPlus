package com.navistar.datadictionary.ui.views;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.part.ViewPart;

import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;

/**
 * Class used for creating Welcome Note ViewPart in the existing workspace
 * @author minalc
 *
 */
public class WelcomeNoteView extends ViewPart{
	
	/** Default Constructor */
	public WelcomeNoteView() {
	}

	/**
	 * This method is used to create Welcome Note viewpart
	 * with its default setting
	 * @param parent
	 */
	@Override
	public void createPartControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NONE);
		container.setLayout(new GridLayout(3, false));
		Label lblDeptNo = new Label(container, SWT.NONE);
		lblDeptNo.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false,
				false, 1, 1));
		new Label(container, SWT.NONE);
		Composite composite = new Composite(container, SWT.NONE);
		Label lblNewLabel = new Label(composite, SWT.NONE);
		lblNewLabel.setBounds(28, 21, 245, 17);
		lblNewLabel.setText("Welcome To Data Dictionary.");

	}

	@Override
	public void setFocus() {
		// nothing to clean up
	}

	/**
	 * This method is overridden to un-check the Welcome Note view option from the file menu
	 */
	@Override
	public void dispose() {
		ApplicationActionBarAdvisor.getInstance().welcomeNoteAction.setChecked(false);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Object getAdapter(Class arg0) {

		return null;
	}
}
