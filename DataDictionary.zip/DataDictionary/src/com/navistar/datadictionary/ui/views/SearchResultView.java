package com.navistar.datadictionary.ui.views;

import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.layout.GridLayoutFactory;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.ViewPart;

import com.navistar.datadictionary.action.OpenProjectAction;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.IconsPathConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.customexception.EditorInitilizationException;
import com.navistar.datadictionary.customexception.EditorReuseException;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.service.EditorService;
import com.navistar.datadictionary.service.OpenComponentService;
import com.navistar.datadictionary.serviceimpl.EditorServiceImpl;
import com.navistar.datadictionary.serviceimpl.OpenComponentServiceImpl;
import com.navistar.datadictionary.ui.config.Activator;
import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.ui.config.DataDictionaryApplication;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.util.SwtResourceManagerUtils;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Class used for creating search result ViewPart in the existing workspace
 * 
 * @author vijayk13
 *
 */
public class SearchResultView extends ViewPart implements MouseListener{

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(SearchResultView.class);

	/** SearchResultView instance */
	private static SearchResultView searchViewInst;

	/** Search Result View parent */
	private Composite parent;

	/** Parent Tree */
	private Tree tree;
	
	public boolean isSearchdDtaBlue;

	/** constructor */
	public static SearchResultView getSearchResultViewInstance() {
		return searchViewInst;
	}
	 

	private org.eclipse.swt.graphics.Font fontStyle;
	/**
	 * This method is used to create search result viewpart with its default setting
	 * 
	 * @param parent
	 */
	@Override
	public void createPartControl(Composite parent) {
		searchViewInst = this;
		this.parent = parent;
		Display display = PlatformUI.getWorkbench().getDisplay();
		Image searchResultImage = new Image(display,
				SearchResultView.class.getResourceAsStream(IconsPathConstant.SEARCH_RESULT));
		fontStyle  = new org.eclipse.swt.graphics.Font(parent.getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None);
		CLabel searchResultLabel = new CLabel(parent, SWT.NONE);
		searchResultLabel.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 10, SWT.BOLD));
		searchResultLabel.setText(ApplicationConstant.LBLSEARCHRESULT);
		searchResultLabel.setImage(searchResultImage);
		createSearchPartControl();
	}

	/**
	 * This method is used to get searched result and display it on Search view
	 */
	public void createSearchPartControl() {

		displaySearchResults(DataDictionaryApplication.getApplication().getSearchedDataList());
		GridLayoutFactory.fillDefaults().generateLayout(parent);

	}

	/**
	 * Method is used to display Search Results.
	 * 
	 * @param searchedComponentList
	 */
	private void displaySearchResults(List<CategoryAttributes> searchCompList) {		

		Display display = PlatformUI.getWorkbench().getDisplay();

		Image categoryImage = new Image(display,
				SearchResultView.class.getResourceAsStream(IconsPathConstant.COMMON_WINDOW));
		Image dataObjectImage = new Image(display,
				SearchResultView.class.getResourceAsStream(IconsPathConstant.ICON_INPUT_OUTPUT));
		Image componentImage = new Image(display,
				SearchResultView.class.getResourceAsStream(IconsPathConstant.ICON_COMPONENT));
		Image notFoundImage = new Image(display, SearchResultView.class.getResourceAsStream(IconsPathConstant.ICON_ARROW));
		// Check if view is already available
		tree = new Tree(parent, SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL);
		tree.setSize(290, 260);
		tree.addMouseListener(this);
		parent.setSize(300, 330);

		TreeItem componentItem = null;
		TreeItem categoryItem = null;
		Map<String,TreeItem> componentMap = new HashMap<String,TreeItem>();

		// Check for searched data
		if (searchCompList != null && !searchCompList.isEmpty()) {
			// Iterate Data object list
			for (Iterator<CategoryAttributes> iterator = searchCompList.iterator(); iterator.hasNext();) {
				CategoryAttributes category = (CategoryAttributes) iterator.next();

				if(componentMap.get(category.getComponent())!=null)
				{
					TreeItem componentTreeItem = componentMap.get(category.getComponent());
					TreeItem[] categoryItems = componentTreeItem.getItems();

					boolean addCategory = true;
					for (TreeItem categoryTreeItem : categoryItems) {
						if(categoryTreeItem.getText().equals(category.getCategory()))
						{
							TreeItem dataObjectItem = new TreeItem(categoryTreeItem, 0);
							dataObjectItem.setImage(dataObjectImage);
							dataObjectItem.setText(category.getName());
							dataObjectItem.setFont(fontStyle);
							addCategory = false;
							break;
						}						
					}

					if(addCategory)
					{
						categoryItem = new TreeItem(componentTreeItem, 0);
						categoryItem.setImage(categoryImage);
						categoryItem.setText(category.getCategory());
						categoryItem.setFont(fontStyle);
						TreeItem dataObjectItem = new TreeItem(categoryItem, 0);
						dataObjectItem.setImage(dataObjectImage);
						dataObjectItem.setText(category.getName());
						dataObjectItem.setFont(fontStyle);

					}


				}else
				{
					TreeItem dataObjectItem = null;
					componentItem = new TreeItem(tree, 0);
					componentItem.setImage(componentImage);
					componentItem.setText(category.getComponent());
					componentItem.setFont(fontStyle);
					componentMap.put(category.getComponent(), componentItem);

					categoryItem = new TreeItem(componentItem, 0);
					categoryItem.setImage(categoryImage);
					categoryItem.setText(category.getCategory());
					categoryItem.setFont(fontStyle);
					dataObjectItem = new TreeItem(categoryItem, 0);
					dataObjectItem.setImage(dataObjectImage);
					dataObjectItem.setText(category.getName());
					dataObjectItem.setFont(fontStyle);
				}			
			}
		} else {
			//if data unavailable
			componentItem = new TreeItem(tree, 0);
			componentItem.setImage(notFoundImage);
			componentItem.setText(MessageConstant.SEARCH_NOT_FOUND);
			componentItem.setFont(fontStyle);
		}

	}

	/**
	 * This method is used to focus the Search View
	 */
	@Override
	public void setFocus() {
		// nothing to clean up
	}

	/**
	 * This method is overridden to un-check the search result view option from the
	 * file menu
	 */
	@Override
	public void dispose() {
		searchViewInst = null;
		ApplicationActionBarAdvisor.getInstance().searchWindowObj.setChecked(false);
	}

	/**
	 * This method is used to get adapter for Search View
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Object getAdapter(Class arg0) {
		return null;
	}

	@Override
	public void mouseDoubleClick(MouseEvent event) {

		final TreeItem item;
		if(tree.getSelection().length>0)
		{
			item = tree.getSelection()[0];
		}
		else
		{
			return;
		}		

		if(item.getItemCount() == 0)
		{	        	  
			// Closing all open editors
			
			String selectedComponent = item.getParentItem().getParentItem().getText();
			String category = item.getParentItem().getText();
			String dataObject = item.getText();
			String openComponent = new OpenComponentServiceImpl().getOpenedComponentName();		

			CategoryAttributes catAttributes = new CategoryAttributes();
			catAttributes.setComponent(selectedComponent);
			catAttributes.setCategory(category);
			catAttributes.setName(dataObject);
			DataDictionaryApplication.getApplication().setSearchedHighlighted(catAttributes);
			DataDictionaryApplication.getApplication().setSearchedHighLight(true);

			IWorkbenchPage activePage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();			

			// Highlight using open component Data
			if(selectedComponent.equals(openComponent))
			{
				IEditorReference[] editors = activePage.getEditorReferences(); 		
				if(editors.length <= 1)
				{
					
					openSearchedComponent();
					ApplicationActionBarAdvisor.getInstance().filterAction.setImageDescriptor(Activator.getImageDescriptor("/icons/filter.png"));
					ApplicationActionBarAdvisor.getInstance().filterAction.setEnabled(true);
				}
				for (IEditorReference editor : editors) {					

					if(editor.getEditor(false) instanceof CategoryEditor && category.equals(editor.getTitle()))
					{

						CategoryEditor categoryEditor = (CategoryEditor) editor.getEditor(false);
						activePage.activate(categoryEditor);			
						categoryEditor.addNatTableConfiguration();
						isSearchdDtaBlue = true;
						categoryEditor.natTable.refresh();
					}

				}

			}
			// Call goes to Matlab, fetch the data and then highlight
			else
			{
				OpenProjectAction.openProjectFlag = false;
				openSearchedComponent();
				ApplicationActionBarAdvisor.getInstance().filterAction.setImageDescriptor(Activator.getImageDescriptor("/icons/filter.png"));
				ApplicationActionBarAdvisor.getInstance().filterAction.setEnabled(true);

				IEditorReference[] editors = activePage.getEditorReferences(); 		
				for (IEditorReference editor : editors) {

					if(editor.getEditor(false) instanceof CategoryEditor && category.equals(editor.getTitle()))
					{
						CategoryEditor categoryEditor = (CategoryEditor) editor.getEditor(false);
						activePage.activate(categoryEditor);
						DataDictionaryApplication.getApplication().setSearchedHighLight(true);
						categoryEditor.addNatTableConfiguration();
						isSearchdDtaBlue = true;
						categoryEditor.natTable.refresh();
					}

				}


			}		

		}

	}

	/**
	 * Method used to open the searched component
	 */
	private void openSearchedComponent()
	{

		EditorService editorService = new EditorServiceImpl();
		// Close all existing editors if any
		editorService.closeAllEditors();

		try {

			OpenComponentService openCompService = new OpenComponentServiceImpl();
			// Open a categories of selected component in editors
			openCompService.openComponentInEditor(ProjectExplorerView.viewer);
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [INFO]: Component Opened : "+openCompService.getOpenedComponentName());
			}
		} catch (FileNotFoundException e) {
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [ERROR]: "+e.getMessage());
			}
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			MessageDialog.openConfirm(new Shell(), "Error Message","Component Not Found");
		}
		catch (MatlabCommunicatinException e) {
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [ERROR]: "+e.getMessage());
			}
			MessageDialog.openConfirm(new Shell(), "Error Message", e.getMessage());
		} catch (EditorReuseException e) {
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [ERROR]: "+e.getMessage());
			}
			MessageDialog.openConfirm(new Shell(), "Error Message", e.getMessage());
		} catch (EditorInitilizationException e) {
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [ERROR]: "+e.getMessage());
			}
			MessageDialog.openConfirm(new Shell(), "Error Message", e.getMessage());
		}

	}

	@Override
	public void mouseDown(MouseEvent event) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseUp(MouseEvent event) {
		// TODO Auto-generated method stub

	}
}
