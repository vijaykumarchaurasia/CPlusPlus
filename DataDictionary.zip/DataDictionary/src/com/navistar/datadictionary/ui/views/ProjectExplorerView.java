package com.navistar.datadictionary.ui.views;

import java.io.File;
import java.io.FileNotFoundException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.jface.action.GroupMarker;
import org.eclipse.jface.action.IMenuListener;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.ViewPart;

import com.google.gson.JsonElement;
import com.google.gson.reflect.TypeToken;
import com.navistar.datadictionary.action.AlphabeticalViewAction;
import com.navistar.datadictionary.action.ApplyCdfxAction;
import com.navistar.datadictionary.action.CheckComponentInputsAction;
import com.navistar.datadictionary.action.CloseProjectAction;
import com.navistar.datadictionary.action.EditorPreference;
import com.navistar.datadictionary.action.ExcelImportExportAction;
import com.navistar.datadictionary.action.HierarchicalViewAction;
import com.navistar.datadictionary.action.IOInconsistency;
import com.navistar.datadictionary.action.ImportProjectAction;
import com.navistar.datadictionary.action.OpenComponentAction;
import com.navistar.datadictionary.action.OpenProjectAction;
import com.navistar.datadictionary.action.RemoveProjectAction;
import com.navistar.datadictionary.action.UpdateCompParaTypeAction;
import com.navistar.datadictionary.action.ValidateCompAction;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.IconsPathConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.customexception.EditorInitilizationException;
import com.navistar.datadictionary.customexception.EditorReuseException;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.model.FontStyleDAO;
import com.navistar.datadictionary.model.Node;
import com.navistar.datadictionary.model.Project;
import com.navistar.datadictionary.service.ChangeViewService;
import com.navistar.datadictionary.serviceimpl.ChangeViewServiceImpl;
import com.navistar.datadictionary.serviceimpl.CloseProjectServiceImpl;
import com.navistar.datadictionary.serviceimpl.EditorServiceImpl;
import com.navistar.datadictionary.serviceimpl.ImportProjectServiceImpl;
import com.navistar.datadictionary.serviceimpl.OpenComponentServiceImpl;
import com.navistar.datadictionary.serviceimpl.OpenProjectServiceImpl;
import com.navistar.datadictionary.ui.config.Activator;
import com.navistar.datadictionary.ui.config.Application;
import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.ui.config.DataDictionaryApplication;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.ui.provider.CustomLabelProvider;
import com.navistar.datadictionary.ui.provider.TreeContentProvider;
import com.navistar.datadictionary.util.GsonUtil;
import com.navistar.datadictionary.util.NodeComparator;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Class used for creating Project Explorer ViewPart in the existing workspace
 * including project import/open functionality
 * 
 * @author minalc
 *
 */
public class ProjectExplorerView extends ViewPart{

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(ProjectExplorerView.class);

	/** Used to display project in tree format */
	public static TreeViewer viewer;

	/** Used to initiate open project call */
	private OpenProjectAction openProjectAction ;

	/** Used to initiate close project call */
	private CloseProjectAction closeProjAction;

	/** Used to initiate remove project call */
	private RemoveProjectAction removeProjAction ;

	/** Used to initiate open component call */
	private OpenComponentAction openCompAction;
	
	/** Used to initiate import project call and its 
	 * methods
	 */
	private ImportProjectAction importProjAction;

	/** Used to initiate open project service calls */
	private OpenProjectServiceImpl openProjService;

	/** Used to initiate close project service calls */
	private CloseProjectServiceImpl closeProjService;

	/** Used to initiate open component service calls */
	private OpenComponentServiceImpl openCompService;

	/** Used to access check editors */
	private EditorServiceImpl editorService;
	
	/** Used to initiate import project service calls */
	private ImportProjectServiceImpl importUtilService; 

	/** Used to perform resolve inconsistency operation */
	private IOInconsistency resolveInconObj;

	/** Used to perform check component operation */
	public CheckComponentInputsAction checkCompInObj;
	
	/** Used to perform project related operation */
	@SuppressWarnings("unused")
	private Project project;

	/** Used to handle project list */
	public List<Node> viewNodeList;
	
	/** Used with view change operation to highlight project */
	public String previousCompName = "";
	
	/** Flag used to indicate view change*/
	public static Boolean hierarchialView = false;
	
	private Type type = new TypeToken<List<CategoryAttributes>>(){}.getType();
	
	public HierarchicalViewAction hierarchiViewObj;
	
	public AlphabeticalViewAction alphabeticalObj;
	
	private static ProjectExplorerView projExpViewInst;
	
	private ExcelImportExportAction importExportObj;
	
	private ApplyCdfxAction applyCdfxAction;
	
	private ValidateCompAction vaCompAction;
	
	/** Used to perform validate component parameter type operation */
	public UpdateCompParaTypeAction updateCompParaTypeAction;
	
	/**
	 * Constructor
	 */
	public ProjectExplorerView() {
			//Add the non static local instance variables here
		openCompAction = new OpenComponentAction();
		openProjService = new OpenProjectServiceImpl();
		closeProjService = new CloseProjectServiceImpl();
		openCompService = new OpenComponentServiceImpl();
		editorService = new EditorServiceImpl();
		resolveInconObj = new IOInconsistency();
		checkCompInObj = new CheckComponentInputsAction();
		importUtilService = new ImportProjectServiceImpl();
		importProjAction = new ImportProjectAction();
		hierarchiViewObj = new HierarchicalViewAction();
		alphabeticalObj = new AlphabeticalViewAction();
		importExportObj = new ExcelImportExportAction();
		applyCdfxAction = new ApplyCdfxAction();
		vaCompAction = new ValidateCompAction();
		updateCompParaTypeAction= new UpdateCompParaTypeAction();
		LOGGER.info("Project Explorer Constructor Intialized");	
		projExpViewInst = this;
	}
	
	public static ProjectExplorerView getInstance()
	{
		return projExpViewInst;
	}

	/**
	 * This method is create the project explorer viewpart with its default setting
	 * 
	 * @param parent
	 */
	@Override
	public void createPartControl(Composite parent) {
		Image windowTitleImage = new Image(PlatformUI.getWorkbench().getDisplay(), ProjectExplorerView.class.getResourceAsStream(IconsPathConstant.PROJ_EXPLORER));
		this.setTitleImage(windowTitleImage);
		LOGGER.info("Project Explorer View Intialization Started");
		
		hierarchiViewObj.setText("Hierarchical View");
		hierarchiViewObj.setEnabled(false);
		
		
		alphabeticalObj.setText("Alphabetical View");
		alphabeticalObj.setEnabled(false);
		
		IActionBars actionBars = getViewSite().getActionBars();
		IMenuManager dropDownMenu = actionBars.getMenuManager();
		
		dropDownMenu.add(hierarchiViewObj);
		dropDownMenu.add(alphabeticalObj);
	
		parent.setLayout(new FillLayout());

		viewer = new TreeViewer(parent, SWT.MULTI | SWT.H_SCROLL | SWT.V_SCROLL);
		viewer.setContentProvider(new TreeContentProvider());
		viewer.setLabelProvider(new CustomLabelProvider());
		
		MenuManager contextMenu = new MenuManager("#ViewerMenu"); 
		contextMenu.setRemoveAllWhenShown(true);
		viewer.addSelectionChangedListener(new ISelectionChangedListener() {
			@Override
			public void selectionChanged(SelectionChangedEvent arg0) {
				try {
					String selectedProject = "";
					String selectedComponent = "";
					//OpenComponentServiceImpl openComponentServiceImpl = new OpenComponentServiceImpl();
					for (String projectPath : DataDictionaryApplication.getApplication().projStatusMap.keySet()) {
						String folder[] = projectPath.split("\\\\");
						String projectName = folder[folder.length - 1];
						//Get the current selection
						IStructuredSelection thisSelection = (IStructuredSelection) viewer.getSelection();
						Node selectedNode = (Node) thisSelection.getFirstElement();
						if (selectedNode != null) {
							selectedProject =  selectedNode.getName();
							if (projectName.equals(selectedProject)) {
								if (DataDictionaryApplication.getApplication().projStatusMap.get(projectPath).getStatus() == 0) {
									ApplicationActionBarAdvisor.getInstance().closeProjAction.setEnabled(false);
								}
								else {
									ApplicationActionBarAdvisor.getInstance().closeProjAction.setEnabled(true);
									//ApplicationActionBarAdvisor.getInstance().searchAction.setEnabled(true);
								}
							}
							if(selectedNode.getParent()!=null){
								selectedComponent = selectedNode.getName();
								//selectedComponent = selectedNode.getSubCategories().get(0).toString();
								IEditorPart activeEditor = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
										.getActiveEditor();
								
								if(!openCompService.getOpenedComponentPath().equals("")){
									if(activeEditor instanceof CategoryEditor && selectedComponent.equals(openCompService.getOpenedComponentName())){
										ApplicationActionBarAdvisor.getInstance().resolvInconObj.setEnabled(true);
										resolveInconObj.setEnabled(true);
									//	if(Application.configCatList.contains("Input") && Application.configCatList.contains("Output")) {
											checkCompInObj.setEnabled(true);
											updateCompParaTypeAction.setEnabled(false);
											if(Application.programName.equals("E95"))
											{
											ApplicationActionBarAdvisor.getInstance().excelImportExport.setEnabled(false);
											}
											else {
												ApplicationActionBarAdvisor.getInstance().excelImportExport.setEnabled(true);	
											}
											importExportObj.setEnabled(true);
									//	}
										applyCdfxAction.setEnabled(true);
										vaCompAction.setEnabled(true);
										
									}
									else{
										ApplicationActionBarAdvisor.getInstance().resolvInconObj.setEnabled(false);
										resolveInconObj.setEnabled(false);
										checkCompInObj.setEnabled(false);
										ApplicationActionBarAdvisor.getInstance().excelImportExport.setEnabled(false);
										importExportObj.setEnabled(false);
										applyCdfxAction.setEnabled(false);
										vaCompAction.setEnabled(false);
										updateCompParaTypeAction.setEnabled(true);
									}
								}
							}
							
							
						}
					}
					
				}
				catch(Exception exception) {
					LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, exception);
					if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
						ActivityLogView.activityLog.append("\n [ERROR]: "+MessageConstant.MENU_INIT_ERROR);
					}
					MessageDialog.openError(new Shell(), "ERROR", MessageConstant.MENU_INIT_ERROR);
				}
			}
		});

		// Performing Operation on the Double Click of a project
		performDoubleClickOp();
		
		contextMenu.addMenuListener(new IMenuListener() {
			@Override
			public void menuAboutToShow(IMenuManager mgr) {
				fillContextMenu(mgr);
			}
		});
		Menu menu = contextMenu.createContextMenu(viewer.getControl());
		viewer.getControl().setMenu(menu);
		viewer.getControl().setLayoutData(parent);
		LOGGER.info("Project Explorer View Intialization Completed");
	}

	/**
	 * 
	 */
	private void performDoubleClickOp() {
		viewer.addDoubleClickListener(new IDoubleClickListener() {
			@Override
			public void doubleClick(DoubleClickEvent event) {
				{	
					try {
						TreeViewer viewer = (TreeViewer) event.getViewer();
						IStructuredSelection thisSelection = (IStructuredSelection) event.getSelection();
						Node selectedNode = (Node) thisSelection.getFirstElement();

						// Check if the project is selected
						if (null == selectedNode.getParent()) {
							performOpenProjectDoubleClk(selectedNode);

						}
						else if(selectedNode.getSubCategories() == null){
							performOpenCompDoubleClk(viewer, selectedNode);
						}

						//ApplicationActionBarAdvisor.getInstance().ioCompatAction.setEnabled(true);	
						ApplicationActionBarAdvisor.getInstance().searchAction.setEnabled(true);
						ApplicationActionBarAdvisor.getInstance().validProjAction.setEnabled(true);
						
					}
					catch(Exception exception){
						LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, exception);
						if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
							ActivityLogView.activityLog.append("\n [ERROR]: "+exception.getMessage());
						}
						MessageDialog.openError(new Shell(), "ERROR", exception.getMessage());
					}
				}
			}

			/**
			 * @param selectedNode
			 * @throws Exception 
			 */
			private void performOpenProjectDoubleClk(Node selectedNode) throws Exception {
				
				//OpenComponentServiceImpl.selCompName="";
				Application.programName=null;
				boolean status = openProjService.performOpenProjectAction(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor());
				if(!status) {	
					Project project = ProjectExplorerView.getActiveProject();
					String prjpath=project.getPath().replace("\\", "/");
					Application.programName= new EditorServiceImpl().getConfigProjDataFrMatlab(prjpath);
					if(Application.programName == null) {
						MessageDialog.openError(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), "Error", "Program name not present in sldd file");
						PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell().setText("Data Dictionary");
						return;
					}else if(Application.programName.equals("1003")) {
						MessageDialog.openError(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), "Error", "Program name not present in sldd file");
						PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell().setText("Data Dictionary");
						return;
					}else if(Application.programName.equals("1004")) {
						MessageDialog.openError(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), "Error", "More than one program names found in sldd file");
						PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell().setText("Data Dictionary");
						return;
					}
					PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell().setText("Data Dictionary : Currently selected project is - "+Application.programName);
					ViewUtil.disableIOFeatures();
					OpenProjectAction.openProjectFlag = true;
					LOGGER.info("Opening Project (Double Click)");
					if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
						LOGGER.info("Project Opened (Double Click)");
						ActivityLogView.activityLog.append("\n [INFO]: Project Opened : "+selectedNode.getName());
						ActivityLogView.activityLog.append("\n [INFO]: Opened project path : "+getActiveProject().getPath());
					}
					if(hierarchialView) {
						hierarchiViewObj.performHierarchicalAction();
					}else {
						alphabeticalObj.performAlphabeticalAction();
					}

					//ApplicationActionBarAdvisor.getInstance().ioCompatAction.setEnabled(true);
					ApplicationActionBarAdvisor.getInstance().searchAction.setEnabled(true);
					ApplicationActionBarAdvisor.getInstance().resolvInconObj.setEnabled(false);
					ApplicationActionBarAdvisor.getInstance().excelImportExport.setEnabled(false);
					ApplicationActionBarAdvisor.getInstance().validProjAction.setEnabled(false);
					//ApplicationActionBarAdvisor.getInstance().validateProjParaTypeAction.setEnabled(true);
				}else {
					if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
						ActivityLogView.activityLog.append("\n [INFO]: Open Project operation cancelled");
					}
				}
			}

			/**
			 * @param viewer
			 * @param selectedNode
			 * @throws FileNotFoundException
			 * @throws MatlabCommunicatinException
			 * @throws EditorReuseException
			 * @throws EditorInitilizationException
			 */
			private void performOpenCompDoubleClk(TreeViewer viewer, Node selectedNode) throws FileNotFoundException,
					MatlabCommunicatinException, EditorReuseException, EditorInitilizationException {
				OpenProjectAction.openProjectFlag = false;
				LOGGER.info("Opening Component (Double Click)");
				DataDictionaryApplication.getApplication().setSearchedHighLight(false);
				DataDictionaryApplication.getApplication().setSearchedHighlighted(null);

				if (editorService.checkForUnsavedEditors()) {
					performOpOnUnsavedComponent(viewer, selectedNode);
				} else {
					performOpOnSavedComponent(viewer, selectedNode);
				}
			}

			/**
			 * @param viewer
			 * @param selectedNode
			 * @throws FileNotFoundException
			 * @throws MatlabCommunicatinException
			 * @throws EditorReuseException
			 * @throws EditorInitilizationException
			 */
			private void performOpOnSavedComponent(TreeViewer viewer, Node selectedNode) throws FileNotFoundException,
					MatlabCommunicatinException, EditorReuseException, EditorInitilizationException {
				// Close all existing editors if any
				editorService.closeAllEditors();
				// Open a categories of selected component in editors
				Application.count=-1;
				boolean status = openCompService.openComponentInEditor(viewer);
				ApplicationActionBarAdvisor.getInstance().filterAction.setImageDescriptor(Activator.getImageDescriptor("/icons/filter.png"));
				ApplicationActionBarAdvisor.getInstance().filterAction.setEnabled(true);
				if(status && ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
					LOGGER.info("Component Opened (Double Click)");
					ActivityLogView.activityLog.append("\n [INFO]: Component Opened: "+selectedNode.getName());
				}
			}

			/**
			 * @param viewer
			 * @param selectedNode
			 * @throws FileNotFoundException
			 * @throws MatlabCommunicatinException
			 * @throws EditorReuseException
			 * @throws EditorInitilizationException
			 */
			private void performOpOnUnsavedComponent(TreeViewer viewer, Node selectedNode) throws FileNotFoundException,
					MatlabCommunicatinException, EditorReuseException, EditorInitilizationException {
				IEditorPart activeEditor = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
						.getActiveEditor();
				CategoryEditor categoryEditor = (CategoryEditor) activeEditor;

				int result = closeProjService.closeProjectHandler(false,2);

				// if user choose to save the data
				if (result == 0  && !categoryEditor.emptyFieldFlag) {
					performOpOnSavedComponent(viewer, selectedNode);
				}else if(result == 1){
					//remove unsaved changes and load category with saved data
					editorService.removeDirtyIndicator();
					performOpOnSavedComponent(viewer, selectedNode);
				}
			}
		});
	}

	/**
	 * Method used to highlight the project after project view 
	 * changes
	 * @param projectName
	 */
	private void highLightProject(String projectName) {
		try {
			TreeItem[] item2 = viewer.getTree().getItems();
			Device device = PlatformUI.getWorkbench().getDisplay();
			Color closeProjectColor = new Color(device, ApplicationConstant.CLOSE_PROJ_COLOR, ApplicationConstant.CLOSE_PROJ_COLOR, ApplicationConstant.CLOSE_PROJ_COLOR);
			FontStyleDAO fontStyle = DataDictionaryApplication.getApplication().fontStyle;
			Font fontStyleNormal;
			Font fontStyleBold;
			Color openProjectColor;
			if(fontStyle != null && fontStyle.getFont() != null && !EditorPreference.isDefFontSel) {
				fontStyleNormal = new Font(device, fontStyle.getFont(), fontStyle.getSize(), SWT.NORMAL);
				fontStyleBold = new Font(device, fontStyle.getFont(),fontStyle.getSize(), SWT.BOLD);
				openProjectColor = new Color(device, fontStyle.getFontColor());
			} else {
				fontStyleNormal = new Font(device, ApplicationConstant.HIGHLIGHTFONTSTYL, ApplicationConstant.HIGHFONTSIZE, SWT.NORMAL);
				fontStyleBold = new Font(device, ApplicationConstant.HIGHLIGHTFONTSTYL,ApplicationConstant.HIGHFONTSIZE, SWT.BOLD);
				openProjectColor = new Color(device, ApplicationConstant.OPEN_PROJ_COLOR,ApplicationConstant.OPEN_PROJ_COLOR, ApplicationConstant.OPEN_PROJ_COLOR);
			}
			for (TreeItem treeItem : item2) {
				// To make closed project non-highlighted(grey)
				treeItem.setForeground(closeProjectColor);
				treeItem.setFont(fontStyleNormal);
				if (projectName.equals(treeItem.getText())) {
					// To make open project highlighted(black)
					treeItem.setForeground(openProjectColor);
					treeItem.setFont(fontStyleBold);
					break;
				}
			}
		}
		catch(Exception exception) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, exception);
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [ERROR]: "+MessageConstant.PROJ_HIGH_ERROR);
			}
			MessageDialog.openError(new Shell(), "ERROR",MessageConstant.PROJ_HIGH_ERROR);
		}
	}

	/**
	 * Method to return project details.
	 * 
	 * @return project
	 */
	public static Project getActiveProject() {
		try {
			Project project = null;
			for (Map.Entry<String, Project> entry : DataDictionaryApplication.getApplication().projStatusMap.entrySet()) {
				if (entry.getValue().getStatus() == 1) {
					project = entry.getValue();
				}
			}
			return project;
		}
		catch(Exception exception) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, exception);
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [ERROR]: "+exception.getMessage());
			}
			return null;
		}
	}

	@Override
	public void setFocus() {
		// Override Method of View Part
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Object getAdapter(Class arg0) {
		// Override Method of View Part
		return null;
	}

	/**
	 * This Method is to get the context menu actions and disable the Open and Close
	 * project option accordingly
	 * 
	 * @param contextMenu
	 */
	protected void fillContextMenu(IMenuManager contextMenu) {
		try {
			IStructuredSelection thisSelection = (IStructuredSelection) viewer.getSelection();
			Node selectedNode = (Node) thisSelection.getFirstElement();
			if(selectedNode!=null)
			{
				// Check if the project is selected
				if (null == selectedNode.getParent()) {

					contextMenu.add(new GroupMarker(IWorkbenchActionConstants.MB_ADDITIONS));
					openProjectAction = new OpenProjectAction();
					openProjectAction.setText(ApplicationConstant.OPEN_PROJECT);
					contextMenu.add(openProjectAction);

					closeProjAction = new CloseProjectAction();
					closeProjAction.setText(ApplicationConstant.CLOSE_PROJECT);
					contextMenu.add(closeProjAction);

					removeProjAction = new RemoveProjectAction();
					removeProjAction.setText(ApplicationConstant.REMOVE_PROJECT);
					contextMenu.add(removeProjAction);

					makeContextMenuEnableDisable(thisSelection, importUtilService, selectedNode);

				} else if(selectedNode.getSubCategories() == null) {
					String selectedComponent = "";
					contextMenu.add(new GroupMarker(IWorkbenchActionConstants.MB_ADDITIONS));
					openCompAction = new OpenComponentAction(viewer);
					openCompAction.setText(ApplicationConstant.OPEN_COMPONENT);
					contextMenu.add(openCompAction);

					contextMenu.add(new GroupMarker(IWorkbenchActionConstants.MB_ADDITIONS));
					resolveInconObj.setText(ApplicationConstant.RESOLVEINCONSIST);
					contextMenu.add(resolveInconObj);
					
					contextMenu.add(new GroupMarker(IWorkbenchActionConstants.MB_ADDITIONS));
					importExportObj.setText("Resolve Inconsistency using Excel");
					contextMenu.add(importExportObj);

					contextMenu.add(new GroupMarker(IWorkbenchActionConstants.MB_ADDITIONS));
					checkCompInObj.setText(ApplicationConstant.CHECKCOMPIN);
					checkCompInObj.setId(ViewIDConstant.COMP_INPUTS);
					contextMenu.add(checkCompInObj);
					
					contextMenu.add(new GroupMarker(IWorkbenchActionConstants.MB_ADDITIONS));
					applyCdfxAction.setText("Apply CDF");
					contextMenu.add(applyCdfxAction);
					
					contextMenu.add(new GroupMarker(IWorkbenchActionConstants.MB_ADDITIONS));
					vaCompAction.setText("Validate Component");
					contextMenu.add(vaCompAction);
					
					/*contextMenu.add(new GroupMarker(IWorkbenchActionConstants.MB_ADDITIONS));
					validateCompParaTypeAction = new ValidateCompParaTypeAction(viewer);
					validateCompParaTypeAction.setText("Update Component's Parameter Type");
					contextMenu.add(validateCompParaTypeAction);
					validateCompParaTypeAction.setEnabled(false);*/
					
					project = getActiveProject();
					
					IEditorPart activeEditor = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
							.getActiveEditor();
					selectedComponent = selectedNode.getName();
					if(!openCompService.getOpenedComponentPath().equals("")){
						if(activeEditor instanceof CategoryEditor && selectedComponent.equals(openCompService.getOpenedComponentName())){
							ApplicationActionBarAdvisor.getInstance().resolvInconObj.setEnabled(true);
							resolveInconObj.setEnabled(true);
							
							if(Application.configCatList.contains("Input") && Application.configCatList.contains("Output")) {
								
								ApplicationActionBarAdvisor.getInstance().excelImportExport.setEnabled(true);
								importExportObj.setEnabled(true);
								updateCompParaTypeAction.setEnabled(false);
							}else {
								
								ApplicationActionBarAdvisor.getInstance().excelImportExport.setEnabled(false);
								importExportObj.setEnabled(false);
								updateCompParaTypeAction.setEnabled(true);
							}
							checkCompInObj.setEnabled(true);
							applyCdfxAction.setEnabled(true);
							vaCompAction.setEnabled(true);
							
							
						}
						else{
							ApplicationActionBarAdvisor.getInstance().resolvInconObj.setEnabled(false);
							resolveInconObj.setEnabled(false);
							checkCompInObj.setEnabled(false);
							ApplicationActionBarAdvisor.getInstance().excelImportExport.setEnabled(false);
							importExportObj.setEnabled(false);
							applyCdfxAction.setEnabled(false);
							vaCompAction.setEnabled(false);
							updateCompParaTypeAction.setEnabled(false);
						}
					}else{
						ApplicationActionBarAdvisor.getInstance().resolvInconObj.setEnabled(false);
						resolveInconObj.setEnabled(false);
						checkCompInObj.setEnabled(false);
						ApplicationActionBarAdvisor.getInstance().excelImportExport.setEnabled(false);
						importExportObj.setEnabled(false);
						applyCdfxAction.setEnabled(false);
						vaCompAction.setEnabled(false);
						updateCompParaTypeAction.setEnabled(false);
					}
				}
			}
			else
			{
					ImportProjectAction importProjAction = new ImportProjectAction();
					contextMenu.add(new GroupMarker(IWorkbenchActionConstants.MB_ADDITIONS));
					importProjAction.setText(ApplicationConstant.IMPORT_PROJECT);
					contextMenu.add(importProjAction);
					

			}
		}
		catch(Exception exception) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, exception);
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [ERROR]: "+MessageConstant.MENU_FILL_ERROR);
			}
			MessageDialog.openError(new Shell(), "ERROR",MessageConstant.MENU_FILL_ERROR);
		}
	}


	/**
	 * Method used to make context menu enable disable depending on project status and selection
	 * @param thisSelection
	 * @param importUtilService
	 * @param selectedNode
	 * @param removeEnableStatus
	 */
	private void makeContextMenuEnableDisable(IStructuredSelection thisSelection,
			ImportProjectServiceImpl importUtilService, Node selectedNode) {
		try {
			//Multiple selection 
			if(thisSelection.size()>1) {
				boolean removeEnbStatus = true;
				TreeItem[] treeItems = viewer.getTree().getSelection();

				for(TreeItem item : treeItems){
					if ((importUtilService.getProjectStatus(item.getText())) == 1){
						removeEnbStatus = false;
					}
				}

				if(removeEnbStatus){
					//If no any project is in open state then enable remove
					openProjectAction.setEnabled(false);
					closeProjAction.setEnabled(false);
					removeProjAction.setEnabled(true);
				}else{
					//If any project is in open state then disable remove
					openProjectAction.setEnabled(false);
					//closeProjAction.setEnabled(false);
					closeProjAction.setEnabled(true);
					removeProjAction.setEnabled(false);
				}			
			}else {
				// enable/disable open and close project options
				if ((importUtilService.getProjectStatus(selectedNode.getName())) == 1) {
					openProjectAction.setEnabled(false);
					closeProjAction.setEnabled(true);
					removeProjAction.setEnabled(false);
				} else {
					openProjectAction.setEnabled(true);
					closeProjAction.setEnabled(false);
					removeProjAction.setEnabled(true);
				}
			}
		}
		catch(Exception exception) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, exception);
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [ERROR]: "+MessageConstant.MENU_ENABLE_ERROR);
			}
			MessageDialog.openError(new Shell(), "ERROR",MessageConstant.MENU_ENABLE_ERROR);
		}
	}


	/**
	 * This method is overridden to un-check the project explorer view option from
	 * the file menu
	 */
	@Override
	public void dispose() {
		LOGGER.info("Project Explorer View Closed");
		ApplicationActionBarAdvisor.getInstance().projExplorerObj.setChecked(false);
	}
	
	
	/**
	 * Method used to display hierarchical view on project explorer
	 * @param parent
	 * @param componentListmap
	 * @return
	 */
	private List<Node> displayHierarchicalView(Map<String,List<String>> componentListmap)
	{
		try {
			viewer.setContentProvider(new TreeContentProvider());
			viewer.setLabelProvider(new CustomLabelProvider());
			Project project = getActiveProject();
			if(project!=null){
				File parentFile = new File(project.getPath());
				String parentElement = parentFile.getName();
				Node parentNode = new Node(parentElement, null);
				List<Node> componentNodeList = new ArrayList<Node>();
				for (Map.Entry<String,List<String>> entry : componentListmap.entrySet()){  

					Node modeleNode = new Node(entry.getKey(),parentNode);
					List<String> componentList = entry.getValue();			
					Collections.sort(componentList);
					for(String component:componentList)
					{
						new Node(component, modeleNode);							
					}
					Collections.sort(componentNodeList, new NodeComparator());
				} 	
				componentNodeList.add(parentNode);
				return componentNodeList;
			}else{
				return null;
			}
		}
		catch(Exception exception) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, exception);
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [ERROR]: "+MessageConstant.HIERARCHY_ERROR);
			}
			MessageDialog.openError(new Shell(), "ERROR",MessageConstant.HIERARCHY_ERROR);
			return null;
		}
	}
	
	/**
	 * Function used to check if project exist while changing
	 * project explorer view
	 * @param name
	 * @return
	 */
	private boolean checkDuplicateProject(String name){
		try {
			for(int i =0 ; i<viewNodeList.size();i++){
				if(viewNodeList.get(i).getName().equals(name)){
					return true;
				}
			}
			return false;
		}
		catch(Exception exception) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, exception);
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [ERROR]: "+MessageConstant.DUPLICATE_PROJ);
			}
			MessageDialog.openError(new Shell(), "ERROR",MessageConstant.DUPLICATE_PROJ);
			return false;
		}
	}
	
	/**
	 * Method used to change the view of opened project to hierarchical
	 */
	public void changeViewToHierarchical()  {
		JsonElement jsonElement = null;
		LOGGER.info("Matlab Request for View Change Sent");
		// Create matlab request for hierarchical view
		ChangeViewService changeViewService = new ChangeViewServiceImpl();
		try {
			jsonElement = changeViewService.createRequestForHierarchical();
			if(jsonElement!=null) {
				if(jsonElement.getAsJsonArray().get(0).getAsJsonObject().has("errorCode")) {
					String errorCode = jsonElement.getAsJsonArray().get(0).getAsJsonObject().get("errorCode").getAsString();
					if(errorCode.equals("127")) {	
						ViewUtil.dispInfoInMsgDialog("No Hierarchical view available for opened project folder structure");
						return;
					}
				}else {
					LOGGER.info("Response Recieved Succesfully");
					hierarchialView = true;
					if(jsonElement != null){
						List<CategoryAttributes> hierarchiViewList = GsonUtil.provider().fromJSONToList(jsonElement.getAsJsonArray().toString(), type);
						Map<String, List<String>> componentListMap;
						try {
							componentListMap = changeViewService.convertListToMap(hierarchiViewList);
							viewNodeList = displayHierarchicalView(componentListMap);
							LOGGER.info(viewNodeList);
						} catch (Exception exception) {
							LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, exception);
						}					
						LOGGER.info("Switched to Hierarchial View");
						if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {		
							ActivityLogView.activityLog.append("\n [INFO]: Switched to Hierarchial View");
						}
					}
					ProjectExplorerView.getInstance().hierarchiViewObj.setEnabled(false);
					ProjectExplorerView.getInstance().alphabeticalObj.setEnabled(true);
				}
			}else {
				hierarchialView = true;
				LOGGER.info("No hierarchical view for opened project");
				if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {		
					ActivityLogView.activityLog.append("\n [INFO]: No hierarchical view for opened project");
				}
				ProjectExplorerView.getInstance().hierarchiViewObj.setEnabled(false);
				ProjectExplorerView.getInstance().alphabeticalObj.setEnabled(true);
			}
		} catch (MatlabCommunicatinException exception) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, exception);
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [ERROR]: "+MessageConstant.CHANGE_VIEW_ERROR);
			}
			MessageDialog.openError(new Shell(), "ERROR",MessageConstant.CHANGE_VIEW_ERROR+"\n"+exception.getMessage());
		}
		
	}
	
	/**
	 * Method used to change the view of opened project to alphabetical
	 */
	public void changeViewToAlphabetical() {
		Project activeProject = getActiveProject();
		if(activeProject != null && activeProject.getStatus()!=ApplicationConstant.REMOVEPROJSTATUS)
		{
			Node tempNode = null;
			try {
				String key;
				 for (Entry<String, Node> entry : DataDictionaryApplication.projNodeMap.entrySet())
			        {
			            key = entry.getKey();
			            if(key.equals(ProjectExplorerView.getActiveProject().getPath())) {
							 tempNode = entry.getValue();
						 }
			        }
				 
				
			//	tempNode = importUtilService.createTreeStructure(activeProject.getPath(),  activeProject.getStatus());
			} catch (Exception exception) {
				LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, exception);
				if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
					ActivityLogView.activityLog.append("\n [ERROR]: "+MessageConstant.CHANGE_VIEW_ERROR);
				}
				MessageDialog.openError(new Shell(), "ERROR",MessageConstant.CHANGE_VIEW_ERROR);
			}
			viewNodeList.add(tempNode);
			hierarchialView = false;
			LOGGER.info("Opened in Alphabetical View");
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {		
				ActivityLogView.activityLog.append("\n [INFO]: Switched to Alphabetical View");
			}
		}
	}
	
	/**
	 * @param projectName
	 * @param actualComponentName
	 */
	public void displayInExplorer(String projectName, String actualCompName) {
		@SuppressWarnings("unchecked")
		Collection<Node> tempCollection = (Collection<Node>) viewer.getInput();
		for (Node node : tempCollection) {
			if(!checkDuplicateProject(node.getName())){
				viewNodeList.add(node);
			}
		}
		//to sort project nodes in hierarchical view
		Collections.sort(viewNodeList,new NodeComparator());
		viewer.setInput(viewNodeList);
		viewer.expandAll();
		importProjAction.loadProjectStatusFromWorkspace(viewer, viewNodeList);
		if(actualCompName != "") {
			new EditorServiceImpl().highlightComponent(actualCompName,hierarchialView);
		}else if(previousCompName != "") {
			new EditorServiceImpl().highlightComponent(previousCompName,hierarchialView);
		}
		else if(actualCompName=="")
		{
			new EditorServiceImpl().highlightComponent(actualCompName,hierarchialView);
		}
		highLightProject(projectName);
		LOGGER.info("View Switch Complete");
	}
}
