/**
 * 
 */
package com.navistar.datadictionary.ui.views;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.nebula.widgets.nattable.hideshow.command.MultiRowHideCommand;
import org.eclipse.nebula.widgets.nattable.hideshow.command.ShowAllRowsCommand;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.PlatformUI;

import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.IconsPathConstant;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.ui.config.Activator;
import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.ui.nattable.CreateNatTable;
import com.navistar.datadictionary.util.SwtResourceManagerUtils;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Class used to show custom filter pop-up menu
 * @author raeesm
 *
 */
public class CustomFilterWindow  {

	/** Shell */
	protected Shell shell = new Shell(Display.getCurrent(),SWT.ON_TOP);
	
	/** Variable to Check if shell is already open **/
	private static boolean started = false;
	/** Combo Box */
	private Combo conditionACombo;
	
	/** Combo Box */
	private Combo conditionBCombo;
	
	/** Comb Box */
	public Combo columnACombo;
	
	/** Combo Box */
	public Combo columnBCombo;
	
	/** Column Name */
	private String columnName;
	
	/** Category Editor */
	private CategoryEditor categoryEditor;
	
	/** Button */
	private Button andButton;
	
	/** Used to store column data */
	private List <String> categoryValue;
	
	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(CustomFilterWindow.class);
	
	/**
	 * Open the window.
	 */
	public void open(int column) {
		createUIComponents(column);
		fillCombo();
		Display display = Display.getCurrent();
		ViewUtil.setShellPositionAtCenter(display, shell);
		if (!started) {
			shell.open();
			shell.layout();
			shell.setMaximized(false);
			shell.setMinimized(false);

			shell.addDisposeListener(new DisposeListener() {
				@Override
				public void widgetDisposed(DisposeEvent event) {
					if(categoryEditor.createNatTable.getRowHideShowLayer().getHiddenRowIndexes().size() > 0) {
						//Do Nothing
						LOGGER.log(Level.INFO, "Custom filter hidden row indexes are more than 0");
					}
					else {
						CreateNatTable.customFilter.setSelection(false);
					}
					started = false;
				}
			});
			started = true;
			while (!shell.isDisposed()) {
				if (!display.readAndDispatch()) {
					display.sleep();
				}

			}
		}
	}
		
	
	/**
	 * Functions used to fill combo box's
	 */
	private void fillCombo() {
		//List<CategoryAttributes> categoryList = categoryEditor.createNatTable.getCategoryList();
		//after sorting list should get updated
		List<CategoryAttributes> categoryList = categoryEditor.createNatTable.getJsonDataProvider().getList();
		categoryValue = new ArrayList<String>();
		
		switch (columnName) {
		
		case "Name":
			getNameValues(categoryList, categoryValue);
			break;
		
		case "Value":
			getValues(categoryList, categoryValue);
			break;
			
		case "Description":
			getDescriptionValues(categoryList, categoryValue);
			break;
		
		case "Base Type":
			getBaseTypeValues(categoryList, categoryValue);
			break;
		
		case "Offset":
			getOffsetValues(categoryList, categoryValue);
			break;
			
		case "Slope":
			getSlopeValues(categoryList, categoryValue);
			break;
			
		case "Min":
			getMinValues(categoryList, categoryValue);
			break;
			
		case "Max":
			getMaxValues(categoryList, categoryValue);
			break;
			
		case "Unit":
			getUnitValues(categoryList, categoryValue);
			break;
			
		case "Dimensions":
			getDimensionValues(categoryList, categoryValue);
			break;
			
		case "InitialValue":
			getInitialValues(categoryList, categoryValue);
			break;
			
		default:
			break;
		}
		
		addValueInCombo(categoryValue);
	}

	private void getInitialValues(List<CategoryAttributes> categoryList, List<String> categoryValue) {
		for(int i = 0;i<categoryList.size(); i++) {
			categoryValue.add(categoryList.get(i).getInitialValue());
		}
	}

	private void getDimensionValues(List<CategoryAttributes> categoryList, List<String> categoryValue) {
		for(int i = 0;i<categoryList.size(); i++) {
			categoryValue.add(categoryList.get(i).getDimensions());
		}
	}

	private void getUnitValues(List<CategoryAttributes> categoryList, List<String> categoryValue) {
		for(int i = 0;i<categoryList.size(); i++) {
			categoryValue.add(categoryList.get(i).getUnit());
		}
	}

	private void getMaxValues(List<CategoryAttributes> categoryList, List<String> categoryValue) {
		for(int i = 0;i<categoryList.size(); i++) {
			categoryValue.add(categoryList.get(i).getMax());
		}
	}

	private void getMinValues(List<CategoryAttributes> categoryList, List<String> categoryValue) {
		for(int i = 0;i<categoryList.size(); i++) {
			categoryValue.add(categoryList.get(i).getMin());
		}
	}

	private void getSlopeValues(List<CategoryAttributes> categoryList, List<String> categoryValue) {
		for(int i = 0;i<categoryList.size(); i++) {
			categoryValue.add(categoryList.get(i).getSlope());
		}
	}

	private void getOffsetValues(List<CategoryAttributes> categoryList, List<String> categoryValue) {
		for(int i = 0;i<categoryList.size(); i++) {
			categoryValue.add(categoryList.get(i).getOffset());
		}
	}

	private void getBaseTypeValues(List<CategoryAttributes> categoryList, List<String> categoryValue) {
		for(int i = 0;i<categoryList.size(); i++) {
			categoryValue.add(categoryList.get(i).getBaseType());
		}
	}

	private void getDescriptionValues(List<CategoryAttributes> categoryList, List<String> categoryValue) {
		for(int i = 0;i<categoryList.size(); i++) {
			categoryValue.add(categoryList.get(i).getDescription());
		}
	}

	private void getValues(List<CategoryAttributes> categoryList, List<String> categoryValue) {
		for(int i = 0;i<categoryList.size(); i++) {
			categoryValue.add(categoryList.get(i).getValue());
		}
	}

	private void getNameValues(List<CategoryAttributes> categoryList, List<String> categoryValue) {
		for(int i = 0;i<categoryList.size(); i++) {
			categoryValue.add(categoryList.get(i).getName());
		}
	}

	/**
	 * Add the data in combo box
	 * @param categoryValue
	 */
	private void addValueInCombo(List<String> categoryValue) {
		
		for(int i = 0;i<categoryValue.size(); i++) {
			if(columnACombo.indexOf(categoryValue.get(i)) == -1 && !categoryValue.get(i).equals("")) {
				columnACombo.add(categoryValue.get(i));
				columnBCombo.add(categoryValue.get(i));
			}
		}
	}

	/**
	 * Create Custom Filter Window
	 * @param column
	 */
	private void createUIComponents(int column) {
		
		Image appIconImage = new Image(PlatformUI.getWorkbench().getDisplay(),
				SearchResultView.class.getResourceAsStream(IconsPathConstant.DATA_DD_ICON));

		shell = new Shell(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell());
		shell.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		shell.setSize(440, 240);
		shell.setImage(appIconImage);
		shell.setLayout(null);
		
		//Get the Active Editor
		IEditorPart activeEditor = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
				.getActiveEditor();
		categoryEditor = (CategoryEditor) activeEditor;
		
		columnName = (String) categoryEditor.createNatTable.getGridLayer().getDataValueByPosition(column, 0);
		shell.setText(ApplicationConstant.CUSTOM_FILTER + " ("+columnName+")");
		shell.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 11, SWT.None));
		CLabel label = new CLabel(shell, SWT.NONE);
		label.setText("Show rows where:");
		label.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None));
		label.setBounds(5, 10, 150, 10);
		label.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		
		Composite container = new Composite(shell, SWT.BORDER);
		container.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		container.setLocation(10, 30);
		container.setSize(414, 150);
		
		conditionACombo = new Combo(container,SWT.READ_ONLY);
		conditionACombo.setLocation(15, 20);
		conditionACombo.setSize(150, 23);
		conditionACombo.select(0);
		conditionACombo.add("<Select>", 0);
		conditionACombo.add("equals", 1);
		conditionACombo.add("does not equals", 2);
		conditionACombo.add("begins with", 3);
		conditionACombo.add("does not begin with", 4);
		conditionACombo.add("ends with", 5);
		conditionACombo.add("does not end with", 6);
		conditionACombo.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None));
		
		/*conditionACombo.add("is greater than", 2);
		conditionACombo.add("is greater than or equal to",3);
		conditionACombo.add("is less than", 4);
		conditionACombo.add("is less than or equal to", 5);
		conditionACombo.add("contains", 10);
		conditionACombo.add("does not contain", 11);*/
		
		columnACombo = new Combo(container, SWT.NONE);
		columnACombo.setLocation(240, 20);
		columnACombo.setSize(150, 23);
		columnACombo.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None));
		
		columnBCombo = new Combo(container, SWT.NONE);
		columnBCombo.setLocation(240, 100);
		columnBCombo.setSize(150, 23);
		columnBCombo.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None));
		
		conditionBCombo = new Combo(container, SWT.DROP_DOWN | SWT.READ_ONLY);
		conditionBCombo.setLocation(15, 100);
		conditionBCombo.setSize(150, 23);
		conditionBCombo.select(0);
		conditionBCombo.add("<Select>", 0);
		conditionBCombo.add("equals", 1);
		conditionBCombo.add("does not equals", 2);
		conditionBCombo.add("begins with", 3);
		conditionBCombo.add("does not begin with", 4);
		conditionBCombo.add("ends with", 5);
		conditionBCombo.add("does not end with", 6);
		conditionBCombo.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None));
		
		/*conditionBCombo.add("is greater than", 2);
		conditionBCombo.add("is greater than or equal to",3);
		conditionBCombo.add("is less than", 4);
		conditionBCombo.add("is less than or equal to", 5);
		conditionBCombo.add("begins with", 6);
		conditionBCombo.add("does not begin with", 7);
		conditionBCombo.add("ends with", 8);
		conditionBCombo.add("does not end with", 9);
		conditionBCombo.add("contains", 10);
		conditionBCombo.add("does not contain", 11);*/
		
		andButton = new Button(container, SWT.RADIO);
		andButton.setText("AND");
		andButton.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None));
		andButton.setBounds(17, 60, 65, 20);
		andButton.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		
		Button orButton = new Button(container, SWT.RADIO);
		orButton.setText("OR");
		orButton.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None));
		orButton.setBounds(87, 57, 75, 25);
		orButton.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		
		Button okButton = new Button(shell, SWT.PUSH);
		okButton.setText("OK");
		okButton.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None));
		okButton.setBounds(250,182,70,25);
		okButton.addSelectionListener(new SelectionListener() {
			
			@Override
			public void widgetSelected(SelectionEvent event) {
				applyCustomFilter(conditionACombo.getText(),conditionBCombo.getText(),columnACombo.getText(),columnBCombo.getText());
				CreateNatTable.customFilter.setSelection(true);
				ApplicationActionBarAdvisor.getInstance().filterAction.setImageDescriptor(Activator.getImageDescriptor("/icons/filter.png"));
				ApplicationActionBarAdvisor.getInstance().filterAction.setEnabled(false);
				shell.close();
			}
			
			@Override
			public void widgetDefaultSelected(SelectionEvent event) {
				//do nothing
			}
		});
		
		Button cancelButton = new Button(shell, SWT.PUSH);
		cancelButton.setText("Cancel");
		cancelButton.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None));
		cancelButton.setBounds(335,182,70,25);
		cancelButton.addSelectionListener(new SelectionListener() {
			
			@Override
			public void widgetSelected(SelectionEvent event) {
				CreateNatTable.customFilter.setSelection(false);
				shell.close();
			}
			
			@Override
			public void widgetDefaultSelected(SelectionEvent event) {
				//do nothing
			}
		});
	}
	
	/**
	 * Used to Apply custom filter
	 * @param conditionA
	 * @param conditionB
	 * @param valueA
	 * @param valueB
	 */
	private void applyCustomFilter(String conditionA, String conditionB, String valueA, String valueB) {

		int rowCount = categoryEditor.createNatTable.getJsonDataProvider().getRowCount();
		List<Integer> hideRowsList = new ArrayList<Integer>();
		int[] hideRowArray;
		switch (columnName) {
		case "Name":
			hideRowsList = hideRows(conditionA, conditionB, valueA, valueB, categoryValue,rowCount,hideRowsList);
			hideRowArray = hideRowsList.stream().mapToInt(i->i).toArray();
			categoryEditor.createNatTable.getSelectionLayer().doCommand(new ShowAllRowsCommand());
			categoryEditor.createNatTable.getSelectionLayer().doCommand(new MultiRowHideCommand(categoryEditor.createNatTable.getSelectionLayer(), hideRowArray));
			break;
		
		case "Value":
			hideRowsList = hideRows(conditionA, conditionB, valueA, valueB, categoryValue,rowCount,hideRowsList);
			hideRowArray = hideRowsList.stream().mapToInt(i->i).toArray();
			categoryEditor.createNatTable.getSelectionLayer().doCommand(new ShowAllRowsCommand());
			categoryEditor.createNatTable.getSelectionLayer().doCommand(new MultiRowHideCommand(categoryEditor.createNatTable.getSelectionLayer(), hideRowArray));
			break;
			
		case "Description":
			hideRowsList = hideRows(conditionA, conditionB, valueA, valueB, categoryValue,rowCount,hideRowsList);
			hideRowArray = hideRowsList.stream().mapToInt(i->i).toArray();
			categoryEditor.createNatTable.getSelectionLayer().doCommand(new ShowAllRowsCommand());
			categoryEditor.createNatTable.getSelectionLayer().doCommand(new MultiRowHideCommand(categoryEditor.createNatTable.getSelectionLayer(), hideRowArray));
			break;
		
		case "Base Type":
			hideRowsList = hideRows(conditionA, conditionB, valueA, valueB, categoryValue,rowCount,hideRowsList);
			hideRowArray = hideRowsList.stream().mapToInt(i->i).toArray();
			categoryEditor.createNatTable.getSelectionLayer().doCommand(new ShowAllRowsCommand());
			categoryEditor.createNatTable.getSelectionLayer().doCommand(new MultiRowHideCommand(categoryEditor.createNatTable.getSelectionLayer(), hideRowArray));
			break;
		
		case "Offset":
			hideRowsList = hideRows(conditionA, conditionB, valueA, valueB, categoryValue,rowCount,hideRowsList);
			hideRowArray = hideRowsList.stream().mapToInt(i->i).toArray();
			categoryEditor.createNatTable.getSelectionLayer().doCommand(new ShowAllRowsCommand());
			categoryEditor.createNatTable.getSelectionLayer().doCommand(new MultiRowHideCommand(categoryEditor.createNatTable.getSelectionLayer(), hideRowArray));
			break;
			
		case "Slope":
			hideRowsList = hideRows(conditionA, conditionB, valueA, valueB, categoryValue,rowCount,hideRowsList);
			hideRowArray = hideRowsList.stream().mapToInt(i->i).toArray();
			categoryEditor.createNatTable.getSelectionLayer().doCommand(new ShowAllRowsCommand());
			categoryEditor.createNatTable.getSelectionLayer().doCommand(new MultiRowHideCommand(categoryEditor.createNatTable.getSelectionLayer(), hideRowArray));
			break;
			
		case "Min":
			hideRowsList = hideRows(conditionA, conditionB, valueA, valueB, categoryValue,rowCount,hideRowsList);
			hideRowArray = hideRowsList.stream().mapToInt(i->i).toArray();
			categoryEditor.createNatTable.getSelectionLayer().doCommand(new ShowAllRowsCommand());
			categoryEditor.createNatTable.getSelectionLayer().doCommand(new MultiRowHideCommand(categoryEditor.createNatTable.getSelectionLayer(), hideRowArray));
			break;
			
		case "Max":
			hideRowsList = hideRows(conditionA, conditionB, valueA, valueB, categoryValue,rowCount,hideRowsList);
			hideRowArray = hideRowsList.stream().mapToInt(i->i).toArray();
			categoryEditor.createNatTable.getSelectionLayer().doCommand(new ShowAllRowsCommand());
			categoryEditor.createNatTable.getSelectionLayer().doCommand(new MultiRowHideCommand(categoryEditor.createNatTable.getSelectionLayer(), hideRowArray));
			break;
			
		case "Unit":
			hideRowsList = hideRows(conditionA, conditionB, valueA, valueB, categoryValue,rowCount,hideRowsList);
			hideRowArray = hideRowsList.stream().mapToInt(i->i).toArray();
			categoryEditor.createNatTable.getSelectionLayer().doCommand(new ShowAllRowsCommand());
			categoryEditor.createNatTable.getSelectionLayer().doCommand(new MultiRowHideCommand(categoryEditor.createNatTable.getSelectionLayer(), hideRowArray));
			break;
			
		case "Dimensions":
			hideRowsList = hideRows(conditionA, conditionB, valueA, valueB, categoryValue,rowCount,hideRowsList);
			hideRowArray = hideRowsList.stream().mapToInt(i->i).toArray();
			categoryEditor.createNatTable.getSelectionLayer().doCommand(new ShowAllRowsCommand());
			categoryEditor.createNatTable.getSelectionLayer().doCommand(new MultiRowHideCommand(categoryEditor.createNatTable.getSelectionLayer(), hideRowArray));
			break;
			
		case "InitialValue":
			hideRowsList = hideRows(conditionA, conditionB, valueA, valueB, categoryValue,rowCount,hideRowsList);
			hideRowArray = hideRowsList.stream().mapToInt(i->i).toArray();
			categoryEditor.createNatTable.getSelectionLayer().doCommand(new ShowAllRowsCommand());
			categoryEditor.createNatTable.getSelectionLayer().doCommand(new MultiRowHideCommand(categoryEditor.createNatTable.getSelectionLayer(), hideRowArray));
			break;
			
		default:
			break;
		}
	}

	/**
	 * function used to get the filtered rows
	 * to hide
	 * @param conditionA
	 * @param conditionB
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 * @return
	 */
	private List<Integer> hideRows(String conditionA, String conditionB, String valueA, String valueB, List<String> valueList, int rowCount, List<Integer> hideRows) {
		//changed for PMD
		List<Integer> hideRowList = hideRows;
		if(conditionA.equals("equals"))
		{
			hideRowList = checkFilterForEquals(conditionB, valueA, valueB, valueList, rowCount, hideRowList);
		}
		else if(conditionA.equals("does not equals"))
		{
			hideRowList = checkFilterForDoesNotEquals(conditionB, valueA, valueB, valueList, rowCount, hideRowList);
		}
		else if(conditionA.equals("begins with"))
		{
			hideRowList = checkFilterForBeginsWith(conditionB, valueA, valueB, valueList, rowCount, hideRowList);
		}
		else if(conditionA.equals("does not begin with"))
		{
			hideRowList = checkFilterForDoesNotBeginsWith(conditionB, valueA, valueB, valueList, rowCount, hideRowList);
		}
		else if(conditionA.equals("ends with"))
		{
			hideRowList = checkFilterForEndsWith(conditionB, valueA, valueB, valueList, rowCount, hideRowList);
		}
		else if(conditionA.equals("does not end with"))
		{
			hideRowList = checkFilterForDoesNotEndsWith(conditionB, valueA, valueB, valueList, rowCount, hideRowList);
		}
		else if(conditionA.equals("<Select>"))
		{
			hideRowList = checkFilterForSelectBlank(conditionB,  valueB, valueList, rowCount, hideRowList);
		}
		else if(conditionA.equals(""))
		{
			hideRowList = checkFilterForSelectBlank(conditionB, valueB, valueList, rowCount, hideRowList);
		}
		return hideRowList;
	}
	
	private List<Integer> checkFilterForEquals(String conditionB, String valueA, String valueB, List<String> valueList, int rowCount, List<Integer> hideRows)
	{
		switch (conditionB) {
		case "does not equals":
			hideValIfFirstEquSecDoesNotEq(valueA, valueB, valueList, rowCount, hideRows);
			break;

		case "equals" :
			hideValIfFirstEquSecEqu(valueA, valueB, valueList, rowCount, hideRows);
			break;
			
		case "begins with" :
			hideValIfFirstEquSecBeginWith(valueA, valueB, valueList, rowCount, hideRows);
			break;
			
		case "does not begin with" :
			hideValIfFirstEquSecDoesNotBegWith(valueA, valueB, valueList, rowCount, hideRows);
			break;
			
		case "ends with" :
			hideValIfFirstEquSecEndsWith(valueA, valueB, valueList, rowCount, hideRows);
			break;
			
		case "does not end with" :
			hideValIfFirstEquSecDoesNotEndWith(valueA, valueB, valueList, rowCount, hideRows);
			break;
			
		case "<Select>" :
			hideValIfFirstEquSecBlankOrSelect(valueA, valueList, rowCount, hideRows);
			break;
			
		case "" :
			hideValIfFirstEquSecBlankOrSelect(valueA, valueList, rowCount, hideRows);
			break;
			
		default:
			break;
		}
		return hideRows;
		
	}


	/**
	 * @param valueA
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstEquSecBlankOrSelect(String valueA, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		hideValIfFirstSelectSecEq(valueA, valueList, rowCount, hideRows);
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstEquSecDoesNotEndWith(String valueA, String valueB, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).equals(valueA) && !valueList.get(i).endsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).equals(valueA) || !valueList.get(i).endsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstEquSecEndsWith(String valueA, String valueB, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).equals(valueA) && valueList.get(i).endsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).equals(valueA) || valueList.get(i).endsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstEquSecDoesNotBegWith(String valueA, String valueB, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).equals(valueA) && !valueList.get(i).startsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).equals(valueA) || !valueList.get(i).startsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstEquSecBeginWith(String valueA, String valueB, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).equals(valueA) && valueList.get(i).startsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).equals(valueA) || valueList.get(i).startsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstEquSecEqu(String valueA, String valueB, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).equals(valueA) && valueList.get(i).equals(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).equals(valueA) || valueList.get(i).equals(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstEquSecDoesNotEq(String valueA, String valueB, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).equals(valueA) && !valueList.get(i).equals(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).equals(valueA) || !valueList.get(i).equals(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}
	private List<Integer> checkFilterForDoesNotEquals(String conditionB, String valueA, String valueB, List<String> valueList, int rowCount, List<Integer> hideRows)
	{
		switch (conditionB) {
		case "does not equals":
			hideValIfFirstDoesNotEqSecDoesNotEq(valueA, valueB, valueList, rowCount, hideRows);
			break;
		
		case "equals" :
			hideValIfFirstDoesNotEqSecEqu(valueA, valueB, valueList, rowCount, hideRows);
			break;
			
		case "begins with" :
			hideValIfFirstDoesNotEqSecBeginWith(valueA, valueB, valueList, rowCount, hideRows);
			break;
			
		case "does not begin with" :
			hideValIfFirstDoesNotEqSecDoesNotBegWith(valueA, valueB, valueList, rowCount, hideRows);
			break;
			
		case "ends with" :
			hideValIfFirstDoesNotEqSecEndsWith(valueA, valueB, valueList, rowCount, hideRows);
			break;
			
		case "does not end with" :
			hideValIfFirstDoesNotEqSecDoesNotEndWith(valueA, valueB, valueList, rowCount, hideRows);
			break;
			
		case "<Select>" :
			hideValIfFirstDoesNotEqSecBlankOrSelect(valueA, valueList, rowCount, hideRows);
			break;
			
		case "" :
			hideValIfFirstDoesNotEqSecBlankOrSelect(valueA, valueList, rowCount, hideRows);
			break;
			
		default:
			break;
		
		}
		return hideRows;
	
	}


	/**
	 * @param valueA
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstDoesNotEqSecBlankOrSelect(String valueA, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		hideValIfFirstSelectSecDoesNotEq(valueA, valueList, rowCount, hideRows);
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstDoesNotEqSecDoesNotEndWith(String valueA, String valueB, List<String> valueList,
			int rowCount, List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).equals(valueA) && !valueList.get(i).endsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).equals(valueA) || !valueList.get(i).startsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstDoesNotEqSecEndsWith(String valueA, String valueB, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).equals(valueA) && valueList.get(i).endsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).equals(valueA) || valueList.get(i).endsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstDoesNotEqSecDoesNotBegWith(String valueA, String valueB, List<String> valueList,
			int rowCount, List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).equals(valueA) && !valueList.get(i).startsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).equals(valueA) || !valueList.get(i).startsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstDoesNotEqSecBeginWith(String valueA, String valueB, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).equals(valueA) && valueList.get(i).startsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).equals(valueA) || valueList.get(i).startsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstDoesNotEqSecEqu(String valueA, String valueB, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).equals(valueA) && valueList.get(i).equals(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).equals(valueA) || valueList.get(i).equals(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstDoesNotEqSecDoesNotEq(String valueA, String valueB, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).equals(valueA) && !valueList.get(i).equals(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).equals(valueA) || !valueList.get(i).equals(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}
	private List<Integer> checkFilterForBeginsWith(String conditionB, String valueA, String valueB, List<String> valueList, int rowCount, List<Integer> hideRows)
	{
		switch (conditionB) {
		case "does not equals":
			hideValIfFirstBeginWithSecDoesNotEq(valueA, valueB, valueList, rowCount, hideRows);
			break;
		
		case "equals" :
			hideValIfFirstBeginWithSecEq(valueA, valueB, valueList, rowCount, hideRows);
			break;
			
		case "begins with" :
			hideValIfFirstBeginWithSecBeginWith(valueA, valueB, valueList, rowCount, hideRows);
			break;
			
		case "does not begin with" :
			//newly added
			hideValIfFirstBeginWithSecDoesNotBeginWith(valueA, valueB, valueList, rowCount, hideRows);
			break;
			
		case "ends with" :
			hideValIfFirstBeginWithSecEndsWith(valueA, valueB, valueList, rowCount, hideRows);
			break;
			
		case "does not end with" :
			hideValIfFirstBeginWithSecDoesNotEndWit(valueA, valueB, valueList, rowCount, hideRows);
			break;
			
		case "<Select>" :
			hideValIfFirstBeginWithSecBlankOrSelect(valueA, valueList, rowCount, hideRows);
			break;
			
		case "" :
			hideValIfFirstBeginWithSecBlankOrSelect(valueA, valueList, rowCount, hideRows);
			break;
			
		default:
			break;
		
		}
		return hideRows;
		
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstBeginWithSecDoesNotBeginWith(String valueA, String valueB, List<String> valueList,
			int rowCount, List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).startsWith(valueA) && !valueList.get(i).startsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).startsWith(valueA) || !valueList.get(i).startsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstBeginWithSecBlankOrSelect(String valueA, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		hideValIfFirstSelectSecBeginWith(valueA, valueList, rowCount, hideRows);
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstBeginWithSecDoesNotEndWit(String valueA, String valueB, List<String> valueList,
			int rowCount, List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).startsWith(valueA) && !valueList.get(i).endsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).startsWith(valueA) || !valueList.get(i).endsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstBeginWithSecEndsWith(String valueA, String valueB, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).startsWith(valueA) && valueList.get(i).endsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).startsWith(valueA) || valueList.get(i).endsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstBeginWithSecBeginWith(String valueA, String valueB, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).startsWith(valueA) && valueList.get(i).startsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).startsWith(valueA) || valueList.get(i).startsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstBeginWithSecEq(String valueA, String valueB, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).startsWith(valueA) && valueList.get(i).equals(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).startsWith(valueA) || valueList.get(i).equals(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstBeginWithSecDoesNotEq(String valueA, String valueB, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).startsWith(valueA) && !valueList.get(i).equals(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).startsWith(valueA) || !valueList.get(i).equals(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}
	private List<Integer> checkFilterForDoesNotBeginsWith(String conditionB, String valueA, String valueB, List<String> valueList, int rowCount, List<Integer> hideRows)
	{
		switch (conditionB) {
		case "does not equals":
			hideValIfFirstDoesNotBegWithSecDoesNotEq(valueA, valueB, valueList, rowCount, hideRows);
			break;
		
		case "equals" :
			hideValIfFirstDoesNotBegWithSecEq(valueA, valueB, valueList, rowCount, hideRows);
			break;
			
		case "begins with" :
			//newly added
			hideValIfFirstDoesNotBegWithSecBegWith(valueA, valueB, valueList, rowCount, hideRows);
			break;
			
		case "does not begin with" :
			//newly added
			hideValIfFirstDoesNotBegWithSecNotBegWith(valueA, valueB, valueList, rowCount, hideRows);
			break;
			
		case "ends with" :
			hideValIfFirstDoesNotBegWithSecEndWith(valueA, valueB, valueList, rowCount, hideRows);
			break;
			
		case "does not end with" :
			hideValIfFirstDoesNotBegWithSecDoesNotEndWith(valueA, valueB, valueList, rowCount, hideRows);
			break;
			
		case "<Select>" :
			hideValIfFirstDoesNotBegWithSecBlankOrSel(valueA, valueList, rowCount, hideRows);
			break;
			
		case "" :
			hideValIfFirstDoesNotBegWithSecBlankOrSel(valueA, valueList, rowCount, hideRows);
			break;
			
		default:
			break;
		
		}
		return hideRows;
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstDoesNotBegWithSecNotBegWith(String valueA, String valueB, List<String> valueList,
			int rowCount, List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).startsWith(valueA) && !valueList.get(i).startsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).startsWith(valueA) || !valueList.get(i).startsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstDoesNotBegWithSecBegWith(String valueA, String valueB, List<String> valueList,
			int rowCount, List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).startsWith(valueA) && valueList.get(i).startsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).startsWith(valueA) || valueList.get(i).startsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstDoesNotBegWithSecBlankOrSel(String valueA, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		hideValIfFirstSelectSecNotBeginWith(valueA, valueList, rowCount, hideRows);
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstDoesNotBegWithSecDoesNotEndWith(String valueA, String valueB, List<String> valueList,
			int rowCount, List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).startsWith(valueA) && !valueList.get(i).endsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).startsWith(valueA) || !valueList.get(i).endsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstDoesNotBegWithSecEndWith(String valueA, String valueB, List<String> valueList,
			int rowCount, List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).startsWith(valueA) && valueList.get(i).endsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).startsWith(valueA) || valueList.get(i).endsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstDoesNotBegWithSecEq(String valueA, String valueB, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).startsWith(valueA) && valueList.get(i).equals(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).startsWith(valueA) || valueList.get(i).equals(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstDoesNotBegWithSecDoesNotEq(String valueA, String valueB, List<String> valueList,
			int rowCount, List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).startsWith(valueA) && !valueList.get(i).equals(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).startsWith(valueA) || !valueList.get(i).equals(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}
	private List<Integer> checkFilterForEndsWith(String conditionB, String valueA, String valueB, List<String> valueList, int rowCount, List<Integer> hideRows)
	{
		switch (conditionB) {
		case "does not equals":
			hideValIfFirstEndWithSecDoesNotEq(valueA, valueB, valueList, rowCount, hideRows);
			break;
		
		case "equals" :
			hideValIfFirstEndWithSecEq(valueA, valueB, valueList, rowCount, hideRows);
			break;
			
		case "begins with" :
			hideValIfFirstEndWithSecBeginWit(valueA, valueB, valueList, rowCount, hideRows);
			break;
			
		case "does not begin with" :
			//newly added
			hideValIfFirstEndWithSecNotBegWit(valueA, valueB, valueList, rowCount, hideRows);

			break;
			
		case "ends with" :
			hideValIfFirstEndWithSecEndWith(valueA, valueB, valueList, rowCount, hideRows);
			break;
			
		case "does not end with" :
			hideValIfFirstEndWithSecDoesNotEndWit(valueA, valueB, valueList, rowCount, hideRows);
			break;
			
		case "<Select>" :
			hideValIfFirstEndWithSecBlankOrSel(valueA, valueList, rowCount, hideRows);
			break;
			
		case "" :
			hideValIfFirstEndWithSecBlankOrSel(valueA, valueList, rowCount, hideRows);
			break;
			
		default:
			break;
		
		}
		return hideRows;
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstEndWithSecNotBegWit(String valueA, String valueB, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).endsWith(valueA) && !valueList.get(i).startsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).endsWith(valueA) || !valueList.get(i).startsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstEndWithSecBlankOrSel(String valueA, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).endsWith(valueA))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).endsWith(valueA))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstEndWithSecDoesNotEndWit(String valueA, String valueB, List<String> valueList,
			int rowCount, List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).endsWith(valueA) && !valueList.get(i).endsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).endsWith(valueA) || !valueList.get(i).endsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstEndWithSecEndWith(String valueA, String valueB, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).endsWith(valueA) && valueList.get(i).endsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).endsWith(valueA) || valueList.get(i).endsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstEndWithSecBeginWit(String valueA, String valueB, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).endsWith(valueA) && valueList.get(i).startsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).endsWith(valueA) || valueList.get(i).startsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstEndWithSecEq(String valueA, String valueB, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).endsWith(valueA) && valueList.get(i).equals(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).endsWith(valueA) || valueList.get(i).equals(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstEndWithSecDoesNotEq(String valueA, String valueB, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).endsWith(valueA) && !valueList.get(i).equals(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).endsWith(valueA) || !valueList.get(i).equals(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}
	private List<Integer> checkFilterForDoesNotEndsWith(String conditionB, String valueA, String valueB, List<String> valueList, int rowCount, List<Integer> hideRows)
	{
		switch (conditionB) {
		case "does not equals":
			hideValIfFirstDoesNotEndWithSecDoesNotEq(valueA, valueB, valueList, rowCount, hideRows);
			break;
		
		case "equals" :
			hideValIfFirstDoesNotEndWithSecEq(valueA, valueB, valueList, rowCount, hideRows);
			break;
			
		case "begins with" :
			//newly added
			hideValIfFirstDoesNotEndWithSecBegWit(valueA, valueB, valueList, rowCount, hideRows);
			break;
			
		case "does not begin with" :
			//newly added
			hideValIfFirstDoesNotEndWithSecNotBegWit(valueA, valueB, valueList, rowCount, hideRows);
			break;
			
		case "ends with" :
			hideValIfFirstDoesNotEndWithSecEndWith(valueA, valueB, valueList, rowCount, hideRows);
			break;
			
		case "does not end with" :
			hideValIfFirstDoesNotEndWithSecNotEndWith(valueA, valueB, valueList, rowCount, hideRows);
			break;
			
		case "<Select>" :
			hideValIfFirstDoesNotEndWithSecBlankOrSel(valueA, valueList, rowCount, hideRows);
			break;
			
		case "" :
			hideValIfFirstDoesNotEndWithSecBlankOrSel(valueA, valueList, rowCount, hideRows);
			break;
			
		default:
			break;
		
		}
		return hideRows;
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstDoesNotEndWithSecNotBegWit(String valueA, String valueB, List<String> valueList,
			int rowCount, List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).endsWith(valueA) && !valueList.get(i).startsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).endsWith(valueA) || !valueList.get(i).startsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstDoesNotEndWithSecBegWit(String valueA, String valueB, List<String> valueList,
			int rowCount, List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).endsWith(valueA) && valueList.get(i).startsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).endsWith(valueA) || valueList.get(i).startsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstDoesNotEndWithSecBlankOrSel(String valueA, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).endsWith(valueA))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).endsWith(valueA))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstDoesNotEndWithSecNotEndWith(String valueA, String valueB, List<String> valueList,
			int rowCount, List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).endsWith(valueA) && !valueList.get(i).endsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).endsWith(valueA) || !valueList.get(i).endsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstDoesNotEndWithSecEndWith(String valueA, String valueB, List<String> valueList,
			int rowCount, List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).endsWith(valueA) && valueList.get(i).endsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).endsWith(valueA) || valueList.get(i).endsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstDoesNotEndWithSecEq(String valueA, String valueB, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).endsWith(valueA) && valueList.get(i).equals(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).endsWith(valueA) || valueList.get(i).equals(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueA
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstDoesNotEndWithSecDoesNotEq(String valueA, String valueB, List<String> valueList,
			int rowCount, List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).endsWith(valueA) && !valueList.get(i).equals(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).endsWith(valueA) || !valueList.get(i).equals(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}
	private List<Integer> checkFilterForSelectBlank(String conditionB, String valueB, List<String> valueList, int rowCount, List<Integer> hideRows)
	{
		switch (conditionB) {
		case "does not equals":
			hideValIfFirstSelectSecDoesNotEq(valueB, valueList, rowCount, hideRows);
			break;
		
		case "equals" :
			hideValIfFirstSelectSecEq(valueB, valueList, rowCount, hideRows);
			break;
			
		case "begins with" :
			hideValIfFirstSelectSecBeginWith(valueB, valueList, rowCount, hideRows);
			break;
			
		case "does not begin with" :
			hideValIfFirstSelectSecNotBeginWith(valueB, valueList, rowCount, hideRows);
			break;
			
		case "ends with" :
			hideValIfFirstEndWithSecBlankOrSel(valueB, valueList, rowCount, hideRows);
			break;
			
		case "does not end with" :
			hideValIfFirstDoesNotEndWithSecBlankOrSel(valueB, valueList, rowCount, hideRows);
			break;
			
		case "<Select>" :
			break;
			
		case "" :
			break;
			
		default:
			break;
		
		}
		return hideRows;
	}


	/**
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstSelectSecNotBeginWith(String valueB, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).startsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).startsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstSelectSecBeginWith(String valueB, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).startsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).startsWith(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}


	/**
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstSelectSecEq(String valueB, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).equals(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(valueList.get(i).equals(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}
	
	/**
	 * @param valueB
	 * @param valueList
	 * @param rowCount
	 * @param hideRows
	 */
	private void hideValIfFirstSelectSecDoesNotEq(String valueB, List<String> valueList, int rowCount,
			List<Integer> hideRows) {
		if(andButton.getSelection()) {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).equals(valueB))) {
					hideRows.add(i);
				}
			}
		}else {
			for(int i = 0 ; i < rowCount; i++) {
				if(!(!valueList.get(i).equals(valueB))) {
					hideRows.add(i);
				}
			}
		}
	}

}
