package com.navistar.datadictionary.ui.views;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.PlatformUI;

import com.google.gson.JsonElement;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.IconsPathConstant;
import com.navistar.datadictionary.constant.MatlabQueryConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.customexception.EditorInitilizationException;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.model.CategoryAttributesIo;
import com.navistar.datadictionary.service.ExcelImportExportService;
import com.navistar.datadictionary.serviceimpl.EditorServiceImpl;
import com.navistar.datadictionary.serviceimpl.ExcelImportExportServiceImpl;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.util.JsontoList;
import com.navistar.datadictionary.util.SwtResourceManagerUtils;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Pop-up window after clicking on Resolve inconsistency using excel option
 * @author nikitak1
 *
 */
public class ExcelImportExportWindow implements DisposeListener {

	/** Shell */
	public static Shell excelImExShl;
	
	/** Variable to Check if shell is already open **/
	public static boolean isImpExpWinOpn = false;
	
	/** exportService to access ExcelImportExportService Implementation**/
	ExcelImportExportService exportService = new ExcelImportExportServiceImpl();
	
	/**
	 * Open the window.
	 */
	public void open() {
		createUIComponents();
		Display display = Display.getDefault();
		ViewUtil.setShellPositionAtCenter(display, excelImExShl);

		if(!isImpExpWinOpn)
		{
			excelImExShl.open();
			excelImExShl.layout();
			excelImExShl.setMaximized(false);
			excelImExShl.setMinimized(false);
			isImpExpWinOpn = true;
			excelImExShl.addDisposeListener(this);
			while (!excelImExShl.isDisposed()) {
				if (!display.readAndDispatch()) {
					display.sleep();
				}
			}
		}

	}

	/**
	 * This method is used to create and configure UI components for Choosing Resolve inconsistency
	 * using excel option.
	 * 
	 */
	private void createUIComponents() {

		Image appIconImg = new Image(PlatformUI.getWorkbench().getDisplay(),
				AddDataObjectWindow.class.getResourceAsStream(IconsPathConstant.DATA_DD_ICON));

		excelImExShl = new Shell(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell());
		excelImExShl.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		excelImExShl.setText("Resolve Inconsistency using Excel");
		excelImExShl.setSize(404, 245);
		excelImExShl.setImage(appIconImg);

		excelImExShl.setLayout(null);
		excelImExShl.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None));
		Composite composite = new Composite(excelImExShl, SWT.BORDER);
		composite.setBounds(10, 10, 378, 198);
		composite.setBackground(new Color(composite.getDisplay(), 255,255,255));
		
		Button btnExcelToSldd = new Button(composite, SWT.RADIO);

		btnExcelToSldd.setBounds(22, 51, 322, 16);
		btnExcelToSldd.setText("Add data objects in SLDD/Delete from SLDD");
		btnExcelToSldd.setCapture(false);
		btnExcelToSldd.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None));
		btnExcelToSldd.setBackground(new Color(composite.getDisplay(), 255,255,255));
		
		Button btnSlddToExcel = new Button(composite, SWT.RADIO);
		btnSlddToExcel.setBounds(22, 86, 307, 16);
		btnSlddToExcel.setText("Add data objects in Excel/Delete from Excel");
		btnSlddToExcel.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None));
		btnSlddToExcel.setBackground(new Color(composite.getDisplay(), 255,255,255));
		
		CLabel lblHowDoYou = new CLabel(composite, SWT.NONE);
		lblHowDoYou.setBackground(new Color(composite.getDisplay(), 255,255,255));
		lblHowDoYou.setBounds(10, 10, 368, 25);
		lblHowDoYou.setText("How do you want to Resolve Inconsistency?");
		lblHowDoYou.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None));
		
		Button btnOk = new Button(composite, SWT.NONE);
		btnOk.setBounds(104, 154, 75, 25);
		btnOk.setText("OK");
		
		btnOk.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None));
		btnOk.addSelectionListener(new SelectionListener() {
			
			@Override
			public void widgetSelected(SelectionEvent event) {
				FileDialog fileDialog = new FileDialog(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell());
				String[] filterExt = { "*.xlsx;*.XLSX;*.xls;*.XLS;"};
				fileDialog.setFilterExtensions(filterExt);
				String excelPath = fileDialog.open();
				if(excelPath!=null) {
				excelPath = excelPath.replace("\\", "/");
				if(btnExcelToSldd.getSelection()){
					if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
						ActivityLogView.activityLog.append("\n [INFO]: Add data objects in SLDD/Delete from SLDD option selected");
					}
					IEditorPart activeEditor = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
							.getActiveEditor();
					//Condition to check if editor is instance of category editor
					if(!(activeEditor instanceof CategoryEditor)) {
						MessageDialog.openInformation(excelImExShl, ApplicationConstant.INFORMATION, "Please open component to add and delete data objects");
					}else {
						//code for Import from Excel to sldd
						
						ImportFromExcelWindowView window = new ImportFromExcelWindowView();
						window.setUIContents(excelPath);	
					}
					
				}else if(btnSlddToExcel.getSelection()) {
					//code for Export to Excel from sldd
					if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
						ActivityLogView.activityLog.append("\n [INFO]: Add data objects in Excel/Delete from Excel option selected");
					}
					ExportToExcelWindowView window = new ExportToExcelWindowView();
					window.setUIContents(excelPath);	 
					
				}else {
					//code for Resolve inconsistent attributes
					if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
						ActivityLogView.activityLog.append("\n [INFO]: Resolve Inconsistent Attributes option selected");
					}
					displayInconAttr(excelPath);	
				}
				excelImExShl.dispose();
				}
			}		

			@Override
			public void widgetDefaultSelected(SelectionEvent event) {
				//nothing to do
			}
		});
		
		Button btnCancel = new Button(composite, SWT.NONE);
		btnCancel.setBounds(197, 154, 75, 25);
		btnCancel.setText("Cancel");
		btnCancel.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None));
		
		Button btnResIncoAttr = new Button(composite, SWT.RADIO);
		btnResIncoAttr.setText("Resolve Inconsistent Attributes");
		btnResIncoAttr.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None));
		btnResIncoAttr.setCapture(false);
		btnResIncoAttr.setBackground(SwtResourceManagerUtils.getColor(255, 255, 255));
		btnResIncoAttr.setBounds(22, 121, 243, 16);
		btnCancel.addSelectionListener(new SelectionListener() {
			
			@Override
			public void widgetSelected(SelectionEvent event) {
				excelImExShl.dispose();
			}
			
			@Override
			public void widgetDefaultSelected(SelectionEvent event) {
				//nothing to do
			}
		});
	}

	@Override
	public void widgetDisposed(DisposeEvent event) {
		isImpExpWinOpn = false;
	}
	
	/**
	 * Method used to get and display inconsistent attributes
	 * in a table
	 */
	public void displayInconAttr(String excelPath) {
		
		List<CategoryAttributesIo> inconAttList = new ArrayList<CategoryAttributesIo>();
		List<CategoryAttributesIo> inconUpdList = new ArrayList<CategoryAttributesIo>();
		
		JsonElement inconAttrResp = null;
		
		try {
			inconAttrResp = exportService.getInconsistentAttributeData(excelPath);
		} catch (MatlabCommunicatinException e) {
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [ERROR]: "+e.getMessage());
			}
			MessageDialog.openConfirm(new Shell(), "Error Message", e.getMessage());
		}
	//	Type type = new TypeToken<List<CategoryAttributesIo>>() {}.getType();
	//	inconAttList = GsonUtil.provider().fromJSONToList(inconAttrResp.getAsJsonArray().toString(), type);
		inconAttList = JsontoList.replaceEmptyBracketsMinMax(inconAttrResp.toString());
		if (inconAttrResp != null && inconAttrResp.isJsonArray()) {
			JsonElement errorObject = inconAttrResp.getAsJsonArray().get(0);
			if (errorObject.isJsonObject() && errorObject.getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)) {
				exportService.checkMatlabRespCode(inconAttrResp);
			} 	else {
				for (CategoryAttributesIo categoryAttribute : inconAttList) {
					categoryAttribute.setWarning(categoryAttribute.getWarning());
					categoryAttribute.setComponent(categoryAttribute.getComponent().toLowerCase());
					if(categoryAttribute.getBaseType().equals("#N/A")) {
						categoryAttribute.setBaseType("");
					}
					if(categoryAttribute.getOffset().equals("#N/A")) {
						categoryAttribute.setOffset("");
					}
					if(categoryAttribute.getSlope().equals("#N/A")) {
						categoryAttribute.setSlope("");
					}
					inconUpdList.add(categoryAttribute);
				}
				try {
					//Closing all the opened editors
					new EditorServiceImpl().closeAllEditors();
					exportService.openInconsistentAttributeEditor(inconUpdList);
				} catch (EditorInitilizationException e) {
					MessageDialog.openConfirm(new Shell(), "Error Message", "Error while opening Inconsistent Attributes editor");
				}
				
			}
		}
	}
}
