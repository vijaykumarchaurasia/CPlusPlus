package com.navistar.datadictionary.ui.views;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.nebula.widgets.nattable.layer.cell.ILayerCell;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.TableEditor;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.forms.widgets.FormToolkit;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.IconsPathConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.model.SaveResponseCode;
import com.navistar.datadictionary.serviceimpl.RenameInModelServiceimpl;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.ui.nattable.CreateNatTable;
import com.navistar.datadictionary.util.GsonUtil;
import com.navistar.datadictionary.util.JSONUtil;
import com.navistar.datadictionary.util.SwtResourceManagerUtils;
import com.navistar.datadictionary.util.ViewUtil;

public class RenameInModelWindowView {
	private static Table table;

	/** Shell */
	private Shell shell;

	/** list to store invalid names */
	private List<String> invalidNameList = new ArrayList<String>();
	
	/** map to store oldName and newName from rename window */
	private Map<String,String> nameMapInTable = new HashMap<>();
	
	/** list to store error response after save */
	//private List<SaveResponseCode> renameFailedList = new ArrayList<>();

	/** list to store error response after no data object found in model */
	private List<SaveResponseCode> noObjInModelList = new ArrayList<>();
	
	/** To use formsAPI widgets*/
	private final FormToolkit formToolkit = new FormToolkit(Display.getDefault());
	
	/**
	 * Open the window.
	 */
	public void open() {

		createContents();
		Display display = Display.getDefault();
	
		ViewUtil.setShellPositionAtCenter(display, shell);
		
		shell.open();
		shell.layout();
		shell.setMaximized(false);
		shell.setMinimized(false);
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}

	}
	
	/**
	 * Method used to create the table contents for rename variables
	 */
	public void setTableContents() {
		GridLayout gridLayout = new GridLayout();
		gridLayout.numColumns = 2;
		
		IEditorPart activeEditor = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
				.getActiveEditor();
		CategoryEditor categoryEditor = (CategoryEditor) activeEditor;
		List<String> oldObjectsList = categoryEditor.getObjectsToRename();
		shell.setLayout(gridLayout);
		table = new Table(shell, SWT.BORDER | SWT.MULTI | SWT.RESIZE | SWT.H_SCROLL | SWT.V_SCROLL);
		final GridData gridDta = new GridData(GridData.FILL_BOTH);
		gridDta.horizontalSpan = 2;
		table.setLayoutData(gridDta);
		table.setBounds(10, 42, 374, 121);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);

		TableColumn oldColumn = new TableColumn(table, SWT.CENTER);
		oldColumn.setWidth(258);
		oldColumn.setText("                              Old Name                      ");
		
		//oldColumn.pack();
		TableColumn newColumn = new TableColumn(table, SWT.CENTER);
		newColumn.setWidth(258);
		//newColumn.setText("New Name");
		newColumn.setText("                        New Name                      ");
		//newColumn.pack();

		int dataObjectsCount = oldObjectsList.size();

		for(int i=0; i<dataObjectsCount; i++){
			TableEditor tableEditor = new TableEditor(table);

			Text dataObjectText = new Text(table,SWT.LEFT);

			TableItem item = new TableItem(table, SWT.LEFT);
			item.setText(oldObjectsList.get(i));
			item.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None));
			dataObjectText.setBounds(item.getBounds());

			tableEditor.grabHorizontal = true;
			dataObjectText.setText(oldObjectsList.get(i));
			item.setText(1,dataObjectText.getText());
			//item.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 13, SWT.None));
			tableEditor.setEditor(dataObjectText, item, 1);
			//item.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 13, SWT.None));
			dataObjectText.addListener(SWT.FocusOut, new Listener() {

				@Override
				public void handleEvent(Event event) {
					item.setText(1,dataObjectText.getText());
					item.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None));
				}
			});
		}
	}

	/**
	 * Method used to create rename in model window
	 */
	public void createContents() {
		Image appIconImage = new Image(PlatformUI.getWorkbench().getDisplay(),
				SearchResultView.class.getResourceAsStream(IconsPathConstant.DATA_DD_ICON));
		shell = new Shell(PlatformUI.getWorkbench().getDisplay(),SWT.ON_TOP | SWT.TITLE | SWT.CLOSE | SWT.MIN | SWT.MAX | SWT.RESIZE);
		shell.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		shell.setSize(570, 225);
		shell.setImage(appIconImage);

		shell.setText(ApplicationConstant.LBLRENAMEINMODEL);
		//shell.setLayout(null);

		Label lblVarToRename = new Label(shell, SWT.NONE);
		lblVarToRename.setBounds(10, 10, 158, 15);
		lblVarToRename.setText("Variables to rename");
		lblVarToRename.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 11, SWT.None));
		lblVarToRename.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		setTableContents();
		Composite remCancelGroup = new Composite(shell, SWT.NONE);
		remCancelGroup.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		GridData gdGroup = new GridData(GridData.FILL_HORIZONTAL);
		gdGroup.widthHint = 540;
		//gdGroup.horizontalSpan = 2;
		remCancelGroup.setLayoutData(gdGroup);
		formToolkit.adapt(remCancelGroup);
		formToolkit.paintBordersFor(remCancelGroup);
		Button btnRenameVar = new Button(remCancelGroup, SWT.NONE);
		btnRenameVar.setBounds(100, 5, 150, 25);
		//btnRenameVar.setBounds(400, 42, 140, 25);
		btnRenameVar.setText("Rename Variables");
		btnRenameVar.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 11, SWT.None));
		btnRenameVar.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent event) {
				try {
					renameInModelBtnClick();
				} catch (MatlabCommunicatinException e) {
					ViewUtil.dispConfirmDialog("Error Message", e.getMessage());
				}
			}
			
			@Override
			public void widgetDefaultSelected(SelectionEvent event) {
				// nothing to clean-up
			}
		});

		Button btnCancel = new Button(remCancelGroup, SWT.NONE);

		//btnCancel.setBounds(457, 138, 75, 25);
		btnCancel.setBounds(270, 5, 150, 25);
		btnCancel.setText("Cancel");
		btnCancel.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 11, SWT.None));
		btnCancel.addSelectionListener(new SelectionListener() {
			@Override
			public void widgetSelected(SelectionEvent event) {
				shell.close();	
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent event) {
				// widgetDefaultSel
			}
		});

	}

	/**
	 * Method used to perform rename in model when Rename Variables button click is performed
	 * @throws MatlabCommunicatinException 
	 */
	private void renameInModelBtnClick() throws MatlabCommunicatinException {
		Type type = new TypeToken<List<SaveResponseCode>>(){}.getType();
		IEditorPart editorPart = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor();
		CategoryEditor categoryEditor = null;
		if(editorPart instanceof CategoryEditor){
			categoryEditor = (CategoryEditor) editorPart;
		}
		JsonArray jsonArray = new JsonArray();

		if(isNameValid()){
			createJsonArrayofRenameObjects(categoryEditor, jsonArray);

			if(jsonArray.size()>0){
				RenameInModelServiceimpl renameInModelObj = new RenameInModelServiceimpl();
				JsonElement jsonElement = renameInModelObj.createJsonForRename(jsonArray);
				if(!JSONUtil.checkForNoMsgException(jsonElement)) {
					if (jsonElement != null && jsonElement.isJsonArray()) {
						JsonElement jsonElement1 = jsonElement.getAsJsonArray().get(0);
						if (jsonElement1.isJsonObject()) {
							if (jsonElement1.getAsJsonObject().has("modelData")) {
								String msgException = jsonElement1.getAsJsonObject().get("modelData").getAsString();
								shell.close();
								MessageDialog.openInformation(shell,ApplicationConstant.INFORMATION,msgException);
								return;
							}
						}
					}
				}
				if(JSONUtil.ifModelPresentForRename(jsonElement)) {
					if(JSONUtil.checkDataObjPresentForRename(jsonElement)) {
						if(JSONUtil.checkForRenameErrorCode(jsonElement)) {
							MessageDialog.openInformation(shell, "Success", "Renamed successfully");
							setRenameDataInCategory();
							if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
								ActivityLogView.activityLog.append("\n [INFO]: Rename In Model performed successfully");
							}
							
						}
						else if(!JSONUtil.ifModelLinkedForRename(jsonElement)) {
							MessageDialog.openInformation(shell, ApplicationConstant.WARNING, "Please link sldd file to model and try again");
						}
						else if(!JSONUtil.ifPreLookupValueCorrect(jsonElement)) {
							String message = "Rename in model failed - Prelookup block value field does not contain array with increasing order";
							createRenameFailList(type,jsonElement,message);
						}
						else {
							String message="Rename in model failed for:";
							createRenameFailList(type, jsonElement,message);
						}
						
					}
					else {
						checkDataObjectPresentToRename(type, jsonElement);
					}
				}
				
				else {
					MessageDialog.openInformation(shell, ApplicationConstant.WARNING, MessageConstant.MODEL_NOT_FOUND);
				}
				shell.close();
				
			}else{
				MessageDialog.openInformation(shell, ApplicationConstant.INFORMATION, "No change in data objects to rename");
			}
		}else{
			displayValidationMsg();
		}
	}

	/**
	 * 
	 */
	private void displayValidationMsg() {
		String validationMessage = MessageConstant.EDIT_MESSAGE + "\n" + "\n" + "'" + invalidNameList + "'"
				+ MessageConstant.EDIT_MESSAGE1 + "\n" + MessageConstant.EDIT_MESSAGE2
				+ "\n" + MessageConstant.EDIT_MESSAGE3 + "\n"
				+ MessageConstant.EDIT_MESSAGE4 + "\n" + MessageConstant.EDIT_MESSAGE6;

		openMessageDialogForNameValidation(shell.getDisplay(), validationMessage);
		invalidNameList = new ArrayList<>();
	}

	/**
	 * @param type
	 * @param jsonElement
	 */
	private void checkDataObjectPresentToRename(Type type, JsonElement jsonElement) {
		String message;
		noObjInModelList  = GsonUtil.provider().fromJSONToList(jsonElement.getAsJsonArray().get(0).toString(), type);

		message = MessageConstant.OBJECT_NOT_FOUND;

		for(SaveResponseCode saveResponseCode : noObjInModelList) {
			message += "\n" + saveResponseCode.getCategory() + " -> " + saveResponseCode.getName();
		}

		MessageDialog.openWarning(shell, ApplicationConstant.WARNING, message);

		removeDataObjectFromModelList();
		

		setRenameDataInCategory();
		noObjInModelList = new ArrayList<>();
	}

	/**
	 * Method used to create rename fail list if rename in model fails.
	 * @param type
	 * @param jsonElement
	 */
	private void createRenameFailList(Type type, JsonElement jsonElement,String message) {
		 List<SaveResponseCode> renameFailedList  = GsonUtil.provider().fromJSONToList(jsonElement.getAsJsonArray().get(0).toString(), type);
		//changed for PMD
		String reMsg = message;
		//message = MessageConstant.ADD_OBJECT_ERROR;

		for(SaveResponseCode saveResponseCode : renameFailedList) {
			reMsg += "\n" + saveResponseCode.getCategory() + " -> " + saveResponseCode.getName();
		}

		MessageDialog.openWarning(shell, ApplicationConstant.WARNING, reMsg);

		for(SaveResponseCode saveRespCode1 : renameFailedList){
			Iterator<String> iterator = nameMapInTable.keySet().iterator();
			while(iterator.hasNext()){
				String oldName = iterator.next();
				if(oldName.equals(saveRespCode1.getName())){
					iterator.remove();
				}
			}
		}

		setRenameDataInCategory();
		renameFailedList = new ArrayList<>();
	}
	
	/**
	 * Method used to remove the data object names if that data object is 
	 * not present in model to rename.
	 */
	public void removeDataObjectFromModelList()
	{
		for(SaveResponseCode saveRespCode1 : noObjInModelList){
		Iterator<String> iterator = nameMapInTable.keySet().iterator();
		while(iterator.hasNext()){
			String oldName = iterator.next();
			if(oldName.equals(saveRespCode1.getName())){
				iterator.remove();
			}
		}
	}
	}

	/**
	 * Method used to create a json array of renamed objects if new name is valid
	 * @param categoryEditor
	 * @param jsonArray
	 */
	private void createJsonArrayofRenameObjects(CategoryEditor categoryEditor, JsonArray jsonArray) {
		for(int i=0;i<table.getItemCount();i++){
			JsonObject renameJsonObj = new JsonObject();
			String oldObjectName = "";
			for(int j=0;j<table.getColumnCount();j++){
				if(j==0){
					oldObjectName = table.getItem(i).getText(j);
				}else if(j==1){
					if(!table.getItem(i).getText(j).equals(oldObjectName)){
						renameJsonObj.addProperty("oldName", oldObjectName);
						renameJsonObj.addProperty("newName", table.getItem(i).getText(j));
						renameJsonObj.addProperty("category", categoryEditor.getTitle());
					}else{
						renameJsonObj = null;
					}
				}
			}
			if(renameJsonObj!=null){
				jsonArray.add(renameJsonObj);
			}
		}
	}
	
	/**
	 * Method to check new name entered is valid name or not
	 * @return
	 */
	public boolean isNameValid() {
		boolean status = false;
		String regex = "^[a-zA-Z][a-zA-Z0-9_]*$";
		List<String> existingNameList = getTableData();
		for(String name : existingNameList){
			if (!((String) name).matches(regex)
					|| name.length() > ApplicationConstant.MAXNAMELEN) {
				status = false;
				invalidNameList.add(name);
			}
			else {
				status =  true;
			}
		}

		if(!invalidNameList.isEmpty()){
			status = false;
		}else{
			status  = true;
		}
		return status;
	}
	
	/**
	 * Method used to open message dialog for name validation
	 * @param cellEvent
	 * @param display
	 * @param validationMessage
	 */
	private void openMessageDialogForNameValidation(Display display,
			String validationMessage) {
		display.asyncExec(new Runnable() {
			public void run() {
				MessageDialog messageDialog = new MessageDialog(
						null,
						ApplicationConstant.EDIT_VIOLATION,
						null,
						validationMessage,
						0, new String[] {
								"Change"
						},
						0);
				messageDialog.open();		
			}
		});
	}

	/**
	 * Method used to get the new names of old data object name
	 * @return 
	 */
	private List<String>  getTableData() {
		List<String> existingNameList = new ArrayList<>();
		for (int i = 0; i < table.getItemCount(); i++) {
			for (int j = 0; j < table.getColumnCount(); j++) {
				TableItem item = table.getItem(i);
				if(j==0){
					nameMapInTable.put(item.getText(0),item.getText(1));
				}
				else if(j==1){
					
					existingNameList.add(item.getText(j));
				}	
			}
		}
		return existingNameList;
	}
	
	/**
	 * Method used to set renamed data objects in category table
	 */
	private void setRenameDataInCategory(){
		IEditorPart editor = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor();
		CategoryEditor categoryEditor = null;
		String newVal = "";
		if(editor instanceof CategoryEditor){
			categoryEditor = (CategoryEditor)editor;
		}
		if(categoryEditor != null){
			for(ILayerCell cell : categoryEditor.cellDataMap.keySet()){
				newVal = nameMapInTable.get(categoryEditor.cellDataMap.get(cell));
				if(newVal== null){
					categoryEditor.createNatTable.getJsonDataProvider().setDataValue(cell.getColumnIndex(), cell.getRowIndex(), categoryEditor.cellDataMap.get(cell));
				}else{	
					
					categoryEditor.createNatTable.getJsonDataProvider().setDataValue(cell.getColumnIndex(), cell.getRowIndex(), newVal);
					categoryEditor.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colOldNamIdx, cell.getRowIndex(), newVal);
					categoryEditor.data = newVal;
					categoryEditor.selDataObj = newVal;
				}
			}
			
			categoryEditor.cellDataMap = new HashMap<>();
		//	categoryEditor.editRowLists = new LinkedHashSet<>();
			
		}
		
	} 
}
