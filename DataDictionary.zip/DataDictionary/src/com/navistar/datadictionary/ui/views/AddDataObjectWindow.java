package com.navistar.datadictionary.ui.views;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.PlatformUI;

import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.IconsPathConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.util.SwtResourceManagerUtils;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Class used to display window for adding data object in Input category
 * @author nikitak1
 *
 */
public class AddDataObjectWindow implements DisposeListener {

	/** Shell */
	public static Shell addObjInputShell;
	
	public static boolean dataObjectAddFlag = true;
	
	/** Variable to Check if shell is already open */
	private static boolean loadDataObject = false;
	
	/** Variable to Check if browse sldd option is selected */
	public static boolean isBrowseSlddSel = false;

	public static boolean isBrowseOpen = false;

	/**
	 * Open the window.
	 */
	public void open() {
		createUIComponents();
		Display display = Display.getDefault();
		ViewUtil.setShellPositionAtCenter(display, addObjInputShell);

		if(!loadDataObject)
		{
			addObjInputShell.open();
			addObjInputShell.layout();
			addObjInputShell.setMaximized(false);
			addObjInputShell.setMinimized(false);
			loadDataObject = true;
			addObjInputShell.addDisposeListener(this);
			while (!addObjInputShell.isDisposed()) {
				if (!display.readAndDispatch()) {
					display.sleep();
				}
			}

		}

	}

	/**
	 * This method is used to create and configure UI components for Add data object for Input category.
	 * 
	 */
	private void createUIComponents() {

		Image appIconImage = new Image(PlatformUI.getWorkbench().getDisplay(),
				AddDataObjectWindow.class.getResourceAsStream(IconsPathConstant.DATA_DD_ICON));

		addObjInputShell = new Shell(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell());
		addObjInputShell.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		addObjInputShell.setText("Add Data Object in Input");
		addObjInputShell.setSize(400, 240);
		addObjInputShell.setImage(appIconImage);

		addObjInputShell.setLayout(null);
		addObjInputShell.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None));
		Composite composite = new Composite(addObjInputShell, SWT.BORDER);
		composite.setBounds(10, 10, 372, 190);
		composite.setBackground(new Color(composite.getDisplay(), 255,255,255));
		
		Button btnManually = new Button(composite, SWT.RADIO);
		btnManually.setBounds(22, 51, 90, 16);
		btnManually.setText("Manually");
		btnManually.setCapture(false);
		btnManually.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None));
		btnManually.setBackground(new Color(composite.getDisplay(), 255,255,255));
		
		Button outSignals = new Button(composite, SWT.RADIO);
		outSignals.setBounds(22, 86, 316, 16);
		outSignals.setText("From Output signals present in project");
		outSignals.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None));
		outSignals.setBackground(new Color(composite.getDisplay(), 255,255,255));
		
		Button btnBrowse = new Button(composite, SWT.RADIO);
		btnBrowse.setBounds(22, 121, 542, 16);
		btnBrowse.setText("Browse sldd");
		btnBrowse.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.FONT_STYLE, 10, SWT.None));
		btnBrowse.setBackground(new Color(composite.getDisplay(), 255,255,255));
		
		CLabel lblHowDoYou = new CLabel(composite, SWT.NONE);
		lblHowDoYou.setBackground(new Color(composite.getDisplay(), 255,255,255));
		lblHowDoYou.setBounds(10, 10, 368, 25);
		lblHowDoYou.setText("How do you want to add data object in Input category?");
		lblHowDoYou.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None));
		
		Button btnOk = new Button(composite, SWT.NONE);
		btnOk.setBounds(114, 150, 75, 25);
		btnOk.setText("OK");
		btnOk.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None));
		btnOk.addSelectionListener(new SelectionListener() {
			
			@Override
			public void widgetSelected(SelectionEvent event) {
				if(btnManually.getSelection()){
					IEditorPart activeEditor = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor();
					if(activeEditor instanceof CategoryEditor)
					{
						((CategoryEditor) activeEditor).setAddDataObjectDetails(null);

					}
					addObjInputShell.dispose();
				}else if(outSignals.getSelection()){
					AddDataObjectWindow.dataObjectAddFlag = true;
					ViewUtil.showHideView(ViewIDConstant.OUTPUT_DATA_OBJ, true);
					addObjInputShell.dispose();
				}else {
					isBrowseSlddSel = true;
					AddDataObjectWindow.dataObjectAddFlag = true;
					ViewUtil.showHideView(ViewIDConstant.OUTPUT_DATA_OBJ, true);
					addObjInputShell.dispose();
				}
				loadDataObject = false;
			}
			
			@Override
			public void widgetDefaultSelected(SelectionEvent event) {
				//nothing to do
			}
		});
		
		Button btnCancel = new Button(composite, SWT.NONE);
		btnCancel.setBounds(200, 150, 75, 25);
		btnCancel.setText("Cancel");
		btnCancel.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None));
		btnCancel.addSelectionListener(new SelectionListener() {
			
			@Override
			public void widgetSelected(SelectionEvent event) {
				addObjInputShell.dispose();
			}
			
			@Override
			public void widgetDefaultSelected(SelectionEvent event) {
				//nothing to do
			}
		});
	}

	@Override
	public void widgetDisposed(DisposeEvent event) {
		loadDataObject = false;
	}

}
