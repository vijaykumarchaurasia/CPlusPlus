package com.navistar.datadictionary.ui.views;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.forms.widgets.FormToolkit;

import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.IconsPathConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.serviceimpl.ApplyCdfServiceImpl;
import com.navistar.datadictionary.util.SwtResourceManagerUtils;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Class used to display data object names and values from CDF file
 * @author nikitak1
 *
 */
public class ApplyCdfView {

	/** Shell */
	private Shell shlApplyCdfTo;

	/** List to store the data object names and cdf values */
	public static List<CategoryAttributes> selCdfObjList;

	/** List to store selected checkbox items */
	private List<TableItem> selTableItems = new ArrayList<>();
	
	/** List to store all checkbox items */
	private List<TableItem> allTableItems = new ArrayList<>();
	
	/** To use formsAPI widgets*/
	private final FormToolkit formToolkit = new FormToolkit(Display.getDefault());
	
	/** To store list from matlab containing names and cdf values */
	private List<CategoryAttributes> cdfDataList;
	

	/**
	 * Open the window.
	 */
	public void open() {
		selCdfObjList = new ArrayList<CategoryAttributes>();
		try {
			cdfDataList = new ApplyCdfServiceImpl().getCdfDataFromMatlab();
		} catch (MatlabCommunicatinException e) {
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [ERROR]: "+e.getMessage());
			}
			MessageDialog.openConfirm(new Shell(), "Error Message", e.getMessage());
		}
		if(cdfDataList!=null) {
			createContents();
			Display display = Display.getDefault();
			ViewUtil.setShellPositionAtCenter(display, shlApplyCdfTo);
			shlApplyCdfTo.open();
			shlApplyCdfTo.layout();
			shlApplyCdfTo.setMaximized(false);
			shlApplyCdfTo.setMinimized(false);
			while (!shlApplyCdfTo.isDisposed()) {
				if (!display.readAndDispatch()) {
					display.sleep();
				}
			}
		}

	}

	/**
	 * Method used to create the table contents for Apply CDF window
	 */
	public void setTableContents() {

		GridLayout gridLayout = new GridLayout();
		gridLayout.numColumns = 2;
		Label lblVarToRename = new Label(shlApplyCdfTo, SWT.NONE);
		lblVarToRename.setBounds(10, 10, 459, 26);
		lblVarToRename.setText("Select data objects to update the value");
		lblVarToRename.setFont(SwtResourceManagerUtils.getFont("Work Sans", 10, SWT.NORMAL));
		lblVarToRename.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		shlApplyCdfTo.setLayout(gridLayout);

		final Table table = new Table(shlApplyCdfTo, SWT.BORDER | SWT.CHECK | SWT.MULTI
				| SWT.FULL_SELECTION);
		final GridData gridDta = new GridData(GridData.FILL_BOTH);
		gridDta.horizontalSpan = 2;
		table.setLayoutData(gridDta);
		table.setHeaderVisible(true);
		final TableColumn nameTabCol = new TableColumn(table, SWT.LEFT);
		final TableColumn valTabCol = new TableColumn(table, SWT.LEFT);
		nameTabCol.setText("Name");
		valTabCol.setText("Value in CDF file");
		nameTabCol.setWidth(200);
		valTabCol.setWidth(300);
		
		List<String> nameDataList = new ArrayList<>();
		for(CategoryAttributes object : cdfDataList) {
			String name = object.getName();
			nameDataList.add(name);
		}
		List<String> valDataList = new ArrayList<>();

		for(CategoryAttributes object : cdfDataList) {
			String value = object.getValue();
			valDataList.add(value);
		}
		int dataObjectsCount = nameDataList.size();
		TableItem item1 = null;
		for(int i=0; i<dataObjectsCount; i++){
			item1 = new TableItem(table, SWT.NONE);
			item1.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None));
			item1.setText(new String[] { nameDataList.get(i), valDataList.get(i) });
			allTableItems.add(item1);
		}

		table.addListener(SWT.Selection, new Listener() {

			@Override
			public void handleEvent(Event event) {
				if (event.detail == SWT.CHECK) {
					TableItem item = (TableItem) event.item;
					
					boolean status = item.getChecked();
					if(status) {
						selTableItems.add(item);
					}else {
						selTableItems.remove(item);
					}
				}

			}
		});
	}

	/**
	 * Method used to create rename in model window
	 * @wbp.parser.entryPoint
	 * 
	 */
	public void createContents() {
		Image appIconImage = new Image(PlatformUI.getWorkbench().getDisplay(),
				SearchResultView.class.getResourceAsStream(IconsPathConstant.DATA_DD_ICON));
		shlApplyCdfTo = new Shell(PlatformUI.getWorkbench().getDisplay(),SWT.ON_TOP|SWT.TITLE|SWT.CLOSE|SWT.MIN |SWT.MAX|SWT.RESIZE);
		shlApplyCdfTo.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		shlApplyCdfTo.setSize(550, 400);
		shlApplyCdfTo.setImage(appIconImage);

		shlApplyCdfTo.setText("Apply CDF to a component");

		setTableContents();
		Group okCancelGroup = new Group(shlApplyCdfTo, SWT.NONE);
		okCancelGroup.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		GridData gdGroup = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gdGroup.widthHint = 520;
		okCancelGroup.setLayoutData(gdGroup);
		
		formToolkit.adapt(okCancelGroup);
		formToolkit.paintBordersFor(okCancelGroup);
		
		Button btnUpdateAll = new Button(okCancelGroup, SWT.NONE);
		btnUpdateAll.setBounds(100, 15, 150, 25);
		btnUpdateAll.setText("Update All");
		btnUpdateAll.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 11, SWT.None));
		btnUpdateAll.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent event) {
				for(TableItem item : allTableItems) {
					CategoryAttributes object = new CategoryAttributes();
					String name = item.getText(0);
					object.setName(name);
					String valOld = item.getText(1);
					String newVal = valOld.replace("],", "]");
					object.setValue(newVal);
					for(CategoryAttributes obj : cdfDataList) {
						if(obj.getName().equals(name)) {
							object.setComponent(obj.getComponent());
						}
					}
					selCdfObjList.add(object);
				}
				dispSelObjDetailsInActLog();
				new ApplyCdfServiceImpl().updateDataObjectValuesOnUI(selCdfObjList);
				shlApplyCdfTo.close();	
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent event) {
				// nothing to clean-up
			}
		});

		Button btnUpdSel = new Button(okCancelGroup, SWT.NONE);
		btnUpdSel.setBounds(270, 15, 150, 25);
		btnUpdSel.setText("Update Selected");
		btnUpdSel.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 11, SWT.None));
		btnUpdSel.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent event) {
				if(!selTableItems.isEmpty()) {
				for(TableItem item : selTableItems) {
					CategoryAttributes object = new CategoryAttributes();
					String name = item.getText(0);
					object.setName(name);
					String valOld = item.getText(1);
					String newVal = valOld.replace("],", "]");
					object.setValue(newVal);
					for(CategoryAttributes obj : cdfDataList) {
						if(obj.getName().equals(name)) {
							object.setComponent(obj.getComponent());
						}
					}
					selCdfObjList.add(object);
				}
	
				dispSelObjDetailsInActLog();
				new ApplyCdfServiceImpl().updateDataObjectValuesOnUI(selCdfObjList);
				shlApplyCdfTo.close();	
				}else {
					ViewUtil.dispInfoInMsgDialog("Please select atleast one data object to update value");
				}
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent arg0) {
				// TODO Auto-generated method stub

			}
		});
	}

	/**
	 * Method used to display data object name and its value from CDF file in Activity log window
	 */
	private void dispSelObjDetailsInActLog() {
		if (ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
			ActivityLogView.activityLog.append("\n [INFO]: Below Data Object(s) selected to update values:");
			ActivityLogView.activityLog.append("\n ===========================================");
			for (int i = 0; i < selCdfObjList.size(); i++) {
				CategoryAttributes attributes = selCdfObjList.get(i);
				ActivityLogView.activityLog
						.append("\n " + (i + 1) + ". " + attributes.getName() + " : " + attributes.getValue());
			}
		}
	}

}
