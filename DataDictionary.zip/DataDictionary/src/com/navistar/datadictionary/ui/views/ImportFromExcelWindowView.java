package com.navistar.datadictionary.ui.views;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.forms.widgets.FormToolkit;

import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.IconsPathConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.customexception.EditorInitilizationException;
import com.navistar.datadictionary.customexception.EditorReuseException;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.serviceimpl.ExcelImportExportServiceImpl;
import com.navistar.datadictionary.serviceimpl.OpenComponentServiceImpl;
import com.navistar.datadictionary.util.SwtResourceManagerUtils;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Class used to get the window for data objects to be imported from excel
 * in sldd
 * @author nikitak1
 *
 */
public class ImportFromExcelWindowView implements SelectionListener, DisposeListener{
	/**Shell to display window */
	private Shell shell;

	/** To use formsAPI widgets*/
	private final FormToolkit formToolkit = new FormToolkit(Display.getDefault());

	/** check box buttons for to be deleted data objects*/
	private Button checkBoxDel;

	/** check box buttons for to be added data objects*/
	private Button checkBoxAdd;

	/** Composite to display dd data objects*/
	private Composite addToDdContent;

	/** Composite to display model data objects*/
	private Composite delFromDdContent;

	/** ok button to resolve inconsistency*/
	private Button okButton;

	/** To access excel import export business logic*/
	private ExcelImportExportServiceImpl excelService;

	/** List to save selected data objects to be added in dd */
	public static List<CategoryAttributes> addCheckList ;

	/** List to save selected data objects to be deleted from dd */
	private List<CategoryAttributes> delCheckList ;

	/**To access the attributes for inconsistency */
	private CategoryAttributes inconAttr;

	/** Variable to Check if shell is already open **/
	private static boolean isWindowOpen = false;

	/** Map to store all objects from both the lists */
	private Map<String, List<CategoryAttributes>> inconListMap;
	
	/** List to store all add check buttons present on window*/
	private List<Button> addChckBoxList = new ArrayList<>();
	
	/** List to store all delete check buttons present on window*/
	private List<Button> delChckBoxList = new ArrayList<>();
	
	/** To resize UI components */
	SashForm sashForm;
	
	//default constructor
	public ImportFromExcelWindowView() {
		shell = new Shell(PlatformUI.getWorkbench().getDisplay(),SWT.ON_TOP | SWT.TITLE | SWT.CLOSE | SWT.MIN | SWT.MAX | SWT.RESIZE);
	}
	/**
	 * Set the UI contents according to inconsistencyListMap which contains 
	 * error codes or inconsistent objects 
	 */
	public void setUIContents(String excelPath) {
		excelService= new ExcelImportExportServiceImpl();
		try {
			inconListMap = excelService.convertInconsistencyListToMap(excelService.getDataObjectsForSldd(excelPath));
		} catch (MatlabCommunicatinException e) {
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [ERROR]: "+e.getMessage());
			}
			ViewUtil.dispConfirmDialog("Error message", e.getMessage());
		}

		//If no inconsistencies for data objects in DD and Excel
		if(!excelService.addInSlddObject && !excelService.delFromSlddObject){				

			MessageDialog.openInformation(shell,ApplicationConstant.INFORMATION,MessageConstant.NO_INCONSI_FOUND);	

		}
		//If Add data objects in data dictionary list is empty
		else if(!excelService.addInSlddObject){

			createContents();
			ScrolledComposite addScroll = createAddGroup();
			ScrolledComposite delScroll = createDelGroup();
			displayDelDataObj(delFromDdContent,inconListMap);	
			setContentForComposites(addScroll, delScroll);
			setNoInconsistencyMessage(addToDdContent);
			createOkCancelGroup();
			openWindow();
		}
		//If Remove data objects from data dictionary list is empty
		else if(!excelService.delFromSlddObject){

			createContents();
			ScrolledComposite addScroll = createAddGroup();
			ScrolledComposite delScroll = createDelGroup();
			displayAddDataObj(addToDdContent,inconListMap);
			setContentForComposites(addScroll, delScroll);
			setNoInconsistencyMessage(delFromDdContent);		
			createOkCancelGroup();
			openWindow();
		}
		else if(inconListMap.isEmpty()) {
			return;
		}
		//If both lists contains inconsistencies
		else{
			createContents();
			ScrolledComposite addScroll = createAddGroup();
			ScrolledComposite delScroll = createDelGroup();
			displayDelDataObj(delFromDdContent,inconListMap);
			displayAddDataObj(addToDdContent,inconListMap);
			setContentForComposites(addScroll, delScroll);
			createOkCancelGroup();
			openWindow();
		}

	}
	/**
	 * Method used to open the inconsistency window
	 */
	private void openWindow() {
		Color sashColor = new Color(PlatformUI.getWorkbench().getDisplay(), 181,235,255);
		sashForm.setWeights(new int[]{1, 5, 5,1});
		sashForm.setBackground(sashColor);
		//for opening window only once
		if(!isWindowOpen){
			isWindowOpen=true;
			ViewUtil.setShellPositionAtCenter(shell.getDisplay(), shell);
			shell.open();
			shell.layout();
			shell.addDisposeListener(this);
			while (!shell.isDisposed()) {
				if (!shell.getDisplay().readAndDispatch()) {
					shell.getDisplay().sleep();
				}
			}
		}
	}
	/**
	 * Method used to create the contents if the data to be displayed is available
	 */
	public void createContents() {
		
		addCheckList = new ArrayList<CategoryAttributes>();
		delCheckList = new ArrayList<CategoryAttributes>();
		Image appIconImg = new Image(PlatformUI.getWorkbench().getDisplay(),
				SearchResultView.class.getResourceAsStream(IconsPathConstant.DATA_DD_ICON));
		shell.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		shell.setSize(524, 512);
		shell.setText("Excel to SLDD");
		shell.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 11, SWT.None));
		//shell.setLayout(new GridLayout(1, false));
		shell.setLayout(new FillLayout());
		shell.setImage(appIconImg);
		shell.setMaximized(true);
		shell.setMinimized(true);
		sashForm = new SashForm(shell, SWT.VERTICAL);
		createCompNameGroup();

	}

	/**
	 * Method for setting content in composites
	 * @param addScroll
	 * @param delScroll
	 */
	private void setContentForComposites(ScrolledComposite addScroll, ScrolledComposite delScroll) {
		ExcelImportExportWindow.isImpExpWinOpn=false;
		ExcelImportExportWindow.excelImExShl.close();
		addScroll.setContent(addToDdContent);
		addScroll.setExpandHorizontal(true);
		addScroll.setExpandVertical(true);
		addScroll.setMinSize(addToDdContent.computeSize(SWT.DEFAULT, SWT.DEFAULT));

		delScroll.setContent(delFromDdContent);
		delScroll.setExpandHorizontal(true);
		delScroll.setExpandVertical(true);
		delScroll.setMinSize(delFromDdContent.computeSize(SWT.DEFAULT, SWT.DEFAULT));
	}
	/**
	 * Method used to create the first Group which contains the opened component name
	 */
	private void createCompNameGroup() {
		OpenComponentServiceImpl openCompServ;
		Group compNameGp = new Group(sashForm, SWT.NONE);
		compNameGp.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		GridData compGrdData = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		compGrdData.widthHint = 488;
		compGrdData.heightHint = 26;
		compNameGp.setLayoutData(compGrdData);

		formToolkit.adapt(compNameGp);
		formToolkit.paintBordersFor(compNameGp);
		openCompServ = new OpenComponentServiceImpl();		
		String componentName= openCompServ.getOpenedComponentName();

		/*Button btnSelectall = new Button(compNameGp, SWT.CHECK);
		btnSelectall.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		btnSelectall.setFont(SwtResourceManagerUtils.getFont("Work Sans", 10, SWT.NORMAL));
		btnSelectall.setBounds(305, 10, 84, 30);
		formToolkit.adapt(btnSelectall, true, true);
		btnSelectall.setText("Select All");
		btnSelectall.addSelectionListener(this);*/

		GridData gdCompGroup = new GridData(SWT.RIGHT,SWT.CENTER,false,false,1,1);
		gdCompGroup.widthHint = 400;
		compNameGp.setLayoutData(gdCompGroup);

		CLabel lblComponentName = new CLabel(compNameGp, SWT.NONE);
		lblComponentName.setBounds(10, 17, 197, 15);
		lblComponentName.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		lblComponentName.setFont(SwtResourceManagerUtils.getFont("Work Sans", 10, SWT.BOLD));
		formToolkit.adapt(lblComponentName, true, true);
		lblComponentName.setText("Component : "+componentName);
		lblComponentName.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 11, SWT.None));

		Button btnSelectAllAdd = new Button(compNameGp, SWT.CHECK);
		btnSelectAllAdd.setFont(SwtResourceManagerUtils.getFont("Work Sans", 9, SWT.NORMAL));
		btnSelectAllAdd.setBounds(220, 17, 131, 17);
		formToolkit.adapt(btnSelectAllAdd, true, true);
		btnSelectAllAdd.setText("Select All to Add");
		btnSelectAllAdd.addSelectionListener(this);
		
		Button btnSelectAllDel = new Button(compNameGp, SWT.CHECK);
		btnSelectAllDel.setFont(SwtResourceManagerUtils.getFont("Work Sans", 9, SWT.NORMAL));
		btnSelectAllDel.setBounds(357, 17, 144, 16);
		formToolkit.adapt(btnSelectAllDel, true, true);
		btnSelectAllDel.setText("Select All to Delete");
		btnSelectAllDel.addSelectionListener(this);
	}
	/**
	 * Method used to create group which will display inconsistent data objects to add
	 * @return
	 */
	private ScrolledComposite createAddGroup() {
		Group addGroup = new Group(sashForm, SWT.NONE);
		addGroup.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		//addGroup.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 8, SWT.BOLD));
		addGroup.setText("Add data objects in Data Dictionary:");
		addGroup.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.BOLD));
		addGroup.setLayout(new GridLayout(1, false));

		GridData addGridData = new GridData(SWT.FILL, SWT.FILL, true, true);
		addGridData.heightHint = 90;
		addGridData.widthHint=336;
		addGroup.setLayoutData(addGridData);

		ScrolledComposite addScroll = new ScrolledComposite(addGroup, SWT.H_SCROLL | SWT.V_SCROLL);
		addScroll.setLayout(new GridLayout(1, false));
		addScroll.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

		addToDdContent = new Composite(addScroll, SWT.NONE);
		addToDdContent.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		addToDdContent.setLayout(new GridLayout(1, false));
		addToDdContent.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		return addScroll;
	}
	/**
	 * Method used to create group which will display inconsistent data objects to delete
	 * @return
	 */
	private ScrolledComposite createDelGroup() {
		Group delGroup = new Group(sashForm, SWT.FILL);
		delGroup.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		//delGroup.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 8, SWT.BOLD));
		delGroup.setText("Delete data objects from Data Dictionary:");
		delGroup.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.BOLD));
		delGroup.setLayout(new GridLayout(1, false));
		GridData delGridData = new GridData(SWT.FILL, SWT.FILL, true, true);
		delGridData.heightHint = 90;
		delGridData.widthHint=334;
		delGroup.setLayoutData(delGridData);

		ScrolledComposite delScroll = new ScrolledComposite(delGroup, SWT.H_SCROLL | SWT.V_SCROLL);
		delScroll.setLayout(new GridLayout(1, false));
		delScroll.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

		delFromDdContent = new Composite(delScroll, SWT.NONE);
		delFromDdContent.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		delFromDdContent.setLayout(new GridLayout(1, false));
		delFromDdContent.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		return delScroll;
	}
	/**
	 * Method to create group which displays OK and Cancel buttons
	 */
	private void createOkCancelGroup() {
		Group okCancelGroup = new Group(sashForm, SWT.NONE);
		okCancelGroup.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		GridData gdGroup = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gdGroup.widthHint = 488;
		okCancelGroup.setLayoutData(gdGroup);
		formToolkit.adapt(okCancelGroup);
		formToolkit.paintBordersFor(okCancelGroup);

		okButton = new Button(okCancelGroup, SWT.NONE);
		okButton.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 9, SWT.BOLD));
		okButton.setBounds(162, 10, 75, 25);
		formToolkit.adapt(okButton, true, true);
		okButton.setText("OK");
		okButton.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None));
		okButton.setEnabled(false);
		okButton.addSelectionListener(this);

		Button cancelButton = new Button(okCancelGroup, SWT.NONE);
		cancelButton.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 9, SWT.BOLD));
		cancelButton.setBounds(250, 10, 75, 25);
		formToolkit.adapt(cancelButton, true, true);
		cancelButton.setText("Cancel");
		cancelButton.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None));
		cancelButton.addSelectionListener(this);

		ExcelImportExportWindow.excelImExShl.dispose();
	}
	/**
	 * Method to display inconsistent data objects as checkbox buttons in Add in Data Dictionary composite
	 * @param addToddContent
	 * @param inconListMap
	 */
	public void displayAddDataObj(Composite addToddContent, Map<String, List<CategoryAttributes>> inconListMap) {

		for (String warning : inconListMap.keySet()) {

			List<CategoryAttributes> inconsistencyList = inconListMap.get(warning);

			boolean warningFlag = true;
			if (warningFlag && warning.equals("Add in DataDictionary")) {
				for (Iterator<CategoryAttributes> iterator = inconsistencyList.iterator(); iterator.hasNext();) {
					CategoryAttributes category = (CategoryAttributes) iterator.next();
					{
						if(category.getName().equals("#N/A")) {
							iterator.remove();
						}else {
							checkBoxAdd = new Button(addToddContent, SWT.CHECK);
							checkBoxAdd.setText(category.getCategory()+": "+category.getName());
							checkBoxAdd.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
							checkBoxAdd.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 10, SWT.NORMAL));
							checkBoxAdd.addSelectionListener(this);
							addChckBoxList.add(checkBoxAdd);
						}
					}
				}
			}
		}
	}

	/**
	 * Method to display inconsistent data objects as checkbox buttons in Delete from Data
	 * Dictionary composite
	 * @param delContent
	 * @param inconListMap
	 */
	public void displayDelDataObj(Composite delContent, Map<String, List<CategoryAttributes>> inconListMap) {

		for (String warning : inconListMap.keySet()) {

			List<CategoryAttributes> inconsistencyList = inconListMap.get(warning);

			boolean warningFlag = true;
			if (warningFlag && warning.equals("Delete from DataDictionary")) {
				for (Iterator<CategoryAttributes> iterator = inconsistencyList.iterator(); iterator.hasNext();) {
					CategoryAttributes category = (CategoryAttributes) iterator.next();
					{
						if(category.getName().equals("#N/A")) {
							iterator.remove();
						}else {
							checkBoxDel = new Button(delContent, SWT.CHECK);
							checkBoxDel.setText(category.getCategory()+": "+category.getName());
							checkBoxDel.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
							checkBoxDel.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 10, SWT.NORMAL));
							checkBoxDel.addSelectionListener(this);
							delChckBoxList.add(checkBoxDel);
						}
					}
				}
			}
		}
	}
	/**
	 * Method used to handle selection event
	 */
	@Override
	public void widgetSelected(SelectionEvent event) {
		Button source = (Button) event.getSource();	
		if(source.getParent().equals(addToDdContent)){
			performAddCheckboxAction(source);
		}
		if(source.getParent().equals(delFromDdContent)){
			performDeleteCheckboxAction(source);
		}

		if(source.getText().equals("Select All to Add")) {
			performSelectAllAdd(source);
		}
		
		if(source.getText().equals("Select All to Delete")) {
			performSelectAllDelete(source);	
		}
		
		if(!addCheckList.isEmpty() || !delCheckList.isEmpty()) {
			okButton.setEnabled(true);
		}else {
			okButton.setEnabled(false);
		}

		if(source.getText().equals("OK")){		
			try {
				excelService.resolveInconsistencyFromExcel(addCheckList, delCheckList);
			} catch (MatlabCommunicatinException e) {
				MessageDialog.openConfirm(new Shell(), "Error Message", e.getMessage());
			} catch (EditorReuseException e) {
				MessageDialog.openConfirm(new Shell(), "Error Message", e.getMessage());
			} catch (EditorInitilizationException e) {
				MessageDialog.openConfirm(new Shell(), "Error Message", e.getMessage());
			}
			shell.close();
			isWindowOpen=false;
		}
		else if(source.getText().equals("Cancel")){			
			shell.close();
			isWindowOpen = false;
			ExcelImportExportWindow.isImpExpWinOpn=false;
			
		}
	}
	/**
	 * @param source
	 */
	private void performDeleteCheckboxAction(Button source) {
		if(source.getSelection()){				
			createDeleteObjectList(source);
		}
		else{
			String name = source.getText().split(": ")[1];
			inconAttr = findDelInconsistencyFromList(name);	
			delCheckList.remove(inconAttr);
		}
	}
	/**
	 * @param source
	 */
	private void performAddCheckboxAction(Button source) {
		if(source.getSelection()){		
			createAddObjectList(source);
		}
		else{
			String name = source.getText().split(": ")[1];
			inconAttr = findAddInconsistencyFromList(name);
			addCheckList.remove(inconAttr);
		}
	}
	private void performSelectAllAdd(Button source) {
		if(source.getSelection()){
			for(Button checkBox:addChckBoxList){
				if(!checkBox.getSelection()) {
					checkBox.setSelection(true);
					if(checkBox.getParent().equals(addToDdContent)) {
						performAddCheckboxAction(checkBox);
					}
				}
			}
		}
		else{
			for(Button checkBox:addChckBoxList){
				checkBox.setSelection(false);
				if(checkBox.getParent().equals(addToDdContent)) {
					String name = checkBox.getText().split(": ")[1];
					inconAttr = findAddInconsistencyFromList(name);
					addCheckList.remove(inconAttr);
				}
			}
		}
	}
	
	private void performSelectAllDelete(Button source) {
		if(source.getSelection()){
			for(Button checkBox:delChckBoxList){
				if(!checkBox.getSelection()) {
					checkBox.setSelection(true);
					if(checkBox.getParent().equals(delFromDdContent)) {
						performDeleteCheckboxAction(checkBox);
					}
				}
			}
		}
		else{
			for(Button checkBox:delChckBoxList){
				checkBox.setSelection(false);
				if(checkBox.getParent().equals(delFromDdContent)) {
					String name = checkBox.getText().split(": ")[1];
					inconAttr = findDelInconsistencyFromList(name);
					delCheckList.remove(inconAttr);
				}
			}
		}
		
	}
	
	/**
	 * Method used to add selected check-box objects in list to add
	 * for resolving inconsistency
	 * @param source
	 */
	private void createAddObjectList(Button source) {
		String warning = "Add in DataDictionary";
		String category = source.getText().split(": ")[0];
		String name = source.getText().split(": ")[1];
		inconAttr = new CategoryAttributes();

		inconAttr.setWarning(warning);
		inconAttr.setCategory(category);
		inconAttr.setName(name);
		inconAttr.setComponent(new OpenComponentServiceImpl().getOpenedComponentName());


		for(List<CategoryAttributes> k:inconListMap.values()) {
			for(CategoryAttributes obj : k) {
				if(obj.getName().equals(name)) {
					setAttrValues("BaseType",obj,inconAttr);
					setAttrValues("Slope", obj,inconAttr);
					setAttrValues("Offset", obj,inconAttr);
				}

			}

		}
		addCheckList.add(inconAttr);

	}

	/**
	 * Method used to set the attributes for newly added data objects from
	 * excel sheet in sldd
	 * @param attr
	 * @param obj
	 * @param inconsisAttri
	 */
	private void setAttrValues(String attr,CategoryAttributes obj, CategoryAttributes inconsisAttri){
		if(attr.equals("BaseType")) {
			if(obj.getBaseType().equals("#N/A")) {
				inconsisAttri.setBaseType("");
			}else {
				inconsisAttri.setBaseType(obj.getBaseType());
			}
		}
		if(attr.equals("Slope")) {
			if(obj.getSlope().equals("#N/A")) {
				inconsisAttri.setSlope("");
			}else {
				inconsisAttri.setSlope(obj.getSlope());
			}
		}
		if(attr.equals("Offset")) {
			if(obj.getOffset().equals("#N/A")) {
				inconsisAttri.setOffset("");
			}else {
				inconsisAttri.setOffset(obj.getOffset());
			}
		}
	}
	/**
	 * Method used to add selected check-box objects in list to delete
	 * for resolving inconsistency
	 * @param source
	 */
	private void createDeleteObjectList(Button source) {
		String warning = "Delete from DataDictionary";
		String category = source.getText().split(": ")[0];
		String name = source.getText().split(": ")[1];
		inconAttr = new CategoryAttributes();
		inconAttr.setWarning(warning);
		inconAttr.setCategory(category);
		inconAttr.setName(name);
		delCheckList.add(inconAttr);
	}

	/**
	 * Default selection event
	 */
	@Override
	public void widgetDefaultSelected(SelectionEvent event) {
		//nothing to clean-up
	}

	/**
	 * To save the selected check-box items for to be added data objects
	 * @param name
	 * @return
	 */
	private CategoryAttributes findAddInconsistencyFromList(String name) {
		if(addCheckList!=null && !addCheckList.isEmpty())
		{
			for (Iterator<CategoryAttributes> iterator = addCheckList.iterator(); iterator.hasNext();) {
				CategoryAttributes inconAttr = (CategoryAttributes) iterator.next();
				if(inconAttr.getName().equals(name))
				{
					return inconAttr;
				}

			}
		}

		return null;
	}
	/**
	 * To save the selected check-box items for to be deleted data objects
	 * @param name
	 * @return
	 */
	private CategoryAttributes findDelInconsistencyFromList(String name) {
		if(delCheckList!=null && !delCheckList.isEmpty())
		{
			for (Iterator<CategoryAttributes> iterator = delCheckList.iterator(); iterator.hasNext();) {
				CategoryAttributes inconsistencyAttr = (CategoryAttributes) iterator.next();
				if(inconsistencyAttr.getName().equals(name))
				{
					return inconsistencyAttr;
				}

			}
		}

		return null;
	}
	/**
	 * To set the message if no inconsistencies between excel and sldd objects
	 * @param composite
	 */
	private void setNoInconsistencyMessage(Composite composite) {
		Label noIssueLabel = new Label(composite, SWT.NONE);
		noIssueLabel.setBounds(10, 19, 316, 15);
		formToolkit.adapt(noIssueLabel, true, true);
		noIssueLabel.setText("No inconsistency");
		noIssueLabel.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None));
		noIssueLabel.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 14, SWT.BOLD));
	}

	/**
	 * To dispose the shell
	 * @param event
	 */
	@Override
	public void widgetDisposed(DisposeEvent event) {
		isWindowOpen = false;
	}
}
