package com.navistar.datadictionary.ui.views;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.layout.GridDataFactory;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

/**
 * This class is used to display a validation message.
 * 
 * @author VijayK13
 *
 */
public class CustomMessageDialog extends MessageDialog{
	
	private static CustomMessageDialog customMsgDialog = null;
	
	public static CustomMessageDialog getmessagedialogInstance()
	{
		return customMsgDialog;
	}

	public CustomMessageDialog(Shell parentShell, String dialogTitle, Image dialogTitleImage, String dialogMessage,
			int dialogImageType, String[] dialogBtnLabels, int defaultIndex) {
		super(parentShell, dialogTitle, dialogTitleImage, dialogMessage, dialogImageType, dialogBtnLabels, defaultIndex);
		customMsgDialog = this;
	}

	@Override
	public int open() {
		customMsgDialog = this;
		return super.open();
	}

	@Override
	protected void cancelPressed() {
		super.cancelPressed();
		customMsgDialog = null;
	}

	@Override
	public boolean close() {
		customMsgDialog = null;
		return super.close();
	}

	@Override
	protected void okPressed() {
		super.okPressed();
		customMsgDialog = null;
	}
	
	@Override
	protected Control createMessageArea(Composite composite) {
		Image image = getImage();
		if (image != null) {
			imageLabel = new Label(composite, SWT.NULL);
			image.setBackground(imageLabel.getBackground());
			imageLabel.setImage(image);
			//addAccessibleListeners(imageLabel, image);
			GridDataFactory.fillDefaults().align(SWT.CENTER, SWT.BEGINNING)
					.applyTo(imageLabel);
		}
		// create message
		if (message != null) {
			Text messageLabel = new Text(composite, SWT.READ_ONLY | SWT.WRAP);
			messageLabel.setText(message);
			GridDataFactory
					.fillDefaults()
					.align(SWT.FILL, SWT.BEGINNING)
					.grab(true, false)
					.hint(
							convertHorizontalDLUsToPixels(IDialogConstants.MINIMUM_MESSAGE_AREA_WIDTH),
							SWT.DEFAULT).applyTo(messageLabel);
		}
		return composite;
	
	}
}
