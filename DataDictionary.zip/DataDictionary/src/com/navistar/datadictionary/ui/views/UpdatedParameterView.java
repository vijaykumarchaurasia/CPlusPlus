package com.navistar.datadictionary.ui.views;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.forms.widgets.FormToolkit;
import com.google.gson.JsonElement;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.IconsPathConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.serviceimpl.OpenComponentServiceImpl;
import com.navistar.datadictionary.serviceimpl.UpdateParameterTypeServiceImpl;
import com.navistar.datadictionary.ui.config.Application;
import com.navistar.datadictionary.util.SwtResourceManagerUtils;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Class used to get the window for Updated parameter
 * @author shalins
 *
 */
public class UpdatedParameterView implements SelectionListener, DisposeListener {

	/**Shell to display window */
	private Shell shlModelIncon;
	
	/** To use formsAPI widgets*/
	private final FormToolkit formToolkit = new FormToolkit(Display.getDefault());
	
	
	/** check box buttons for dd data objects*/
	private CLabel checkBoxdd;

	/** Composite to display dd data objects*/
	private Composite ddContent;
	
	/** List to save selected dd data objects */
	public static List<CategoryAttributes> ddCheckBoxList ;
	
	
	/** Variable to Check if shell is already open **/
	private static boolean isInconWinOpn = false;
	
	/** To resize UI components */
	SashForm sashForm;
	
	//default constructor
	public UpdatedParameterView() {
		shlModelIncon = new Shell(PlatformUI.getWorkbench().getDisplay(),SWT.ON_TOP | SWT.TITLE | SWT.CLOSE |  SWT.RESIZE);
	
		//| SWT.MIN | SWT.MAX
	}
	/**
	 * Set the UI contents according to inconsistencyListMap which contains 
	 * error codes or inconsistent objects 
	 */
	public void setUIContents(JsonElement jsonElement) {
		Map<String, List<CategoryAttributes>> updateParaMap = null;
		UpdateParameterTypeServiceImpl validateParameter = new UpdateParameterTypeServiceImpl();
		
		//Map<String, List<CategoryAttributes>> inconsistencyMap = null;
		try {
			updateParaMap = validateParameter.convertInconsistencyListToMap(jsonElement);
		} catch (MatlabCommunicatinException e) {
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [ERROR]: "+e.getMessage());
			}
			ViewUtil.dispConfirmDialog("Error Message", e.getMessage());
			return;
		}
		
			createContents();
			ScrolledComposite ddScroll = createDdGroup();
			displayDDDataObj(ddContent,updateParaMap);
			setContentForComposites(ddScroll);
			createOkCancelGroup();
			openWindow();
		}
		
	
	/**
	 * Method used to open the inconsistency window
	 */
	private void openWindow() {
		//Color sashColor = new Color(PlatformUI.getWorkbench().getDisplay(), 224,224,224);
		Color sashColor = new Color(PlatformUI.getWorkbench().getDisplay(), 192,192,192);
		sashForm.setWeights(new int[]{1,6,1});
		sashForm.setBackground(sashColor);
		//for opening window only once
		if(!isInconWinOpn){
			isInconWinOpn=true;
			ViewUtil.setShellPositionAtCenter(shlModelIncon.getDisplay(), shlModelIncon);
			shlModelIncon.open();
			shlModelIncon.layout();
			shlModelIncon.addDisposeListener(this);
			while (!shlModelIncon.isDisposed()) {
				if (!shlModelIncon.getDisplay().readAndDispatch()) {
					shlModelIncon.getDisplay().sleep();
				}
			}
		}
	}
	/**
	 * Method used to create the contents if the data to be displayed is available
	 */
	public void createContents() {

			//ddCheckBoxList = new ArrayList<CategoryAttributes>();
			//modelCheckBoxList = new ArrayList<CategoryAttributes>();
			Image appIconImage = new Image(PlatformUI.getWorkbench().getDisplay(),
					SearchResultView.class.getResourceAsStream(IconsPathConstant.DATA_DD_ICON));
			shlModelIncon.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
			shlModelIncon.setSize(450, 400);
			shlModelIncon.setText("Updated Parameter Type");
			shlModelIncon.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 11, SWT.None));
			//shlModelIncon.setLayout(new GridLayout(1, false));
			//fillLayout.type = SWT.VERTICAL;
			shlModelIncon.setLayout(new FillLayout());
			shlModelIncon.setImage(appIconImage);
			shlModelIncon.setMaximized(false);
			shlModelIncon.setMinimized(false);
			sashForm = new SashForm(shlModelIncon, SWT.VERTICAL);
			createCompNameGroup();
			
	}
	
	/**
	 * Method for setting content in composites
	 * @param ddScroll
	 * @param modelScroll
	 */
	private void setContentForComposites(ScrolledComposite ddScroll) {
		//ScrolledComposite modelScroll
		ddScroll.setContent(ddContent);
		ddScroll.setExpandHorizontal(true);
		ddScroll.setExpandVertical(true);
		ddScroll.setMinSize(ddContent.computeSize(SWT.DEFAULT, SWT.DEFAULT));

	}
	/**
	 * Method used to create the first Group which contains the opened component name
	 */
	private void createCompNameGroup() {
		OpenComponentServiceImpl openCompService;
		Group compNameGp = new Group(sashForm, SWT.NONE);
		compNameGp.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		GridData compNameGData = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		compNameGData.widthHint = 488;
		compNameGData.heightHint = 26;
		compNameGp.setLayoutData(compNameGData);
		formToolkit.adapt(compNameGp);
		formToolkit.paintBordersFor(compNameGp);

		CLabel lblComponentName = new CLabel(compNameGp, SWT.NONE);
		lblComponentName.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		lblComponentName.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 10, SWT.NORMAL));
		lblComponentName.setBounds(10, 13, 197, 20);
		formToolkit.adapt(lblComponentName, true, true);
		openCompService = new OpenComponentServiceImpl();		
		String componentName= openCompService.getOpenedComponentName();
		lblComponentName.setText("Component : "+componentName);
		lblComponentName.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 11, SWT.NORMAL));
		
		
	}
	/**
	 * Method used to create group which will display inconsistent data objects in Data Dictionary
	 * @return
	 */
	private ScrolledComposite createDdGroup() {
		Group ddGroup = new Group(sashForm, SWT.NONE);
		ddGroup.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		//ddGroup.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 8, SWT.BOLD));
		ddGroup.setText("Updated Data Object :");
		
		ddGroup.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 12, SWT.BOLD));
		ddGroup.setLayout(new GridLayout(1, false));
		
		GridData ddGridData = new GridData(SWT.FILL, SWT.FILL, true, true);
		ddGridData.heightHint = 90;
		ddGridData.widthHint=336;
		ddGroup.setLayoutData(ddGridData);
		
		ScrolledComposite ddScroll = new ScrolledComposite(ddGroup, SWT.H_SCROLL | SWT.V_SCROLL);
		ddScroll.setLayout(new GridLayout(1, false));
		ddScroll.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

		ddContent = new Composite(ddScroll, SWT.NONE);
		ddContent.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		ddContent.setLayout(new GridLayout(1, false));
		ddContent.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
	
		
		return ddScroll;
	}
	
	/**
	 * Method to create group which displays OK and Cancel buttons
	 */
	private void createOkCancelGroup() {
		Group okCancelGroup = new Group(sashForm, SWT.NONE);
		okCancelGroup.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
		GridData gdGroup = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gdGroup.widthHint = 488;
		okCancelGroup.setLayoutData(gdGroup);
		formToolkit.adapt(okCancelGroup);
		formToolkit.paintBordersFor(okCancelGroup);

		Button okButton = new Button(okCancelGroup, SWT.NONE);
		okButton.setFont(SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 9, SWT.BOLD));
		okButton.setBounds(182, 10, 75, 25);
		formToolkit.adapt(okButton, true, true);
		okButton.setText("OK");
		okButton.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.None));
		okButton.setEnabled(true);
		okButton.addSelectionListener(this);


	}
	/**
	 * Method to display inconsistent data objects as checkbox buttons in Data Dictionary composite
	 * @param ddContent
	 * @param inconsistencyListMap
	 */
	public void displayDDDataObj(Composite ddContent, Map<String, List<CategoryAttributes>> inconsistencyMap) {
		int count =01;
		
		List<CategoryAttributes> inconsistencyList = new ArrayList<CategoryAttributes>();
		for (String warning : inconsistencyMap.keySet()) {
			List<CategoryAttributes> inconsListWarn = inconsistencyMap.get(warning);
			//List<CategoryAttributes> inconsistencyList;
			List<String> catlist = Application.configCatList;
			Collections.sort(catlist);
			for(String i : catlist)
			{
			for (Iterator<CategoryAttributes> iterator = inconsListWarn.iterator(); iterator.hasNext();) {
				CategoryAttributes category = (CategoryAttributes) iterator.next();
				if(category.getCategory().equals(i))
						{
						inconsistencyList.add(category);
						}
			}
			}
		/*for (String warning : inconsistencyMap.keySet()) {
			List<CategoryAttributes> inconsistencyList=inconsistencyMap.get(warning);*/
			boolean warningFlag = true;
			if (warningFlag && warning.equals("Updated Data Objects")) {
				//int count =1;
					
				for (Iterator<CategoryAttributes> iterator = inconsistencyList.iterator(); iterator.hasNext();) {
					CategoryAttributes category = (CategoryAttributes) iterator.next();
					{
						if(Application.configCatList.contains(category.getCategory())){
							//int count =1;
							checkBoxdd = new CLabel(ddContent, SWT.None);
							if(count<10) {
								checkBoxdd.setText("0"+count+")  "+category.getCategory()+": "+category.getName());
							}
							else
							{
							checkBoxdd.setText(count+")  "+category.getCategory()+": "+category.getName());
							}
							checkBoxdd.setBackground(SwtResourceManagerUtils.getColor(SWT.COLOR_WHITE));
							checkBoxdd.setFont(new Font(PlatformUI.getWorkbench().getDisplay(), ApplicationConstant.APP_FONT_STYLE, 10, SWT.NORMAL));
									//SwtResourceManagerUtils.getFont(ApplicationConstant.FONT_STYLE, 50, SWT.NORMAL));
							count++;
					
						}
					}
				}
			}
		}
	}
	
	/**
	 * Method used to handle selection event
	 */
	@Override
	public void widgetSelected(SelectionEvent event) {
		Button source = (Button) event.getSource();		
		if(source.getText().equals("OK")){		
			shlModelIncon.close();
			isInconWinOpn = false;
					
		}
	}
	
	/**
	 * Default selection event
	 */
	@Override
	public void widgetDefaultSelected(SelectionEvent event) {
		//nothing to clean-up
	}
	
	@Override
	public void widgetDisposed(DisposeEvent event) {
		isInconWinOpn = false;
	}
}
