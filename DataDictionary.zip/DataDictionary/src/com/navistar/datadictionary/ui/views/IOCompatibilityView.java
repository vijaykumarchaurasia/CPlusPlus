package com.navistar.datadictionary.ui.views;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.GroupMarker;
import org.eclipse.jface.action.IMenuListener;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.layout.GridLayoutFactory;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.ViewPart;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.navistar.datadictionary.action.DeleteDataObjectAction;
import com.navistar.datadictionary.action.UseThisObjectAction;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.IconsPathConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.customexception.EditorInitilizationException;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.model.CategoryAttributesIo;
import com.navistar.datadictionary.service.IOCompatibilityService;
import com.navistar.datadictionary.service.OpenComponentService;
import com.navistar.datadictionary.serviceimpl.EditorServiceImpl;
import com.navistar.datadictionary.serviceimpl.IOCompatibilityServiceImpl;
import com.navistar.datadictionary.serviceimpl.OpenComponentServiceImpl;
import com.navistar.datadictionary.ui.config.Application;
import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.ui.editors.IOCompatibilityEditor;
import com.navistar.datadictionary.util.GsonUtil;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Class used for creating Check I/OCompatibility ViewPart in the existing workspace.
 * @author VijayK13
 *
 */
public class IOCompatibilityView extends ViewPart implements MouseListener{

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(ProjectExplorerView.class);
	/** IO Compatibility view instance */
	
	private static IOCompatibilityView ioViewInstance;


	/** IO Compatibility view parent */
	private Composite parent;

	/** IO Compatibility warning tree */
	private Tree tree;

	/** Used to access IOCompatibility Service */
	private IOCompatibilityService ioCompatService;

	/** Used to access Open Component Service */
	private OpenComponentService openCompService;

	/** Used to store I/O compatibility details */
	public Map<String, List<CategoryAttributesIo>> ioCompatMap;

	/** constructor */
	public static IOCompatibilityView getIOCompatibilityViewInstance() {
		return ioViewInstance;
	}

	private org.eclipse.swt.graphics.Font fontStyle;
	
	/**
	 * This method is used to create IO compatibility view.
	 */
	@Override
	public void createPartControl(Composite parent) {
		
		Device device;
		ioCompatService = new IOCompatibilityServiceImpl();
		openCompService = new OpenComponentServiceImpl();
		ioViewInstance = this;
		ioViewInstance.parent = parent;
		this.parent = parent;
		device = PlatformUI.getWorkbench().getDisplay();
		fontStyle  = new org.eclipse.swt.graphics.Font(device, ApplicationConstant.APP_FONT_STYLE,10, SWT.NORMAL);
		createIOPartControl();
		
	}

	/**
	 * This method is used to create parts for IO Compatibility view.
	 */
	public void createIOPartControl() {
		JsonElement ioJsonData = null;
		
		try {
			ioJsonData = ioCompatService.getIOCompatibilityData();
		} catch (MatlabCommunicatinException e) {
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [ERROR]: "+e.getMessage());
			}
			MessageDialog.openConfirm(new Shell(), "Error Message", e.getMessage());
		}
		
		if(ioJsonData != null)
		{
			ioCompatMap = ioCompatService.convertIOListToMap(ioJsonData);
			List<CategoryAttributesIo> oldList = new ArrayList<>();
			List<CategoryAttributesIo> inconModiflstIo = new ArrayList<>();
			List<CategoryAttributesIo> inconModiflstIoStruc = new ArrayList<>();
			for (Entry<String, List<CategoryAttributesIo>> entry : ioCompatMap.entrySet()) {
				oldList.addAll(entry.getValue());
			}
			boolean isChanged = false;
			
			for(CategoryAttributesIo obj : oldList) {
				if(obj!=null) {
					if(checkInconIoORNrmlIO(obj)) {
						if(obj.getMin().equals("1.1111111111111111E+104")) {
							obj.setMin("");
						}
						if(obj.getMax().equals("1.1111111111111111E+104")) {
							obj.setMax("");
						}
						if(!inconModiflstIo.contains(obj)) {
							inconModiflstIo.add(obj);
						}
						isChanged = true;
					}
					if(checkInconStructIO(obj)) {
						if(obj.getMin().equals("1.1111111111111111E+104")) {
							obj.setMin("");
						}
						if(obj.getMax().equals("1.1111111111111111E+104")) {
							obj.setMax("");
						}
						if(!inconModiflstIoStruc.contains(obj)) {
							inconModiflstIoStruc.add(obj);
						}
						isChanged = true;
					}
					
				}
			}
			IEditorPart activeEditor = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor();
		    Collections.sort(inconModiflstIo, new SortByName());
		    Collections.sort(inconModiflstIoStruc, new SortByName());
			if(isChanged) {
				ioCompatMap =isChanged(ioCompatMap,inconModiflstIo,inconModiflstIoStruc);
				/*if(Application.programName.equals("E44"))
				{
					ioCompatMap.replace("Inconsistent I/Os", inconModiflstIo);
				}
				else
				{
					if(!inconModiflstIo.isEmpty())
					{
						ioCompatMap.replace("Inconsistent Normal I/Os", inconModiflstIo);
					}
					if(!inconModiflstIoStruc.isEmpty())
					{
						ioCompatMap.replace("Inconsistent Structured I/Os", inconModiflstIoStruc);
					}
				}*/
			}
			else{
				CategoryAttributesIo categoryObjNormal = new CategoryAttributesIo();
				CategoryAttributesIo categoryObjStructured = new CategoryAttributesIo();
				if(Application.programName.equals("E44"))
				{
					categoryObjNormal.setWarning(ApplicationConstant.INCONSISTENT_IOS+" "+ApplicationConstant.NO_ISSUES);
					inconModiflstIo.add(categoryObjNormal);
					ioCompatMap.replace("Inconsistent I/Os",inconModiflstIo);
					closeListTblAftrEmpty(activeEditor, "Inconsistent I/Os");
				}
				else
				{
					categoryObjNormal.setWarning(ApplicationConstant.INCONSISTENT_IOS_NORMAL+" "+ApplicationConstant.NO_ISSUES);
					inconModiflstIo.add(categoryObjNormal);
					categoryObjStructured.setWarning(ApplicationConstant.INCONSISTENT_IOS_STRUCTURE+" "+ApplicationConstant.NO_ISSUES);
					inconModiflstIoStruc.add(categoryObjStructured);
					ioCompatMap.replace("Inconsistent Normal I/Os", inconModiflstIo);
					ioCompatMap.replace("Inconsistent Structured I/Os", inconModiflstIoStruc);
					closeListTblAftrEmpty(activeEditor, "Inconsistent Normal I/Os");
					closeListTblAftrEmpty(activeEditor, "Inconsistent Structured I/Os");
				}
				
			}
			if(ioCompatMap.containsKey("Duplicate Outputs (No Issues)")) {
				closeListTblAftrEmpty(activeEditor, "Duplicate Outputs");
			}
			displayIODetails(parent, ioCompatMap);
			GridLayoutFactory.fillDefaults().generateLayout(parent);
			addContextMenuToIo();
		}
	}
	
	
	public boolean checkInconIoORNrmlIO(CategoryAttributesIo obj)
	{
		return (obj.getName()!=null && !obj.getName().equals("") && (obj.getWarning().equals("Inconsistent I/Os") || obj.getWarning().equals("Inconsistent Normal I/Os")));
	}
	
	public boolean checkInconStructIO(CategoryAttributesIo obj)
	{
		return (obj.getName()!=null && !obj.getName().equals("") && obj.getWarning().equals("Inconsistent Structured I/Os"));
	}
	
	public Map<String, List<CategoryAttributesIo>> isChanged(Map<String, List<CategoryAttributesIo>> ioCompatMap,List<CategoryAttributesIo> inconModiflstIo,List<CategoryAttributesIo> inconModiflstIoStruc )
	{
		if(Application.programName.equals("E44"))
		{
			ioCompatMap.replace("Inconsistent I/Os", inconModiflstIo);
		}
		else
		{
			if(!inconModiflstIo.isEmpty())
			{
				ioCompatMap.replace("Inconsistent Normal I/Os", inconModiflstIo);
			}
			if(!inconModiflstIoStruc.isEmpty())
			{
				ioCompatMap.replace("Inconsistent Structured I/Os", inconModiflstIoStruc);
			}
		}
		return ioCompatMap;
	}

	/**
	 * Method used to add context menu to I/O Compatibility view
	 */
	private void addContextMenuToIo() {
		MenuManager contextMenu = new MenuManager("#ViewerMenu");
		contextMenu.setRemoveAllWhenShown(true);

		contextMenu.addMenuListener(new IMenuListener() {
			@Override
			public void menuAboutToShow(IMenuManager mgr) {
				try {
					fillContextMenu(mgr);
				} catch (Exception e) {
					LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
					MessageDialog.openConfirm(new Shell(), "Error Message","Error while filling I/O compatibility context menu");
				}
			}
		});

		Menu menu = contextMenu.createContextMenu(tree);
		tree.setMenu(menu);
	}

	/**
	 * Method used to close the I/O list table when there is no data object in the list
	 * @param activeEditor
	 * @param tableName
	 */
	private void closeListTblAftrEmpty(IEditorPart activeEditor, String tableName) {
		if(activeEditor instanceof IOCompatibilityEditor) {
			if(activeEditor.getTitle().equals(tableName)) {
				new EditorServiceImpl().closeAllEditors();
			}
		}
	}
	
	class SortByName implements Comparator<CategoryAttributes> {
		@Override
		public int compare(CategoryAttributes o1, CategoryAttributes o2) {
			// TODO Auto-generated method stub
			return o1.getName().compareTo(o2.getName());
		}
	}

	/**
	 * This method is used to get adapter.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Object getAdapter(Class arg0) {
		return null;
	}

	/**
	 * This method is used to perform actions while disposing the IO Compatibility
	 * view.
	 */
	@Override
	public void dispose() {
		ioViewInstance = null;
		ApplicationActionBarAdvisor.getInstance().action = (Action) ApplicationActionBarAdvisor.getInstance().resetPersObj;
		ApplicationActionBarAdvisor.getInstance().ioCompatWinAction.setChecked(false);
		// Closing all open editors
		closeIOCompatibilityEditor();
	}

	/**
	 * This function is used to close the currently IOCompatibility Editor.
	 */
	private void closeIOCompatibilityEditor() {
		IWorkbenchPage activePage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
		IEditorReference[] editors = activePage.getEditorReferences();
		for (IEditorReference editor : editors) {

			if (editor.getEditor(false) instanceof IOCompatibilityEditor) {
				editor.getEditor(false).dispose();

			}

		}
	}


	/**
	 * Method is used to display IO Compatibility details.
	 * 
	 * @param parent
	 * @param ioCompatibilityListMap
	 */
	private void displayIODetails(final Composite parent,
			Map<String, List<CategoryAttributesIo>> ioCompatMap2) {//get icon image instance for tree 
		final Display display = PlatformUI.getWorkbench().getDisplay();
		Image plugImage = new Image(display,
				IOCompatibilityView.class.getResourceAsStream(IconsPathConstant.ICON_PLUG));
		Image inputOutputImage = new Image(display,
				IOCompatibilityView.class.getResourceAsStream(IconsPathConstant.ICON_INPUT_OUTPUT));
		Image warningImage = new Image(display,
				IOCompatibilityView.class.getResourceAsStream(IconsPathConstant.ICON_WARNING_NEW));

		// Check if view is already available
		if (tree != null && (ApplicationActionBarAdvisor.getInstance().action.getText()
				.equals(ApplicationConstant.IO_COMPATIBILITY)
				|| ApplicationActionBarAdvisor.getInstance().action.getText()
				.equals(ApplicationConstant.CHECK_IOCOMPAT))) {
			tree.removeAll();
		} else {
			tree = new Tree(parent, SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL);
			tree.setSize(290, 260);
			parent.setSize(300, 330);
			tree.addMouseListener(this);
		}

		// Iterate IO warning List details
		for (String warning : ioCompatMap2.keySet()) {

			List<CategoryAttributesIo> ioCompatList = ioCompatMap2.get(warning);

			boolean warningFlag = true;
			TreeItem warningItem = null;
			TreeItem dataObjectItem = null;

			// Iterate Data object list
			for (Iterator<CategoryAttributesIo> iterator = ioCompatList.iterator(); iterator.hasNext();) {
				CategoryAttributesIo category = (CategoryAttributesIo) iterator.next();

				TreeItem compoCategory = null;
				if (warningFlag) {
					warningItem = new TreeItem(tree, 0);
					warningItem.setImage(warningImage);
					
					if(category.getWarning().contains(ApplicationConstant.NO_ISSUES))
					{
						warningItem.setText(category.getWarning());				
						warningItem.setFont(fontStyle);
					}
					else
					{
						warningItem.setText(ApplicationConstant.WARNING_CAPS + category.getWarning());
						warningItem.setFont(fontStyle);
						
					}	
					
					warningFlag = false;				

					if(!category.getWarning().contains(ApplicationConstant.NO_ISSUES))
					{
						dataObjectItem = new TreeItem(warningItem, 0);
						dataObjectItem.setImage(plugImage);
						dataObjectItem.setText(category.getName());
						dataObjectItem.setFont(fontStyle);
						compoCategory = new TreeItem(dataObjectItem, 0);
						compoCategory.setImage(inputOutputImage);
						compoCategory.setText(category.getComponent() + " : " + category.getCategory());
						compoCategory.setFont(fontStyle);

					}


				} else {
					if (dataObjectItem.getText().equalsIgnoreCase(category.getName())) {
						compoCategory = new TreeItem(dataObjectItem, 0);
						compoCategory.setImage(inputOutputImage);
						compoCategory.setText(
								category.getComponent() + " : " + category.getCategory());
						compoCategory.setFont(fontStyle);
					} else {
						dataObjectItem = new TreeItem(warningItem, 0);
						dataObjectItem.setImage(plugImage);
						dataObjectItem.setText(category.getName());
						dataObjectItem.setFont(fontStyle);
						compoCategory = new TreeItem(dataObjectItem, 0);
						compoCategory.setImage(inputOutputImage);
						compoCategory.setText(
								category.getComponent() + " : " + category.getCategory());
						compoCategory.setFont(fontStyle);
					}

				}

			}
		}
	}

	/**
	 * Method used to set focus to this view
	 */
	@Override
	public void setFocus() {
		// nothing to clean up
	}

	/**
	 * This method is used to get tree for I/O compatibility view.
	 * @return
	 */
	public Tree getTree() {
		return this.tree;
	}

	/**
	 * Sent when a mouse button is pressed twice within the (operating system specified) double click period
	 * @param event
	 */
	@Override
	public void mouseDoubleClick(MouseEvent event) {

		final TreeItem item;
		if (tree.getSelection().length > 0) {
			item = tree.getSelection()[0];
		} else {
			return;
		}

		if (item.getText().contains(ApplicationConstant.NO_ISSUES)) {
			return;
		}

		if (item.getItemCount() == 0) {
			// Closing all open editors
			new EditorServiceImpl().closeAllEditors();
			String waringValue = item.getParentItem().getParentItem().getText();
			String dataObject = item.getParentItem().getText();
			String componentName = item.getText().split(" : ")[0];
			String categoryName = item.getText().split(" : ")[1];
			String strWarning[] = waringValue.split(":");

			if (strWarning.length > 1) {
				List<CategoryAttributesIo> ioCompatList = ioCompatMap.get(strWarning[1].trim());
				try {
					Collections.sort(ioCompatList, new SortByName());
					openCompService.findAndOpenComponent(dataObject, componentName, categoryName,
							ioCompatList);
				} catch (EditorInitilizationException e) {
					MessageDialog.openConfirm(new Shell(), "Error Message",
							"Error while filling I/O compatibility context menu");
				}
			}
		}
	}

	/**
	 * Method used for scroll down event of mouse
	 * @param event
	 */
	@Override
	public void mouseDown(MouseEvent event) {
		//nothing to clean-up
	}

	/**
	 * Method used for scroll up event of mouse
	 * @param event
	 */
	@Override
	public void mouseUp(MouseEvent event) {
		//nothing to clean-up
	}
	
	/**
	 * This Method is to get the context menu actions and disable the Open and Close
	 * project option accordingly
	 * 
	 * @param contextMenu
	 */
	protected void fillContextMenu(IMenuManager contextMenu) {

		TreeItem selectedNode = tree.getSelection()[0];
		String warningName = "";
		if(selectedNode.getParentItem()!= null){
			if(selectedNode.getParentItem().getParentItem()!=null){
				warningName = selectedNode.getParentItem().getParentItem().getText();
			}
		}
		
		// Check if the project is selected
		if (selectedNode.getItemCount() == 0 && (warningName.contains(ApplicationConstant.INCONSISTENT_IOS)
				|| warningName.contains(ApplicationConstant.DUPLICATE_OP))) {

			contextMenu.add(new GroupMarker(IWorkbenchActionConstants.MB_ADDITIONS));
			DeleteDataObjectAction delDataObjAction = new DeleteDataObjectAction();
			delDataObjAction.setText(ApplicationConstant.BTNDELDATAOBJ);
			contextMenu.add(delDataObjAction);
		} 
		if (selectedNode.getItemCount() == 0 && (warningName.contains(ApplicationConstant.INCONSISTENT_IOS))) {

			contextMenu.add(new GroupMarker(IWorkbenchActionConstants.MB_ADDITIONS));
			UseThisObjectAction useThisObjAction = new UseThisObjectAction();
			useThisObjAction.setText(ApplicationConstant.USE_THIS_OBJECT);
			contextMenu.add(useThisObjAction);
			
		} 

	}
	
	/**
	 * Method used for refreshing IOEditor and view after performing Use This Object operation
	 * @throws EditorInitilizationException 
	 */
	public void refreshIOAfterUseThisObj(CategoryAttributes dataOfUseThisObj) throws EditorInitilizationException {
			
		List<CategoryAttributesIo> oldList = ioCompatMap.get(dataOfUseThisObj.getWarning());
		List<CategoryAttributes> usedList = new ArrayList<>();
		
		for(CategoryAttributesIo obj : oldList) {
			usedList.add((CategoryAttributes) obj);
		}
	//	usedList = oldList.stream().parallel().collect(Collectors.toList());
		
		Iterator<CategoryAttributes> listIterator = usedList.iterator();			
				
		while(listIterator.hasNext()) {

			CategoryAttributes categoryObject = listIterator.next();
			//added one more condition to check if name with empty string exist in Inconsistent i/os list
			if(categoryObject.getName().equals(dataOfUseThisObj.getName()) || categoryObject.getName().equals("")) {
				listIterator.remove();
			}
		}

		
		if(!usedList.isEmpty()) {
			List<CategoryAttributesIo> newlist = new ArrayList<>();
			for(CategoryAttributes obj : usedList) {
				newlist.add((CategoryAttributesIo) obj);
			}
			ioCompatMap.put(dataOfUseThisObj.getWarning(),newlist);
		}else {
			CategoryAttributesIo categoryObj = new CategoryAttributesIo();
			categoryObj.setWarning(ApplicationConstant.INCONSISTENT_IOS+" "+ApplicationConstant.NO_ISSUES);
			usedList.add(categoryObj);
			List<CategoryAttributesIo> newlist = new ArrayList<>();
			for(CategoryAttributes obj : usedList) {
				newlist.add((CategoryAttributesIo) obj);
			}
			ioCompatMap.put(ApplicationConstant.INCONSISTENT_IOS,newlist);
		}
				
		JsonArray jsonArray = new JsonArray();
		for(String warning: ioCompatMap.keySet()) {
			JsonElement jsonElement = new JsonParser().parse(GsonUtil.provider().toJSON(ioCompatMap.get(warning)));
			jsonArray.add(jsonElement);
		}
		
		//refresh view and editor
		Application.ioJsonElement = jsonArray;	
		IOCompatibilityView.getIOCompatibilityViewInstance().createIOPartControl();
	
		IEditorPart activeEditor = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor();
		
		if(activeEditor instanceof IOCompatibilityEditor) {
			new EditorServiceImpl().closeAllEditors();
			
			List<CategoryAttributesIo> ioList = ioCompatMap.get(dataOfUseThisObj.getWarning());
			if(null!=ioList.get(0) && !ioList.isEmpty() && ioList.get(0).getName()!=null) {
				try {
					openCompService.findAndOpenComponent(dataOfUseThisObj.getName(),dataOfUseThisObj.getComponent(),dataOfUseThisObj.getCategory(), ioList);
				} catch (Exception e) {
					LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
					throw new EditorInitilizationException("Error while finding and opening component", e);
				}
			}else {
				new EditorServiceImpl().closeAllEditors();
			}
			
			
		}
	} 





}
