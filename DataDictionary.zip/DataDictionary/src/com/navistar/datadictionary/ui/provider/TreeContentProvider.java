package com.navistar.datadictionary.ui.provider;

import java.util.List;

import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.Viewer;

import com.navistar.datadictionary.model.Node;

/**
 * This class is used for tree view of projects in project explorer
 * 
 * @author nikitak1
 *
 */
public class TreeContentProvider implements ITreeContentProvider {
	/**
	 * This method is used to get children of the input element.
	 * 
	 * @param parentElement
	 */
	public Object[] getChildren(Object parentElement) {
		@SuppressWarnings("rawtypes")
		List subcats = ((Node) parentElement).getSubCategories();
		return subcats == null ? new Object[0] : subcats.toArray();
	}

	/**
	 * This method is used to get the parent of the input element
	 */
	public Object getParent(Object element) {
		return ((Node) element).getParent();
	}

	/**
	 * This method is used to check if the input element has children
	 */
	public boolean hasChildren(Object element) {
		return ((Node) element).getSubCategories() != null;
	}

	/**
	 * This method is used to get all the parent as well as child elements of the
	 * input element
	 */
	@SuppressWarnings("rawtypes")
	public Object[] getElements(Object inputElement) {
		if (inputElement != null) {

			return ((List) inputElement).toArray();

		}
		return new Object[0];
	}

	/**
	 * This method is used to dispose the tree contents
	 */
	public void dispose() {
		// nothing to clean up
	}

	/**
	 * This method is used to handle the changed in input
	 */
	public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
		// nothing to clean up
	}

}
