package com.navistar.datadictionary.ui.provider;

import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.swt.graphics.Image;

import com.navistar.datadictionary.model.Node;

/**
 * This method is used to create custom labels for tree node in project explorer view
 * @author nikitak1
 *
 */
public class CustomLabelProvider implements ILabelProvider {
	 
	/**
	 * This method is used to get the name of tree element
	 * @param element tree element
	 */
	public String getText(Object element) {
	    return ((Node) element).getName();
	}	 

	/**
	 * This method is used to implement the custom listener for tree element
	 * @param iLabelProviderListener
	 */
	@Override
	public void addListener(ILabelProviderListener iLblProvider) {		
		//nothing to clean up
	}
	
	/**
	 * This method is used to dispose the tree element's label
	 */
	@Override
	public void dispose() {
		//nothing to clean up	
	}
	
	/**
	 * This method is used to check the label property
	 * @param element tree element
	 * @param arg1 property name
	 */
	@Override
	public boolean isLabelProperty(Object element, String propertyName) {
		return false;
	}

	/**
	 * This method is used to remove the listener of tree element's label
	 * @param iLabelProviderListener
	 */
	@Override
	public void removeListener(ILabelProviderListener iLblProvider) {
		//nothing to clean up
	}

	/**
	 * This method is used to get the image of tree element
	 * @param Object tree element
	 */
	@Override
	public Image getImage(Object element) {
		return null;
	}
	  
	}

