package com.navistar.datadictionary.ui.nattable;

import java.util.Arrays;
import java.util.List;

import org.eclipse.nebula.widgets.nattable.data.IColumnPropertyAccessor;

import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.model.CategoryAttributesIo;

/**
 * The class is used to access the column property of the category tab of the table.
 * 
 * @author VijayK13
 * @param <T>
 *
 */
public class InputColumnPropertyAccessor<T> implements IColumnPropertyAccessor<T> {

	/** List of all the column */
	private static final List<String> PROPERTY_NAMES =
			Arrays.asList("warning","category","name","structureElementname","value","description","component","baseType","offset","slope","min",
					"max","unit","initialValue","dimensions","dimensionsMode","sampleTime","samplingMode",
					"complexity","swCalibrationAccess","coderInfo","displayFormat", "memorySection", "oldName", "flag");

	/**
	 *  This method is used to get the column data based on the column index.
	 *  
	 *  @param inputObject category object
	 *  @param columnIndex column index
	 */
	@Override
	public Object getDataValue(T object, int columnIndex) {
		CategoryAttributes inputObject = null;
		CategoryAttributesIo ioObject = null;
		String attributes = null;
		if(object instanceof CategoryAttributesIo)
		{
			ioObject = (CategoryAttributesIo)object;
			attributes = getAttributes(columnIndex, ioObject);
			
		}else if(object instanceof CategoryAttributes) {
			inputObject = (CategoryAttributes)object;
			attributes = getAttributes(columnIndex, inputObject);
			
		}
		else
		{
			return null;
		}		
		return attributes;
			//	getAttributes(columnIndex,inputObject);
	}
	
	/**
	 * Method used to get attribute value depending on column index
	 * @param columnIndex
	 * @param inputObject
	 * @return
	 */
	private String getAttributes(int columnIndex,CategoryAttributes inputObject) {
		switch (columnIndex) {
		case 0:
			return inputObject.getWarning();	
		case 1:
			return inputObject.getCategory();			
		case 2:
			return inputObject.getName();	                
		case 4:
			return inputObject.getValue();			
		case 5:
			return inputObject.getDescription();
		//case 5:
			//return inputObject.getSubSignalName();
		case 6:
			return inputObject.getComponent();	
		case 7:
			return inputObject.getBaseType();
		case 8:
			return inputObject.getOffset();			
		case 9:
			return inputObject.getSlope();
		case 10:
			return inputObject.getMin();
		case 11:
			return inputObject.getMax();
		case 12:
			return inputObject.getUnit();
		case 13:
			return inputObject.getInitialValue();	
		case 14:
			return inputObject.getDimensions();
		
		}
	//	return "";
		
		String data = getHiddenAttr(columnIndex, inputObject);
		return data;		
	}
	
	private String getHiddenAttr(int columnIndex, CategoryAttributes inputObject) {
		switch(columnIndex) {
		case 3:
			return inputObject.getStructureElementName();
		case 15:
			return inputObject.getDimensionsMode();
		case 16:
			return inputObject.getSampleTime();
		/*case 16:
			return inputObject.getSamplingMode();*/
		case 17:
			return inputObject.getComplexity();
		case 18:
			return inputObject.getSwCalAccess();
		case 20:
			return inputObject.getDisplayFormat();
		case 19:
			return inputObject.getCoderInfo();
		case 21:
			return inputObject.getMemorySection();
		case 22:
			return inputObject.getOldName();
		
		}
		return "";
	}

	private String getAttributes(int columnIndex,CategoryAttributesIo inputObject) {
		switch (columnIndex) {
		case 0:
			return inputObject.getWarning();	
		case 1:
			return inputObject.getCategory();			
		case 2:
			return inputObject.getName();	                
		case 4:
			return inputObject.getValue();			
		case 5:
			return inputObject.getDescription();
		case 6:
			return inputObject.getComponent();	
		case 7:
			return inputObject.getBaseType();
		case 8:
			return inputObject.getOffset();			
		case 9:
			return inputObject.getSlope();
		case 10:
			return inputObject.getMin();
		case 11:
			return inputObject.getMax();
		case 12:
			return inputObject.getUnit();
		case 13:
			return inputObject.getInitialValue();	
		case 14:
			return inputObject.getDimensions();
		}
		String data = getHiddenAttrIO(columnIndex, inputObject);
		return data;
	}

	/**
	 * @param columnIndex
	 * @param inputObject
	 */
	private String getHiddenAttrIO(int columnIndex, CategoryAttributesIo inputObject) {
		switch(columnIndex) {
		case 3:
			return inputObject.getStructureElementName(); 
		case 15:
			return inputObject.getDimensionsMode();
		case 16:
			return inputObject.getSampleTime();
		/*case 16:
			return inputObject.getSamplingMode();*/
		case 17:
			return inputObject.getComplexity();
		case 18:
			return inputObject.getSwCalAccess();
		case 19:
			return inputObject.getDisplayFormat();
		case 20:
			return inputObject.getCoderInfo();
		case 21:
			return inputObject.getMemorySection();
		case 22:
			return inputObject.getOldName();
		case 23:
			return inputObject.getFlag();
		}
		return "";
	}

	/**
	 *  This method is used to set the column data into category object based on the column index and new value.
	 *  
	 *  @param inputObject category object
	 *  @param columnIndex column index
	 */
	@Override
	public void setDataValue(T object, int columnIndex, Object newValue) {
		CategoryAttributes inputObject = null;
		CategoryAttributesIo ioObject = null;
		if(object instanceof CategoryAttributesIo)
		{
			ioObject = (CategoryAttributesIo)object;
			setAttributes(columnIndex, newValue, ioObject);
			
		}else if(object instanceof CategoryAttributes) {
			inputObject = (CategoryAttributes)object;
			setAttributes(columnIndex, newValue, inputObject);
			
		}
		else
		{
			return ;
		}
			
	}

	/**
	 * Method used to set value depending on column index
	 * @param columnIndex
	 * @param newValue
	 * @param inputObject
	 */
	private void setAttributes(int columnIndex, Object newValue, CategoryAttributes inputObject) {
		switch (columnIndex) {
		case 0:
			inputObject.setWarning((String) newValue);
			break;
		case 1:
			inputObject.setCategory((String) newValue);
			break;
		case 2:
			inputObject.setName((String) newValue);
			break;					
		case 4:
			inputObject.setValue((String) newValue);
			break;					
		case 5:
			inputObject.setDescription((String) newValue);
			break;
		case 6:
			inputObject.setComponent((String) newValue);
			break;
		case 7:
			inputObject.setBaseType((String) newValue);
			break;
		case 8:
			inputObject.setOffset((String) newValue);
			break;
		case 9:
			inputObject.setSlope((String) newValue);
			break;
		case 10:
			inputObject.setMin((String) newValue);
			break;
		case 11:
			inputObject.setMax((String) newValue);
			break;
		case 12:
			inputObject.setUnit((String) newValue);
			break;
		case 13:
			inputObject.setInitialValue((String) newValue);
			break;
		case 14:
			inputObject.setDimensions((String) newValue);					 
			break;
		}
		setHiddenAttr(columnIndex, newValue, inputObject);	
	
		
	}
	
	private void setHiddenAttr(int columnIndex, Object newValue, CategoryAttributes inputObject) {
		switch(columnIndex) {
		case 3:
			inputObject.setStructureElementName((String) newValue);
			break;
		case 15:
			inputObject.setDimensionsMode((String) newValue);
			break;
		case 16:
			inputObject.setSampleTime((String) newValue);
			break;
		/*case 16:
			inputObject.setSamplingMode((String) newValue);
			break;*/
		case 17:
			inputObject.setComplexity((String) newValue);
			break;
		case 18:
			inputObject.setSwCalAccess((String) newValue);
			break;
		case 20:
			inputObject.setDisplayFormat((String) newValue);
			break;
		case 19:
			inputObject.setCoderInfo((String) newValue);
			break;
		case 21:
			inputObject.setMemorySection((String) newValue);
			break;
			
		case 22:
			inputObject.setOldName((String) newValue);
			break;
		
		}
		
	}

	private void setAttributes(int columnIndex, Object newValue, CategoryAttributesIo inputObject) {
		switch (columnIndex) {			
			
		case 0:
			inputObject.setWarning((String) newValue);
			break;
		case 1:
			inputObject.setCategory((String) newValue);
			break;
		case 2:
			inputObject.setName((String) newValue);
			break;					
		case 4:
			inputObject.setValue((String) newValue);
			break;					
		case 5:
			inputObject.setDescription((String) newValue);
			break;
		case 6:
			inputObject.setComponent((String) newValue);
			break;
		case 7:
			inputObject.setBaseType((String) newValue);
			break;
		case 8:
			inputObject.setOffset((String) newValue);
			break;
		case 9:
			inputObject.setSlope((String) newValue);
			break;
		case 10:
			inputObject.setMin((String) newValue);
			break;
		case 11:
			inputObject.setMax((String) newValue);
			break;
		case 12:
			inputObject.setUnit((String) newValue);
			break;
		case 13:
			inputObject.setInitialValue((String) newValue);
			break;
		case 14:
			inputObject.setDimensions((String) newValue);					 
			break;
		}
		setHiddenAttrIO(columnIndex, newValue, inputObject);
	}

	/**
	 * @param columnIndex
	 * @param newValue
	 * @param inputObject
	 */
	private void setHiddenAttrIO(int columnIndex, Object newValue, CategoryAttributesIo inputObject) {
		switch(columnIndex) {
		case 3:
			inputObject.setStructureElementName((String) newValue);					 
			break;
		case 15:
			inputObject.setDimensionsMode((String) newValue);
			break;
		case 16:
			inputObject.setSampleTime((String) newValue);
			break;
		/*case 16:
			inputObject.setSamplingMode((String) newValue);
			break;*/
		case 17:
			inputObject.setComplexity((String) newValue);
			break;
		case 18:
			inputObject.setSwCalAccess((String) newValue);
			break;
		case 20:
			inputObject.setDisplayFormat((String) newValue);
			break;
		case 19:
			inputObject.setCoderInfo((String) newValue);
			break;	
		case 21:
			inputObject.setMemorySection((String) newValue);
			break;
		case 22:
			inputObject.setOldName((String) newValue);
			break;
		case 23:
			inputObject.setFlag((String) newValue);
			break;
		}
	}

	/**
	 * Method is used to get column count
	 */
	@Override
	public int getColumnCount() {	        
		return PROPERTY_NAMES.size();
	}

	/**
	 * Method is used to get column property
	 */
	@Override
	public String getColumnProperty(int columnIndex) {
		return PROPERTY_NAMES.get(columnIndex);
	}

	/**
	 * Method is used to get column index
	 */
	@Override
	public int getColumnIndex(String propertyName) {
		return PROPERTY_NAMES.indexOf(propertyName);
	}

}
