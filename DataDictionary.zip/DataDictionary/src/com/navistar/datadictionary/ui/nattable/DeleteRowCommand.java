package com.navistar.datadictionary.ui.nattable;

import org.eclipse.nebula.widgets.nattable.command.AbstractRowCommand;
import org.eclipse.nebula.widgets.nattable.command.ILayerCommand;
import org.eclipse.nebula.widgets.nattable.layer.ILayer;

/**
 * Class is used to for delete row from natTable
 * @author minalc
 */
public class DeleteRowCommand extends AbstractRowCommand {

	/**
	 * Public Constructor to initialize layer and row position of NatTable.
	 * @param layer
	 * @param rowPosition
	 */
    public DeleteRowCommand(ILayer layer, int rowPosition) {
        super(layer, rowPosition);
    }

    /**
     * Protected constructor.
     * @param command
     */
    protected DeleteRowCommand(DeleteRowCommand command) {
        super(command);
    }

    /**
     * This method is used to clone the command.
     */
    @Override
    public ILayerCommand cloneCommand() {
        return new DeleteRowCommand(this);
    }

}
