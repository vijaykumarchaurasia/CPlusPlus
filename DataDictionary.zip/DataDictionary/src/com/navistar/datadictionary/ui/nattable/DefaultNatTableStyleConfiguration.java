package com.navistar.datadictionary.ui.nattable;

import org.eclipse.nebula.widgets.nattable.config.AbstractRegistryConfiguration;
import org.eclipse.nebula.widgets.nattable.config.CellConfigAttributes;
import org.eclipse.nebula.widgets.nattable.config.IConfigRegistry;
import org.eclipse.nebula.widgets.nattable.data.convert.DefaultDisplayConverter;
import org.eclipse.nebula.widgets.nattable.painter.cell.ICellPainter;
import org.eclipse.nebula.widgets.nattable.painter.cell.TextPainter;
import org.eclipse.nebula.widgets.nattable.painter.cell.decorator.LineBorderDecorator;
import org.eclipse.nebula.widgets.nattable.style.BorderStyle;
import org.eclipse.nebula.widgets.nattable.style.CellStyleAttributes;
import org.eclipse.nebula.widgets.nattable.style.HorizontalAlignmentEnum;
import org.eclipse.nebula.widgets.nattable.style.Style;
import org.eclipse.nebula.widgets.nattable.style.VerticalAlignmentEnum;
import org.eclipse.nebula.widgets.nattable.util.GUIHelper;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;

/**
 * This class is used for rendering and setting the default configuration for
 * the NatTable.
 * 
 * @author nikitak1
 *
 */
public class DefaultNatTableStyleConfiguration extends AbstractRegistryConfiguration {

	/** Set the background color as white for the table */
	public Color bgColor = GUIHelper.COLOR_WHITE;

	/** Set the foreground color as black for the table */
	public Color fgColor = GUIHelper.COLOR_BLACK;

	/** Set the background color as white for the gradient */
	public Color gradientBgColor = GUIHelper.COLOR_WHITE;

	/** Set the foreground color as sky blue for the gradient */
	public Color gradientFgColor = GUIHelper.getColor(136, 212, 215);

	/** Set the default font for the table */
	public Font font = GUIHelper.DEFAULT_FONT;

	/** Set the horizontal alignment for the table */
	public HorizontalAlignmentEnum hAlign = HorizontalAlignmentEnum.LEFT;

	/** Set the vertical alignment for the table */
	public VerticalAlignmentEnum vAlign = VerticalAlignmentEnum.TOP;

	/** Set the border style for the table */
	public BorderStyle borderStyle = null;

	/** Cell painter to display cell in table */
	public ICellPainter cellPainter = new LineBorderDecorator(new TextPainter());

	/**
	 * This method is used to configure NatTable's registry using custom
	 * ICellPainter.
	 *
	 * @param configRegistry
	 *            The configRegistry instance to register configuration values to
	 *            table.
	 */
	@Override
	public void configureRegistry(IConfigRegistry configRegistry) {
		configRegistry.registerConfigAttribute(CellConfigAttributes.CELL_PAINTER, this.cellPainter);
		
		Style cellStyle = new Style();
		cellStyle.setAttributeValue(CellStyleAttributes.BACKGROUND_COLOR, this.bgColor);
		cellStyle.setAttributeValue(CellStyleAttributes.FOREGROUND_COLOR, this.fgColor);
		cellStyle.setAttributeValue(CellStyleAttributes.GRADIENT_BACKGROUND_COLOR, this.gradientBgColor);
		cellStyle.setAttributeValue(CellStyleAttributes.GRADIENT_FOREGROUND_COLOR, this.gradientFgColor);
		cellStyle.setAttributeValue(CellStyleAttributes.FONT, this.font);
		cellStyle.setAttributeValue(CellStyleAttributes.HORIZONTAL_ALIGNMENT, this.hAlign);
		cellStyle.setAttributeValue(CellStyleAttributes.VERTICAL_ALIGNMENT, this.vAlign);
		cellStyle.setAttributeValue(CellStyleAttributes.BORDER_STYLE, this.borderStyle);

		configRegistry.registerConfigAttribute(CellConfigAttributes.CELL_STYLE, cellStyle);
		
		configRegistry.registerConfigAttribute(CellConfigAttributes.DISPLAY_CONVERTER, new DefaultDisplayConverter());
	}
}