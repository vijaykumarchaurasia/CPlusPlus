package com.navistar.datadictionary.ui.nattable;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.nebula.widgets.nattable.NatTable;
import org.eclipse.nebula.widgets.nattable.config.CellConfigAttributes;
import org.eclipse.nebula.widgets.nattable.config.ConfigRegistry;
import org.eclipse.nebula.widgets.nattable.config.IConfigRegistry;
import org.eclipse.nebula.widgets.nattable.data.IColumnPropertyAccessor;
import org.eclipse.nebula.widgets.nattable.data.IDataProvider;
import org.eclipse.nebula.widgets.nattable.data.ListDataProvider;
import org.eclipse.nebula.widgets.nattable.dataset.person.PersonWithAddress;
import org.eclipse.nebula.widgets.nattable.edit.action.KeyEditAction;
import org.eclipse.nebula.widgets.nattable.edit.action.MouseEditAction;
import org.eclipse.nebula.widgets.nattable.edit.config.DefaultEditBindings;
import org.eclipse.nebula.widgets.nattable.edit.config.DefaultEditConfiguration;
import org.eclipse.nebula.widgets.nattable.edit.editor.IComboBoxDataProvider;
import org.eclipse.nebula.widgets.nattable.examples.fixtures.StyledColumnHeaderConfiguration;
import org.eclipse.nebula.widgets.nattable.examples.fixtures.StyledRowHeaderConfiguration;
import org.eclipse.nebula.widgets.nattable.extension.glazedlists.GlazedListsEventLayer;
import org.eclipse.nebula.widgets.nattable.extension.glazedlists.filterrow.ComboBoxFilterRowHeaderComposite;
import org.eclipse.nebula.widgets.nattable.filterrow.combobox.ComboBoxFilterIconPainter;
import org.eclipse.nebula.widgets.nattable.filterrow.combobox.ComboBoxFilterRowConfiguration;
import org.eclipse.nebula.widgets.nattable.filterrow.combobox.FilterRowComboBoxCellEditor;
import org.eclipse.nebula.widgets.nattable.grid.data.DefaultColumnHeaderDataProvider;
import org.eclipse.nebula.widgets.nattable.grid.data.DefaultCornerDataProvider;
import org.eclipse.nebula.widgets.nattable.grid.data.DefaultRowHeaderDataProvider;
import org.eclipse.nebula.widgets.nattable.grid.layer.ColumnHeaderLayer;
import org.eclipse.nebula.widgets.nattable.grid.layer.CornerLayer;
import org.eclipse.nebula.widgets.nattable.grid.layer.GridLayer;
import org.eclipse.nebula.widgets.nattable.grid.layer.RowHeaderLayer;
import org.eclipse.nebula.widgets.nattable.grid.layer.config.DefaultRowStyleConfiguration;
import org.eclipse.nebula.widgets.nattable.hideshow.ColumnHideShowLayer;
import org.eclipse.nebula.widgets.nattable.hideshow.RowHideShowLayer;
import org.eclipse.nebula.widgets.nattable.hideshow.command.ShowAllRowsCommand;
import org.eclipse.nebula.widgets.nattable.layer.DataLayer;
import org.eclipse.nebula.widgets.nattable.layer.ILayer;
import org.eclipse.nebula.widgets.nattable.layer.cell.ColumnOverrideLabelAccumulator;
import org.eclipse.nebula.widgets.nattable.painter.cell.TextPainter;
import org.eclipse.nebula.widgets.nattable.painter.cell.decorator.PaddingDecorator;
import org.eclipse.nebula.widgets.nattable.reorder.ColumnReorderLayer;
import org.eclipse.nebula.widgets.nattable.selection.SelectionLayer;
import org.eclipse.nebula.widgets.nattable.selection.config.DefaultSelectionStyleConfiguration;
import org.eclipse.nebula.widgets.nattable.sort.ISortModel;
import org.eclipse.nebula.widgets.nattable.sort.SortDirectionEnum;
import org.eclipse.nebula.widgets.nattable.sort.SortHeaderLayer;
import org.eclipse.nebula.widgets.nattable.sort.command.SortCommandHandler;
import org.eclipse.nebula.widgets.nattable.sort.config.SingleClickSortConfiguration;
import org.eclipse.nebula.widgets.nattable.style.BorderStyle;
import org.eclipse.nebula.widgets.nattable.style.BorderStyle.LineStyleEnum;
import org.eclipse.nebula.widgets.nattable.style.CellStyleAttributes;
import org.eclipse.nebula.widgets.nattable.style.DisplayMode;
import org.eclipse.nebula.widgets.nattable.style.HorizontalAlignmentEnum;
import org.eclipse.nebula.widgets.nattable.style.Style;
import org.eclipse.nebula.widgets.nattable.style.VerticalAlignmentEnum;
import org.eclipse.nebula.widgets.nattable.ui.binding.UiBindingRegistry;
import org.eclipse.nebula.widgets.nattable.ui.matcher.CellEditorMouseEventMatcher;
import org.eclipse.nebula.widgets.nattable.ui.matcher.KeyEventMatcher;
import org.eclipse.nebula.widgets.nattable.ui.matcher.LetterOrDigitKeyEventMatcher;
import org.eclipse.nebula.widgets.nattable.ui.matcher.MouseEventMatcher;
import org.eclipse.nebula.widgets.nattable.ui.menu.AbstractHeaderMenuConfiguration;
import org.eclipse.nebula.widgets.nattable.ui.menu.HeaderMenuConfiguration;
import org.eclipse.nebula.widgets.nattable.ui.menu.IMenuItemProvider;
import org.eclipse.nebula.widgets.nattable.ui.menu.MenuItemProviders;
import org.eclipse.nebula.widgets.nattable.ui.menu.PopupMenuBuilder;
import org.eclipse.nebula.widgets.nattable.util.GUIHelper;
import org.eclipse.nebula.widgets.nattable.viewport.ViewportLayer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PlatformUI;

import com.google.gson.JsonElement;
import com.navistar.datadictionary.action.EditorPreference;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.handler.DeleteRowCommandHandler;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.model.CategoryAttributesIo;
import com.navistar.datadictionary.model.FontStyleDAO;
import com.navistar.datadictionary.ui.config.Activator;
import com.navistar.datadictionary.ui.config.Application;
import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.ui.config.DataDictionaryApplication;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.ui.editors.ComponentIpEditor;
import com.navistar.datadictionary.ui.editors.IOCompatibilityEditor;
import com.navistar.datadictionary.ui.editors.ResolveInconAttributesEditor;
import com.navistar.datadictionary.ui.views.CustomFilterWindow;

import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.FilterList;
import ca.odell.glazedlists.GlazedLists;
import ca.odell.glazedlists.SortedList;
import ca.odell.glazedlists.TransformedList;

/**
 * This class is used to create data and header layer in category table.
 * 
 * @author Vijayk13
 *
 */
public class CreateNatTable {

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(CreateNatTable.class);
	
	/** Category names to hide*/
	public static Map<String, List<Integer>> hideListMap;
	
	static {
		hideListMap = new HashMap<String, List<Integer>>();
		Application.configCatList = new ArrayList<>();
		Map<String, List<Integer>> map = new HashMap<>();
		try {
			map = dispCategoryAndColumns();
			//dispCategoryAndColumnsAttributes();
		} catch (Exception exception) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, exception);
		}
		if(map!=null) {
			Iterator<Entry<String, List<Integer>>> hmIterator = map.entrySet().iterator();

			while (hmIterator.hasNext()) {
				Map.Entry mapElement = (Map.Entry)hmIterator.next();
				String cat = mapElement.getKey().toString();
				if(!Application.configCatList.contains(cat)) {
					Application.configCatList.add(cat);
				}
				List<Integer> list = (List<Integer>) mapElement.getValue();
			//	Integer[] arr = list.toArray(new Integer[list.size()]);
				Integer[] arr = list.toArray(new Integer[0]);
				hideListMap.put(cat, Arrays.asList(arr));
			}

		}

	}


	/**
	 * Method used to get the column hide/show data from visibility named sheet of excel file
	 * @return
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public static Map<String,List<Integer>> dispCategoryAndColumns() throws FileNotFoundException, IOException {
		Map<String,List<Integer>> catAttrMap = null;
		if(Application.projConfigPath!=null) {
			FileInputStream file = new FileInputStream(new File(Application.projConfigPath));
			//Create Workbook instance holding reference to .xlsx file
			XSSFWorkbook workbook = new XSSFWorkbook(file);
			String program = Application.programName;
			String visibility = "Visibility";
			if(program!=null) {
				String sheetName = program+"_"+visibility;
				//Get first/desired sheet from the workbook
				XSSFSheet sheet = workbook.getSheet(sheetName);

				catAttrMap = new HashMap<>();
				String category = "";
				List<String> catList = new ArrayList<>();
				List<List<Integer>> allIndexList = new LinkedList<>();
				List<Integer> indList;
				int catIndex = 0;
				if(sheet!=null) {
					//Iterate through each rows one by one
					Iterator<Row> rowIterator = sheet.iterator();
					while (rowIterator.hasNext()) 
					{
						indList = new ArrayList<>();
						Row row = rowIterator.next();
						//For each row, iterate through all the columns
						Iterator<Cell> cellIterator = row.cellIterator();

						while (cellIterator.hasNext()) 
						{
							Cell cell = cellIterator.next();
							//Check the cell type and format accordingly
							switch (cell.getCellType()) 
							{
							// case Cell.CELL_TYPE_NUMERIC:
							//    break;
							case Cell.CELL_TYPE_STRING:
								if(cell.getColumnIndex()==0) {
									if(cell.getRowIndex()>0) {
										category = cell.getStringCellValue();
										catList.add(category);
									}
								}
								if(cell.getStringCellValue().equals("hidden")) {
									int actual = cell.getColumnIndex() - 1;
									if (actual<= 2)
									{
										indList.add(actual);										
									}
									else
									{
									indList.add(actual+1);
									}
								}

								break;
							}
						}
						if(!indList.isEmpty()) {
							if (!indList.contains(3))
							{
								indList.add(3);
							}
							indList.add(20);
							indList.add(21);
							indList.add(22);
							indList.add(23);
							indList.add(24);
							allIndexList.add(indList);
						}	
					}

					for(String cat : catList) {

						catAttrMap.put(cat, allIndexList.get(catIndex));
						catIndex++;
					}
					Application.catColumnMap = catAttrMap;
					file.close();
					return catAttrMap;
				}
			}
		}
		return catAttrMap;
	}
	
	////////////////////////////////////////////////////////////////////////////////
	public static Map<String, List<String>> dispCategoryAndColumnsAttributes() throws FileNotFoundException, IOException {
		Map<String,List<String>> catAttrMap = null;
		if(Application.projConfigPath!=null) {
			FileInputStream file = new FileInputStream(new File(Application.projConfigPath));
			//Create Workbook instance holding reference to .xlsx file
			XSSFWorkbook workbook = new XSSFWorkbook(file);
			String program = Application.programName;
			String objectType = "ObjectType";
			if(program!=null) {
				String sheetName = program+"_"+objectType;
				//Get first/desired sheet from the workbook
				XSSFSheet sheet = workbook.getSheet(sheetName);

				catAttrMap = new HashMap<>();
				String category = "";
				List<String> catList = new ArrayList<>();
				List<List<String>> allIndexList = new LinkedList<>();
				List<String> indList;
				int catIndex = 0;
				if(sheet!=null) {
					//Iterate through each rows one by one
					Iterator<Row> rowIterator = sheet.iterator();
					while (rowIterator.hasNext()) 
					{
						indList = new ArrayList<>();
						Row row = rowIterator.next();
						//For each row, iterate through all the columns
						Iterator<Cell> cellIterator = row.cellIterator();

						while (cellIterator.hasNext()) 
						{
							Cell cell = cellIterator.next();
							//Check the cell type and format accordingly
							switch (cell.getCellType()) 
							{
							case Cell.CELL_TYPE_NUMERIC:
								if(cell.getColumnIndex()==1) {
									if(cell.getRowIndex()>=0) {
										category = String.valueOf(cell.getNumericCellValue());
										catList.add(category);
									}
								}
								if(cell.getColumnIndex()>1) {
									if(cell.getRowIndex()>=0) {
								String cellValue =String.valueOf((int)cell.getNumericCellValue());
								indList.add(cellValue);
								}
								}
								break;
								
							case Cell.CELL_TYPE_STRING:
								if(cell.getColumnIndex()==1) {
									if(cell.getRowIndex()>=0) {
										category = cell.getStringCellValue();
										catList.add(category);
									}
								}
								if(cell.getColumnIndex()>1) {
									if(cell.getRowIndex()>=0) {
								String cellValue =cell.getStringCellValue();
								indList.add(cellValue);
								}
								}
								break;
							}
								
							}
						if(!indList.isEmpty())
						{
						allIndexList.add(indList);
						}
						
						}

					for(String cat : catList) {

						catAttrMap.put(cat, allIndexList.get(catIndex));
						catIndex++;
					}
					Application.catColumnAttributeMap = catAttrMap;
					file.close();
					return catAttrMap;
				}
			}
		}
		return catAttrMap;
	}
	
	public String hiddenAttributeValues(String category, String columnName)
	{
		List<String> list1 = Application.catColumnAttributeMap.get("Category Fields");
		int indexValue = list1.indexOf(columnName);
		for(String catName : Application.catColumnAttributeMap.keySet())
		{
			if(catName.equals(category))
			{
				List<String> list = Application.catColumnAttributeMap.get(category);
				if(Application.programName.equals("E44"))
				{
					if (category.equals("Axis") || category.equals("Calibration") || category.equals("Curve") || category.equals("Input")|| category.equals("Map") || category.equals("Output"))
					{
						list.add("");
					}
				}
				if (!list.get(indexValue).equals("NA"))
				{
					return list.get(indexValue);
				}
				}
		}
		return "null";
	}

	
	////////////////////////////////////////////////////////////////////////////////

	/** Column property accessor */
	private IColumnPropertyAccessor<CategoryAttributes> colPropAccessor = new InputColumnPropertyAccessor<CategoryAttributes>();
	
	private IColumnPropertyAccessor<CategoryAttributesIo> colPropAccessorIo = new InputColumnPropertyAccessor<CategoryAttributesIo>();

	/** array of attributes */
	private String[] propertyNames = { "warning", "category", "name","structureElementname", "value", "description", "component", "baseType",
			"offset", "slope", "min", "max", "unit", "initialValue", "dimensions", "dimensionsMode", "sampleTime",
			 "complexity", "swCalibrationAccess", "coderInfo","displayFormat","memorySection", "oldName","flag" };

	public static String colWarning = "warning";
	public static String colCategory = "category";
	public static String colName = "name";
	public static String colValue = "value";
	public static String colDesc = "description";
	public static String colComp = "component";
	public static String colBaseType = "baseType";
	public static String colOffset = "offset";
	public static String colSlope = "slope";
	public static String colMin = "min";
	public static String colMax = "max";
	public static String colUnit = "unit";
	public static String colComplex = "complexity";
	public static String colDim = "dimensions";
	public static String colDimMode = "dimensionsMode";
	public static String colSamplTim = "sampleTime";
//	public static String colSampMode = "samplingMode";
	public static String colInitVal = "initialValue";
	public static String colSwCalAccess = "swCalibrationAccess";
	public static String colDispFor = "displayFormat";
	public static String colCoderInf = "coderInfo";
	public static String colMemorySection = "memorySection";
	public static String colOldName = "oldName";
//	public static String colMaxDim = "maxDimension";
	public static String colHidden = "flag";
	public static String colStructElemName = "structureElementname";
	

	public static int colCatIdx = 1;
	public static int colNameIdx = 2;
	public static int colStructureElementNameIdx = 3;
	public static int colValIdx = 4;
	public static int colDescIdx = 5;
	public static int colCompIdx = 6;
	public static int colBaseTyIdx = 7;
	public static int colOffIdx = 8;
	public static int colSlopIdx = 9;
	public static int colMinIdx = 10;
	public static int colMaxIdx = 11;
	public static int colUnitIdx = 12;
	public static int colIniValIdx = 13;
	public static int colDimIdx = 14;
	public static int colDimModeIdx = 15;
	public static int colSamplTimIdx = 16;
//	public static int colSampModIdx = 16;
	public static int colComplxIdx = 17;
	public static int colSwCalAccIdx = 18;
	public static int colCoderInfIdx = 19;
	public static int colDispForIdx=20;
	public static int colMemSecIdx = 21;
	public static int colOldNamIdx = 22;
	public static int colHiddenIdx = 23;



	//public static String COLUMN_DESC = "description";

	/** property map for attribute name with Column Header */
	private Map<String, String> propertyMap = new HashMap<String, String>();

	/** List of categories */
	List<CategoryAttributes> newCatList;

	List<CategoryAttributesIo> newCatListIo;
	/** NatTable */
	//private NatTable natTable;

	/** json Element of Data Objects */
	private JsonElement jsonDataObj;

	/** body Data Layer */
	private DataLayer bodyDataLayer;

	/** Body Data Provider */
	private ListDataProvider<CategoryAttributes> bodyDataProvider;
	
	private ListDataProvider<CategoryAttributesIo> bodyDtaPrvdrIo;

	/** selection Layer */
	private SelectionLayer selectionLayer;

	/** viewport layer */
	private ViewportLayer viewportLayer;

	/** Gridlayer */
	private GridLayer gridLayer;

	/** Filter Roew Header Layer */
	public  ComboBoxFilterRowHeaderComposite<CategoryAttributes> filterRowHLayer;

	public  ComboBoxFilterRowHeaderComposite<CategoryAttributesIo> filterRowHLayerIo;
	/** Sorted List */
	//private SortedList<CategoryAttributes> sortedList;

	/** Filter List */
	public  FilterList<CategoryAttributes> filterList;

	public  FilterList<CategoryAttributesIo> filterListIo;
	/** Glaze Event List Layer */
	//private GlazedListsEventLayer<CategoryAttributes> glazedListELayer;

	/** Event List */
	//private EventList<CategoryAttributes> eventList;

	/** Transformation List */
	//private TransformedList<CategoryAttributes, CategoryAttributes> rowObjGlazedList;

	/** used to register column label */
	private ColumnOverrideLabelAccumulator colLblAccum;

	public static MenuItem customFilter;

	private RowHideShowLayer rowHideShowLayer;

	public CategoryAttributesSortModel catAttrSortMdl;
	
	public CategoryAttributesSortModelIo catAttrSortMdlIo;
	
	private static final String BODY_LABEL_1 = "BodyLabel_1";
	/**
	 * Used to return rowhideshow layer
	 * @return
	 */
	public RowHideShowLayer getRowHideShowLayer() {
		return rowHideShowLayer;
	}

	/**
	 * used to return JSON Element of Data Objects
	 * 
	 * @return JsonElement JSON Element of Data Objects
	 */
	public JsonElement getJsonElementofDataObjects() {
		return jsonDataObj;
	}

	/**
	 * Used to return body data layer
	 * 
	 * @return DataLayer body Data Layer
	 */
	public DataLayer getDataLayer() {
		return bodyDataLayer;
	}

	/**
	 * Used to return list of ListDataProvider for category.
	 * 
	 * @return list of ListDataProvider for category
	 */
	public ListDataProvider<CategoryAttributes> getJsonDataProvider() {
		return bodyDataProvider;
	}
	
	public ListDataProvider<CategoryAttributesIo> getJsonDataProviderIO() {
		return bodyDtaPrvdrIo;
	}

	/**
	 * Used to return selection Layer.
	 * 
	 * @return
	 */
	public SelectionLayer getSelectionLayer() {
		return selectionLayer;
	}

	/**
	 * Used to return new category list.
	 * 
	 * @return newCatList
	 */
	public List<CategoryAttributes> getCategoryList() {
		return newCatList;
	}

	/**
	 * Used to return view port layer of natTable
	 * @return
	 */
	public ViewportLayer getViewportLayer() {
		return viewportLayer;
	}

	/**
	 * Used to return view grid layer of natTable
	 * @return
	 */
	public GridLayer getGridLayer() {
		return gridLayer;
	}

	/**
	 * Used to set Category list.
	 * 
	 * @param newCatList
	 */
	public void setCategoryList(List<CategoryAttributes> newCatList) {
		this.newCatList = newCatList;
	}

	/**
	 * method used to get the ColumnLabelAccumulator
	 * @return
	 */
	public ColumnOverrideLabelAccumulator getColumnLabelAccumulator() {
		return colLblAccum;
	}

	/**
	 * method used to set the ColumnLabelAccumulator
	 * @param columnLabelAccumulator
	 */
	public void setColumnLabelAccumulator(ColumnOverrideLabelAccumulator colLblAccum) {
		this.colLblAccum = colLblAccum;
	}

	public NatTable displayNatTableIO(Composite parent, List<CategoryAttributesIo> dataList) {
		insertPropertyMapValues();

		newCatListIo = dataList;
		String category = null;
		if(!dataList.isEmpty()) {
			category = newCatListIo.get(0).getCategory();
		}

		if(newCatListIo.get(0).getName().equals("")) {
			newCatListIo = new ArrayList<>();
		}
		EventList<CategoryAttributesIo> eventList = GlazedLists.eventList(newCatListIo);
		TransformedList<CategoryAttributesIo, CategoryAttributesIo> rowObjGlazedList = GlazedLists.threadSafeList(eventList);
		SortedList<CategoryAttributesIo> sortedList = new SortedList<CategoryAttributesIo>(rowObjGlazedList, null);
		filterListIo = new FilterList<CategoryAttributesIo>(sortedList);   
		bodyDtaPrvdrIo =
				new ListDataProvider<CategoryAttributesIo>(filterListIo, colPropAccessorIo);
		bodyDataLayer = new DataLayer(bodyDtaPrvdrIo);


		// Set the width for name and description column
		bodyDataLayer.setColumnWidthByPosition(5, 210);
		bodyDataLayer.setColumnWidthByPosition(2, 210);
		bodyDataLayer.setColumnWidthByPosition(3, 210);
		bodyDataLayer.setColumnWidthByPosition(22, 170);

		ColumnHideShowLayer columnHide = columnShowHide(category);
		rowHideShowLayer = new RowHideShowLayer(columnHide);
		
		GlazedListsEventLayer<CategoryAttributesIo> glazedListELayer = new GlazedListsEventLayer<CategoryAttributesIo>(rowHideShowLayer, filterListIo);
		selectionLayer = new SelectionLayer(glazedListELayer);
		viewportLayer = new ViewportLayer(selectionLayer);



		// build the column header layer stack
		IDataProvider colHdDataPvd = new DefaultColumnHeaderDataProvider(propertyNames, propertyMap);
		DataLayer colHeadDataLayer = new DataLayer(colHdDataPvd);
		ILayer columnHeaderLayer = new ColumnHeaderLayer(colHeadDataLayer, viewportLayer, selectionLayer);
		ConfigRegistry configRegistry = new ConfigRegistry();
		this.catAttrSortMdlIo = new CategoryAttributesSortModelIo(bodyDtaPrvdrIo.getList());

		SortHeaderLayer<CategoryAttributes> sortHeaderLayer =
				new SortHeaderLayer<CategoryAttributes>(columnHeaderLayer, this.catAttrSortMdl);

		filterRowHLayerIo =
				new ComboBoxFilterRowHeaderComposite<CategoryAttributesIo>(
						filterListIo,
						glazedListELayer,
						sortedList,
						colPropAccessorIo,
						sortHeaderLayer,
						colHdDataPvd,
						configRegistry);
		final IComboBoxDataProvider comboBoxDataPvd = filterRowHLayerIo.getComboBoxDataProvider();
		filterRowHLayerIo.addConfiguration(new ComboBoxFilterRowConfiguration() {
			{
				FilterRowComboBoxCellEditor fComboCellEdit = new FilterRowComboBoxCellEditor(comboBoxDataPvd,10);
				fComboCellEdit.setFreeEdit(true);
				fComboCellEdit.setShowDropdownFilter(true);
				fComboCellEdit.setMultiselect(true);
				fComboCellEdit.setUseCheckbox(false);
				this.cellEditor = fComboCellEdit;
				this.filterIconPainter = new ComboBoxFilterIconPainter(comboBoxDataPvd, GUIHelper.getImage("filter"), null);
			}
		});

		filterRowHLayerIo.setFilterRowVisible(false);
		// build the row header layer stack
		IDataProvider rowHeaderDataPvd = new DefaultRowHeaderDataProvider(bodyDtaPrvdrIo);
		DataLayer rowHeaderDLayer = new DataLayer(rowHeaderDataPvd, 40, 20);
		ILayer rowHeaderLayer = new RowHeaderLayer(rowHeaderDLayer, viewportLayer, selectionLayer);

		// build the corner layer stack
		IDataProvider cornerDataPvd = new DefaultCornerDataProvider(colHdDataPvd,
				rowHeaderDataPvd);
		DataLayer cornerDataLayer = new DataLayer(cornerDataPvd);
		ILayer cornerLayer = new CornerLayer(cornerDataLayer, rowHeaderLayer, filterRowHLayerIo);

		bodyDataLayer.registerCommandHandler(new DeleteRowCommandHandler<>(bodyDtaPrvdrIo.getList()));

		colLblAccum = new ColumnOverrideLabelAccumulator(bodyDataLayer);
		setColumnLabelAccumulator(colLblAccum);
		bodyDataLayer.setConfigLabelAccumulator(colLblAccum);
		registerColumnLabels(colLblAccum);

		gridLayer =	new GridLayer(viewportLayer, filterRowHLayerIo, rowHeaderLayer, cornerLayer,false);
		// create the grid layer composed with the prior created layer stacks
		gridLayer.addConfiguration(new DefaultEditConfiguration());

		gridLayer.addConfiguration(new DefaultEditBindings() {

			@Override
			public void configureUiBindings(UiBindingRegistry uiBindingRegistry) {
				uiBindingRegistry.registerDoubleClickBinding(new CellEditorMouseEventMatcher(), new MouseEditAction());
				uiBindingRegistry.unregisterSingleClickBinding(new CellEditorMouseEventMatcher());
				uiBindingRegistry.registerKeyBinding(new LetterOrDigitKeyEventMatcher(), new KeyEditAction());
				uiBindingRegistry.registerKeyBinding(new KeyEventMatcher(131072), new KeyEditAction());
				uiBindingRegistry.unregisterMouseDragMode(MouseEventMatcher.columnHeaderLeftClick(SWT.NONE));
			}
		});

		NatTable natTable = new NatTable(parent, gridLayer, false);
		natTable.setConfigRegistry(configRegistry);

		
		// as the auto configuration of the NatTable is turned off, we have to add the DefaultNatTableStyleConfiguration manually
		natTable.addConfiguration(new DefaultNatTableStyleConfiguration());

		natTable.addConfiguration(new AbstractHeaderMenuConfiguration(natTable) {
			@Override
			protected PopupMenuBuilder createColumnHeaderMenu(NatTable natTable) {
				return new PopupMenuBuilder(natTable)
						.withMenuItemProvider(new IMenuItemProvider() {

							@Override
							public void addMenuItem(NatTable table, Menu menu) {
								customFilter = new MenuItem(menu, SWT.CHECK);
								customFilter.setText(ApplicationConstant.CUSTOM_FILTER);
								customFilter.addSelectionListener(new SelectionAdapter() {

									@Override
									public void widgetSelected(SelectionEvent event) {
										int column = MenuItemProviders.getNatEventData(event).getColumnPosition();
										CustomFilterWindow window = new CustomFilterWindow();
										if(filterRowHLayer.isFilterRowVisible()) {
											MessageDialog.openInformation(new Shell(), "Information", ApplicationConstant.CUSTOMFILTERMSG);
											customFilter.setSelection(false);
										}else {
											window.open(column);
										}
									}
								});

								MenuItem clearFilter = new MenuItem(menu, SWT.PUSH);
								clearFilter.setText(ApplicationConstant.CLEAR_FILTER);
								clearFilter.setEnabled(true);
								clearFilter.addSelectionListener(new SelectionListener() {

									@Override
									public void widgetSelected(SelectionEvent event) {
										// TODO Auto-generated method stub
										filterRowHLayer.setAllValuesSelected();
										filterRowHLayer.setFilterRowVisible(false);
										natTable.doCommand(new ShowAllRowsCommand());
										customFilter.setSelection(false);
										ApplicationActionBarAdvisor.getInstance().filterAction.setEnabled(true);
										ApplicationActionBarAdvisor.getInstance().filterAction.setImageDescriptor(Activator.getImageDescriptor("/icons/filter.png"));
									}

									@Override
									public void widgetDefaultSelected(SelectionEvent event) {
										// TODO Auto-generated method stub

									}
								});

								MenuItem clearSort = new MenuItem(menu, SWT.PUSH);
								clearSort.setText(ApplicationConstant.CLEAR_SORT);
								clearSort.setEnabled(true);
								clearSort.addSelectionListener(new SelectionListener() {

									@Override
									public void widgetSelected(SelectionEvent event) {
										CategoryEditor categoryEditor = getActiveCategoryEditor();
										
										if(!catAttrSortMdl.sorted[catAttrSortMdl.currentSortColumn])
										{
											return;
										}

										if(categoryEditor.isDirty()) {
											MessageDialog.openInformation(new Shell(), "Information", "Sorting cannot be cleared.");
											clearSort.setSelection(false);
											return;
										}
										catAttrSortMdl.clearSort(catAttrSortMdl.currentSortColumn, SortDirectionEnum.NONE, false);
										clearSort.setSelection(false);

									}

									@Override
									public void widgetDefaultSelected(SelectionEvent event) {
										// TODO Auto-generated method stub

									}
								});
							}

						});
			}
		});
		
		addCustomStyling(natTable);
		// Enable sorting on single click on the column header
		natTable.addConfiguration(new SingleClickSortConfiguration());
		addColumnHighlight(natTable.getConfigRegistry());
		natTable.configure();
		return natTable;

	}

	
	/**
	 * Function is used to create a NatTable depending on input list
	 * 
	 * @param parent
	 * @param dataList
	 * @return
	 */
	public NatTable displayNatTable(Composite parent, List<CategoryAttributes> dataList) {
		insertPropertyMapValues();

		newCatList = dataList;
		String category = null;
		if(!dataList.isEmpty()) {
			category = newCatList.get(0).getCategory();
		}

		if(newCatList.get(0).getName().equals("")) {
			newCatList = new ArrayList<>();
		}
		EventList<CategoryAttributes> eventList = GlazedLists.eventList(newCatList);
		TransformedList<CategoryAttributes, CategoryAttributes> rowObjGlazedList = GlazedLists.threadSafeList(eventList);
		SortedList<CategoryAttributes> sortedList = new SortedList<CategoryAttributes>(rowObjGlazedList, null);
		filterList = new FilterList<CategoryAttributes>(sortedList);   
		bodyDataProvider =
				new ListDataProvider<CategoryAttributes>(filterList, colPropAccessor);
		bodyDataLayer = new DataLayer(bodyDataProvider);


		// Set the width for name and description column
		bodyDataLayer.setColumnWidthByPosition(5, 180);
		bodyDataLayer.setColumnWidthByPosition(2, 200);
		//bodyDataLayer.setColumnWidthByPosition(3, 200);

		if(category!=null && !category.equals("") && Application.configCatList.contains(category)) {
			ColumnHideShowLayer columnHide = columnShowHide(category);
			rowHideShowLayer = new RowHideShowLayer(columnHide);
			if(columnHide.isColumnIndexHidden(CreateNatTable.colValIdx)) {
				if(!Application.iniValCatList.contains(category)) {
					Application.iniValCatList.add(category);
				}
			}else if(columnHide.isColumnIndexHidden(CreateNatTable.colIniValIdx)) {
				if(!Application.valueCatList.contains(category)) {
					Application.valueCatList.add(category);
				}
			}
		}

		GlazedListsEventLayer<CategoryAttributes> glazedListELayer = new GlazedListsEventLayer<CategoryAttributes>(rowHideShowLayer, filterList);
		selectionLayer = new SelectionLayer(glazedListELayer);
		viewportLayer = new ViewportLayer(selectionLayer);

		// build the column header layer stack
		IDataProvider colHdDataPvd = new DefaultColumnHeaderDataProvider(propertyNames, propertyMap);
		DataLayer colHeadDataLayer = new DataLayer(colHdDataPvd);
		ILayer columnHeaderLayer = new ColumnHeaderLayer(colHeadDataLayer, viewportLayer, selectionLayer);
		ConfigRegistry configRegistry = new ConfigRegistry();
		this.catAttrSortMdl = new CategoryAttributesSortModel(bodyDataProvider.getList());

		SortHeaderLayer<CategoryAttributes> sortHeaderLayer =
				new SortHeaderLayer<CategoryAttributes>(columnHeaderLayer, this.catAttrSortMdl);

		filterRowHLayer =
				new ComboBoxFilterRowHeaderComposite<CategoryAttributes>(
						filterList,
						glazedListELayer,
						sortedList,
						colPropAccessor,
						sortHeaderLayer,
						colHdDataPvd,
						configRegistry);
		final IComboBoxDataProvider comboBoxDataPvd = filterRowHLayer.getComboBoxDataProvider();
		filterRowHLayer.addConfiguration(new ComboBoxFilterRowConfiguration() {
			{
				FilterRowComboBoxCellEditor fComboCellEdit = new FilterRowComboBoxCellEditor(comboBoxDataPvd,10);
				fComboCellEdit.setFreeEdit(true);
				fComboCellEdit.setShowDropdownFilter(true);
				fComboCellEdit.setMultiselect(true);
				fComboCellEdit.setUseCheckbox(false);
				this.cellEditor = fComboCellEdit;
				this.filterIconPainter = new ComboBoxFilterIconPainter(comboBoxDataPvd, GUIHelper.getImage("filter"), null);
			}
		});

		filterRowHLayer.setFilterRowVisible(false);
		// build the row header layer stack
		IDataProvider rowHeaderDataPvd = new DefaultRowHeaderDataProvider(bodyDataProvider);
		DataLayer rowHeaderDLayer = new DataLayer(rowHeaderDataPvd, 40, 20);
		ILayer rowHeaderLayer = new RowHeaderLayer(rowHeaderDLayer, viewportLayer, selectionLayer);

		// build the corner layer stack
		IDataProvider cornerDataPvd = new DefaultCornerDataProvider(colHdDataPvd,
				rowHeaderDataPvd);
		DataLayer cornerDataLayer = new DataLayer(cornerDataPvd);
		ILayer cornerLayer = new CornerLayer(cornerDataLayer, rowHeaderLayer, filterRowHLayer);

		bodyDataLayer.registerCommandHandler(new DeleteRowCommandHandler<>(bodyDataProvider.getList()));

		colLblAccum = new ColumnOverrideLabelAccumulator(bodyDataLayer);
		setColumnLabelAccumulator(colLblAccum);
		bodyDataLayer.setConfigLabelAccumulator(colLblAccum);
		registerColumnLabels(colLblAccum);

		gridLayer =	new GridLayer(viewportLayer, filterRowHLayer, rowHeaderLayer, cornerLayer,false);
		// create the grid layer composed with the prior created layer stacks
		gridLayer.addConfiguration(new DefaultEditConfiguration());

		gridLayer.addConfiguration(new DefaultEditBindings() {

			@Override
			public void configureUiBindings(UiBindingRegistry uiBindingRegistry) {
				uiBindingRegistry.registerDoubleClickBinding(new CellEditorMouseEventMatcher(), new MouseEditAction());
				uiBindingRegistry.unregisterSingleClickBinding(new CellEditorMouseEventMatcher());
				uiBindingRegistry.registerKeyBinding(new LetterOrDigitKeyEventMatcher(), new KeyEditAction());
				uiBindingRegistry.registerKeyBinding(new KeyEventMatcher(131072), new KeyEditAction());
				uiBindingRegistry.unregisterMouseDragMode(MouseEventMatcher.columnHeaderLeftClick(SWT.NONE));
			}
		});

		NatTable natTable = new NatTable(parent, gridLayer, false);
		natTable.setConfigRegistry(configRegistry);

		
		// as the auto configuration of the NatTable is turned off, we have to add the DefaultNatTableStyleConfiguration manually
		natTable.addConfiguration(new DefaultNatTableStyleConfiguration());

		natTable.addConfiguration(new AbstractHeaderMenuConfiguration(natTable) {
			@Override
			protected PopupMenuBuilder createColumnHeaderMenu(NatTable natTable) {
				return new PopupMenuBuilder(natTable)
						.withMenuItemProvider(new IMenuItemProvider() {

							@Override
							public void addMenuItem(NatTable table, Menu menu) {
								customFilter = new MenuItem(menu, SWT.CHECK);
								customFilter.setText(ApplicationConstant.CUSTOM_FILTER);
								customFilter.addSelectionListener(new SelectionAdapter() {

									@Override
									public void widgetSelected(SelectionEvent event) {
										int column = MenuItemProviders.getNatEventData(event).getColumnPosition();
										CustomFilterWindow window = new CustomFilterWindow();
										if(filterRowHLayer.isFilterRowVisible()) {
											MessageDialog.openInformation(new Shell(), "Information", ApplicationConstant.CUSTOMFILTERMSG);
											customFilter.setSelection(false);
										}else {
											window.open(column);
										}
									}
								});

								MenuItem clearFilter = new MenuItem(menu, SWT.PUSH);
								clearFilter.setText(ApplicationConstant.CLEAR_FILTER);
								clearFilter.setEnabled(true);
								clearFilter.addSelectionListener(new SelectionListener() {

									@Override
									public void widgetSelected(SelectionEvent event) {
										// TODO Auto-generated method stub
										filterRowHLayer.setAllValuesSelected();
										filterRowHLayer.setFilterRowVisible(false);
										natTable.doCommand(new ShowAllRowsCommand());
										customFilter.setSelection(false);
										ApplicationActionBarAdvisor.getInstance().filterAction.setEnabled(true);
										ApplicationActionBarAdvisor.getInstance().filterAction.setImageDescriptor(Activator.getImageDescriptor("/icons/filter.png"));
									}

									@Override
									public void widgetDefaultSelected(SelectionEvent event) {
										// TODO Auto-generated method stub

									}
								});

								MenuItem clearSort = new MenuItem(menu, SWT.PUSH);
								clearSort.setText(ApplicationConstant.CLEAR_SORT);
								clearSort.setEnabled(true);
								clearSort.addSelectionListener(new SelectionListener() {

									@Override
									public void widgetSelected(SelectionEvent event) {
										CategoryEditor categoryEditor = getActiveCategoryEditor();
										
										if(!catAttrSortMdl.sorted[catAttrSortMdl.currentSortColumn])
										{
											return;
										}

										if(categoryEditor.isDirty()) {
											MessageDialog.openInformation(new Shell(), "Information", "Sorting cannot be cleared.");
											clearSort.setSelection(false);
											return;
										}
										catAttrSortMdl.clearSort(catAttrSortMdl.currentSortColumn, SortDirectionEnum.NONE, false);
										clearSort.setSelection(false);

									}

									@Override
									public void widgetDefaultSelected(SelectionEvent event) {
										// TODO Auto-generated method stub

									}
								});
							}

						});
			}
		});
		
		addCustomStyling(natTable);
		// Enable sorting on single click on the column header
		natTable.addConfiguration(new SingleClickSortConfiguration());
		addColumnHighlight(natTable.getConfigRegistry());
		natTable.configure();
		return natTable;

	}

	/**
     * Register an attribute to be applied to all cells with the highlight
     * label. A similar approach can be used to bind styling to an arbitrary
     * group of cells
     */
    private void addColumnHighlight(IConfigRegistry configRegistry) {
        Style style = new Style();
        style.setAttributeValue(
                CellStyleAttributes.FOREGROUND_COLOR,
                GUIHelper.COLOR_BLUE);
        style.setAttributeValue(
                CellStyleAttributes.HORIZONTAL_ALIGNMENT,
                HorizontalAlignmentEnum.RIGHT);

        configRegistry.registerConfigAttribute(
                CellConfigAttributes.CELL_STYLE, // attribute to apply
                style, // value of the attribute
                DisplayMode.NORMAL, // apply during normal rendering i.e not
                                    // during selection or edit
                BODY_LABEL_1); // apply the above for all cells with this label
    }
    
	private void addCustomStyling(NatTable natTable) {
        // Setup NatTable default styling

        // NOTE: Getting the colors and fonts from the GUIHelper ensures that
        // they are disposed properly (required by SWT)
        DefaultNatTableStyleConfiguration natTblConfig = new DefaultNatTableStyleConfiguration();
        natTblConfig.bgColor = GUIHelper.getColor(249, 172, 7);
        natTblConfig.fgColor = GUIHelper.getColor(30, 76, 19);
        natTblConfig.hAlign = HorizontalAlignmentEnum.LEFT;
        natTblConfig.vAlign = VerticalAlignmentEnum.TOP;

        // A custom painter can be plugged in to paint the cells differently
        natTblConfig.cellPainter = new PaddingDecorator(new TextPainter(), 1);

        // Setup even odd row colors - row colors override the NatTable default
        // colors
        DefaultRowStyleConfiguration rowStyleConfig = new DefaultRowStyleConfiguration();
        rowStyleConfig.oddRowBgColor = GUIHelper.getColor(254, 251, 243);
        rowStyleConfig.evenRowBgColor = GUIHelper.COLOR_BLACK;

        // Setup selection styling
        DefaultSelectionStyleConfiguration selectionStyle = new DefaultSelectionStyleConfiguration();
       FontStyleDAO fontStyle = DataDictionaryApplication.getApplication().fontStyle;
		if(fontStyle  != null && fontStyle.getFont() != null && !EditorPreference.isDefFontSel) {
			selectionStyle.selectionFont = GUIHelper.getFont(new FontData(fontStyle.getFont(), fontStyle.getSize(), fontStyle.getFontStyle()));
        } else {
        	selectionStyle.selectionFont = GUIHelper.getFont(new FontData("Work Sans", 11, SWT.NORMAL));
        }
        selectionStyle.selectionBgColor = GUIHelper.getColor(217, 232, 251);
        selectionStyle.selectionFgColor = GUIHelper.COLOR_BLACK;
        selectionStyle.anchorBorderStyle = new BorderStyle(1, GUIHelper.COLOR_DARK_GRAY, LineStyleEnum.SOLID);
        selectionStyle.anchorBgColor = GUIHelper.getColor(99, 127, 191);
        selectionStyle.selectedHeaderBgColor = GUIHelper.getColor(99, 127, 191);

        // Add all style configurations to NatTable
        natTable.addConfiguration(natTblConfig);
        natTable.addConfiguration(rowStyleConfig);
        natTable.addConfiguration(selectionStyle);

        // Column/Row header style and custom painters
        natTable.addConfiguration(new StyledRowHeaderConfiguration());
        natTable.addConfiguration(new StyledColumnHeaderConfiguration());

        // Add popup menu - build your own popup menu using the PopupMenuBuilder
        natTable.addConfiguration(new HeaderMenuConfiguration(natTable));
 }
	
	/**
	 * Method used to hide the column depending on category
	 * 
	 * @param category
	 * @return
	 */
	private ColumnHideShowLayer columnShowHide(String category) {
	
		ColumnReorderLayer columnReorder = new ColumnReorderLayer(bodyDataLayer);
		ColumnHideShowLayer columnHide = new ColumnHideShowLayer(columnReorder);

		IWorkbenchPage activePage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();

		IEditorReference[] editors = activePage.getEditorReferences(); 		
		for (IEditorReference editor : editors) {

			if (editor.getEditor(false) instanceof IOCompatibilityEditor
					|| editor.getEditor(false) instanceof ComponentIpEditor) {
				if(editor.getTitle().equals("Inconsistent I/Os")) {
					hideListMap.put("Input", Arrays.asList(0, 3, 4, 15, 16, 17, 18, 19, 20, 21, 22, 24));
					hideListMap.put("Output", Arrays.asList(0, 3, 4, 15, 16, 17, 18, 19, 20, 21, 22, 24));
				}
				/*}else {
					hideListMap.put("Input", Arrays.asList(0, 3, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24));
					hideListMap.put("Output", Arrays.asList(0, 3, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23));
				}*/
					else if(editor.getTitle().equals("Inconsistent Structured I/Os")) {
						hideListMap.put("Input", Arrays.asList(0, 4, 8, 9, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24));
						hideListMap.put("Output", Arrays.asList(0, 4, 8, 9, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24));
					}
					else {
						if(Application.programName.equals("E44"))
						{
							hideListMap.put("Input", Arrays.asList(0, 3, 4, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24));
							hideListMap.put("Output", Arrays.asList(0, 3, 4, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24));
						}
						else
						{
							if(editor.getTitle().equals("Inconsistent Normal I/Os"))
							{
								hideListMap.put("Input", Arrays.asList(0, 3, 4, 8, 9, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24));
								hideListMap.put("Output", Arrays.asList(0, 3, 4, 8, 9, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24));
							}
							else
							{
								hideListMap.put("Input", Arrays.asList(0, 4, 8, 9, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24));
								hideListMap.put("Output", Arrays.asList(0, 4, 8, 9, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24));
							}
						}
					}

			} else if (editor.getEditor(false) instanceof CategoryEditor) {
				Map<String, List<Integer>> map = null;
				try {
					map = dispCategoryAndColumns();
				} catch (FileNotFoundException fne) {
					LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, fne);
				} catch (IOException ioe) {
					LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, ioe);
				}


				if(map!=null) {
					Iterator<Entry<String, List<Integer>>> hmIterator = map.entrySet().iterator();

					while (hmIterator.hasNext()) {
						Map.Entry mapElement = (Map.Entry)hmIterator.next();
						String cat = mapElement.getKey().toString();
						if(!Application.configCatList.contains(cat)) {
							Application.configCatList.add(cat);
						}

						List<Integer> list = (List<Integer>) mapElement.getValue();
						//Integer[] arr = list.toArray(new Integer[list.size()]);
						Integer[] arr = list.toArray(new Integer[0]);
						hideListMap.put(cat, Arrays.asList(arr));
					}
				}
			} else if (editor.getEditor(false) instanceof ResolveInconAttributesEditor) {
				hideListMap.put("Input", Arrays.asList(4, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24));
				hideListMap.put("Output", Arrays.asList(4, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24));
			}
		}
		
		List<Integer> list = hideListMap.get(category);
		columnHide.hideColumnPositions(list);

		return columnHide;
	}

	/**
	 * This method is used to set the column header label.
	 */
	private void insertPropertyMapValues() {
		propertyMap.put("warning", "Warning");
		propertyMap.put("category", "Category");
		propertyMap.put("name", "Name");
		propertyMap.put("structureElementname", "Structure Element Name");
		propertyMap.put("value", "Value");
		propertyMap.put("component", "Component");
		propertyMap.put("description", "Description");
		propertyMap.put("baseType", "Base Type");
		propertyMap.put("offset", "Offset");
		propertyMap.put("slope", "Slope");
		propertyMap.put("min", "Min");
		propertyMap.put("max", "Max");
		propertyMap.put("unit", "Unit");
		propertyMap.put("initialValue", "InitialValue");
		
		propertyMap.put("dimensions", "Dimensions");
		propertyMap.put("dimensionsMode", "DimensionsMode");
		propertyMap.put("sampleTime", "SampleTime");
		propertyMap.put("samplingMode", "SamplingMode");
		propertyMap.put("complexity", "Complexity");
		propertyMap.put("swCalibrationAccess", "SwCalibrationAccess");
		//propertyMap.put("displayFormat", "DisplayFormat");
		propertyMap.put("coderInfo", "Storage Class");
		propertyMap.put("displayFormat", "DisplayFormat");
		propertyMap.put("memorySection", "Memory section");
		propertyMap.put("oldName", "OldName");
		propertyMap.put("flag", "<hidden>");
		
	}

	/**
	 * Method used to register the column labels which is used for adding
	 * comboBoxEditor
	 * 
	 * @param columnLabelAccumulator
	 */
	public static void registerColumnLabels(ColumnOverrideLabelAccumulator colLblAccum) {
		colLblAccum.registerColumnOverrides(0, colWarning);
		colLblAccum.registerColumnOverrides(1, colCategory);
		colLblAccum.registerColumnOverrides(2, colName);
		colLblAccum.registerColumnOverrides(3, colStructElemName);
		colLblAccum.registerColumnOverrides(4, colValue);
		colLblAccum.registerColumnOverrides(5, colDesc);
		colLblAccum.registerColumnOverrides(6, colComp);
		colLblAccum.registerColumnOverrides(7, colBaseType);
		colLblAccum.registerColumnOverrides(8, colOffset);
		colLblAccum.registerColumnOverrides(9, colSlope);
		colLblAccum.registerColumnOverrides(10, colMin);
		colLblAccum.registerColumnOverrides(11, colMax);
		colLblAccum.registerColumnOverrides(12, colUnit);
		colLblAccum.registerColumnOverrides(13, colInitVal);
		colLblAccum.registerColumnOverrides(14, colDim);
		colLblAccum.registerColumnOverrides(15, colDimMode);
		colLblAccum.registerColumnOverrides(16, colSamplTim);
	//	colLblAccum.registerColumnOverrides(16, colSampMode);
		colLblAccum.registerColumnOverrides(17, colComplex);
		colLblAccum.registerColumnOverrides(18, colSwCalAccess);
		colLblAccum.registerColumnOverrides(19, colCoderInf);
		colLblAccum.registerColumnOverrides(20, colDispFor);
		colLblAccum.registerColumnOverrides(21, colMemorySection);
		colLblAccum.registerColumnOverrides(22, colOldName);
		colLblAccum.registerColumnOverrides(23, colHidden);
	}

	public CategoryEditor getActiveCategoryEditor()
	{
		IEditorPart activeEditor = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor();
		if(activeEditor instanceof CategoryEditor)
		{
			return (CategoryEditor)activeEditor;

		}
		return null;
	}



	/**
	 * A simple implementation for {@link ISortModel} that can be used to sort
	 * {@link PersonWithAddress} objects. It uses it's own {@link Comparator}
	 * and doesn't support multiple column sorting and it won't be possible to
	 * remove the sorting. Of course this can be implemented to work like the
	 * default behaviour of the NatTable.
	 */
	class CategoryAttributesSortModel implements ISortModel {
		/**
		 * Array that contains the sort direction for every column. Needed to
		 * access the current sort state of a column.
		 */
		protected SortDirectionEnum[] sortDirections;
		/**
		 * Array that contains the sorted flags for every column. Needed to
		 * access the current sort state of a column.
		 */
		protected boolean[] sorted;
		/**
		 * As this implementation only supports single column sorting, this
		 * property contains the the column index of the column that is
		 * currently used for sorting. Initial value = -1 for no sort column
		 */
		protected int currentSortColumn = -1;
		/**
		 * As this implementation only supports single column sorting, this
		 * property contains the current sort direction of the column that is
		 * currently used for sorting.
		 */
		protected SortDirectionEnum currentSortDir = SortDirectionEnum.ASC;
		/**
		 * Data list that is sorted
		 */
		private List<CategoryAttributes> catAttrlist;

		/**
		 * Creates a new {@link CategoryAttributesSortModel} for the list of
		 * objects.
		 *
		 * @param categoryAttributeslist
		 *            the list of objects that should be sorted
		 */
		public CategoryAttributesSortModel(List<CategoryAttributes> catAttrlist) {
			this.catAttrlist = catAttrlist;
			this.sortDirections = new SortDirectionEnum[20];
			Arrays.fill(this.sortDirections, SortDirectionEnum.NONE);
			this.sorted = new boolean[20];
			Arrays.fill(this.sorted, false);
			// call initial sorting			
			//sort(0, SortDirectionEnum.ASC, false);
			sort(0, SortDirectionEnum.NONE, false);
		}
		
		
		/**
		 * As this is a simple implementation of an {@link ISortModel} and we
		 * don't support multiple column sorting, this list returns either a
		 * list with one entry for the current sort column or an empty list.
		 */
		@Override
		public List<Integer> getSortedColumnIndexes() {
			List<Integer> indexes = new ArrayList<>();
			if (this.currentSortColumn > -1) {
				indexes.add(Integer.valueOf(this.currentSortColumn));
			}
			return indexes;
		}
		/**
		 * @return TRUE if the column with the given index is sorted at the
		 *         moment.
		 */
		@Override
		public boolean isColumnIndexSorted(int columnIndex) {
			return this.sorted[columnIndex];
		}
		/**
		 * @return the direction in which the column with the given index is
		 *         currently sorted
		 */
		@Override
		public SortDirectionEnum getSortDirection(int columnIndex) {
			return this.sortDirections[columnIndex];
		}
		/**
		 * @return 0 as we don't support multiple column sorting.
		 */
		@Override
		public int getSortOrder(int columnIndex) {
			return 0;
		}
		/**
		 * Remove all sorting
		 */
		@Override
		public void clear() {
			Arrays.fill(this.sortDirections, SortDirectionEnum.NONE);
			Arrays.fill(this.sorted, false);
			this.currentSortColumn = -1;
		}
		/**
		 * This method is called by the {@link SortCommandHandler} in response
		 * to a sort command. It is responsible for sorting the requested
		 * column.
		 */
		@Override
		public void sort(int columnIndex, SortDirectionEnum sortDirection, boolean accumulate) {
			//changed for PMD
			SortDirectionEnum sortDirec = sortDirection;
			if(columnIndex!=0 && this.catAttrlist.isEmpty())
			{
				return;
			}

			CategoryEditor categoryEditor = getActiveCategoryEditor();
			if(categoryEditor!=null && categoryEditor.isDirty())
			{
				MessageDialog.openInformation(new Shell(), "Information", "Sorting cannot be applied");
				return;
			}

			if (!isColumnIndexSorted(columnIndex)) {
				clear();
			}
			//if (sortDirection.equals(SortDirectionEnum.NONE)) {
			if (isColumnIndexSorted(columnIndex) && sortDirec.equals(SortDirectionEnum.NONE)) {
				// we don't support NONE as user action
				sortDirec = SortDirectionEnum.ASC;
				//clear();
			}

			Collections.sort(this.catAttrlist, new CategoryAttributesComparator(columnIndex, sortDirec));
			this.sortDirections[columnIndex] = sortDirec;
			this.sorted[columnIndex] = sortDirec.equals(SortDirectionEnum.NONE) ? false : true;
			this.currentSortColumn = columnIndex;
			this.currentSortDir = sortDirec;
		}

		public void clearSort(int columnIndex, SortDirectionEnum sortDirection, boolean accumulate)
		{
			clear();
			Collections.sort(this.catAttrlist, new CategoryAttributesComparator(columnIndex, sortDirection));
			this.sortDirections[columnIndex] = sortDirection;
			this.sorted[columnIndex] = sortDirection.equals(SortDirectionEnum.NONE) ? false : true;
			this.currentSortColumn = columnIndex;
			this.currentSortDir = sortDirection;


		}
		@SuppressWarnings("rawtypes")
		@Override
		public List<Comparator> getComparatorsForColumnIndex(int columnIndex) {
			return null;
		}
		@Override
		public Comparator<?> getColumnComparator(int columnIndex) {
			return null;
		}


		/**
		 * Custom comparator for {@link PersonWithAddress} objects
		 */
		class CategoryAttributesComparator implements Comparator<CategoryAttributes> {
			int colIdx = 0;
			SortDirectionEnum sortDirection;
			public CategoryAttributesComparator(int columnIndex, SortDirectionEnum sortDirection) {
				this.colIdx = columnIndex;
				this.sortDirection = sortDirection;
			}
			@SuppressWarnings({ "rawtypes", "unchecked" })
			@Override
			public int compare(CategoryAttributes catAttributes1, CategoryAttributes catAttributes2) {
				//remove search highlight before sorting
				getSelectionLayer().setConfigLabelAccumulator(null);
				
				Comparable compareObject1 = null;
				Comparable compareObject2 = null;

				switch (this.colIdx) {				
				case 2:
					compareObject1 = catAttributes1.getName();
					compareObject2 = catAttributes2.getName();
					break;
					
				case 6:
					compareObject1 = catAttributes1.getBaseType();
					compareObject2 = catAttributes2.getBaseType();
					break;		
							
				case 11:
					compareObject1 = catAttributes1.getUnit();
					compareObject2 = catAttributes2.getUnit();
					break;
							
				case 9:
					try {
						String min1 = catAttributes1.getMin();
						String min2 = catAttributes2.getMin();
						
						if(min1!=null && !min1.equals(""))
						{
							compareObject1 = Double.parseDouble(catAttributes1.getMin());
						}
						if(min2!=null && !min2.equals(""))
						{
							compareObject2 = Double.parseDouble(catAttributes2.getMin());
						}
						
					} catch (NumberFormatException exception) {
						LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, exception);
					}
					break;
				case 10:
					
					try {
						String max1 = catAttributes1.getMin();
						String max2 = catAttributes2.getMin();
						
						if(max1!=null && !max1.equals(""))
						{
							compareObject1 = Double.parseDouble(catAttributes1.getMax());
						}
						if(max2!=null && !max2.equals(""))
						{
							compareObject2 = Double.parseDouble(catAttributes2.getMax());
						}
						
					} catch (NumberFormatException exception) {
						LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, exception);
					}
					break;

				}

				int result = 0;
				// make null safe compare
				if (compareObject1 == null) {
					if (compareObject2 != null) {
						result = -1;
					} else {
						result = 0;
					}
				} else {
					if (compareObject2 != null) {
						result = compareObject1.compareTo(compareObject2);
					} else {
						result = 1;
					}
				}
				// negate compare result if sort direction is descending
				if (this.sortDirection.equals(SortDirectionEnum.DESC)) {
					result = result * -1;
				}
				return result;
			}
		}

	}
	
	
	class CategoryAttributesSortModelIo implements ISortModel {
		/**
		 * Array that contains the sort direction for every column. Needed to
		 * access the current sort state of a column.
		 */
		protected SortDirectionEnum[] sortDirections;
		/**
		 * Array that contains the sorted flags for every column. Needed to
		 * access the current sort state of a column.
		 */
		protected boolean[] sorted;
		/**
		 * As this implementation only supports single column sorting, this
		 * property contains the the column index of the column that is
		 * currently used for sorting. Initial value = -1 for no sort column
		 */
		protected int currentSortColumn = -1;
		/**
		 * As this implementation only supports single column sorting, this
		 * property contains the current sort direction of the column that is
		 * currently used for sorting.
		 */
		protected SortDirectionEnum currentSortDir = SortDirectionEnum.ASC;
		/**
		 * Data list that is sorted
		 */
		private List<CategoryAttributesIo> catAttrlistIo;

		/**
		 * Creates a new {@link CategoryAttributesSortModel} for the list of
		 * objects.
		 *
		 * @param categoryAttributeslist
		 *            the list of objects that should be sorted
		 */
		public CategoryAttributesSortModelIo(List<CategoryAttributesIo> catAttrlistIo) {
			this.catAttrlistIo = catAttrlistIo;
			this.sortDirections = new SortDirectionEnum[20];
			Arrays.fill(this.sortDirections, SortDirectionEnum.NONE);
			this.sorted = new boolean[20];
			Arrays.fill(this.sorted, false);
			// call initial sorting			
			//sort(0, SortDirectionEnum.ASC, false);
			sort(0, SortDirectionEnum.NONE, false);
		}
		
		
		/**
		 * As this is a simple implementation of an {@link ISortModel} and we
		 * don't support multiple column sorting, this list returns either a
		 * list with one entry for the current sort column or an empty list.
		 */
		@Override
		public List<Integer> getSortedColumnIndexes() {
			List<Integer> indexes = new ArrayList<>();
			if (this.currentSortColumn > -1) {
				indexes.add(Integer.valueOf(this.currentSortColumn));
			}
			return indexes;
		}
		/**
		 * @return TRUE if the column with the given index is sorted at the
		 *         moment.
		 */
		@Override
		public boolean isColumnIndexSorted(int columnIndex) {
			return this.sorted[columnIndex];
		}
		/**
		 * @return the direction in which the column with the given index is
		 *         currently sorted
		 */
		@Override
		public SortDirectionEnum getSortDirection(int columnIndex) {
			return this.sortDirections[columnIndex];
		}
		/**
		 * @return 0 as we don't support multiple column sorting.
		 */
		@Override
		public int getSortOrder(int columnIndex) {
			return 0;
		}
		/**
		 * Remove all sorting
		 */
		@Override
		public void clear() {
			Arrays.fill(this.sortDirections, SortDirectionEnum.NONE);
			Arrays.fill(this.sorted, false);
			this.currentSortColumn = -1;
		}
		/**
		 * This method is called by the {@link SortCommandHandler} in response
		 * to a sort command. It is responsible for sorting the requested
		 * column.
		 */
		@Override
		public void sort(int columnIndex, SortDirectionEnum sortDirection, boolean accumulate) {
			//changed for PMD
			SortDirectionEnum sortDirec = sortDirection;
			if(columnIndex!=0 && this.catAttrlistIo.isEmpty())
			{
				return;
			}

			CategoryEditor categoryEditor = getActiveCategoryEditor();
			if(categoryEditor!=null && categoryEditor.isDirty())
			{
				MessageDialog.openInformation(new Shell(), "Information", "Sorting cannot be applied");
				return;
			}

			if (!isColumnIndexSorted(columnIndex)) {
				clear();
			}
			//if (sortDirection.equals(SortDirectionEnum.NONE)) {
			if (isColumnIndexSorted(columnIndex) && sortDirec.equals(SortDirectionEnum.NONE)) {
				// we don't support NONE as user action
				sortDirec = SortDirectionEnum.ASC;
				//clear();
			}

			Collections.sort(this.catAttrlistIo, new CategoryAttributesComparator(columnIndex, sortDirec));
			this.sortDirections[columnIndex] = sortDirec;
			this.sorted[columnIndex] = sortDirec.equals(SortDirectionEnum.NONE) ? false : true;
			this.currentSortColumn = columnIndex;
			this.currentSortDir = sortDirec;
		}

		public void clearSort(int columnIndex, SortDirectionEnum sortDirection, boolean accumulate)
		{
			clear();
			Collections.sort(this.catAttrlistIo, new CategoryAttributesComparator(columnIndex, sortDirection));
			this.sortDirections[columnIndex] = sortDirection;
			this.sorted[columnIndex] = sortDirection.equals(SortDirectionEnum.NONE) ? false : true;
			this.currentSortColumn = columnIndex;
			this.currentSortDir = sortDirection;


		}
		@SuppressWarnings("rawtypes")
		@Override
		public List<Comparator> getComparatorsForColumnIndex(int columnIndex) {
			return null;
		}
		@Override
		public Comparator<?> getColumnComparator(int columnIndex) {
			return null;
		}


		/**
		 * Custom comparator for {@link PersonWithAddress} objects
		 */
		class CategoryAttributesComparator implements Comparator<CategoryAttributes> {
			int colIdx = 0;
			SortDirectionEnum sortDirection;
			public CategoryAttributesComparator(int columnIndex, SortDirectionEnum sortDirection) {
				this.colIdx = columnIndex;
				this.sortDirection = sortDirection;
			}
			@SuppressWarnings({ "rawtypes", "unchecked" })
			@Override
			public int compare(CategoryAttributes catAttributes1, CategoryAttributes catAttributes2) {
				//remove search highlight before sorting
				getSelectionLayer().setConfigLabelAccumulator(null);
				
				Comparable compareObject1 = null;
				Comparable compareObject2 = null;

				switch (this.colIdx) {				
				case 2:
					compareObject1 = catAttributes1.getName();
					compareObject2 = catAttributes2.getName();
					break;
					
				case 6:
					compareObject1 = catAttributes1.getBaseType();
					compareObject2 = catAttributes2.getBaseType();
					break;		
							
				case 11:
					compareObject1 = catAttributes1.getUnit();
					compareObject2 = catAttributes2.getUnit();
					break;
							
				case 9:
					try {
						String min1 = catAttributes1.getMin();
						String min2 = catAttributes2.getMin();
						
						if(min1!=null && !min1.equals(""))
						{
							compareObject1 = Double.parseDouble(catAttributes1.getMin());
						}
						if(min2!=null && !min2.equals(""))
						{
							compareObject2 = Double.parseDouble(catAttributes2.getMin());
						}
						
					} catch (NumberFormatException exception) {
						LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, exception);
					}
					break;
				case 10:
					
					try {
						String max1 = catAttributes1.getMin();
						String max2 = catAttributes2.getMin();
						
						if(max1!=null && !max1.equals(""))
						{
							compareObject1 = Double.parseDouble(catAttributes1.getMax());
						}
						if(max2!=null && !max2.equals(""))
						{
							compareObject2 = Double.parseDouble(catAttributes2.getMax());
						}
						
					} catch (NumberFormatException exception) {
						LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, exception);
					}
					break;

				}

				int result = 0;
				// make null safe compare
				if (compareObject1 == null) {
					if (compareObject2 != null) {
						result = -1;
					} else {
						result = 0;
					}
				} else {
					if (compareObject2 != null) {
						result = compareObject1.compareTo(compareObject2);
					} else {
						result = 1;
					}
				}
				// negate compare result if sort direction is descending
				if (this.sortDirection.equals(SortDirectionEnum.DESC)) {
					result = result * -1;
				}
				return result;
			}
		}

	}
}



