package com.navistar.datadictionary.ui.nattable;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.nebula.widgets.nattable.config.AbstractRegistryConfiguration;
import org.eclipse.nebula.widgets.nattable.config.CellConfigAttributes;
import org.eclipse.nebula.widgets.nattable.config.EditableRule;
import org.eclipse.nebula.widgets.nattable.config.IConfigRegistry;
import org.eclipse.nebula.widgets.nattable.config.IEditableRule;
import org.eclipse.nebula.widgets.nattable.data.IDataProvider;
import org.eclipse.nebula.widgets.nattable.edit.EditConfigAttributes;
import org.eclipse.nebula.widgets.nattable.painter.cell.ComboBoxPainter;
import org.eclipse.nebula.widgets.nattable.style.CellStyleAttributes;
import org.eclipse.nebula.widgets.nattable.style.DisplayMode;
import org.eclipse.nebula.widgets.nattable.style.Style;
import org.eclipse.nebula.widgets.nattable.util.GUIHelper;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PlatformUI;

import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.serviceimpl.EditorServiceImpl;
import com.navistar.datadictionary.ui.config.Application;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.util.ComboBoxCellEditor;
import com.navistar.datadictionary.util.NatCombo;
import com.navistar.datadictionary.util.NumberUtil;

/**
 * Class is used to implement methods for adding configuration to NatTable
 * @author JAYSHRIVISHB
 *
 */
public class NatTableEditConfiguration extends AbstractRegistryConfiguration {

	/** Logger */
	//private static final Logger LOGGER = Logger.getLogger(NatTableEditConfiguration.class);

	/** used to store maximum column count in nattable */
	public static int maxColumnCount = 0;
	
	/** used to store minimum column count in nattable */
	public static int minColumnCount = 0;
	
	/** used to store name count in nattable */
	public static int nameColumnCount = 0;
	/**
	 * Method is used to configure register
	 */
	@Override
	public void configureRegistry(IConfigRegistry configRegistry) {
		configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE, IEditableRule.ALWAYS_EDITABLE);
	
		//Highlight searched data object in specific row
		Style cellStyle = new Style();
		cellStyle.setAttributeValue(
				CellStyleAttributes.BACKGROUND_COLOR,
				GUIHelper.getColor(new RGB(135, 206, 250)));
		configRegistry.registerConfigAttribute(
				CellConfigAttributes.CELL_STYLE, cellStyle,
				DisplayMode.NORMAL, "High_Light_LABEL");
		
		registerEditors(configRegistry);
	}

	/**
	 * Method is used to register editors
	 * @param configRegistry
	 */
	public static void registerEditors(IConfigRegistry configRegistry) {
		registerBaseTypeComboBox(configRegistry);
		if(Application.unitsJson!=null) {
			registerUnitComboBox(configRegistry);
		}
	}

	/**
	 * Method used to register editable columns
	 * @param configRegistry
	 * @param dataProvider
	 */
	public static void registerEditableRules(IConfigRegistry configRegistry, IDataProvider dataProvider) {
		configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE, IEditableRule.ALWAYS_EDITABLE,
				DisplayMode.EDIT, CreateNatTable.colWarning);
		configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE, IEditableRule.ALWAYS_EDITABLE,
				DisplayMode.EDIT, CreateNatTable.colCategory);

		configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE, IEditableRule.ALWAYS_EDITABLE,
				DisplayMode.EDIT, CreateNatTable.colName);

		configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE, IEditableRule.ALWAYS_EDITABLE,
				DisplayMode.EDIT, CreateNatTable.colValue);

		configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE, IEditableRule.ALWAYS_EDITABLE,
				DisplayMode.EDIT, CreateNatTable.colDesc);

		configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE, IEditableRule.ALWAYS_EDITABLE,
				DisplayMode.EDIT, CreateNatTable.colBaseType);

		configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE, getEditRuleofSlopeOffset(dataProvider),
				DisplayMode.EDIT, CreateNatTable.colOffset);

		configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE, getEditRuleofSlopeOffset(dataProvider),
				DisplayMode.EDIT, CreateNatTable.colSlope);

		configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE, IEditableRule.ALWAYS_EDITABLE,
				DisplayMode.EDIT, CreateNatTable.colMin);

		configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE, IEditableRule.ALWAYS_EDITABLE,
				DisplayMode.EDIT, CreateNatTable.colMax);

		configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE, IEditableRule.ALWAYS_EDITABLE,
				DisplayMode.EDIT, CreateNatTable.colUnit);

		configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE, IEditableRule.ALWAYS_EDITABLE,
				DisplayMode.EDIT, CreateNatTable.colComplex);

		configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE, IEditableRule.NEVER_EDITABLE,
				DisplayMode.EDIT, CreateNatTable.colDim);

		configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE, IEditableRule.ALWAYS_EDITABLE,
				DisplayMode.EDIT, CreateNatTable.colDimMode);

		configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE, IEditableRule.ALWAYS_EDITABLE,
				DisplayMode.EDIT, CreateNatTable.colSamplTim);

		/*configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE, IEditableRule.ALWAYS_EDITABLE,
				DisplayMode.EDIT, CreateNatTable.colSampMode);
*/
		configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE, IEditableRule.ALWAYS_EDITABLE,
				DisplayMode.EDIT, CreateNatTable.colInitVal);

		configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE, IEditableRule.ALWAYS_EDITABLE,
				DisplayMode.EDIT, CreateNatTable.colSwCalAccess);

		configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE, IEditableRule.ALWAYS_EDITABLE,
				DisplayMode.EDIT, CreateNatTable.colDispFor);

		configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE, IEditableRule.ALWAYS_EDITABLE,
				DisplayMode.EDIT, CreateNatTable.colCoderInf);
		
		configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE, IEditableRule.NEVER_EDITABLE,
				DisplayMode.EDIT, CreateNatTable.colOldName);
	}
	
	/**
	 * Method is used to configure drop down for BaseType field in NatTable
	 * @param configRegistry
	 */
	public static void registerBaseTypeComboBox(IConfigRegistry configRegistry) {
		// register a combobox for the city names
		ComboBoxCellEditor comboBoxObj = new ComboBoxCellEditor(getBaseTypeList()) {
			@Override
			protected void addNatComboListener(NatCombo combo) {
				super.addNatComboListener(combo);
				combo.addSelectionListener(new SelectionListener() {

					@Override
					public void widgetSelected(SelectionEvent event) {
						setOffsetAndSlope((String) event.item.getData());
					}

					@Override
					public void widgetDefaultSelected(SelectionEvent event) {
						// widgetDefaultsel

					}
				});
			}
		};
		configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITOR, comboBoxObj, DisplayMode.NORMAL,
				CreateNatTable.colBaseType);

		configRegistry.registerConfigAttribute(CellConfigAttributes.CELL_PAINTER, new ComboBoxPainter(),
				DisplayMode.NORMAL, CreateNatTable.colBaseType);
	}

	/**
	 * Method is used to validate the number
	 * @param newValue
	 * @param validNumberStatus
	 * @param selectedBaseType
	 * @return
	 */
	public static boolean isNumberValid(Object newValue,Object selectedBaseType) {
		boolean validNumberStatus = true;
		if (selectedBaseType.equals(ApplicationConstant.INT8)) {
			if (!NumberUtil.validateInt8(newValue)) {
				validNumberStatus = false;
			}
		} else if (selectedBaseType.equals(ApplicationConstant.UINT8)) {
			if (!NumberUtil.validateUInt8(newValue)) {
				validNumberStatus = false;
			}
		} else if (selectedBaseType.equals(ApplicationConstant.INT16)) {
			if (!NumberUtil.validateInt16(newValue)) {
				validNumberStatus = false;
			}
		} else if (selectedBaseType.equals(ApplicationConstant.UINT16)) {
			if (!NumberUtil.validateUInt16(newValue)) {
				validNumberStatus = false;
			}
		} else if (selectedBaseType.equals(ApplicationConstant.INT32)) {
			if (!NumberUtil.validateInt32(newValue)) {
				validNumberStatus = false;
			}
		} else if (selectedBaseType.equals(ApplicationConstant.UINT32)) {
			if (!NumberUtil.validateUInt32(newValue)) {
				validNumberStatus = false;
			}
		}
		
		return validNumberStatus;
	}
	
	/**
	 * Method used to get the name list from existing data
	 * @param dataProvider
	 * @return
	 */
	public static List<String> getNameList(int rowIndex){
		
		IWorkbenchPage activePage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
		IEditorReference[] editors = activePage.getEditorReferences();
		
		List<String> nameList = new ArrayList<>();
		for(IEditorReference editorRef : editors){
			IEditorPart editorPart = editorRef.getEditor(false);
			
			if(editorPart instanceof CategoryEditor) {
				IDataProvider dataProvider = ((CategoryEditor) editorPart).createNatTable.getJsonDataProvider();
				for(int i=0;i<dataProvider.getRowCount();i++){
					if(i != rowIndex){
						nameList.add((String)dataProvider.getDataValue(CreateNatTable.colNameIdx, i));
					}
				}
			}
		}
		return nameList;
	}
	
	/**
	 * drop down list
	 * 
	 * @return List<String>
	 */
	private static List<String> getBaseTypeList() {
		List<String> baseTypeList = new ArrayList<>();
		baseTypeList.add(ApplicationConstant.SINGLE);
		baseTypeList.add(ApplicationConstant.BOOLEAN);
		baseTypeList.add(ApplicationConstant.INT8);
		baseTypeList.add(ApplicationConstant.UINT8);
		baseTypeList.add(ApplicationConstant.INT16);
		baseTypeList.add(ApplicationConstant.UINT16);
		baseTypeList.add(ApplicationConstant.INT32);
		baseTypeList.add(ApplicationConstant.UINT32);
		return baseTypeList;
	}

	/**
	 * set offset and slope according to selected abstract type
	 * 
	 * @param configRegistry
	 * @param baseType
	 */
	private static void setOffsetAndSlope(String baseType) {

		IEditorPart editor = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor();
		CategoryEditor categoryEditor = (CategoryEditor) editor;
		int rowIndex = categoryEditor.natTable.getActiveCellEditor().getRowIndex();

		if (baseType.equals(ApplicationConstant.SINGLE) || baseType.equals(ApplicationConstant.BOOLEAN)) {

			categoryEditor.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colOffIdx,
					rowIndex, "0");
			categoryEditor.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colSlopIdx,
					rowIndex, "1");
		} else {
			categoryEditor.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colOffIdx,
					rowIndex, "0");
			categoryEditor.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colSlopIdx,
					rowIndex, "1");
		}
	}

	/**
	 * Edit rule: depending on basic type make offset and slope editable
	 * @param dataProvider
	 */
	private static IEditableRule getEditRuleofSlopeOffset(final IDataProvider dataProvider) {

		return new EditableRule() {
			@Override
			public boolean isEditable(int columnIndex, int rowIndex) {
				int colIdxBaseType = CreateNatTable.colBaseTyIdx;

				if ((((String) dataProvider.getDataValue(colIdxBaseType, rowIndex)).equals(ApplicationConstant.SINGLE))
						|| (((String) dataProvider.getDataValue(colIdxBaseType, rowIndex)).equals(ApplicationConstant.BOOLEAN))) {
					return false;
				} else {
					return true;
				}
			}
		};
	}
	
	public static void registerUnitComboBox(IConfigRegistry configRegistry) {
        ComboBoxCellEditor comboBoxObj = null;
        List<String> list = new EditorServiceImpl().getUnitsList();
		
		comboBoxObj = new ComboBoxCellEditor(list, 10) {

			@Override
			protected void addNatComboListener(NatCombo combo) {
				super.addNatComboListener(combo);
				combo.addSelectionListener(new SelectionListener() {
	            	  
                    @Override
                    public void widgetSelected(SelectionEvent event) {
                    	String comboBoxString = (String) event.item.getData();
                    //	comboBoxString = comboBoxString.substring(comboBoxString.first(":") + 0);
                    	comboBoxString = comboBoxString.split(" : ")[0];
                    }

                    @Override
                    public void widgetDefaultSelected(SelectionEvent event) {
                    	// widgetDefaultsel
                    }
              });
				
				
			}
			
		};
	
		comboBoxObj.setFreeEdit(false);
	//	comboBoxObj.setShowDropdownFilter(true);
       
              configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITOR, comboBoxObj,
                          DisplayMode.NORMAL, CreateNatTable.colUnit);

              configRegistry.registerConfigAttribute(CellConfigAttributes.CELL_PAINTER, new ComboBoxPainter(),
                          DisplayMode.NORMAL, CreateNatTable.colUnit);
		
	}
	
}
