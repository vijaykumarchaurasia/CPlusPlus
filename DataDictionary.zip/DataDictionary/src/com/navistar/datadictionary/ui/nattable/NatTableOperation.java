package com.navistar.datadictionary.ui.nattable;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.nebula.widgets.nattable.NatTable;
import org.eclipse.nebula.widgets.nattable.data.IDataProvider;
import org.eclipse.nebula.widgets.nattable.viewport.command.ShowRowInViewportCommand;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PlatformUI;

import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.serviceimpl.OpenComponentServiceImpl;
import com.navistar.datadictionary.ui.config.Application;
import com.navistar.datadictionary.ui.editors.CategoryEditor;

/**
 * The class is used to get all selected data or a row data of a category which
 * is edited or newly added in the table.
 * 
 * @author vijayk13
 *
 */
public class NatTableOperation {

	/** Used to get the existing category list */
	public List<CategoryAttributes> existCatList;
	
	public static List<String> duplicateNameList = new ArrayList<>();
	
	public static IWorkbenchPage activePage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
	
	public CategoryAttributes categoryDAO;
	
	/**
	 * Function is used to get the all selection data of type category that is
	 * edited or newly added data
	 * 
	 * @param selectedTableCellList
	 * @param natTable
	 * @return
	 */
	public List<CategoryAttributes> getNewDataofCategory(Set<Integer> selTblCellList,
			IDataProvider bodyDataProvider) {
		ArrayList<CategoryAttributes> newCatDataList = new ArrayList<>();
		if(selTblCellList.contains(new Integer(-1))){
			selTblCellList.remove(new Integer(-1));
		}
		for (Integer row : selTblCellList) {
				
				CategoryAttributes categoryDAO = getSelectedRowData(row, bodyDataProvider);
				//// Condition to check for ant empty fields for newly inserted data object
				if (categoryDAO != null) {
					newCatDataList.add(categoryDAO);
				} else {
					newCatDataList = null;
					break;
				}
			}
		return newCatDataList;
	}
	
	
	/**
	 * Method used to add a new row in natTable
	 * @param parent
	 * @param newRowIndex
	 */
	public void addNewRowInNatTable(Composite parent,int newRowIndex,CreateNatTable createNatTable, NatTable natTable,Set<Integer> newAddedRowLists,String categoryName,CategoryAttributes catAttributes) {

		//	String categoryName = (String)createNatTable.getJsonDataProvider().getDataValue(CreateNatTable.COLUMN_CATEGORY_INDEX, 0);
			
			//Create empty object to add new row
			categoryDAO = new CategoryAttributes("",categoryName, "","", "", "", "", "",
					"", "", "", "", "","", "","","","","","","","");
			if(null!=catAttributes){
				setInputCategoryAttributes(categoryName, catAttributes, categoryDAO);
			}else{
				categoryDAO.setBaseType("single");
				categoryDAO.setOffset("0");
				categoryDAO.setSlope("1");
				categoryDAO.setOldName("null");
				categoryDAO.setStructureElementName(null);
				//categoryDAO.setMemorySection("null");
			}
			categoryDAO.setComponent(new OpenComponentServiceImpl().getOpenedComponentName());
			existCatList = createNatTable.getCategoryList();
			existCatList.add(newRowIndex, categoryDAO);

			createNatTable.setCategoryList(existCatList);

			//Display natTable with newly added row

			createNatTable.filterList.add(categoryDAO);
			natTable.refresh();

			//If rowIndex is greater than -1
			if(newRowIndex > -1)
			{
				newAddedRowLists.add(newRowIndex);
			}		
			NatTableEditConfiguration.maxColumnCount = 0;
			NatTableEditConfiguration.minColumnCount = 0;
			NatTableEditConfiguration.nameColumnCount = 0;

		}


	/**
	 * @param categoryName
	 * @param categoryAttributes
	 * @param categoryDAO
	 */
	private void setInputCategoryAttributes(String categoryName, CategoryAttributes catAttributes,
			CategoryAttributes categoryDAO) {
		if (null != catAttributes.getName() && catAttributes.getName() != "") {
			categoryDAO.setName(catAttributes.getName());
		}
		if (null != catAttributes.getDescription() && catAttributes.getDescription() != "") {
			categoryDAO.setDescription(catAttributes.getDescription());
		}
		if (null != catAttributes.getBaseType() && catAttributes.getBaseType() != "") {
			categoryDAO.setBaseType(catAttributes.getBaseType());
		}
		if (null != catAttributes.getCategory() && catAttributes.getCategory() != "") {
			categoryDAO.setCategory(categoryName);
		}
		if (null != catAttributes.getDimensions() && catAttributes.getDimensions() != "") {
			categoryDAO.setDimensions(catAttributes.getDimensions());
		}
		if (null != catAttributes.getInitialValue() && catAttributes.getInitialValue() != "") {
			categoryDAO.setInitialValue(catAttributes.getInitialValue());
		}
		//Set Visible attributes
		setVisibleAttributes(catAttributes, categoryDAO);
		//Set Hidden attributes
		setHiddenattributes(catAttributes, categoryDAO);
	}


	/**
	 * @param categoryName
	 * @param categoryAttributes
	 * @param categoryDAO
	 */
	private void setVisibleAttributes(CategoryAttributes catAttributes,
			CategoryAttributes categoryDAO) {
		if (null != catAttributes.getMax() && catAttributes.getMax() != "") {
			categoryDAO.setMax(catAttributes.getMax());
		}
		if(null!=catAttributes.getMin() && catAttributes.getMin()!=""){
			categoryDAO.setMin(catAttributes.getMin());
		}
		if(null!=catAttributes.getOffset() && catAttributes.getOffset()!=""){
			categoryDAO.setOffset(catAttributes.getOffset());
		}
		if(null!=catAttributes.getSlope() && catAttributes.getSlope()!=""){
			categoryDAO.setSlope(catAttributes.getSlope());
		}
		if(null!=catAttributes.getUnit() && catAttributes.getUnit()!=""){
			categoryDAO.setUnit(catAttributes.getUnit());
		}
		if(null!=catAttributes.getValue() && catAttributes.getValue()!=""){
			categoryDAO.setValue(catAttributes.getValue());
		}
	}


	/**
	 * @param categoryAttributes
	 * @param categoryDAO
	 */
	private void setHiddenattributes(CategoryAttributes catAttributes, CategoryAttributes categoryDAO) {
		if (null != catAttributes.getDimensionsMode() && catAttributes.getDimensionsMode() != "") {
			categoryDAO.setDimensionsMode(catAttributes.getDimensionsMode());
		}
		if (null != catAttributes.getComplexity() && catAttributes.getComplexity() != "") {
			categoryDAO.setComplexity(catAttributes.getComplexity());
		}
		if(null!=catAttributes.getSampleTime() && catAttributes.getSampleTime()!=""){
			categoryDAO.setSampleTime(catAttributes.getSampleTime());
		}
		/*if(null!=catAttributes.getSamplingMode() && catAttributes.getSamplingMode()!=""){
			categoryDAO.setSamplingMode(catAttributes.getSamplingMode());
		}*/
		if(null!=catAttributes.getSwCalAccess() && catAttributes.getSwCalAccess()!=""){
			categoryDAO.setSwCalAccess(catAttributes.getSwCalAccess());
		}
		if (null != catAttributes.getDisplayFormat() && catAttributes.getDisplayFormat() != "") {
			categoryDAO.setDisplayFormat(catAttributes.getDisplayFormat());
		}
		if (null != catAttributes.getCoderInfo() && catAttributes.getCoderInfo() != "") {
			categoryDAO.setCoderInfo(catAttributes.getCoderInfo());
		}
		if(null!=catAttributes.getMemorySection() && catAttributes.getMemorySection()!=""){
			categoryDAO.setOldName(catAttributes.getMemorySection());
		}	
		if(null!=catAttributes.getOldName() && catAttributes.getOldName()!=""){
			categoryDAO.setOldName(catAttributes.getOldName());
		}
		if(null!=catAttributes.getMaxDimension() && catAttributes.getMaxDimension()!=""){
			categoryDAO.setMaxDimension(catAttributes.getMaxDimension());
		}
	}

	/**
	 * Function is used to get the particular row data of type category.
	 * 
	 * @param rowIndex
	 * @param bodyDataProvider
	 * @return categoryDAO
	 */
	public CategoryAttributes getSelectedRowData(int rowIndex, IDataProvider bodyDataProvider) {
		
		CreateNatTable hiddenAttriValue = new  CreateNatTable();
		CategoryAttributes category = getCategoryForSelectedRow(rowIndex, bodyDataProvider);
		category.setWarning("");
		category.setStructureElementName(null);
		String categoryName = category.getCategory();

		// Condition to check for any empty fields for newly inserted dataobject
		if (checkForEmptyField(category)) {
			CategoryEditor categoryEditor = getCategoryEditor(category.getCategory());
			categoryEditor.emptyFieldsFlag = true;
			category = null;

		}
		else if(!isDataObjectNameValid(category))
		{
			return null;
		}
		else {
			if (isNameDuplicate(rowIndex, category.getCategory(), category.getName())) {
			//	CategoryEditor categoryEditor = getCategoryEditor(category.getCategory());
				CategoryEditor.duplicNameFlg = true;
				duplicateNameList.add(category.getName());
				category = null;
			} else {
				// Default value for hidden columns of all categories
				category.setDimensionsMode(hiddenAttriValue.hiddenAttributeValues(category.getCategory(), "Dimensions Mode"));
				category.setComplexity(hiddenAttriValue.hiddenAttributeValues(category.getCategory(), "Complexity"));
				category.setCoderInfo(hiddenAttriValue.hiddenAttributeValues(category.getCategory(), "Storage Class"));
				
				if(isNullOrEmpty(category.getDescription())) {
					category.setDescription("");
				}
				
				//set min and max of define from value
				if((ApplicationConstant.CATEGORY_DEFINE).equals(categoryName)){
					category.setMin(category.getMin());
					category.setMax(category.getMax());
				}
				
				//SampleTime hidden so set default value
			/*	if ((ApplicationConstant.CATEGORY_INPUT).equals(categoryName)
						|| (ApplicationConstant.CATEGORY_OUTPUT).equals(categoryName)
						|| (ApplicationConstant.CATEGORY_LOCAL).equals(categoryName)
						|| (ApplicationConstant.CATEGORY_NVM).equals(categoryName)) {		*/		
					category.setSampleTime(hiddenAttriValue.hiddenAttributeValues(category.getCategory(), "Sample Time"));		
				//} 
				
				//SwCalibrationAccess and DisplayFormat is n/a so set it as "Null"
				/*if ((ApplicationConstant.CATEGORY_LOCAL).equals(categoryName)
						|| (ApplicationConstant.CATEGORY_NVM).equals(categoryName)
						|| (ApplicationConstant.CATEGORY_DEFINE).equals(categoryName)) {	*/			
				category.setSwCalAccess(hiddenAttriValue.hiddenAttributeValues(category.getCategory(), "SwCalibration Access"));
					if(Application.programName.equals("E44"))
					{
						category.setDisplayFormat(hiddenAttriValue.hiddenAttributeValues(category.getCategory(), "Display Format"));
						category.setMemorySection(null);
					}
					else
					{
						category.setMemorySection(hiddenAttriValue.hiddenAttributeValues(category.getCategory(), "Memory Section"));
						category.setDisplayFormat(null);
					}
				/*} else{
					//column is hidden so set default value
					category.setSwCalAccess("ReadOnly");
					if(Application.programName.equals("E44"))
					{
					category.setDisplayFormat("");
					category.setMemorySection(null);
					}
					else
					{
						category.setDisplayFormat(null);
						category.setMemorySection("CONST");
					}
				}*/
		}

		}

		return category;

	}
	
	/**
	 * Method used to check name is duplicate or not
	 * @param categoryName
	 */
	private boolean isNameDuplicate(int rowIndex,String categoryType,String categoryName) {
		List<String> existingNameList = getExistingNameList(rowIndex,categoryType);
		/*if(existingNameList.contains(categoryName)){
			return true;
		}else{
			return false;
		}*/
		return existingNameList.contains(categoryName);
	}

	/**
	 * Method used to get the list of names for existing data objects
	 * @param rowIndex
	 * @param categoryType
	 * @param categoryName
	 * @return
	 */
	private List<String> getExistingNameList(int rowIndex,String categoryType){

		IEditorReference[] editors = activePage.getEditorReferences();
		
		List<String> nameList = new ArrayList<>();
		for(IEditorReference editorRef : editors){
			IEditorPart editorPart = editorRef.getEditor(false);
			
			if(editorPart instanceof CategoryEditor) {
				IDataProvider dataProvider = ((CategoryEditor) editorPart).createNatTable.getJsonDataProvider();
				for(int i=0;i<dataProvider.getRowCount();i++){
					if(editorPart.getTitle().equals(categoryType)){
						if(i != rowIndex){
							nameList.add((String)dataProvider.getDataValue(CreateNatTable.colNameIdx, i));
						}		
					}else{
						nameList.add((String)dataProvider.getDataValue(CreateNatTable.colNameIdx, i));
					}
				}
			}
		}
		return nameList;
	}
	/**
	 * Function is used to check empty input for new object
	 * 
	 * @param categoryDAO
	 * @return boolean
	 */
	private boolean checkForEmptyField(CategoryAttributes categoryDAO) {
		
		boolean statusValue = false;
		
		//Check empty fields depending on categories
		if((ApplicationConstant.CATEGORY_AXIS).equals(categoryDAO.getCategory())
				|| (ApplicationConstant.CATCALIBRATION).equals(categoryDAO.getCategory())
				|| (ApplicationConstant.CATEGORY_MAP).equals(categoryDAO.getCategory())
				|| (ApplicationConstant.CATEGORY_CURVE).equals(categoryDAO.getCategory())) {
			statusValue = isCategoryFieldsEmpty(categoryDAO);
			
		} else if ((ApplicationConstant.CATEGORY_INPUT).equals(categoryDAO.getCategory())
				|| (ApplicationConstant.CATEGORY_OUTPUT).equals(categoryDAO.getCategory())
				|| (ApplicationConstant.CATEGORY_LOCAL).equals(categoryDAO.getCategory())) {	
			statusValue = isNameAndBaseTypeFieldEmpty(categoryDAO);
			
		}else if ((ApplicationConstant.CATEGORY_NVM).equals(categoryDAO.getCategory())) {		
			statusValue = isNameAndBaseTypeFieldEmpty(categoryDAO);	
			
		}else if ((ApplicationConstant.CATEGORY_DEFINE).equals(categoryDAO.getCategory())) {			
			statusValue = isDefineCategoryFieldsEmpty(categoryDAO);	
			
		}
		return statusValue;
	}

	/**
	 * This method is used to check Input, Output, Local and NVM Category Name and Data Type Fields Null or Empty. 
	 * @param categoryDAO
	 * @return
	 */
	private boolean isNameAndBaseTypeFieldEmpty(CategoryAttributes categoryDAO) {
		boolean statusValue;
		if (isNullOrEmpty(categoryDAO.getName())) {
			statusValue = true;
		} else {		
			statusValue = false;
		}
		return statusValue;
	}
	
	/**
	 * This method is used to check Axis, Map, Curve and calibration Category required fields Null or Empty.
	 * @param categoryDAO
	 * @return
	 */
	private boolean isCategoryFieldsEmpty(CategoryAttributes categoryDAO) {
		boolean statusValue;
		if (isNullOrEmpty(categoryDAO.getName()) || isNullOrEmpty(categoryDAO.getValue())
				|| isNullOrEmpty(categoryDAO.getMin()) || isNullOrEmpty(categoryDAO.getMax())) {
			statusValue = true;
		} else {			
			statusValue = false;
		}
		return statusValue;
	}
	
	/**
	 * This method is used to check Define Category required fields Null or Empty.
	 * @param categoryDAO
	 * @return
	 */
	private boolean isDefineCategoryFieldsEmpty(CategoryAttributes categoryDAO) {
		boolean statusValue;
		if (isNullOrEmpty(categoryDAO.getName()) || isNullOrEmpty(categoryDAO.getValue())) {
			statusValue = true;
		} else {
			
			statusValue = false;
		}
		return statusValue;
	}
	
	/**
	 * This method is used to check inputString is null or empty
	 * @param inputString
	 * @return boolean
	 */
	private boolean isNullOrEmpty(String inputString) {
        /*if(inputString != null && !inputString.trim().isEmpty())
        {
            return false;
        }
        return true;*/
		return !(inputString != null && !inputString.trim().isEmpty());
    }
	
	/**
	 * Method used to set focus on newly added row
	 * @param rowCount
	 */
	public void setFocusOnNewRow(int rowCount,CreateNatTable createNatTable ,NatTable natTable, int newRowIndex )
	{
		natTable.doCommand(new ShowRowInViewportCommand(createNatTable.getGridLayer().getBodyLayer(), newRowIndex));
	}

	/**
	 * Method is used to get category data for selected row by providing the row index
	 * @param rowIndex
	 * @param bodyDataProvider
	 * @return
	 */
	public CategoryAttributes getCategoryForSelectedRow(int rowIndex, IDataProvider bodyDataProvider) {
		CategoryAttributes category = new CategoryAttributes();
		category.setWarning((String) bodyDataProvider.getDataValue(0, rowIndex));
		category.setCategory((String) bodyDataProvider.getDataValue(1, rowIndex));
		category.setName((String) bodyDataProvider.getDataValue(2, rowIndex));
		category.setStructureElementName((String) bodyDataProvider.getDataValue(3, rowIndex));
		String value = convertValueToString((String) bodyDataProvider.getDataValue(4, rowIndex));
		if(value != null) {
			category.setValue(value);
		}
		else {
			category.setValue("");
		}
		
		String descriptionValue = (String) bodyDataProvider.getDataValue(5, rowIndex);
		if(descriptionValue != null) {
			category.setDescription(descriptionValue);
		}
		else {
			category.setDescription("");
		}
		
		category.setComponent((String) bodyDataProvider.getDataValue(6, rowIndex));
		//category.setBaseType((String) bodyDataProvider.getDataValue(6, rowIndex));
		String baseType = (String) bodyDataProvider.getDataValue(7, rowIndex);
		if(baseType!=null)
		{
			category.setBaseType(baseType);
		}
		else
		{
			category.setBaseType("");
		}
		
		String offsetValue = (String) bodyDataProvider.getDataValue(8, rowIndex);
		if(offsetValue != null) {
			category.setOffset(offsetValue);
		}
		else {
			category.setOffset("");
		}
		
		String slope = (String) bodyDataProvider.getDataValue(9, rowIndex);
		if(slope!=null)
		{
			category.setSlope(slope);
			
		}else
		{
			category.setSlope("");
			
		}
		
		String minVal = (String) bodyDataProvider.getDataValue(10, rowIndex);
		if(minVal!=null)
		{
			category.setMin(minVal);
		}
		else
		{
			category.setMin("");
		}
		
		String maxVal = (String) bodyDataProvider.getDataValue(11, rowIndex);
		if(maxVal!=null)
		{
			category.setMax(maxVal);
		}
		else
		{
			category.setMax("");
		}
		
		String unitVal = (String) bodyDataProvider.getDataValue(12, rowIndex);
		if(unitVal!=null)
		{
			category.setUnit(unitVal);
		}
		else
		{
			category.setUnit("");
		}
		
		
		category.setComplexity((String) bodyDataProvider.getDataValue(17, rowIndex));
		category.setDimensions((String) bodyDataProvider.getDataValue(14, rowIndex));
		category.setDimensionsMode((String) bodyDataProvider.getDataValue(15, rowIndex));
		category.setSampleTime((String) bodyDataProvider.getDataValue(16, rowIndex));
//		category.setSamplingMode((String) bodyDataProvider.getDataValue(16, rowIndex));
		
		String initialval = (String) bodyDataProvider.getDataValue(13, rowIndex);
		if(initialval!=null)
		{
			category.setInitialValue(initialval);
			
		}
		else
		{
			category.setInitialValue("");
			
		}
		
		
		category.setSwCalAccess((String) bodyDataProvider.getDataValue(18, rowIndex));
		category.setDisplayFormat((String) bodyDataProvider.getDataValue(20, rowIndex));
		category.setCoderInfo((String) bodyDataProvider.getDataValue(19, rowIndex));
		category.setMemorySection((String) bodyDataProvider.getDataValue(21, rowIndex));
		category.setOldName((String) bodyDataProvider.getDataValue(22, rowIndex));
		return category;
	}
	
	/**
	 * Method is used to set category data for selected row by providing the row index
	 * @param rowIndex
	 * @param bodyDataProvider
	 * @return
	 */
	public void setCategoryForSelectedRow(CategoryAttributes catAttributes,int rowIndex, IDataProvider bodyDataProvider) {
		bodyDataProvider.setDataValue(0, rowIndex, catAttributes.getWarning());
		bodyDataProvider.setDataValue(1, rowIndex, catAttributes.getCategory());
		bodyDataProvider.setDataValue(2, rowIndex, catAttributes.getName());
		bodyDataProvider.setDataValue(3, rowIndex, catAttributes.getStructureElementName());
		bodyDataProvider.setDataValue(4, rowIndex, catAttributes.getValue());
		bodyDataProvider.setDataValue(5, rowIndex, catAttributes.getDescription());
		bodyDataProvider.setDataValue(6, rowIndex, catAttributes.getComponent());
		bodyDataProvider.setDataValue(7, rowIndex, catAttributes.getBaseType());
		bodyDataProvider.setDataValue(8, rowIndex, catAttributes.getOffset());
		bodyDataProvider.setDataValue(9, rowIndex, catAttributes.getSlope());
		bodyDataProvider.setDataValue(10, rowIndex, catAttributes.getMin());
		bodyDataProvider.setDataValue(11, rowIndex, catAttributes.getMax());
		bodyDataProvider.setDataValue(12, rowIndex, catAttributes.getUnit());
		bodyDataProvider.setDataValue(13, rowIndex, catAttributes.getComplexity());
		bodyDataProvider.setDataValue(14, rowIndex, catAttributes.getDimensions());
		bodyDataProvider.setDataValue(15, rowIndex, catAttributes.getDimensionsMode());
		bodyDataProvider.setDataValue(16, rowIndex, catAttributes.getSampleTime());
	//	bodyDataProvider.setDataValue(16, rowIndex, catAttributes.getSamplingMode());
		bodyDataProvider.setDataValue(17, rowIndex, catAttributes.getInitialValue());
		bodyDataProvider.setDataValue(18, rowIndex, catAttributes.getSwCalAccess());
		bodyDataProvider.setDataValue(19, rowIndex, catAttributes.getDisplayFormat());
		bodyDataProvider.setDataValue(20, rowIndex, catAttributes.getCoderInfo());
		bodyDataProvider.setDataValue(21, rowIndex, catAttributes.getOldName());
		bodyDataProvider.setDataValue(22, rowIndex, catAttributes.getOldName());
		bodyDataProvider.setDataValue(23, rowIndex, catAttributes.getMaxDimension());
	}
	
	/** 
	 * Method used to convert value into string 
	 * @param value
	 * @return
	 */
	private String convertValueToString(String value){
		String valueString = "";
		
		if(!isNullOrEmpty(value)){
			valueString = value.replace("][", ",");
		}		
		return valueString;
		
	}
	
	/**
	 * Method used to get instance of categoryEditor
	 * @return
	 */
	private CategoryEditor getCategoryEditor(String categoryType) {
		CategoryEditor categoryEditor = null;
		IEditorPart[] dirtyEditors = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getDirtyEditors();
		
		for(IEditorPart editor : dirtyEditors){
			if(editor.getTitle().equals(categoryType)){
				categoryEditor = (CategoryEditor)editor;
			}
		}
		return categoryEditor;
	}
	
	/**
	 * Method used to set default values after data objects added from model
	 * 
	 * @param parent
	 * @param newRowIndex
	 * @param createNatTable
	 * @param natTable
	 * @param newAddedRowLists
	 * @param categoryDAO
	 */
	public void addDataObjectsToResolveIncFrmModel(Composite parent,int newRowIndex,CreateNatTable createNatTable, NatTable natTable,Set<Integer> newAddedRowLists,CategoryAttributes categoryDAO) {

		//	String categoryName = (String)createNatTable.getJsonDataProvider().getDataValue(CreateNatTable.COLUMN_CATEGORY_INDEX, 0);
		    CreateNatTable hiddenAttriValue = new  CreateNatTable();
			if(categoryDAO.getCategory().equals("Define") || categoryDAO.getCategory().equals("Map") || categoryDAO.getCategory().equals("Curve") || categoryDAO.getCategory().equals("Axis") || categoryDAO.getCategory().equals("Calibration")) {
				categoryDAO.setMin("0");
				categoryDAO.setMax("1");
				
				if(categoryDAO.getCategory().equals("Define")) {
					categoryDAO.setValue("0");		
				}
				else {
					categoryDAO.setValue("[0.0]");
				}
				categoryDAO.setInitialValue("");
				categoryDAO.setDimensions("[1,1]");
			}
			else {
				categoryDAO.setMin("");
				categoryDAO.setMax("");
				categoryDAO.setInitialValue("");
				categoryDAO.setValue("");
				categoryDAO.setDimensions("1");
			}
			//Create object to add new row
			categoryDAO.setBaseType("single");
			categoryDAO.setOffset("0");
			categoryDAO.setSlope("1");
			categoryDAO.setOldName("null");
			categoryDAO.setStructureElementName(null);
			if (Application.programName.equals("E95"))
			{
				categoryDAO.setMemorySection(hiddenAttriValue.hiddenAttributeValues(categoryDAO.getCategory(),"Memory Section"));
			}
			else
			{
				categoryDAO.setMemorySection(null);
			}
			categoryDAO.setDescription("");
			
			categoryDAO.setUnit("");
			
			categoryDAO.setSampleTime(hiddenAttriValue.hiddenAttributeValues(categoryDAO.getCategory(), "Sample Time"));
			
			existCatList = createNatTable.getCategoryList();
			existCatList.add(newRowIndex, categoryDAO);

			createNatTable.setCategoryList(existCatList);

			createNatTable.filterList.add(categoryDAO);
			natTable.refresh();

			//If rowIndex is greater than -1
			if(newRowIndex > -1)
			{
				newAddedRowLists.add(newRowIndex);
			}		
			NatTableEditConfiguration.maxColumnCount = 0;
			NatTableEditConfiguration.minColumnCount = 0;
			NatTableEditConfiguration.nameColumnCount = 0;

		}
	
	/**
	 * Method used to set default values after data objects added from CAN excel sheet
	 * 
	 * @param parent
	 * @param newRowIndex
	 * @param createNatTable
	 * @param natTable
	 * @param newAddedRowLists
	 * @param categoryDAO
	 */
	public void addDataObjectsToResolveIncFrmExcel(Composite parent,int newRowIndex,CreateNatTable createNatTable, NatTable natTable,Set<Integer> newAddedRowLists,CategoryAttributes categoryDAO) {


		categoryDAO.setMin("");
		categoryDAO.setMax("");
		categoryDAO.setInitialValue("");
		categoryDAO.setValue("");
		categoryDAO.setDimensions("1");
		categoryDAO.setBaseType(categoryDAO.getBaseType());
		categoryDAO.setOffset(categoryDAO.getOffset());
		categoryDAO.setSlope(categoryDAO.getSlope());
		categoryDAO.setOldName("null");
		categoryDAO.setStructureElementName(null);
		if (Application.programName.equals("E95"))
		{
			categoryDAO.setMemorySection("CONST");
		}
		else
		{
			categoryDAO.setMemorySection(null);
		}
		categoryDAO.setDescription("");

		categoryDAO.setUnit("");

		existCatList = createNatTable.getCategoryList();
		existCatList.add(newRowIndex, categoryDAO);

		createNatTable.setCategoryList(existCatList);

		//Display natTable with newly added row
		createNatTable.filterList.add(categoryDAO);
		natTable.refresh();

		//If rowIndex is greater than -1
		if(newRowIndex > -1)
		{
			newAddedRowLists.add(newRowIndex);
		}		
		NatTableEditConfiguration.maxColumnCount = 0;
		NatTableEditConfiguration.minColumnCount = 0;
		NatTableEditConfiguration.nameColumnCount = 0;

	}
	
	/**
	 * Method used to check if valid name of data object entered by user
	 * @param category
	 * @return
	 */
	public boolean isDataObjectNameValid(CategoryAttributes category)
	{
		String regex = "^[a-zA-Z][a-zA-Z0-9_]*$";
		String validationMessage = "";
		String nameValue = category.getName();
		CategoryEditor editor = getCategoryEditor(category.getCategory());
		IWorkbenchPage activePage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();

		//List<String> existingNameList = NatTableEditConfiguration.getNameList(rowIndex);

		//if (columnIndex == CreateNatTable.COLUMN_DESC_INDEX || columnIndex == CreateNatTable.COLUMN_VALUE_INDEX) {
		if (nameValue == null || nameValue.equals("")) {
			validationMessage = MessageConstant.NAME_VAL;
			editor.invalidNameFlag = true;
			MessageDialog.openError(editor.parent.getShell(), ApplicationConstant.ERROR, validationMessage);
			editor.setDirty(true);
			activePage.activate(editor);
			return false;

		} else if (!((String) nameValue).matches(regex)     
				|| nameValue.length() > ApplicationConstant.MAXNAMELEN) {
			validationMessage =/* MessageConstant.EDIT_VIOLATION_MESSAGE + "\n" + "\n" + "'" +*/ nameValue + "'"
					+ MessageConstant.EDIT_MESSAGE1 + "\n" + MessageConstant.EDIT_MESSAGE2
					+ "\n" + MessageConstant.EDIT_MESSAGE3 + "\n"
					+ MessageConstant.EDIT_MESSAGE4 + "\n" + MessageConstant.EDIT_MESSAGE6;

			editor.invalidNameFlag = true;
			MessageDialog.openError(editor.parent.getShell(), ApplicationConstant.ERROR, validationMessage);
			activePage.activate(editor);
			editor.setDirty(true);

			return false;
		} /*else if (existingNameList.contains(nameValue)) {
	   validationMessage = MessageConstant.UNIQUE_NAME_VALIDATION;
	   //openMessageDialogForNameValidation(selectedCellEvent, display, validationMessage);
	   return false;
	  }*/

		return true;
	}


	/**
	 * Method used to add a new row in natTable
	 * @param parent
	 * @param newRowIndex
	 */
	public void updateNewRowInNatTable(int newRowIndex,CreateNatTable createNatTable, NatTable natTable,Set<Integer> newAddedRowLists,String categoryName,CategoryAttributes object) {

		existCatList = createNatTable.getCategoryList();
		CategoryAttributes catAttributes = existCatList.get(newRowIndex); 

		catAttributes.setName(object.getName());
		catAttributes.setBaseType(object.getBaseType());
		catAttributes.setCoderInfo(object.getCoderInfo());
		catAttributes.setCategory(categoryName);
		catAttributes.setComplexity(object.getComplexity());
		catAttributes.setComponent(new OpenComponentServiceImpl().getOpenedComponentName());
		catAttributes.setDescription(object.getDescription());
		catAttributes.setDimensions(object.getDimensions());
		catAttributes.setDimensionsMode(object.getDimensionsMode());
		catAttributes.setDisplayFormat(object.getDisplayFormat());
		catAttributes.setInitialValue(object.getInitialValue());
		catAttributes.setMax(object.getMax());
		catAttributes.setMaxDimension(object.getMaxDimension());
		catAttributes.setMin(object.getMin());
		catAttributes.setOffset(object.getOffset());
		catAttributes.setOldName(object.getOldName());
		catAttributes.setMemorySection(object.getMemorySection());
		catAttributes.setSampleTime(object.getSampleTime());
//		catAttributes.setSamplingMode(object.getSamplingMode());
		catAttributes.setSlope(object.getSlope());
		catAttributes.setSwCalAccess(object.getSwCalAccess());
		catAttributes.setUnit(object.getUnit());
		catAttributes.setValue(object.getValue());
		catAttributes.setStructureElementName(object.getStructureElementName());
			//editor.selectedOutputDataObject = "";
	//	}

			existCatList.add(newRowIndex, catAttributes);

		createNatTable.setCategoryList(existCatList);

		//Display natTable with newly added row

		//createNatTable.filterList.add(categoryAttributes);
		natTable.refresh();

		//If rowIndex is greater than -1
		/*if(newRowIndex > -1)
		{
			newlyAddedRowLists.add(newRowIndex);
		}	*/	
		NatTableEditConfiguration.maxColumnCount = 0;
		NatTableEditConfiguration.minColumnCount = 0;
		NatTableEditConfiguration.nameColumnCount = 0;

	}

}
