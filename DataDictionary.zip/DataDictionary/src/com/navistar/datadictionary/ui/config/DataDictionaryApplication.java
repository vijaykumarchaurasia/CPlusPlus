package com.navistar.datadictionary.ui.config;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.eclipse.equinox.app.IApplicationContext;

import com.google.gson.JsonElement;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.model.FontStyleDAO;
import com.navistar.datadictionary.model.Node;
import com.navistar.datadictionary.model.Project;

/**
 * Class is used to store data 
 * @author vijayk13
 *
 */
public class DataDictionaryApplication extends Application{

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(DataDictionaryApplication.class);

	/** DataDictionaryApplication instance*/
	private static DataDictionaryApplication application = null;

	/** Open component list*/
	private Map<String,List<CategoryAttributes>> componentMapList;
	
	/** Inconsistent list*/
	private Map<String,List<CategoryAttributes>> inconsistentMap;	
	
	/** Searched data list*/
	private List<CategoryAttributes> searchedDataList;
	
	/** Search Button Flag  */
	private boolean searchFlag;
	
	/** Component inputs window flag*/
	private boolean checkCompIpStatus;
	
	/** Searched Highlighted Object */
	private CategoryAttributes objHighighted;
	
	/** Search High Light Flag */
	private boolean searchedHighLight;	
	
	/** Used to store the project status */
	public  Map<String, Project> projStatusMap = new LinkedHashMap<String, Project>();	

	/** Used to store the recently project list */
	public  Map<String, String> recentImpProjMap = new LinkedHashMap<String, String>();

	private JsonElement outputSignalJson;
	
	//public static String userName = System.getProperty("user.name");
	public static String unitFileName = "";
	/** Used to store the font style */
	public FontStyleDAO fontStyle = new FontStyleDAO(); 
	
	public static Map<String, Node> projNodeMap = new LinkedHashMap<>();
	
	/** Check the search highlight flag */
	public boolean isSearchedHighLight() {
		return searchedHighLight;
	}

	/** Set the search highlight flag */
	public void setSearchedHighLight(boolean searchedHighLight) {
		this.searchedHighLight = searchedHighLight;
	}
	
	/** Get the searched highlighted object*/
	public CategoryAttributes getSearchedHighlighted() {
		return objHighighted;
	}

	/** Set the searched highlighted object */
	public void setSearchedHighlighted(CategoryAttributes objHighlighted) {
		this.objHighighted = objHighlighted;
	}
	
	/**
	 * Method to check if data exists in component inputs window
	 * @return
	 */
	public boolean isCheckCompIpStatus() {
		return checkCompIpStatus;
	}
	
	/**
	 * Method to set the flag if data exists in component inputs window
	 * @param checkCompIpStatus
	 */
	public void setCheckCompIpStatus(boolean checkCompIpStatus) {
		this.checkCompIpStatus = checkCompIpStatus;
	}
	
	/** Check the Flag */
	public boolean isSearchFlag() {
		return searchFlag;
	}
	
	/** Set search flag */
	public void setSearchFlag(boolean searchFlag) {
		this.searchFlag = searchFlag;
	}

	/**
	 * This method is used to get inconsistent map list
	 * @return
	 */
	public Map<String, List<CategoryAttributes>> getInconsistentMapList() {
		return inconsistentMap;
	}

	/**
	 * This method is used to set inconsistent map list
	 * @param inconsistentMapList
	 */
	public void setInconsistentMapList(Map<String, List<CategoryAttributes>> inconsistentMap) {
		this.inconsistentMap = inconsistentMap;
	}

	/**
	 * Constructor
	 */
	private DataDictionaryApplication() {
		application = this;
		componentMapList = new HashMap<String,List<CategoryAttributes>>();
	}

	/**
	 * This method is used to get instance of DataDictionaryApplication
	 * @return
	 */
	public static DataDictionaryApplication getApplication() {
		if (application == null) {
			application = new DataDictionaryApplication();}
		return application;
	}

	/**
	 * This method is used to start the Data Dictionary application
	 */
	@Override
	public Object start(IApplicationContext context) throws Exception {
		LOGGER.info("Application started");
		return super.start(context);
	}

	/**
	 * This method is used to get open component data
	 * @return
	 */
	public Map<String, List<CategoryAttributes>> getComponentMapList() {
		return componentMapList;
	}

	/**
	 * This method is used to set open component data
	 * @param componentMapList
	 */
	public void setComponentMapList(Map<String, List<CategoryAttributes>> componentMapList) {
		this.componentMapList = componentMapList;
	}

	/**
	 * This method is used to set searched data list
	 * @return
	 */
	public List<CategoryAttributes> getSearchedDataList() {
		return searchedDataList;
	}

	/**
	 * This method is used to get searched data list
	 * @param searchedDataList
	 */
	public void setSearchedDataList(List<CategoryAttributes> searchedDataList) {
		this.searchedDataList = searchedDataList;
	}
	
	public JsonElement getOutputSignalJson() {
		return outputSignalJson;
	}

	public void setOutputSignalJson(JsonElement outputSignalJson) {
		this.outputSignalJson = outputSignalJson;
	}
	

}
