package com.navistar.datadictionary.ui.config;

import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;

import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.serviceimpl.WorkspaceServiceImpl;


/**
 * The activator class controls the plug-in life cycle
 * @author nikitak1
 */
public class Activator extends AbstractUIPlugin {

	/** The plug-in ID */
	public static final String PLUGIN_ID = ApplicationConstant.PLUGIN_ID; 

	/** The shared instance */
	private static Activator plugin;
	
	/**
	 * The constructor
	 */
	public Activator() {
	}

	/**
	 * This method is used to start the plug-in
	 * @param context
	 */
	public void start(BundleContext context) throws Exception {
		super.start(context);
		plugin = this;
	}

	/**
	 * This method is used to stop the plug-in
	 * @param context
	 */
	public void stop(BundleContext context) throws Exception {
		plugin = null;
		//Workspace path of application
		String resourcePath = ResourcesPlugin.getWorkspace().getRoot().getLocation().toString();
		WorkspaceServiceImpl workspaceObject = new WorkspaceServiceImpl();
		workspaceObject.saveWorkspaceHistory(resourcePath+"/workspace.json");
		super.stop(context);
	}

	/**
	 * Returns the shared instance
	 *
	 * @return the shared instance
	 */
	public static Activator getDefault() {
		return plugin;
	}

	/**
	 * Returns an image descriptor for the image file at the given
	 * plug-in relative path
	 *
	 * @param path the path
	 * @return the image descriptor
	 */
	public static ImageDescriptor getImageDescriptor(String path) {
		return imageDescriptorFromPlugin(PLUGIN_ID, path);
	}
}
