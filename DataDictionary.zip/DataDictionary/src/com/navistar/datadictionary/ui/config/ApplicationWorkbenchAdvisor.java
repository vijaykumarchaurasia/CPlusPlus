package com.navistar.datadictionary.ui.config;

import org.eclipse.ui.application.IWorkbenchWindowConfigurer;
import org.eclipse.ui.application.WorkbenchAdvisor;
import org.eclipse.ui.application.WorkbenchWindowAdvisor;

import com.navistar.datadictionary.constant.ApplicationConstant;

/**
 * This is used to to configure the workbench to suit the needs of the
 * application
 * 
 * @author nikitak1
 *
 */
public class ApplicationWorkbenchAdvisor extends WorkbenchAdvisor {

	/** Perspective id */
	private static final String PERSPECTIVE_ID = ApplicationConstant.PERSPECTIVE_ID;

	/**
	 * Creates a new workbench window advisor for configuring a new workbench window
	 * via the given workbench window configurer.
	 *
	 * @param configurer
	 *            the workbench window configurer
	 * @return a new workbench window advisor
	 */
	@Override
	public WorkbenchWindowAdvisor createWorkbenchWindowAdvisor(IWorkbenchWindowConfigurer configurer) {
		return new ApplicationWorkbenchWindowAdvisor(configurer);
	}

	/**
	 * This method is called during startup when the workbench is creating the first
	 * new window to return the id of the perspective
	 *
	 * @return the id of the perspective for the initial window, or null if no
	 *         initial perspective should be shown
	 */
	@Override
	public String getInitialWindowPerspectiveId() {
		return PERSPECTIVE_ID;
	}

	
}
