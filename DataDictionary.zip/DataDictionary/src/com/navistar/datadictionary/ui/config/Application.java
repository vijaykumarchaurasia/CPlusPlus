package com.navistar.datadictionary.ui.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.eclipse.equinox.app.IApplication;
import org.eclipse.equinox.app.IApplicationContext;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.PlatformUI;

import com.google.gson.JsonElement;

/**
 * This class controls all aspects of the application's execution
 * 
 * @author nikitak1
 *
 */
public class Application implements IApplication {

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(Application.class);
	
	/** IO Compatibility JSON data for cache*/
	public static JsonElement ioJsonElement = null;
	
	/** Check Component Inputs JSON data for cache*/
	public static JsonElement compIpJsonElement = null;
	
	/** IO Compatibility error message*/
	public static String ioCompatErrMsg = "";

	/** Hierarchical view JSON data for cache*/
	public static JsonElement hierarchiJsnEle = null;
	
	/** All output signal JSON data for cache*/
	public static JsonElement allOutputSignal = null;
	
	/** Inconsistent attributes excel and sldd JSON data for cache*/
	public static JsonElement inconAttrJson = null;
	
	/** Units symbol list data for a project to cache */
	public static JsonElement unitsJson = null;

	/** Project configured data excel file path from Navistar MBD toolbox to cache */
	public static String projConfigPath;
	
	/** Project config file Category list */
	public static List<String> configCatList;
	
	/** Category and column configured map */
	public static Map<String, List<Integer>> catColumnMap = new HashMap<String, List<Integer>>();

	/** Category and column Attribute configured map */
	public static Map<String, List<String>> catColumnAttributeMap = new HashMap<String, List<String>>();
	
	public static JsonElement pathJson;

	public static String programName=null;
	

	public static String compName;
	
	/** Keep count for open component using context menu and doubleclick 
	   *If count is -1 open component executing directly
	   *if count is 0  open component is executing via update component parameter type*/
	public static int count;

	public static boolean displayExceptionPopup;
	
	public static List<String> valueCatList = new ArrayList<>();
	
	public static List<String> iniValCatList = new ArrayList<>();
	
	/**
	 * This method is used to start the Data Dictionary application
	 */
	@Override
	public Object start(IApplicationContext context) throws Exception {

		Display display = PlatformUI.createDisplay();
		try {
			LOGGER.info("Application started");
			int returnCode = PlatformUI.createAndRunWorkbench(display, new ApplicationWorkbenchAdvisor());			
			if (returnCode == PlatformUI.RETURN_RESTART) {
				return IApplication.EXIT_RESTART;
			} else {
				return IApplication.EXIT_OK;
			}			
			
		} finally {
			display.dispose();
		}

	}

	/**
	 * This method is used to stop the Data Dictionary application
	 */
	@Override
	public void stop() {
		if (!PlatformUI.isWorkbenchRunning()) {
			return;
		}
		final IWorkbench workbench = PlatformUI.getWorkbench();
		final Display display = workbench.getDisplay();
		display.syncExec(new Runnable() {
			public void run() {
				if (!display.isDisposed()) {
					workbench.close();
					LOGGER.info("Application closed");
				}
			}
		});
	}
	
}
