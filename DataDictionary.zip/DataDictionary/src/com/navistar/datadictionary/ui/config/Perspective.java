package com.navistar.datadictionary.ui.config;

import org.eclipse.ui.IFolderLayout;
import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.PlatformUI;

import com.navistar.datadictionary.action.HierarchicalViewAction;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.ui.views.ProjectExplorerView;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * This class is used to set the perspective of the application
 * @author nikitak1
 *
 */

public class Perspective implements IPerspectiveFactory {
	
	/**
	 * Creates the initial layout for a page. 
	 * @param layout
	 */
	@Override
	public void createInitialLayout(final IPageLayout layout) {
		displayLayout(layout);
	}
	
	/**
	 * Display the layout for a page
	 */
	private void displayLayout(final IPageLayout layout)
	{
		final String editorArea = layout.getEditorArea();
		layout.setEditorAreaVisible(true);

		//Condition to maintain project explorer state
		if(!ApplicationActionBarAdvisor.getInstance().projExplorerObj.isChecked())
		{

			ApplicationActionBarAdvisor.getInstance().projExplorerObj.setChecked(true);
			HierarchicalViewAction hierarchyView = new HierarchicalViewAction();
			if(ProjectExplorerView.hierarchialView) {
				hierarchyView.performHierarchicalAction();
			}
			ProjectExplorerView.getInstance().alphabeticalObj.setEnabled(true);
			ProjectExplorerView.getInstance().hierarchiViewObj.setEnabled(true);
		}
		
		if(!ApplicationActionBarAdvisor.getInstance().activityLogAction.isChecked()) {
			ApplicationActionBarAdvisor.getInstance().activityLogAction.setChecked(true);
		}

		layout.addStandaloneView(ViewIDConstant.PROJ_EXPLORER,  true, IPageLayout.LEFT, 0.22f, editorArea);
		final IFolderLayout bottomViewFolder = layout.createFolder(ApplicationConstant.MESSAGES, IPageLayout.BOTTOM, 0.5f, editorArea);
		bottomViewFolder.addView(ViewIDConstant.ACTIVITY_LOG);
		if(ViewUtil.isViewOpen(ViewIDConstant.TABLE_EDITOR)) {
		bottomViewFolder.addView(ViewIDConstant.TABLE_EDITOR);
		}

		//Condition to maintain IOCompatibility state
		if(ApplicationActionBarAdvisor.getInstance().ioCompatWinAction.isChecked())
		{
			bottomViewFolder.addView(ViewIDConstant.CHECK_IO_COMPAT);
		}

		//Condition to maintain Search View State
		if(ApplicationActionBarAdvisor.getInstance().searchWindowObj.isChecked())
		{
			bottomViewFolder.addView(ViewIDConstant.SEARCH_RESULT);
		}
		
		//Condition to maintain Component Inputs view
		IViewPart componentIPView = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().findView(ViewIDConstant.COMP_INPUTS);
		if(componentIPView != null){
			bottomViewFolder.addView(ViewIDConstant.COMP_INPUTS);
		}
	}
}

