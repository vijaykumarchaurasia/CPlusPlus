package com.navistar.datadictionary.ui.config;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IPartListener;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.application.ActionBarAdvisor;
import org.eclipse.ui.application.IActionBarConfigurer;
import org.eclipse.ui.application.IWorkbenchWindowConfigurer;
import org.eclipse.ui.application.WorkbenchWindowAdvisor;

import com.navistar.datadictionary.action.ImportProjectAction;
import com.navistar.datadictionary.action.OpenProjectAction;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.customexception.EditorInitilizationException;
import com.navistar.datadictionary.customexception.EditorReuseException;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.model.Project;
import com.navistar.datadictionary.serviceimpl.EditorServiceImpl;
import com.navistar.datadictionary.serviceimpl.OpenComponentServiceImpl;
import com.navistar.datadictionary.serviceimpl.WorkspaceServiceImpl;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.ui.editors.WelcomeNoteEditor;
import com.navistar.datadictionary.ui.editors.WelcomeNoteEditorInput;
import com.navistar.datadictionary.ui.views.ProjectExplorerView;
import com.navistar.datadictionary.ui.views.TableEditiorView;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * This is used to to configure the workbench windows to suit the needs of the
 * application.
 * 
 * @author nikitak1
 *
 */
public class ApplicationWorkbenchWindowAdvisor extends WorkbenchWindowAdvisor {

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(ApplicationWorkbenchWindowAdvisor.class);

	/** Instance to configure workbench window */
	public static IWorkbenchWindowConfigurer configurer;

	/** variable to usec to get project list from workspace.json */
	List<Project> projectList = new ArrayList<>();

	/** variable used to get the recently imported projects */
	public static String recentlyImpProj;
	
	public static boolean partFlag = true;

	/**
	 * Creates a new workbench window advisor for configuring a workbench window via
	 * the given workbench window configurer.
	 *
	 * @param configurer
	 *            an object for configuring the workbench window
	 */
	public ApplicationWorkbenchWindowAdvisor(IWorkbenchWindowConfigurer configurer) {
		super(configurer);
	}

	/**
	 * Creates a new action bar advisor to configure the action bars of the window
	 * via the given action bar configurer.
	 *
	 * @param configurer
	 *            the action bar configurer for the window
	 * @return the action bar advisor for the window
	 */
	public ActionBarAdvisor createActionBarAdvisor(IActionBarConfigurer configurer) {
		return new ApplicationActionBarAdvisor(configurer);
	}

	/**
	 * This method is called before the window's controls have been created to
	 * configure aspects of the window other than actions bars.
	 */
	public void preWindowOpen() {
		configurer = getWindowConfigurer();
		configurer.setInitialSize(new Point(400, 300));
		configurer.setShowCoolBar(true);
		configurer.setShowStatusLine(true);
		configurer.setShowPerspectiveBar(false);
		configurer.setTitle(ApplicationConstant.APPLICATION_NAME);

		String resourcePath = ResourcesPlugin.getWorkspace().getRoot().getLocation().toString();
		WorkspaceServiceImpl workspaceObject = new WorkspaceServiceImpl();
		projectList = workspaceObject.getWorkspaceHistory(resourcePath + "/workspace.json");
	}

	/**
	 * This method is called after the window has been created from scratch, or when
	 * it has been restored from a previously-saved window to adjust the restored
	 * window.
	 */
	@Override
	public void postWindowOpen() {
		//Create matlab instance at the time of application launching
		/*try {
			@SuppressWarnings("unused")
			MatlabEngine matlabEngine = new MatlabEngineConnectionDaoImpl().getMatlabEngineInstance();
		} catch (MatlabCommunicatinException e) {
			MessageDialog.openConfirm(new Shell(), "Error Message", e.getMessage());
		}*/

		//Maximized the application window
		getWindowConfigurer().getWindow().getShell().setMaximized(true);
		

		//Get active page
		IWorkbenchPage page = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();

		try {
			page.showView(ViewIDConstant.PROJ_EXPLORER);
			ImportProjectAction importProjAction = new ImportProjectAction();
			TreeViewer viewer = null;
			// Open component path
			String componentPath = "";
			// Load imported project in workspace
			if (!projectList.isEmpty()) {
				for (Project project : projectList) {
					if(project.getStatus()!=ApplicationConstant.REMOVEPROJSTATUS)
					{
						Object objArr[] = importProjAction.createImportProjectStructure(project.getPath(), project.getStatus(),
								project.getComponentPath());
						boolean checkImpProjErr = (boolean) objArr[0];
						viewer = (TreeViewer) objArr[1];
						//open component only if there is no error while importing project
						if(!checkImpProjErr) {
							//Set open component path 
							if(project.getComponentPath()!= null && (!(project.getComponentPath().equals(""))))
							{
								componentPath = project.getComponentPath();						
							}
							importProjAction.loadProjectStatusFromWorkspace(viewer, ImportProjectAction.nodes);
						}
					}
					if(project.getStatus()==ApplicationConstant.OPEN_PROJ_STATUS) {
						String projectPath  =  project.getPath().replace("\\", "/");
						OpenProjectAction.openProjectName = FilenameUtils.getBaseName(projectPath);
						//Project project = ProjectExplorerView.getActiveProject();
						//String prjpath=project.getPath().replace("\\", "/");
						Application.programName= new EditorServiceImpl().getConfigProjDataFrMatlab(projectPath);
						if(Application.programName == null) {
							MessageDialog.openError(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), "Error", "Program name not present in sldd file");
							PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell().setText("Data Dictionary");
							return;
						}else if(Application.programName.equals("1003")) {
							MessageDialog.openError(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), "Error", "Program name not present in sldd file");
							PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell().setText("Data Dictionary");
							return;
						}else if(Application.programName.equals("1004")) {
							MessageDialog.openError(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), "Error", "More than one program names found in sldd file");
							PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell().setText("Data Dictionary");
							return;
						}
						ViewUtil.disableIOFeatures();
						PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell().setText("Data Dictionary : Currently selected project is - "+Application.programName);
						ProjectExplorerView.getInstance().hierarchiViewObj.setEnabled(true);
						ApplicationActionBarAdvisor.getInstance().closeProjAction.setEnabled(true);
						ApplicationActionBarAdvisor.getInstance().searchAction.setEnabled(true);
						ApplicationActionBarAdvisor.getInstance().validProjAction.setEnabled(true);
					
					}
					
				}
				

			}
			WelcomeNoteEditorInput welcomeNoteObj = new WelcomeNoteEditorInput();
			page.openEditor(welcomeNoteObj, WelcomeNoteEditor.WELCOME_NOTE_EDIT); // the id in your plugin.xml of your editor

			ViewUtil.closeView(ViewIDConstant.TABLE_EDITOR);
			ViewUtil.closeView(ViewIDConstant.MIN_MAX_INFO);
			
			boolean flag = ApplicationActionBarAdvisor.getInstance().activityLogAction.isChecked();
			ViewUtil.showHideView(ViewIDConstant.ACTIVITY_LOG,flag);
					
			//Open component's categories
			if (!(componentPath.equals(""))) {
				displayCategories(componentPath, viewer);
				ApplicationActionBarAdvisor.getInstance().filterAction.setImageDescriptor(Activator.getImageDescriptor("/icons/filter.png"));
				ApplicationActionBarAdvisor.getInstance().filterAction.setEnabled(true);
			}

			// IPartListener for workbench part events
			PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().addPartListener(new IPartListener() {

				@Override
				public void partOpened(IWorkbenchPart part) {
					//Nothing to clean-up
					
				}

				@Override
				public void partDeactivated(IWorkbenchPart part) {
					//Nothing to clean-up
				}

				@Override
				public void partClosed(IWorkbenchPart part) {
					//Nothing to clean-up
				}

				@Override
				public void partBroughtToTop(IWorkbenchPart part) {
				// partBroughtToTop
				}

				@Override
				public void partActivated(IWorkbenchPart part) {	
					 
					if(part instanceof CategoryEditor){
						CategoryEditor categoryEditor = (CategoryEditor) part;
					 
						if(!categoryEditor.getTitle().equals(TableEditiorView.category)){
							ViewUtil.closeView(ViewIDConstant.TABLE_EDITOR);
						}
						if(categoryEditor.createNatTable.filterRowHLayer.isFilterRowVisible())
						{
							ApplicationActionBarAdvisor.getInstance().filterAction.setImageDescriptor(Activator.getImageDescriptor("/icons/clear-filter.png"));
							ApplicationActionBarAdvisor.getInstance().filterAction.setToolTipText("Clear Filter");
						}
						else
						{
							ApplicationActionBarAdvisor.getInstance().filterAction.setImageDescriptor(Activator.getImageDescriptor("/icons/filter.png"));
							ApplicationActionBarAdvisor.getInstance().filterAction.setToolTipText(ApplicationConstant.FILTER);
						}
						//make undo/redo enable/disable according to category
						if(categoryEditor.undoEditStack.size()>0){
							ApplicationActionBarAdvisor.getInstance().undoAction.setEnabled(true);
						}else{
							ApplicationActionBarAdvisor.getInstance().undoAction.setEnabled(false);
						}
						if(categoryEditor.redoEditorStack.size()>0)
						{
							ApplicationActionBarAdvisor.getInstance().redoAction.setEnabled(true);
						}else{
							ApplicationActionBarAdvisor.getInstance().redoAction.setEnabled(false);
						}
					}			
				}

			});
		} catch (PartInitException pe) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, pe);
			MessageDialog.openConfirm(new Shell(), "Error Message", "Editor Initilization Error(Launch)");
		} catch (MatlabCommunicatinException e) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			
		}
	}

	/**
	 * This method is used to display categories of opened component.
	 * @param componentPath
	 * @param viewer
	 */
	public void displayCategories(String componentPath, TreeViewer viewer) {
		EditorServiceImpl editorService = new EditorServiceImpl();
		try {
			OpenComponentServiceImpl.selCompName = componentPath;
			OpenProjectAction.openProjectFlag = false;
			
			editorService.displayComponentCategories(componentPath, viewer);
		
		} catch (FileNotFoundException e) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			MessageDialog.openConfirm(new Shell(), "Error Message", e.getMessage());
			
		} catch (MatlabCommunicatinException e) {
			MessageDialog.openConfirm(new Shell(), "Error Message", e.getMessage());
		} catch (EditorReuseException e) {
			MessageDialog.openConfirm(new Shell(), "Error Message", e.getMessage());
		} catch (EditorInitilizationException e) {
			MessageDialog.openConfirm(new Shell(), "Error Message", e.getMessage());
		}
	}

	/**
	 * Method get called before closing application window
	 */
	@Override
	public boolean preWindowShellClose() {
		boolean result = false;
		result = MessageDialog.openConfirm(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), "Confirm", "Are you sure, you want to exit the application?");
		if(result) {
			ViewUtil.closeView(ViewIDConstant.COMP_INPUTS);
			ViewUtil.closeView(ViewIDConstant.CHECK_IO_COMPAT);
			ViewUtil.closeView(ViewIDConstant.SEARCH_RESULT);
			ViewUtil.closeView(ViewIDConstant.OUTPUT_DATA_OBJ);
		} 
		return result;
	}
}