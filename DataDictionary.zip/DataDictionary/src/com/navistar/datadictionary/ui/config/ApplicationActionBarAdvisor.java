package com.navistar.datadictionary.ui.config;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.ICoolBarManager;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.action.ToolBarManager;
import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.jface.util.PropertyChangeEvent;
import org.eclipse.swt.SWT;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.ActionFactory;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;
import org.eclipse.ui.application.ActionBarAdvisor;
import org.eclipse.ui.application.IActionBarConfigurer;

import com.navistar.datadictionary.action.ActivityLogAction;
import com.navistar.datadictionary.action.ClearListAction;
import com.navistar.datadictionary.action.CloseProjectAction;
import com.navistar.datadictionary.action.CopyAction;
import com.navistar.datadictionary.action.CutAction;
import com.navistar.datadictionary.action.DataDictionaryAbout;
import com.navistar.datadictionary.action.DataObjectWindowAction;
import com.navistar.datadictionary.action.DeleteDataObjectAction;
import com.navistar.datadictionary.action.ExcelImportExportAction;
import com.navistar.datadictionary.action.FilterAction;
import com.navistar.datadictionary.action.HelpSearchAction;
import com.navistar.datadictionary.action.IOCompatibilityAction;
import com.navistar.datadictionary.action.IOCompatibilityWindowAction;
import com.navistar.datadictionary.action.IOInconsistency;
import com.navistar.datadictionary.action.ImportProjectAction;
import com.navistar.datadictionary.action.ImportRecentlyImportedProjectAction;
import com.navistar.datadictionary.action.MinMaxInfoAction;
import com.navistar.datadictionary.action.PasteAction;
import com.navistar.datadictionary.action.ProjectExplorerAction;
import com.navistar.datadictionary.action.RedoAction;
import com.navistar.datadictionary.action.SaveAction;
import com.navistar.datadictionary.action.SaveAllAction;
import com.navistar.datadictionary.action.SearchAction;
import com.navistar.datadictionary.action.SearchWindowAction;
import com.navistar.datadictionary.action.TableEditorAction;
import com.navistar.datadictionary.action.UndoAction;
import com.navistar.datadictionary.action.UpdateProjParaTypeAction;
import com.navistar.datadictionary.action.ValidateProjAction;
import com.navistar.datadictionary.action.WelcomeNoteCustomAction;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.ui.editors.WelcomeNoteEditor;
import com.navistar.datadictionary.ui.editors.WelcomeNoteEditorInput;
import com.navistar.datadictionary.ui.views.DataObjectView;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * This class is responsible for creating, adding, and disposing of the actions
 * added to a workbench window. Each window will be populated with new actions.
 * 
 * @author nikitak1
 *
 */
public class ApplicationActionBarAdvisor extends ActionBarAdvisor implements IPropertyChangeListener {

	/** The instance of this application action bar advisor */
	private static ApplicationActionBarAdvisor actionBarInst;
	/** Save action of workbench */
	public IWorkbenchAction saveAction;
	/** Exit action of workbench */
	private IWorkbenchAction exitAction;
	/** Import action of workbench */
	private IWorkbenchAction importAction;
	/** Help search action of workbench */
	private IWorkbenchAction helpSearchAction;
	/** Save All action of workbench */
	public IWorkbenchAction saveAllAction;
	/** Undo action of workbench */
	public IWorkbenchAction undoAction;
	/** Redo action of workbench */
	public IWorkbenchAction redoAction;
	/** Cut action of workbench */
	public IWorkbenchAction cutAction;
	/** Copy action of workbench */
	public IWorkbenchAction copyAction;
	/** Paste action of workbench */
	public IWorkbenchAction pasteAction;
	/** Delete action of workbench */
	public IWorkbenchAction deleteAction;
	
	/** Close action of workbench */
	public IWorkbenchAction closeProjAction;
	/** resolve io consistency action of workbench */
	public IOInconsistency resolvInconObj;
	/** Filter action of workbench */
	public FilterAction filterAction;
	/** io compatibility action of menu item of workbench */
	public IOCompatibilityAction ioCompatAction;
	/** io compatibility action of view of workbench */
	public IOCompatibilityWindowAction ioCompatWinAction;
	/** Welcome note action of workbench */
	public WelcomeNoteCustomAction welcomeNoteAction;
	/** Project explorer action of workbench */
	public ProjectExplorerAction projExplorerObj;
	/** Data object window action of workbench */
	public DataObjectWindowAction dataObjWindowObj;
	/** Import action of workbench */
	public ActivityLogAction activityLogAction;
	/** Table editor action of workbench */
	public TableEditorAction tableEditorAction;
	/** Table editor action of workbench */
	public MinMaxInfoAction minMaxInfoAction;
	/** Search action of workbench */
	public SearchAction searchAction;
	/** Search window action of workbench */
	public SearchWindowAction searchWindowObj;
	/** Reset perspective action of workbench */
	public IWorkbenchAction resetPersObj;
	/** preferences Action of workbench */
	public IWorkbenchAction preferencesAction;
	/** Data Dictionary About of workbench */
	private IWorkbenchAction dataDictAbout;
	
	public ExcelImportExportAction excelImportExport;

	/** To get the check IO action */
	public Action action;
	
	/** menu for recently imported project list */
	public static MenuManager recentimportMenu;
	
	/** recently imported project path list */
	public static List<String> pathList = new ArrayList<>();
	
	
	/** check component inputs action*/
	//public CheckComponentInputsAction checkComInAction;
	
	public ValidateProjAction validProjAction;
	
	public UpdateProjParaTypeAction updateProjParaTypeAction ;
	
	private IWorkbenchAction introAction;
	
	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(ApplicationActionBarAdvisor.class);
	
	public ApplicationActionBarAdvisor(IActionBarConfigurer configurer) {
		super(configurer);
		actionBarInst = this;
	}

	/**
	 * @return The instance of this class, or null.
	 */
	public static ApplicationActionBarAdvisor getInstance() {
		return actionBarInst;
	}

	/**
	 * Creates the actions and registers them. Registering is needed to ensure that
	 * key bindings work. The corresponding commands key bindings are defined in the
	 * plugin.xml file. Registering also provides automatic disposal of the actions
	 * when the window is closed.
	 * 
	 * @param window
	 */
	@Override
	protected void makeActions(IWorkbenchWindow window) {

		introAction = ActionFactory.INTRO.create(window);
		introAction.setText("About Data Dictionary");
		register(introAction);
		
		saveAction = new SaveAction();
		saveAction.setText(ApplicationConstant.SAVE);
		saveAction.setToolTipText(ApplicationConstant.SAVE);
		saveAction.setImageDescriptor(Activator.getImageDescriptor("/icons/save.png"));
		saveAction.setDisabledImageDescriptor(Activator.getImageDescriptor("/icons/save-disable.png"));
		saveAction.setAccelerator(SWT.CTRL + 'S');
		saveAction.setEnabled(false);
		
		this.register(saveAction);
		
		importAction = new ImportProjectAction();
		importAction.setText(ApplicationConstant.IMPORT_PROJECT);
		importAction.setToolTipText(ApplicationConstant.IMPORT_PROJECT);
		importAction.setImageDescriptor(Activator.getImageDescriptor("/icons/import.png"));
		importAction.setDisabledImageDescriptor(Activator.getImageDescriptor("/icons/import-disable.png"));
		importAction.setAccelerator(SWT.CTRL + 'I');
		this.register(importAction);

		closeProjAction = new CloseProjectAction();
		closeProjAction.setText("Close Project");
		closeProjAction.setToolTipText("Close Project");
		this.register(closeProjAction);
		closeProjAction.setEnabled(false);

		saveAllAction = new SaveAllAction();
		saveAllAction.setText(ApplicationConstant.SAVE_ALL);
		saveAllAction.setToolTipText(ApplicationConstant.SAVE_ALL);
		saveAllAction.setImageDescriptor(Activator.getImageDescriptor("/icons/saveall.png"));
		saveAllAction.setDisabledImageDescriptor(Activator.getImageDescriptor("/icons/saveall-disable.png"));
		saveAllAction.setAccelerator(SWT.CTRL + SWT.SHIFT + 'S');
		saveAllAction.setEnabled(false);
		
		this.register(saveAllAction);
		

		undoAction = new UndoAction();
		undoAction.setText(ApplicationConstant.UNDO);
		undoAction.setToolTipText(ApplicationConstant.UNDO);
		undoAction.setImageDescriptor(Activator.getImageDescriptor("/icons/undo.png"));
		undoAction.setDisabledImageDescriptor(Activator.getImageDescriptor("/icons/undo-disable.png"));
		undoAction.setEnabled(false);
		this.register(undoAction);
		
		
		redoAction = new RedoAction();
		redoAction.setText(ApplicationConstant.REDO);
		redoAction.setToolTipText(ApplicationConstant.REDO);
		redoAction.setImageDescriptor(Activator.getImageDescriptor("/icons/redo.png"));
		redoAction.setDisabledImageDescriptor(Activator.getImageDescriptor("/icons/redo-disable.png"));
		redoAction.setEnabled(false);
		this.register(redoAction);
		
		
		cutAction = new CutAction();
		cutAction.setText(ApplicationConstant.CUT_SHORTCUT);
		cutAction.setToolTipText(ApplicationConstant.CUT_SHORTCUT);
		cutAction.setEnabled(false);
		cutAction.setImageDescriptor(Activator.getImageDescriptor("/icons/cut.png"));
		cutAction.setDisabledImageDescriptor(Activator.getImageDescriptor("/icons/cut-disable.png"));		
		this.register(cutAction);
		
		copyAction = new CopyAction();
		copyAction.setText(ApplicationConstant.COPY_SHORTCUT);
		copyAction.setToolTipText(ApplicationConstant.COPY_SHORTCUT);
		copyAction.setEnabled(false);
		copyAction.setImageDescriptor(Activator.getImageDescriptor("/icons/copy.png"));
		copyAction.setDisabledImageDescriptor(Activator.getImageDescriptor("/icons/copy-disable.png"));
		this.register(copyAction);
		
		pasteAction = new PasteAction();
		pasteAction.setText(ApplicationConstant.PASTE_SHORTCUT);
		pasteAction.setToolTipText(ApplicationConstant.PASTE_SHORTCUT);
		pasteAction.setEnabled(false);
		pasteAction.setImageDescriptor(Activator.getImageDescriptor("/icons/paste.png"));
		pasteAction.setDisabledImageDescriptor(Activator.getImageDescriptor("/icons/paste-disable.png"));
		this.register(pasteAction);
		
		deleteAction = new DeleteDataObjectAction();
		deleteAction.setText((ApplicationConstant.DELETE));
		deleteAction.setImageDescriptor(Activator.getImageDescriptor("/icons/delete.png"));
		deleteAction.setDisabledImageDescriptor(Activator.getImageDescriptor("/icons/delete-disable.png"));
		deleteAction.setEnabled(false);
		this.register(deleteAction);
		
		searchAction = new SearchAction();
		searchAction.setText(ApplicationConstant.CHECK_SEARCH);
		searchAction.setToolTipText(ApplicationConstant.CHECK_SEARCH);
		searchAction.setImageDescriptor(Activator.getImageDescriptor("/icons/search.png"));
		searchAction.setDisabledImageDescriptor(Activator.getImageDescriptor("/icons/search-disable.png"));
		searchAction.setId(ViewIDConstant.SEARCH_RESULT);
		this.register(searchAction);
		searchAction.setEnabled(false);
		
		searchWindowObj = new SearchWindowAction();
		searchWindowObj.setText(ApplicationConstant.SEARCH_RESULTS);
		searchWindowObj.setToolTipText(ApplicationConstant.SEARCH_RESULTS);
		searchWindowObj.setChecked(false);
		searchWindowObj.setId(ViewIDConstant.SEARCH_RESULT);
		this.register(searchWindowObj);
		searchWindowObj.addPropertyChangeListener(this);
		
		ioCompatAction = new IOCompatibilityAction();
		ioCompatAction.setText(ApplicationConstant.CHECK_IOCOMPAT);
		ioCompatAction.setToolTipText(ApplicationConstant.CHECK_IOCOMPAT);
		ioCompatAction.setImageDescriptor(Activator.getImageDescriptor("/icons/IO.png"));
		ioCompatAction.setDisabledImageDescriptor(Activator.getImageDescriptor("/icons/IO-disable.png"));
		ioCompatAction.setId(ViewIDConstant.CHECK_IO_COMPAT);
		this.register(ioCompatAction);
		ioCompatAction.setEnabled(false);
		

		ioCompatWinAction = new IOCompatibilityWindowAction();
		ioCompatWinAction.setText(ApplicationConstant.IO_COMPATIBILITY);
		ioCompatWinAction.setToolTipText(ApplicationConstant.IO_COMPATIBILITY);
		ioCompatWinAction.setChecked(false);
		ioCompatWinAction.setId(ViewIDConstant.CHECK_IO_COMPAT);
		this.register(ioCompatWinAction);
		ioCompatWinAction.addPropertyChangeListener(this);

		welcomeNoteAction = new WelcomeNoteCustomAction();
		welcomeNoteAction.setText("Welcome Note");
		welcomeNoteAction.setToolTipText("Welcome Note");
		welcomeNoteAction.setChecked(true);
		welcomeNoteAction.setId(ApplicationConstant.WELCOMENOTEEDITID);
		this.register(welcomeNoteAction);
		welcomeNoteAction.addPropertyChangeListener(this);

		projExplorerObj = new ProjectExplorerAction();
		projExplorerObj.setText("Project Explorer");
		projExplorerObj.setToolTipText("Project Explorer");
		projExplorerObj.setChecked(true);
		projExplorerObj.setId(ViewIDConstant.PROJ_EXPLORER);
		this.register(projExplorerObj);
		projExplorerObj.addPropertyChangeListener(this);

		dataObjWindowObj = new DataObjectWindowAction();
		dataObjWindowObj.setText("Data Object Window");
		dataObjWindowObj.setToolTipText("Data Object Window");
		dataObjWindowObj.setChecked(false);
		dataObjWindowObj.setId(DataObjectView.DATA_OBJ_VIEW_ID);
		this.register(dataObjWindowObj);
		dataObjWindowObj.addPropertyChangeListener(this);

		activityLogAction = new ActivityLogAction();
		activityLogAction.setText("Activity Log");
		activityLogAction.setToolTipText("Activity Log");
		activityLogAction.setId(ViewIDConstant.ACTIVITY_LOG);
		activityLogAction.setChecked(true);
		this.register(activityLogAction);
		activityLogAction.addPropertyChangeListener(this);

		tableEditorAction = new TableEditorAction();
		tableEditorAction.setText("Table Editor");
		tableEditorAction.setToolTipText("Table Editor");
		tableEditorAction.setId(ViewIDConstant.TABLE_EDITOR);
		tableEditorAction.setChecked(false);
		this.register(tableEditorAction);
		tableEditorAction.addPropertyChangeListener(this);
		
		minMaxInfoAction = new MinMaxInfoAction();
		minMaxInfoAction.setText("Min Max Assist");
		minMaxInfoAction.setToolTipText("Min Max Assist");
		minMaxInfoAction.setId(ViewIDConstant.MIN_MAX_INFO);
		minMaxInfoAction.setChecked(false);
		this.register(minMaxInfoAction);
		minMaxInfoAction.addPropertyChangeListener(this);


		resetPersObj = ActionFactory.RESET_PERSPECTIVE.create(window);
		this.register(resetPersObj);
		
		preferencesAction = ActionFactory.PREFERENCES.create(window);
		this.register(preferencesAction);

		resolvInconObj = new IOInconsistency();
		resolvInconObj.setText("Resolve Inconsistency using Model");
		resolvInconObj.setToolTipText("Resolve Inconsistency using Model");
		resolvInconObj.setImageDescriptor(Activator.getImageDescriptor("/icons/inconsistencywithmodel.png"));
		resolvInconObj.setDisabledImageDescriptor(Activator.getImageDescriptor("/icons/inconsistencywithmodel-disable.png"));
		resolvInconObj.setEnabled(false);
		this.register(resolvInconObj);

		filterAction = new FilterAction();
		filterAction.setText(ApplicationConstant.FILTER);
		filterAction.setToolTipText(ApplicationConstant.FILTER);
		filterAction.setImageDescriptor(Activator.getImageDescriptor("/icons/filter.png"));
		filterAction.setDisabledImageDescriptor(Activator.getImageDescriptor("/icons/filter-disable.png"));
		filterAction.setEnabled(false);
		this.register(filterAction);

		exitAction = ActionFactory.QUIT.create(window);
		this.register(exitAction);

		IWorkbenchAction aboutAction = ActionFactory.ABOUT.create(window);
		this.register(aboutAction);
		aboutAction.setEnabled(false);

		helpSearchAction = new HelpSearchAction();
		helpSearchAction.setText("Help Search");
		helpSearchAction.setToolTipText("Help Search");
		this.register(helpSearchAction);
		helpSearchAction.setEnabled(true);
		
		dataDictAbout = new DataDictionaryAbout();
		dataDictAbout.setText("Version 6.0 (R2021b)");
		dataDictAbout.setToolTipText("Version 6.0 (R2021b)");
		this.register(dataDictAbout);
		dataDictAbout.setEnabled(false);
		
		excelImportExport = new ExcelImportExportAction();
		excelImportExport.setText("Resolve Inconsistency using Excel");
		excelImportExport.setToolTipText("Resolve Inconsistency using Excel");
		excelImportExport.setImageDescriptor(Activator.getImageDescriptor("/icons/inconsistencywithexcel.png"));
		excelImportExport.setDisabledImageDescriptor(Activator.getImageDescriptor("/icons/inconsistencywithexcel-disable.png"));
		excelImportExport.setEnabled(false);
		this.register(excelImportExport);
		
		validProjAction = new ValidateProjAction();
		validProjAction.setText("Validate Project");
		validProjAction.setToolTipText("Validate Project");
		validProjAction.setImageDescriptor(Activator.getImageDescriptor("/icons/val.png"));
		this.register(validProjAction);
		validProjAction.setEnabled(false);
		
		updateProjParaTypeAction = new UpdateProjParaTypeAction();
		updateProjParaTypeAction.setText("Update Project's Paramter Type");
		updateProjParaTypeAction.setToolTipText("Update Project's Paramter Type");
		updateProjParaTypeAction.setImageDescriptor(Activator.getImageDescriptor("/icons/val.png"));
		this.register(updateProjParaTypeAction);
		updateProjParaTypeAction.setEnabled(false);
		super.makeActions(window);
	}

	/**
	 * This method is used to insert elements in menu bar
	 */
	@Override
	protected void fillMenuBar(IMenuManager menuBar) {
		// File
		MenuManager fileMenu = new MenuManager("&File", "file");
		menuBar.add(fileMenu);
		fileMenu.add(importAction);
		recentimportMenu = new MenuManager("&Recently Imported Projects", "Recently Imported Projects");
		recentimportMenu.setImageDescriptor(Activator.getImageDescriptor("/icons/recent.png"));
		String[] sprlitProjectPath = null;
		if (ApplicationWorkbenchWindowAdvisor.recentlyImpProj != null
				&& !ApplicationWorkbenchWindowAdvisor.recentlyImpProj.equals("")) {
			sprlitProjectPath = ApplicationWorkbenchWindowAdvisor.recentlyImpProj.split(",");

			for (int i = 0; i < sprlitProjectPath.length; i++) {
				IWorkbenchAction projectPath = new ImportRecentlyImportedProjectAction();
				projectPath.setText(sprlitProjectPath[i]);
				this.register(projectPath);
				projectPath.setEnabled(true);
				recentimportMenu.add(projectPath);
				pathList.add(sprlitProjectPath[i]);
				// recentlyimportedMenu.r
			}

		}
		IWorkbenchAction clearListAction = new ClearListAction();
		clearListAction.setText("Clear List");
		this.register(clearListAction);
		if (sprlitProjectPath != null) {
			clearListAction.setEnabled(true);
		} else {
			clearListAction.setEnabled(false);
		}
		recentimportMenu.add(new Separator());
		recentimportMenu.add(clearListAction);
		fileMenu.add(recentimportMenu);
		fileMenu.add(new Separator());
		fileMenu.add(saveAction);
		fileMenu.add(saveAllAction);
		fileMenu.add(closeProjAction);
		fileMenu.add(new Separator());
		fileMenu.add(exitAction);

		// Edit
		MenuManager editMenu = new MenuManager("&Edit", "edit");
		menuBar.add(editMenu);
		editMenu.add(undoAction);
		editMenu.add(redoAction);
		editMenu.add(cutAction);
		editMenu.add(copyAction);
		editMenu.add(pasteAction);
		editMenu.add(deleteAction);
		// Project
		MenuManager projectMenu = new MenuManager("&Project", "edit");
		menuBar.add(projectMenu);
		projectMenu.add(ioCompatAction);
		projectMenu.add(validProjAction);
		projectMenu.add(updateProjParaTypeAction);
		// Project
		MenuManager windowsMenu = new MenuManager("&Windows", "window");
		menuBar.add(windowsMenu);
		windowsMenu.add(ioCompatWinAction);
		windowsMenu.add(welcomeNoteAction);
		windowsMenu.add(projExplorerObj);
		windowsMenu.add(activityLogAction);
		windowsMenu.add(searchWindowObj);
		windowsMenu.add(new Separator());
		windowsMenu.add(resetPersObj);
		windowsMenu.add(new Separator());
		windowsMenu.add(preferencesAction);

		// Help
		MenuManager helpMenu = new MenuManager("&Help", "help");
		menuBar.add(helpMenu);
	//	helpMenu.add(aboutAction);
		helpMenu.add(new Separator());
		helpMenu.add(helpSearchAction);
		helpMenu.add(new Separator());
		helpMenu.add(dataDictAbout);
		

		// Help
		helpMenu.add(introAction);

		super.fillMenuBar(menuBar);
	}

	/**
	 * Method is used to set actions in cool bar
	 */
	@Override
	protected void fillCoolBar(ICoolBarManager coolBar) {

		IToolBarManager saveSaveAllGroup = new ToolBarManager(SWT.FLAT | SWT.RIGHT);
		saveSaveAllGroup.add(importAction);
		saveSaveAllGroup.add(saveAction);
		saveSaveAllGroup.add(saveAllAction);

		coolBar.add(saveSaveAllGroup);

		IToolBarManager undoRedoGroup = new ToolBarManager(SWT.FLAT | SWT.RIGHT);
		undoRedoGroup.add(undoAction);
		undoRedoGroup.add(redoAction);

		coolBar.add(undoRedoGroup);

		IToolBarManager cutCopyPasteGroup = new ToolBarManager(SWT.FLAT | SWT.RIGHT);
		cutCopyPasteGroup.add(cutAction);
		cutCopyPasteGroup.add(copyAction);
		cutCopyPasteGroup.add(pasteAction);

		coolBar.add(cutCopyPasteGroup);

		IToolBarManager searchToolBar = new ToolBarManager(SWT.FLAT | SWT.RIGHT);
		searchToolBar.add(searchAction);

		coolBar.add(searchToolBar);
		IToolBarManager ioFilterGroup = new ToolBarManager(SWT.FLAT | SWT.RIGHT);
		ioFilterGroup.add(ioCompatAction);
		ioFilterGroup.add(resolvInconObj);
		ioFilterGroup.add(excelImportExport);
		ioFilterGroup.add(filterAction);
		coolBar.add(ioFilterGroup);
	}

	/**
	 * Method is used to perform action according to the check and uncheck.
	 */
	@Override
	public void propertyChange(PropertyChangeEvent event) {
		action = (Action) event.getSource();
		if(!action.getText().equals(ApplicationConstant.WELCOME_NOTE)){
			ViewUtil.showHideView(action.getId(), action.isChecked());
		}
		else{
			showHideWelcomeNote();
		}
	}

	/**
	 * 
	 */
	public void showHideWelcomeNote() {
		IWorkbenchPage page = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
		IEditorPart activeEditor = page.getActiveEditor();
		if(welcomeNoteAction.isChecked()){
			WelcomeNoteEditorInput welcomeEditObj = new WelcomeNoteEditorInput();
			try {
				page.openEditor(welcomeEditObj, WelcomeNoteEditor.WELCOME_NOTE_EDIT);
			} catch (PartInitException exception) {
				LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, exception);
			} 
		}
		else if(!welcomeNoteAction.isChecked()){			
			//Condition to check if editor is instance of welcome editor
			if(activeEditor instanceof WelcomeNoteEditor) {
				if(activeEditor.getTitle().equals(ApplicationConstant.WELCOME_NOTE)){
					page.closeEditor(activeEditor, false);
				}
			}
		}
	}
}
