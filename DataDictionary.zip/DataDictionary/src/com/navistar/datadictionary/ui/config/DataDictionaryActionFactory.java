package com.navistar.datadictionary.ui.config;

import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.actions.ActionFactory;
/**
 * This class is used to access the standard actions provided by the workbench
 * @author nikitak1
 *
 */
public class DataDictionaryActionFactory extends ActionFactory{

	/**
	 * Parameterized constructor
	 * @param actionId
	 * @param commandId
	 */
	protected DataDictionaryActionFactory(String actionId, String commandId) {
		super(actionId, commandId);
	
	}
	/**
	 * Creates a new standard action for the given workbench window
	 * @param window
	 */
	@Override
	public IWorkbenchAction create(IWorkbenchWindow window) {
		return null;
	}

}
