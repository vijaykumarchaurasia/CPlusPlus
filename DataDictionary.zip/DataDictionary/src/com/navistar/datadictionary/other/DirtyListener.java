package com.navistar.datadictionary.other;
/**
 * This interface is used so that dirty indicator will be visible when editor is changed.
 * @author nikitak1
 *
 */
public interface DirtyListener {
	/**
	 * This method is used to show the dirty bit used for Save functionality.
	 */
	void fireDirty();

}
