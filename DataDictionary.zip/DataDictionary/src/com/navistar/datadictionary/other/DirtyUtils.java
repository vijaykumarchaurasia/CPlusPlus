package com.navistar.datadictionary.other;

import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Text;
/**
 * This class is used to handle the text change in the workspace editor
 * @author nikitak1
 *
 */
public class DirtyUtils {
	/**
	 * This method is used to register dirty listener.
	 * @param listener
	 * @param controls
	 */
	public static void registryDirty(DirtyListener listener,Control... controls) {
		if (controls == null) {
			return;
		}

		for (Control control : controls) {
			// Text Editor control
			if (control instanceof Text) {
				Text text = (Text) control;
				text.addVerifyListener(new VerifyListenerImpl(listener));
			}
			// Check box or Radio button control
			else if (control instanceof Button) {
				Button button = (Button) control;
				button.addSelectionListener(new SelectionListenerImpl(listener));
			}
			// Not supported control
			else {
				throw new UnsupportedOperationException("Not support for "
						+ control.getClass().getSimpleName());
			}
		}
	}
	/**
	 * This class deals with the events that are generated when editor
	 * is about to be modified.
	 *
	 */
	static class VerifyListenerImpl implements VerifyListener {
		private DirtyListener listener;
		/**
		 * 
		 * @param listener
		 */
		public VerifyListenerImpl(DirtyListener listener) {
			this.listener = listener;
		}
		/**
		 * Sent when the text is about to be modified
		 */
		@Override
		public void verifyText(VerifyEvent arg0) {
			listener.fireDirty();
		}

	}

}