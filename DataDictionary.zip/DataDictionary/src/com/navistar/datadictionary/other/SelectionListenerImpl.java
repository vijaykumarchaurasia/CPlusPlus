package com.navistar.datadictionary.other;

import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;

/**
 *  This class deals with the events that are generated when selection 
 *  occurs in a control. 
 *  For Button (Check box, Radio).
 *
 */
public class SelectionListenerImpl implements SelectionListener {
	/** This is instance variable for dirty indicator listener*/
	private DirtyListener listener;

	public SelectionListenerImpl(DirtyListener listener) {
		this.listener = listener;
	}
	/**
	 *  Sent when default selection occurs in the control.
	 *  @param selectionEvent
	 */
	@Override
	public void widgetDefaultSelected(SelectionEvent selectionEvent) {
		//Nothing to clean-up
	}
	/** 
	 * Sent when selection occurs in the control 
	 * @param selectionEvent
	 */
	@Override
	public void widgetSelected(SelectionEvent selectionEvent) {
		listener.fireDirty();
	}

}
