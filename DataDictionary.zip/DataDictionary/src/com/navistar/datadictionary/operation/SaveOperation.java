package com.navistar.datadictionary.operation;

import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.PlatformUI;

import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.ui.editors.CategoryEditor;

/**
 * Class is used for Save operations
 * @author JAYSHRIVISHB
 *
 */
public class SaveOperation {

	/**
	 * Make save and save-all actions enabled and disable
	 */
	public void makeSaveEnableDisable(CategoryEditor categoryEditor) {

		boolean saveStatus = false;
		boolean saveAllStatus = false;
		IEditorPart[] dirtyEditors = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getDirtyEditors();
		for(IEditorPart editor : dirtyEditors){
			if(editor instanceof CategoryEditor && editor.getTitle().equals(categoryEditor.getTitle())){
				saveStatus = true;
			}else{
				saveAllStatus = true;
			}
		}
		
		ApplicationActionBarAdvisor.getInstance().saveAction.setEnabled(saveStatus);
		ApplicationActionBarAdvisor.getInstance().saveAllAction.setEnabled(saveAllStatus);
		if(dirtyEditors.length > 0)
		{
			ApplicationActionBarAdvisor.getInstance().saveAction.setEnabled(true);
			//ApplicationActionBarAdvisor.getInstance().undoAction.setEnabled(true);
		}else {
			ApplicationActionBarAdvisor.getInstance().undoAction.setEnabled(false);
		}
		
	}
}
