package com.navistar.datadictionary.operation;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.operations.AbstractOperation;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.PlatformUI;

import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.model.NatTableRowData;
import com.navistar.datadictionary.model.NatTableRowIndex;
import com.navistar.datadictionary.model.NatTableRowIndexArray;
import com.navistar.datadictionary.model.NatTableRowIndexArrayForDelete;
import com.navistar.datadictionary.model.NatTableRowIndexDelete;
import com.navistar.datadictionary.model.TableCell;
import com.navistar.datadictionary.model.TableCellArray;
import com.navistar.datadictionary.serviceimpl.ImportProjectServiceImpl;
import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.ui.nattable.CreateNatTable;
import com.navistar.datadictionary.ui.nattable.DeleteRowCommand;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Class is used to create a operation for undo and redo
 * @author minalc
 */
public class UndoRedoOperation extends AbstractOperation {

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(CategoryEditor.class);
	
	public SaveOperation saveOperation = new SaveOperation();
	/**
	 * This constructor is used to test operation.
	 */
	public UndoRedoOperation() {
		super("Test operation");		
	}

	/**
	 * This method is used to execute the Action operations.
	 */
	@Override
	public IStatus execute(IProgressMonitor monitor, IAdaptable info) throws ExecutionException {
		return Status.OK_STATUS;
	}

	/**
	 * Method get called internally for redo operation
	 */
	@Override
	public IStatus redo(IProgressMonitor monitor, IAdaptable info) throws ExecutionException {

		IEditorPart activeEditor = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
				.getActiveEditor();
		CategoryEditor categoryEditor = (CategoryEditor) activeEditor;
		Object stackElement = null;
		if(!categoryEditor.editModeFlag){
			if (!categoryEditor.redoEditorStack.isEmpty()) {
				ViewUtil.closeView(ViewIDConstant.TABLE_EDITOR);
				ViewUtil.closeView(ViewIDConstant.MIN_MAX_INFO);
				stackElement = categoryEditor.redoEditorStack.pop();
				try {
					// Perform redo when multiple cell update or added in paste
					if(stackElement instanceof NatTableRowIndexArray){
						ImportProjectServiceImpl.pasteFlag = true;
						NatTableRowIndexArray natTblRowIdxArray = (NatTableRowIndexArray)stackElement;
						List<Object> natTblRowIdxList = natTblRowIdxArray.getNatTableRowIndexList();
						
						for(int i=natTblRowIdxList.size()-1;i>=0;i--){
							//if(natTableRowIndexList.get(i) instanceof NatTableRowIndex){
							//	natTableAddRowHandlerRedo(categoryEditor, natTableRowIndexList.get(i));
							//}else 
							if(natTblRowIdxList.get(i) instanceof NatTableRowData){
								natTableUpdateRowHandlerRedo(categoryEditor, natTblRowIdxList.get(i));
							}		
						}
						ImportProjectServiceImpl.pasteFlag = false;
						//categoryEditor.natTableRowDataList = new ArrayList<Object>();
						NatTableRowIndexArray redoIdxArray = new NatTableRowIndexArray();
						redoIdxArray.setNatTableRowIndexList(categoryEditor.natTblRowDataList);
						categoryEditor.natTblRowDataList = new ArrayList<Object>();
						categoryEditor.undoEditStack.push(redoIdxArray);
					}
					//Perform undo for multiple row delete
					if(stackElement instanceof NatTableRowIndexArrayForDelete) {

						NatTableRowIndexArrayForDelete delIdxArray = (NatTableRowIndexArrayForDelete)stackElement;
						List<Object> delIdxList = delIdxArray.getNatTableRowIndexList();
						for(int i=delIdxList.size()-1;i>=0;i--){
							if(delIdxList.get(i) instanceof NatTableRowData){
								NatTableRowData rowData = (NatTableRowData) delIdxList.get(i);
								deleteMultipleRowAtSpecificIndexAfterRedo(categoryEditor,  rowData.getRowIndex());
							}
						}
						NatTableRowIndexArrayForDelete delUndoIdxArray = new NatTableRowIndexArrayForDelete();
						delUndoIdxArray.setNatTableRowIndexList(categoryEditor.natTblRowDataList);
						categoryEditor.undoEditStack.push(delUndoIdxArray);
						categoryEditor.natTblRowDataList = new ArrayList<Object>();
					
					}
					
					//Perform undo for single row delete
					if(stackElement instanceof NatTableRowIndexDelete) {
						deleteSingleRowAtSpecificIndexAfterRedo(categoryEditor, stackElement);
					}
					// Perform redo of cell edit if stackElement is instanceof TableCellArray
					if(stackElement instanceof TableCellArray){
						ImportProjectServiceImpl.pasteFlag = true;
						TableCellArray tableCellArray = (TableCellArray)stackElement;
						List<Object> tableCellList = tableCellArray.getTableCellList();
						for(int i=tableCellList.size()-1;i>=0;i--){
							tableCellEditUndoRedo(categoryEditor, tableCellList.get(i));
						}	
						ImportProjectServiceImpl.pasteFlag = false;
						TableCellArray tblCellUndoArray = new TableCellArray();
						tblCellUndoArray.setTableCellList(categoryEditor.tableCellDataList);
						categoryEditor.undoEditStack.push(tblCellUndoArray);
						categoryEditor.tableCellDataList = new ArrayList<>();
					}
					
					// Perform redo of cell edit if stackElement is instanceof TableCell
					if (stackElement instanceof TableCell) {
						tableCellRedo(categoryEditor, stackElement);

					}

					// Perform redo of new row add if stackElement is instanceof NatTableRowHandler
					else if (stackElement instanceof NatTableRowIndex) {
						natTableAddRowHandlerRedo(categoryEditor,stackElement);
					}

					categoryEditor.natTable.refresh();
					
					//make dirty bit true 
					if(categoryEditor.savedDataObjList.toString().equals(categoryEditor.updatDataObjList.toString()))
					{
						categoryEditor.setDirtyStatus(false);
					}
					else
					{
						categoryEditor.setDirtyStatus(true);
					}

					makeUndoRedoEnableDisable(categoryEditor.undoEditStack,categoryEditor.redoEditorStack);
					saveOperation.makeSaveEnableDisable(categoryEditor);
					
				} catch (Exception e) {
					LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
					MessageDialog.openConfirm(new Shell(), "Error Message","Error while performing redo operation");
				}
			}
		}	
		categoryEditor.columnindex = 0;
		categoryEditor.rowidx = 0;
		return Status.OK_STATUS;
	}

	/**
	 * Method used to add new row for redo event
	 * @param categoryEditor
	 * @param natTableOperation
	 * @param stackElement
	 */
	private void natTableAddRowHandlerRedo(CategoryEditor categoryEditor,Object stackElement) {
		NatTableRowIndex natTblRowHandler = (NatTableRowIndex) stackElement;
		CategoryAttributes catAttributes = new CategoryAttributes();
		catAttributes = categoryEditor.natTableOperation.categoryDAO;
		categoryEditor.natTableOperation.addNewRowInNatTable(categoryEditor.getParent(), natTblRowHandler.getRowIndex(),categoryEditor.createNatTable,categoryEditor.natTable,categoryEditor.editRowLists,categoryEditor.getTitle(),catAttributes);

		categoryEditor.natTableOperation.setFocusOnNewRow(categoryEditor.natTable.getRowCount(), categoryEditor.createNatTable, categoryEditor.natTable, natTblRowHandler.getRowIndex());
		
		//Add redo action for undo in undo stack
		categoryEditor.undoEditStack.push(new NatTableRowIndex(natTblRowHandler.getSelectionLayer(), natTblRowHandler.getRowIndex()));
	}

	/**
	 * Method get called internally for undo
	 */
	@Override
	public IStatus undo(IProgressMonitor monitor, IAdaptable info) throws ExecutionException {

		IEditorPart activeEditor = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
				.getActiveEditor();
		CategoryEditor categoryEditor = (CategoryEditor) activeEditor;
		Object stackElement = null;

		if(!categoryEditor.editModeFlag){
			if (!categoryEditor.undoEditStack.isEmpty()) {
				ViewUtil.closeView(ViewIDConstant.TABLE_EDITOR);
				ViewUtil.closeView(ViewIDConstant.MIN_MAX_INFO);
				stackElement = categoryEditor.undoEditStack.pop();
				try {
					// Perform undo when multiple cell update or added in paste
					if(stackElement instanceof NatTableRowIndexArray){
						ImportProjectServiceImpl.pasteFlag = true;
						NatTableRowIndexArray rowIdxArray = (NatTableRowIndexArray)stackElement;
						List<Object> rowIdxList = rowIdxArray.getNatTableRowIndexList();

						for(int i=rowIdxList.size()-1;i>=0;i--){
							if(rowIdxList.get(i) instanceof NatTableRowIndex){
								natTableAddRowHandlerUndo(categoryEditor, rowIdxList.get(i));
							}else if(rowIdxList.get(i) instanceof NatTableRowData){
								natTableUpdateRowHandlerUndo(categoryEditor, rowIdxList.get(i));
							}

						}
						ImportProjectServiceImpl.pasteFlag = false;
						NatTableRowIndexArray redoIdxArray = new NatTableRowIndexArray();
						redoIdxArray.setNatTableRowIndexList(categoryEditor.natTblRowDataList);
						categoryEditor.redoEditorStack.push(redoIdxArray);
						categoryEditor.natTblRowDataList = new ArrayList<Object>();
					} 
					//Perform undo operation for multiple delete
					if(stackElement instanceof NatTableRowIndexArrayForDelete){
						NatTableRowIndexArrayForDelete delIdxArray = (NatTableRowIndexArrayForDelete)stackElement;
						List<Object> delIdxList = delIdxArray.getNatTableRowIndexList();
						for(int i=0;i<delIdxList.size();i++){
							if(delIdxList.get(i) instanceof NatTableRowData){
								addMultipleRowAtSpecificIndexAfterUndo(categoryEditor, delIdxList.get(i));
							}
						}
						NatTableRowIndexArrayForDelete redoDelIdxArray = new NatTableRowIndexArrayForDelete();
						redoDelIdxArray.setNatTableRowIndexList(categoryEditor.natTblRowDataList);
						categoryEditor.redoEditorStack.push(redoDelIdxArray);
						categoryEditor.natTblRowDataList = new ArrayList<Object>();
					}
					//Perform undo for single row delete
					if(stackElement instanceof NatTableRowIndexDelete) {
						addSingleRowAtSpecificIndexAfterUndo(categoryEditor, stackElement);
					}

					// Perform undo of cell edit if stackElement is instanceof TableCellArray
					if(stackElement instanceof TableCellArray){
						ImportProjectServiceImpl.pasteFlag = true;
						TableCellArray tableCellArray = (TableCellArray)stackElement;
						List<Object> tableCellList = tableCellArray.getTableCellList();
						for(int i=tableCellList.size()-1;i>=0;i--){
							tableCellEditUndoRedo(categoryEditor, tableCellList.get(i));
						}	
						ImportProjectServiceImpl.pasteFlag = false;
						TableCellArray redoTblCellArray = new TableCellArray();
						redoTblCellArray.setTableCellList(categoryEditor.tableCellDataList);
						categoryEditor.redoEditorStack.push(redoTblCellArray);
						categoryEditor.tableCellDataList = new ArrayList<>();
					}

					// Perform undo of cell edit if stackElement is instanceof TableCell
					if (stackElement instanceof TableCell) {
						tableCellUndo(categoryEditor, stackElement);
					}

					// Perform undo of new row add if stackElement is instanceof NatTableRowHandler
					else if (stackElement instanceof NatTableRowIndex) {
						natTableAddRowHandlerUndo(categoryEditor, stackElement);
					}
					categoryEditor.natTable.refresh();

					//make dirty bit false 
					if(categoryEditor.savedDataObjList.toString().equals(categoryEditor.updatDataObjList.toString()))
					{
						categoryEditor.setDirtyStatus(false);
					}
					else
					{
						categoryEditor.setDirtyStatus(true);
					}

					makeUndoRedoEnableDisable(categoryEditor.undoEditStack,categoryEditor.redoEditorStack);
					saveOperation.makeSaveEnableDisable(categoryEditor);

				} catch (Exception e) {
					LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
					MessageDialog.openConfirm(new Shell(), "Error Message","Error while performing undo operation");
				}

			}
		}	
		categoryEditor.columnindex = 0;
		categoryEditor.rowidx = 0;
		return Status.OK_STATUS;
	}

	/**
	 * This method is used to add multiple row at specific index after undo event
	 * @param categoryEditor
	 * @param object
	 * @author JAYSHRIVISHB
	 */
	private void addMultipleRowAtSpecificIndexAfterUndo(CategoryEditor categoryEditor, Object object) {
		NatTableRowData natTableRowData = (NatTableRowData) object;
		categoryEditor.createNatTable.filterList.add(natTableRowData.getRowIndex(),natTableRowData.getCategoryAttributes());
		categoryEditor.natTable.refresh();
		categoryEditor.natTblRowDataList.add(new NatTableRowData(natTableRowData.getCategoryAttributes(), natTableRowData.getRowIndex()));
	}

	/**
	 * This method is used to add single row at specific index after undo event
	 * @param categoryEditor
	 * @param object
	 * @author JAYSHRIVISHB
	 */
	private void addSingleRowAtSpecificIndexAfterUndo(CategoryEditor categoryEditor, Object object) {
		
		NatTableRowIndexDelete natTableRowData = (NatTableRowIndexDelete) object;
		categoryEditor.createNatTable.filterList.add(natTableRowData.getRowIndex(),natTableRowData.getCategoryAttributes());
		categoryEditor.natTable.refresh();
		categoryEditor.redoEditorStack.add(new NatTableRowIndexDelete(categoryEditor.createNatTable.getSelectionLayer(),natTableRowData.getCategoryAttributes(),natTableRowData.getRowIndex()));
	}

	/**
	 * This method is used to delete single row at specific index after redo event
	 * @param categoryEditor
	 * @param stackElement
	 * @author JAYSHRIVISHB
	 */
	private void deleteSingleRowAtSpecificIndexAfterRedo(CategoryEditor categoryEditor,Object stackElement) {
		NatTableRowIndexDelete delRowHandler = (NatTableRowIndexDelete) stackElement;

		delRowHandler.getSelectionLayer().doCommand(	new DeleteRowCommand(delRowHandler.getSelectionLayer(), delRowHandler.getRowIndex()));

		//Add redo action for undo in undo stack
		categoryEditor.undoEditStack.push(new NatTableRowIndexDelete(delRowHandler.getSelectionLayer(), delRowHandler.getCategoryAttributes(),delRowHandler.getRowIndex()));
	}


	/**
	 * This method is used to delete multiple row at specific index after redo event
	 * @param categoryEditor
	 * @param stackElement
	 * @param rowIndex 
	 * @author JAYSHRIVISHB
	 */
	private void deleteMultipleRowAtSpecificIndexAfterRedo(CategoryEditor categoryEditor, int rowIndex) {
		//NatTableRowIndexArrayForDelete natTableDeleteRowHandler = (NatTableRowIndexArrayForDelete) stackElement;
		CategoryAttributes catAttributes = null; 
		boolean deleteStatus = false;
		catAttributes = categoryEditor.natTableOperation.getCategoryForSelectedRow(rowIndex, categoryEditor.createNatTable.getJsonDataProvider());
		deleteStatus = categoryEditor.createNatTable.getSelectionLayer().doCommand(	new DeleteRowCommand(categoryEditor.createNatTable.getSelectionLayer(), rowIndex));

		//Add redo action for undo in undo stack
		if(deleteStatus) {

			categoryEditor.natTblRowDataList.add(new NatTableRowData(catAttributes, rowIndex));
		}
	}
	
	/**
	 * Method used to enable or disable undo redo actions
	 */
	public void makeUndoRedoEnableDisable(Stack<Object> undoEditStack,Stack<Object> redoEditStack) {
		//Make undo action enable	
		if(undoEditStack.size()>0)
		{	
			ApplicationActionBarAdvisor.getInstance().undoAction.setEnabled(true);
		}
		else
		{
			ApplicationActionBarAdvisor.getInstance().undoAction.setEnabled(false);
		}
		//Make redo action enable
		if(redoEditStack.size()>0)
		{
			ApplicationActionBarAdvisor.getInstance().redoAction.setEnabled(true);
		}
		else
		{
			ApplicationActionBarAdvisor.getInstance().redoAction.setEnabled(false);
		}
	}
	
	/**
	 * Method used to set the offset and slope value based on base type
	 * @param categoryEditor
	 * @param tableCell
	 * @param bodyDataRowIndex
	 */
	private void setOffSetAndSlope(CategoryEditor categoryEditor, int bodyDataRowIndex) {
		String selectedBaseType = (String)categoryEditor.createNatTable.getJsonDataProvider().getDataValue(CreateNatTable.colBaseTyIdx, bodyDataRowIndex);
		if(selectedBaseType.equals("single") || selectedBaseType.equals("boolean")){
			//set offset and slope
			categoryEditor.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colOffIdx,
					bodyDataRowIndex, "0");
			categoryEditor.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colSlopIdx,
					bodyDataRowIndex, "1");
		}else{
			//set offset and slope
			categoryEditor.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colOffIdx,
					bodyDataRowIndex, "0");
			categoryEditor.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colSlopIdx,
					bodyDataRowIndex, "1");
		}
	}
	/**
	 * Method used to perform undo for single table cell
	 * @param categoryEditor
	 * @param stackElement
	 */
	private void tableCellUndo(CategoryEditor categoryEditor, Object stackElement) {
		TableCell tableCell = (TableCell) stackElement;

		int bodyDataColIdx = tableCell.getColumnIndex();
		int bodyDataRowIndex = tableCell.getRowIndex();

		if (bodyDataColIdx >= 0 && bodyDataRowIndex >= 0) {
			String previousData = (String) categoryEditor.createNatTable.getJsonDataProvider()
					.getDataValue(bodyDataColIdx, bodyDataRowIndex);

			categoryEditor.createNatTable.getJsonDataProvider().setDataValue(bodyDataColIdx,
					bodyDataRowIndex, tableCell.getCellData());
			// If base type is getting undone then add validation accordingly
			if(bodyDataColIdx == CreateNatTable.colBaseTyIdx){
				//Undo offset and slope according to selected base type
				setOffSetAndSlope(categoryEditor, bodyDataRowIndex);
			}
			
			// If value of define is getting undone then add validation accordingly
			if(bodyDataColIdx == CreateNatTable.colValIdx){
				//Undo min and max as well if change in value of define
				resetMinMaxofDefine(categoryEditor, tableCell, bodyDataRowIndex);
			}
			//Add undo action for redo in redo stack
			categoryEditor.redoEditorStack.push(new TableCell(bodyDataRowIndex, bodyDataColIdx, previousData));
		}
	}
	
	/**
	 * Method used to add row for undo event
	 * @param categoryEditor
	 * @param stackElement
	 */
	private void natTableAddRowHandlerUndo(CategoryEditor categoryEditor, Object stackElement) {
		NatTableRowIndex tableRowHandler = (NatTableRowIndex) stackElement;
		CategoryAttributes catAttributes = null;
		boolean deleteStatus = false;
		try {
			catAttributes = categoryEditor.natTableOperation.getCategoryForSelectedRow(tableRowHandler.getRowIndex(), categoryEditor.createNatTable.getJsonDataProvider());
			deleteStatus = tableRowHandler.getSelectionLayer().doCommand(
					new DeleteRowCommand(tableRowHandler.getSelectionLayer(), tableRowHandler.getRowIndex()));
			categoryEditor.newAddedRowList.remove(tableRowHandler.getRowIndex());
		} catch (Exception e) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			MessageDialog.openConfirm(new Shell(), "Error Message","Error while removing new row in undo operation");
		}
		// If undo is successful then only add in redo stack
		if (deleteStatus) {
			if(!ImportProjectServiceImpl.pasteFlag){
				//Add undo action for redo in redo stack when paste action is not executed
				categoryEditor.redoEditorStack.push(stackElement);
			}else{
				categoryEditor.natTblRowDataList.add(new NatTableRowData(catAttributes, tableRowHandler.getRowIndex()));
			}		
		}
	}
	
	/**
	 * Method used to undo natTable update while paste action
	 * @param categoryEditor
	 * @param stackElement
	 */
	private void natTableUpdateRowHandlerUndo(CategoryEditor categoryEditor, Object stackElement) {
		NatTableRowData natTableRowData = (NatTableRowData) stackElement;
		try {
			CategoryAttributes categoryAttribute = categoryEditor.natTableOperation.getCategoryForSelectedRow(natTableRowData.getRowIndex(), categoryEditor.createNatTable.getJsonDataProvider());
			categoryEditor.natTblRowDataList.add(new NatTableRowData(categoryAttribute, natTableRowData.getRowIndex()));
			categoryEditor.natTableOperation.setCategoryForSelectedRow(natTableRowData.getCategoryAttributes(), natTableRowData.getRowIndex(), categoryEditor.createNatTable.getJsonDataProvider());
		} catch (Exception e) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			MessageDialog.openConfirm(new Shell(), "Error Message","Error while updating row in undo operation");
		}
	}
	
	/**
	 * Method used to undone/redone the TableCell action after paste
	 * @param categoryEditor
	 * @param stackElement
	 */
	private void tableCellEditUndoRedo(CategoryEditor categoryEditor, Object stackElement){
		TableCell tableCell = (TableCell) stackElement;
		
		categoryEditor.tableCellDataList.add(new TableCell(tableCell.getRowIndex(), tableCell.getColumnIndex(),
				categoryEditor.createNatTable.getJsonDataProvider()
						.getDataValue(tableCell.getColumnIndex(), tableCell.getRowIndex()).toString()));
		categoryEditor.createNatTable.getJsonDataProvider().setDataValue(tableCell.getColumnIndex(),
				tableCell.getRowIndex(), tableCell.getCellData());

	}
	
	/**
	 * Method used to redo natTable update while paste action
	 * @param categoryEditor
	 * @param stackElement
	 */
	private void natTableUpdateRowHandlerRedo(CategoryEditor categoryEditor, Object stackElement) {
		NatTableRowData natTableRowData = (NatTableRowData) stackElement;
		try {
			if(natTableRowData.getRowIndex()>=categoryEditor.createNatTable.getJsonDataProvider().getRowCount()){
				categoryEditor.natTableOperation.addNewRowInNatTable(categoryEditor.getParent(), categoryEditor.createNatTable.getJsonDataProvider().getRowCount(),categoryEditor.createNatTable,categoryEditor.natTable,categoryEditor.editRowLists,categoryEditor.getTitle(),null);
				categoryEditor.natTableOperation.setFocusOnNewRow(categoryEditor.natTable.getRowCount(), categoryEditor.createNatTable, categoryEditor.natTable, categoryEditor.createNatTable.getJsonDataProvider().getRowCount());
				categoryEditor.natTblRowDataList.add(new NatTableRowIndex(categoryEditor.createNatTable.getSelectionLayer(),categoryEditor.createNatTable.getJsonDataProvider().getRowCount()-1));
			}
			CategoryAttributes categoryAttribute = categoryEditor.natTableOperation.getCategoryForSelectedRow(natTableRowData.getRowIndex(), categoryEditor.createNatTable.getJsonDataProvider());
			categoryEditor.natTblRowDataList.add(new NatTableRowData(categoryAttribute, natTableRowData.getRowIndex()));
			categoryEditor.natTableOperation.setCategoryForSelectedRow(natTableRowData.getCategoryAttributes(), natTableRowData.getRowIndex(), categoryEditor.createNatTable.getJsonDataProvider());
		} catch (Exception e) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			MessageDialog.openConfirm(new Shell(), "Error Message","Error while updating row in redo operation");
		}
	}
	
	/**
	 * Method used to set the min and max of define depending on value 
	 * @param categoryEditor
	 * @param tableCell
	 * @param bodyDataRowIndex
	 */
	private void resetMinMaxofDefine(CategoryEditor categoryEditor, TableCell tableCell, int bodyDataRowIndex) {
		if((categoryEditor.getTitle().equals(ApplicationConstant.CATEGORY_DEFINE) && tableCell.getColumnIndex() == CreateNatTable.colValIdx)){
			//set min and max
			categoryEditor.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colMinIdx,
					bodyDataRowIndex, tableCell.getCellData());
			categoryEditor.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colMaxIdx,
					bodyDataRowIndex, tableCell.getCellData());
		}
	}

	/**
	 * Method used to redo table cell operation which is undone
	 * @param categoryEditor
	 * @param stackElement
	 */
	private void tableCellRedo(CategoryEditor categoryEditor, Object stackElement) {
		TableCell tableCell = (TableCell) stackElement;

		int bodyDataColIdx = tableCell.getColumnIndex();
		int bodyDataRowIndex = tableCell.getRowIndex();

		if (bodyDataColIdx >= 0 && bodyDataRowIndex >= 0) {
			String previousData = (String) categoryEditor.createNatTable.getJsonDataProvider()
					.getDataValue(bodyDataColIdx, bodyDataRowIndex);

			categoryEditor.createNatTable.getJsonDataProvider().setDataValue(bodyDataColIdx,
					bodyDataRowIndex, tableCell.getCellData());
			
			if(bodyDataColIdx == CreateNatTable.colBaseTyIdx){
				//Undo offset and slope according to selected base type
				setOffSetAndSlope(categoryEditor, bodyDataRowIndex);
			}
			
			if(bodyDataColIdx == CreateNatTable.colValIdx){
				//Undo min and max as well if change in value of define
				resetMinMaxofDefine(categoryEditor, tableCell, bodyDataRowIndex);
			}		
			//Add redo action for undo in undo stack
			categoryEditor.undoEditStack.push(new TableCell(bodyDataRowIndex, bodyDataColIdx, previousData));
		}
	}

}
