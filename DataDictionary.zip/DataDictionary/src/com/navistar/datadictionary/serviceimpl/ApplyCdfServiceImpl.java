package com.navistar.datadictionary.serviceimpl;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PlatformUI;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.reflect.TypeToken;
import com.navistar.datadictionary.constant.MatlabScriptConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.daoimpl.MatlabCommunicationDaoImpl;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.operation.SaveOperation;
import com.navistar.datadictionary.service.ApplyCdfService;
import com.navistar.datadictionary.ui.config.DataDictionaryApplication;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.ui.nattable.CreateNatTable;
import com.navistar.datadictionary.ui.views.ActivityLogView;
import com.navistar.datadictionary.util.CreateMatlabRequest;
import com.navistar.datadictionary.util.DataDictionaryUtil;
import com.navistar.datadictionary.util.GsonUtil;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Class implements methods of ApplyCdfService interface to implement applying cdf values
 * to a component.
 * @author nikitak1
 *
 */
public class ApplyCdfServiceImpl implements ApplyCdfService{

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(ApplyCdfServiceImpl.class);
	

	/**
	 * Method used to get names and values from CDF file using MATLAB script
	 * @throws MatlabCommunicatinException
	 */
	@Override
	public List<CategoryAttributes> getCdfDataFromMatlab() throws MatlabCommunicatinException {
		FileDialog fileDialog = new FileDialog(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell());
		String[] filterExt = { "*.cdfx;*.CDFX;*.cdf;*.CDF;"};
		fileDialog.setFilterExtensions(filterExt);
		String cdfPath = fileDialog.open();
		cdfPath = cdfPath.replace("\\", "/");
		JsonElement jsonElement = null;
		MatlabCommunicationDaoImpl matlabDataRequest = new MatlabCommunicationDaoImpl();
		if (cdfPath != null) {
			CategoryAttributes category = new CategoryAttributes();

			category.setName(cdfPath);
			Gson gson = new Gson();
			String jsonStr = gson.toJson(category);
			jsonStr = "["+jsonStr+"]";
			String matlabQuery = CreateMatlabRequest.createMatlabRequest(
					MatlabScriptConstant.QRYGETCDFVAL, new OpenComponentServiceImpl().getOpenedComponentName(),jsonStr);
			try {
				jsonElement = matlabDataRequest.executeMatlabRequest(matlabQuery);
				if(jsonElement.getAsJsonArray().get(0).isJsonObject()) {
					if(jsonElement.getAsJsonArray().get(0).getAsJsonObject().has("errorCode")) {
						String errorCode = jsonElement.getAsJsonArray().get(0).getAsJsonObject().get("errorCode").getAsString();
						if(errorCode.equals("972")) {	
							ViewUtil.dispInfoInMsgDialog("CDFX file does not contain any data");
							if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
								ActivityLogView.activityLog.append("\n [INFO]: CDFX file does not contain any data");
							}
							return null;
						}else if(errorCode.equals("973")) {
							ViewUtil.dispInfoInMsgDialog("Opened component not present in CDFX file. Please select valid CDFX file");
							if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
								ActivityLogView.activityLog.append("\n [INFO]: Opened component not present in CDFX file");
							}
							return null;
						}
					}
				}
			} catch (MatlabCommunicatinException e) {
				LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
				throw new MatlabCommunicatinException(e.getMessage(), e);
			}

		}
		Type type = new TypeToken<List<CategoryAttributes>>() {}.getType();
		List<CategoryAttributes> cdfList = GsonUtil.provider().fromJSONToList(jsonElement.toString(),type);	
		return cdfList;
	}

	/**
	 * Method used to get data object names from component and update its value from CDF file
	 * @param objToAddList
	 */
	@Override
	public void updateDataObjectValuesOnUI(List<CategoryAttributes> objToAddList) {
		Map<String, List<CategoryAttributes>> componentMapList = DataDictionaryApplication.getApplication()
				.getComponentMapList();
		IWorkbenchPage activePage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();	
		IEditorReference[] editorRef = activePage.getEditorReferences();
		List<String> dataObjList = new ArrayList<>();
		Set<String> nonUpd = new HashSet<>();
		if (componentMapList != null) {
			// using for-each loop for iteration over Map.entrySet()
			for (Map.Entry<String, List<CategoryAttributes>> entry : componentMapList.entrySet()) {
				String category;	 
				List<CategoryAttributes> categoryList = entry.getValue();
				for (Iterator<CategoryAttributes> iterator = categoryList.iterator(); iterator.hasNext();) {
					CategoryAttributes catAttributes = (CategoryAttributes) iterator.next();
					for(CategoryAttributes object : objToAddList) {
						if(object.getName().equals(catAttributes.getName())) {
								dataObjList.add(object.getName());
								category = catAttributes.getCategory();
								object.setCategory(category);
								for(IEditorReference editor : editorRef){
									IEditorPart editorPart = editor.getEditor(false);
									if(editorPart instanceof CategoryEditor && editorPart.getTitle().equals(category)){
										setCdfValDataInCategoryTable(activePage, category,
												object, editorPart, objToAddList, dataObjList);
									}
								}
						}
					}
				}
				
			}
			
		}
		
		for(CategoryAttributes obj : objToAddList) {
			if(!dataObjList.contains(obj.getName())) {
				nonUpd.add(obj.getName());
			}
		}
	
		if(!nonUpd.isEmpty()) {
			ViewUtil.dispInfoInMsgDialog("Data object(s) not found in the component to update values : "+nonUpd.toString());
		}
	}

	/**
	 * Method used to set CDF value data in category tables
	 * @param objToAddList
	 * @param activePage
	 * @param dataObjList
	 * @param category
	 * @param catAttributes
	 * @param object
	 * @param editorPart
	 */
	/*private void setCdfValDataInCategoryTable(List<CategoryAttributes> objToAddList, IWorkbenchPage activePage,
			List<String> dataObjList, String category, CategoryAttributes catAttributes, CategoryAttributes object,
			IEditorPart editorPart)*/ 
	 private void setCdfValDataInCategoryTable(IWorkbenchPage activePage, String category, CategoryAttributes object,
			IEditorPart editorPart, List<CategoryAttributes> objToAddList, List<String> dataObNamLst){
		CategoryEditor categoryEditor = (CategoryEditor)editorPart;
		int searchedIndex = DataDictionaryUtil.searchIndex(object.getName(), new OpenComponentServiceImpl().getOpenedComponentName(), category,
				categoryEditor.createNatTable.getJsonDataProvider().getList());
		categoryEditor.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colValIdx,
				searchedIndex, object.getValue());
		categoryEditor.natTable.addConfiguration(categoryEditor);	
		categoryEditor.natTable.refresh();
		DataDictionaryApplication.getApplication().setSearchedHighlighted(object);
		DataDictionaryApplication.getApplication().setSearchedHighLight(true);
		activePage.activate(categoryEditor);
		categoryEditor.addNatTableConfigurationForAddResolve(object.getName(),
				new OpenComponentServiceImpl().getOpenedComponentName(),category,dataObNamLst,object,objToAddList);
		categoryEditor.setDirtyStatus(true);
		new SaveOperation().makeSaveEnableDisable(categoryEditor);
		categoryEditor.editRowLists.add(searchedIndex);
		
	}
}
