package com.navistar.datadictionary.serviceimpl;

import java.io.File;
import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Nonnull;
import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PlatformUI;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import com.navistar.datadictionary.action.IOCompatibilityAction;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.MatlabQueryConstant;
import com.navistar.datadictionary.constant.MatlabResponseConstant;
import com.navistar.datadictionary.constant.MatlabScriptConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.dao.MatlabCommunicationDao;
import com.navistar.datadictionary.daoimpl.MatlabCommunicationDaoImpl;
import com.navistar.datadictionary.model.CategoryAttributesIo;
import com.navistar.datadictionary.model.Project;
import com.navistar.datadictionary.service.IOCompatibilityService;
import com.navistar.datadictionary.ui.config.Application;
import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.ui.editors.IOCompatibilityEditor;
import com.navistar.datadictionary.ui.views.ActivityLogView;
import com.navistar.datadictionary.ui.views.IOCompatibilityView;
import com.navistar.datadictionary.ui.views.ProjectExplorerView;
import com.navistar.datadictionary.util.CreateMatlabRequest;
import com.navistar.datadictionary.util.FileUtility;
import com.navistar.datadictionary.util.JSONUtil;
import com.navistar.datadictionary.util.JsontoList;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Class implements methods of IOCompatibilityService interface to implement I/O Compatibility operations.
 * @author JAYSHRIVISHB
 *
 */
public class IOCompatibilityServiceImpl implements IOCompatibilityService {


	/** Used to access matlab communication dao */
	MatlabCommunicationDao matlabDataRequest;

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(IOCompatibilityServiceImpl.class);

	/**
	 * Constructor
	 */
	public IOCompatibilityServiceImpl() {

		matlabDataRequest = new MatlabCommunicationDaoImpl();
	}
	
	/**
	 * Method is used to get the I/O Compatibility list data after querying matlab script.
	 * @throws MatlabCommunicatinException 
	 */
	@Override
	public JsonElement getIOCompatibilityData() throws MatlabCommunicatinException {
		JsonElement jsonElement = null;
		
		// Check for IO Compatibility window action
		Action action = ApplicationActionBarAdvisor.getInstance().action;
		if(action!=null && null!=action.getText())
		{
		if (action.getText().equals(ApplicationConstant.IO_COMPATIBILITY) || !IOCompatibilityAction.ioFlag) {
			jsonElement = Application.ioJsonElement;
		} else if (action.getText().equals(ApplicationConstant.CHECK_IOCOMPAT) && IOCompatibilityAction.ioFlag) {
			IOCompatibilityAction.ioFlag = false;
			ApplicationActionBarAdvisor.getInstance().ioCompatWinAction.setChecked(true);
			Project project = ProjectExplorerView.getActiveProject();
			
			
			if (project != null) {
				if(Application.programName.equals("E44"))
				{
				String matlabQuery = CreateMatlabRequest.createMatlabRequest(MatlabScriptConstant.QUERY_IO_COMPAT,
						project.getPath().replace("\\", "/"), MatlabScriptConstant.EMPTY_STRING);
				try
				{
					jsonElement = matlabDataRequest.executeMatlabRequest(matlabQuery);
				}
				catch(MatlabCommunicatinException e)
				{
					throw new MatlabCommunicatinException(e.getMessage(), e);
				}		
			}
			else
			{
				String matlabQuery = CreateMatlabRequest.createMatlabRequest(MatlabScriptConstant.QUERY_IO_COMPAT_E95,
						project.getPath().replace("\\", "/"), MatlabScriptConstant.EMPTY_STRING);
			
				try
				{
					jsonElement =matlabDataRequest.executeMatlabRequest(matlabQuery);
							//new FileUtility().readFromJsonFile("C:\\Users\\shalins\\Desktop\\E_95_8.json");
							//matlabDataRequest.executeMatlabRequest(matlabQuery);
				}
				catch(MatlabCommunicatinException e)
				{
					throw new MatlabCommunicatinException(e.getMessage(), e);
				}
				/*catch(Exception e)
				{
					//throw new MatlabCommunicatinException(e.getMessage(), e);
					e.printStackTrace();
				}*/
				
			}
				//handled for unknown exchange api error
				if (jsonElement != null && jsonElement.isJsonArray()) {
					JsonElement jsonElement1 = jsonElement.getAsJsonArray().get(0);
					if (jsonElement1.isJsonObject()) {
						if (jsonElement1.getAsJsonObject().has("modelData")) {
							Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
							String msgException = jsonElement1.getAsJsonObject().get("modelData").getAsString();
							MessageDialog.openInformation(shell,ApplicationConstant.INFORMATION,msgException);
							return null;
						}else if(jsonElement1.getAsJsonObject().has("errorCode")) {
							Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
							String error = jsonElement1.getAsJsonObject().get("errorCode").getAsString();
							if(error.equals("676767")) {
								MessageDialog.openInformation(shell,ApplicationConstant.INFORMATION,"I/O Compatibility"
										+ " cannot be checked because of no Input or Output present in the project");
							}
							
						}
					
					}
				}
				Application.ioJsonElement = jsonElement;
			}
		}
		}
		return jsonElement;
	}
	
	public boolean getArxmlPath() {
		Map<String, List<String>> map = FileUtility.arxmlPrjMap;
		Map<String, List<String>> filemap = (Map<String, List<String>>) FileUtility.componentlist;
		boolean exist =false;
		File openedProjectPath =new File( ProjectExplorerView.getActiveProject().getPath());
		List<String> compFromMap =filemap.get(openedProjectPath.getName());
		List<String> arxmlFromMap =map.get(openedProjectPath.getName());
		for(String f: compFromMap)
		{
		for (String str : arxmlFromMap) {

			// get the base name of component path
			File file = new File(f);
			File compName = new File(str);
			String fileName = FilenameUtils.getBaseName(file.getName()).toUpperCase();

			if (fileName.equals(FilenameUtils.getBaseName(compName.getName()))) {
				exist= true;
			}
		}
		}
		
		return exist;			

	}
	
	/**
	 * Method is used to parse JSON data and convert into HashMap.
	 * 
	 * @param jsonElement
	 * @return ioListMap
	 */
	public Map<String, List<CategoryAttributesIo>> convertIOListToMap(@Nonnull JsonElement jsonElement) {
		Map<String, List<CategoryAttributesIo>> ioListMap = null;
		/*Type type = new TypeToken<List<CategoryAttributes>>() {
		}.getType();
*/
		// Check if JSON element is null
		if (jsonElement != null) {
			//CategoryAttributesIo attributes =  new CategoryAttributesIo();
			ioListMap = new LinkedHashMap<String, List<CategoryAttributesIo>>();
			
			// Check if empty JSON element in E_44
			if (JSONUtil.checkIOCompatibilityIsEmpty(jsonElement)) {
				ioListMap = dispE44Warng(ioListMap);
				

			} 
			//Check if empty JSON element in E_95
			else if (JSONUtil.checkIOCompatibilityIsEmptyE95(jsonElement)) {
				
				Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
				MessageDialog.openInformation(shell, ApplicationConstant.INFORMATION,MessageConstant.IO_COMP_ARXML_ERROR);
				ioListMap = dispE95Warng(ioListMap);
								
				
			}
			
				
			else {
				
				// Parse the JSON details and convert into Map
				for (JsonElement jsonArray : jsonElement.getAsJsonArray()) {
					
					// check for error code and set error message accordingly
					ioListMap = checkErrNMsg(jsonArray, ioListMap);
											
				}
				
			}
		}
		return ioListMap;
	}
	
	
	public Map<String, List<CategoryAttributesIo>> checkErrNMsg (JsonElement jsonArray, Map<String, List<CategoryAttributesIo>> ioListMap)
	{
		if (jsonArray != null && jsonArray.isJsonArray()) {
			if(jsonArray.getAsJsonArray().size() > 0)
			{
			JsonElement errorObject = jsonArray.getAsJsonArray().get(0);
			
			if (errorObject.isJsonObject() && errorObject.getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)) {
				int errorValue = errorObject.getAsJsonObject().get(MatlabQueryConstant.ERROR_CODE).getAsInt();
				CategoryAttributesIo catAttributes =  new CategoryAttributesIo();	
				switch (errorValue) {
				case MatlabResponseConstant.NOINCONSISERRCODE:
					catAttributes.setWarning(ApplicationConstant.INCONSISTENT_IOS+" "+ApplicationConstant.NO_ISSUES);	
					ioListMap.put(ApplicationConstant.INCONSISTENT_IOS, Arrays.asList(catAttributes));								
					break;
				case MatlabResponseConstant.NOUNCONNERRCODE:
					catAttributes.setWarning(ApplicationConstant.UNCONNECTED_IP+" "+ApplicationConstant.NO_ISSUES);		
					ioListMap.put(ApplicationConstant.UNCONNECTED_IP, Arrays.asList(catAttributes));		
					break;
				case MatlabResponseConstant.NODUPOUTERRCODE:
					catAttributes.setWarning(ApplicationConstant.DUPLICATE_OP+" "+ApplicationConstant.NO_ISSUES);				
					ioListMap.put(ApplicationConstant.DUPLICATE_OP, Arrays.asList(catAttributes));	
					break;
				case MatlabResponseConstant.NOUNCONOUTERRCODE:
					catAttributes.setWarning(ApplicationConstant.UNCONNECTED_OP+" "+ApplicationConstant.NO_ISSUES);				
					ioListMap.put(ApplicationConstant.UNCONNECTED_OP, Arrays.asList(catAttributes));	
					break;
				case MatlabResponseConstant.NOINCONSISNORMALERRCODE:
					catAttributes.setWarning(ApplicationConstant.INCONSISTENT_IOS_NORMAL+" "+ApplicationConstant.NO_ISSUES);				
					ioListMap.put(ApplicationConstant.INCONSISTENT_IOS_NORMAL, Arrays.asList(catAttributes));	
					break;
				case MatlabResponseConstant.NOINCONSISSTRUCTUREDERRCODE:
					catAttributes.setWarning(ApplicationConstant.INCONSISTENT_IOS_STRUCTURE+" "+ApplicationConstant.NO_ISSUES);				
					ioListMap.put(ApplicationConstant.INCONSISTENT_IOS_STRUCTURE, Arrays.asList(catAttributes));	
					break;
					
				}
			}
			else
			{
				String updatedArray = jsonArray.toString().replaceAll("Null", "");
				//List<CategoryAttributes> ioCompatList = GsonUtil.provider().fromJSONToList(updatedArray,
				//		type);
				List<CategoryAttributesIo> ioCompatList = JsontoList.replaceEmptyBracketsMinMax(updatedArray);
				if (ioCompatList != null && !ioCompatList.isEmpty()) {
					CategoryAttributesIo iOCompatDAO = ioCompatList.get(0);
					ioListMap.put(iOCompatDAO.getWarning(), ioCompatList);
				}
			}
			}
		}
		return ioListMap;
	}
	
	public Map<String, List<CategoryAttributesIo>> dispE95Warng( Map<String, List<CategoryAttributesIo>> ioListMap)
	{
		for(int count=1;count<6;count++)
		{
			CategoryAttributesIo attributes =  new CategoryAttributesIo();
			switch(count)
			{
			case 1: 
				attributes.setWarning(ApplicationConstant.INCONSISTENT_IOS_NORMAL+" "+ApplicationConstant.NO_ISSUES);				
				ioListMap.put(ApplicationConstant.INCONSISTENT_IOS_NORMAL, Arrays.asList(attributes));
				break;
			case 2:
				attributes.setWarning(ApplicationConstant.INCONSISTENT_IOS_STRUCTURE+" "+ApplicationConstant.NO_ISSUES);				
				ioListMap.put(ApplicationConstant.INCONSISTENT_IOS_STRUCTURE, Arrays.asList(attributes));
				break;
			case 3:
				attributes.setWarning(ApplicationConstant.UNCONNECTED_IP+" "+ApplicationConstant.NO_ISSUES);				
				ioListMap.put(ApplicationConstant.UNCONNECTED_IP, Arrays.asList(attributes));
				break;
			case 4:
				attributes.setWarning(ApplicationConstant.DUPLICATE_OP+" "+ApplicationConstant.NO_ISSUES);				
				ioListMap.put(ApplicationConstant.DUPLICATE_OP, Arrays.asList(attributes));
				break;
			case 5:
				attributes.setWarning(ApplicationConstant.UNCONNECTED_OP+" "+ApplicationConstant.NO_ISSUES);				
				ioListMap.put(ApplicationConstant.UNCONNECTED_OP, Arrays.asList(attributes));
				break;
			}
		}
		return  ioListMap;
	}
	
	
	public Map<String, List<CategoryAttributesIo>> dispE44Warng( Map<String, List<CategoryAttributesIo>> ioListMap)
	{
		for(int count=1;count<5;count++)
		{
			CategoryAttributesIo attributes =  new CategoryAttributesIo();
			switch(count)
			{
			case 1: 
				attributes.setWarning(ApplicationConstant.INCONSISTENT_IOS+" "+ApplicationConstant.NO_ISSUES);				
				ioListMap.put(ApplicationConstant.INCONSISTENT_IOS, Arrays.asList(attributes));	
				break;
			case 2:
				attributes.setWarning(ApplicationConstant.UNCONNECTED_IP+" "+ApplicationConstant.NO_ISSUES);				
				ioListMap.put(ApplicationConstant.UNCONNECTED_IP, Arrays.asList(attributes));
				break;
			case 3:
				attributes.setWarning(ApplicationConstant.DUPLICATE_OP+" "+ApplicationConstant.NO_ISSUES);				
				ioListMap.put(ApplicationConstant.DUPLICATE_OP, Arrays.asList(attributes));
				break;
			case 4:
				attributes.setWarning(ApplicationConstant.UNCONNECTED_OP+" "+ApplicationConstant.NO_ISSUES);				
				ioListMap.put(ApplicationConstant.UNCONNECTED_OP, Arrays.asList(attributes));
				break;
			}
		}
		return  ioListMap;
	}
	
	
	/**
	 * This method is used to perform context menu action on right click of project
	 * and component
	 * 
	 * @param actionName
	 * @param viewer
	 */
	@Override
	public void deleteDataObjectFromView(Tree tree) throws MatlabCommunicatinException {

		Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
		if (tree != null) {
			String delDataObjName = "";
			String compName = "";
				TreeItem selectedNode = tree.getSelection()[0];
				//check if child present for parent item
				String warningName="";
				if(selectedNode.getParentItem()!= null){
					if(selectedNode.getParentItem().getParentItem()!=null){
						warningName = selectedNode.getParentItem().getParentItem().getText();
					}
				}
				if (selectedNode.getItemCount() == 0 && (warningName.contains(ApplicationConstant.INCONSISTENT_IOS)
						|| warningName.contains(ApplicationConstant.DUPLICATE_OP))) {
					boolean delDataDialogVal = MessageDialog.openConfirm(shell, ApplicationConstant.WARNING,
							MessageConstant.DELETE_DATA);
					if (delDataDialogVal) {
						Project project = ProjectExplorerView.getActiveProject();
						project.getPath().replace("\\", "/");
						String componentPath = FileUtility.getComponentPathFromProject( selectedNode.getText().split(" : ")[0],project.getPath());
						componentPath =  componentPath.replace("\\", "/");
						JsonElement inputJsonElement = null;
						JsonArray inputJsonArray = new JsonArray();
						JsonObject inputJsonObject = new JsonObject();
						delDataObjName = selectedNode.getParentItem().getText();
						compName = selectedNode.getText().split(" : ")[0];
						if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
							ActivityLogView.activityLog.append("\n [INFO]: Below Data Object Deleted Successfully:");
							ActivityLogView.activityLog.append("\n ===========================================");
							ActivityLogView.activityLog.append("\n " + compName +" : " + delDataObjName);
						}
						inputJsonObject.addProperty("Name", selectedNode.getParentItem().getText());
						inputJsonArray.add(inputJsonObject);
						inputJsonElement = inputJsonArray;
						String matlabQuery = CreateMatlabRequest.createMatlabRequest(MatlabScriptConstant.QUERYDELDATAOBJ, componentPath,inputJsonElement.toString());
						JsonElement result = null;
						try {
							 result = matlabDataRequest.executeMatlabRequest(matlabQuery);
						}
						catch (MatlabCommunicatinException e) {
							LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
							throw new MatlabCommunicatinException(e.getMessage(),e);
						}
						if (result != null && result.isJsonArray()) {
							JsonElement resultJsonElement = result.getAsJsonArray().get(0);
							if (resultJsonElement.isJsonObject()
									&& resultJsonElement.getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)) {
								MessageDialog.openConfirm(shell, ApplicationConstant.WARNING,
										MessageConstant.DELETE_DATA_ERROR);
							} else if (resultJsonElement.isJsonObject()
									&& resultJsonElement.getAsJsonObject().has(MatlabQueryConstant.MESSAGE_CODE) && 
									resultJsonElement.getAsJsonObject().get(MatlabQueryConstant.MESSAGE_CODE).getAsInt() == 502) {								
								refereshEditorAndView(selectedNode);
								
							}


						}
					}
				}
			}
	}
	
	/**
	 * Method is used to refresh category editor , I/O compatibility editor and I/O compatibility view after deleting the data object 
	 */
	@Override
	public void refereshEditorAndView(TreeItem treeItem) {

		String warningName = treeItem.getParentItem().getParentItem().getText();
		String componentName = treeItem.getText().split(" : ")[0];
		String categoryName = treeItem.getText().split(" : ")[1];
		String objectName = treeItem.getParentItem().getText();

		// Check if I/O Compatibility view exists
		if(Application.ioJsonElement!=null) {
			updateIOCompatibilityData(warningName, componentName, objectName,categoryName);
		}
		
		// Check if Component Inputs view exists
		if(Application.compIpJsonElement!=null) {
			CheckComponentInputsServiceimpl checkCompInObj= new CheckComponentInputsServiceimpl();
			checkCompInObj.updateCompInputsData(warningName, componentName, objectName, categoryName);
			
			ViewUtil.closeView(ViewIDConstant.COMP_INPUTS);
			ViewUtil.showHideView(ViewIDConstant.COMP_INPUTS, true);
		}
		
		
		IWorkbenchPage activePage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();

		IEditorReference[] editors = activePage.getEditorReferences(); 		
		for (IEditorReference editor : editors) {
				
				if(editor.getEditor(false) instanceof IOCompatibilityEditor)
				{
					IOCompatibilityEditor ioComatEditor = (IOCompatibilityEditor) editor.getEditor(false);
					ioComatEditor.refreshIOCompatibilityEditor(warningName, componentName, categoryName, objectName);
				}
				else if(editor.getEditor(false) instanceof CategoryEditor)
				{
					CategoryEditor categoryEditor = (CategoryEditor) editor.getEditor(false);
					categoryEditor.updateCategoryEditor(categoryEditor,warningName,componentName,objectName);
				}
						
		} 
		
		Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
		MessageDialog.openInformation(shell, ApplicationConstant.INFORMATION,MessageConstant.DELETE_SUCCESS);
		
		
	}
	
	/**
	 * Method used to refresh I/O compatibility view after deleting the data object 
	 * @param warningName
	 * @param componentName
	 * @param objectName
	 * @param gsonUtil
	 * @param type
	 * @param jsonParser
	 * @param updatedIODataArray
	 * @param gson
	 */
	@Override
	public void updateIOCompatibilityData(String warningName, String componentName, String objectName,
			String categoryName) {
		
	//	GsonUtil gsonUtil = GsonUtil.provider();
		Type type = new TypeToken<List<CategoryAttributesIo>>() {}.getType();
		JsonArray updatedIOArray = new JsonArray();
		for (JsonElement jsonArray : Application.ioJsonElement.getAsJsonArray()) {

			// check for error code and set error message accordingly
			if (jsonArray != null && jsonArray.isJsonArray()) {
				JsonElement errorObject = jsonArray.getAsJsonArray().get(0);
				if (errorObject.isJsonObject() && errorObject.getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)) {
					updatedIOArray.add((JsonArray)jsonArray);
				}
				else
				{
					List<CategoryAttributesIo> ioCompatDataList = JsontoList.replaceEmptyBracketsMinMax(jsonArray.toString());
					//List<CategoryAttributes> ioCompatDataList = gsonUtil.fromJSONToList(jsonArray.toString(),type);					
					for (Iterator<CategoryAttributesIo> iterator = ioCompatDataList.iterator(); iterator.hasNext();) {
						CategoryAttributesIo catAttributes = (CategoryAttributesIo) iterator.next();
						if(null!=catAttributes.getComponent() && null!=catAttributes.getName() && null!=catAttributes.getCategory()){
						if (catAttributes.getComponent().equals(componentName)
								&& catAttributes.getName().equals(objectName)
								&& catAttributes.getCategory().equals(categoryName)) {
							ioCompatDataList.remove(catAttributes);
							if(ioCompatDataList.isEmpty()) {
								CategoryAttributesIo obj = new CategoryAttributesIo();
								obj.setWarning(catAttributes.getWarning()+" (No Issues)");
								ioCompatDataList.add(obj);
								
							}
							break;
						}
						}

					}
					
					updatedIOArray.add((JsonArray) new JsonParser().parse(new Gson().toJson(ioCompatDataList, type)));

				}

			}

		}

		// Update Application.ioJsonElement
		Application.ioJsonElement = updatedIOArray;
		ApplicationActionBarAdvisor.getInstance().action = ApplicationActionBarAdvisor
				.getInstance().ioCompatWinAction;

		// Refresh the IO Compatibility view
		IOCompatibilityView.getIOCompatibilityViewInstance().createIOPartControl();
		
	}
}
