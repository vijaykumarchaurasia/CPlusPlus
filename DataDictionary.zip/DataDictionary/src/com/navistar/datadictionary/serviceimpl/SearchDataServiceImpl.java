package com.navistar.datadictionary.serviceimpl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.PlatformUI;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.MatlabQueryConstant;
import com.navistar.datadictionary.constant.MatlabScriptConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.daoimpl.MatlabCommunicationDaoImpl;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.service.SearchDataService;
import com.navistar.datadictionary.ui.config.DataDictionaryApplication;
import com.navistar.datadictionary.util.CreateMatlabRequest;

/**
 * Class implements methods of SearchDataService interface to implement
 * search operation.
 * 
 * @author vijayk13
 *
 */
public class SearchDataServiceImpl implements SearchDataService {

		
	/**
	 * This method is used to get searched data object list
	 * @param dataObject
	 * @param matchCase
	 * @param exactWord
	 */
	@Override
	public List<CategoryAttributes> searchDataForOpenComponent(String dataObject, boolean matchCase, boolean exactWord) {
		Map<String, List<CategoryAttributes>> componentMapList = DataDictionaryApplication.getApplication()
				.getComponentMapList();
		List<CategoryAttributes> searchedList = new ArrayList<CategoryAttributes>();
		if (componentMapList != null) {
			// using for-each loop for iteration over Map.entrySet()
			for (Map.Entry<String, List<CategoryAttributes>> entry : componentMapList.entrySet()) {

				List<CategoryAttributes> categoryList = entry.getValue();
				for (Iterator<CategoryAttributes> iterator = categoryList.iterator(); iterator.hasNext();) {
					getSearchedComponentList(dataObject, matchCase, exactWord, searchedList, iterator);
				}

			}

		}

		return searchedList;

	}

	/**
	 * This method is used to check the searched string in component data
	 * @param dataObject
	 * @param matchCase
	 * @param exactWord
	 * @param searchedList
	 * @param iterator
	 */
	private void getSearchedComponentList(String dataObject, boolean matchCase, boolean exactWord,
			List<CategoryAttributes> searchedList, Iterator<CategoryAttributes> iterator) {
		CategoryAttributes catAttributes = (CategoryAttributes) iterator.next();
		String updDataObjName = "";
		//Check for check boxes
		if (exactWord && matchCase) {
			if (catAttributes.getName().equals(dataObject)) {
				searchedList.add(catAttributes);
			}
		} else if (exactWord && !matchCase) {
			if (catAttributes.getName().equalsIgnoreCase(dataObject)) {
				searchedList.add(catAttributes);
			}
		} 
		else if(!exactWord && matchCase){
			updDataObjName = dataObject.replace(MessageConstant.WILD_CARD_CHAR, MessageConstant.CASE_SNSTV_PTRN);
			searchForWildCardCharacter(updDataObjName, searchedList, catAttributes,MessageConstant.CASE_SNSTV_PTRN,MessageConstant.CASE_SNSTV_PTRN);
		}
		else {
			updDataObjName = dataObject.replace(MessageConstant.WILD_CARD_CHAR, MessageConstant.CASE_SNSTV_PTRN);
			searchForWildCardCharacter(updDataObjName, searchedList, catAttributes,"(?i:.*",".*)");
		}
	}

	/**
	 * This method is used to search given string containing wild card character(*) in component data
	 * @param dataObject	
	 * @param searchedList
	 * @param categoryAttributes
	 * @param startPattern
	 * @param endPattern
	 */
	private void searchForWildCardCharacter(String dataObject, List<CategoryAttributes> searchedList,
			CategoryAttributes catAttributes,String startPattern,String endPattern) {
		//Check for wild card character in string
		if (dataObject.contains(MessageConstant.WILD_CARD_CHAR)) {
			String firstCharacter = dataObject.substring(0, 1);
			//Check for first character
			if (firstCharacter.equals(MessageConstant.WILD_CARD_CHAR)) {
				if (catAttributes.getName()
						.matches(startPattern + dataObject.substring(1) + endPattern)) {
					searchedList.add(catAttributes);
				}
			} else {
				if (catAttributes.getName().matches(startPattern + dataObject + endPattern)) {
					searchedList.add(catAttributes);
				}
			}

		} else {
			if (catAttributes.getName().matches(startPattern + dataObject + endPattern)) {
				searchedList.add(catAttributes);
			}
		}
	}
	
	/**
	 * Method used to search data object in closed component
	 * @param component
	 * @param dataObject
	 * @param matchCase
	 * @param exactWord
	 * @return
	 * @throws MatlabCommunicatinException 
	 */
	@Override
	public JsonElement searchDataForCloseComponent(String component, String dataObject, boolean matchCase,
			boolean exactWord) throws MatlabCommunicatinException {		
		
		JsonArray jsonArray = new JsonArray();
		JsonObject jsonObject = new JsonObject();
		jsonObject.addProperty(MatlabQueryConstant.SEARCH_DATA, dataObject);
		jsonObject.addProperty(MatlabQueryConstant.MATCH_CASE, matchCase);
		jsonObject.addProperty(MatlabQueryConstant.EXACT_WORD, exactWord);
		jsonArray.add(jsonObject);
		
		String matlabQuery = CreateMatlabRequest.createMatlabRequest(MatlabScriptConstant.QUERYSEARCHOBJ,
				component, jsonArray.toString());
		
		JsonElement jsonElement = null;
		try
		{
			jsonElement = new MatlabCommunicationDaoImpl().executeMatlabRequest(matlabQuery);
		}
		
		catch(MatlabCommunicatinException e)
		{
			throw new MatlabCommunicatinException(e.getMessage(), e);
		}
		//handled for unknown exchange api error
		if (jsonElement != null && jsonElement.isJsonArray()) {
			JsonElement jsonElement1 = jsonElement.getAsJsonArray().get(0);
			if (jsonElement1.isJsonObject()) {
				if (jsonElement1.getAsJsonObject().has("modelData")) {
					Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
					String msgException = jsonElement1.getAsJsonObject().get("modelData").getAsString();
					MessageDialog.openInformation(shell,ApplicationConstant.INFORMATION,msgException);
					return null;
				}
			}
		}
		return jsonElement;
	}

}
