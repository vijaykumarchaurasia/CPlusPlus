package com.navistar.datadictionary.serviceimpl;

import java.io.File;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PlatformUI;

import com.google.gson.JsonElement;
import com.google.gson.reflect.TypeToken;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.MatlabScriptConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.customexception.EditorInitilizationException;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.daoimpl.MatlabCommunicationDaoImpl;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.model.CategoryAttributesIo;
import com.navistar.datadictionary.model.Project;
import com.navistar.datadictionary.service.UseThisObjectService;
import com.navistar.datadictionary.ui.config.Application;
import com.navistar.datadictionary.ui.config.DataDictionaryApplication;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.ui.nattable.CreateNatTable;
import com.navistar.datadictionary.ui.views.CheckComponentInputsView;
import com.navistar.datadictionary.ui.views.IOCompatibilityView;
import com.navistar.datadictionary.ui.views.ProjectExplorerView;
import com.navistar.datadictionary.util.CreateMatlabRequest;
import com.navistar.datadictionary.util.DataDictionaryUtil;
import com.navistar.datadictionary.util.FileUtility;
import com.navistar.datadictionary.util.GsonUtil;
import com.navistar.datadictionary.util.JSONUtil;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Class implements methods of UseThisObjectService interface to implement
 * use this data object operation.
 * @author nikitak1
 * 
 */
public class UseThisObjectServiceImpl implements UseThisObjectService {

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(UseThisObjectServiceImpl.class);

	/** Object for which user performs Use This Data Object operation */
	private CategoryAttributes dataOfUseThisObj ;
	
	/** Used to store Inconsistent attribute details */
	public Map<String, List<CategoryAttributes>> inconAttrListMap;

	/** Used to store path of browsed CAN excel sheet */
	private String excelPath;
	
	/** Used to check if excel use this object is successful */
	public static boolean useThisFlg;

	/**
	 * Method used to get the data for which user performs 
	 * "Use this Data object" action
	 * @param tree
	 */
	@Override
	public void getObjectToUseForCompIp(Tree tree) {

		try {
			List<CategoryAttributes> dataObjectList = new ArrayList<CategoryAttributes>();
			List<CategoryAttributes> finalObjectList = null;
			if (tree != null) {
				TreeItem selectedNode = tree.getSelection()[0];
				String warningName = selectedNode.getParentItem().getParentItem().getText();
				if (selectedNode.getItemCount() == 0 && (warningName.contains(ApplicationConstant.INCONSISTENT_IOS))) {

					dataObjectList = getDataObjectListForCompIp(selectedNode.getParentItem().getText());

					String useObjectComp = selectedNode.getText().substring(0, selectedNode.getText().indexOf(":")).trim();
					for(CategoryAttributes catAttr : dataObjectList){
						if(catAttr.getComponent().equals(useObjectComp)){
							finalObjectList = new ArrayList<CategoryAttributes>();
							finalObjectList.add(catAttr);
							dataObjectList.remove(catAttr);
							break;
						}
					}
					finalObjectList.addAll(dataObjectList);
					createJsonRequest(finalObjectList);
				}

			}
		} catch (MatlabCommunicatinException | EditorInitilizationException exception) {
			ViewUtil.dispConfirmDialog("Error Message", exception.getMessage());
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, exception);
		}

	}

	/**
	 * Method used to get the data for which user performs 
	 * "Use this Data object" action
	 * @param tree
	 */
	@Override
	public void getObjectToUseForIOComp(Tree tree) {

		try {
			List<CategoryAttributes> dataObjectList = new ArrayList<CategoryAttributes>();
			List<CategoryAttributes> finalObjectList = null;
			if (tree != null) {
				TreeItem selectedNode = tree.getSelection()[0];
				String warningName = selectedNode.getParentItem().getParentItem().getText();
				if (selectedNode.getItemCount() == 0 && (warningName.contains(ApplicationConstant.INCONSISTENT_IOS))) {
					
					dataObjectList = getDataObjectListForIOComp(selectedNode.getParentItem().getText());
					String useObjectName = selectedNode.getText().substring(0, selectedNode.getText().indexOf(":")).trim();
				            
					for(CategoryAttributes catAttr : dataObjectList){
						if(catAttr.getComponent().equals(useObjectName)){
							finalObjectList = new ArrayList<CategoryAttributes>();
							finalObjectList.add(catAttr);
							dataObjectList.remove(catAttr);
							break;
						}
					}
					finalObjectList.addAll(dataObjectList);
					createJsonRequest(finalObjectList);
				}

			}
		} catch (MatlabCommunicatinException | EditorInitilizationException e) {
			ViewUtil.dispConfirmDialog("Error message", e.getMessage());
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
		}

	}

	/**
	 * Method used to get the component list for particular data object for Component Inputs view
	 * @return
	 */
	@Override
	public List<CategoryAttributes> getDataObjectListForCompIp(String dataObjectName) {
		List<CategoryAttributesIo> ioList = new ArrayList<>();
		List<CategoryAttributes> dataObjectList = new ArrayList<>();

		ioList = CheckComponentInputsView.getCompInputsViewInstance().checkCompInMap.get(ApplicationConstant.INCONSISTENT_IOS);
		for(CategoryAttributes catAttr : ioList){
			if(catAttr.getName().equals(dataObjectName)){
				dataObjectList.add(catAttr);
			}

		}

		return dataObjectList;
	}

	/**
	 * Method used to get the component list for particular data object for I/O Compatibility view
	 * @return
	 */
	@Override
	public List<CategoryAttributes> getDataObjectListForIOComp(String dataObjectName) {
		List<CategoryAttributesIo> ioList = new ArrayList<>();
		List<CategoryAttributes> dataObjectList = new ArrayList<>();
		
		ioList = IOCompatibilityView.getIOCompatibilityViewInstance().ioCompatMap.get(ApplicationConstant.INCONSISTENT_IOS);
		for(CategoryAttributesIo catAttr : ioList){
			if(catAttr.getName().equals(dataObjectName)){
				dataObjectList.add(catAttr);
			}

		}

		return dataObjectList;
	}

	/**
	 * Method used to set the component path in Category object to send as Matlab request for use this object
	 * @param componentName
	 */
	@Override
	public String getCompPathForCategory(String componentName){
		String compPath = "";

		String projectPath = ProjectExplorerView.getActiveProject().getPath();
		Set<String> set = FileUtility.slddPathMap.keySet();
		for (String str : set) {

			// get the base name of component path
			File file = new File(str);
			String fileName = FilenameUtils.getBaseName(file.getName());

			if (str.contains(projectPath) && fileName.equals(componentName)) {
				compPath = str.replace("\\", "/");
				break;
			}
		}
		return compPath;		
	}

	/**
	 * Method used to perform operation when user clicks on Use This Data Object option
	 */
	@Override
	public void createJsonRequest(List<CategoryAttributes> categoryList) throws MatlabCommunicatinException, EditorInitilizationException {
		
		try {
			IWorkbenchPart activePart = null;
			String useThisObjectJson = "";
			MatlabCommunicationDaoImpl matlabDataRequest = new MatlabCommunicationDaoImpl();
			Project project = ProjectExplorerView.getActiveProject();
			if(!categoryList.isEmpty()){
				for(CategoryAttributes catAttr : categoryList){
					catAttr.setComponent(getCompPathForCategory(catAttr.getComponent()));
				}
				activePart= PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
						.getActivePart();
				if (activePart.getTitle().equals(ApplicationConstant.IO_COMPATIBILITY)) {
					IOCompatibilityView.getIOCompatibilityViewInstance().ioCompatMap = new IOCompatibilityServiceImpl().convertIOListToMap(Application.ioJsonElement);
				}
				if(activePart.getTitle().equals(ApplicationConstant.COMPONENT_INPUTS)){
					CheckComponentInputsView.getCompInputsViewInstance().checkCompInMap = new CheckComponentInputsServiceimpl().convertCompIOListToMap(Application.compIpJsonElement);
				}

				useThisObjectJson = GsonUtil.provider().toJSON(categoryList);
			}
			String matlabQuery = CreateMatlabRequest.createMatlabRequest(MatlabScriptConstant.QUERYUSEDATAOBJ, project.getPath().replace("\\", "/"), useThisObjectJson);

			dataOfUseThisObj = new CategoryAttributes();
			dataOfUseThisObj=categoryList.get(0);	
			JsonElement jsonResponse = matlabDataRequest.executeMatlabRequest(matlabQuery);
			if(JSONUtil.ifUseThisObjSuccess(jsonResponse)) {
				IEditorPart activeEditor = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
						.getActiveEditor();
				MessageDialog.openInformation(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), ApplicationConstant.SUCCESS, MessageConstant.USE_THIS_SUCCESS);

				if (activePart.getTitle().equals(ApplicationConstant.IO_COMPATIBILITY)) {
					IOCompatibilityView.getIOCompatibilityViewInstance().refreshIOAfterUseThisObj(dataOfUseThisObj);
				}
				if(activePart.getTitle().equals(ApplicationConstant.COMPONENT_INPUTS)){
					CheckComponentInputsView.getCompInputsViewInstance().refreshCompIpAfterUseThisObj(dataOfUseThisObj);
				}
				if(activeEditor instanceof CategoryEditor) {
					updateDataObjectValuesOnUI(categoryList);	
				}
			}
			
			else {
				MessageDialog.openWarning(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), ApplicationConstant.WARNING, MessageConstant.USE_THIS_ERROR);
			}

		} catch (MatlabCommunicatinException e) {
			throw new MatlabCommunicatinException(e.getMessage(), e);
		} catch (EditorInitilizationException e) {
			throw new EditorInitilizationException(e.getMessage(), e);
		}

	}

	/**
	 * Method used to create list for use this object operation using excel
	 * and sldd
	 * @param dataObjectName
	 * @param warningName
	 */
	@Override
	public void getObjectToUseForExcelSldd(String dataObjectName,String warningName) {
		try {
			JsonElement jsonElement = Application.inconAttrJson;
			List<CategoryAttributes> inconAttrList = new ArrayList<>();
			Type type = new TypeToken<List<CategoryAttributes>>() {
			}.getType();
			inconAttrList = GsonUtil.provider().fromJSONToList(jsonElement.toString(), type);
			if(jsonElement.getAsJsonArray().get(0).getAsJsonObject().has("ExcelPath")){
				if(jsonElement.getAsJsonArray().get(0).getAsJsonObject().get("warning").getAsString().equals("Present in excel")) {
					excelPath = jsonElement.getAsJsonArray().get(0).getAsJsonObject().get("ExcelPath").getAsString();
				}else {
					excelPath = jsonElement.getAsJsonArray().get(1).getAsJsonObject().get("ExcelPath").getAsString();
				}
			}
			List<CategoryAttributes> dataObjectList = new ArrayList<>();
			List<CategoryAttributes> exFinalObjectList = new ArrayList<>();
			dataObjectList = getSameObjectListForInconAttr(dataObjectName,inconAttrList);
			for(CategoryAttributes catAttr : dataObjectList){
				if(catAttr.getName().equals(dataObjectName) && catAttr.getWarning().equals(warningName)){
					catAttr.setComponent(new OpenComponentServiceImpl().getOpenedComponentPath());
					if(catAttr.getBaseType().equals("#N/A")) {
						catAttr.setBaseType("");
					}
					if(catAttr.getOffset().equals("#N/A")) {
						catAttr.setOffset("");
					}
					if(catAttr.getSlope().equals("#N/A")) {
						catAttr.setSlope("");
					}
					exFinalObjectList.add(catAttr);
					dataObjectList.remove(catAttr);
					break;
				}
			}
			exFinalObjectList.addAll(dataObjectList);
			createReqForExcelSldd(exFinalObjectList);
			
		} catch (MatlabCommunicatinException mce) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, mce);
			ViewUtil.dispConfirmDialog("Error message", mce.getMessage());
		} catch (EditorInitilizationException eie) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, eie);
		} catch (Exception exception) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, exception);
		}

	}

	/**
	 * Method used to get the same names data object to resolve inconsistencies
	 * between excel sheet and sldd
	 */
	@Override
	public List<CategoryAttributes> getSameObjectListForInconAttr(String dataObjName,List<CategoryAttributes> inconAttrList) {
		List<CategoryAttributes> dataObjectList = new ArrayList<>();

		for(CategoryAttributes catAttr : inconAttrList){
			if(catAttr.getName().equals(dataObjName)){
				catAttr.setComponent(new OpenComponentServiceImpl().getOpenedComponentPath());
				dataObjectList.add(catAttr);
			}

		}

		return dataObjectList;
	}

	/**
	 * Method used to create MATLAB request to perform Use this object
	 * for excel and sldd inconsistent attributes
	 */
	@Override
	public void createReqForExcelSldd(List<CategoryAttributes> categoryList)
			throws MatlabCommunicatinException, EditorInitilizationException {
		try {
			String useThisObjectJson = "";
			MatlabCommunicationDaoImpl matlabDataRequest = new MatlabCommunicationDaoImpl();
			
			if(!categoryList.isEmpty()){
				useThisObjectJson = GsonUtil.provider().toJSON(categoryList);
			}
			String matlabQuery = CreateMatlabRequest.createMatlabRequest(MatlabScriptConstant.EXCELUSETHISOBJ,excelPath.replace("\\", "/"), useThisObjectJson);
			dataOfUseThisObj = new CategoryAttributes();
			dataOfUseThisObj=categoryList.get(0);	
			JsonElement jsonResponse = matlabDataRequest.executeMatlabRequest(matlabQuery);
			boolean isSuccess= new ExcelImportExportServiceImpl().checkMatlabRespCode(jsonResponse);
			if(isSuccess) {
				useThisFlg=true;
			}
			
		} catch (MatlabCommunicatinException mce) {
			throw new MatlabCommunicatinException(mce.getMessage(), mce);
			
		} 
		
	}
	
	/**
	 * Method used to update values in category table after Use this data object 
	 */
	@Override
	public void updateDataObjectValuesOnUI(List<CategoryAttributes> objToRepList) {
		Map<String, List<CategoryAttributes>> componentMapList = DataDictionaryApplication.getApplication()
				.getComponentMapList();
		IWorkbenchPage activePage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();	
		IEditorReference[] editorRef = activePage.getEditorReferences();
		if (componentMapList != null) {
			// using for-each loop for iteration over Map.entrySet()
			for (Map.Entry<String, List<CategoryAttributes>> entry : componentMapList.entrySet()) {
				String category;	 
				List<CategoryAttributes> categoryList = entry.getValue();
				for (Iterator<CategoryAttributes> iterator = categoryList.iterator(); iterator.hasNext();) {
					CategoryAttributes catAttributes = (CategoryAttributes) iterator.next();
					//CategoryAttributes object = objToRepList.get(1);
					CategoryAttributes newObject = objToRepList.get(0);
					for(int count=0;count<objToRepList.size();count++) {
						CategoryAttributes object = objToRepList.get(count);
						if(object.getName().equals(catAttributes.getName()) && object.getComponent().equals(new OpenComponentServiceImpl().getOpenedComponentPath())) {
							category = object.getCategory();
							for(IEditorReference editor : editorRef){
								IEditorPart editorPart = editor.getEditor(false);
								if(editorPart instanceof CategoryEditor && editorPart.getTitle().equals(category)){
									setUseThisDataInCategoryTable(activePage, category, newObject, editorPart);
								}
							}
						}
					}
				}
			}
		}
	}

  /**
   * Method used to set attributes values in particular category after Use this data object operation
   */
  @Override
  public void setUseThisDataInCategoryTable(IWorkbenchPage activePage, String category, CategoryAttributes object,
			IEditorPart editorPart){
		CategoryEditor categoryEditor = (CategoryEditor)editorPart;
		int searchedIndex = DataDictionaryUtil.searchIndex(object.getName(), new OpenComponentServiceImpl().getOpenedComponentName(), category,
				categoryEditor.createNatTable.getJsonDataProvider().getList());
		categoryEditor.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colDescIdx,
				searchedIndex, object.getDescription());
		categoryEditor.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colBaseTyIdx,
				searchedIndex, object.getBaseType());
		categoryEditor.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colSlopIdx,
				searchedIndex, object.getSlope());
		categoryEditor.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colOffIdx,
				searchedIndex, object.getOffset());
		categoryEditor.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colIniValIdx,
				searchedIndex, object.getInitialValue());
		categoryEditor.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colMinIdx,
				searchedIndex, object.getMin());
		categoryEditor.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colMaxIdx, 
				searchedIndex, object.getMax());
		categoryEditor.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colUnitIdx,
				searchedIndex, object.getUnit());
		categoryEditor.createNatTable.getJsonDataProvider().setDataValue(CreateNatTable.colDimIdx,
				searchedIndex, object.getDimensions());
		
		categoryEditor.natTable.addConfiguration(categoryEditor);	
		categoryEditor.natTable.refresh();
		activePage.activate(categoryEditor);
	}
	
}
