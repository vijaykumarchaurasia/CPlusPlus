package com.navistar.datadictionary.serviceimpl;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.MatlabScriptConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.customexception.EditorInitilizationException;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.daoimpl.MatlabCommunicationDaoImpl;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.service.FindInModelService;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.ui.nattable.CreateNatTable;
import com.navistar.datadictionary.ui.views.ProjectExplorerView;
import com.navistar.datadictionary.util.CreateMatlabRequest;
import com.navistar.datadictionary.util.JSONUtil;

/**
 * Class implements methods of FindInModelService interface to implement find in model operation.
 * @author JAYSHRIVISHB
 *
 */
public class FindInModelServiceImpl implements FindInModelService {

	/** Used to access nattable properties */
	public CreateNatTable createNatTable = new CreateNatTable();
	
	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(FindInModelServiceImpl.class);

	/**
	 * Method to highlight the model element in Matlab model
	 * @throws MatlabCommunicatinException 
	 * @throws EditorInitilizationException 
	 */
	@Override
	public void highlightInModel() throws MatlabCommunicatinException, EditorInitilizationException {
		
		MatlabCommunicationDaoImpl matlabDataRequest = new MatlabCommunicationDaoImpl();
		OpenComponentServiceImpl openCompService = new OpenComponentServiceImpl();
		
		//Get active page
		IWorkbenchPage page = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
		IEditorPart activeEditor = page.getActiveEditor();
		
		
		try {
			CategoryEditor activeCatEditor = (CategoryEditor)activeEditor;
			page.showView(ViewIDConstant.PROJ_EXPLORER);
			
			String modelPath = openCompService.getOpenedComponentPath();
			modelPath = modelPath.replace("\\", "/");
			CategoryAttributes category = new CategoryAttributes();
			category.setName(activeCatEditor.selDataObj);
			String projectPath = ProjectExplorerView.getActiveProject().getPath().replace("\\", "/");
			Gson gson = new Gson();
			String jsonStr = gson.toJson(category);
			jsonStr = "["+jsonStr+"]";
			
			String matlabQuery = CreateMatlabRequest.createMatlabRequest(MatlabScriptConstant.FIND_IN_MODEL, modelPath+","+projectPath, jsonStr);
		
			JsonElement jsonElement = null;
			try
			{
				jsonElement = matlabDataRequest.executeMatlabRequest(matlabQuery);	
			}
			catch(MatlabCommunicatinException e)
			{
				throw new MatlabCommunicatinException(e.getMessage(), e);
			}
		
			Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
			if(!JSONUtil.checkErrorCodeForNoModel(jsonElement))
			{
				MessageDialog.openInformation(shell,ApplicationConstant.INFORMATION,MessageConstant.MODEL_NOT_FOUND);
			}else {
				if(!JSONUtil.checkForErrorCode(jsonElement))
				{
					MessageDialog.openInformation(shell,ApplicationConstant.INFORMATION,MessageConstant.OBJECT_NOT_FOUND);
				}
				if(!JSONUtil.checkForNoMsgException(jsonElement)) {
					if (jsonElement != null && jsonElement.isJsonArray()) {
						JsonElement jsonElement1 = jsonElement.getAsJsonArray().get(0);
						if (jsonElement1.isJsonObject()) {
							if (jsonElement1.getAsJsonObject().has("modelData")) {
								String msgException = jsonElement1.getAsJsonObject().get("modelData").getAsString();
								MessageDialog.openInformation(shell,ApplicationConstant.INFORMATION,msgException);
							}
						}
					}
				}
			}
			
		} catch (PartInitException e) {
			LOGGER.log(Level.ERROR,MessageConstant.EXCEPTION_IN_LOG,e);
			throw new EditorInitilizationException("Failed to load the editor", e);
		}
	}

}
