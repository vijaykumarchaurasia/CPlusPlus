package com.navistar.datadictionary.serviceimpl;

import java.io.File;
import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.io.FilenameUtils;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.PlatformUI;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.MatlabQueryConstant;
import com.navistar.datadictionary.constant.MatlabResponseConstant;
import com.navistar.datadictionary.constant.MatlabScriptConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.daoimpl.MatlabCommunicationDaoImpl;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.model.CategoryAttributesIo;
import com.navistar.datadictionary.model.Project;
import com.navistar.datadictionary.service.CheckComponentInputsService;
import com.navistar.datadictionary.ui.config.Application;
import com.navistar.datadictionary.ui.config.DataDictionaryApplication;
import com.navistar.datadictionary.ui.views.ProjectExplorerView;
import com.navistar.datadictionary.util.CreateMatlabRequest;
import com.navistar.datadictionary.util.FileUtility;
import com.navistar.datadictionary.util.GsonUtil;
import com.navistar.datadictionary.util.JSONUtil;
import com.navistar.datadictionary.util.JsontoList;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Class implements methods of CheckComponentInputsService interface to implement Component Inputs operations.
 * @author nikitak1
 *
 */

public class CheckComponentInputsServiceimpl implements CheckComponentInputsService {

	/**
	 * Method is used to get the Check Component Inputs list data after querying matlab script.
	 * @throws MatlabCommunicatinException 
	 */
	@Override
	public JsonElement getComponentInputsData() throws MatlabCommunicatinException {
		JsonElement jsonElement = null;
		MatlabCommunicationDaoImpl matlabDataRequest = new MatlabCommunicationDaoImpl();

		Project project = ProjectExplorerView.getActiveProject();
		if (project.getComponentPath() != null) {

			OpenComponentServiceImpl openCompService = new OpenComponentServiceImpl();
			String slddPath = openCompService .getOpenedComponentPath();
			CategoryAttributes category = new CategoryAttributes();

			category.setName(slddPath);
			Gson gson = new Gson();
			String jsonStr = gson.toJson(category);
			jsonStr = "["+jsonStr+"]";
			if(Application.programName.equals("E44"))
			{
				String matlabQuery = CreateMatlabRequest.createMatlabRequest(MatlabScriptConstant.CHECKCOMPINPUTS, project.getPath().replace("\\", "/"), jsonStr.replace("\\", "/"));
				try
				{
					jsonElement = matlabDataRequest.executeMatlabRequest(matlabQuery);
				}
				catch(MatlabCommunicatinException e)
				{
					throw new MatlabCommunicatinException(e.getMessage(), e);
				}		
		   }

			else
			{
				
				String matlabQuery = CreateMatlabRequest.createMatlabRequest(MatlabScriptConstant.CHECKCOMPINPUTS_E95, project.getPath().replace("\\", "/"), jsonStr.replace("\\", "/"));
			try
			{
				jsonElement = matlabDataRequest.executeMatlabRequest(matlabQuery);
						//new FileUtility().readFromJsonFile("C:\\Users\\shalins\\Desktop\\E_95_8.json");
						//matlabDataRequest.executeMatlabRequest(matlabQuery);
			}
			catch(MatlabCommunicatinException e)
			{
				throw new MatlabCommunicatinException(e.getMessage(), e);
			}	
			
				
			}
			Application.compIpJsonElement = jsonElement;
		}

		return jsonElement;
	}
	
	public String getArxmlPath() {
		Map<String, List<String>> map = FileUtility.arxmlPrjMap;
		String componentName = "null";
		File openedProjectPath =new File( ProjectExplorerView.getActiveProject().getPath());
		List<String> compFromMap =map.get(openedProjectPath.getName());
		for (String str : compFromMap) {
			File file = new File(str);
			File compName = new File(OpenComponentServiceImpl.selCompName);
			// get the base name of component path
			String fileName = FilenameUtils.getBaseName(file.getName()).toLowerCase();

			if (fileName.equals(FilenameUtils.getBaseName(compName.getName()))) {
				componentName = str;
			}
		}
		
		
		return componentName.replace("\\", "/");			

	}
	
	

	/**
	 * Method is used to parse JSON data and convert into HashMap.
	 * 
	 * @param jsonElement
	 * @return compIOListMap
	 */
	@Override
	public Map<String, List<CategoryAttributesIo>> convertCompIOListToMap(JsonElement jsonElement) {
		Map<String, List<CategoryAttributesIo>> compIOListMap = new LinkedHashMap<String, List<CategoryAttributesIo>>();
	//	Type type = new TypeToken<List<CategoryAttributesIo>>() {
	//	}.getType();

		if (jsonElement != null) {
			//CategoryAttributesIo attributes =  new CategoryAttributesIo();
			// Check if empty JSON element
			if(JSONUtil.checkIfNoCompInputsPresent(jsonElement)) {
				return null;
			}
			else if (JSONUtil.checkIOCompatibilityIsEmpty(jsonElement)) {
				compIOListMap = dispE44Warng(compIOListMap);
					
			}
				
				//Check if empty JSON element in E_95
				else if (JSONUtil.checkIOCompatibilityIsEmptyE95(jsonElement)) {
					
					Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
					MessageDialog.openInformation(shell, ApplicationConstant.INFORMATION,MessageConstant.IO_COMP_ARXML_ERROR);
					compIOListMap = dispE95Warng(compIOListMap);
		
					
				}
			else {
				// Parse the JSON details and convert into Map
				for (JsonElement jsonArray : jsonElement.getAsJsonArray()) {

					// check for error code and set error message accordingly
					compIOListMap = checkErrNMsg(jsonArray, compIOListMap);
					}

			}
		
		}
		return compIOListMap;

	}
	
	public Map<String, List<CategoryAttributesIo>> checkErrNMsg (JsonElement jsonArray, Map<String, List<CategoryAttributesIo>> compIOListMap)
	{
		//Map<String, List<CategoryAttributesIo>> compIOListMap = new LinkedHashMap<String, List<CategoryAttributesIo>>();
		if (jsonArray != null && jsonArray.isJsonArray()) {
			JsonElement errorObject = jsonArray.getAsJsonArray().get(0);

			if (errorObject.isJsonObject() && errorObject.getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)) {
				String errorValue = errorObject.getAsJsonObject().get(MatlabQueryConstant.ERROR_CODE).getAsString();
				CategoryAttributesIo catAttributes =  new CategoryAttributesIo();	
				switch (errorValue) {
				case MatlabResponseConstant.COMP_NO_INCON_IP:
					catAttributes.setWarning(ApplicationConstant.INCONSISTENT_IOS+" "+ApplicationConstant.NO_ISSUES);	
					compIOListMap.put(ApplicationConstant.INCONSISTENT_IOS, Arrays.asList(catAttributes));
					break;

				case MatlabResponseConstant.COMP_NO_UNCONN_IP:
					catAttributes.setWarning(ApplicationConstant.UNCONNECTED_IP+" "+ApplicationConstant.NO_ISSUES);		
					compIOListMap.put(ApplicationConstant.UNCONNECTED_IP, Arrays.asList(catAttributes));
					break;
				
				case MatlabResponseConstant.COMP_NO_INCON_NRML_IP:
					catAttributes.setWarning(ApplicationConstant.INCONSISTENT_IOS_NORMAL+" "+ApplicationConstant.NO_ISSUES);				
					compIOListMap.put(ApplicationConstant.INCONSISTENT_IOS_NORMAL, Arrays.asList(catAttributes));	
					break;
				case MatlabResponseConstant.COMP_NO_INCON_STRUC_IP:
					catAttributes.setWarning(ApplicationConstant.INCONSISTENT_IOS_STRUCTURE+" "+ApplicationConstant.NO_ISSUES);				
					compIOListMap.put(ApplicationConstant.INCONSISTENT_IOS_STRUCTURE, Arrays.asList(catAttributes));	
					break;

				} 
			  }
			
			else
			{
				String updatedArray = jsonArray.toString().replaceAll("Null", "");
			//	List<CategoryAttributes> checkCompIpsList = GsonUtil.provider().fromJSONToList(updatedArray,
			//		type);
				List<CategoryAttributesIo> checkCompIpsList = JsontoList.replaceEmptyBracketsMinMax(updatedArray);
				
				if (checkCompIpsList != null && !checkCompIpsList.isEmpty()) {
					CategoryAttributesIo iOCompatDAO = checkCompIpsList.get(0);
					compIOListMap.put(iOCompatDAO.getWarning(), checkCompIpsList);
				}
			}

		}
		return compIOListMap;
	}
	
	
	public Map<String, List<CategoryAttributesIo>> dispE95Warng( Map<String, List<CategoryAttributesIo>> compIOListMap)
	{
		for(int count=1;count<4;count++)
		{
			CategoryAttributesIo attributes =  new CategoryAttributesIo();
			
			switch(count)
			{
			case 1: 
				attributes.setWarning(ApplicationConstant.INCONSISTENT_IOS_NORMAL+" "+ApplicationConstant.NO_ISSUES);				
				compIOListMap.put(ApplicationConstant.INCONSISTENT_IOS_NORMAL, Arrays.asList(attributes));
				break;
			case 2:
				attributes.setWarning(ApplicationConstant.INCONSISTENT_IOS_STRUCTURE+" "+ApplicationConstant.NO_ISSUES);				
				compIOListMap.put(ApplicationConstant.INCONSISTENT_IOS_STRUCTURE, Arrays.asList(attributes));
				break;
			case 3:
				attributes.setWarning(ApplicationConstant.UNCONNECTED_IP+" "+ApplicationConstant.NO_ISSUES);				
				compIOListMap.put(ApplicationConstant.UNCONNECTED_IP, Arrays.asList(attributes));
				break;
			
			}
		}
		return  compIOListMap;
	}
	
	
	public Map<String, List<CategoryAttributesIo>> dispE44Warng( Map<String, List<CategoryAttributesIo>> compIOListMap)
	{
		for(int count=1; count<3; count++)
		{
			CategoryAttributesIo attributes =  new CategoryAttributesIo();
			switch(count)
			{
			case 1:
				attributes.setWarning(ApplicationConstant.INCONSISTENT_IOS+" "+ApplicationConstant.NO_ISSUES);				
				compIOListMap.put(ApplicationConstant.INCONSISTENT_IOS, Arrays.asList(attributes));	
				break;

			case 2:
				attributes.setWarning(ApplicationConstant.UNCONNECTED_IP+" "+ApplicationConstant.NO_ISSUES);				
				compIOListMap.put(ApplicationConstant.UNCONNECTED_IP, Arrays.asList(attributes));
				break;
			}
		}
		return  compIOListMap;
	}
	

	/**
	 * Method used to close the Component Inputs window
	 */
	@Override
	public void closeCheckCompInputsWindow() {
		IViewPart checkCompIpview = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().findView(ViewIDConstant.COMP_INPUTS);
		if(checkCompIpview != null){
			ViewUtil.showHideView(ViewIDConstant.COMP_INPUTS, false);
		}
		
	}
	/**
	 * Method used to refresh Component Inputs view after deleting the data object 
	 * @param warningName
	 * @param componentName
	 * @param objectName
	 * @param categoryName
	 * 
	 */
	@Override
	public void updateCompInputsData(String warningName, String componentName, String objectName,
			String categoryName) {
		
		GsonUtil gsonUtil = GsonUtil.provider();
		Type type = new TypeToken<List<CategoryAttributes>>() {}.getType();
		JsonArray updatedCompArray = new JsonArray();
		for (JsonElement jsonArray : Application.compIpJsonElement.getAsJsonArray()) {

			// check for error code and set error message accordingly
			if (jsonArray != null && jsonArray.isJsonArray()) {
				JsonElement errorObject = jsonArray.getAsJsonArray().get(0);
				if (errorObject.isJsonObject() && errorObject.getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)) {
					updatedCompArray.add((JsonArray)jsonArray);
				}
				else
				{
					List<CategoryAttributes> ioCompatDataList = gsonUtil.fromJSONToList(jsonArray.toString(),type);					
					for (Iterator<CategoryAttributes> iterator = ioCompatDataList.iterator(); iterator.hasNext();) {
						CategoryAttributes catAttributes = (CategoryAttributes) iterator.next();

						if (catAttributes.getComponent().equals(componentName)
								&& catAttributes.getName().equals(objectName)
								&& catAttributes.getCategory().equals(categoryName)) {
							ioCompatDataList.remove(catAttributes);
							break;
						}

					}

					updatedCompArray.add((JsonArray) new JsonParser().parse(new Gson().toJson(ioCompatDataList, type)));

				}

			}

		}

		// Update Application.compIpJsonElement
		Application.compIpJsonElement = updatedCompArray;
		
		DataDictionaryApplication.getApplication().setCheckCompIpStatus(false);

		/*ViewUtil.closeView(ViewIDConstant.COMPONENT_INPUTS_ID);
		ViewUtil.showHideView(ViewIDConstant.COMPONENT_INPUTS_ID, true);*/
		

	}


}
