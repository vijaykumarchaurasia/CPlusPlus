package com.navistar.datadictionary.serviceimpl;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.google.gson.JsonElement;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.daoimpl.MatlabCommunicationDaoImpl;
import com.navistar.datadictionary.model.Project;
import com.navistar.datadictionary.service.ValidatProjParamService;
import com.navistar.datadictionary.ui.config.Application;
import com.navistar.datadictionary.ui.views.ProjectExplorerView;
import com.navistar.datadictionary.util.CreateMatlabRequest;
import com.navistar.datadictionary.util.JSONUtil;

/**
 * Class implements methods for ValidatProjParamService for validating hidden object
 * parameters for opened component and project.
 * @author nikitak1
 *
 */
public class ValidateProjParamServiceImpl implements ValidatProjParamService{

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(ValidateProjParamServiceImpl.class);

	@Override
	public JsonElement createValidCompParamReq() throws MatlabCommunicatinException {
		JsonElement jsonElement = null;
		String componentPath = new OpenComponentServiceImpl().getOpenedComponentPath();
		componentPath = componentPath.replace("\\", "/");
		MatlabCommunicationDaoImpl matlabCommDaoImpl = new MatlabCommunicationDaoImpl();
		Project project = ProjectExplorerView.getActiveProject();

		if (project.getComponentPath() != null) {

		//	String matlabQuery = CreateMatlabRequest.createMatlabRequest("ValidationOfSldd",
		//			componentPath, "");
		//	
			String matlabQuery = CreateMatlabRequest.createMatlabRequest("ValidationOfSldd",
					componentPath+","+Application.projConfigPath.replace("\\", "/")+","+Application.programName, "");
			try
			{
				jsonElement = matlabCommDaoImpl.executeMatlabRequest(matlabQuery);
			}
			catch(MatlabCommunicatinException e)
			{
				LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
				throw new MatlabCommunicatinException(e.getMessage(), e);
			}

		}

		return jsonElement;
		
	}

	@Override
	public JsonElement createValidProjParamReq() throws MatlabCommunicatinException {
		JsonElement jsonElement = null;
		MatlabCommunicationDaoImpl matlabCommDaoImpl = new MatlabCommunicationDaoImpl();
		Project project = ProjectExplorerView.getActiveProject();

		if (project.getPath() != null) {

		//	String matlabQuery = CreateMatlabRequest.createMatlabRequest("ValidationOfSldd",
		//			project.getPath().replace("\\", "/"), "");
			String matlabQuery = CreateMatlabRequest.createMatlabRequest("ValidationOfSldd",
					project.getPath().replace("\\","/")+","+Application.projConfigPath.replace("\\", "/")+","+Application.programName, "");
	
			try
			{
				jsonElement = matlabCommDaoImpl.executeMatlabRequest(matlabQuery);
				if (!JSONUtil.checkForErrorCode(jsonElement))
				{
					return null;
				}
			}
			catch(MatlabCommunicatinException e)
			{
				LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
				throw new MatlabCommunicatinException(e.getMessage(), e);
			}

		}

		return jsonElement;
		
	}

}