package com.navistar.datadictionary.serviceimpl;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;

import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.customexception.EditorInitilizationException;
import com.navistar.datadictionary.customexception.EditorReuseException;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.model.CategoryAttributesIo;
import com.navistar.datadictionary.model.Node;
import com.navistar.datadictionary.model.Project;
import com.navistar.datadictionary.service.OpenComponentService;
import com.navistar.datadictionary.ui.config.Application;
import com.navistar.datadictionary.ui.config.DataDictionaryApplication;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.ui.editors.ComponentIpEditor;
import com.navistar.datadictionary.ui.editors.ComponentIpEditorInput;
import com.navistar.datadictionary.ui.editors.IOCompatibilityEditor;
import com.navistar.datadictionary.ui.editors.IOCompatibilityEditorInput;
import com.navistar.datadictionary.ui.views.ProjectExplorerView;
import com.navistar.datadictionary.util.DataDictionaryUtil;
import com.navistar.datadictionary.util.FileUtility;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Class implements methods of OpenComponentService interface to implement open component operation.
 * @author JAYSHRIVISHB
 *
 */
public class OpenComponentServiceImpl implements OpenComponentService{
	


	/**Used to validate close projects*/
	private CloseProjectServiceImpl closeProjService = new CloseProjectServiceImpl();

	/** It is used to store the selected component */
	public static String selCompName;

	/** Instance of ImportProjectStructureService */
	private ImportProjectServiceImpl importService = new ImportProjectServiceImpl();

	/** Used to access check editors */
	private EditorServiceImpl editorService = new EditorServiceImpl();

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(OpenComponentServiceImpl.class);
	
	
	public OpenComponentServiceImpl(){	
	}


	/**
	 * Method is used to validate the dirty editors
	 * @throws MatlabCommunicatinException 
	 * @throws EditorReuseException 
	 * @throws EditorInitilizationException 
	 */
	@Override
	public void validateEditors(TreeViewer viewer) throws MatlabCommunicatinException, EditorReuseException, EditorInitilizationException {

		IEditorPart activeEditor = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor();
		


		try {
			// Check if any editor is having unsaved data
			if (editorService.checkForUnsavedEditors()) {
				int result = closeProjService.closeProjectHandler(false,2);
				CategoryEditor categoryEditor = null;

				if(activeEditor!=null && !activeEditor.getTitle().equals(ApplicationConstant.WELCOME_NOTE))
				{
					categoryEditor = (CategoryEditor) activeEditor;
				}
				// if user choose to save all
				if (result == 0 && !categoryEditor.emptyFieldFlag) {
					// Close all editors of component
					editorService.closeAllEditors();

					// Open a categories of selected component in editor
					openComponentInEditor(viewer);
				}else if(result == 1){
					//remove unsaved changes and load tab with saved data
					editorService.removeDirtyIndicator();
					// Close all editors of component
					editorService.closeAllEditors();
					// Open a categories of selected component in editor
					openComponentInEditor(viewer);
				}
			} else {
				// Close all editors of component
				editorService.closeAllEditors();

				// Open a categories of selected component in editor
				openComponentInEditor(viewer);
			}
		}
		catch (FileNotFoundException e)
		{
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			throw new EditorInitilizationException(e.getMessage(), e);
		}
		catch (MatlabCommunicatinException e)
		{
			throw new MatlabCommunicatinException(e.getMessage(), e);
		} catch (EditorReuseException e) {

			throw new EditorReuseException(e.getMessage(), e);

		} catch (EditorInitilizationException e) {

			throw new EditorInitilizationException(e.getMessage(), e);
		}
	}

	/**
	 * Method used to open selected component in editor
	 * 
	 * @param viewer
	 * @throws FileNotFoundException
	 * @throws MatlabCommunicatinException 
	 * @throws EditorReuseException 
	 * @throws EditorInitilizationException 
	 */
	@Override
	public boolean openComponentInEditor(TreeViewer viewer) throws FileNotFoundException, MatlabCommunicatinException, EditorReuseException, EditorInitilizationException {
		boolean status = false;
		if( Application.count ==-1)
		{
		 Application.compName = getSelectedComponentName(viewer);	
		 
		}
		selCompName = Application.compName;	
		
		// Reset previous Values before opening component
		CategoryEditor.deletedListMap = new HashMap<String,List<CategoryAttributes>>();
		CategoryEditor.allNewObjList = new ArrayList<CategoryAttributes>();
		
		ViewUtil.closeView(ViewIDConstant.MIN_MAX_INFO);
		//Close the table editor if opened
		IViewPart view = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().findView(ViewIDConstant.TABLE_EDITOR);
		if(view != null){
			ViewUtil.showHideView(ViewIDConstant.TABLE_EDITOR, false);	
		}
		CheckComponentInputsServiceimpl checkCompInObj =  new CheckComponentInputsServiceimpl();
		checkCompInObj.closeCheckCompInputsWindow();
		DataDictionaryApplication.getApplication().setOutputSignalJson(null);
		ViewUtil.closeView(ViewIDConstant.OUTPUT_DATA_OBJ);
		
		try {
					
			status = editorService.displayComponentCategories(Application.compName, viewer);	
		} catch (MatlabCommunicatinException e) {
			throw new MatlabCommunicatinException(e.getMessage(), e);
		}
		catch(EditorReuseException e) {
			throw new EditorReuseException(e.getMessage(), e);
		}
		catch (EditorInitilizationException e) {
			throw new EditorInitilizationException(e.getMessage(), e);
		} 
		
		return status;
	}

	/**
	 * Method is used to get selected component name from project tree
	 * @param viewer
	 */
	@Override
	public String getSelectedComponentName(TreeViewer viewer) {
		String openedProjectPath = ProjectExplorerView.getActiveProject().getPath();

		IStructuredSelection thisSelection = (IStructuredSelection) viewer.getSelection();
		Node selectedNode = (Node) thisSelection.getFirstElement();
		Node parentNode = selectedNode;
		String componentName = "";
		if(parentNode != null) {
			while (null != parentNode.getParent()) {
				parentNode = parentNode.getParent();
			}
			Map<String, String> map = FileUtility.slddPathMap;

			Set<String> set = map.keySet();
			for (String str : set) {

				// get the base name of component path
				File file = new File(str);
				String fileName = FilenameUtils.getBaseName(file.getName());

				if (str.contains(openedProjectPath) && fileName.equals(selectedNode.getName())) {
					componentName = str;
				}
			}

			componentName = componentName.replace("\\", "/");			

			if(DataDictionaryApplication.getApplication().isSearchedHighLight())
			{

				ProjectExplorerView.viewer.setSelection(thisSelection);

				CategoryAttributes catAttributes = DataDictionaryApplication.getApplication().getSearchedHighlighted();
				componentName = DataDictionaryUtil.getComponentPathByName(catAttributes.getComponent());
				importService.updateProjectStatus(DataDictionaryUtil.getProjectNameFromPath(ProjectExplorerView.getActiveProject().getPath()), ApplicationConstant.OPEN_PROJ_STATUS,
						componentName);	

			}
			else
			{
				importService.updateProjectStatus(parentNode.getName(), ApplicationConstant.OPEN_PROJ_STATUS,
						componentName);			
			}
			selCompName = componentName;


			return componentName;
		}
		else if(DataDictionaryApplication.getApplication().isSearchedHighLight())
		{
			ProjectExplorerView.viewer.setSelection(thisSelection);

			CategoryAttributes catAttributes = DataDictionaryApplication.getApplication().getSearchedHighlighted();
			componentName = DataDictionaryUtil.getComponentPathByName(catAttributes.getComponent());
			importService.updateProjectStatus(DataDictionaryUtil.getProjectNameFromPath(ProjectExplorerView.getActiveProject().getPath()), ApplicationConstant.OPEN_PROJ_STATUS,
					componentName);
			selCompName = componentName;
			return componentName;
		}
		else {
			return "";
		}

	}


	/**
	 * Method is used to open editors for selected open component's categories
	 * @param dataObject
	 * @param componentName
	 * @param categoryName
	 * @param ioCompatibilityList
	 * @throws EditorInitilizationException 
	 */
	@Override
	public void findAndOpenComponent(String dataObject, String componentName, String categoryName,
			List<CategoryAttributesIo> ioCompatList) throws EditorInitilizationException {
		IOCompatibilityEditorInput iOCompatEditIn = new IOCompatibilityEditorInput(dataObject,componentName,categoryName,ioCompatList);
		// get the Active page		
		IWorkbenchPage activePage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();		

		try {
			activePage.openEditor(iOCompatEditIn, IOCompatibilityEditor.EDITOR_ID);
			activePage.activate(activePage.findView(ViewIDConstant.CHECK_IO_COMPAT));
		} catch (PartInitException e) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			throw new EditorInitilizationException("Error while finding and opening component", e);
		}
	}

	/**
	 * Method is used to open editors for selected open component's categories
	 * @param dataObject
	 * @param componentName
	 * @param categoryName
	 * @param compIpList
	 */
	@Override
	public void openComponentForCompEditor(String dataObject, String componentName, String categoryName,
			List<CategoryAttributesIo> compIpList) {
		ComponentIpEditorInput compIpEditorInput = new ComponentIpEditorInput(dataObject,componentName,categoryName,compIpList);
		// get the Active page		
		IWorkbenchPage activePage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();		

		try {
			activePage.openEditor(compIpEditorInput, ComponentIpEditor.EDITOR_ID);
			activePage.activate(activePage.findView(ViewIDConstant.COMP_INPUTS));
		} catch (PartInitException e) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
		}


	}

	/**
	 * Method used to get the path of open component
	 * @return
	 */
	@Override
	public String getOpenedComponentPath() {

		Project project = ProjectExplorerView.getActiveProject();

		return project.getComponentPath();
	}
	/**
	 * Method used to get the name of opened component
	 * @return
	 */
	@Override
	public String getOpenedComponentName() {
		// TODO Auto-generated method stub
		String openedCompPath=getOpenedComponentPath();
		if(openedCompPath!="")
		{
			// get the base name of component path
			File file = new File(openedCompPath);
			String openedCompName = FilenameUtils.getBaseName(file.getName());
			return openedCompName;			
		}
		return "";

	}
}

