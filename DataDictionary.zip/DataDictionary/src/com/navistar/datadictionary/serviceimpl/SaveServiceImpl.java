package com.navistar.datadictionary.serviceimpl;

import java.lang.reflect.Type;
import java.util.List;

import org.apache.log4j.Logger;

import com.google.gson.JsonElement;
import com.google.gson.reflect.TypeToken;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.daoimpl.MatlabCommunicationDaoImpl;
import com.navistar.datadictionary.model.SaveResponseCode;
import com.navistar.datadictionary.service.SaveService;
import com.navistar.datadictionary.ui.config.Application;
import com.navistar.datadictionary.util.CreateMatlabRequest;
import com.navistar.datadictionary.util.GsonUtil;
import com.navistar.datadictionary.util.JSONUtil;

/**
 * Class implements methods of SaveService interface to implement save data operation.
 * @author JAYSHRIVISHB
 *
 */
public class SaveServiceImpl implements SaveService{
	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(SaveServiceImpl.class);
	/** Used to execute matlab request */
	MatlabCommunicationDaoImpl matlabComm = new MatlabCommunicationDaoImpl();
	/**unsaved category list*/
	List<SaveResponseCode> unsavedCatList;
	
	/**
	 * Method is used to set the save edited categories data
	 * @param queryName
	 * @param componentName
	 * @param dataObject
	 * @throws MatlabCommunicatinException 
	 */
	@Override
	public boolean saveCategoryData(String queryName, String componentName, String dataObject) throws MatlabCommunicatinException {
		boolean status = false;
		GsonUtil gsonUtil = GsonUtil.provider();
		Type type = new TypeToken<List<SaveResponseCode>>(){}.getType();
		
		String matlabQuery = CreateMatlabRequest.createMatlabRequest(queryName, componentName+","+Application.projConfigPath.replace("\\", "/")+","+Application.programName, dataObject);
		JsonElement jsonElement = null;
		LOGGER.info("matlabQuery : "+ matlabQuery);
		try
		{
			jsonElement = matlabComm.executeMatlabRequest(matlabQuery);
		}
		catch(MatlabCommunicatinException e)
		{
			throw new MatlabCommunicatinException(e.getMessage(), e);
		}
		
		if (JSONUtil.checkForSaveErrorCode(jsonElement)) {
			status = true;
		} else {
			if (jsonElement.isJsonArray()) {
				unsavedCatList = gsonUtil.fromJSONToList(jsonElement.getAsJsonArray().toString(), type);
				setUnsavedCategoryList(unsavedCatList);
				status = false;
			}
		}		
		return status;
	}
		
	/**
	 * Method used to get unsaved category list
	 * @return
	 */
	public List<SaveResponseCode> getUnsavedCategoryList(){
		return this.unsavedCatList;
	}
	
	/**
	 * Method used to set unsaved category list
	 */
	public void setUnsavedCategoryList(List<SaveResponseCode> unsavedCatList){
		this.unsavedCatList = unsavedCatList;
	}

}
