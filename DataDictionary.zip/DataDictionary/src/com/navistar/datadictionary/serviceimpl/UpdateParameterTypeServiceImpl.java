package com.navistar.datadictionary.serviceimpl;

import java.lang.reflect.Type;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.PlatformUI;

import com.google.gson.JsonElement;
import com.google.gson.reflect.TypeToken;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.MatlabQueryConstant;
import com.navistar.datadictionary.constant.MatlabScriptConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.daoimpl.MatlabCommunicationDaoImpl;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.model.Project;
import com.navistar.datadictionary.service.UpdateParameterTypeService;
import com.navistar.datadictionary.ui.config.Application;
import com.navistar.datadictionary.ui.views.ProjectExplorerView;
import com.navistar.datadictionary.util.CreateMatlabRequest;
import com.navistar.datadictionary.util.GsonUtil;
import com.navistar.datadictionary.util.JSONUtil;

/**
 * Class implements methods for UpdateProjParamService for opened component and project.
 * @author shalins
 *
 */
public class UpdateParameterTypeServiceImpl implements UpdateParameterTypeService {

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(UpdateParameterTypeServiceImpl.class);
	
	/** To access opened component */
	
	@Override
	public JsonElement updateValPrjParaType() throws MatlabCommunicatinException {
		JsonElement jsonElement = null;
		MatlabCommunicationDaoImpl matlabCommDaoImpl = new MatlabCommunicationDaoImpl();
		Project project = ProjectExplorerView.getActiveProject();

		if (project.getPath() != null) {

		
			String matlabQuery = CreateMatlabRequest.createMatlabRequest("UpdateParameterType",
					project.getPath().replace("\\","/")+","+Application.projConfigPath.replace("\\", "/")+","+Application.programName, "");
	
			try
			{
				jsonElement = matlabCommDaoImpl.executeMatlabRequest(matlabQuery);
			}
			catch(MatlabCommunicatinException e)
			{
				LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
				throw new MatlabCommunicatinException(e.getMessage(), e);
			}
			
		}

		return jsonElement;
	}

	

	public JsonElement updateValCompParaType() throws MatlabCommunicatinException {
		JsonElement jsonElement = null;
		String componentPath = new OpenComponentServiceImpl().getOpenedComponentPath();
		componentPath = componentPath.replace("\\", "/");
		MatlabCommunicationDaoImpl matlabCommDaoImpl = new MatlabCommunicationDaoImpl();
		Project project = ProjectExplorerView.getActiveProject();
	
		if (project.getComponentPath() != null) {
	
			String matlabQuery = CreateMatlabRequest.createMatlabRequest("UpdateParameterType",
					componentPath+","+Application.projConfigPath.replace("\\", "/")+","+Application.programName, "");
			try
			{
				jsonElement = matlabCommDaoImpl.executeMatlabRequest(matlabQuery);
			}
			catch(MatlabCommunicatinException e)
			{
				LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
				throw new MatlabCommunicatinException(e.getMessage(), e);
			}

		}

		return jsonElement;
		
	}
	
	/**
	 * Method used to get the inconsistent data objects
	 * @return
	 * @throws MatlabCommunicatinException 
	 */
	@Override
	public JsonElement getUpdatedtDataObjects() throws MatlabCommunicatinException {
		JsonElement jsonElement = null;
		String componentPath = new OpenComponentServiceImpl().getOpenedComponentPath();
		componentPath = componentPath.replace("\\", "/");
		String projectPath = ProjectExplorerView.getActiveProject().getPath().replace("\\", "/");
		MatlabCommunicationDaoImpl matlabCommDaoImpl = new MatlabCommunicationDaoImpl();
		Project project = ProjectExplorerView.getActiveProject();

		if (project.getComponentPath() != null) {

			String matlabQuery = CreateMatlabRequest.createMatlabRequest(MatlabScriptConstant.QUERYDATARESOLVED,
					componentPath+","+projectPath+","+Application.projConfigPath.replace("\\", "/")+","+Application.programName, "");
			try
			{
				jsonElement = matlabCommDaoImpl.executeMatlabRequest(matlabQuery);
						
			}
			
			catch(MatlabCommunicatinException e)
			{
				LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
				throw new MatlabCommunicatinException(e.getMessage(), e);
			}
		}

		return jsonElement;
	}

	/**
	 * Method is used to parse JSON data and convert into HashMap.
	 * 
	 * @param jsonElement
	 * @return inconsistencyListMap
	 * @throws MatlabCommunicatinException 
	 */
	@Override
	public Map<String, List<CategoryAttributes>> convertInconsistencyListToMap(JsonElement jsonElementList ) throws MatlabCommunicatinException {
		JsonElement jsonElement = null;

		jsonElement = jsonElementList;

		Map<String, List<CategoryAttributes>> inconsistencyMap = new LinkedHashMap<String, List<CategoryAttributes>>();
		Type type = new TypeToken<List<CategoryAttributes>>() {
		}.getType();

		if (jsonElement != null) {
			// Check if empty JSON element
			if (JSONUtil.checkUpdateParaIsEmpty(jsonElement)) {

				// Parse the JSON details and convert into Map
				for (JsonElement jsonArray : jsonElement.getAsJsonArray()) {

					// check for error code and set error message accordingly
					if (jsonArray != null && jsonArray.isJsonArray()) {
						JsonElement errorObject = jsonArray.getAsJsonArray().get(0);
						if (errorObject.isJsonObject()
								&& errorObject.getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)) {
							String errorValue = errorObject.getAsJsonObject().get(MatlabQueryConstant.ERROR_CODE)
									.getAsString();

							if (errorValue.equals("300")) {
								Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
								MessageDialog.openInformation(shell,ApplicationConstant.INFORMATION,"Updation failed");	
							}
						}  
						else {
							/*if (inconsistencyList != null && !inconsistencyList.isEmpty()) {
								}*/
							displayInconsistencyInBothList(inconsistencyMap, type, jsonArray);
							}
						
						}

					}

				}

			} else if(jsonElement.getAsJsonArray().get(0).getAsJsonObject().has("errorCode")) {
				//inconsistencyListMap = new LinkedHashMap<String, List<CategoryAttributes>>();
				String errorCode = jsonElement.getAsJsonArray().get(0).getAsJsonObject().get("errorCode").getAsString();
				if (errorCode.equals("300")) {
					Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
					MessageDialog.openInformation(shell,ApplicationConstant.INFORMATION,"Updation failed");	
				}
			}
		
		return inconsistencyMap;
		
	}
	
	private void displayInconsistencyInBothList(Map<String, List<CategoryAttributes>> inconsistencyMap, Type type,
			JsonElement jsonArray) {
		String updatedArray = jsonArray.toString().replaceAll("Null", "");
		List<CategoryAttributes> inconsistencyList = GsonUtil.provider()
				.fromJSONToList(updatedArray, type);
		if (inconsistencyList != null && !inconsistencyList.isEmpty()) {
			CategoryAttributes inconsistencyAtt = inconsistencyList.get(0);
			inconsistencyMap.put(inconsistencyAtt.getWarning(), inconsistencyList);
		}
	}
	
}
