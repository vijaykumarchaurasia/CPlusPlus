package com.navistar.datadictionary.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.navistar.datadictionary.constant.MatlabScriptConstant;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.daoimpl.MatlabCommunicationDaoImpl;
import com.navistar.datadictionary.model.SaveResponseCode;
import com.navistar.datadictionary.service.RenameInModelService;
import com.navistar.datadictionary.ui.views.ProjectExplorerView;
import com.navistar.datadictionary.ui.views.RenameInModelWindowView;
import com.navistar.datadictionary.util.CreateMatlabRequest;

/**
 * Class implements methods of RenameInModelService interface to implement rename in model operation.
 * @author nikitak1
 *
 */
public class RenameInModelServiceimpl implements RenameInModelService {

	/** list to store error response after save */
	private List<SaveResponseCode> renameFailedList = new ArrayList<>();

	/**
	 * Method used to get rename failed list
	 * @return List<SaveResponseCode>
	 */
	public List<SaveResponseCode> getRenameFailedList() {
		return renameFailedList;
	}

	/**
	 * Method used to set rename failed list
	 * @param renameFailedList
	 */
	public void setRenameFailedList(List<SaveResponseCode> renameFailedList) {
		this.renameFailedList = renameFailedList;
	}

	/**
	 * Method used to open rename window
	 */
	@Override
	public void openRenameWindow() {

		RenameInModelWindowView renameInModel = new RenameInModelWindowView();
		renameInModel.open();

	}

	/**
	 * Method used to create json for rename in model
	 * @param jsonArray
	 * @throws MatlabCommunicatinException 
	 */
	@Override
	public JsonElement createJsonForRename(JsonArray jsonArray) throws MatlabCommunicatinException {
		String renameObj=jsonArray.toString();
		String componentPath = new OpenComponentServiceImpl().getOpenedComponentPath();
		componentPath = componentPath.replace("\\", "/");
		String projectPath = ProjectExplorerView.getActiveProject().getPath().replace("\\", "/");
		String matlabQuery = CreateMatlabRequest.createMatlabRequest(MatlabScriptConstant.RENAME_IN_MODEL, componentPath+","+projectPath, renameObj);
		JsonElement jsonElement = null;
		try {
			jsonElement = new MatlabCommunicationDaoImpl().executeMatlabRequest(matlabQuery);
		} catch (MatlabCommunicatinException e) {
			throw new MatlabCommunicatinException(e.getMessage(), e);
		}
	
		return jsonElement;

	}
}




