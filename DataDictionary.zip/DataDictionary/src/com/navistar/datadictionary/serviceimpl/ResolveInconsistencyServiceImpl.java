package com.navistar.datadictionary.serviceimpl;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.nebula.widgets.nattable.viewport.command.ShowRowInViewportCommand;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PlatformUI;

import com.google.gson.JsonElement;
import com.google.gson.reflect.TypeToken;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.MatlabQueryConstant;
import com.navistar.datadictionary.constant.MatlabResponseConstant;
import com.navistar.datadictionary.constant.MatlabScriptConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.customexception.EditorInitilizationException;
import com.navistar.datadictionary.customexception.EditorReuseException;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.daoimpl.MatlabCommunicationDaoImpl;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.model.Project;
import com.navistar.datadictionary.operation.SaveOperation;
import com.navistar.datadictionary.service.EditorService;
import com.navistar.datadictionary.service.ResolveInconsistencyService;
import com.navistar.datadictionary.ui.config.Application;
import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.ui.config.DataDictionaryApplication;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.ui.nattable.DeleteRowCommand;
import com.navistar.datadictionary.ui.views.ActivityLogView;
import com.navistar.datadictionary.ui.views.InconsistencyWindowView;
import com.navistar.datadictionary.ui.views.ProjectExplorerView;
import com.navistar.datadictionary.util.CreateMatlabRequest;
import com.navistar.datadictionary.util.DataDictionaryUtil;
import com.navistar.datadictionary.util.GsonUtil;
import com.navistar.datadictionary.util.JSONUtil;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Class implements methods of ResolveInconsistencyService which is used for Resolve Inconsistency functionality
 * @author JAYSHRIVISHB
 *
 */
public class ResolveInconsistencyServiceImpl implements ResolveInconsistencyService {

	/** To access inconsistency window*/
	private InconsistencyWindowView window;

	/** To access opened component */
	private OpenComponentServiceImpl openCompServ;

	/** To check if inconsistency found for sldd data objects */
	public boolean sldDataObject;

	/** To check if inconsistency found for model data objects */
	public boolean modelObject;
	
	/** To check if Redundancy found for model data objects */
	public boolean redunObject;
	
	/** To check if duplicate name data objects found */
	public boolean duplObject;
	
	public static boolean resolveDeleteFlag = false;
	
	public static boolean resolveAddFlag = false;
	
	public static List<CategoryAttributes> resolveAddList = new ArrayList<>();
	
	/** Used to perform save operation */
	public SaveOperation saveOperation = new SaveOperation();
	/**
	 * 	Default Constructor
	 */
	public ResolveInconsistencyServiceImpl() {
		window = new InconsistencyWindowView();
		openCompServ = new OpenComponentServiceImpl();
		sldDataObject = true;
		modelObject = true;
		duplObject = true;
		redunObject= true;
	}
	
	public boolean isDuplObject() {
		return duplObject;
	}

	public void setDuplObject(boolean duplObject) {
		this.duplObject = duplObject;
	}

	/**
	 * Method to check if inconsistent data objects present in Data dictionary
	 * @return
	 */
	public boolean isDDObject() {
		return sldDataObject;
	}
	/**
	 * Method to set if inconsistent data objects present in Data dictionary
	 * @param noDDObject
	 */
	public void setDDObject(boolean noDDObject) {
		this.sldDataObject = noDDObject;
	}
	/**
	 * Method to check if inconsistent data objects present in model
	 * @return
	 */
	public boolean isModelObject() {
		return modelObject;
	}
	/**
	 * Method to set if inconsistent data objects present in model
	 * @param noModelObject
	 */
	public void setModelObject(boolean noModelObject) {
		this.modelObject = noModelObject;
	}
	
	/**
	 * Method to open the inconsistency window
	 */
	@Override
	public void openInconsistencyWindow() {
		window.setUIContents();
	}
	/**
	 * Method used to get the inconsistent data objects
	 * @return
	 * @throws MatlabCommunicatinException 
	 */
	@Override
	public JsonElement getInconsistentDataObjects() throws MatlabCommunicatinException {
		JsonElement jsonElement = null;
		String componentPath = openCompServ.getOpenedComponentPath();
		componentPath = componentPath.replace("\\", "/");
		String projectPath = ProjectExplorerView.getActiveProject().getPath().replace("\\", "/");
		MatlabCommunicationDaoImpl matlabCommDaoImpl = new MatlabCommunicationDaoImpl();
		Project project = ProjectExplorerView.getActiveProject();

		if (project.getComponentPath() != null) {

			String matlabQuery = CreateMatlabRequest.createMatlabRequest(MatlabScriptConstant.QUERYDATARESOLVED,
					componentPath+","+projectPath+","+Application.projConfigPath.replace("\\", "/")+","+Application.programName, "");
			try
			{
				jsonElement = matlabCommDaoImpl.executeMatlabRequest(matlabQuery);
			
					
			}
			catch(MatlabCommunicatinException mce)
			{
				throw new MatlabCommunicatinException(mce.getMessage(), mce);
			}
			


		}

		return jsonElement;
	}

	/**
	 * Method is used to parse JSON data and convert into HashMap.
	 * 
	 * @param jsonElement
	 * @return inconsistencyListMap
	 * @throws MatlabCommunicatinException 
	 */
	@Override
	public Map<String, List<CategoryAttributes>> convertInconsistencyListToMap() throws MatlabCommunicatinException {
		JsonElement jsonElement = null;

		try {
			jsonElement = getInconsistentDataObjects();
		} catch (MatlabCommunicatinException e) {
			throw new MatlabCommunicatinException(e.getMessage(), e);
		}

		Map<String, List<CategoryAttributes>> inconsistencyMap = new LinkedHashMap<String, List<CategoryAttributes>>();
		Type type = new TypeToken<List<CategoryAttributes>>() {
		}.getType();

		if (jsonElement != null) {
			// Check if empty JSON element
			if (JSONUtil.checkInconsistencyIsEmpty(jsonElement)) {

				// Parse the JSON details and convert into Map
				for (JsonElement jsonArray : jsonElement.getAsJsonArray()) {

					// check for error code and set error message accordingly
					if (jsonArray != null && jsonArray.isJsonArray()) {
						JsonElement errorObject = jsonArray.getAsJsonArray().get(0);
						if (errorObject.isJsonObject()
								&& errorObject.getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)) {
							String errorValue = errorObject.getAsJsonObject().get(MatlabQueryConstant.ERROR_CODE)
									.getAsString();

							checkForDDModelInconsistency(errorValue);
						}  
						else {
							String updatedArray = jsonArray.toString().replaceAll("Null", "");
							List<CategoryAttributes> inconsistencyList = GsonUtil.provider()
									.fromJSONToList(updatedArray, type);
							if (inconsistencyList != null && !inconsistencyList.isEmpty()) {
								CategoryAttributes inconsistencyAtt = inconsistencyList.get(0);
								if(inconsistencyAtt.getName().equals("")) {
									modelObject = false;
								}
							}
							displayInconsistencyInBothList(inconsistencyMap, type, jsonArray);
						}

					}else if(jsonArray != null && jsonArray.isJsonObject()) {
						if ((jsonArray.getAsJsonObject().has("modelData"))) {
							displayExceptionPopup(jsonArray);
							break;
						}
					}

				}

			} else if(jsonElement.getAsJsonArray().get(0).getAsJsonObject().has("errorCode")) {
				//inconsistencyListMap = new LinkedHashMap<String, List<CategoryAttributes>>();
				String errorCode = jsonElement.getAsJsonArray().get(0).getAsJsonObject().get("errorCode").getAsString();
				if (errorCode.equals("114")) {
					Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
					MessageDialog.openInformation(shell,ApplicationConstant.INFORMATION,"Model not found");	
				}
			}
		}
		if(Application.programName.equals("E95")) {
			List<CategoryAttributes> addList = getUpdAddCatListLocal(inconsistencyMap);
			if(!addList.isEmpty()) {
				inconsistencyMap.replace("Add in DataDictionary", addList);
			}else {
				sldDataObject = false;
			}

			List<CategoryAttributes> delList = getUpdDelCatListLocal(inconsistencyMap);
			if(!delList.isEmpty()) {
				inconsistencyMap.replace("Delete from DataDictionary", delList);
			}else {
				modelObject = false;
			}
		}
		
		return inconsistencyMap;
		
	}
	
	private List<CategoryAttributes> getUpdAddCatListLocal(Map<String, List<CategoryAttributes>> inconsistencyMap) {
		List<CategoryAttributes> list = new ArrayList<>();
		Iterator<String> it = inconsistencyMap.keySet().iterator();  
		while(it.hasNext()) {  
			String key = it.next();  
			if (key.equals("Add in DataDictionary")) {  
				list = inconsistencyMap.get(key);
			}     
		}
		
		for (Iterator<CategoryAttributes> iterator = list.iterator(); iterator.hasNext();) {
			CategoryAttributes obj = iterator.next();
			String objCat =obj.getCategory();
			String objNam = obj.getName();
			if (objCat.equals("Local")){
				if (objNam.endsWith("Tx") || objNam.endsWith("Rx") || objNam.endsWith("Tx>") || objNam.endsWith("Rx>")) {
					iterator.remove();
				}
			}
		
			if (( objNam.endsWith("Cfg_CA") || objNam.endsWith("Glbl_CA"))  || objNam.endsWith("Cfg_C") || objNam.endsWith("Glbl_C")) {
				iterator.remove();
			}

		}
		return list;
	}
	
	
	private List<CategoryAttributes> getUpdDelCatListLocal(Map<String, List<CategoryAttributes>> inconsistencyMap) {
		List<CategoryAttributes> list = new ArrayList<>();
		Iterator<String> it = inconsistencyMap.keySet().iterator();  
		while(it.hasNext()) {  
			String key = it.next();  
			if (key.equals("Delete from DataDictionary")) {  
				list = inconsistencyMap.get(key);
			}     
		}
		
		for (Iterator<CategoryAttributes> iterator = list.iterator(); iterator.hasNext();) {
			CategoryAttributes obj = iterator.next();
			String objNam = obj.getName();
			if (objNam.endsWith("Tx") || objNam.endsWith("Rx")) {
				iterator.remove();
			}

		}
		return list;
	}
	/**
	 * Method used to check which inconsistencies are present.
	 * DD inconsistencies- Add data object in data dictionary
	 * Model inconsistencies- Remove data object from data dictionary
	 * @param errorValue
	 */
	private void checkForDDModelInconsistency(String errorValue) {
		if (errorValue.equals(MatlabResponseConstant.NODDINCONOBJ)) {
			sldDataObject = false;
		}

		if (errorValue.equals(MatlabResponseConstant.NOMDLINCONOBJ)) {
			modelObject = false;
		}
		
		if (errorValue.equals(MatlabResponseConstant.REDUNDANT_DATA_ERROR_CODE)) {
			redunObject = false;
			
		}
		
		if (errorValue.equals(MatlabResponseConstant.NODUPLICOBJ)) {
			duplObject = false;
			
		}
		
	}

	/**
	 * Method used to display matlab exception pop-up
	 * @param jsonArray
	 */
	private void displayExceptionPopup(JsonElement jsonArray) {
		String msgException = jsonArray.getAsJsonObject().get("modelData").getAsString();
		MessageDialog.openInformation(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(),ApplicationConstant.INFORMATION,msgException);
		Application.displayExceptionPopup=true;
	}
	
	/**
	 * Method used to display inconsistencies in both (DD and model).
	 * @param inconsistencyListMap
	 * @param type
	 * @param jsonArray
	 */
	private void displayInconsistencyInBothList(Map<String, List<CategoryAttributes>> inconsistencyMap, Type type,
			JsonElement jsonArray) {
		String updatedArray = jsonArray.toString().replaceAll("Null", "");
		List<CategoryAttributes> inconsistencyList = GsonUtil.provider()
				.fromJSONToList(updatedArray, type);
		if (inconsistencyList != null && !inconsistencyList.isEmpty()) {
			CategoryAttributes inconsistencyAtt = inconsistencyList.get(0);
			inconsistencyMap.put(inconsistencyAtt.getWarning(), inconsistencyList);
		}
	}
	/**
	 * Method used to send the inconsistent data objects for resolving inconsistency to Matlab
	 * @param ddCheckBoxList
	 * @param modelCheckBoxList
	 * @throws MatlabCommunicatinException 
	 * @throws EditorReuseException 
	 * @throws EditorInitilizationException 
	 */
	@Override
	public void resolveInconsistency(List<CategoryAttributes> ddCheckBoxList, List<CategoryAttributes> modelCheckBoxList) throws MatlabCommunicatinException, EditorReuseException, EditorInitilizationException {
		IWorkbenchPage activePage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();	
		IEditorReference[] editorRef = activePage.getEditorReferences();
		List<String> dataObjectList = new ArrayList<String>();
		List<CategoryAttributes> deletedUpdateList = null;
		List<CategoryAttributes> extraDelList = new ArrayList<>();
		int objectCount = 0;
		Map<String,List<CategoryAttributes>> attributesMap = new HashMap<String,List<CategoryAttributes>>();
		Map<CategoryEditor,Integer> rowCntMap = new HashMap<>();
		
		for(CategoryAttributes object : modelCheckBoxList){
			String categoryName = object.getCategory();
			objectCount = objectCount + 1;
			for(IEditorReference editor : editorRef){
				IEditorPart editorPart = editor.getEditor(false);
				if(editorPart instanceof CategoryEditor && editorPart.getTitle().equals(categoryName)){
					CategoryEditor categoryEditor = (CategoryEditor)editorPart;
					object.setComponent(new OpenComponentServiceImpl().getOpenedComponentName());
					DataDictionaryApplication.getApplication().setSearchedHighlighted(object);
					DataDictionaryApplication.getApplication().setSearchedHighLight(true);
					activePage.activate(categoryEditor);
					//categoryEditor.createNatTable.
					int deleteSearchIndex = DataDictionaryUtil.searchIndex(object.getName(),object.getComponent(),object.getCategory(), categoryEditor.createNatTable.getJsonDataProvider().getList());
					categoryEditor.createNatTable.getSelectionLayer().doCommand(
							new DeleteRowCommand(categoryEditor.createNatTable.getSelectionLayer(), deleteSearchIndex));
					resolveDeleteFlag = true;
					if(attributesMap.isEmpty())
					{
						deletedUpdateList = new ArrayList<>();
						deletedUpdateList.add(object);
						attributesMap.put(editorPart.getTitle(),deletedUpdateList);
					}
					else if(attributesMap.containsKey(editorPart.getTitle())) 
					{
						List<CategoryAttributes> list = attributesMap.get(editorPart.getTitle());
						list.add(object);
					}
					else
					{
						deletedUpdateList = new ArrayList<>();
						deletedUpdateList.add(object);
						attributesMap.put(editorPart.getTitle(),deletedUpdateList);
					}
				
					CategoryEditor.deletedListMap=attributesMap;
					categoryEditor.setDirtyStatus(true);
					saveOperation.makeSaveEnableDisable(categoryEditor);
				}else if(!Application.configCatList.contains(object.getCategory())){
					if(!extraDelList.contains(object)) {
						extraDelList.add(object);
					}
				}
			}
		}
		
		for(CategoryAttributes object : ddCheckBoxList){
			String categoryName = object.getCategory();
			for(IEditorReference editor : editorRef){
				
				IEditorPart editorPart = editor.getEditor(false);
				if(editorPart instanceof CategoryEditor && editorPart.getTitle().equals(categoryName)){
					
					CategoryEditor categoryEditor = (CategoryEditor)editorPart;
					categoryEditor.displayNewObjectsAfterResolve(object,categoryName);
					object.setComponent(new OpenComponentServiceImpl().getOpenedComponentName());
					//categoryEditor.setDirtyStatus(true);
					resolveAddFlag = true;
					DataDictionaryApplication.getApplication().setSearchedHighlighted(object);
					DataDictionaryApplication.getApplication().setSearchedHighLight(true);
					activePage.activate(categoryEditor);	
					dataObjectList.add(object.getName());
					categoryEditor.addNatTableConfigurationForAddResolve(object.getName(),object.getComponent(),object.getCategory(),dataObjectList,object,ResolveInconsistencyServiceImpl.resolveAddList);
					categoryEditor.setDirtyStatus(true);
					rowCntMap.put(categoryEditor, categoryEditor.createNatTable.getJsonDataProvider().getRowCount());
					saveOperation.makeSaveEnableDisable(categoryEditor);
				}
			}
		}	
		
		//added separate loop for configuring nattable due to Unhandled event loop exception
		for(IEditorReference editor : editorRef){	
			IEditorPart editorPart = editor.getEditor(false);
			if(editorPart instanceof CategoryEditor){	
				CategoryEditor categoryEditor = (CategoryEditor)editorPart;
				categoryEditor.natTable.configure();
			}
		}
		//to focus the newly added data objects while performing Resolve inconsistency
		for (Map.Entry<CategoryEditor,Integer> entry : rowCntMap.entrySet()) {
			entry.getKey().natTable.doCommand(new ShowRowInViewportCommand(entry.getKey().createNatTable.getGridLayer().getBodyLayer(), entry.getValue()-1));
			entry.getKey().natTable.configure();
		}
	
		boolean status = false;
		EditorService editorService = new EditorServiceImpl();
		try {
			status = editorService.deleteDataObjectsFromEditor(extraDelList);
		} catch (MatlabCommunicatinException e) {
			// Reset static data after throwing exception
			//deletedListMap = new HashMap<String, List<CategoryAttributes>>();
			MessageDialog.openConfirm(new Shell(), "Error Message", e.getMessage());
		}
		if(status) {
			ViewUtil.dispInfoInMsgDialog("Extra data objects deleted successfully from component");
		}
		
		if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
			ActivityLogView.activityLog.append("\n [INFO]: Resolve inconsistency performed successfully");
		}
	}
	
	/**
	 * Method used to enable Resolve Inconsistency icon
	 */
	@Override
	public void enableResolveInconAction() {

		OpenComponentServiceImpl openCompSerImpl = new OpenComponentServiceImpl();
		if (openCompSerImpl.getOpenedComponentPath() != "") {

			ApplicationActionBarAdvisor.getInstance().resolvInconObj.setEnabled(true);
			
		}
	}


}
