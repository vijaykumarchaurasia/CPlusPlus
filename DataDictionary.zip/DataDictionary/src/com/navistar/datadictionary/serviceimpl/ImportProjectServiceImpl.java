package com.navistar.datadictionary.serviceimpl;

import java.io.File;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FilenameUtils;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Shell;

import com.google.gson.JsonElement;
import com.google.gson.reflect.TypeToken;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.MatlabScriptConstant;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.daoimpl.MatlabCommunicationDaoImpl;
import com.navistar.datadictionary.daoimpl.MatlabEngineConnectionDaoImpl;
import com.navistar.datadictionary.model.Component;
import com.navistar.datadictionary.model.Node;
import com.navistar.datadictionary.model.Project;
import com.navistar.datadictionary.service.ImportProjectService;
import com.navistar.datadictionary.ui.config.Application;
import com.navistar.datadictionary.ui.config.DataDictionaryApplication;
import com.navistar.datadictionary.ui.views.AddDataObjectWindow;
import com.navistar.datadictionary.util.CreateMatlabRequest;
import com.navistar.datadictionary.util.FileUtility;
import com.navistar.datadictionary.util.GsonUtil;
import com.navistar.datadictionary.util.JSONUtil;

/**
 * This class is used to maintain imported project, maintain the status of every project, update an imported project status as per open, close or remove.
 * The class creates the project structure and return the project status.
 * 
 * @author VijayK13
 *
 */
public class ImportProjectServiceImpl  implements ImportProjectService{

	public static boolean pasteFlag;
	
	/** All imported project component */
	List<String> allImpcompList = new ArrayList<>();		
	
	/** All imported project parent and its component */
	public static Map<String, Map<String, String>> projectMap = new LinkedHashMap<>();	 
	
	/** Used to execute matlab request */
	MatlabCommunicationDaoImpl matlabComm = new MatlabCommunicationDaoImpl();
	
	/** Directory Path */
	private String path;


	/**
	 * Function used to maintain imported project structure for current instance of application
	 * @param filePath
	 * @return
	 */
	public List<String> loadImportedProject(String filePath)
	{
		if(filePath=="" || filePath==null)
		{
			return null;
		}
		//current imported project component
		List<String> curntImpcompList = new ArrayList<>();		

		File parentFileObject = new File(filePath);
		String parentElement = parentFileObject.getName();

		FileUtility fileUtils = new FileUtility();
		curntImpcompList = fileUtils.getComponentList(filePath);


		Map<String,String> crntCompPathName = new LinkedHashMap<String, String>();
		for(String key : FileUtility.slddPathMap.keySet())
		{
			String value = FileUtility.slddPathMap.get(key);

			for(String compName : curntImpcompList)
			{
				if(compName.equals(value))
				{
					crntCompPathName.put(key, compName);
				}
			}
		}
		projectMap.put(parentElement, crntCompPathName);

		return curntImpcompList;
	}
	
	/**
	 * Function used to maintain imported project structure for current instance of application USING TOP.SLDD
	 * @param filePath
	 * @return
	 */
	public List<String> loadImportedProjectUsingTopSldd(String filePath, JsonElement jsonElement)
	{
		//current imported project component
		List<Component> crntImportedcomp = new ArrayList<>();	
		List<String> cImpcompNameList = new ArrayList<>();
		

		File parentFileObject = new File(filePath);
		String parentElement = parentFileObject.getName();
		
		GsonUtil gsonUtil = GsonUtil.provider();
		Type type = new TypeToken<List<Component>>(){}.getType();
	
		if(jsonElement!=null)
		{
			crntImportedcomp = gsonUtil.fromJSONToList(jsonElement.getAsJsonArray().toString(), type);
		}
		
		
		//get the name of component from path of component
		cImpcompNameList = getNameFromComponent(crntImportedcomp);
		
		Map<String,String> crntCompPathName = new LinkedHashMap<String, String>();
		for(String key : FileUtility.slddPathMap.keySet())
		{
			String value = FileUtility.slddPathMap.get(key);

			for(String compName : cImpcompNameList)
			{
				if(compName.equals(value))
				{
					crntCompPathName.put(key, compName);
				}
			}
		}
		projectMap.put(parentElement, crntCompPathName);

		return cImpcompNameList;
	}

	/**
	 * Function used to maintain the status of every project
	 * @param projectAndStatusMap
	 * @param projectPath
	 * @param status
	 * @param componentPath
	 * @return
	 */
	public Map<String, Project> setProjectandStaus(Map<String,Project> projStatusMap,String projectPath,int status, String componentPath)
	{
		if(projStatusMap!=null)
		{
			if(projStatusMap.containsKey(projectPath))
			{
				projStatusMap.put(projectPath,new Project(projectPath, status,componentPath,""));
			}
			else
			{
				projStatusMap.put(projectPath,new Project(projectPath, status,componentPath,""));
			}
		}
		
		return projStatusMap;
	}
	
	/**
	 * Function is used to update a imported project status as per open, close or remove
	 * @param projectName
	 * @param status
	 * @param componentPath
	 */
	public void updateProjectStatus(String projectName, int status, String componentPath)
	{
		Map<String, Project> projectMap = DataDictionaryApplication.getApplication().projStatusMap;
		for(String projectPathAsKey : projectMap.keySet())
		{
			String folder[] = projectPathAsKey.split("\\\\");
			String projToBeCompare = folder[folder.length-1];
			if(status == ApplicationConstant.REMOVEPROJSTATUS) {
				if(projToBeCompare.equals(projectName))
				{
					DataDictionaryApplication.getApplication().projStatusMap.put(projectPathAsKey, new Project(projectPathAsKey, status,componentPath,""));
				}
			}else {
				if(projToBeCompare.equals(projectName) && projectMap.get(projectPathAsKey).getStatus()!=ApplicationConstant.REMOVEPROJSTATUS)
				{
					DataDictionaryApplication.getApplication().projStatusMap.put(projectPathAsKey, new Project(projectPathAsKey, status,componentPath,""));
				}
			}
		}
		
		if(AddDataObjectWindow.addObjInputShell!=null) {
			AddDataObjectWindow.addObjInputShell.dispose();
		}
	}
	/**
	 * Function is used to get project status using project name
	 * @param projectName
	 * @return
	 */
	public int getProjectStatus(String projectName)
	{
		int status=0;
		Map<String, Project> projectMap = DataDictionaryApplication.getApplication().projStatusMap;
		for(String projectPathAsKey : projectMap.keySet())
		{
			String folder[] = projectPathAsKey.split("\\\\");
			String projToBeCompare = folder[folder.length-1];
			if(status == ApplicationConstant.REMOVEPROJSTATUS) {
				if(projToBeCompare.equals(projectName))
				{
					status = projectMap.get(projectPathAsKey).getStatus();
				}
			}else {
				if(projToBeCompare.equals(projectName) && projectMap.get(projectPathAsKey).getStatus()!=ApplicationConstant.REMOVEPROJSTATUS)
				{
					status = projectMap.get(projectPathAsKey).getStatus();
				}
			}
			
			/*if(projToBeCompare.equals(projectName))
			{
				status = projectMap.get(projectPathAsKey).getStatus();
			}*/
		}
		return status;
	}

	/**
	 * This method is used to create tree structure for the project.
	 * 
	 * @param filePath
	 * @param importStatus
	 * @return
	 */
	public Node createTreeStructure(String filePath,int importStatus) throws MatlabCommunicatinException
	{
		List<String> crntImpCompList = new ArrayList<>();
		
		String queryName = MatlabScriptConstant.QUERYTOPSLDDCOMP;
		
		MatlabEngineConnectionDaoImpl matlabConnection = new MatlabEngineConnectionDaoImpl();
		
		File parentFile = new File(filePath);
		String parentElement = parentFile.getName();
		
		String matlabQuery = CreateMatlabRequest.createMatlabRequest(queryName, parentFile.getPath().replace("\\", "/"),ApplicationConstant.EMPTY_STRING);
		JsonElement jsonElement = null;
		String excelPath = "";
		try
		{
			jsonElement =  matlabComm.executeMatlabRequest(matlabQuery);
			Application.unitsJson = new EditorServiceImpl().getUnitsDataFrMatlab();
			excelPath = new EditorServiceImpl().getConfigExcelPath();
			
		}
		catch(MatlabCommunicatinException e)
		{
			throw new MatlabCommunicatinException(e.getMessage(),e);
		}
		if(excelPath==null ) {
			return null;
		}
		if(JSONUtil.checkForValidProj(jsonElement)) {
			if (!JSONUtil.checkErrorCodeForNoTopSldd(jsonElement)) {
				crntImpCompList = loadImportedProject(filePath);
			}
			else {
				crntImpCompList = loadImportedProjectUsingTopSldd(filePath,jsonElement);
			}

			//sort alphabetically
			Collections.sort(crntImpCompList);

			Node node = new Node(parentElement, null);

			for(String componentName : crntImpCompList)
			{
				new Node(componentName, node);
			}

			matlabConnection.removeProjectPath(filePath);

			DataDictionaryApplication.projNodeMap.put(filePath, node);

			return node; 
		}
		return null;
	}
	
	/**
	 * Method used to get the component name from component object
	 * @param currentImportedcomponents
	 * @return
	 */
	public List<String> getNameFromComponent(List<Component> currentImpcomp)
	{
		List<String> cImpcompNameList = new ArrayList<>();
		
		if(currentImpcomp!=null)
		{
			for(Component component : currentImpcomp)
			{
				// get the base name of component path
				File file = new File(component.getComponentName());
				String fileName = FilenameUtils.getBaseName(file.getName());
				cImpcompNameList.add(fileName);
				FileUtility.slddPathMap.put(file.getPath(), fileName);
			}
		}
		
		return cImpcompNameList;
	}
	
	/**
	 * Function used to open directory dialog which allows user to select a required folder
	 * @param shell
	 * @return
	 */
	public String openDirectoryDialog(Shell shell) {
		DirectoryDialog dialog = new DirectoryDialog(shell);
        path = dialog.open();
        boolean directoryStatus;

        if (path != null) {
			directoryStatus = onOkClick();			  

			if(!directoryStatus)
			{
				path = ApplicationConstant.INVALID;
			}

		}
		return path;			
	}
	
	/**
	 * Function used for "OK" click of DirectoryDialog
	 * @return 
	 */
	private boolean onOkClick() {
		 List<String> slddComponent = new ArrayList<>();
		 slddComponent = new FileUtility().getComponentList(path);
		 return !slddComponent.isEmpty();		
	}
}
