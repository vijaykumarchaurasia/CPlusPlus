package com.navistar.datadictionary.serviceimpl;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import com.navistar.datadictionary.action.EditorPreference;
import com.navistar.datadictionary.action.OpenProjectAction;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.IconsPathConstant;
import com.navistar.datadictionary.constant.MatlabQueryConstant;
import com.navistar.datadictionary.constant.MatlabResponseConstant;
import com.navistar.datadictionary.constant.MatlabScriptConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.customexception.EditorInitilizationException;
import com.navistar.datadictionary.customexception.EditorReuseException;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.daoimpl.MatlabCommunicationDaoImpl;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.model.FontStyleDAO;
import com.navistar.datadictionary.model.Project;
import com.navistar.datadictionary.service.EditorService;
import com.navistar.datadictionary.ui.config.Activator;
import com.navistar.datadictionary.ui.config.Application;
import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.ui.config.ApplicationWorkbenchWindowAdvisor;
import com.navistar.datadictionary.ui.config.DataDictionaryApplication;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.ui.editors.CategoryEditorInput;
import com.navistar.datadictionary.ui.editors.IOCompatibilityEditor;
import com.navistar.datadictionary.ui.nattable.CreateNatTable;
import com.navistar.datadictionary.ui.views.ProjectExplorerView;
import com.navistar.datadictionary.util.CreateMatlabRequest;
import com.navistar.datadictionary.util.FileUtility;
import com.navistar.datadictionary.util.GsonUtil;
import com.navistar.datadictionary.util.JSONUtil;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Class implements methods of EditorService interface to implement editor
 * operation.
 * 
 * @author JAYSHRIVISHB
 *
 */
public class EditorServiceImpl implements EditorService {

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(EditorServiceImpl.class);

	/** Used to execute matlab request */
	MatlabCommunicationDaoImpl matlabComm = new MatlabCommunicationDaoImpl();

	/** Instance of ImportProjectStructureService */
	private ImportProjectServiceImpl importService = new ImportProjectServiceImpl();

	/** Store Matlab query name */
	private String queryName = MatlabScriptConstant.LOADCOMPDATA;

	//private ResolveInconsistencyServiceImpl resolveInconObj;
	
	public static List<List<CategoryAttributes>> unitList = null;

	/**
	 * Method used to check any unsaved editor is there
	 * 
	 * @return boolean
	 */
	public boolean checkForUnsavedEditors() {
		IEditorPart[] dirtyEditors = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
				.getDirtyEditors();

		return dirtyEditors.length > 0;
	}

	/**
	 * This method is used to close all the editors.
	 */
	public void closeAllEditors() {

		IWorkbenchPage activePage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
		IEditorReference[] editors = activePage.getEditorReferences();
		if (editors.length != 0) {
			activePage.closeEditors(activePage.getEditorReferences(), true);
		}
		ApplicationActionBarAdvisor.getInstance().filterAction
				.setImageDescriptor(Activator.getImageDescriptor("/icons/filter.png"));
		ApplicationActionBarAdvisor.getInstance().filterAction.setEnabled(false);
	}

	/**
	 * This method is used to open the categories in tabs on selection of component.
	 * 
	 * @param componentName
	 * @param viewer
	 * @throws FileNotFoundException
	 * @throws MatlabCommunicatinException
	 * @throws EditorReuseException
	 * @throws EditorInitilizationException
	 */
	@Override
	public boolean displayComponentCategories(String componentName, TreeViewer viewer) throws FileNotFoundException,
			MatlabCommunicatinException, EditorReuseException, EditorInitilizationException {
		//changed for PMD
		
		boolean status = false;
		String compName = componentName;
		ResolveInconsistencyServiceImpl resolveInconObj = new ResolveInconsistencyServiceImpl();
		String projectName = "";
		String actualCompName = "";
		IWorkbench workbench = PlatformUI.getWorkbench();
		IWorkbenchWindow activeWindow = workbench.getActiveWorkbenchWindow();
		IWorkbenchPage activePage = activeWindow.getActivePage();

		IEditorReference[] editors = activePage.getEditorReferences();
		if (editors.length != 0) {
			activePage.closeEditors(activePage.getEditorReferences(), true);
		}

		String jsonObject = null;
		String compNameWithExt = new File(compName).getName();
		actualCompName = compNameWithExt.substring(0, compNameWithExt.lastIndexOf('.'));
		highlightComponent(actualCompName, ProjectExplorerView.hierarchialView);
		compName = compName.replace("\\", "/");
		//Application.programName = new EditorServiceImpl().getConfigProjDataFrMatlab(compName);
		//String matlabQuery = CreateMatlabRequest.createMatlabRequest(queryName, compName, jsonObject);
		JsonElement jsonElement = null;
		Application.configCatList = new ArrayList<>();
		try {
			
			String matlabQuery = CreateMatlabRequest.createMatlabRequest(queryName, compName+","+Application.projConfigPath.replace("\\", "/")+","+Application.programName, jsonObject);
		//	boolean isProgNamePres = new EditorServiceImpl().openCompWithProgName(Application.programName);
			status = true;
			Application.catColumnMap = CreateNatTable.dispCategoryAndColumns();
			Application.catColumnAttributeMap  = CreateNatTable.dispCategoryAndColumnsAttributes();
			//	if(isProgNamePres) {
					jsonElement = matlabComm.executeMatlabRequest(matlabQuery);
	
					//PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell().setText("Data Dictionary : Currently selected project is - "+Application.programName);
		
		}  catch (IOException e) {
			ViewUtil.dispInfoInMsgDialog("Configuration file does not exist. Please add valid configuration file and try again");
		}
		catch(Exception e)
		{
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
		}
		
		// Exception Handling if null is returned after matlab function execution
		if (jsonElement == null) {
			Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
			MessageDialog.openWarning(shell, ApplicationConstant.WARNING, MessageConstant.FETCH_DATA_ERROR);
			return false;
		} else if (!JSONUtil.checkForErrorCode(jsonElement)) {
			/*Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
			MessageDialog.openInformation(shell, ApplicationConstant.INFORMATION, MessageConstant.FETCH_SLDD_ERROR);*/
			importService.updateProjectStatus(projectName, ApplicationConstant.OPEN_PROJ_STATUS, "");
			return false;
		} 
		//handled for unknown exchange api error
		else if (jsonElement != null && jsonElement.isJsonArray()) {
			JsonElement jsonElement1 = jsonElement.getAsJsonArray().get(0);
			if (jsonElement1.isJsonObject()) {
				if (jsonElement1.getAsJsonObject().has("modelData")) {
					Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
					String msgException = jsonElement1.getAsJsonObject().get("modelData").getAsString();
					MessageDialog.openInformation(shell,ApplicationConstant.INFORMATION,msgException);
					return false;
				}
			}
		}

		try {
			displayComponentInEditors(activePage, jsonElement);
		} catch (EditorReuseException e) {
			throw new EditorReuseException(e.getMessage(), e);
		} catch (EditorInitilizationException e) {
			throw new EditorInitilizationException(e.getMessage(), e);
		}
		ApplicationActionBarAdvisor.getInstance().searchAction.setEnabled(true);
		resolveInconObj.enableResolveInconAction();
		if(Application.programName.equals("E95")) {
			ApplicationActionBarAdvisor.getInstance().excelImportExport.setEnabled(false);
		}
		else
		{
		ApplicationActionBarAdvisor.getInstance().excelImportExport.setEnabled(true);
		}
		//ViewUtil.disableIOFeatures();
		
	
		return status;
	}

	/**
	 * Method used to send query to matlab that opened component has what program variable and 
	 * check from matlab side if excel sheet of that program is present
	 * @param program
	 * @return
	 * @throws MatlabCommunicatinException
	 */
	@Override
	public boolean openCompWithProgName(String program) throws MatlabCommunicatinException {
		boolean status = false;
		JsonElement jsonElement = null;
		MatlabCommunicationDaoImpl matlabDataRequest = new MatlabCommunicationDaoImpl();
		String matlabQuery = CreateMatlabRequest.createMatlabRequest(
				MatlabScriptConstant.QRYSENDPROGNAME, program,"");
		try {
			jsonElement = matlabDataRequest.executeMatlabRequest(matlabQuery);
			status = JSONUtil.isProgNameAdded(jsonElement);
		} catch (MatlabCommunicatinException mce) {
			throw new MatlabCommunicatinException(mce.getMessage(), mce);
		}
		return status;
	}

	/**
	 * Method used to create editors using editor input
	 * 
	 * @param activePage
	 * @param jsonElement
	 * @throws EditorReuseException
	 * @throws EditorInitilizationException
	 */
	public void displayComponentInEditors(IWorkbenchPage activePage, JsonElement jsonElement)
			throws EditorReuseException, EditorInitilizationException {
		JsonElement nonNullJson = jsonElement;
		String newresp = nonNullJson.toString().replace("null", " \"\" ");
		newresp = nonNullJson.toString().replace("1.1111111111111111E+104", " \"\" ");
		nonNullJson = new JsonParser().parse(newresp);
		List<CategoryEditorInput> catEditorInList;
		catEditorInList = new CopyOnWriteArrayList<CategoryEditorInput>();

		for (JsonElement jsonElementArr : nonNullJson.getAsJsonArray()) {
			CategoryEditorInput catEditorInput = new CategoryEditorInput(jsonElementArr);
			catEditorInList.add(catEditorInput);

		}

		boolean found = false;
		// Opening Editor references
		IEditorReference[] eRefs = activePage.getEditorReferences();
		for (IEditorReference ref : eRefs) {
			IEditorPart editorPart = ref.getEditor(false);
			if (editorPart != null) {
				// Restore
				CategoryEditor editor = (CategoryEditor) ref.getEditor(true);
				found = true;

				boolean saved = true;

				// If editor is dirty, save it.
				if (editor.isDirty()) {
					saved = activePage.saveEditor(editor, true);
				}
				if (saved) {
					// Reset input for InputEditor.
					CategoryEditorInput inputEditor = (CategoryEditorInput) editor.getEditorInput();

					Iterator<CategoryEditorInput> iterate = catEditorInList.iterator();
					while (iterate.hasNext()) {
						CategoryEditorInput catEditorInput = iterate.next();
						if (catEditorInput.getName().equals(inputEditor.getName())) {
							catEditorInList.remove(catEditorInput);
						}
					}
					try {
						activePage.reuseEditor(editor, inputEditor);
						editor.showData();
					} catch (Exception e) {
						LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
						throw new EditorReuseException("Failed to reuse the editor", e);
					}

				}
			}
		}
		if (!found) {
			if (!catEditorInList.isEmpty()) {

				Iterator<Entry<String, List<Integer>>> hmIterator = Application.catColumnMap.entrySet().iterator();
				   while (hmIterator.hasNext()) {
			            Map.Entry mapElement = (Map.Entry)hmIterator.next();
			            String cat = mapElement.getKey().toString();
			            Application.configCatList.add(cat);
				   }
				Iterator<CategoryEditorInput> iterate = catEditorInList.iterator();
				while (iterate.hasNext()) {
					CategoryEditorInput catEditorInput = iterate.next();
					try {
						if(Application.configCatList.contains(catEditorInput.getName())){
							activePage.openEditor(catEditorInput, CategoryEditor.CAT_EDI_ID);
						}
					} catch (PartInitException e) {
						LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
						throw new EditorInitilizationException("Failed to load the editor", e);
					}
				}

			}

		} else {
			if (!catEditorInList.isEmpty()) {
				Iterator<CategoryEditorInput> iterator = catEditorInList.iterator();
				while (iterator.hasNext()) {
					CategoryEditorInput catEditorInput = iterator.next();

					try {
						activePage.openEditor(catEditorInput, CategoryEditor.CAT_EDI_ID);
					} catch (PartInitException e) {
						LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
						throw new EditorInitilizationException("Failed to load the editor", e);
					}
				}

			}

		}
		ApplicationWorkbenchWindowAdvisor.partFlag = false;
	}

	/**
	 * Method used to remove dirty indicator of dirty editors
	 */
	@Override
	public void removeDirtyIndicator() {
		// Get all editors having dirty bit enable
		IEditorPart[] dirtyEditors = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
				.getDirtyEditors();

		for (IEditorPart iEditorPart : dirtyEditors) {
			CategoryEditor categoryEditor = (CategoryEditor) iEditorPart;

			categoryEditor.setDirtyStatus(false);
			categoryEditor.newAddedRowList = new HashSet<>();
			categoryEditor.addedRowLists = new HashSet<>();
			categoryEditor.editRowLists = new HashSet<>();
		}
	}

	/**
	 * Method used to delete data objects from category editor
	 * 
	 * @param deletedDataObjectList
	 * @throws MatlabCommunicatinException
	 */
	@Override
	public boolean deleteDataObjectsFromEditor(List<CategoryAttributes> delDataObjList)
			throws MatlabCommunicatinException {

		// Check if any empty fields while saving a new object
		if (delDataObjList != null && !delDataObjList.isEmpty()) {

			try {
				JsonElement element = null;
				JsonArray array = new JsonArray();
				for (CategoryAttributes deletedDataObject : delDataObjList) {
					JsonObject object = new JsonObject();
					object.addProperty("Name", deletedDataObject.getName());
					array.add(object);
				}

				element = array;
				String componentPath = "";
				IEditorPart editorPart = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
						.getActiveEditor();
				// to get path of closed component for deleting data object on I/O Compatibility
				// editor
				if (editorPart instanceof IOCompatibilityEditor) {
					Project project = ProjectExplorerView.getActiveProject();
					project.getPath().replace("\\", "/");
					componentPath = FileUtility.getComponentPathFromProject(delDataObjList.get(0).getComponent(),
							project.getPath());

				}
				// to get path of opened component if deleting data object on Category Editor
				else if (editorPart instanceof CategoryEditor) {
					componentPath = ProjectExplorerView.getActiveProject().getComponentPath();
				}

				componentPath = componentPath.replace("\\", "/");

				String matlabQuery = CreateMatlabRequest.createMatlabRequest(
						MatlabScriptConstant.QUERYDELDATAOBJ, componentPath, element.toString());
				JsonElement jsonElement = matlabComm.executeMatlabRequest(matlabQuery);

				if (jsonElement != null && jsonElement.isJsonArray()) {
					JsonElement errorObject = jsonElement.getAsJsonArray().get(0);
					if (errorObject.isJsonObject()
							&& errorObject.getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)) {
						return false;
					} else if (errorObject.isJsonObject()
							&& errorObject.getAsJsonObject().has(MatlabQueryConstant.MESSAGE_CODE)) {
						return true;
					}
				}

			} catch (Exception e) {
				LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
				throw new MatlabCommunicatinException(e.getMessage(), e);
			}

		}
		return false;
	}

	/**
	 * Function used to highlight component
	 * 
	 * @param actualComponentName
	 * @param hierarchialView
	 */
	public void highlightComponent(String actualCompName, Boolean hierarchialView) {

		Device device = PlatformUI.getWorkbench().getDisplay();
		Color closedProjColor = new Color(device, ApplicationConstant.CLOSE_PROJ_COLOR,
				ApplicationConstant.CLOSE_PROJ_COLOR, ApplicationConstant.CLOSE_PROJ_COLOR);
		Font fontStyleNormal;
		Font fontStyleBold;
		Color openProjectColor;
		FontStyleDAO fontStyle = DataDictionaryApplication.getApplication().fontStyle;
		//If font is set and store default font is not set then apply the selected font else set default font
		//If user selected font greater than 12 then for project explorer set it to 12
		if (fontStyle != null && fontStyle.getFont() != null && !EditorPreference.isDefFontSel) {
			int fontSize = fontStyle.getSize();
			if (fontSize > 12) {
				fontSize = 12;
			}
			fontStyleNormal = new Font(device, fontStyle.getFont(), fontSize, SWT.NORMAL);
			fontStyleBold = new Font(device, fontStyle.getFont(), fontSize, SWT.BOLD);
			openProjectColor = new Color(device, fontStyle.getFontColor());
		} else {
			fontStyleNormal = new Font(device, ApplicationConstant.HIGHLIGHTFONTSTYL,
					ApplicationConstant.HIGHFONTSIZE, SWT.NORMAL);
			fontStyleBold = new Font(device, ApplicationConstant.HIGHLIGHTFONTSTYL,
					ApplicationConstant.HIGHFONTSIZE, SWT.BOLD);
			openProjectColor = new Color(device, ApplicationConstant.OPEN_PROJ_COLOR,
					ApplicationConstant.OPEN_PROJ_COLOR, ApplicationConstant.OPEN_PROJ_COLOR);
		}
		TreeItem[] tree = ProjectExplorerView.viewer.getTree().getItems();
		Image moduleImage = new Image(PlatformUI.getWorkbench().getDisplay(),
				OpenProjectServiceImpl.class.getResourceAsStream(IconsPathConstant.ICON_MODULE));
		Image componentImage = new Image(PlatformUI.getWorkbench().getDisplay(),
				OpenProjectServiceImpl.class.getResourceAsStream(IconsPathConstant.ICON_COMPONENT));
		if (hierarchialView) {
			for (TreeItem treeItem : tree) {
				TreeItem[] treeChildItems = treeItem.getItems();
				for (TreeItem treeItem2 : treeChildItems) {
					createTreeForHierarchicalView(actualCompName, closedProjColor, fontStyleNormal,
							fontStyleBold, openProjectColor, moduleImage, componentImage, treeItem2);
				}
			}
		} else {
			for (TreeItem treeItem : tree) {
				TreeItem[] treeChildItems = treeItem.getItems();
				for (TreeItem treeItem2 : treeChildItems) {
					treeItem2.setImage(componentImage);
					treeItem2.setForeground(closedProjColor);
					treeItem2.setFont(fontStyleNormal);
					// Make the open component highlighted
					if (actualCompName.equals(treeItem2.getText())) {
						treeItem2.setForeground(openProjectColor);
						if (OpenProjectAction.openProjectFlag) {
							treeItem2.setFont(fontStyleNormal);
							treeItem2.setForeground(closedProjColor);
							OpenProjectAction.openProjectFlag = false;
						} else {
							treeItem2.setFont(fontStyleBold);
							treeItem2.setForeground(openProjectColor);
						}
					}
				}
			}
		}
	}

	/**
	 * Method used to create hierarchical view
	 * @param actualCompName
	 * @param closedProjColor
	 * @param fontStyleNormal
	 * @param fontStyleBold
	 * @param openProjectColor
	 * @param moduleImage
	 * @param componentImage
	 * @param treeItem2
	 */
	private void createTreeForHierarchicalView(String actualCompName, Color closedProjColor,
			Font fontStyleNormal, Font fontStyleBold, Color openProjectColor, Image moduleImage, Image componentImage,
			TreeItem treeItem2) {
		treeItem2.setForeground(closedProjColor);
		treeItem2.setFont(fontStyleNormal);
		if (treeItem2.getItems().length > 0) {
			treeItem2.setImage(moduleImage);
		} else {
			treeItem2.setImage(componentImage);
			treeItem2.setGrayed(true);
			// Make the open component highlighted
			if (actualCompName.equals(treeItem2.getText())) {
				treeItem2.setForeground(openProjectColor);
				if (OpenProjectAction.openProjectFlag) {
					OpenProjectAction.openProjectFlag = false;
				} else {
					treeItem2.setFont(fontStyleBold);
					treeItem2.setForeground(openProjectColor);
				}
			}
		}

		TreeItem[] child = treeItem2.getItems();

		for (TreeItem treeItem3 : child) {
			treeItem3.setImage(componentImage);
			// Make the closed component un-highlighted
			treeItem3.setForeground(closedProjColor);
			treeItem3.setFont(fontStyleNormal);
			// Make the open component highlighted
			if (actualCompName.equals(treeItem3.getText())) {
				treeItem3.setForeground(openProjectColor);
				if (OpenProjectAction.openProjectFlag) {
					treeItem3.setFont(fontStyleNormal);
					treeItem3.setForeground(closedProjColor);
					OpenProjectAction.openProjectFlag = false;
				} else {
					treeItem3.setFont(fontStyleBold);
					treeItem3.setForeground(openProjectColor);
				}
			}
		}
	}


	/**
	 * Method used to get outputs from the opened project while adding 
	 * in Input category
	 */
	@Override
	public JsonElement getOutputDataObjects(Project project, String componentName) throws MatlabCommunicatinException {
		JsonElement jsonElement = null;
		MatlabCommunicationDaoImpl matlabDataRequest = new MatlabCommunicationDaoImpl();

		if (project.getComponentPath() != null) {

			if (DataDictionaryApplication.getApplication().getOutputSignalJson() != null) {
				jsonElement = DataDictionaryApplication.getApplication().getOutputSignalJson();
			} else {
				JsonObject jsonObject = new JsonObject();
				jsonObject.addProperty("Name", componentName);
				JsonArray jsonArray = new JsonArray();
				jsonArray.add(jsonObject);

				String matlabQuery = CreateMatlabRequest.createMatlabRequest(
						MatlabScriptConstant.QUERYALLOUTSIGNAL, project.getPath().replace("\\", "/"),
						jsonArray.toString());
				try {
					jsonElement = matlabDataRequest.executeMatlabRequest(matlabQuery);
				} catch (MatlabCommunicatinException e) {
					LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
					throw new MatlabCommunicatinException(e.getMessage(), e);
				}
				DataDictionaryApplication.getApplication().setOutputSignalJson(jsonElement);
			}
		}
		return jsonElement;
	}

	/**
	 * Method used to get outputs from browsed sldd by user while adding
	 * in Input category
	 */
	@Override
	public JsonElement getOutputsFromBrowsedSldd(String slddPath) throws MatlabCommunicatinException {
		JsonElement jsonElement = null;
		MatlabCommunicationDaoImpl matlabDataRequest = new MatlabCommunicationDaoImpl();
		if (slddPath != null) {
				String matlabQuery = CreateMatlabRequest.createMatlabRequest(
						MatlabScriptConstant.QRYBROWSESLDD, slddPath.replace("\\", "/"),"");
				try {
					jsonElement = matlabDataRequest.executeMatlabRequest(matlabQuery);
				} catch (MatlabCommunicatinException e) {
					LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
					throw new MatlabCommunicatinException(e.getMessage(), e);
				}
			
		}
		return jsonElement;
	}

	/**
	 * Method used to get units data from MATLAB
	 */
	@Override
	public JsonElement getUnitsDataFrMatlab() throws MatlabCommunicatinException {
		JsonElement unitsJson = null;
		MatlabCommunicationDaoImpl matlabDataRequest = new MatlabCommunicationDaoImpl();
		String matlabQuery = CreateMatlabRequest.createMatlabRequest(
				MatlabScriptConstant.QRYGETUNITS, "","");
		try {
			unitsJson = matlabDataRequest.executeMatlabRequest(matlabQuery);
			if(JSONUtil.checkForUnitsFile(unitsJson)) {
				return unitsJson;
			}
		} catch (MatlabCommunicatinException mce) {
			throw new MatlabCommunicatinException(mce.getMessage(), mce);
		}
		return null;
	}
	
	/**
	 * Method used to get the symbol list from the units data from MATLAB
	 */
	@Override
	public List<String> getUnitsList() {
		JsonElement jsonElement = Application.unitsJson;
		List<CategoryAttributes> objectList = new ArrayList<CategoryAttributes>();
		List<String> symbolList = new ArrayList<String>();
		List<String> newList = new ArrayList<String>();
		Type type = new TypeToken<List<CategoryAttributes>>() {}.getType();

		objectList = GsonUtil.provider().fromJSONToList(jsonElement.getAsJsonArray().toString(), type);
		for (CategoryAttributes object : objectList) {
			String symbol = object.getName();
			String unName = object.getDescription();
			if(!(symbol.equals("#N/A") || unName.equals("#N/A"))) {
				symbolList.add(symbol+" : "+unName);
		        newList = symbolList.stream().distinct().collect(Collectors.toList()); //to remove duplicates from multiple excel files
			}
			
		}
		return newList;
	}
	
	/**
	 * Method used to get program name for opened component from Matlab
	 */
	@Override
	public String getConfigProjDataFrMatlab(String comp) throws MatlabCommunicatinException {
		JsonElement jsonElement = null;
		String programName = null;
		MatlabCommunicationDaoImpl matlabDataRequest = new MatlabCommunicationDaoImpl();
		String matlabQuery = CreateMatlabRequest.createMatlabRequest(
				MatlabScriptConstant.QRYGETPROGRAMNAME, comp,"");
		try {
			jsonElement = matlabDataRequest.executeMatlabRequest(matlabQuery);
			programName = JSONUtil.getProgramNameForComp(jsonElement);
			
		} catch (MatlabCommunicatinException mce) {
			throw new MatlabCommunicatinException(mce.getMessage(), mce);
		}
		return programName;
	}

	/**
	 * Method used to get the excel file path from Navistar MBD toolbox
	 */
	@Override
	public String getConfigExcelPath() throws MatlabCommunicatinException{
		JsonElement jsonElement = null;
		String path;

		MatlabCommunicationDaoImpl matlabDataRequest = new MatlabCommunicationDaoImpl();
		String matlabQuery = CreateMatlabRequest.createMatlabRequest(
				MatlabScriptConstant.QRYGETCONFIGFILEPATH, "","");
		try {
			jsonElement = matlabDataRequest.executeMatlabRequest(matlabQuery);
			path = JSONUtil.getProjConfigFilePath(jsonElement);
			
			if(path.equals(MatlabResponseConstant.NO_CONFIG_FILE)) {
				MessageDialog.openError(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), "Error", "Configuration file does not exist. Please add configuration file and try again");
				return null;
			}if(path.equals(MatlabResponseConstant.FOLDER_STRUC_INCOR)){
				MessageDialog.openError(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), "Error", "Configuration file does not exist. Either multiple excel files present or incorrect folder path of configuration file found");
				return null;
			}
			else {
				Application.projConfigPath = path;
			}
			
		} catch (MatlabCommunicatinException mce) {
			throw new MatlabCommunicatinException(mce.getMessage(), mce);
		}
		return path;
	}
	
}
