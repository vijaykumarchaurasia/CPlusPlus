package com.navistar.datadictionary.serviceimpl;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.navistar.datadictionary.model.FontStyleDAO;
import com.navistar.datadictionary.model.Project;
import com.navistar.datadictionary.service.WorkspaceService;
import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.ui.config.ApplicationWorkbenchWindowAdvisor;
import com.navistar.datadictionary.ui.config.DataDictionaryApplication;
import com.navistar.datadictionary.util.FileUtility;

/**
 * Class implements methods of WorkspaceService interface to implement workspace
 * related operation.
 * 
 * @author JAYSHRIVISHB
 *
 */
public class WorkspaceServiceImpl implements WorkspaceService {

	/**
	 * Function will return already imported projects and their status
	 * 
	 * @param workspacePath
	 * @return
	 */
	public List<Project> getWorkspaceHistory(String workspacePath) {
		FileUtility fileUtils = new FileUtility();
		Gson gsonObject = new Gson();
		List<Project> projectList = new ArrayList<>();
		JsonElement jsonElement = fileUtils.readFromJsonFile(workspacePath);
		if (jsonElement != null && jsonElement.isJsonArray()) {
			// If to check workspace.json is having empty array
			if (jsonElement.getAsJsonArray().size() > 0) {
				for (JsonElement jsonElements : jsonElement.getAsJsonArray()) {
					JsonArray jObj = jsonElements.getAsJsonArray();
					if (jObj.size() > 0) {
						JsonObject jsonOBJ = jObj.get(0).getAsJsonObject();
						if (jsonOBJ.has("path")) {
							Type type = new TypeToken<List<Project>>() {
							}.getType();
							projectList = gsonObject.fromJson(jObj, type);
						} else if (jsonOBJ.has("recentlyImportedProjectList")) {
							ApplicationWorkbenchWindowAdvisor.recentlyImpProj = jsonOBJ
									.get("recentlyImportedProjectList").getAsString();
							DataDictionaryApplication.getApplication().recentImpProjMap.put(
									"recentlyImportedProjectList",
									ApplicationWorkbenchWindowAdvisor.recentlyImpProj);
						} else if (jsonOBJ.has("font")) {
							// FontStyleDAO= gsonObject.fromJson(jObj, type);
							FontStyleDAO[] daos = gsonObject.fromJson(jObj, FontStyleDAO[].class);
							DataDictionaryApplication.getApplication().fontStyle = daos[0];
						}
					}
				}
			}
		}
		return projectList;
	}

	/**
	 * Function used to save current status of workspace
	 * 
	 * @param workspacePath
	 * @return
	 */
	public boolean saveWorkspaceHistory(String workspacePath) {
		Map<String, Project> projStatusMap = DataDictionaryApplication.getApplication().projStatusMap;
		FontStyleDAO fontStyle = DataDictionaryApplication.getApplication().fontStyle;
		Gson gsonObject = new Gson();
		FileUtility fileUtils = new FileUtility();
		// Convert project objects into json object
		String projectListJson = gsonObject.toJson(projStatusMap.values());
		String fontStyleJson = gsonObject.toJson(fontStyle);
		String recentProjString = "";
		Map<String, String> recentMap = new HashMap<>();
		if (ApplicationActionBarAdvisor.pathList.size() > 0) {
			for (int i = 0; i < ApplicationActionBarAdvisor.pathList.size(); i++) {
				if (i == 0) {
					recentProjString = recentProjString
							+ ApplicationActionBarAdvisor.pathList.get(i);
				} else {
					recentProjString = recentProjString + ","
							+ ApplicationActionBarAdvisor.pathList.get(i);
				}
			}
			recentMap.put("recentlyImportedProjectList", recentProjString);
		}
		if (recentMap != null) {
			recentProjString = gsonObject.toJson(recentMap);
		}

		if (!projectListJson.equals("") || !fontStyleJson.equals("")) {
			projectListJson = "[" + projectListJson + "," + "[" + recentProjString + "]" + "," + "["
					+ fontStyleJson + "]" + "]";
		}

		boolean writeStatus = fileUtils.writeIntoJsonFile(projectListJson, workspacePath);

		return writeStatus;
	}
}
