package com.navistar.datadictionary.serviceimpl;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.PlatformUI;

import com.navistar.datadictionary.action.EditorPreference;
import com.navistar.datadictionary.action.OpenProjectAction;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.IconsPathConstant;
import com.navistar.datadictionary.constant.LoggerConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.daoimpl.MatlabEngineConnectionDaoImpl;
import com.navistar.datadictionary.model.FontStyleDAO;
import com.navistar.datadictionary.model.Node;
import com.navistar.datadictionary.model.Project;
import com.navistar.datadictionary.service.CheckComponentInputsService;
import com.navistar.datadictionary.service.CloseProjectService;
import com.navistar.datadictionary.service.EditorService;
import com.navistar.datadictionary.service.OpenProjectService;
import com.navistar.datadictionary.ui.config.Application;
import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.ui.config.DataDictionaryApplication;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.ui.editors.IOCompatibilityEditor;
import com.navistar.datadictionary.ui.views.ActivityLogView;
import com.navistar.datadictionary.ui.views.ProjectExplorerView;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Class implements methods of OpenProjectService interface to implement open project operation.
 * @author JAYSHRIVISHB
 *
 */
public class OpenProjectServiceImpl implements OpenProjectService {
	
	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(OpenProjectServiceImpl.class);
	
	/** Instance of ImportProjectStructureService */
	private ImportProjectServiceImpl importService = new ImportProjectServiceImpl();
	
	/** It is used to store index of open project */
	public static int index = 0;
	
	/**Used to validate close projects*/
	private CloseProjectService closeProjService;
	
	/** Used to access check editors */
	private EditorService editorService;
	
	/** Used to call method for closing Component Inputs view */
	private CheckComponentInputsService checkCompInObj;
	
	/**
	 * Default Constructor
	 */
	public OpenProjectServiceImpl() {
		closeProjService = new CloseProjectServiceImpl();
		editorService = new EditorServiceImpl();
		checkCompInObj=new CheckComponentInputsServiceimpl();
	}

	/**
	 * Method used to open project in project explorer
	 * @param editor
	 * @throws Exception 
	 */
	public boolean performOpenProjectAction(IEditorPart editor) throws Exception {
		boolean isCancelSel = false;
		try {
			LOGGER.info(LoggerConstant.OPEN_PROJ_ACTION);
			Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
			boolean saveDialogRetVal = false;

			//2 represents cancel of message dialog
			int saveDialogSelVal = 2;
			boolean dialogReturnValue = false;
			String firstProjectOpen = ApplicationConstant.EMPTY_STRING;
			// Check if IOCompatibilityEditor is opened 
			if(editor instanceof IOCompatibilityEditor) {
				dialogReturnValue = MessageDialog.openConfirm(shell, ApplicationConstant.WARNING,
						ApplicationConstant.OPEN_PROJ_MSG);
				firstProjectOpen = ApplicationConstant.EMPTY_STRING;
				if((dialogReturnValue) || (ApplicationConstant.FIRSTPROJOPEN.equals(firstProjectOpen))) {
					Application.ioJsonElement = null;
					ApplicationActionBarAdvisor.getInstance().ioCompatWinAction.setChecked(false);
					ApplicationActionBarAdvisor.getInstance().searchWindowObj.setChecked(false);
					LOGGER.info("Closing Check Components Window");
					checkCompInObj.closeCheckCompInputsWindow();
					LOGGER.info("Closing all Editors");
					editorService.closeAllEditors();	// Close all editors of previous project
					LOGGER.info("Opening Project in Explorer");
					openProjectInExplorer(); 	// Open a selected project in explorer
				}
			}else if(editor instanceof CategoryEditor){	//Check if any of the editors are opened
				CategoryEditor categoryEditor = (CategoryEditor)editor;
				// add pop up if any project is open
				for (String projectPath : DataDictionaryApplication.getApplication().projStatusMap.keySet()) {
					if (DataDictionaryApplication.getApplication().projStatusMap.get(projectPath).getStatus() == 1) {
						if (editorService.checkForUnsavedEditors()) {
							MessageDialog dialog = new MessageDialog(shell, ApplicationConstant.WARNING, null,
									ApplicationConstant.SAVEOPENPROJMSG, MessageDialog.CONFIRM,
									new String[] { ApplicationConstant.BTN_SAVE_ALL, ApplicationConstant.BTN_DISCARD, ApplicationConstant.BTN_CANCEL }, 0);
							saveDialogSelVal = dialog.open();
							if(saveDialogSelVal==2) {
								isCancelSel = true;
								LOGGER.info("User pressed cancel while opening project when category table is edited");
								return isCancelSel;
							}
							saveDialogRetVal = true;
							firstProjectOpen = ApplicationConstant.FIRSTPROJOPEN;
						} else {
							dialogReturnValue = MessageDialog.openConfirm(shell, ApplicationConstant.WARNING,
									ApplicationConstant.OPEN_PROJ_MSG);
							firstProjectOpen = ApplicationConstant.EMPTY_STRING;
							if(!dialogReturnValue) {
								isCancelSel = true;
								LOGGER.info("User pressed cancel while opening project when category table is not edited");
								return isCancelSel;
							}
						}
						break;
					}
					firstProjectOpen = ApplicationConstant.FIRSTPROJOPEN;
				}
				LOGGER.info("Checking if project is Opening for the first time");
				checkOpenProjectFirstTime(dialogReturnValue,saveDialogRetVal,saveDialogSelVal,firstProjectOpen,categoryEditor);
			}else {
				LOGGER.info("Opening Project in Explorer");
				openProjectInExplorer();	// Open a selected project in explorer
			}
			ProjectExplorerView.getInstance().hierarchiViewObj.setEnabled(true);
			PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell().setText("Data Dictionary");
		}
		catch(Exception exception) {
			throw exception;
		}
		return isCancelSel;
	}
	
	/**
	 * Method used to check project is opening for the first time
	 * @param dialogReturnValue
	 * @param saveAlldialogReturnValue
	 * @param saveAllDialogSelectedValue
	 * @param firstProjectOpen
	 * @param categoryEditor
	 */
	public void checkOpenProjectFirstTime(boolean dialogReturnValue,boolean saveDialogRetVal,int saveDialogSelVal,String firstProjectOpen,CategoryEditor categoryEditor)
	{
		try {
			if ((dialogReturnValue) || (ApplicationConstant.FIRSTPROJOPEN.equals(firstProjectOpen))
					|| ((saveDialogRetVal) && saveDialogSelVal == 0)) {
				Application.ioJsonElement = null;
				ApplicationActionBarAdvisor.getInstance().ioCompatWinAction.setChecked(false);
				ApplicationActionBarAdvisor.getInstance().searchWindowObj.setChecked(false);
				checkCompInObj.closeCheckCompInputsWindow();
				// Check if any editor is having unsaved data
				if (editorService.checkForUnsavedEditors()) {
					int result = closeProjService.closeProjectHandler(saveDialogRetVal,saveDialogSelVal);
					// if user choose to save exiting editors data then save all and open a new project
					if (result == 0 && !categoryEditor.emptyFieldFlag) {
						LOGGER.info("Save all Operation Completed");
						LOGGER.info("Closing all Editors");
						editorService.closeAllEditors();	// Close all editors of previous project
						LOGGER.info("Opening Project in Explorer");
						openProjectInExplorer();	// Open a selected project in explorer
					}else if(result == 1){	//If users choses to discard all the changes
						if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
							ActivityLogView.activityLog.append("\n [INFO]: Changes discarded successfully");
						}
						LOGGER.info("Discard Operation Completed");
						editorService.removeDirtyIndicator();	//remove unsaved changes and load tabs with saved data
						LOGGER.info("Closing all Editors");
						editorService.closeAllEditors();	// Close all editors of previous project
						LOGGER.info("Opening Project in Explorer");
						openProjectInExplorer();	// Open a selected project in explorer
					}
					else if(result ==2)
					{
						LOGGER.info("Cancel Operation Completed");
					}
					else {
						LOGGER.info("Closing all Editors");
						editorService.closeAllEditors();	// Close all editors of previous project
						LOGGER.info("Opening Project in Explorer");
						openProjectInExplorer();	// Open a selected project in explorer
					}
				} else if((dialogReturnValue) || (ApplicationConstant.FIRSTPROJOPEN.equals(firstProjectOpen))) {
					LOGGER.info("Opening Project for the first time");
					LOGGER.info("Discard Operation Completed");
					editorService.removeDirtyIndicator();	//remove unsaved changes and load tabs with saved data
					LOGGER.info("Closing all Editors");
					editorService.closeAllEditors();	// Close all editors of previous project
					openProjectInExplorer();	// Open a selected project in explorer
				}
				ApplicationActionBarAdvisor.getInstance().closeProjAction.setEnabled(true);
				//ApplicationActionBarAdvisor.getInstance().ioCompatAction.setEnabled(true);
				ApplicationActionBarAdvisor.getInstance().searchAction.setEnabled(true);
				//ApplicationActionBarAdvisor.getInstance().validProjAction.setEnabled(true);
				//ApplicationActionBarAdvisor.getInstance().validateProjParaTypeAction.setEnabled(true);
			}
		}
		catch(Exception exception) {
			throw exception;
		}
	}

	/**
	 * Method used to open a project inside explorer
	 */
	public void openProjectInExplorer() {
		try {
			OpenComponentServiceImpl.selCompName="";
			String projectName;
			projectName = enableProject();
			Tree tree = ProjectExplorerView.viewer.getTree();
			int treeItemCount = tree.getItems().length;
			LOGGER.info("Updating Project and Status Map");
			Display display = PlatformUI.getWorkbench().getDisplay();
			Image projectImage = new Image(display, OpenProjectServiceImpl.class.getResourceAsStream(IconsPathConstant.OPEN_PROJECT_ICON));
			Image closedProjImage = new Image(display, OpenProjectServiceImpl.class.getResourceAsStream(IconsPathConstant.CLOSE_PROJ_ICON));
			Image componentImage = null;
			FontStyleDAO fontStyle = DataDictionaryApplication.getApplication().fontStyle;
			Font treeItemNFont;  
			Font treeItemBoldFont;  
			Color openProjectColor;
			Color closeProjectColor = new Color(display, ApplicationConstant.CLOSE_PROJ_COLOR,ApplicationConstant.CLOSE_PROJ_COLOR, ApplicationConstant.CLOSE_PROJ_COLOR);
			//If font is set and store default font is not set then apply the selected font else set default font
			if(fontStyle != null && fontStyle.getFont() != null && !EditorPreference.isDefFontSel) {
				treeItemNFont = new Font(display, fontStyle.getFont(),fontStyle.getSize(), SWT.NORMAL);
				treeItemBoldFont = new Font(display, fontStyle.getFont(),fontStyle.getSize(), SWT.BOLD);
				openProjectColor = new Color(display, fontStyle.getFontColor());
				componentImage = new Image(display, OpenProjectServiceImpl.class.getResourceAsStream("/icons/IO.png"));
			} else {
				treeItemNFont = new Font(display, ApplicationConstant.FONT_STYLE, ApplicationConstant.HIGHFONTSIZE, SWT.NORMAL);
				treeItemBoldFont = new Font(display, ApplicationConstant.FONT_STYLE, ApplicationConstant.HIGHFONTSIZE, SWT.BOLD);
				openProjectColor = new Color(display, ApplicationConstant.OPEN_PROJ_COLOR,ApplicationConstant.OPEN_PROJ_COLOR, ApplicationConstant.OPEN_PROJ_COLOR);
			}
			for (int i = 0; i < treeItemCount; i++) {
				tree.getItem(i).setImage(projectImage);
				TreeItem itemList[] = tree.getItem(i).getItems();
				for(TreeItem item: itemList) {
					item.setImage(componentImage);
					item.setFont(	treeItemNFont);
					item.setForeground(openProjectColor);
				}
				if (projectName.equals(tree.getItem(i).getText())) {
					importService.updateProjectStatus(projectName, ApplicationConstant.OPEN_PROJ_STATUS, "");
					tree.getItem(i).setImage(projectImage);
					tree.getItem(i).setFont(treeItemBoldFont);
					tree.getItem(i).setForeground(openProjectColor);
				} else {
					importService.updateProjectStatus(tree.getItem(i).getText(), ApplicationConstant.CLOSE_PROJ_STATUS, "");
					tree.getItem(i).setForeground(closeProjectColor);
					tree.getItem(i).setFont(treeItemNFont);
					tree.getItem(i).setImage(closedProjImage);
				}
			}
			LOGGER.info("Project and Status Map Updated");
			LOGGER.info("Project Path Add/Remove  in Matlab");
			//add or remove path in Matlab depending on project status
			addOrRemovePathInMatlab();
			LOGGER.info("Project Path Added/Removed  in Matlab");
			OpenProjectAction.openProjectName = projectName;
			// Close the window and reset the default data.
			ViewUtil.closeView(ViewIDConstant.TABLE_EDITOR);
			ViewUtil.closeView(ViewIDConstant.SEARCH_RESULT);
			DataDictionaryApplication.getApplication().setSearchedDataList(null);
			DataDictionaryApplication.getApplication().setSearchedHighLight(false);
			DataDictionaryApplication.getApplication().setSearchedHighlighted(null);
			ViewUtil.closeView(ViewIDConstant.CHECK_IO_COMPAT);
			Application.ioJsonElement = null;
			ApplicationActionBarAdvisor.getInstance().closeProjAction.setEnabled(true);
		}
		catch(Exception exception) {
			throw exception;
		}
		
	}

	/**
	 * Method used to add or remove project path in Matlab
	 */
	public void addOrRemovePathInMatlab() {
		try {
			MatlabEngineConnectionDaoImpl matlabConnection = new MatlabEngineConnectionDaoImpl();
	        //first remove the path then add
			//for that sorted the map based on the status of project
			Map<String, Project> sortedMap = DataDictionaryApplication.getApplication().projStatusMap.entrySet()
	                                             .stream()
	                                             .sorted(Entry.comparingByValue(OpenProjectServiceImpl::compare))
	                                             .collect(Collectors.toMap(Entry::getKey, Entry::getValue,
	                                                     (e1, e2) -> e1, LinkedHashMap::new));

	    

	    
			for (Map.Entry<String, Project> entry : sortedMap.entrySet()) {
				if (entry.getValue().getStatus() == 1) {
					matlabConnection.addProjectPath(entry.getValue().getPath());
				}
				else if(entry.getValue().getStatus() == 0) {
					matlabConnection.removeProjectPath(entry.getValue().getPath());
				}
			}
		}
		catch(Exception exception) {
			throw exception;
		}
	}
	
	public static int compare(Project e1, Project e2) {
        return e1.getStatus() - e2.getStatus();
    }
	/**
	 * This method is used to enable the project after it is open
	 * 
	 * @param viewer
	 * @return
	 */
	public String enableProject() {
		try {
			Device device;
			Tree tree = ProjectExplorerView.viewer.getTree();
			IStructuredSelection selected = (IStructuredSelection) ProjectExplorerView.viewer.getSelection();
			Node selectNode = (Node) selected.getFirstElement();
			TreeItem[] item = tree.getSelection();
			TreeItem[] item2 = ProjectExplorerView.viewer.getTree().getItems();
			String projectName = item[0].getText();
			int counter = 0;
			device = PlatformUI.getWorkbench().getDisplay();
			Color closeProjectColor = new Color(device, ApplicationConstant.CLOSE_PROJ_COLOR, ApplicationConstant.CLOSE_PROJ_COLOR, ApplicationConstant.CLOSE_PROJ_COLOR);
			LOGGER.info("Enabling Project");
			FontStyleDAO fontStyle = DataDictionaryApplication.getApplication().fontStyle;
			Font fontStyleNormal;
			Font fontStyleBold;
			Color openProjectColor;
			if(fontStyle != null && fontStyle.getFont() != null && !EditorPreference.isDefFontSel) {
				fontStyleNormal = new Font(device, fontStyle.getFont(), fontStyle.getSize(), SWT.NORMAL);
				fontStyleBold = new Font(device, fontStyle.getFont(),fontStyle.getSize(), SWT.BOLD);
				openProjectColor = new Color(device, fontStyle.getFontColor());
			} else {
				fontStyleNormal = new Font(device, ApplicationConstant.HIGHLIGHTFONTSTYL, ApplicationConstant.HIGHFONTSIZE, SWT.NORMAL);
				fontStyleBold = new Font(device, ApplicationConstant.HIGHLIGHTFONTSTYL,ApplicationConstant.HIGHFONTSIZE, SWT.BOLD);
				openProjectColor = new Color(device, ApplicationConstant.OPEN_PROJ_COLOR,ApplicationConstant.OPEN_PROJ_COLOR, ApplicationConstant.OPEN_PROJ_COLOR);
			}
			for (TreeItem treeItem : item2) {
				// To make closed project non-highlighted(grey)
				treeItem.setForeground(closeProjectColor);
				treeItem.setFont(fontStyleNormal);
				if (projectName.equals(treeItem.getText())) {
					index = counter;
					// To make open project highlighted(black)
					treeItem.setForeground(openProjectColor);
					treeItem.setFont(fontStyleBold);
					break;
				}
				counter = counter + 1;
			}
			ProjectExplorerView.viewer.setExpandedState(selectNode, !ProjectExplorerView.viewer.getExpandedState(selectNode));
			ProjectExplorerView.viewer.refresh();
			LOGGER.info("Project Enabled");
			LOGGER.info("Disabling other projects");
			// Disable all the project logic start here
			for (counter = 0; counter < item2.length; counter++) {
				if (counter != index) {
					tree.getItem(counter).setItemCount(0);
					//Set the gray color for disabled project
					tree.getItem(counter).setForeground(new Color(device, ApplicationConstant.CLOSE_PROJ_COLOR,ApplicationConstant.CLOSE_PROJ_COLOR,ApplicationConstant.CLOSE_PROJ_COLOR));
					tree.getItem(counter).setFont(fontStyleNormal); 
				}
			}
			LOGGER.info("Other Projects Disabled");
			return projectName;
		}
		catch(Exception exception) {
			throw exception;
		}
	}

	/**
	 * Method is used the name of opened project
	 * @return
	 */
	@Override
	public String getOpenedProjectName() {
		try {
			String openedProjectName="";
			for(String projectPathAsKey : DataDictionaryApplication.getApplication().projStatusMap.keySet())
			{
				Project project = DataDictionaryApplication.getApplication().projStatusMap.get(projectPathAsKey);
				if(project.getStatus()==1){
					String openedProjectPath = project.getPath();
					String folder[] = openedProjectPath.split("\\\\");
					openedProjectName = folder[folder.length - 1];
					break;
				}		
			}
			return openedProjectName;
		}
		catch(Exception exception) {
			throw exception;
		}
	}
}
