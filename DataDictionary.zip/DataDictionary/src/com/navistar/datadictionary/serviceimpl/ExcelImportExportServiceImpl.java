package com.navistar.datadictionary.serviceimpl;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.nebula.widgets.nattable.viewport.command.ShowRowInViewportCommand;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.reflect.TypeToken;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.MatlabQueryConstant;
import com.navistar.datadictionary.constant.MatlabScriptConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.customexception.EditorInitilizationException;
import com.navistar.datadictionary.customexception.EditorReuseException;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.dao.MatlabCommunicationDao;
import com.navistar.datadictionary.daoimpl.MatlabCommunicationDaoImpl;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.model.CategoryAttributesIo;
import com.navistar.datadictionary.model.Project;
import com.navistar.datadictionary.operation.SaveOperation;
import com.navistar.datadictionary.service.ExcelImportExportService;
import com.navistar.datadictionary.service.OpenComponentService;
import com.navistar.datadictionary.ui.config.Application;
import com.navistar.datadictionary.ui.config.DataDictionaryApplication;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.ui.editors.IOCompatibilityEditorInput;
import com.navistar.datadictionary.ui.editors.ResolveInconAttributesEditor;
import com.navistar.datadictionary.ui.nattable.DeleteRowCommand;
import com.navistar.datadictionary.ui.views.ActivityLogView;
import com.navistar.datadictionary.ui.views.ProjectExplorerView;
import com.navistar.datadictionary.util.CreateMatlabRequest;
import com.navistar.datadictionary.util.DataDictionaryUtil;
import com.navistar.datadictionary.util.GsonUtil;
import com.navistar.datadictionary.util.JSONUtil;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Business logic for Import/Export from Excel to Sldd
 * @author nikitak1
 *
 */

public class ExcelImportExportServiceImpl implements ExcelImportExportService {
	
	/** To access opened component */
	private OpenComponentService openCompServ;

	/** To check if inconsistency found for sldd data objects */
	public boolean addInSlddObject;

	/** To check if inconsistency found for model data objects */
	public boolean delFromSlddObject;

	public static boolean resDdDelFlg = false;
	
	public static boolean resDdAddFlg = false;
	
	public static List<CategoryAttributes> addFrmExcelList = new ArrayList<>();
	
	/** Used to access matlab communication dao */
	MatlabCommunicationDao matlabDataRequest = new MatlabCommunicationDaoImpl();
	
	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(ExcelImportExportServiceImpl.class);
		
	/** Used to perform save operation */
	public SaveOperation saveOperation = new SaveOperation();
	
	public boolean delFromExcel;
	
	public boolean addInExcel;
	
	public ExcelImportExportServiceImpl() {
		
		openCompServ = new OpenComponentServiceImpl();
		addInSlddObject = true;
		delFromSlddObject = true;
		addInExcel = true;
		delFromExcel = true;
	}
	
	/**
	 * Method used to get data objects from excel to add and delete in sldd
	 */
	@Override
	public JsonElement getDataObjectsForSldd(String excelPath) throws MatlabCommunicatinException {
		JsonElement jsonElement = null;
		String componentPath = openCompServ.getOpenedComponentPath();
		componentPath = componentPath.replace("\\", "/");
		MatlabCommunicationDaoImpl matlabCommImpl = new MatlabCommunicationDaoImpl();
		Project project = ProjectExplorerView.getActiveProject();

		if (project.getComponentPath() != null) {

			String matlabQuery = CreateMatlabRequest.createMatlabRequest(MatlabScriptConstant.QUERYEXCELIMPORT,
					componentPath+","+excelPath, "");
			try
			{
				jsonElement = matlabCommImpl.executeMatlabRequest(matlabQuery);
			}
			catch(Exception e)
			{
				throw new MatlabCommunicatinException(e.getMessage(), e);
			}
		}

		return jsonElement;
	}

	
	/**
	 * Method is used to parse JSON data and convert into HashMap.
	 * 
	 * @param jsonElement
	 * @return inconListMap
	 * @throws MatlabCommunicatinException 
	 */
	@Override
	public Map<String, List<CategoryAttributes>> convertInconsistencyListToMap(JsonElement jsonElement) {
		
		Map<String, List<CategoryAttributes>> inconListMap = new LinkedHashMap<String, List<CategoryAttributes>>();
		Type type = new TypeToken<List<CategoryAttributes>>() {
		}.getType();

		// Check if empty JSON element
		if (jsonElement != null) {
			// Check if lists from matlab are valid and error code free
			if (JSONUtil.checkExcelToSlddDataIsValid(jsonElement)) {

				// Parse the JSON details and convert into Map
				for (JsonElement jsonArray : jsonElement.getAsJsonArray()) {

					// check for error code and set error message accordingly
					if (jsonArray != null && jsonArray.isJsonArray()) {
						JsonElement errorObject = jsonArray.getAsJsonArray().get(0);
						if (errorObject.isJsonObject()
								&& errorObject.getAsJsonObject().has(MatlabQueryConstant.ERROR_CODE)) {
							String errorValue = errorObject.getAsJsonObject().get(MatlabQueryConstant.ERROR_CODE)
									.getAsString();
							checkWhichListIsEmpty(errorValue);
						}  
						else {
							displayInconsistencyInBothList(inconListMap, type, jsonArray);
						}

					}
					checkHashNAInNameFromExcel(inconListMap);
				}

			} else if(jsonElement.getAsJsonArray().get(0).getAsJsonObject().has("errorCode")) {
				checkMatlabRespCode(jsonElement);
			}
		}
		return inconListMap;
	}


	/**
	 * Method used to check different error codes sent by Matlab script
	 * @param jsonElement
	 */
	public boolean checkMatlabRespCode(JsonElement jsonElement) {
		JsonArray jsonArray = jsonElement.getAsJsonArray();
		Map<String,String> errorDispMap = new HashMap<>();
		Shell shell = new Shell(PlatformUI.getWorkbench().getDisplay(),SWT.ON_TOP);
		boolean isSingleObj = false;
		for(JsonElement jsonElement2: jsonArray) {
			if(jsonElement2.isJsonObject()) {
				isSingleObj= true;
				if(jsonElement.getAsJsonArray().get(0).getAsJsonObject().has("messageCode")) {
					String messageCode = jsonElement.getAsJsonArray().get(0).getAsJsonObject().get("messageCode").getAsString();
					if(messageCode.equals("920")) {	
						MessageDialog.openInformation(shell,ApplicationConstant.SUCCESS,"Data objects updated in excel sheet successfully");	
						if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
							ActivityLogView.activityLog.append("\n [INFO]: Data objects updated in excel sheet successfully");
						}
					}if(messageCode.equals("945")) {
						MessageDialog.openInformation(shell,ApplicationConstant.SUCCESS,"Attributes replaced successfully");
						if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
							ActivityLogView.activityLog.append("\n [INFO]: Data objects updated in excel sheet successfully");
						}
						return true;
					}
				}else {
					checkErrorCode(jsonElement);
				}
			}
		}		

		if(!isSingleObj) {
			for(JsonElement jsonElement2:jsonElement.getAsJsonArray()) {
				if(jsonElement2.getAsJsonArray().get(0).getAsJsonObject().has("errorCode")) {
					String dupliName = jsonElement2.getAsJsonArray().get(0).getAsJsonObject().get("Name").toString();
					String message = jsonElement2.getAsJsonArray().get(0).getAsJsonObject().get("attribute").toString();
					errorDispMap.put(dupliName, message);
				}

			}
			if(!errorDispMap.isEmpty()) {
				Iterator<Entry<String, String>> iterator = errorDispMap.entrySet().iterator();
				String dispError="";
				while(iterator.hasNext()) {
					Map.Entry<String,String> obj = iterator.next();
					dispError = dispError+"Data object "+ obj.getKey()+" "+obj.getValue()+"\n";
				}	
				MessageDialog.openWarning(shell,ApplicationConstant.WARNING,dispError.replaceAll("\"", ""));

			}
		}
		return false;
	}


	/**
	 * Method used to display pop-up based on error codes sent by MATLAB
	 * @param jsonElement
	 */
	private void checkErrorCode(JsonElement jsonElement) {
		String errorCode = jsonElement.getAsJsonArray().get(0).getAsJsonObject().get("errorCode").getAsString();
		
		if(errorCode.equals("901")) {	
			ViewUtil.dispInfoInMsgDialog("Please select excel sheet");
		}else if(errorCode.equals("904")) {
			ViewUtil.dispInfoInMsgDialog("Component not present in excel sheet");
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [INFO]: Opened component not present in excel sheet");
			}
		}else if(errorCode.equals("912")) {
			ViewUtil.dispInfoInMsgDialog("'Source Variable' not present. Please select valid excel sheet");
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [INFO]: 'Source Variable' not present in excel sheet");
			}
		}else if(errorCode.equals("913")) {
			ViewUtil.dispInfoInMsgDialog("'Destination Variable' not present. Please select valid excel sheet");
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [INFO]: 'Destination Variable' not present in excel sheet");
			}
		}else if(errorCode.equals("921")) {
			ViewUtil.dispInfoInMsgDialog("Please close the excel sheet and try again");
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [INFO]: Excel sheet should be closed while performing current operation");
			}
		}else if(errorCode.equals("944")) {
			ViewUtil.dispInfoInMsgDialog("No other data object available to replace attributes");
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [INFO]: No other data object available to replace attributes");
			}
		}else if(errorCode.equals("907")) {
			ViewUtil.dispInfoInMsgDialog("Data object not present in excel");
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [INFO]: Data object is not present in excel");
			}
		}else if(errorCode.equals("931")) {
			ViewUtil.dispInfoInMsgDialog("Either Input and Output data object not present in SLDD or no inconsistent data object found");
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [INFO]: Either Input and Output data object not present in SLDD or no inconsistent data object found");
			}
		}else if((errorCode).equals("999")) {
			ViewUtil.dispInfoInMsgDialog("Input and Output data objects are not present in SLDD");
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [INFO]: Input and Output data objects are not present in SLDD");
			}
		}else if((errorCode).equals("1234")) {
			ViewUtil.dispInfoInMsgDialog("No inconsistent I/O attributes found");
			if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
				ActivityLogView.activityLog.append("\n [INFO]: No inconsistent I/O attributes found");
			}
		}
	}
	
	/**
	 * Method used to check which inconsistencies are present.
	 * DD inconsistencies- Add data object in data dictionary
	 * Model inconsistencies- Remove data object from data dictionary
	 * @param errorValue
	 */
	private void checkWhichListIsEmpty(String errorValue) {
		if (errorValue.equals("902")) {
			addInSlddObject = false;
		}
		if (errorValue.equals("903")) {
			delFromSlddObject = false;
		}
		if(errorValue.equals("905")) {
			addInExcel = false;
		}
		if(errorValue.equals("906")) {
			delFromExcel = false;
		}
	}
	
	
	/**
	 * Method used to display inconsistencies in both add and delete lists.
	 * @param inconsistencyListMap
	 * @param type
	 * @param jsonArray
	 */
	@Override
	public void displayInconsistencyInBothList(Map<String, List<CategoryAttributes>> inconsistencyMap, Type type,
			JsonElement jsonArray) {
		String updatedArray = jsonArray.toString().replaceAll("Null", "");
		List<CategoryAttributes> inconsistencyList = GsonUtil.provider()
				.fromJSONToList(updatedArray, type);
		
		if (inconsistencyList != null && !inconsistencyList.isEmpty()) {
			CategoryAttributes inconAttr = inconsistencyList.get(0);
			inconsistencyMap.put(inconAttr.getWarning(), inconsistencyList);
		}
		
	}


	/**
	 * Method used to check if Add in Data Dictionary list contains
	 * name having {@link #N/A in it
	 * @param inconsistencyListMap
	 */
	@Override
	public void checkHashNAInNameFromExcel(Map<String, List<CategoryAttributes>> inconsistencyMap) {
		boolean blankObjFlag = false;
		boolean nameObjFlag = false;
		
		for (String warning : inconsistencyMap.keySet()) {
			List<CategoryAttributes> inconList = inconsistencyMap.get(warning);
			if (warning.equals("Add in DataDictionary")) {
				Iterator<CategoryAttributes> iterator;
				for (iterator = inconList.iterator(); iterator.hasNext();) {
					CategoryAttributes category = (CategoryAttributes) iterator.next();
					{
						if(category.getName().equals("#N/A")) {
							blankObjFlag = true;
						}else {
							nameObjFlag = true;
						}
					}
				}
				
			}
			if(warning.equals("Delete from excel")) {
				
				Iterator<CategoryAttributes> iterator;
				for (iterator = inconList.iterator(); iterator.hasNext();) {
					CategoryAttributes category = (CategoryAttributes) iterator.next();
					{
						if(category.getName().equals("#N/A")) {
							blankObjFlag = true;
						}else {
							nameObjFlag = true;
						}
					}
				}
				
			
				
			}
			if(warning.equals("Add in DataDictionary") && blankObjFlag && !nameObjFlag) {
				addInSlddObject = false;
				
			}else if(warning.equals("Delete from excel") && blankObjFlag && !nameObjFlag) {
				delFromExcel = false;
			}
		}
		
	}
	/**
	 * Method used to display the inconsistent data objects to add on UI
	 * and delete extra objects from UI
	 * @param addCheckBoxList
	 * @param delCheckBoxList
	 * @throws MatlabCommunicatinException 
	 * @throws EditorReuseException 
	 * @throws EditorInitilizationException 
	 */
	@Override
	public void resolveInconsistencyFromExcel(List<CategoryAttributes> addCheckBoxList, List<CategoryAttributes> delCheckBoxList) throws MatlabCommunicatinException, EditorReuseException, EditorInitilizationException {

		IWorkbenchPage activePage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();	
		IEditorReference[] editorRef = activePage.getEditorReferences();
		List<String> dataObjectList = new ArrayList<>();
		List<CategoryAttributes> deletedUpdateList = null;
		int objectCount = 0;
		Map<String,List<CategoryAttributes>> attributesMap = new HashMap<String,List<CategoryAttributes>>();
		Map<CategoryEditor,Integer> rowCntMap = new HashMap<>();
		
		for(CategoryAttributes object : delCheckBoxList){
			String categoryName = object.getCategory();
			objectCount = objectCount + 1;
			for(IEditorReference editor : editorRef){
				IEditorPart editorPart = editor.getEditor(false);
				if(editorPart instanceof CategoryEditor && editorPart.getTitle().equals(categoryName)){
					CategoryEditor categoryEditor = (CategoryEditor)editorPart;
					object.setComponent(openCompServ.getOpenedComponentName());
					DataDictionaryApplication.getApplication().setSearchedHighlighted(object);
					DataDictionaryApplication.getApplication().setSearchedHighLight(true);
					activePage.activate(categoryEditor);
					int deleteSearchIndex = DataDictionaryUtil.searchIndex(object.getName(),object.getComponent(),object.getCategory(), categoryEditor.createNatTable.getJsonDataProvider().getList());
					categoryEditor.createNatTable.getSelectionLayer().doCommand(
							new DeleteRowCommand(categoryEditor.createNatTable.getSelectionLayer(), deleteSearchIndex));
					resDdDelFlg = true;
					if(attributesMap.isEmpty())
					{
						deletedUpdateList = new ArrayList<>();
						deletedUpdateList.add(object);
						attributesMap.put(editorPart.getTitle(),deletedUpdateList);
					}
					else if(attributesMap.containsKey(editorPart.getTitle())) 
					{
						List<CategoryAttributes> list = attributesMap.get(editorPart.getTitle());
						list.add(object);
					}
					else
					{
						deletedUpdateList = new ArrayList<>();
						deletedUpdateList.add(object);
						attributesMap.put(editorPart.getTitle(),deletedUpdateList);
					}
				
					CategoryEditor.deletedListMap=attributesMap;
					categoryEditor.setDirtyStatus(true);
					saveOperation.makeSaveEnableDisable(categoryEditor);
					
				}
			}
		}
		
		for(CategoryAttributes object : addCheckBoxList){
			String categoryName = object.getCategory();

			for(IEditorReference editor : editorRef){
				IEditorPart editorPart = editor.getEditor(false);
				if(editorPart instanceof CategoryEditor && editorPart.getTitle().equals(categoryName)){
					
					CategoryEditor categoryEditor = (CategoryEditor)editorPart;
					categoryEditor.displayNewObjectsAfterResolveExcel(object,categoryName);
					object.setComponent(openCompServ.getOpenedComponentName());
					categoryEditor.setDirtyStatus(true);
					resDdAddFlg = true;
					DataDictionaryApplication.getApplication().setSearchedHighlighted(object);
					DataDictionaryApplication.getApplication().setSearchedHighLight(true);
					activePage.activate(categoryEditor);	
					dataObjectList.add(object.getName());
					categoryEditor.addNatTableConfigurationForAddResolve(object.getName(),object.getComponent(),object.getCategory(),dataObjectList,object,addFrmExcelList);
					categoryEditor.setDirtyStatus(true);
					rowCntMap.put(categoryEditor, categoryEditor.createNatTable.getJsonDataProvider().getRowCount());
					saveOperation.makeSaveEnableDisable(categoryEditor);
				}
			}
		}
		//added separate loop for configuring nattable due to Unhandled event loop exception
		for(IEditorReference editor : editorRef){	
			IEditorPart editorPart = editor.getEditor(false);
			if(editorPart instanceof CategoryEditor){	
				CategoryEditor categoryEditor = (CategoryEditor)editorPart;
				//categoryEditor.natTable.addConfiguration(categoryEditor);
				categoryEditor.natTable.configure();
			}
		}
		for (Map.Entry<CategoryEditor,Integer> entry : rowCntMap.entrySet()) {
			entry.getKey().natTable.doCommand(new ShowRowInViewportCommand(entry.getKey().createNatTable.getGridLayer().getBodyLayer(), entry.getValue()-1));
			entry.getKey().natTable.configure();
		}
		
		if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
			ActivityLogView.activityLog.append("\n [INFO]: Data objects added and/or deleted from category table. Perform SaveAll to resolve inconsistencies");
		}
	}
	
	/**
	 * Method used to get inconsistent attributes data from MATLAB script
	 */
	@Override
	public JsonElement getInconsistentAttributeData(String excelPath) throws MatlabCommunicatinException {
		Project project = ProjectExplorerView.getActiveProject();
		//OpenComponentServiceImpl serviceImpl = new OpenComponentServiceImpl();
		String componentName = openCompServ.getOpenedComponentPath();
		String excelSheetPath = "";
		JsonElement jsonElement = null;

		if (project != null) {
			String matlabQuery = CreateMatlabRequest.createMatlabRequest(
					MatlabScriptConstant.INCONSIIOATTR, componentName.replace("\\", "/")+","+excelPath, excelSheetPath);
			try {
				jsonElement = matlabDataRequest.executeMatlabRequest(matlabQuery);
			} catch (MatlabCommunicatinException e) {
				throw new MatlabCommunicatinException(e.getMessage(), e);
			}
		}
	
		Application.inconAttrJson = jsonElement;
		return jsonElement;
	}

	/**
	 * Method used to open table displaying inconsistent attributes from sldd and
	 * CAN excel sheet
	 * @param inconAttrList
	 */
	@Override
	public void openInconsistentAttributeEditor(List<CategoryAttributesIo> inconAttrList)
			throws EditorInitilizationException {
		Collections.sort(inconAttrList, new CustomComparator());
		IOCompatibilityEditorInput iOEditorInput = new IOCompatibilityEditorInput("", "", "",
				inconAttrList);
		// get the Active page
		IWorkbenchPage activePage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
		try {
			activePage.openEditor(iOEditorInput, ResolveInconAttributesEditor.INCON_ATTR_ID);
			activePage.activate(activePage.findView(ViewIDConstant.CHECK_IO_COMPAT));
		} catch (PartInitException e) {
			LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
			throw new EditorInitilizationException("Error while opening resolve inconsistent attributes window", e);
		}
	}
	
	/**
	 * Class created to sort the data objects using its NAME attribute to display alternatively
	 * in table for ease of performing Use This Object functionality
	 * @author nikitak1
	 *
	 */
	class CustomComparator implements Comparator<CategoryAttributes> {
	    @Override
	    public int compare(CategoryAttributes object1, CategoryAttributes object2) {
	        return object1.getName().compareTo(object2.getName());
	    }
	}

	@Override
	public JsonElement getDataObjectsForExcel(String excelPath) throws MatlabCommunicatinException {
		JsonElement jsonElement = null;
		String componentPath = openCompServ.getOpenedComponentPath();
		componentPath = componentPath.replace("\\", "/");
		MatlabCommunicationDaoImpl matlabCommImpl = new MatlabCommunicationDaoImpl();
		Project project = ProjectExplorerView.getActiveProject();

		if (project.getComponentPath() != null) {

			String matlabQuery = CreateMatlabRequest.createMatlabRequest(MatlabScriptConstant.QUERYEXCELOBJGET,
					componentPath+","+excelPath, "");
			try
			{
				jsonElement = matlabCommImpl.executeMatlabRequest(matlabQuery);
				
			}
			catch(Exception e)
			{
				throw new MatlabCommunicatinException(e.getMessage(), e);
			}
		}

		return jsonElement;
	}
	
	/**
	 * Method used to call MATLAB script for adding and deleting data objects in CAN excel sheet
	 * @param addToExcelList
	 * @param delFromExcelList
	 */
	@Override
	public JsonElement resolveInconsistencyInToExcel(List<CategoryAttributes> addToExcelList,
			List<CategoryAttributes> delFromExcelList) throws MatlabCommunicatinException {
		addToExcelList.addAll(delFromExcelList);
		String bothLists = new Gson().toJson(addToExcelList);
		
		String jsonStrForReq = CreateMatlabRequest.createMatlabRequest(MatlabScriptConstant.QRYEXLRSLVINCON,
				openCompServ.getOpenedComponentPath(), bothLists);	
		JsonElement jsonElement = new MatlabCommunicationDaoImpl().executeMatlabRequest(jsonStrForReq);
		checkMatlabRespCode(jsonElement);
		
		return jsonElement;
	}
}
