package com.navistar.datadictionary.serviceimpl;

import org.apache.log4j.Logger;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.ui.PlatformUI;

import com.navistar.datadictionary.action.EditorPreference;
import com.navistar.datadictionary.action.SaveAllAction;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.IconsPathConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.daoimpl.MatlabEngineConnectionDaoImpl;
import com.navistar.datadictionary.model.FontStyleDAO;
import com.navistar.datadictionary.service.CheckComponentInputsService;
import com.navistar.datadictionary.service.CloseProjectService;
import com.navistar.datadictionary.ui.config.Application;
import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.ui.config.DataDictionaryApplication;
import com.navistar.datadictionary.ui.views.ActivityLogView;
import com.navistar.datadictionary.ui.views.ProjectExplorerView;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Class implements methods of CloseProjectService interface to implement close project operation.
 * @author JAYSHRIVISHB
 *
 */
public class CloseProjectServiceImpl implements CloseProjectService {

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(CloseProjectServiceImpl.class);

	/** Used to access check editors */
	private EditorServiceImpl editorService;

	/** Instance of ImportProjectStructureService */
	private ImportProjectServiceImpl importService;

	public CloseProjectServiceImpl() {
		importService = new ImportProjectServiceImpl();
		editorService = new EditorServiceImpl();
	}

	/**
	 * Method used to close project from context menu and file menu
	 * 
	 */
	@Override
	public void performCloseProjectAction() {
		try {
			ApplicationActionBarAdvisor.getInstance().closeProjAction.setEnabled(false);
			ApplicationActionBarAdvisor.getInstance().ioCompatAction.setEnabled(false);	
			ApplicationActionBarAdvisor.getInstance().searchAction.setEnabled(false);
			ApplicationActionBarAdvisor.getInstance().validProjAction.setEnabled(false);
			ApplicationActionBarAdvisor.getInstance().updateProjParaTypeAction.setEnabled(false);

			Application.ioJsonElement = null;
			ApplicationActionBarAdvisor.getInstance().ioCompatWinAction.setChecked(false);
			ApplicationActionBarAdvisor.getInstance().searchWindowObj.setChecked(false);
			
			PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell().setText("Data Dictionary");
			
			CheckComponentInputsService checkCompInputs =  new CheckComponentInputsServiceimpl();
			LOGGER.info("Closing Check Component Window if Open");
			checkCompInputs.closeCheckCompInputsWindow();	//Closing check component window
			// Check if any editor is having unsaved data
			if (editorService.checkForUnsavedEditors() ) {
				int result = closeProjectHandler(false,2);
				// if user choose to save all
				if (result == 0) {
					LOGGER.info("Save All Operation Completed");
					LOGGER.info("Closing all editors");
					// Close all editors of component
					editorService.closeAllEditors();
					LOGGER.info("Closing Project");
					// close project from explorer
					closeProjectFromExplorer();
					LOGGER.info("Project Closed");
				}else if(result == 1){	//If users choses to discard changes
					if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
						ActivityLogView.activityLog.append("\n [INFO]: Changes discarded successfully");
					}
					LOGGER.info("Discard Operation Complete");
					//remove unsaved changes and load categories with saved data
					editorService.removeDirtyIndicator();
					LOGGER.info("Closing all editors");
					// Close all editors of component
					editorService.closeAllEditors();
					LOGGER.info("Closing Project");
					// close project from explorer
					closeProjectFromExplorer();
					LOGGER.info("Project Closed");
				}
			} else {
				LOGGER.info("Closing all editors");
				// Close all editors of component
				editorService.closeAllEditors();
				LOGGER.info("Closing Project");
				// close project from explorer
				closeProjectFromExplorer();
				LOGGER.info("Project Closed");
			}
		}
		catch(Exception exception) {
			throw exception;
		}
	}

	/**
	 * Method is used to close project from explorer
	 * @param viewer
	 */
	public void closeProjectFromExplorer() {
		try {
			// Close project in project explorer
			Tree tree = ProjectExplorerView.viewer.getTree();
			int treeItemCount = tree.getItems().length;
			LOGGER.info("Removing Project Path from Matlab");
			//Remove project to be closed from MATLAb path
			removeClosedProjectFromPath();
			LOGGER.info("Project Path Removed from Matlab");
			LOGGER.info("Disabling Project");
			// Close/disable all the project
			disableProject();
			LOGGER.info("Updating Project Status Map");
			for (int index = 0; index < treeItemCount; index++) {
				importService.updateProjectStatus(tree.getItem(index).getText(),
						ApplicationConstant.CLOSE_PROJ_STATUS, "");
			}

			// close the window and reset the data.
			ViewUtil.closeView(ViewIDConstant.TABLE_EDITOR);
			ViewUtil.closeView(ViewIDConstant.MIN_MAX_INFO);
			ViewUtil.closeView(ViewIDConstant.SEARCH_RESULT);

			ViewUtil.closeView(ViewIDConstant.CHECK_IO_COMPAT);
			ViewUtil.closeView(ViewIDConstant.OUTPUT_DATA_OBJ);
			Application.ioJsonElement = null;

			DataDictionaryApplication.getApplication().setSearchedDataList(null);
			DataDictionaryApplication.getApplication().setOutputSignalJson(null);
		}
		catch(Exception exception) {
			throw exception;
		}
	}

	/**
	 * This method is used to disable the open project
	 * 
	 * @param viewer
	 */
	public void disableProject() {
		try {
			Device device;
			Tree tree = ProjectExplorerView.viewer.getTree();
			device = PlatformUI.getWorkbench().getDisplay();
			Image closedProjImage = new Image(PlatformUI.getWorkbench().getDisplay(), CloseProjectService.class.getResourceAsStream(IconsPathConstant.CLOSE_PROJ_ICON));
			FontStyleDAO fontStyle = DataDictionaryApplication.getApplication().fontStyle;
			Font fontStyleNormal;
			if(fontStyle != null && fontStyle.getFont() != null && !EditorPreference.isDefFontSel) {
				fontStyleNormal = new Font(device, fontStyle.getFont(), fontStyle.getSize(), SWT.NORMAL);
			} else {
				fontStyleNormal = new org.eclipse.swt.graphics.Font(device, ApplicationConstant.HIGHLIGHTFONTSTYL, ApplicationConstant.HIGHFONTSIZE, SWT.NORMAL);
			}
			for (int index = 0; index < tree.getItems().length; index++) {	//closing the project
				tree.getItem(index).setItemCount(ApplicationConstant.CLOSEPROJITEMCNT);
				tree.getItem(index).setForeground(new Color(device, ApplicationConstant.CLOSE_PROJ_COLOR, ApplicationConstant.CLOSE_PROJ_COLOR, ApplicationConstant.CLOSE_PROJ_COLOR));
				tree.getItem(index).setFont(fontStyleNormal);
				tree.getItem(index).setImage(closedProjImage);
			}
		}
		catch(Exception exception) {
			throw exception;
		}
	}


	/**
	 * Method used for handling close project actions
	 */
	public int closeProjectHandler(boolean saveDialogRetVal, int saveDialogSelVal) {
		try {
			int result = 0;

			if (!saveDialogRetVal) {
				// Shell to display messageBox
				Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();

				// Custom message dialog to allow user to save editors
				MessageDialog dialog = new MessageDialog(shell, ApplicationConstant.SAVERESWARNING, null,
						MessageConstant.SAVE_ALL_MESSAGE, MessageDialog.CONFIRM,
						new String[] { ApplicationConstant.BTN_SAVE_ALL, ApplicationConstant.BTN_DISCARD, ApplicationConstant.BTN_CANCEL }, 0);
				result = dialog.open();

				// If user choose save all
				if (result == 0) {
					LOGGER.info("Saving all the changes");
					SaveAllAction saveAllAction = new SaveAllAction();
					saveAllAction.run();
				} else if (result == 1) {
					if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
						ActivityLogView.activityLog.append("\n [INFO]: Changes discarded successfully");
					}
					LOGGER.info("Performing Discard Operation");
					editorService.removeDirtyIndicator();

				} else if (result == 2) {
					LOGGER.info("Save All operation canceled");
				}
			}else if(saveDialogRetVal && saveDialogSelVal == 0){
				LOGGER.info("Saving all the changes");
				SaveAllAction saveAllAction = new SaveAllAction();
				saveAllAction.run();
				result = 0;
			}else if(saveDialogRetVal && saveDialogSelVal == 1){
				if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
					ActivityLogView.activityLog.append("\n [INFO]: Changes discarded successfully");
				}
				LOGGER.info("Performing Discard Operation");
				editorService.removeDirtyIndicator();	
			}
			else
			{
				result = 2;
			}
			return result;
		}
		catch(Exception exception) {
			throw exception;
		}
	}

	/**
	 * Method used to remove the project path from MATLAB
	 */
	public void removeClosedProjectFromPath() {
		try {
			String projectToBeClosed = "";
			for(String projectPath : DataDictionaryApplication.getApplication().projStatusMap.keySet()) {
				if(DataDictionaryApplication.getApplication().projStatusMap.get(projectPath).getStatus()==1) {
					projectToBeClosed = projectPath;
				}
			}
			MatlabEngineConnectionDaoImpl matlabConnection = new MatlabEngineConnectionDaoImpl();
			matlabConnection.removeProjectPath(projectToBeClosed);
		}
		catch(Exception exception) {
			throw exception;
		}
	}
}
