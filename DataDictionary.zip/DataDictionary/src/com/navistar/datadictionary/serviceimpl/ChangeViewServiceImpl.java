package com.navistar.datadictionary.serviceimpl;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.JsonElement;
import com.navistar.datadictionary.constant.MatlabScriptConstant;
import com.navistar.datadictionary.customexception.MatlabCommunicatinException;
import com.navistar.datadictionary.daoimpl.MatlabCommunicationDaoImpl;
import com.navistar.datadictionary.model.CategoryAttributes;
import com.navistar.datadictionary.model.Project;
import com.navistar.datadictionary.service.ChangeViewService;
import com.navistar.datadictionary.ui.config.Application;
import com.navistar.datadictionary.ui.views.ProjectExplorerView;
import com.navistar.datadictionary.util.CreateMatlabRequest;
import com.navistar.datadictionary.util.JSONUtil;

/**
 * Class implements methods of ChangeViewService interface to implement change to hierarchical view operation.
 * @author nikitak1
 *
 */
public class ChangeViewServiceImpl implements ChangeViewService{

	/**
	 * Method used to create matlab request for hierarchical view display
	 * @return JsonElement
	 * @throws MatlabCommunicatinException
	 */
	@Override
	public JsonElement createRequestForHierarchical() throws MatlabCommunicatinException  {
		JsonElement jsonElement = null;
		Project project = ProjectExplorerView.getActiveProject();
		if (project != null) {
			String matlabQuery = CreateMatlabRequest.createMatlabRequest(MatlabScriptConstant.QUERYHIERACHIVIEW,
					project.getPath().replace("\\", "/"), MatlabScriptConstant.EMPTY_STRING);

			try
			{
				jsonElement = new MatlabCommunicationDaoImpl().executeMatlabRequest(matlabQuery);	
			}
			catch(MatlabCommunicatinException e)
			{
				throw new MatlabCommunicatinException(e.getMessage(), e);
			}

			if(!JSONUtil.checkIfNoHierarchicalView(jsonElement)){
				Application.hierarchiJsnEle = jsonElement;

			}else{
				return null;
			}



		}
		return jsonElement;
	}
	
	/**
	 * Method used to convert json response list to map for displaying in view
	 * @return Map
	 * @param hierarchicalViewList
	 */
	@Override
	public Map<String, List<String>> convertListToMap(List<CategoryAttributes> hierarchicalList) throws Exception{
	{
			Map<String,List<String>> folderCompMap = new LinkedHashMap<String,List<String>>();
			for (CategoryAttributes catAttributes:hierarchicalList) {
				List<String> componentList = folderCompMap.get(catAttributes.getName());
				if(componentList!=null)
				{				
					componentList.add(catAttributes.getComponent());				
				}
				else
				{
					componentList = new ArrayList<String>();
					componentList.add(catAttributes.getComponent());

				}
				folderCompMap.put(catAttributes.getName(), componentList);
			}
			for(Map.Entry<String, List<String>> entry : folderCompMap.entrySet()){
				if(entry.getKey().equals("OtherSldd")) {
					for(String compValue : entry.getValue()) {
						if(compValue.equals("NoSldd")) {
							folderCompMap.remove(entry.getKey());
						}
					}
				}
			}
			return folderCompMap;

		}
	}
}
