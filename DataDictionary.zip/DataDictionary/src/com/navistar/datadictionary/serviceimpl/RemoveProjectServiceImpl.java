package com.navistar.datadictionary.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.ui.PlatformUI;

import com.navistar.datadictionary.action.ImportProjectAction;
import com.navistar.datadictionary.constant.ApplicationConstant;
import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.model.Node;
import com.navistar.datadictionary.service.RemoveProjectService;
import com.navistar.datadictionary.ui.views.ActivityLogView;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Class used to remove project from project explorer view
 * @author JAYSHRIVISHB
 *
 */
public class RemoveProjectServiceImpl implements RemoveProjectService {
	
	/** Used to access import project service*/
	public ImportProjectServiceImpl importProj = new ImportProjectServiceImpl();
	
	/** Used to access import project action*/
	public ImportProjectAction importProjAction = new ImportProjectAction();

	/**
	 * Method used to get selected projects list - to be removed
	 * @param viewer
	 * @return
	 */
	@Override
	public List<String> getProjectListForRemove(TreeViewer viewer) {
		Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
		TreeItem[] viewerItem = viewer.getTree().getSelection();
		
		List<String> removedProjList = new ArrayList<>();
		for(TreeItem item : viewerItem)
		{
			int childCount = item.getItemCount();
			if(childCount > 0){
				MessageDialog.openWarning(shell,ApplicationConstant.WARNING, MessageConstant.REMOVE_PROJECT);
				removedProjList = null;
				break;
			}else{
				removedProjList.add(item.getText());
			}					
		}
		
		return removedProjList;
	}

	/**
	 * Method used to update project list and status of removed project in workspace file
	 * @param viewer
	 * @param removedProjectList
	 */
	@Override
	public void removeProjectFromWorkspace(TreeViewer viewer, List<String> removeProjectList) {

		// Get the input node list of tree viewer
		// Type conversion from object to List<String>
		@SuppressWarnings("unchecked")
		List<Node> nodes = (List<Node>) viewer.getInput();
		TreeItem[] viewerItem = viewer.getTree().getSelection();
		Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
		if (removeProjectList != null) {
			for (TreeItem item : viewerItem) {

				if (removeProjectList.indexOf(item.getText()) > -1) {
					int index = viewer.getTree().indexOf(item);
					if(index >=0)
					{
						MessageDialog dialog = new MessageDialog(shell, ApplicationConstant.WARNING, null,
								MessageConstant.RM_PROJ_CONFIRM, MessageDialog.CONFIRM,
								new String[] { ApplicationConstant.BTN_YES, ApplicationConstant.BTN_NO }, 0);
						int result = dialog.open();
						if (result == 0) {
							for (TreeItem item1 : viewerItem) {

								if (removeProjectList.indexOf(item1.getText()) > -1) {
									int index1 = viewer.getTree().indexOf(item1);
									String projectName = item1.getText();
									if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
										ActivityLogView.activityLog.append("\n [INFO]: Removed Project : " + item1.getText() );
									}
									item1.dispose();
									
									nodes.remove(index1);
									
									ImportProjectAction.nodes=nodes;
									importProj.updateProjectStatus(projectName, ApplicationConstant.REMOVEPROJSTATUS,
											ApplicationConstant.EMPTY_STRING);
									
								}
							}
							viewer.setInput(nodes);
							// call maintain project status after removing projects
							importProjAction.resetProjectStatus();
						}
					}
					else
					{
						MessageDialog.openWarning(shell,ApplicationConstant.WARNING, MessageConstant.REMOVE_COMPONENT);
					}
				}
			}
			

		}
		
	}

}
