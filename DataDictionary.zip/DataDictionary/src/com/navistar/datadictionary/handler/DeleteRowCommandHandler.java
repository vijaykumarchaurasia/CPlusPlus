package com.navistar.datadictionary.handler;

import java.util.List;

import org.eclipse.nebula.widgets.nattable.command.ILayerCommandHandler;
import org.eclipse.nebula.widgets.nattable.layer.ILayer;
import org.eclipse.nebula.widgets.nattable.layer.event.RowDeleteEvent;

import com.navistar.datadictionary.ui.nattable.DeleteRowCommand;

/**
 * Class is used for deleting row from natTable
 * @author minalc
 */
public class DeleteRowCommandHandler<T> implements ILayerCommandHandler<DeleteRowCommand> {

	/** NatTable data */
    private List<T> bodyData;

    /**
     * Constructor
     * @param bodyData
     */
    public DeleteRowCommandHandler(List<T> bodyData) {
        this.bodyData = bodyData;
    }

    /**
     * This method is used to get command class.
     */
    @Override
    public Class<DeleteRowCommand> getCommandClass() {
        return DeleteRowCommand.class;
    }

    /**
     * This method is used to perform operation on delete row command.
     */
    @Override
    public boolean doCommand(ILayer targetLayer, DeleteRowCommand command) {
        boolean deleteStatus = false;
        
    	//convert the transported position to the target layer
        if (command.convertToTargetLayer(targetLayer)) {
            //remove the element
            this.bodyData.remove(command.getRowPosition());
            //fire the event to refresh
            targetLayer.fireLayerEvent(new RowDeleteEvent(targetLayer, command.getRowPosition()));
            deleteStatus = true;
        }
        return deleteStatus;
    }

}
