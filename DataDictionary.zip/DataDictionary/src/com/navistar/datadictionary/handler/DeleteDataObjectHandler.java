package com.navistar.datadictionary.handler;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;

import com.navistar.datadictionary.action.DeleteDataObjectAction;

/**
 * Class is used to delete data object(s).
 * @author minalc
 *
 */
public class DeleteDataObjectHandler extends AbstractHandler implements IHandler{

	/**
	 * Execute method get called when "DEL" is pressed for deleting data object(s)
	 */
	@Override
	public Object execute(ExecutionEvent arg0) throws ExecutionException {
		DeleteDataObjectAction delDataObjAction = new DeleteDataObjectAction();
		delDataObjAction.run();
		return null;
	}

}
