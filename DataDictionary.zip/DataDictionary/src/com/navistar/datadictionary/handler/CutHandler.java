package com.navistar.datadictionary.handler;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;

import com.navistar.datadictionary.action.CutAction;

/**
 * Class is used to handle cut event
 * @author raeesm
 *
 */
public class CutHandler extends AbstractHandler implements IHandler {

	/**
	 * Execute method get called when "Ctrl+X" is pressed for cut
	 */
	@Override
	public Object execute(ExecutionEvent arg0) throws ExecutionException {
		// TODO Auto-generated method stub
		CutAction cutAction = new CutAction();
		cutAction.run();
		return null;
	}

}
