package com.navistar.datadictionary.handler;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;

import com.navistar.datadictionary.action.CopyAction;
/**
 * Copy handler used to copy the data on clip board via keyboard shortcut
 * @author raeesm
 *
 */
public class CopyHandler extends AbstractHandler implements IHandler {

	/** 
	 * Execute method get called when "Ctrl+C" is pressed for copy	 
	 */
	@Override
	public Object execute(ExecutionEvent arg0) throws ExecutionException {
		// TODO Auto-generated method stub
		CopyAction copyAction = new CopyAction();
		copyAction.run();
		return null;
	}

}
