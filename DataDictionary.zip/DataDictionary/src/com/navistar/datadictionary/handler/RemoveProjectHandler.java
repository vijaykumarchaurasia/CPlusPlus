package com.navistar.datadictionary.handler;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;

import com.navistar.datadictionary.action.RemoveProjectAction;

/**
 * Class is used to handle the remove project(s)
 * @author minalc
 *
 */
public class RemoveProjectHandler extends AbstractHandler implements IHandler{

	/**
	 * Method get called internally on remove project called by Shift+DEL
	 */
	@Override
	public Object execute(ExecutionEvent arg0) throws ExecutionException {
		
		RemoveProjectAction removeProjAction = new RemoveProjectAction();
		removeProjAction.run();
		return null;
	}

}
