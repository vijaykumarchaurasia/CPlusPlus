package com.navistar.datadictionary.handler;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;
import org.eclipse.core.commands.operations.IUndoContext;
import org.eclipse.core.commands.operations.IUndoableOperation;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.PlatformUI;

import com.navistar.datadictionary.constant.MessageConstant;
import com.navistar.datadictionary.constant.ViewIDConstant;
import com.navistar.datadictionary.operation.UndoRedoOperation;
import com.navistar.datadictionary.ui.config.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.ui.editors.CategoryEditor;
import com.navistar.datadictionary.ui.views.ActivityLogView;
import com.navistar.datadictionary.util.ViewUtil;

/**
 * Class is used to handle a undo operation
 * @author minalc
 *
 */
public class UndoHandler extends AbstractHandler implements IHandler{

	/** Logger */
	private static final Logger LOGGER = Logger.getLogger(CategoryEditor.class);
	
	/**
	 * Execute method get called when "CTRl+Z" is pressed for undo
	 */
	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		
		if(ApplicationActionBarAdvisor.getInstance().undoAction.isEnabled()){
			IUndoableOperation operation =  new UndoRedoOperation(); 
			
			IWorkbench workbench = PlatformUI.getWorkbench();
		    IUndoContext undoContext = workbench.getOperationSupport().getUndoContext();
				    
		    //Add the current context for operation to be undo
		    operation.addContext(undoContext);
		    
		    try {    
		    	operation.undo(null, null);
		    	if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
		    		ActivityLogView.activityLog.append("\n [INFO]: Operation Un-done");
		    	}
		    	if(ViewUtil.isViewOpen(ViewIDConstant.OUTPUT_DATA_OBJ)) {
		    		ViewUtil.closeView(ViewIDConstant.OUTPUT_DATA_OBJ);
		    	}
			} catch (Exception e) {
				if(ViewUtil.isViewOpen(ViewIDConstant.ACTIVITY_LOG)) {
		    		ActivityLogView.activityLog.append("\n [ERROR]: "+e.getMessage());
		    	}
				LOGGER.log(Level.ERROR, MessageConstant.EXCEPTION_IN_LOG, e);
				MessageDialog.openConfirm(new Shell(), "Error Message","Error while performing Undo Operation");
			}
		}	
	   return null;
	}

}
