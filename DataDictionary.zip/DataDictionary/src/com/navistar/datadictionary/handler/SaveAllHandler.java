package com.navistar.datadictionary.handler;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;

import com.navistar.datadictionary.action.SaveAllAction;

/**
 * Class is used to handle the save all for all editors
 * @author minalc
 *
 */
public class SaveAllHandler extends AbstractHandler implements IHandler{

	/**
	 * Method get called internally on save-all action when user press 
	 * Ctrl+Shift+S
	 */
	@Override
	public Object execute(ExecutionEvent arg0) throws ExecutionException {
		
		SaveAllAction saveAllAction = new SaveAllAction();
		saveAllAction.run();
		return null;
	}

}
