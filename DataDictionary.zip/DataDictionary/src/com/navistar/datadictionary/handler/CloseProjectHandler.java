package com.navistar.datadictionary.handler;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;

/**
 * This class is used to handle the close project action.
 * @author minalc
 *
 */
public class CloseProjectHandler extends AbstractHandler{

	/**
	 * This method is used to handle close project action.
	 */
	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		return null;
	}

}
