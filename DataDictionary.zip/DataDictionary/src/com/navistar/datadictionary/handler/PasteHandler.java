package com.navistar.datadictionary.handler;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;

import com.navistar.datadictionary.action.PasteAction;

/**
 * Paste Handler used to paste the data on nattable via keyboard shortcut
 * @author raeesm
 *
 */

public class PasteHandler extends AbstractHandler implements IHandler{

	/** 
	 * Execute method get called when "Ctrl+V" is pressed for paste
	 */
	@Override
	public Object execute(ExecutionEvent arg0) throws ExecutionException {
		PasteAction pasteAction = new  PasteAction();
		pasteAction.run();
		return null;
	}

}
