package com.navistar.datadictionary.handler;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;

import com.navistar.datadictionary.action.SaveAction;

/**
 * Class is used to handle the save for editor
 * @author minalc
 *
 */
public class SaveHandler extends AbstractHandler implements IHandler{

	/**
	 * Method get called internally on save action when user 
	 * press Ctrl+S
	 */
	@Override
	public Object execute(ExecutionEvent arg0) throws ExecutionException {
		
		SaveAction saveAction = new SaveAction();
		saveAction.run();
		return null;
	}

}
