package com.navistar.datadictionary.handler;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import com.navistar.datadictionary.action.ImportProjectAction;
import com.navistar.datadictionary.ui.views.ProjectExplorerView;
/**
 * This class is used to handle the event on the project import.
 * @author nikitak1
 *
 */
public class ImportProjectHandler extends AbstractHandler implements IHandler{
	/** This is used to maintain single reference of project explorer view */
	static ProjectExplorerView projExplorerView;
	
	/**
	 * Execute method get called when "CTRl+I" is pressed for importing project.
	 * @param arg0
	 */
	@Override
	public Object execute(ExecutionEvent arg0) throws ExecutionException {
	
		IWorkbenchAction importProjAction = new ImportProjectAction();
		importProjAction.run();
		
		return null;
	}
}
