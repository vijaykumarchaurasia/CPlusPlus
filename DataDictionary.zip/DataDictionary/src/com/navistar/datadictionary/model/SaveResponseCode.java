package com.navistar.datadictionary.model;

import com.google.gson.annotations.SerializedName;

/**
 * Class used for save response code given by matlab script
 * @author JAYSHRIVISHB
 *
 */
public class SaveResponseCode {

	/** Error code*/
	@SerializedName("errorCode")
	private String errorCode;
	
	/** Category*/
	@SerializedName("category")
	private String category;
	
	/** Name*/
	@SerializedName("Name")
	private String name;
	
	/** Attribute*/
	@SerializedName("attribute")
	private String attribute;

	/**
	 * Method is used to get error code
	 * @return
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * Method is used to set error code
	 * @param errorCode
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * Method is used to get category
	 * @return
	 */
	public String getCategory() {
		return category;
	}

	/**
	 * Method is used to set category
	 * @param category
	 */
	public void setCategory(String category) {
		this.category = category;
	}

	/**
	 * Method is used to get name
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * Method is used to set name
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Method is used to get attribute
	 * @return
	 */
	public String getAttribute() {
		return attribute;
	}

	/**
	 * Method is used to set attribute
	 * @param attribute
	 */
	public void setAttribute(String attribute) {
		this.attribute = attribute;
	}

}
