package com.navistar.datadictionary.model;

/**
 * Class used to get the particular row data for undo operation
 * @author minalc
 *
 */
public class NatTableRowData {

	/** CategoryAttribute instance of particular row */
	private CategoryAttributes catAttributes;
	
	/** row index */
	private int rowIndex;

	/**
	 * Parameterized constructor for setting nattable row data.
	 * @param categoryAttributes
	 * @param rowIndex
	 */
	public NatTableRowData(CategoryAttributes catAttributes, int rowIndex) {
		super();
		this.catAttributes = catAttributes;
		this.rowIndex = rowIndex;
	}

	/**
	 * Method used to get category attributes
	 * @return
	 */
	public CategoryAttributes getCategoryAttributes() {
		return catAttributes;
	}

	/**
	 * Method used to set the category attributes
	 * @param categoryAttributes
	 */
	public void setCategoryAttributes(CategoryAttributes catAttributes) {
		this.catAttributes = catAttributes;
	}

	/**
	 * Method is used to get row index
	 * @return
	 */
	public int getRowIndex() {
		return rowIndex;
	}

	/**
	 * Method is used to set row index
	 * @param rowIndex
	 */
	public void setRowIndex(int rowIndex) {
		this.rowIndex = rowIndex;
	}

	@Override
	public String toString() {
		return "NatTableRowData [categoryAttributes=" + catAttributes + ", rowIndex=" + rowIndex + "]";
	}
}
