package com.navistar.datadictionary.model;

import org.eclipse.swt.graphics.RGB;

/**
 * Class is used to store font information.
 * @author JAYSHRIVISHB
 *
 */
public class FontStyleDAO {

	/** Font style*/
	private String font;
	/** Font size*/
	private int size;
	/** font Style*/
	private int fontStyle;
	/** font Color*/
	private RGB fontColor;
	
	public FontStyleDAO() {
		
	}
	/**
	 * 
	 * @param font
	 * @param size
	 * @param fontStyle
	 */
	public FontStyleDAO(String font, int size, int fontStyle, RGB fontColor) {
		super();
		this.font = font;
		this.size = size;
		this.fontStyle = fontStyle;
		this.fontColor = fontColor;
	}

	/**
	 * @return the font
	 */
	public String getFont() {
		return font;
	}

	/**
	 * @param font the font to set
	 */
	public void setFont(String font) {
		this.font = font;
	}

	/**
	 * @return the size
	 */
	public int getSize() {
		return size;
	}

	/**
	 * @param size the size to set
	 */
	public void setSize(int size) {
		this.size = size;
	}
	/**
	 * @return the fontStyle
	 */
	public int getFontStyle() {
		return fontStyle;
	}
	/**
	 * @param fontStyle the fontStyle to set
	 */
	public void setFontStyle(int fontStyle) {
		this.fontStyle = fontStyle;
	}
	/**
	 * @return the fontColor
	 */
	public RGB getFontColor() {
		return fontColor;
	}
	/**
	 * @param fontColor the fontColor to set
	 */
	public void setFontColor(RGB fontColor) {
		this.fontColor = fontColor;
	}
}
