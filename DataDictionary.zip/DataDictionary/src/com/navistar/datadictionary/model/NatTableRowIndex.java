package com.navistar.datadictionary.model;

import org.eclipse.nebula.widgets.nattable.selection.SelectionLayer;

/**
 * Class is used to store selection layer and newly added row index
 * @author minalc
 */
public class NatTableRowIndex {

	/** selection layer */
	private SelectionLayer selectionLayer;
	
	/** rowIndex for NatTable */
	private int rowIndex;
	
	/**
	 * This method is used to get selection layer.
	 * @return
	 */
	public SelectionLayer getSelectionLayer() {
		return selectionLayer;
	}

	/**
	 * This method is used to set selection layer
	 * @param selectionLayer
	 */
	public void setSelectionLayer(SelectionLayer selectionLayer) {
		this.selectionLayer = selectionLayer;
	}

	/**
	 * This method is used get row index of NatTable.
	 * @return
	 */
	public int getRowIndex() {
		return rowIndex;
	}

	/**
	 * This method is used to set row index of NatTable.
	 * @param rowIndex
	 */
	public void setRowIndex(int rowIndex) {
		this.rowIndex = rowIndex;
	}

	/**
	 * Parameterized constructor used to set selection layer and row Index of NatTable.
	 * @param selectionLayer
	 * @param rowIndex
	 */
	public NatTableRowIndex(SelectionLayer selectionLayer, int rowIndex) {
		super();
		this.selectionLayer = selectionLayer;
		this.rowIndex = rowIndex;
	}		
	
}
