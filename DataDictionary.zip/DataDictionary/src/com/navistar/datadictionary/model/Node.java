package com.navistar.datadictionary.model;

import java.util.ArrayList;
import java.util.List;
/**
 * This class is used to create a tree items in tree viewer which is in the
 * Project Explorer as of type Node
 * @author nikitak1
 *
 */
public class Node implements Comparable<Node>{
	/** This is used for the name of the tree item/node */
	private String name;
	
	@SuppressWarnings("rawtypes")
	/** This is used to get the child items of a particular tree item/node */
	private List subCategories;
	
	/** This is used to get the parent of the tree item */
	private Node parent;
	
	/**
	 * Parameterized constructor to get Node
	 * @param name
	 * @param parent
	 */
	public Node(String name, Node parent) {
		this.name = name;
		this.parent = parent;
		if (parent != null) {
			parent.addSubCategory(this);
		}
	}
	/**
	 * This method is used to get the Node
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public List getSubCategories() {
		return subCategories;
	}
	
	/**
	 * This method is used to add child items to Node
	 * @param subcategory
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void addSubCategory(Node subcategory) {
		if (subCategories == null) {
			subCategories = new ArrayList();
		}
		if (!subCategories.contains(subcategory)) {
			subCategories.add(subcategory);
		}
	}
	
	/**
	 * Method used to get name of node
	 * @return
	 */
	public String getName() {
		return name;
	}
	/**
	 * Method used to get parent of node
	 * @return
	 */
	public Node getParent() {
		return parent;
	}
	/**
	 * Default method to compare this object with the specified
	 * object for order
	 * @param compareNode
	 *
	 */
	@Override
	public int compareTo(Node compareNode) {
		return 0;
	}
}
