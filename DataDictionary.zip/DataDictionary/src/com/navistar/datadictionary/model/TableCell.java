package com.navistar.datadictionary.model;

/**
 * Class is used for table cell information such as rowIndex and columnIndex
 * @author shubhangim1
 *
 */
public class TableCell {

	/** Row Index*/
	private int rowIndex;
	/** Column Index*/
	private int columnIndex;
	/** Cell data*/
	private String cellData;

	/**
	 * Parameterized constructor
	 * @param rowIndex
	 * @param columnIndex
	 */
	public TableCell(int rowIndex, int columnIndex) {
		super();
		this.rowIndex = rowIndex;
		this.columnIndex = columnIndex;
	}
	
	/**
	 * Parameterized constructor
	 * @param rowIndex
	 * @param columnIndex
	 * @param cellData
	 */
	public TableCell(int rowIndex, int columnIndex, String cellData) {
		super();
		this.rowIndex = rowIndex;
		this.columnIndex = columnIndex;
		this.cellData = cellData;
	}

	/**
	 * Method is used get Row Index
	 * @return
	 */
	public int getRowIndex() {
		return rowIndex;
	}

	/**
	 * Method is used set Row Index
	 * @param rowIndex
	 */
	public void setRowIndex(int rowIndex) {
		this.rowIndex = rowIndex;
	}

	/**
	 * Method is used get Column Index
	 * @return
	 */
	public int getColumnIndex() {
		return columnIndex;
	}

	/**
	 * Method is used set Column Index
	 * @param columnIndex
	 */
	public void setColumnIndex(int columnIndex) {
		this.columnIndex = columnIndex;
	}	
	
	/**
	 * Method is used get Cell data
	 * @return
	 */
	public String getCellData() {
		return cellData;
	}

	/**
	 * Method is used set cell data
	 * @param cellData
	 */
	public void setCellData(String cellData) {
		this.cellData = cellData;
	}

	/**
	 * Method is used to get Table cell data.
	 */
	@Override
	public String toString() {
		return "TableCell [rowIndex=" + this.rowIndex + ", columnIndex=" + this.columnIndex + ", cellData=" + this.cellData + "]";
	}

}
