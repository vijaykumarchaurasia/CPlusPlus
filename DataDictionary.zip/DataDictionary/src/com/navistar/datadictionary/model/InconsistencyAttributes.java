package com.navistar.datadictionary.model;

import com.google.gson.annotations.SerializedName;
/**
 * Class used for data access object for inconsistency.
 * 
 * @author vijayk13
 *
 */
public class InconsistencyAttributes {

	@SerializedName("warning")
	private String warning;

	@SerializedName("category")
	private String category;

	@SerializedName("Name")
	private String name;

	/**
	 * Default Constructor
	 */
	public InconsistencyAttributes(){

	}
	/** 
	 * Parametric constructor
	 * @param warning
	 * @param category
	 * @param name
	 */
	public InconsistencyAttributes(String warning, String category, String name) {
		super();
		this.warning = warning;
		this.category = category;
		this.name = name;
	}

	/**
	 * To get the warning name which is inconsistency from DD or model
	 * @return
	 */
	public String getWarning() {
		return warning;
	}

	/**
	 *  To set the warning name which is inconsistency from DD or model
	 * @param warning
	 */
	public void setWarning(String warning) {
		this.warning = warning;
	}

	/**
	 * To get the category name of data object
	 * @return
	 */
	public String getCategory() {
		return category;
	}

	/**
	 * To set the category name of data object
	 * @param category
	 */
	public void setCategory(String category) {
		this.category = category;
	}

	/**
	 * To get the name of data object
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * To set the name of data object
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	
}
