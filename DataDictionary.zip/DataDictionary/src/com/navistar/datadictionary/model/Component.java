package com.navistar.datadictionary.model;

/**
 * Class is used for component information such as name
 * @author shubhangim1
 *
 */
public class Component {
	
	/** Component name of imported project*/
	private String componentName;
	
	/**
	 * parameterized constructor
	 * @param componentName
	 */
	public Component(String componentName) {
		super();
		this.componentName = componentName;
	}
	
	/**
	 * Method is used to get component name
	 * @return
	 */
	public String getComponentName() {
		return componentName;
	}
	
	/**
	 * Method is used to set component name
	 * @param componentName
	 */
	public void setComponentName(String componentName) {
		this.componentName = componentName;
	} 

}
