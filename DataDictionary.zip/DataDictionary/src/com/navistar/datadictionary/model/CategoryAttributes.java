package com.navistar.datadictionary.model;

import com.google.gson.annotations.SerializedName;

/**
 * Class used for data access object for category.
 * 
 * @author vijayk13
 *
 */
public class CategoryAttributes {

	/** warning */
	@SerializedName("warning")
	private String warning;

	/** category */
	@SerializedName("category")
	private String category;

	/** name of data object */
	@SerializedName("Name")
	private String name;

	/** Value Category */
	@SerializedName("Value")
	private String value;

	/** Description Category */
	@SerializedName("Description")
	private String description;

	/** component */
	@SerializedName("component")
	private String component;

	/** Basetype Category */
	@SerializedName("Basetype")
	private String baseType;

	/** OffSet Category */
	@SerializedName("Offset")
	private String offset;

	/** Slope Category */
	@SerializedName("slope")
	private String slope;	

	/** Min Category */
	@SerializedName("Min")
	private String min;

	/** Max Category */
	@SerializedName("Max")
	private String max;

	/** Unit Category */
	@SerializedName("Unit")
	private String unit;

	/** Complexity Category */
	@SerializedName("Complexity")
	private String complexity;

	/** Dimensions Category */
	@SerializedName("Dimensions")
	private String dimensions;

	/** DimensionsMode Category */
	@SerializedName("DimensionsMode")
	private String dimensionsMode;

	/** SampleTime Category */
	@SerializedName("SampleTime")
	private String sampleTime;

	/** SamplingMode Category *//*
	@SerializedName("SamplingMode")
	private String samplingMode;*/

	/** InitialValue Category */
	@SerializedName("InitialValue")
	private String initialValue;

	/** InitialValue Category */
	@SerializedName("SwCalibrationAccess")
	private String swCalAccess;

	/** InitialValue Category */
	@SerializedName("DisplayFormat")
	private String displayFormat;

	/** Coderinfo Category */
	@SerializedName("Coderinfo")
	private String coderInfo;

	/** Memorysection Category */
	@SerializedName("MemorySection")
	private String memorySection; 
	
	/** oldName of data object */
	@SerializedName("oldName")
	private String oldName;
	
	/** max dimension of component */
	@SerializedName("maxDimension")
	private String maxDimension;
	
	/** SubSignalName Category */
	@SerializedName("StructureElementName")
	private String structureElementname;

	/**
	 * Default Constructor
	 */
	public CategoryAttributes(){

	}

	/**
	 * Method used to get the category 
	 * @return
	 */
	public String getCategory() {
		return category;
	}

	/**
	 * Method used to get the Sw Calibration access
	 * @return
	 */
	public String getSwCalAccess() {
		return swCalAccess;
	}

	/**
	 * Method used to set the Sw Calibration access
	 * @param swCalAccess
	 */
	public void setSwCalAccess(String swCalAccess) {
		this.swCalAccess = swCalAccess;
	}

	/**
	 * Method used to set the category
	 * @param category
	 */
	public void setCategory(String category) {
		this.category = category;
	}

	/**
	 * Parameterized Constructor
	 * @param category
	 * @param name
	 * @param value
	 * @param description
	 * @param baseType
	 * @param min
	 * @param max
	 * @param unit
	 * @param complexity
	 * @param dimensions
	 * @param dimensionsMode
	 * @param sampleTime
	 * @param samplingMode
	 * @param initialValue
	 */
	public CategoryAttributes(String warning, String category, String name, String structureElementname, String value, String description, String component,
			String baseType, String offset, String slope, String min, String max, String unit, String complexity,
			String dimensions, String dimensionsMode, String sampleTime, String initialValue,
			String swCalAccess,  String coderInfo,String displayFormat, String memorySection) {
		super();
		this.warning = warning;
		this.category = category;
		this.name = name;
		this.value = value;
		this.description = description;
		this.component = component;
		this.baseType = baseType;
		this.offset = offset;
		this.slope = slope;
		this.min = min;
		this.max = max;
		this.unit = unit;
		this.complexity = complexity;
		this.dimensions = dimensions;
		this.dimensionsMode = dimensionsMode;
		this.sampleTime = sampleTime;
	//	this.samplingMode = samplingMode;
		this.initialValue = initialValue;
		this.swCalAccess = swCalAccess;
		this.displayFormat = displayFormat;
		this.coderInfo = coderInfo;
		this.memorySection = memorySection;
		this.structureElementname = structureElementname;
	}



	/**
	 * Method used to get the Name
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * Method used to set the Name
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Method used to get the value category
	 * @return
	 */
	public String getValue() {
		return value;
	}

	/**
	 * Method used to set the value category
	 * @param value
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * Method used to get the description category
	 * @return
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Method used to set the description category
	 * @param description
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
	/**
	 * Method used to get the SubSignalName category
	 * @return
	 */
	
	public String getStructureElementName() {
		return structureElementname;
	}

	/**
	 * Method used to set the StructureElementName category
	 * @param structureElementname
	 */
	public void setStructureElementName(String structureElementname) {
		this.structureElementname = structureElementname;
	}

	/**
	 * Method used to get the data type category
	 * @return
	 */
	public String getBaseType() {
		return baseType;
	}

	/**
	 * Method used to set the data type category
	 * 
	 * @param baseType
	 */
	public void setBaseType(String baseType) {
		this.baseType = baseType;
	}

	public String getOffset() {
		return offset;
	}

	public void setOffset(String offset) {
		this.offset = offset;
	}

	public String getSlope() {
		return slope;
	}

	public void setSlope(String slope) {
		this.slope = slope;
	}

	/**
	 * Method used to get the min category
	 * 
	 * @return
	 */
	public String getMin() {
		return min;
	}

	/**
	 * Method used to set the min category
	 * 
	 * @param min
	 */
	public void setMin(String min) {
		this.min = min;
	}

	/**
	 * Method used to get the max category
	 * 
	 * @return
	 */
	public String getMax() {
		return max;
	}

	/**
	 * Method used to set the max category
	 * 
	 * @param max
	 */
	public void setMax(String max) {
		this.max = max;
	}

	/**
	 * Method used to get the unit category
	 * 
	 * @return
	 */
	public String getUnit() {
		return unit;
	}

	/**
	 * Method used to set the unit category
	 * 
	 * @param unit
	 */
	public void setUnit(String unit) {
		this.unit = unit;
	}

	/**
	 * Method used to get the complexity category
	 * 
	 * @return
	 */
	public String getComplexity() {
		return complexity;
	}

	/**
	 * Method used to set the complexity category
	 * 
	 * @param complexity
	 */
	public void setComplexity(String complexity) {
		this.complexity = complexity;
	}

	/**
	 * Method used to get the dimensions category
	 * 
	 * @return
	 */
	public String getDimensions() {
		return dimensions;
	}

	/**
	 * Method used to set the dimensions category
	 * 
	 * @param dimensions
	 */
	public void setDimensions(String dimensions) {
		this.dimensions = dimensions;
	}

	/**
	 * Method used to get the dimensions mode category
	 * 
	 * @return
	 */
	public String getDimensionsMode() {
		return dimensionsMode;
	}

	/**
	 * Method used to set the dimensions mode category
	 * 
	 * @param dimensionsMode
	 */
	public void setDimensionsMode(String dimensionsMode) {
		this.dimensionsMode = dimensionsMode;
	}

	/**
	 * Method used to get the sample time category
	 * 
	 * @return
	 */
	public String getSampleTime() {
		return sampleTime;
	}

	/**
	 * Method used to set the sample time category
	 * 
	 * @param sampleTime
	 */
	public void setSampleTime(String sampleTime) {
		this.sampleTime = sampleTime;
	}

/*	*//**
	 * Method used to get the sample mode category
	 * 
	 * @return
	 *//*
	public String getSamplingMode() {
		return samplingMode;
	}

	*//**
	 * Method used to set the sampling mode category
	 * 
	 * @param samplingMode
	 *//*
	public void setSamplingMode(String samplingMode) {
		this.samplingMode = samplingMode;
	}
*/
	/**
	 * Method used to get the Intial value Category
	 * @return
	 */
	public String getInitialValue() {
		return initialValue;
	}

	/**
	 * Method used to set the initial value category
	 * @param initialValue
	 */
	public void setInitialValue(String initialValue) {
		this.initialValue = initialValue;
	}

	/**
	 * Method used to get the warning of category
	 * @return
	 */
	public String getWarning() {
		return warning;
	}

	/**
	 * Method used to set the warning of category
	 * @param warning
	 */
	public void setWarning(String warning) {
		this.warning = warning;
	}

	/**
	 * Method used to get the component name
	 * @return
	 */
	public String getComponent() {
		return component;
	}

	/**
	 * Method used to set the component name
	 * @param component
	 */
	public void setComponent(String component) {
		this.component = component;
	}
/*
	*//**
	 * Method used to get the Sw Calibration access
	 * @return
	 *//*
	public String getSwCalibrationAccess() {
		return swCalAccess;
	}

	*//**
	 * Method used to set the Sw Calibration access
	 * @param swCalibrationAccess
	 *//*
	public void setSwCalibrationAccess(String swCalAccess) {
		this.swCalAccess = swCalAccess;
	}*/

	/**
	 * Method used to get the display format
	 * @return
	 */
	public String getDisplayFormat() {
		return displayFormat;
	}

	/**
	 * Method used to set the display format
	 * @param displayFormat
	 */
	public void setDisplayFormat(String displayFormat) {
		this.displayFormat = displayFormat;
	}

	/**
	 * Method used to get the coder info
	 * @return
	 */
	public String getCoderInfo() {
		return coderInfo;
	}

	/**
	 * Method used to set the coder info
	 * @param coderInfo
	 */
	public void setCoderInfo(String coderInfo) {
		this.coderInfo = coderInfo;
	}

	/**
	 * Method used to set the memory section
	 * @param memorySection
	 */
	public void setMemorySection(String memorySection) {
		this.memorySection = memorySection;
	}
	
	/**
	 * Method used to get the memory section
	 * @return
	 */
	public String getMemorySection() {
		return memorySection;
	}
	
	/**
	 * Method used to get the old name of data object
	 * @return String
	 */
	public String getOldName() {
		return oldName;
	}

	/**
	 * Method used to set the old name of data object
	 * @param oldName
	 */
	public void setOldName(String oldName) {
		this.oldName = oldName;
	}

	/**
	 * Method used to get the maximum dimension
	 */
	public String getMaxDimension() {
		return maxDimension;
	}

	/**
	 * Method used to set the maximum dimension
	 * @param maxDimension
	 */
	public void setMaxDimension(String maxDimension) {
		this.maxDimension = maxDimension;
	}

	/**
	 * Method used to get category attributes.
	 */
	@Override
	public String toString() {
		return "CategoryAttributes [warning=" + warning + ", category=" + category + ", name=" + name + ",subSignalname=" + structureElementname + ", value="
				+ value + ", description=" + description + ", component=" + component + ", baseType=" + baseType
				+ ", offset=" + offset + ", slope=" + slope + ", min=" + min + ", max=" + max + ", unit=" + unit
				+ ", complexity=" + complexity + ", dimensions=" + dimensions + ", dimensionsMode=" + dimensionsMode
				+ ", sampleTime=" + sampleTime +  ", initialValue=" + initialValue
				+ ", swCalibrationAccess=" + swCalAccess + ", displayFormat=" + displayFormat + ", coderInfo="
				+ coderInfo +", memorySection=" + memorySection + ", oldName=" + oldName + ", maxDimension=" + maxDimension + "]";
	}

	/**
	 * This method is used to compare Objects of CategoryAttributes for equality
	 */
	@Override
	public boolean equals(Object obj) {

		boolean isEqual = false;
		CategoryAttributes catAttributes = (CategoryAttributes) obj;
		
		// If the object is compared with itself then return true   
		if (obj == this) { 
			isEqual = true;
			return isEqual;
		} 

		// Check if obj is an instance of CategoryAttributes or not "null instanceof [type]" also returns false 
		if (!(obj instanceof CategoryAttributes)) { 
			isEqual = false;
			return isEqual;
		}

		if(this.warning.equals(catAttributes.getWarning()) && 
				this.name.equals(catAttributes.getName()) && 
				this.category.equals(catAttributes.getCategory()) && 
				this.component.equals(catAttributes.getComponent()) &&
				this.description.equals(catAttributes.getDescription()) &&
				this.min.equals(catAttributes.getMin()) &&
				this.max.equals(catAttributes.getMax()))
		{
			isEqual = true;
			return isEqual;
			
		}
		if (this == obj){
			isEqual = true;
			return isEqual;
		}

		if (getClass() != obj.getClass()){
			isEqual = false;
			return isEqual;
		}
		return isEqual;
	}
}
