package com.navistar.datadictionary.model;

import java.util.List;

public class TableCellArray {
	private List<Object> tableCellList;
	
	public TableCellArray() {
	}

	public List<Object> getTableCellList() {
		return tableCellList;
	}

	public void setTableCellList(List<Object> tableCellList) {
		this.tableCellList = tableCellList;
	}

	@Override
	public String toString() {
		return "TableCellArray [tableCellList=" + tableCellList + "]";
	}
}
