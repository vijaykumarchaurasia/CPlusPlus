package com.navistar.datadictionary.model;

import java.util.ArrayList;
import java.util.List;

/** 
 * class is used to collect all NatTableRowIndex instances for deleted row
 * @author JAYSHRIVISHB
 *
 */
public class NatTableRowIndexArrayForDelete {
	
	/** list of NatTableRowIndex */
	private List<Object> naTblRowIdxList;
	
	/**
	 * Default constructor
	 */
	public NatTableRowIndexArrayForDelete() {
		naTblRowIdxList = new ArrayList<>();
	}

	/**
	 * Method used to get the list of NatTableRowIndex instance
	 * @return
	 */
	public List<Object> getNatTableRowIndexList() {
		return naTblRowIdxList;
	}

	/**
	 * Method used to set the list of NatTableRowIndex instance
	 * @param natTableRowIndexList
	 */
	public void setNatTableRowIndexList(List<Object> naTblRowIdxList) {
		this.naTblRowIdxList = naTblRowIdxList;
	}

	/**
	 * Method used to get instance of NatTableRowIndexList
	 */
	@Override
	public String toString() {
		return "NatTableRowIndexArray [natTableRowIndexList=" + naTblRowIdxList + "]";
	}	
}

