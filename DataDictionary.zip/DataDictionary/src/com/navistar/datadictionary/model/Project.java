package com.navistar.datadictionary.model;

/**
 * Class is used for project information such as project path, status and its component path
 * @author shubhangim1
 *
 */
public class Project {

	/** Project path*/
	private String path;
	/** Project status*/
	private int status;
	/** Component path*/
	private String componentPath;
	/** recently imported project list as string */
	private String rcntImpProjList;

	/**
	 * Parameterized constructor
	 * @param path
	 * @param status
	 * @param componentPath
	 * @param recentlyImportedProjectList
	 */
	public Project(String path, int status, String componentPath,String rcntImpProjList) {
		super();
		this.path = path;
		this.status = status;
		this.componentPath = componentPath;
		this.rcntImpProjList = rcntImpProjList;
	}

	/**
	 * Method is used to get component path
	 * @return
	 */
	public String getComponentPath() {
		return componentPath;
	}

	/**
	 * Method is used to set component path
	 * @param componentPath
	 */
	public void setComponentPath(String componentPath) {
		this.componentPath = componentPath;
	}

	/**
	 * Method is used to get project path
	 * @return
	 */
	public String getPath() {
		return path;
	}

	/**
	 * Method is used to set project path
	 * @param path
	 */
	public void setPath(String path) {
		this.path = path;
	}

	/**
	 * Method is used to get project's status
	 * @return
	 */
	public int getStatus() {
		return status;
	}

	/**
	 * Method is used to set project's status
	 * @param status
	 */
	public void setStatus(int status) {
		this.status = status;
	}

	/**
	 * Method is used to get project object
	 * @return
	 */
	@Override
	public String toString() {
		return "Project [path=" + path + ", status=" + status + "]";
	}

	/**
	 * Method is used to get the recently imported projects
	 */
	public String getRecentlyImportedProjectList() {
		return rcntImpProjList;
	}

	/**
	 * Method is used to set the recently imported projects
	 */
	public void setRecentlyImportedProjectList(String rcntImpProjList) {
		this.rcntImpProjList = rcntImpProjList;
	}

}
