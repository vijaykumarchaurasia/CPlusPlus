package com.navistar.datadictionary.model;

import java.util.ArrayList;
import java.util.List;

/** 
 * class is used to collect all NatTableRowIndex instances
 * @author minalc
 *
 */
public class NatTableRowIndexArray {
	
	/** list of NatTableRowIndex */
	private List<Object> natTblRowIdxList;
	
	/**
	 * Default constructor
	 */
	public NatTableRowIndexArray() {
		natTblRowIdxList = new ArrayList<>();
	}

	/**
	 * Method used to get the list of NatTableRowIndex instance
	 * @return
	 */
	public List<Object> getNatTableRowIndexList() {
		return natTblRowIdxList;
	}

	/**
	 * Method used to set the list of NatTableRowIndex instance
	 * @param natTableRowIndexList
	 */
	public void setNatTableRowIndexList(List<Object> natTblRowIdxList) {
		this.natTblRowIdxList = natTblRowIdxList;
	}

	/**
	 * Method used to get instance of NatTableRowIndexList
	 */
	@Override
	public String toString() {
		return "NatTableRowIndexArray [natTableRowIndexList=" + natTblRowIdxList + "]";
	}	
}

