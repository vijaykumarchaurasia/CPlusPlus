package com.navistar.datadictionary.model;

import com.google.gson.annotations.SerializedName;

/**
 * Class used for data access object for category in I/O tables
 * 
 * @author nikitak1
 *
 */
public class CategoryAttributesIo extends CategoryAttributes{
	
	/** hidden attribute */
	@SerializedName("hidden")
	private String flag;

	/**
	 * Default Constructor
	 */
	public CategoryAttributesIo(){

	}


    public CategoryAttributesIo(String warning, String category, String name, String structureElementname, String value, String description, String component,
			String baseType, String offset, String slope, String min, String max, String unit, String complexity,
			String dimensions, String dimensionsMode, String sampleTime, String initialValue,
			String swCalAccess, String displayFormat, String coderInfo,String memorySection, String hidden) {
    	super(warning, category, name, structureElementname, value, description, component, baseType, offset, slope, min, max, unit, 
    			complexity, dimensions, dimensionsMode, sampleTime, initialValue, swCalAccess, 
    			coderInfo,displayFormat, memorySection);
    	
    	this.flag = hidden;
    }
    
    public String getFlag() {
		return flag;
	}


	public void setFlag(String flag) {
		this.flag = flag;
	}


	/**
	 * Method used to get category attributes.
	 */
	@Override
	public String toString() {
		return "CategoryAttributes [warning=" + getWarning() + ", category=" + getCategory() + ", name=" + getName() + ", structureElementname =" + getStructureElementName() + ", value="
				+ getValue() + ", description=" + getDescription() + ", component=" + getComponent() + ", baseType=" + getBaseType()
				+ ", offset=" + getOffset() + ", slope=" + getSlope() + ", min=" + getMin() + ", max=" + getMax() + ", unit=" + getUnit()
				+ ", complexity=" + getComplexity() + ", dimensions=" + getDimensions() + ", dimensionsMode=" + getDimensionsMode()
				+ ", sampleTime=" + getSampleTime() + ",  initialValue=" + getInitialValue()
				+ ", swCalibrationAccess=" + getSwCalAccess() + ", displayFormat=" + getDisplayFormat() + ", coderInfo="
				+ getCoderInfo() + ",memorySection=" + getMemorySection() + ", oldName=" + getOldName() + ", maxDimension=" + getMaxDimension() + ", flag=" + flag + "]";
	}

	/**
	 * This method is used to compare Objects of CategoryAttributes for equality
	 */
	@Override
	public boolean equals(Object obj) {

		boolean isEqual = false;
		CategoryAttributesIo catAttributes = (CategoryAttributesIo) obj;
		
		// If the object is compared with itself then return true   
		if (obj == this) { 
			isEqual = true;
			return isEqual;
		} 

		// Check if obj is an instance of CategoryAttributes or not "null instanceof [type]" also returns false 
		if (!(obj instanceof CategoryAttributesIo)) { 
			isEqual = false;
			return isEqual;
		}

		if(super.getWarning().equals(catAttributes.getWarning()) && 
				super.getName().equals(catAttributes.getName()) && 
				super.getCategory().equals(catAttributes.getCategory()) && 
				super.getComponent().equals(catAttributes.getComponent()) &&
				super.getDescription().equals(catAttributes.getDescription()) &&
				super.getMin().equals(catAttributes.getMin()) &&
				super.getMax().equals(catAttributes.getMax()))
		{
			isEqual = true;
			return isEqual;
			
		}
		if (this == obj){
			isEqual = true;
			return isEqual;
		}

		if (getClass() != obj.getClass()){
			isEqual = false;
			return isEqual;
		}
		return isEqual;
	}
}
