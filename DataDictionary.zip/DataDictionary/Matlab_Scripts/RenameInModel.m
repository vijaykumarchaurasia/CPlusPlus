%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :RenameInModel
% MAIN PURPOSE     :Function is used to rename data object(s) in Simulink model as 
%                   well as in sldd.(Applicable for all categories)  
% INPUT(S)         :1.sldd_path=(''C:\Users\shubhangim1\Music\E39_example\AirManagement\aserc\Model\aserc.sldd')
%                   2.rename_obj=struct('oldName','CPPPP_distCruiseTrip','newName','Rename_Out','category','Output')
% OUTPUT           :1.Renamed data object(s) in Simulink model as well as in sldd, open 
%                     respective model and send "messagecode:511" on successful rename OR
%                   2.If simulink model not present in project folder will send
%                     "errorCode:114" OR
%                   3.Renamed fail in model will send "errorCode:122",category and Attribute name
%                   4.Renamed fail in sldd will send "errorCode:121",category and Attribute name
%                   5.Renamed fail in sldd will send "errorCode:123",category and Attribute name
% DATE OF CREATION :30th July 2019
% REVESION NO      :Rev.1.5
% STATUS           :Rev. 1.1: Tested to Rename data object(s)in single sldd
%                        1.2: Tested to Rename data object(s)in simulink model
%                             and sldd
%                        1.3: Tested to Rename data object(s)in simulink model and sldd, only if
%                             model is available in project folder
%                        1.4: Optimization of script
%                        1.5: num_Of_Entries evaluation is changed as program name entry is added in other data section.
% FUNCTION CALL    :1.[Map,Curve,Axis,Inputs,Outputs,CalibrationAndDefine,Nvm,Local,Unique_Constant_First_Order_Transfer_Fcn,SeperatingPathOfSldd,~,~,~,~,~,~,~,~,modelData,errorCode,GetmodelPath]= ModelData(sldd_path);
%                   2.modelSuccess =DataObjectRenameInModel(sldd_path,Dobjoldname,Dobjnewname,DobjCategory);
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [renameScucess] = RenameInModel(sldd_path,rename_obj)
% Function call  
OldNameOfObj=rename_obj.oldName;
[Map,Curve,Axis,Inputs,Outputs,CalibrationAndDefine,Nvm,Local,Unique_Constant_First_Order_Transfer_Fcn,SeperatingPathOfSldd,~,~,~,~,~,~,~,~,modelData,errorCode,GetmodelPath]= ModelData(sldd_path,OldNameOfObj);
%Precaution has been taken if model loaded previously, because same name model cannot open from other path 
if ~isempty(modelData)               
    renameScucess=table(modelData);        %Exception message will send if same name model is trying to open from other path
    return;
end
%if model not available in project folder
if strcmp(errorCode,'114')
    renameScucess=table(errorCode);
    return;
end
%Combining model data boject
modelData=[Map;Curve;Axis;Inputs;Outputs;CalibrationAndDefine;Unique_Constant_First_Order_Transfer_Fcn;Nvm;Local];

%Open sldd to fetch data from it
myDictionaryObj = Simulink.data.dictionary.open(SeperatingPathOfSldd{1});
dDataSectObj = getSection(myDictionaryObj,'Design Data');
allEntries = find(dDataSectObj);
num_Of_Entries = length(allEntries);
%Initialization
cntr=1;
flag1=1;
flag2=1;
flag3=1;
flag4=1;
Data1="";
DataObjSldd{1,num_Of_Entries} = [];
%Implementation of loading indicator
%Start loadingIndicator
LoadingIndicator = waitbar(0,'0% Completed','Name','Renaming data object(s) in model...','WindowStyle', 'modal');
frames = java.awt.Frame.getFrames();
frames(end).setAlwaysOnTop(1);                %Set loadingIndicator always on top of screen
javaFrame = get(LoadingIndicator,'JavaFrame');
ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png'); 
javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath)); %Set data dictionary icon on loadingIndicator
%Loop to rename data object(s)    
for length_objNames = 1:length(rename_obj)
    % Checking old data object name present in model 
    [LogicalData,~]=ismember((rename_obj(length_objNames).oldName),modelData);   
    if LogicalData==0
        flag2=0;
        Data1(cntr,1) = string(num2str(122));
        Data1(cntr,2) = string(rename_obj(length_objNames).category);
        Data1(cntr,3) = string(rename_obj(length_objNames).oldName); 
        Data1(cntr,4) = ('Old name of data object is not present in model');
        cntr=cntr+1;
    else
        %Store data object names of sldd
      	for index2=1:num_Of_Entries
            property_name=allEntries(index2).Name;
            DataObjSldd{index2}=property_name;
        end
      % Making sure new data object name is not present in sldd 
      [LogicalData2,~]=ismember(DataObjSldd,(rename_obj(length_objNames).newName));
       if nnz(LogicalData2)>0
              flag1=0;
              Data1(cntr,1) = string(num2str(121));
              Data1(cntr,2) = string(rename_obj(length_objNames).category);
              Data1(cntr,3) = string(rename_obj(length_objNames).oldName); 
              Data1(cntr,4) = ('New name of data object is already present in sldd'); 
              cntr=cntr+1;
       else
              %Checking old data object name present in sldd
              [LogicalData3,~]=ismember(DataObjSldd,(rename_obj(length_objNames).oldName));
              if nnz(LogicalData3)==0
                 flag3=0;
				 Data1(cntr,1) = string(num2str(121));
				 Data1(cntr,2) = string(rename_obj(length_objNames).category);
				 Data1(cntr,3) = string(rename_obj(length_objNames).oldName); 
                 Data1(cntr,4) = ('Data object not present in sldd');
				 cntr=cntr+1; 
              else
                  for index2=1:num_Of_Entries
                      property_name=allEntries(index2).Name;
                      % Making sure old data object name exist in sldd 
                      if strcmp(property_name,(rename_obj(length_objNames).oldName))      %Checking data object present in sldd
                            allEntries(index2).Name=(rename_obj(length_objNames).newName);%Renaming data object in sldd
                            Dobjoldname = rename_obj(length_objNames).oldName;            %Accessing oldName to send as input to 'DataObjectRenameInModel' function 
                            Dobjnewname = rename_obj(length_objNames).newName;            %Accessing newName to send as input to 'DataObjectRenameInModel' function
                            DobjCategory = rename_obj(length_objNames).category;          %Accessing category to send as input to 'DataObjectRenameInModel' function
                            saveChanges(myDictionaryObj)                                  %Saving changes in sldd
                            % Function call to rename data object in model
                            modelSuccess = DataObjectRenameInModel(sldd_path,Dobjoldname,Dobjnewname,DobjCategory,GetmodelPath);	
                            if contains(modelSuccess,'The data should be a 1D finite real numeric vector of width greater than 1')
                                flag4=0;
                                Data1(cntr,1) = string(num2str(123));
                                Data1(cntr,2) = string(rename_obj(length_objNames).category);
                                Data1(cntr,3) = string(rename_obj(length_objNames).oldName); 
                                Data1(cntr,4) = ('prelookup block value field does not contains array with increasing order');
                                cntr=cntr+1; 
                            end
                      end
                  end
              end
      end
    end
    waitbar(length_objNames/length(rename_obj),LoadingIndicator,sprintf('%1.0f%% Completed',(length_objNames/(length(rename_obj)))*100))
end
%If old data object name is not present in sldd will send error code:121
if flag3==0
	renameScucess = {cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'} )};
     close(LoadingIndicator);
    return;
end
% If old data object name is not present in model will send error code:122
if flag2==0
	renameScucess = {cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'} )};
     close(LoadingIndicator);
    return;
end

%If prelookup block value field does not contains array with increasing order 
if flag4==0
	renameScucess = {cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'} )};
     close(LoadingIndicator);
    return;
end

if flag1==0                            %If new data object name is present in sldd will send error code:121
	renameScucess = {cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'} )}; 
    close(LoadingIndicator)            %Close loadingIndicator
else
	messageCode = "511";
	Data2 = (table(messageCode));
	renameScucess{1,:}=Data2;          %If data object renamed successfully will send message code:511
    close(LoadingIndicator)            %Close loadingIndicator
	save_system(modelSuccess)          %Save model 
end