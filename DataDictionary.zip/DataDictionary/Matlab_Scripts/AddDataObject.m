%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :AddDataObject
% MAIN PURPOSE     :Function is used to Add, Update, Rename data object(s) in sldd
% INPUT(S)         :1.sldd_path=('C:\Users\shubhangim1\Music\E39_example\AirManagement\aserc\Model\aserc.sldd')
%                   2.added_data_Obj=struct('warning','','category','Output','Name','new_op','Value','','Description','Edit_description','component','fiacc','Basetype','boolean','Offset','0','slope','1','Min','0','Max','1','Unit','','Complexity','real','Dimensions','1','DimensionsMode','auto','SampleTime','-1','SamplingMode','','InitialValue','[0]','SwCalibrationAccess','ReadOnly','DisplayFormat','','CoderInfo','Custom','oldName','new_op');
% OUTPUT           :1.Data object added successfully will send "messageCode=501"
%                   2.Wrong validation will send "errorCode=111"
% DATE OF CREATION :17th May 2019
% REVESION NO      :1.9
% STATUS           :Rev. 1.1: Tested to add data object(s) in sldd
%                        1.2: Changed as per Excel sheet provided from Customer
%                        1.3: Handle Error Conditions and Blank data from Java
%                        1.4: Send Category and DataObjectName if Dataobject not added
%                        1.5: Validation for attributes which accept only Numbers
%                        1.6: Rename data objec(s) in sldd
%                        1.7: If any matlab variable/signal/parameter which not contain category added in sldd from backend and same name data obj try to add from tool,then backend obj get deleted and adding user entered data obj in sldd
%                        1.8: Hardcoded categories removed and Reading configuration excel file stored in Navistar Tool box, data object attributes are configured using switch case depending on data object type,  
%                             num_Of_Entries evaluation is changed as program name entry is added in other data section.
%                        1.9: 22th Sep 2021
%                             Added GetConfigurationData function call to get configuration data from excel. \
%                        1.10: 10th Mar 2022
%                             1) Added switch case for AUTOSAR4.Parameter type 
%                             2) For AUTOSAR4.Parameter, added condition of attribute storageclass (E95 specific) and MemorySection attribute
% FUNCTION CALL    :DataMsg = DataValidationforObject(added_data_Obj,length_objNames);
%                   [~] =DeleteDataObject(sldd_path,delete_data_object);
%                   [ConfigurationData,errorCode] = GetConfigurationData(ConfigFilePath,ProgramName);
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function SendData = AddDataObject(componentData,added_data_Obj)
DataObjAdded='';
%Extract sldd_path, ConfigFilePath and ProgramName from componentData
FilePaths = split(componentData,',');
sldd_path = FilePaths{1};
ConfigFilePath = FilePaths{2};
ProgramName = FilePaths{3};

%Get configuration data from excel file in table form
[ConfigurationData,errorCode] = GetConfigurationData(ConfigFilePath,ProgramName);
if strcmp(errorCode,"1006") || strcmp(errorCode,"1007") 
    SendData = table(errorCode);
    return;
end
%Implementation of LoadingIndicator
LoadingIndicator = waitbar(0,' 1% Completed','Name','Adding data object(s)...','windowstyle', 'modal');
frames = java.awt.Frame.getFrames();
frames(end).setAlwaysOnTop(1);
javaFrame = get(LoadingIndicator,'JavaFrame');
ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));

%Category fields defined in configuration file
categorys = ConfigurationData.CategoryFields;

for length_objNames = 1:length(added_data_Obj)
    %Detecting added data object category row number
    StoreCategoryIndex = find(strcmp(categorys,added_data_Obj(length_objNames).category));
    %Condition for categories present in Excel file
    if nnz(ismember(categorys,added_data_Obj(length_objNames).category))
        DataMsg = DataValidationforObject(added_data_Obj,length_objNames);
        outputfromValidation = fields(DataMsg);
        if contains(outputfromValidation{1}, 'MessageCode')
            myDictionaryObj =Simulink.data.dictionary.open(sldd_path);        %open sldd
            dDataSectObj = getSection(myDictionaryObj,'Design Data');         %get design data from sldd    
            allEntries = find(dDataSectObj);
			num_Of_Entries = length(allEntries);
            dataObject_Name={};
            attributes={};
            if num_Of_Entries > 0
                for index2=1:num_Of_Entries
                    dataObject_Name{index2}=allEntries(index2).Name;
                    attributes{index2}=getValue(allEntries(index2));       
                end
            end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    % Logic to rename data object in sldd
            cntr=1;
            if ~nnz(contains((added_data_Obj(length_objNames).oldName),'null'))
                [var2,~]=ismember((added_data_Obj(length_objNames).oldName),dataObject_Name);
                if  nnz(var2)>0  
                    if ~isequal((added_data_Obj(length_objNames).Name),(added_data_Obj(length_objNames).oldName))
                        [var,~]=ismember((added_data_Obj(length_objNames).Name),dataObject_Name);
                        if nnz(var)>0
                            Data1(cntr,1) = string(num2str(121));
                            Data1(cntr,2) = string(added_data_Obj(length_objNames).category);
                            Data1(cntr,3) = string(added_data_Obj(length_objNames).Name);
                            Data1(cntr,4) = 'Name';
                            cntr=cntr+1;
                            SendData = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'});
                            close(LoadingIndicator)
                            return;
                        else
                            for index2=1:num_Of_Entries
                                dataObject_Name{index2}=allEntries(index2).Name;
                                if strcmp(dataObject_Name{index2},(added_data_Obj(length_objNames).oldName)) % comparing OldName and existing data object in sldd 
                                    allEntries(index2).Name=(added_data_Obj(length_objNames).Name);
                                    dataObject_Name{index2} = (added_data_Obj(length_objNames).Name);
                                end
                            end
                        end
                    end
                end
            end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            fieldsInDobj={};
    %       add_simulinlk_signal_obj='';
            new_data_object=added_data_Obj(length_objNames).Name;           %store 'Name' of data object 
            [dObjPrsnt, ~] = ismember(new_data_object,dataObject_Name);
            addDataEntry = 1;
            if (nnz(dObjPrsnt)>0) %If data object is getting updated
                addDataEntry =0;
                entryObj = getEntry(dDataSectObj,new_data_object);            
                add_simulinlk_signal_obj = getValue(entryObj);      
                if isequal(add_simulinlk_signal_obj,0)%If matlab variable added in sldd from backend and same name data obj added from tool,then backend obje get deleted and adding user entered data obj in sldd
                    [~]=DeleteDataObject(sldd_path,entryObj);
                    addDataEntry = 1;
                else
                    fieldsInDobj = fields(add_simulinlk_signal_obj);%If any matlab variable which not contain category added in sldd from backend and same name data obj try to add from tool,then backend obj get deleted and adding user entered data obj in sldd
                    DobjCategryPrsnt = contains(fieldsInDobj,'objectType');
                    if nnz(DobjCategryPrsnt) < 1
                        [~] =DeleteDataObject(sldd_path,entryObj);
                        addDataEntry = 1;
                    end
                end
            end
            Dimesnion_for_val = str2num(added_data_Obj(length_objNames).Dimensions);%Get dimension
            
            DataObjectType = ConfigurationData.ObjectType{StoreCategoryIndex};
            if addDataEntry ==1   %If newly data object get added
                    %Object type for data object
                    switch(DataObjectType)
                        case 'AUTOSAR.Signal'
                            add_simulinlk_signal_obj = AUTOSAR.Signal;
                        case 'Simulink.Signal'
                            add_simulinlk_signal_obj = Simulink.Signal;
                        case 'AUTOSAR.Parameter'
                            add_simulinlk_signal_obj = AUTOSAR.Parameter;
                        case 'Simulink.Parameter'
                            add_simulinlk_signal_obj = Simulink.Parameter;
                        case 'AUTOSAR4.Parameter'
                            add_simulinlk_signal_obj = AUTOSAR4.Parameter;
                    end
                add_simulinlk_signal_obj.addprop('objectType'); % Add 'objectType' property while adding data object
            end
            %Condition for signal and parameter object type
            if contains(DataObjectType,'Signal')
                %Initial value
                add_simulinlk_signal_obj.InitialValue = added_data_Obj(length_objNames).InitialValue;
                %Data type
                add_simulinlk_signal_obj.DataType = added_data_Obj(length_objNames).Basetype;
                %Dimensions
                if (strcmp((added_data_Obj(length_objNames).InitialValue),""))
                    add_simulinlk_signal_obj.Dimensions = 1;
                else
                    add_simulinlk_signal_obj.Dimensions = (length(str2num(added_data_Obj(length_objNames).InitialValue))); 
                end
                %Hidden Attributes
                %Sample Time
                add_simulinlk_signal_obj.SampleTime = str2num(ConfigurationData.SampleTime{StoreCategoryIndex});
                %Storage Class
                if isequal(ProgramName, 'E95')
                    add_simulinlk_signal_obj.StorageClass = ConfigurationData.StorageClass{StoreCategoryIndex};
                else
                    add_simulinlk_signal_obj.CoderInfo.StorageClass = ConfigurationData.StorageClass{StoreCategoryIndex};
                    if strcmp('Custom',ConfigurationData.StorageClass{StoreCategoryIndex})% Condition for custom
                        %Custom storage class
                        add_simulinlk_signal_obj.CoderInfo.CustomStorageClass = ConfigurationData.CustomStorageClass{StoreCategoryIndex};
                        %Header file
                        if ~strcmp('NA',ConfigurationData.HeaderFile{StoreCategoryIndex})
                            add_simulinlk_signal_obj.CoderInfo.CustomAttributes.HeaderFile = ConfigurationData.HeaderFile{StoreCategoryIndex};
                        end
                    end
                end
                %%Complexity
                add_simulinlk_signal_obj.Complexity = ConfigurationData.Complexity{StoreCategoryIndex};
                %Dimensions mode
                add_simulinlk_signal_obj.DimensionsMode = ConfigurationData.DimensionsMode{StoreCategoryIndex};
                %Condition to check if object type is AUTOSAR type
                if contains(DataObjectType, 'AUTOSAR')
                    %SwCalibration Access
                    add_simulinlk_signal_obj.SwCalibrationAccess = ConfigurationData.SwCalibrationAccess{StoreCategoryIndex};
                    %Display Format
                    if ~isequal(ProgramName, 'E95')
                        add_simulinlk_signal_obj.DisplayFormat = ConfigurationData.DisplayFormat{StoreCategoryIndex};
                    end
                end
            else
                if contains(DataObjectType, 'Parameter')
                    %Value
                    add_simulinlk_signal_obj.Value = Value(added_data_Obj,Dimesnion_for_val,length_objNames);
                    %Base Type          
                    add_simulinlk_signal_obj.DataType = added_data_Obj(length_objNames).Basetype;
                    
                    %Hidden Attributes
                    %Storage Class
                    if isequal(ProgramName,'E95')
                        add_simulinlk_signal_obj.StorageClass = ConfigurationData.StorageClass{StoreCategoryIndex};
                        if isequal(DataObjectType, 'AUTOSAR4.Parameter')
                            add_simulinlk_signal_obj.CoderInfo.CustomAttributes.MemorySection = ConfigurationData.MemorySection{StoreCategoryIndex};
                        end
                    else
                        add_simulinlk_signal_obj.CoderInfo.StorageClass = ConfigurationData.StorageClass{StoreCategoryIndex};
                        if strcmp('Custom',ConfigurationData.StorageClass{StoreCategoryIndex})% Condition for custom
                            %Custom storage class
                            add_simulinlk_signal_obj.CoderInfo.CustomStorageClass = ConfigurationData.CustomStorageClass{StoreCategoryIndex};
                            %Header file
                            if ~strcmp('NA',ConfigurationData.HeaderFile{StoreCategoryIndex})
                                add_simulinlk_signal_obj.CoderInfo.CustomAttributes.HeaderFile = ConfigurationData.HeaderFile{StoreCategoryIndex};
                            end
                        end
                    end
                    if contains(DataObjectType, 'AUTOSAR')
                        %SwCalibration Access
                        add_simulinlk_signal_obj.SwCalibrationAccess = ConfigurationData.SwCalibrationAccess{StoreCategoryIndex};
                        %Display Format
                        if ~isequal(ProgramName, 'E95')
                            add_simulinlk_signal_obj.DisplayFormat = ConfigurationData.DisplayFormat{StoreCategoryIndex};
                        end
                    end
                end
            end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
    % Implementation for DataType as Compu Method
            Basetype = added_data_Obj(length_objNames).Basetype;
            expressionsep = '[a-z,A-Z]';
            DataTypIdx = regexp(Basetype,expressionsep,'split');
            Bitsize = str2num(char(DataTypIdx(end)));
            expressionsignbit = 'u';
            signbitchk = regexp(Basetype,expressionsignbit,'match');
            if isempty(signbitchk)
                intbit = '1' ;   
            else
                intbit = '0' ;  
            end

            %%%--Validation for Offset--%%%
            offset = str2num(added_data_Obj(length_objNames).Offset);
            if isempty(offset)
                Data1(1,1) = string(num2str(111));
                Data1(1,2) = string(added_data_Obj(length_objNames).category);
                Data1(1,3) = string(added_data_Obj(length_objNames).Name);
                Data1(1,4) = 'Enter numeric value for Offset';
                SendData = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'});
                close(LoadingIndicator)
                return;
            end
            %%%--Validation for slope--%%%
            slope = str2num(added_data_Obj(length_objNames).slope);
            %Condition handled if slope field contains any special character
            if isempty(slope) || slope<=0
                Data1(1,1) = string(num2str(111));
                Data1(1,2) = string(added_data_Obj(length_objNames).category);
                Data1(1,3) = string(added_data_Obj(length_objNames).Name);
                Data1(1,4) = 'Slope can not be negative and 0. Enter valid numeric value.';
                SendData = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'});
                close(LoadingIndicator)
                return;
            else
                %Condition handled for slope field connot be negative
                if isnumeric(slope)
                      frsactionL = log(1/slope)/log(2);
                end
            end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%            
            %If Offset=0 && slope=1 (Basetype: except 'single' and 'boolean')
            BaseTypeForMinMaxCalculation={'int8','uint8','int16','uint16','int32','uint32'};
            minvalUsr = str2num(added_data_Obj(length_objNames).Min);
            maxvalUsr = str2num(added_data_Obj(length_objNames).Max);
            slopeUsr = str2num(added_data_Obj(length_objNames).slope);
            format long
            frsactionLUsr = log(1/slopeUsr)/log(2);
            precisionUsr = (1/(2^frsactionLUsr));
            if ~isreal(frsactionLUsr)|| isinf(frsactionLUsr)
               SendData = ErrorforValueWithinRange(added_data_Obj,length_objNames,LoadingIndicator);
               close(LoadingIndicator)
               return;
            end
            int8Min=-128;
            int8Max=127;
            uint8Min=0;
            uint8Max=255;
            int16Min=-32768; 
            int16Max=32767; 
            uint16Min=0;
            uint16Max=65535;
            int32Min=-2147483648;
            int32Max=2147483647;
            uint32Min=0;
            uint32Max=4294967295;

            if nnz(contains(categorys,(added_data_Obj(length_objNames).category)))   %Check whether category of added data object is present in Categoryfields
                if (str2num(added_data_Obj(length_objNames).Offset)==0 && str2num(added_data_Obj(length_objNames).slope)==1)
                   if nnz(strcmp(added_data_Obj(length_objNames).Basetype,BaseTypeForMinMaxCalculation(1:6)))
                       switch(added_data_Obj(length_objNames).Basetype)
                           case 'int8'
                               if (~isempty(minvalUsr)) && (~isempty(maxvalUsr))
                                   if  (minvalUsr < int8Min) || (maxvalUsr >int8Max)
                                      DataObjAdded = ErrorforValueWithinRange(added_data_Obj,length_objNames,LoadingIndicator);
                                   end
                               end

                           case 'uint8'   
                               if (~isempty(minvalUsr)) && (~isempty(maxvalUsr))
                                   if (minvalUsr < uint8Min) || (maxvalUsr > uint8Max)
                                      DataObjAdded = ErrorforValueWithinRange(added_data_Obj,length_objNames,LoadingIndicator);
                                   end
                               end

                           case 'int16' 
                               if (~isempty(minvalUsr)) && (~isempty(maxvalUsr))
                                   if (minvalUsr < int16Min) || (maxvalUsr > int16Max)
                                      DataObjAdded = ErrorforValueWithinRange(added_data_Obj,length_objNames,LoadingIndicator);
                                   end
                               end

                           case 'uint16'   
                               if (~isempty(minvalUsr)) && (~isempty(maxvalUsr))
                                   if (minvalUsr < uint16Min) || (maxvalUsr > uint16Max)
                                      DataObjAdded = ErrorforValueWithinRange(added_data_Obj,length_objNames,LoadingIndicator);
                                   end
                               end

                           case 'int32'    
                               if (~isempty(minvalUsr)) && (~isempty(maxvalUsr))
                                   if  (minvalUsr < int32Min) || (maxvalUsr > int32Max)
                                      DataObjAdded = ErrorforValueWithinRange(added_data_Obj,length_objNames,LoadingIndicator);
                                   end
                               end

                           case 'uint32'  
                               if (~isempty(minvalUsr)) && (~isempty(maxvalUsr))
                                   if (minvalUsr < uint32Min) || (maxvalUsr > uint32Max)
                                      DataObjAdded = ErrorforValueWithinRange(added_data_Obj,length_objNames,LoadingIndicator);
                                   end
                               end
                       end
                   end
                %If Offset=0 && Slope is in power of 2 (e.g 2,4,8,0.5,0.25)
                elseif (str2num(added_data_Obj(length_objNames).Offset)==0 && mod(frsactionLUsr,1)==0 )   
                        if nnz(strcmp(added_data_Obj(length_objNames).Basetype,BaseTypeForMinMaxCalculation(1:6)))
                            switch(added_data_Obj(length_objNames).Basetype)
                                case 'int8'
                                    OutputMin=int8Min * precisionUsr;
                                    OutputMax=int8Max * precisionUsr;
                                    if (~isempty(minvalUsr)) && (~isempty(maxvalUsr))
                                        if (minvalUsr < OutputMin) || (maxvalUsr > OutputMax)
                                            DataObjAdded = ErrorforValueWithinRange(added_data_Obj,length_objNames,LoadingIndicator);
                                        end
                                    end

                                case 'uint8'
                                     OutputMin=uint8Min * precisionUsr;
                                     OutputMax=uint8Max * precisionUsr;
                                    if (~isempty(minvalUsr)) && (~isempty(maxvalUsr))
                                        if (minvalUsr < OutputMin) || (maxvalUsr > OutputMax)
                                            DataObjAdded = ErrorforValueWithinRange(added_data_Obj,length_objNames,LoadingIndicator);
                                        end
                                    end

                                case 'int16'
                                    OutputMin=int16Min * precisionUsr;
                                    OutputMax=int16Max * precisionUsr;
                                    if (~isempty(minvalUsr)) && (~isempty(maxvalUsr))
                                        if (minvalUsr < OutputMin) || (maxvalUsr >OutputMax)
                                            DataObjAdded = ErrorforValueWithinRange(added_data_Obj,length_objNames,LoadingIndicator);
                                        end
                                    end

                                case 'uint16'
                                    OutputMin=uint16Min * precisionUsr;
                                    OutputMax=uint16Max * precisionUsr;
                                    if (~isempty(minvalUsr)) && (~isempty(maxvalUsr))
                                        if (minvalUsr < OutputMin) || (maxvalUsr > OutputMax)
                                            DataObjAdded = ErrorforValueWithinRange(added_data_Obj,length_objNames,LoadingIndicator);
                                        end
                                    end

                                case 'int32' 
                                    OutputMin=int32Min * precisionUsr;
                                    OutputMax=int32Max * precisionUsr;
                                    if (~isempty(minvalUsr)) && (~isempty(maxvalUsr ))
                                        if (minvalUsr < OutputMin) || (maxvalUsr > OutputMax)
                                            DataObjAdded = ErrorforValueWithinRange(added_data_Obj,length_objNames,LoadingIndicator);
                                        end
                                    end

                                case 'uint32'   
                                    OutputMin=uint32Min * precisionUsr;
                                    OutputMax=uint32Max * precisionUsr;
                                    if (~isempty(minvalUsr)) && (~isempty(maxvalUsr))
                                        if (minvalUsr < OutputMin) || (maxvalUsr > OutputMax)
                                            DataObjAdded = ErrorforValueWithinRange(added_data_Obj,length_objNames,LoadingIndicator);
                                        end
                                    end
                            end
                        end

                else
                    if str2num(added_data_Obj(length_objNames).slope)<=0
                          DataObjAdded = ErrorforValueWithinRange(added_data_Obj,length_objNames,LoadingIndicator);
                    end
                    if ~(str2num(added_data_Obj(length_objNames).Offset)==0 && str2num(added_data_Obj(length_objNames).slope)==1) || ~(str2num(added_data_Obj(length_objNames).Offset)==0 && mod(frsactionLUsr,1)==0 )  
                        if nnz(strcmp(added_data_Obj(length_objNames).Basetype,BaseTypeForMinMaxCalculation(1:6)))
                            switch(added_data_Obj(length_objNames).Basetype)
                                case 'int8'
                                    OutputMin=((int8Min * slopeUsr) + str2num(added_data_Obj(length_objNames).Offset));
                                    OutputMax=((int8Max * slopeUsr) + str2num(added_data_Obj(length_objNames).Offset));
                                    if (~isempty(minvalUsr)) && (~isempty(maxvalUsr))
                                        if (minvalUsr < OutputMin) || (maxvalUsr > OutputMax)
                                            DataObjAdded = ErrorforValueWithinRange(added_data_Obj,length_objNames,LoadingIndicator);
                                        end
                                    end

                                case 'uint8'
                                     OutputMin=((uint8Min * slopeUsr)+ str2num(added_data_Obj(length_objNames).Offset));
                                     OutputMax=((uint8Max * slopeUsr)+ str2num(added_data_Obj(length_objNames).Offset));
                                     if (~isempty(minvalUsr)) && (~isempty(maxvalUsr))
                                         if ( minvalUsr < OutputMin) || (maxvalUsr > OutputMax)
                                            DataObjAdded = ErrorforValueWithinRange(added_data_Obj,length_objNames,LoadingIndicator);
                                         end
                                     end

                                case 'int16'
                                    OutputMin=((int16Min * slopeUsr) + str2num(added_data_Obj(length_objNames).Offset));
                                    OutputMax=((int16Max * slopeUsr) + str2num(added_data_Obj(length_objNames).Offset));
                                     if (~isempty(minvalUsr)) && (~isempty(maxvalUsr))
                                         if (minvalUsr < OutputMin) || (maxvalUsr > OutputMax)
                                            DataObjAdded = ErrorforValueWithinRange(added_data_Obj,length_objNames,LoadingIndicator);
                                         end
                                     end

                                case 'uint16'
                                    OutputMin=((uint16Min * slopeUsr) + str2num(added_data_Obj(length_objNames).Offset));
                                    OutputMax=((uint16Max * slopeUsr) + str2num(added_data_Obj(length_objNames).Offset));
                                    if (~isempty(minvalUsr)) && (~isempty(maxvalUsr))
                                        if (minvalUsr < OutputMin) || (maxvalUsr > OutputMax)
                                            DataObjAdded = ErrorforValueWithinRange(added_data_Obj,length_objNames,LoadingIndicator);
                                        end
                                    end

                                case 'int32' 
                                    OutputMin=((int32Min * slopeUsr) + str2num(added_data_Obj(length_objNames).Offset));
                                    OutputMax=((int32Max * slopeUsr) + str2num(added_data_Obj(length_objNames).Offset));
                                    if (~isempty(minvalUsr)) && (~isempty(maxvalUsr))
                                        if (minvalUsr < OutputMin) || (maxvalUsr > OutputMax)
                                            DataObjAdded = ErrorforValueWithinRange(added_data_Obj,length_objNames,LoadingIndicator);
                                        end
                                    end

                                case 'uint32'   
                                    OutputMin=((uint32Min * slopeUsr) + str2num(added_data_Obj(length_objNames).Offset));
                                    OutputMax=((uint32Max * slopeUsr) + str2num(added_data_Obj(length_objNames).Offset));
                                    if (~isempty(minvalUsr)) && (~isempty(maxvalUsr))
                                        if (minvalUsr < OutputMin) || (maxvalUsr > OutputMax)
                                            DataObjAdded = ErrorforValueWithinRange(added_data_Obj,length_objNames,LoadingIndicator);
                                        end
                                    end
                            end
                        end
                    end 
                end
            end
            
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            if strcmp(added_data_Obj(length_objNames).slope,'1') && strcmp(added_data_Obj(length_objNames).Offset,'0')
                add_simulinlk_signal_obj.DataType = added_data_Obj(length_objNames).Basetype;
            elseif strcmp(added_data_Obj(length_objNames).Offset,'0')&& mod(frsactionLUsr,1)==0
                add_simulinlk_signal_obj.DataType = strcat('fixdt','(',intbit,',',string(Bitsize),',',string(frsactionL),')');
            else
                add_simulinlk_signal_obj.DataType = strcat('fixdt','(',intbit,',',string(Bitsize),',',string(slope),',',string(offset),')');           
            end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
            if (strcmp(added_data_Obj(length_objNames).Min,"") || strcmp(added_data_Obj(length_objNames).Max,""))
                add_simulinlk_signal_obj.Min = [];
                add_simulinlk_signal_obj.Max = [];
            else
                if ~isequal(str2num(added_data_Obj(length_objNames).Min),Inf)
                    add_simulinlk_signal_obj.Min = str2num(added_data_Obj(length_objNames).Min); %store 'Min' value of data object
                end
                if ~isequal(str2num(added_data_Obj(length_objNames).Max),Inf)
                    add_simulinlk_signal_obj.Max = str2num(added_data_Obj(length_objNames).Max); %store 'Max' value of data object
                end
            end

            add_simulinlk_signal_obj.Unit = added_data_Obj(length_objNames).Unit;                                            %store 'Unit' value of data object
            add_simulinlk_signal_obj.objectType = added_data_Obj(length_objNames).category;                                  %store 'category' of data object 
            add_simulinlk_signal_obj.Description = added_data_Obj(length_objNames).Description;                              %store 'Description' of data object 

            if ~isempty(DataObjAdded)
                SendData=DataObjAdded;
                close(LoadingIndicator) 
                return;
            end

            %Check wheather to update or add Dataoject
            if addDataEntry == 1
                addEntry(dDataSectObj,new_data_object,add_simulinlk_signal_obj);                                             %add data in sldd
            else
                setValue(entryObj,add_simulinlk_signal_obj)
            end
            saveChanges(myDictionaryObj)
            waitbar(length_objNames/length(added_data_Obj),LoadingIndicator,sprintf(' %1.0f%% Completed',(length_objNames/length(added_data_Obj))*100))
            clearvars inp_data_v Dimesnion_for_val add_simulinlk_signal_obj dataObject_Name  ;
        else
            SendData = DataMsg;
            close(LoadingIndicator) 
            return;
        end
    else
        Data1(1,1) = string(num2str(111));
        Data1(1,2) = string(added_data_Obj(length_objNames).category);
    	Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
        Data1(1,4) = 'Selected category is not present in Excel File';
        SendData = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'} );
        return;
    end
end
close(LoadingIndicator) 
messageCode = 501;
SendData = table(messageCode);
end

function DataObjAdded = ErrorforValueWithinRange(added_data_Obj,length_objNames,~)
	Data1(1,1) = string(num2str(111));
	Data1(1,2) = string(added_data_Obj(length_objNames).category);
	Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
	Data1(1,4) = 'Min/Max Value must be within the range of selected basetype';
	DataObjAdded = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'} );
	return;
end

function inp_data_value = Value(added_data_Obj,Dimesnion_for_val,length_objNames)
    if ~(Dimesnion_for_val==-1)          %if 'Value' is not empty                    
        inp_data_value = str2num(added_data_Obj(length_objNames).Value);  %store the 'Value' of data object
        SizeofValue=size(inp_data_value);
        DimensionOfValue=char(strcat('[',string(SizeofValue(1)),',',string(SizeofValue(2)),']'));
        if ~(strcmp(added_data_Obj(length_objNames).category,'Map'))
            if ~strcmp(DimensionOfValue,added_data_Obj(length_objNames).Dimensions)
                Data1(1,1) = string(num2str(111));
                Data1(1,2) = string(added_data_Obj(length_objNames).category);
                Data1(1,3) = string(added_data_Obj(length_objNames).Name);
                Data1(1,4) = 'Multiple rows are not allowed for this category';
                SendData = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'});
                close(LoadingIndicator)
                return;
            end
        else 
            if ~strcmp(DimensionOfValue,added_data_Obj(length_objNames).Dimensions) %If Map category is there then do multiplication of Dimension received from java as well as Matlab and then compare it
                MultiplicationOfMatlabDimension=SizeofValue(1)*SizeofValue(2);
                StoreJavaDimension=str2num(added_data_Obj(length_objNames).Dimensions);
                MultiplicationOfJavaDimension=StoreJavaDimension(1)*StoreJavaDimension(2);
                if ~isequal(MultiplicationOfMatlabDimension,MultiplicationOfJavaDimension)
                    Data1(1,1) = string(num2str(111));
                    Data1(1,2) = string(added_data_Obj(length_objNames).category);
                    Data1(1,3) = string(added_data_Obj(length_objNames).Name);
                    Data1(1,4) = 'Enter same number of column in each row and press tab after entering Value field';
                    SendData = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'});
                    close(LoadingIndicator)
                    return;
                end
            end
        end
        inp_data_value = reshape(inp_data_value,[Dimesnion_for_val(1),Dimesnion_for_val(2)]); %reshape array
        if strcmp(added_data_Obj(length_objNames).category,"Map")
            inp_data_value = reshape(inp_data_value,[Dimesnion_for_val(2),Dimesnion_for_val(1)]);
            inp_data_value = inp_data_value';
        end
    else
        inp_data_value = 0;                                      %else store 0
    end
end