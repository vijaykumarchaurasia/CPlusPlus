%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :GetConfigurationData
% MAIN PURPOSE     :Function is used to fetch configuration data from program specific configuration excel file sheet.  
% INPUT(S)         :1.EntryName
% OUTPUT           :1.messageCode = 505 OR
%                   2.No sheet found in excel, send errorCode = 1005,  
%                     Program specific sheet is not present in excel, send errorCode = 1006,
%                     Excel file is empty or error while reading excel, send errorCode = 1007,
% DATE OF CREATION :12th August 2021
% REVESION NO      :1.2
% STATUS           :Rev. 1.1: Function has been written to add program specific variable entry in SLDD and
%                   and read corresponding excel sheet.
%                   Rev. 1.2: 1.Used sheetnames() command instead of xlsfinfo(),
%                             2.Removed if isempty(sheets) condition.
% FUNCTION CALL    :[DataInTable,Error] = ReadConfigData(ConfigFilePath,SheetName);
% AUTHOR           : Nitin Dahyalkar
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ConfigurationData,messageCode] = GetConfigurationData(ConfigFilePath,ProgramName)    

%Initialize variables
messageCode = [];
ConfigurationData = [];
SheetName = [];

%Get the name of sheets present in configuration excel file
sheets = sheetnames(ConfigFilePath);   %Rev.1.2
for Sheetnum = 1:length(sheets)
    if contains(sheets(Sheetnum),ProgramName) && contains(sheets(Sheetnum),"ObjectType") 
        SheetName = sheets(Sheetnum);
        break;
    end
end
if isempty(SheetName)
    %Sheet for program name is not found in excel
    messageCode = "1006";
    return;
else
    %Read configuration data
    [DataInTable,Error] = ReadConfigData(ConfigFilePath,SheetName); %Read excel data
    if ~isempty(Error) || isempty(DataInTable)
        %No data present in excel sheet or error while reading excel file
        messageCode = "1007";
        return;
    else
        ConfigurationData = DataInTable;
    end
end    
end
