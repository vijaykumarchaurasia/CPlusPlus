%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :SearchDataObject
% MAIN PURPOSE     :Function is used to search data object in project and in sldd. 
% INPUT(S)         :1.sldd_path=('C:\Users\shubhangim1\Music\E39_example')
%                   2.SearchInputs = struct('search_data','_C','match_case','true','exact_word','true')
% OUTPUT           :1."Wildcard search" is possible 
%                   2."Exact word" search is possible
%                   3."Match case" search is possible
% DATE OF CREATION :18th July 2019
% REVESION NO      :1.2
% STATUS           :Rev. 1.1: Tested to Search Dataobject in Project and in single sldd. 
%                   Rev. 1.2: num_Of_Entries evaluation is changed as program name entry is added in other data section.
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function SearchData = SearchDataObject(componentName,SearchInputs)
search_data = SearchInputs.search_data;
match_case = SearchInputs.match_case;
exact_word = SearchInputs.exact_word;

%To check user selected project or single component
if contains(componentName,'.sldd')
    componentName = extractBefore(componentName,'/Model');
end

%to add path in the Matlab directory
addpath(genpath(componentName))
DirPath = dir(fullfile(componentName,'**\*.sldd'));
fileList = strcat({DirPath.folder}, {'\'},{DirPath.name});

%Check for Top Sldd Component present if present generate details from it.
if nnz(contains(fileList,'top.sldd')>0)
    fileList = {'top.sldd'};
    [Alldata,modelData] = AllDataObjectName(fileList);  
    if ~isempty(modelData)
        SearchData=table(modelData);
        return;
    end
else
    [Alldata,modelData] = AllDataObjectName(fileList);   
    if ~isempty(modelData)
        SearchData=table(modelData);
        return;
    end
end

%Use data generated from all components on path
Objname=Alldata(:,1).DobjName;
Categoryname=Alldata(:,3).Category;
componentname=Alldata(:,2).component;
store = {};
%Check for Wildcard search or general serach
if contains(search_data,'*')
    wildcardSearch = regexpi(string(Objname), regexptranslate('wildcard', string(search_data)));
    cntr=1;
    for index2=1:length(wildcardSearch)
        if ~(isempty(wildcardSearch{index2}))
            store(cntr,3)=Objname(index2);
            store(cntr,2)=Categoryname(index2);
            store(cntr,1)=componentname(index2);
            cntr=cntr+1;
        end
    end
else
    if (isequal(match_case,1)&&(isequal(exact_word,0))) %Other searching criteria
            data = contains(Objname,search_data);             
            PosObjname=find(data);
            store(:,1)=componentname(PosObjname);
            store(:,3)= Objname(data);
            store(:,2)=Categoryname(PosObjname);            
    elseif (isequal(exact_word,1))
            [data,pos] = ismember(Objname,search_data);
            PosObjname=find(pos);
            store(:,3)= Objname(data);
            store(:,2)=Categoryname(PosObjname);
            store(:,1)=componentname(PosObjname);
    elseif (isequal(match_case,0)&&(isequal(exact_word,0)))
            data = contains(Objname,search_data,'IgnoreCase',true);  
            PosObjname=find(data);
            store(:,3)= Objname(data);
            store(:,2)=Categoryname(PosObjname);
            store(:,1)=componentname(PosObjname);
    end
end

%Required data object is not found will send error code: 115
if isempty(store)
    errorCode = "115";
    SearchData = (table(errorCode));
else
    SearchData=cell2table(cellstr(store),'VariableNames',{'component','category','Name'});
end
clearvars store; 
end

function [Alldata,modelData] = AllDataObjectName(fileList)
    localcntr = 1;
    modelData={};
    Alldata = cell2table(cell(0,3),'VariableNames',{'DobjName','component' ,'Category'}); 

    %Logic written for loading indicator
    if contains(fileList,'top.sldd')
        LoadingIndicator = waitbar(0,'Please wait while data is being fetched from Top.sldd','Name','Searching data object(s)...','WindowStyle', 'modal');
        frames = java.awt.Frame.getFrames();
        frames(end).setAlwaysOnTop(1);
        javaFrame = get(LoadingIndicator,'JavaFrame');
        ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
        javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));
    else
        LoadingIndicator = waitbar(0,'Please wait while data object is being searched','Name','Searching data object(s)...','WindowStyle', 'modal');
        frames = java.awt.Frame.getFrames();
        frames(end).setAlwaysOnTop(1);
        javaFrame = get(LoadingIndicator,'JavaFrame');
        ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
        javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));
        flag1 = 0;
    end
    %For loop is used to open single sldd at a time
    for DataCntrSlddFile=1:length(fileList)
        try
%             Simulink.data.dictionary.closeAll
            myDictionaryObj = Simulink.data.dictionary.open((char(fileList(DataCntrSlddFile))));
        catch Exception
              modelData={Exception.message};  %If any error throw while opening sldd    
              close(LoadingIndicator)
              return;
        end
        dDataSectObj = getSection(myDictionaryObj,'Design Data');
        allEntries = find(dDataSectObj);
        num_Of_Entries = length(allEntries);
        
    if contains(fileList,'top.sldd')
        waitbar(length(fileList),LoadingIndicator,sprintf('Please wait while data is being fetched from Top.sldd %1.0f%%',(length(fileList)*100)))  
        flag1 = 1;
        close(LoadingIndicator)
        LoadingIndicator = waitbar(0,'Please wait while data object is being searched','Name','Searching data object(s)...','WindowStyle', 'modal');
        frames = java.awt.Frame.getFrames();
        frames(end).setAlwaysOnTop(1);
        javaFrame = get(LoadingIndicator,'JavaFrame');
        ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
        javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));
    else
        waitbar(double(DataCntrSlddFile)/double(length(fileList)),LoadingIndicator,sprintf('Please wait while data object is being searched %1.0f%%',(double(DataCntrSlddFile)/double(length(fileList)))*100))
        frames = java.awt.Frame.getFrames();
        frames(end).setAlwaysOnTop(1);
    end
        % For loop is used to get attributes of data object
        for index1=1:num_Of_Entries
            Attribute=getValue(allEntries(index1));    
            if isobject(getValue(allEntries(index1)))     % check Data object is object type or normal variable
                if ~isstring(Attribute)
                    if ~ischar(Attribute)
                        FieldPrsnt = fields(getValue(allEntries(index1)));
                        objecttypepresent = ismember(FieldPrsnt,'objectType');
                        if nnz(objecttypepresent) > 0
                            AlldataObject_Name(1,localcntr) = string(allEntries(index1).Name);  
                            AlldataObject_Name(2,localcntr) = string(strtok((allEntries(index1).DataSource),'.'));
                            AlldataObject_Name(3,localcntr) = string(Attribute.objectType);
                        end
                    end
                end
            end
			localcntr = localcntr +1;
            if flag1
                waitbar(double(index1)/double(num_Of_Entries),LoadingIndicator,sprintf('Please wait while data object is being searched %1.0f%%',(double(index1)/double(num_Of_Entries))*100))
            end 
        end
        datainF = cellstr(AlldataObject_Name);
        Alldata = cell2table(datainF','VariableNames',{'DobjName','component' ,'Category'}); 
    end
    close(LoadingIndicator)
end

