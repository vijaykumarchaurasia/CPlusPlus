%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :ValidationOfSldd
% MAIN PURPOSE     :Function is used to validate each attribute of data
%                   object present in sldd
% INPUT(S)         :1.componentData=('D:/Navistar_SVN/E95_Projects/398_funde_chwlp/ChassisControl/chwlp/Model/chwlp.sldd,C:/Users/nitind6/AppData/Roaming/MathWorks/MATLAB Add-Ons/Toolboxes/NAVISTAR MBD Toolbox(3)/MatlabScripts/DataDictionaryTool/ConfigObjectType.xlsx,E95')
% OUTPUT           :1.Data object validation successfully done will send "messageCode=441"
% DATE OF CREATION :4th Aug 2020
% REVESION NO      :1.2
% STATUS           :Rev. 1.1: Tested to validate attribute of data object(s) in sldd
%                   Rev. 1.2: 1)Tested to validate attribute of data objects(s) in sldd using configuration file instead of 
%                               hardcoding(SLDD-154).
%                             2)Conditions to check whether if any Cal, Axis, Curve or Map has parameter type other than AUTOSAR4.Parameter for E95 
%                             3)Added condition to check program name,if program name is E95 then custom storage class is not assigned.
%                               Added MemorySection attribute for AUTOSAR4.Parameter. 
% FUNCTION CALL    : [ConfigurationData,errorCode] = GetConfigurationData(ConfigFilePath,ProgramName)
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [SendData] = ValidationOfSldd(componentData,~)

%Spliting component path, ConfigFilePath and ProgramName from componentData
FilePaths = split(componentData,',');
componentName = FilePaths{1};
ConfigFilePath = FilePaths{2};
ProgramName = FilePaths{3};
%To check user selected project or single component
if contains(componentName,'.sldd')
    componentName = extractBefore(componentName,'/Model');
end
%To add path in the Matlab directory
addpath(genpath(componentName))
DirPath = dir(fullfile(componentName,'**\*.sldd'));
fileList = strcat({DirPath.folder}, {'\'},{DirPath.name});

%Calling GetConfigurationData function to read attributes defined in configuration excel file 
[ConfigurationData,errorCode] = GetConfigurationData(ConfigFilePath,ProgramName);
if strcmp(errorCode,"1006") || strcmp(errorCode,"1007") 
    SendData = table(errorCode);
    return;
end
%Category fields defined in configuration file
categorys = ConfigurationData.CategoryFields;

%Check for Top Sldd Component present if present generate details from it.
if nnz(contains(fileList,'top.sldd')>0)
    fileList = {'top.sldd'};
    %Implementation of LoadingIndicator
    LoadingIndicator1 = waitbar(0,'Please wait while opening top.sldd','Name','Validating components attribute...','windowstyle', 'modal');
    frames = java.awt.Frame.getFrames();
    frames(end).setAlwaysOnTop(1);
    javaFrame = get(LoadingIndicator1,'JavaFrame');
    ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
    javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));
elseif isequal(length(fileList),1)
    %Implementation of LoadingIndicator
    LoadingIndicator1 = waitbar(0,' 1% Completed','Name','Validating components attribute...','windowstyle', 'modal');
    frames = java.awt.Frame.getFrames();
    frames(end).setAlwaysOnTop(1);
    javaFrame = get(LoadingIndicator1,'JavaFrame');
    ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
    javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));
else
    %Implementation of LoadingIndicator
    LoadingIndicator1 = waitbar(0,' 1% Completed','Name','Validating components attribute...','windowstyle', 'modal');
    frames = java.awt.Frame.getFrames();
    frames(end).setAlwaysOnTop(1);
    javaFrame = get(LoadingIndicator1,'JavaFrame');
    ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
    javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));
end

for DataCntrSlddFile=1:length(fileList)
myDictionaryObj = Simulink.data.dictionary.open(char(fileList(DataCntrSlddFile)));
DesignDataSectionObject = getSection(myDictionaryObj,'Design Data');
AllEntries = find(DesignDataSectionObject);

%Check if any Cal, Axis, Curve or Map has parameter type other than AUTOSAR4.Parameter for E95 
%'_CA' for calibration array
pat = {'_C','_X','_Y','_T','_M','_CA'};
if isequal(ProgramName, 'E95')
    for DataIndex = 1 : length(AllEntries)
        DataObjName = AllEntries(DataIndex).Name;
        AttriInfo = getValue(AllEntries(DataIndex));
        ObjFields = fields(AttriInfo);
        ObjVar = nnz(ismember(ObjFields,'objectType'));
        if ObjVar == 1
            if (~isequal(class(AttriInfo),'AUTOSAR4.Parameter') && endsWith(DataObjName, pat))
                errorCode = 302;
                SendData = table(errorCode);
                close(LoadingIndicator1);
                return;
            end
        end
    end
end

%Loop is use to get data object name and respective category
for Entry=1:length(AllEntries)
    Attribute=getValue(AllEntries(Entry));     %Get attribute of data object
    if ~isnumeric(Attribute)&& ~ischar(Attribute)&&~isstring(Attribute)
        GetFields=fields(Attribute);               %Get fields of data object
        log_array = ismember(GetFields,'objectType'); %Check data object having object type
        varv = nnz(log_array);
        if varv==1
            DataObjectCategories=Attribute.objectType; %Get category of data object
            %Check if category of data object is present in categories defined in configuration file 
			if nnz(contains(categorys,DataObjectCategories))
                CategoryIndex = find(strcmp(categorys,DataObjectCategories)); %Get index of category in configuration file
                ObjectType = ConfigurationData.ObjectType{CategoryIndex};
                DataObjName=string(AllEntries(Entry).Name);%Get name of data object
                if contains(ObjectType,'Signal')
                    %%Complexity%%
				    Complexity_Signal = ConfigurationData.Complexity{CategoryIndex};
                    if ~strcmp(Attribute.Complexity,Complexity_Signal) 
                        entryObj = getEntry(DesignDataSectionObject,DataObjName); %Get data object entry from sldd            
                        Attribute = getValue(entryObj); %Get attributes of data object
                        Attribute.Complexity=Complexity_Signal;    %Assign 'auto' for Complexity attribute 
                        setValue(entryObj,Attribute)    %Set property to data object
                    end
                    %%DimensionsMode%%
				    DimensionsMode_Signal = ConfigurationData.DimensionsMode{CategoryIndex};
                    if ~strcmp(Attribute.DimensionsMode,DimensionsMode_Signal)      
                        entryObj = getEntry(DesignDataSectionObject,DataObjName);%Get data object entry from sldd       
                        Attribute = getValue(entryObj); %Get attributes of data object
                        Attribute.DimensionsMode=DimensionsMode_Signal;%Assign 'auto' for DimensionsMode attribute 
                        setValue(entryObj,Attribute)    %Set property to data object
                    end          
                    %%SampleTime%%
				    SampleTime_Signal = str2num(ConfigurationData.SampleTime{CategoryIndex});
                    if ~strcmp(string(Attribute.SampleTime),string(SampleTime_Signal))
                        entryObj = getEntry(DesignDataSectionObject,DataObjName);%Get data object entry from sldd           
                        Attribute = getValue(entryObj); %Get attributes of data object
                        Attribute.SampleTime=SampleTime_Signal;        %Assign value
                        setValue(entryObj,Attribute)    %Set value to data object
                    end
                    %%StorageClass%%
                    StorageClass_Signal = ConfigurationData.StorageClass{CategoryIndex};
                    if isequal(ProgramName, 'E95')
                        if ~strcmp(Attribute.StorageClass,StorageClass_Signal)
                            entryObj = getEntry(DesignDataSectionObject,DataObjName);%Get data object entry from sldd           
                            Attribute = getValue(entryObj);          %Get attributes of data object
                            Attribute.StorageClass = StorageClass_Signal; %Assign storage class in sldd
                            setValue(entryObj,Attribute)             %Set value to data object
                        end
                    else
                        CustomStorageClass_Signal = ConfigurationData.CustomStorageClass{CategoryIndex};
                        HeaderFile_Signal = ConfigurationData.HeaderFile{CategoryIndex};
                        if ~strcmp(Attribute.CoderInfo.StorageClass,StorageClass_Signal)
                            entryObj = getEntry(DesignDataSectionObject,DataObjName);%Get data object entry from sldd           
                            Attribute = getValue(entryObj);          %Get attributes of data object
                            Attribute.CoderInfo.StorageClass = StorageClass_Signal; %Assign storage class in sldd
                            if strcmp('Custom',ConfigurationData.StorageClass{CategoryIndex})
                                Attribute.CoderInfo.CustomStorageClass = CustomStorageClass_Signal;
                                if ~strcmp('NA',HeaderFile_Signal)
                                    Attribute.CoderInfo.CustomAttributes.HeaderFile = HeaderFile_Signal;
                                end
                            end
                            setValue(entryObj,Attribute)             %Set value to data object
                        end
                    end
                    %Condition for configuring AUTOSAR.Signal specific attributes
                    if contains(ObjectType, 'AUTOSAR')
                        %%SwCalibrationAccess%%
				        SwCalibrationAccess_Signal = ConfigurationData.SwCalibrationAccess{CategoryIndex};
                        if ~strcmp(Attribute.SwCalibrationAccess,SwCalibrationAccess_Signal)
                            entryObj = getEntry(DesignDataSectionObject,DataObjName);%Get data object entry from sldd             
                            Attribute.SwCalibrationAccess = SwCalibrationAccess_Signal; %Assign value
                            setValue(entryObj,Attribute) %Set value
                        end
                        %%DisplayFormat%%
                        if ~isequal(ProgramName, 'E95')
					        DisplayFormat_Signal = ConfigurationData.DisplayFormat{CategoryIndex};
                            if ~strcmp(Attribute.DisplayFormat,DisplayFormat_Signal)
                                entryObj = getEntry(DesignDataSectionObject,DataObjName);%Get data object entry from sldd             
                                Attribute.DisplayFormat = DisplayFormat_Signal;
                                setValue(entryObj,Attribute) %Set value
                            end
                        end
                    end
                else
                    if contains(ObjectType, 'Parameter')
                        %%Complexity%%
				        Complexity_Param = ConfigurationData.Complexity{CategoryIndex};
                        if ~strcmp(Attribute.Complexity,Complexity_Param)
                            entryObj = getEntry(DesignDataSectionObject,DataObjName);%Get data object entry from sldd             
                            Attribute = getValue(entryObj);%Get attributes of data object
                            Attribute.Complexity = Complexity_Param;%Assign value
                            setValue(entryObj,Attribute)%Set value
                        end
                        %%StorageClass%%
                        StorageClass_Param = ConfigurationData.StorageClass{CategoryIndex};
                        if isequal(ProgramName, 'E95')
                            if ~strcmp(Attribute.StorageClass,StorageClass_Param)
                                entryObj = getEntry(DesignDataSectionObject,DataObjName);%Get data object entry from sldd           
                                Attribute = getValue(entryObj);          %Get attributes of data object
                                Attribute.StorageClass = StorageClass_Param; %Assign storage class in sldd
                                setValue(entryObj,Attribute)             %Set value to data object
                            end
                            if isequal(class(Attribute),'AUTOSAR4.Parameter')
                                StorageClass_MemSec = ConfigurationData.MemorySection{CategoryIndex};
                                if ~strcmp(Attribute.CoderInfo.CustomAttributes.MemorySection,StorageClass_MemSec)
                                    entryObj = getEntry(DesignDataSectionObject,DataObjName);%Get data object entry from sldd           
                                    Attribute = getValue(entryObj);          %Get attributes of data object
                                    Attribute.CoderInfo.CustomAttributes.MemorySection = StorageClass_MemSec;
                                    setValue(entryObj,Attribute)             %Set value to data object
                                end
                            end
                        else
                            CustomStorageClass_Param = ConfigurationData.CustomStorageClass{CategoryIndex};
                            HeaderFile_Param = ConfigurationData.HeaderFile{CategoryIndex};
                            if ~strcmp(Attribute.CoderInfo.StorageClass,StorageClass_Param)
                                entryObj = getEntry(DesignDataSectionObject,DataObjName);%Get data object entry from sldd           
                                Attribute = getValue(entryObj);          %Get attributes of data object
                                Attribute.CoderInfo.StorageClass = StorageClass_Param; %Assign storage class in sldd
                                if strcmp('Custom',ConfigurationData.StorageClass{CategoryIndex})
                                    Attribute.CoderInfo.CustomStorageClass = CustomStorageClass_Param;
                                    if ~strcmp('NA',HeaderFile_Param)
                                        Attribute.CoderInfo.CustomAttributes.HeaderFile = HeaderFile_Param;
                                    end
                                end
                                setValue(entryObj,Attribute)             %Set value to data object
                            end
                        end
                        %Condition for configuring AUTOSAR.Parameter specific attributes
                        if contains(ObjectType, 'AUTOSAR')
                            %%SwCalibrationAccess%%
						    SwCalibrationAccess_Param = ConfigurationData.SwCalibrationAccess{CategoryIndex};
                            if ~strcmp(Attribute.SwCalibrationAccess,SwCalibrationAccess_Param)
                                entryObj = getEntry(DesignDataSectionObject,DataObjName);%Get data object entry from sldd             
                                Attribute.SwCalibrationAccess = SwCalibrationAccess_Param;%%Assign value                                                  
                                setValue(entryObj,Attribute)%Set value
                            end
                            %%DisplayFormat%%
						    if ~isequal(ProgramName,'E95')
                                DisplayFormat_Param = ConfigurationData.DisplayFormat{CategoryIndex};
                                if ~strcmp(Attribute.DisplayFormat,DisplayFormat_Param)
                                    entryObj = getEntry(DesignDataSectionObject,DataObjName);%Get data object entry from sldd             
                                    Attribute.DisplayFormat = DisplayFormat_Param;
                                    setValue(entryObj,Attribute)%Set value
                                end
                            end
                        end
                    end
                end
            end
        end
    end
    saveChanges(myDictionaryObj)
    if isequal(length(fileList),1)%For single component
        waitbar(Entry/length(AllEntries),LoadingIndicator1,sprintf('%1.0f%% Completed',(Entry/length(AllEntries))*100))
    end
end
if isequal(length(fileList),1)%For single component close loading indicator
    close(LoadingIndicator1);
end
if length(fileList)>1 %For project
    waitbar(DataCntrSlddFile/length(fileList),LoadingIndicator1,sprintf('%1.0f%% Completed',(DataCntrSlddFile/length(fileList))*100))
end
end
if length(fileList)>1%For project close loading indicator
    close(LoadingIndicator1);
end
messageCode = 441;
SendData = table(messageCode);