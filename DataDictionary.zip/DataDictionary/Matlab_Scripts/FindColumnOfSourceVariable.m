%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :FindColumnOfSourceVariable
% MAIN PURPOSE     :Function is used to find Alphabet of column header of Destination variable and its data type/offset/slop in excel sheet
% INPUT(S)         :1.StoreIndexOutputName='12'; (This number depends on column header present in excel sheet.The numbers written here in '' is just example)
%                   2.StoreIndexDataTypeName_Output='13';
%                   3.StoreIndexOffsetName_Output='14';
%                   4.StoreIndexSlopeName_Output='15';
%                   5.StoreIndexComponentName='16';
% OUTPUT           :1.Get Alphabet of respective column header
% DATE OF CREATION :30th April 2020
% REVESION NO      :-
% STATUS           :Function has been written to called in "ExcelAddDeleteQuery","ResolveUseThisObject"script 
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [ColumnSelect_SV,ColumnSelect_SV_DataType,ColumnSelect_SV_Offset,ColumnSelect_SV_slope,ColumnSelect_ModelName] = FindColumnOfSourceVariable(StoreIndexInputName,StoreIndexDataTypeName_Input,StoreIndexOffsetName_Input,StoreIndexSlopeName_Input,StoreIndexComponentName)
    Alphabet = 'A':'Z';
    if StoreIndexInputName > 26 %Source variable
        CheckForFirst = floor(StoreIndexInputName/26);
        CheckForCol = mod(StoreIndexInputName,26);
        ColumnSelect_SV = strcat(Alphabet(CheckForFirst),Alphabet(CheckForCol));
    else
        ColumnSelect_SV = Alphabet(StoreIndexInputName);
    end

    if StoreIndexDataTypeName_Input > 26 %Data type
        CheckForFirst = floor(StoreIndexDataTypeName_Input/26);
        CheckForCol = mod(StoreIndexDataTypeName_Input,26);
        ColumnSelect_SV_DataType = strcat(Alphabet(CheckForFirst),Alphabet(CheckForCol));
    else
        ColumnSelect_SV_DataType = Alphabet(StoreIndexDataTypeName_Input);
    end

    if StoreIndexOffsetName_Input > 26 %Offset
        CheckForFirst = floor(StoreIndexOffsetName_Input/26);
        CheckForCol = mod(StoreIndexOffsetName_Input,26);
        ColumnSelect_SV_Offset = strcat(Alphabet(CheckForFirst),Alphabet(CheckForCol));
    else
        ColumnSelect_SV_Offset = Alphabet(StoreIndexOffsetName_Input);
    end

    if StoreIndexSlopeName_Input > 26 %slope
        CheckForFirst = floor(StoreIndexSlopeName_Input/26);
        CheckForCol = mod(StoreIndexSlopeName_Input,26);
        ColumnSelect_SV_slope = strcat(Alphabet(CheckForFirst),Alphabet(CheckForCol));
    else
        ColumnSelect_SV_slope = Alphabet(StoreIndexSlopeName_Input);
    end

    if StoreIndexComponentName > 26 %Model name
        CheckForFirst = floor(StoreIndexComponentName/26);
        CheckForCol = mod(StoreIndexComponentName,26);
        ColumnSelect_ModelName = strcat(Alphabet(CheckForFirst),Alphabet(CheckForCol));
    else
        ColumnSelect_ModelName = Alphabet(StoreIndexComponentName);
    end
