%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :ResolveUseThisObject
% MAIN PURPOSE     :Function is used to replace the attributes of all input or output present in sldd with
%                   selected input or output data object in excel and vice versa.  
% INPUT(S)         :1.ExcelPath=(''C:\Users\shubhangim1\Music\E39_example\AirManagement\aserc\Model\aserc.sldd')
%                   2.received_data_Obj=struct('Name','CPPPP_distCruiseTrip','Min',0,'Max','1000','Description','Knob is at ON position','InitaiValue','500','category','Input')
% OUTPUT           :1.Replace the attributes of all input or output present in sldd with
%                     selected input or output data object in excel and vice versa.
%                   2.If single data object received from java will send error code:944
%                   3.Data Object replaced successfully will send message code: 945
%                   4.If received data object is not present in excel will
%                     send erroe code:907
%                   5.If excel sheet is open while running code will send
%                     error code: 921
%                   6.If column header not present in excel sheet will send following errorcode:
%                     �Source Variable� name not present in excel= errorCode:912(used as not valid excel sheet)
%                     'Destination Variable' name not present in excel= errorCode:913
% DATE OF CREATION :5th May 2020
% REVESION NO      :Rev.1.4
% STATUS           :Rev. 1.1: Tested for selected input or output data object's attributes of sldd get  
%                             replaced at every existing places in excel and vice versa.
%                        1.2: Tested for following column header not
%                             present in excel sheet:
%                             'DataType_Source Variable','DataType_Destination Variable','Offset_Source Variable',
%                             'Offset_Destination Variable','Slope_Source Variable','Slope_Destination Variable'
%                        1.3: num_Of_Entries evaluation is changed as program name entry is added in other data section.
%                        1.4: 1.xlsfinfo is replaced with sheetnames command. 
%                             2.xlswrite is replaced with common function WriteData() where writecell() writes data in excel file. 
%FUNCTION CALL     :1.[Code,StoreIndexInputName,StoreIndexOutputName,StoreIndexDataTypeName_Input,StoreIndexDataTypeName_Output,StoreIndexOffsetName_Input,StoreIndexOffsetName_Output,StoreIndexSlopeName_Input,StoreIndexSlopeName_Output,StoreIndexComponentName,StoreInputDataObject1,StoreOutputDataObject1,~,~,~,~,~,~,~]=ValidationOfExcel(received_data_Obj(length_objNames).Description);
%                   2.[ColumnSelect_SV,ColumnSelect_SV_DataType,ColumnSelect_SV_Offset,ColumnSelect_SV_slope,~] = FindColumnOfSourceVariable(StoreIndexInputName,StoreIndexDataTypeName_Input,StoreIndexOffsetName_Input,StoreIndexSlopeName_Input,StoreIndexComponentName);
%                   3.[ColumnSelect_DV,ColumnSelect_DV_DataType,ColumnSelect_DV_Offset,ColumnSelect_DV_slope,~] = FindColumnOfDestinationVariable(StoreIndexOutputName,StoreIndexDataTypeName_Output,StoreIndexOffsetName_Output,StoreIndexSlopeName_Output,StoreIndexComponentName);
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function outdata = ResolveUseThisObject(ExcelPath,received_data_Obj)
 categoryfields = {'Input','Output'};
%If single data object received from java will send error code:944
if length(received_data_Obj)==1
    errorCode = "944";
    outdata = table(errorCode);
    return;
else
    %Implementation of loading indicator
    LoadingIndicator = waitbar(0,'Please wait while replacing your selected data object','Name','Use this data object...','WindowStyle', 'modal');
    frames = java.awt.Frame.getFrames();
    frames(end).setAlwaysOnTop(1);
    javaFrame = get(LoadingIndicator,'JavaFrame');
    ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
    javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));
    Alphabet='A':'Z';
    %Loop to replace selected data object's attribute with others
	for length_objNames = 2:length(received_data_Obj)
	      if strcmp(received_data_Obj(1).warning,'Present in sldd') %Data object and attributes present in excel get replaced by attributes of sldd 

                %To find position of 'Source Variable', 'Destination Variable' and respective DataType/Offset/Slope from excel sheet
                %TXT is variable which contains all data inside the Excel/Test Vector file
                %Read ThirdS Row for Headings of Column
                [Code,StoreIndexInputName,StoreIndexOutputName,StoreIndexDataTypeName_Input,StoreIndexDataTypeName_Output,StoreIndexOffsetName_Input,StoreIndexOffsetName_Output,StoreIndexSlopeName_Input,StoreIndexSlopeName_Output,StoreIndexComponentName,StoreInputDataObject1,StoreOutputDataObject1,StoreDataType_Input1,StoreDataType_Output1,StoreOffset_Input1,StoreOffset_Output1,StoreSlope_Input1,StoreSlope_Output1,StoreComponentName1]=ValidationOfExcel(ExcelPath);
                 if ~strcmp(Code,"4000")
                     errorCode=Code;
                     outdata=table(errorCode);
                     close(LoadingIndicator);
                     return;
                 end
                 
                switch(received_data_Obj(1).category)
                    case  'Input'
                           cntr=1;
                           %Check received dat object is present in excel
                           %sheet
                           [DataObjFoundInExcel,~]=ismember(StoreInputDataObject1,received_data_Obj(2).Name);
                           %DataObj not present in excel
                           if ~nnz(DataObjFoundInExcel)
                               errorCode = "907";
                               outdata = table(errorCode);
                               close(LoadingIndicator);
                               return;
                           end
                           %Pre allocate memory
                            StorePositionOfDataObj1{1,length(DataObjFoundInExcel)} = [];
                            %Loop used to store exact position of data object in
                            %excel
                           for index=1:length(DataObjFoundInExcel)
                               if DataObjFoundInExcel(index)==1
                                   StorePositionOfDataObj1{cntr}=index;
                                   cntr=cntr+1;
                               end
                           end
                           %remove empty cell
                           StorePositionOfDataObj1 = StorePositionOfDataObj1(~cellfun('isempty', StorePositionOfDataObj1));
                           StorePositionOfDataObj = string(StorePositionOfDataObj1);
                           
                           %Find column of Source variable/data type/offset/slope
                           %in excel
                           [~,ColumnSelect_SV_DataType,ColumnSelect_SV_Offset,ColumnSelect_SV_slope,~] = FindColumnOfSourceVariable(StoreIndexInputName,StoreIndexDataTypeName_Input,StoreIndexOffsetName_Input,StoreIndexSlopeName_Input,StoreIndexComponentName);

                           %Get sheetname from excel
                           sheets = sheetnames(ExcelPath);
                           
                           %Replacing received data object's attribute(Basetype,Offset,slope) with attributes present excel
                            for indexIn=1:length(StorePositionOfDataObj)
                                xlRange_SV_DataType=strcat(ColumnSelect_SV_DataType,StorePositionOfDataObj(indexIn));
                                xlRange_SV_Offset=strcat(ColumnSelect_SV_Offset,StorePositionOfDataObj(indexIn));
                                xlRange_SV_slope=strcat(ColumnSelect_SV_slope,StorePositionOfDataObj(indexIn));
                                %Loop used to check xlrange contains alphabet
                                for indexAlphabet=1:length(Alphabet)
                                    if contains(char(xlRange_SV_DataType),Alphabet(indexAlphabet))%If column header 'DataType_Source Variable' is present in excel then only replace with received value
                                        message_SV_DataType = WriteData({received_data_Obj(1).Basetype},ExcelPath,sheets,xlRange_SV_DataType);
                                        if ~isempty(message_SV_DataType.message)
                                            if contains(message_SV_DataType.message,'may be open') %Excel sheet is open,close it and try again
                                               errorCode="921";
                                               outdata=table(errorCode);
                                               close(LoadingIndicator);
                                               return;
                                            end
                                        end
                                    end

                                    if contains(char(xlRange_SV_Offset),Alphabet(indexAlphabet))%If column header 'Offset_Source Variable' is present in excel then only replace with received value
                                        message_SV_Offset = WriteData({str2num(received_data_Obj(1).Offset)},ExcelPath,sheets,xlRange_SV_Offset);
                                        if ~isempty(message_SV_Offset.message)
                                            if contains(message_SV_Offset.message,'may be open') %Excel sheet is open,close it and try again
                                               errorCode="921";
                                               outdata=table(errorCode);
                                               close(LoadingIndicator);
                                               return;
                                            end
                                        end
                                    end

                                    if contains(char(xlRange_SV_slope),Alphabet(indexAlphabet))%If column header 'Slope_Source Variable' is present in excel then only replace with received value
                                        message_SV_slope = WriteData({str2num(received_data_Obj(1).slope)},ExcelPath,sheets,xlRange_SV_slope);
                                        if ~isempty(message_SV_slope.message)
                                            if contains(message_SV_slope.message,'may be open') %Excel sheet is open,close it and try again
                                               errorCode="921";
                                               outdata=table(errorCode);
                                               close(LoadingIndicator);
                                               return;
                                            end
                                        end
                                    end
                                end

                            end
                           
                    case  'Output'
                           cntr2=1;
                           Data4="";
                           [DataObjFoundInExcel,~]=ismember(StoreOutputDataObject1,received_data_Obj(length_objNames).Name);
                           %DataObj not present in excel
                            if ~nnz(DataObjFoundInExcel)
                                errorCode = "907";
                                outdata = table(errorCode);
                                close(LoadingIndicator);
                                return;
                            end
                           %Pre allocate memory
                            StorePositionOfDataObjOp{1,length(DataObjFoundInExcel)} = [];
                           %Loop used to store exact position of data object in
                           %excel
                           for index2=1:length(DataObjFoundInExcel)
                               if DataObjFoundInExcel(index2)==1
                                   StorePositionOfDataObjOp{cntr2}=index2;
                                   cntr2=cntr2+1;
                               end
                           end

                           %remove empty cell
                           StorePositionOfDataObjOp = StorePositionOfDataObjOp(~cellfun('isempty', StorePositionOfDataObjOp));
                           StorePositionOfDataObjOp1 = string(StorePositionOfDataObjOp);

                           %Find column of Destination variable/data type/offset/slope
                           %in excel
                           [~,ColumnSelect_DV_DataType,ColumnSelect_DV_Offset,ColumnSelect_DV_slope,~] = FindColumnOfDestinationVariable(StoreIndexOutputName,StoreIndexDataTypeName_Output,StoreIndexOffsetName_Output,StoreIndexSlopeName_Output,StoreIndexComponentName);

                            %Get sheetname from excel
                            sheets = sheetnames(ExcelPath);

                            %Replacing received data object's attribute(Basetype,Offset,slope) with attributes present excel
                            for indexOut=1:length(StorePositionOfDataObjOp1)
                                xlRange_DV_DataType=strcat(ColumnSelect_DV_DataType,StorePositionOfDataObjOp1(indexOut));
                                xlRange_DV_Offset=strcat(ColumnSelect_DV_Offset,StorePositionOfDataObjOp1(indexOut));
                                xlRange_DV_slope=strcat(ColumnSelect_DV_slope,StorePositionOfDataObjOp1(indexOut));
                                %Loop used to check xlrange contains alphabet
                                for indexAlphabet=1:length(Alphabet)
                                    if contains(char(xlRange_DV_DataType),Alphabet(indexAlphabet)) %If column header 'DataType_Destination Variable' is present in excel then only replace with received value
                                        message_DV_DataType = WriteData({received_data_Obj(1).Basetype},ExcelPath,sheets,xlRange_DV_DataType);
                                        if ~isempty(message_DV_DataType.message)
                                            if contains(message_DV_DataType.message,'may be open') %Excel sheet is open,close it and try again
                                               errorCode="921";
                                               outdata=table(errorCode);
                                               close(LoadingIndicator);
                                               return;
                                            end
                                        end
                                    end

                                    if contains(char(xlRange_DV_Offset),Alphabet(indexAlphabet))%If column header 'Offset_Destination Variable' is present in excel then only replace with received value
                                        message_DV_Offset = WriteData({str2num(received_data_Obj(1).Offset)},ExcelPath,sheets,xlRange_DV_Offset);
                                        if ~isempty(message_DV_Offset.message)
                                            if contains(message_DV_Offset.message,'may be open') %Excel sheet is open,close it and try again
                                               errorCode="921";
                                               outdata=table(errorCode);
                                               close(LoadingIndicator);
                                               return;
                                            end
                                        end
                                    end

                                    if contains(char(xlRange_DV_slope),Alphabet(indexAlphabet))%If column header 'Slope_Destination Variable' is present in excel then only replace with received value
                                        message_DV_slope = WriteData({str2num(received_data_Obj(1).slope)},ExcelPath,sheets,xlRange_DV_slope);
                                        if ~isempty(message_DV_slope.message)
                                            if contains(message_DV_slope.message,'may be open') %Excel sheet is open,close it and try again
                                               errorCode="921";
                                               outdata=table(errorCode);
                                               close(LoadingIndicator);
                                               return;
                                            end
                                        end
                                    end
                                end

                            end
                end
          else
                %Data object and attributes present in sldd get replaced by attributes(Basetype,offset,slope) of excel 
                sldd_name =  received_data_Obj(1).component;
%                 Simulink.data.dictionary.closeAll
                myDictionaryObj =Simulink.data.dictionary.open(sldd_name);        %open sldd
                dDataSectObj = getSection(myDictionaryObj,'Design Data');         %get design data from sldd    
                allEntries = find(dDataSectObj);
                num_Of_Entries = length(allEntries);
                for index=1:num_Of_Entries
                    dataObject_Name{index}=allEntries(index).Name;
                    attributes{index}=getValue(allEntries(index));       
                end
                new_data_object=received_data_Obj(length_objNames).Name;              %store 'Name' of data object 
                [dObjPrsnt, ~] = ismember(new_data_object,dataObject_Name);

                if (nnz(dObjPrsnt)>0)
                    entryObj = getEntry(dDataSectObj,new_data_object);            
                    add_simulinlk_signal_obj = getValue(entryObj);
                end


                %Implementation for DataType as Compu Method
                Basetype = received_data_Obj(1).Basetype;
                offset = received_data_Obj(1).Offset;
                slope = str2double(received_data_Obj(1).slope);
                if isempty(Basetype)||isempty(offset)||isempty(slope) %If data type is not received from java, assign default value for basetype/slope/offset
                        Basetype="single";
                        offset='0';
                        slope='1';
                elseif strcmp(Basetype,'single')
                        Basetype="single";
                        offset='0';
                        slope='1';
                elseif strcmp(Basetype,'boolean')
                        Basetype="boolean";
                        offset='0';
                        slope='1';
                else
                    offset = received_data_Obj(1).Offset;
                    slope = str2double(received_data_Obj(1).slope);
                end
                expressionsep = '[a-z,A-Z]';
                DataTypIdx = regexp(Basetype,expressionsep,'split');
                Bitsize = str2num(char(DataTypIdx(end)));
                expressionsignbit = 'u';
                signbitchk = regexp(Basetype,expressionsignbit,'match');
                if isempty(signbitchk)
                    intbit = '1' ;   
                else
                    intbit = '0' ;  
                end
                
                if isnumeric(slope)
                    frsactionL = log(1/slope)/log(2);
                end

                if strcmp(slope,'1') && strcmp(offset,'0')
                    add_simulinlk_signal_obj.DataType = Basetype;
                elseif strcmp(received_data_Obj(1).Offset,'0')&& mod(frsactionL,1)==0
                    add_simulinlk_signal_obj.DataType = strcat('fixdt','(',intbit,',',string(Bitsize),',',string(frsactionL),')');
                else
                    add_simulinlk_signal_obj.DataType = strcat('fixdt','(',intbit,',',string(Bitsize),',',string(slope),',',string(offset),')');           
                end
                %end of Compu Method Details      

                add_simulinlk_signal_obj.Dimensions = str2num(received_data_Obj(1).Dimensions);
                add_simulinlk_signal_obj.Min = str2num(received_data_Obj(1).Min);                                  
                add_simulinlk_signal_obj.Max = str2num(received_data_Obj(1).Max);                              
                add_simulinlk_signal_obj.Unit = received_data_Obj(1).Unit;   
                add_simulinlk_signal_obj.Description = received_data_Obj(1).Description;                                    

                %For SwCalibrationAccess and DisplayFormat attributes of Autosar signal and parameter
                if nnz(contains(categoryfields(1:2),add_simulinlk_signal_obj.objectType))
                    add_simulinlk_signal_obj.SwCalibrationAccess = received_data_Obj(1).SwCalibrationAccess;                                                  
                    add_simulinlk_signal_obj.DisplayFormat = received_data_Obj(1).DisplayFormat;         
                end
                % DimensionsMode and Complexity attributes for Signals 
                if nnz(contains(categoryfields(1:2),add_simulinlk_signal_obj.objectType))
                    add_simulinlk_signal_obj.DimensionsMode = received_data_Obj(1).DimensionsMode;                %else assign existing value to DimensionsMode
                    add_simulinlk_signal_obj.Complexity = received_data_Obj(1).Complexity;                %store 'Complexity' of data object as per from User      
                    add_simulinlk_signal_obj.InitialValue = received_data_Obj(1).InitialValue;   
                end
                
                %Storage class implementation
                add_simulinlk_signal_obj.CoderInfo.StorageClass=received_data_Obj(1).Coderinfo;%Set StorageClass as 'Auto'


                setValue(entryObj,add_simulinlk_signal_obj)
                waitbar(length_objNames/length(received_data_Obj),LoadingIndicator,sprintf('Please wait while replacing your selected data object %1.0f%%',(length_objNames/(length(received_data_Obj)))*100))
                clearvars inp_data_v Dimesnion_for_val add_simulinlk_signal_obj ;

                saveChanges(myDictionaryObj)%save data dictionary
       end
	end

end
    close(LoadingIndicator);
    messageCode = "945";
    outdata = table(messageCode);%Data Object replaced successfully will send message code: 945
end

function ErrorCode = WriteData(received_data,FilePath,sheets,xlRange)
    ErrorCode.message = [];
    try
        writecell(received_data,FilePath,'Sheet',char(sheets(1)),'Range',char(xlRange));%Replace data received from java
    catch Exception
        ErrorCode = Exception;
    end
end

