%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :Build_JSON_Response
% MAIN PURPOSE     :Function is used to convert table data in JSON format.
% INPUT(S)         :1.queryName=('AddDataObject');
%                   2.inp_table_data: Output received from 'AddDataObject'
%                     in table format
% OUTPUT           :1.Convert received data into JSON format
% DATE OF CREATION :7th May 2019
% REVESION NO      :1.1
% STATUS           :Rev. 1.1: Tested to convert table data into JSON format
%                             (Applicable for received queryName)
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [json_data] = Build_JSON_Response(~,inp_table_data)
    json_data=jsonencode(inp_table_data); %Covert received data into JSON format
end