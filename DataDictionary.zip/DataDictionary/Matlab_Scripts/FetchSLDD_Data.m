%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :FetchSLDD_Data
% MAIN PURPOSE     :Function is used to fetch data objects and respective attributes from sldd 
%                   and segregate it based on cayegory.
% INPUT(S)         :1.sldd_path=('C:\Users\shubhangim1\Music\Fresh_Project\E39_example\AirManagement\aserc\Model\aserc.sldd')
% OUTPUT           :1.Display all the component�s data objects of the each category type in a table OR
%                   2.If sldd is empty, will send "errorCode:101" 
%                   3.If any of cal, map, axis or curve has parameter type
%                   other than AUTOSAR4.Parameter for E95 then send errorCode = 301 
%                   4.If MemorySection column is not present in
%                   ConfigObjectType excel sheet for E95,will send errorCode = 300 
% DATE OF CREATION :5th May 2019
% REVESION NO      :1.6
% STATUS           :Rev. 1.1: Tested to fetch data objects and respective attributes from sldd 
%                             and segregate it based on cetegory.
%                        1.2: Loading indicator has been implemented.
%                        1.3: Removed unwanted variables and if else loop
%                        1.4: Changes for configurable in attribute definition
%                        1.5: Category wise switch case for fetching data entries is replaced with condition of object type. 
%                             num_Of_Entries evaluation is changed as program name entry is added in other data section.
%                        1.6: (22 Sep 2021)
%                             Added GetConfigurationData function call to get configuration data from excel.
%                        1.7: 10 Mar 2022
%                             1) Added condition to check if parameter type of calibration,axis, map or curve is different than AUTOSAR4.Parameter for E95 
%                             2) Added MemorySection attribute for AUTOSAR4.Parameter type, added condition of E95 progrzm for storage class attribute(SLDD-157), converted else-if condition to elseif for checking parameter type in switch case    
%                             3) Added condition to check whether MemorySection column is present in ConfigObjectType excel sheet for E95 
% FUNCTION CALL    :[ConfigurationData,errorCode] = GetConfigurationData(ConfigFilePath,ProgramName);
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [json_data] = FetchSLDD_Data(componentData,~)
    
    %Extract sldd_path, ConfigFilePath and ProgramName from componentData
    FilePaths = split(componentData,',');
    sldd_path = FilePaths{1};
    ConfigFilePath = FilePaths{2};
    ProgramName = FilePaths{3};
    %Get configuration data from excel file in table form
    [ConfigurationData,errorCode] = GetConfigurationData(ConfigFilePath,ProgramName);
    if strcmp(errorCode,"1006") || strcmp(errorCode,"1007") 
        json_data = table(errorCode);
        return;
    end
    
    %Open sldd and get entries inside it If sldd is blank give error
    try
        myDictionaryObj = Simulink.data.dictionary.open(sldd_path);
    catch Exception
        modelData={Exception.message};  %If any error throw while opening sldd    
        json_data = table(modelData);
        return;
    end
    
    dDataSectObj = getSection(myDictionaryObj,'Design Data');
    allEntries = find(dDataSectObj);
    num_Of_Entries = length(allEntries);
    %Check whether parameter type of Cal, Axis, Curve and Map is AUTOSAR4.Parameter for E95 
    pat = {'_C','_X','_Y','_T','_M','_CA'};
    %Check if any Cal, Axis, Curve or Map has parameter type other than AUTOSAR4.Parameter for E95 
    if isequal(ProgramName, 'E95')
        %Check whether MemorySection columen is present in ConfigObjectType excel sheet for E95
        ConfigFileFields = fields(ConfigurationData);
        if ~nnz(strcmp(ConfigFileFields,'MemorySection'))
            errorCode = 300;
            json_data = table(errorCode);
            return;
        end
        for DataIndex = 1 : num_Of_Entries
            DataObjName = allEntries(DataIndex).Name;
            AttriInfo = getValue(allEntries(DataIndex));
            ObjFields = fields(AttriInfo);
            ObjVar = nnz(ismember(ObjFields,'objectType'));
            %Check whether data object has objectType property or not
            if ObjVar == 1
                if (endsWith(DataObjName, pat) && ~isequal(class(AttriInfo), 'AUTOSAR4.Parameter'))
                    errorCode = 301;
                    json_data = table(errorCode);
                    return;
                end
            end
        end
    end
    %Category fields(Rev.1.6)
    categorys = ConfigurationData.CategoryFields;
	%Function to get required data like categories attributes
    if num_Of_Entries > 0
       [attributes,maxDimensionInSldd] = extractSLDDdata(allEntries,num_Of_Entries);    %Function call
       if isempty(maxDimensionInSldd)%If max dimension is zero then assigning 111 to it
           maxDimensionInSldd=111;
       end
    else
        maxDimensionInSldd=1;
    end
	num_category_cntr=1;
	%Logic written for loading indicator
	LoadingIndicator = waitbar(0,' 1% Completed','Name','Fetching component data...','windowstyle', 'modal');
	frames = java.awt.Frame.getFrames();
	frames(end).setAlwaysOnTop(1);
	javaFrame = get(LoadingIndicator,'JavaFrame');
	ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
	javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));
    
	attri_Info = {};
	while(num_category_cntr<(length(categorys))+1) 
		attri_Info_cntr = 1;
		lcl_cntr=1;
		%Fetch data object and its attributes
		for sldd_entry_data_cntr=1:num_Of_Entries
			if isobject(getValue(allEntries(sldd_entry_data_cntr))) && ~isstring(getValue(allEntries(sldd_entry_data_cntr))) && ~ischar(getValue(allEntries(sldd_entry_data_cntr)))          % check Data object is object type or normal variable
				FieldPrsntV = fields(getValue(allEntries(sldd_entry_data_cntr)));
				objecttypepresent = ismember(FieldPrsntV,'objectType');
				if nnz(objecttypepresent) > 0
					if strmatch((attributes{sldd_entry_data_cntr}.objectType),(categorys{num_category_cntr}),'exact')       
						attri_Info{attri_Info_cntr}=attributes{sldd_entry_data_cntr};       %Storing attributes information
						attri_Info_cntr= attri_Info_cntr+1;           
					end
					all_Entries=getValue(allEntries(sldd_entry_data_cntr));                 %Get attributes of data object
					if strmatch(all_Entries.objectType,categorys{num_category_cntr},'exact')%Matching string to get catagory of each data object
						dataObject_Name1{lcl_cntr}=allEntries(sldd_entry_data_cntr).Name;   %storing data object names
						attri_fields = fieldnames(all_Entries);                             %storing attribute names of all entries in fields
						lcl_cntr = lcl_cntr +1;                                             %counter increment
					end
				end
			end        
		end
		%Storing default attributes for non existing category in sldd
		attri_Info_cntr2 = 1;
		if isempty(attri_Info)
            %Check if program name is E95
            if isequal(ProgramName, 'E95')
			    BlankObj{1}.StorageClass = "";
            else
                BlankObj{1}.CoderInfo.StorageClass = "";
            end
			BlankObj{1}.DataType = "";
			BlankObj{1}.Value= "0";
			BlankObj{1}.Min= "";
			BlankObj{1}.Max= "";
			BlankObj{1}.Unit= "";
			BlankObj{1}.Dimensions= '[1,1]';
			BlankObj{1}.Complexity= "";
			BlankObj{1}.Description= "";
			BlankObj{1}.InitialValue= "";
			BlankObj{1}.SamplingMode= "";
			BlankObj{1}.SampleTime= "";
			BlankObj{1}.DimensionsMode= "";
			attri_Info(attri_Info_cntr2,:) = BlankObj; 
			store_categories(attri_Info_cntr2,:) = BlankObj;            %Store attributes information
			name_categories(attri_Info_cntr2,:) = "";                   %Store data object names
		else
			store_categories(attri_Info_cntr2,:) = attri_Info;          %Store attributes information
			name_categories(attri_Info_cntr2,:) =dataObject_Name1;      %Store data object names
		end

	   %Loop for catagory wise data objects information extraction
		for attri = 1:length(store_categories)                           
			store_attribute =store_categories(attri_Info_cntr2,:);      %Store attributes information
			name_of_attribute = name_categories(attri_Info_cntr2,:);    %Store attribute name
			Name(attri,1)=string(name_of_attribute(attri));             %Get all attribute names
			Object_Type = ConfigurationData.ObjectType{num_category_cntr};
            %Can check categories present in Excel file with the respective
            %extracted category data and then as per the data object
            %evaluate attributes
            if contains(Object_Type,'Signal')  
                signal = 1;
                parameter = 0;
                curv_cat = 0;
                switch(Object_Type)
                    case 'AUTOSAR.Signal'
                        %Implementation of SwCalibrationAccess and DisplayFormat
                        if ~(name_categories{attri}=="")
                            SwCalibrationAccess(attri,1) = string(store_attribute{attri}.SwCalibrationAccess);
                            DisplayFormat(attri,1)= string(store_attribute{attri}.DisplayFormat);
                        else
                            SwCalibrationAccess(attri,1) = "";	
                            DisplayFormat(attri,1) = "";
                        end
                        MemorySection(attri,1) = ""; %Implementation of memory section
                    case 'Simulink.Signal'
                        SwCalibrationAccess(attri,1) = "Null";	
                        DisplayFormat(attri,1) = "Null";
                        MemorySection(attri,1) = ""; %Implementation of memory section
                end
            elseif contains(Object_Type,'Parameter')
                signal = 0;
				parameter = 1;
                if strmatch(categorys{num_category_cntr},'Curve')
                    curv_cat = 1;
                else
                    curv_cat = 0;
                end
                switch(Object_Type)
                    case 'AUTOSAR.Parameter'
                        %Implementation of SwCalibrationAccess and DisplayFormat
                        if ~(name_categories=="")
                            SwCalibrationAccess(attri,1) = string(store_attribute{attri}.SwCalibrationAccess);
                            DisplayFormat(attri,1)= string(store_attribute{attri}.DisplayFormat);
                        else
                            SwCalibrationAccess(attri,1) = "";	
                            DisplayFormat(attri,1) = "";
                        end
                        MemorySection(attri,1) = ""; %Implementation of memory section
                    case 'AUTOSAR4.Parameter'
                        %Implementation of SwCalibrationAccess and DisplayFormat
                        if ~(name_categories=="")
                            SwCalibrationAccess(attri,1) = string(store_attribute{attri}.SwCalibrationAccess);
                            DisplayFormat(attri,1)= string(store_attribute{attri}.DisplayFormat);
                            MemorySection(attri,1) = string(store_attribute{attri}.CoderInfo.CustomAttributes.MemorySection); %Implementation of memory section
                        else
                            SwCalibrationAccess(attri,1) = "";	
                            DisplayFormat(attri,1) = "";
                            MemorySection(attri,1) = ""; %Implementation of memory section
                        end
                    case 'Simulink.Parameter'
                        SwCalibrationAccess(attri,1) = "Null";	
                        DisplayFormat(attri,1) = "Null";
                        MemorySection(attri,1) = ""; %Implementation of memory section
                end
            end
            
			if signal == 1 && parameter == 0
				Value(attri,:)= 'Null';
				maxDimension(attri,:) = store_attribute{attri}.Dimensions;
				if isempty(store_attribute{attri}.InitialValue)
						InitialValue(attri,1)="Null";
				else
					pattern = ["1","2","3","4","5","6","7","8","9","0"];
					vart = contains(store_attribute{attri}.InitialValue,pattern);
					if vart
						if (length(str2num(store_attribute{attri}.InitialValue))==1)
							if contains(store_attribute{attri}.InitialValue,'[')
								InitialValue(attri,:)=string(store_attribute{attri}.InitialValue);	
							else
								InitialValue(attri,:)=string(strcat('[',store_attribute{attri}.InitialValue,']'));
							end
						else	
							InitialValue(attri,:)=string(store_attribute{attri}.InitialValue);
						end
					else	
						InitialValue(attri,:)=string(store_attribute{attri}.InitialValue);					
					end					
				end
				SamplingMode(attri,1)=string(store_attribute{attri}.SamplingMode);  
				SampleTime(attri,1)=string(store_attribute{attri}.SampleTime);      
				DimensionsMode(attri,1)=string(store_attribute{attri}.DimensionsMode); 
			elseif signal == 0 && parameter == 1
				for variable_max_len = 1:length(store_categories)
					if ischar(store_attribute{variable_max_len}.Dimensions)
						to_chk_max_length(variable_max_len,:) = str2num(store_attribute{variable_max_len}.Dimensions);
						store_attribute{variable_max_len}.Dimensions =  str2num(store_attribute{variable_max_len}.Dimensions);
					else
						to_chk_max_length(variable_max_len,:) = store_attribute{variable_max_len}.Dimensions;  %Checking length of dimension 
					end
				   max_dimensions =maxDimensionInSldd;
				end
				maxDimension(attri,:) = maxDimensionInSldd;	
				dim_of_data_obj = store_attribute{attri}.Dimensions;
				if isequal(dim_of_data_obj, -1)                         %If value of 'Dimensions' is -1
					dim_of_data_obj = [1 1];                            %Store[1 1] value to 'Dimensions'
					max_dimensions = 1; 
				end
				if curv_cat == 0
					mat_max_dim = zeros(max_dimensions);
				elseif curv_cat ==1
					mat_max_dim = zeros(1,max_dimensions);
				end
				if ~isempty(store_attribute{attri}.Value)    %If 'Value' is not empty
					store_val = store_attribute{attri}.Value;%Store value assigned in sldd
				else
					 store_val =('Null');                    %Else store 0
				end
				mat_max_dim(1:dim_of_data_obj(1),1:dim_of_data_obj(2)) = store_val;
				if curv_cat ==1
					Value(attri,:)=mat_max_dim;  
				else
					data_len=1;
					for len_d=1:max_dimensions
						Value(attri,data_len:(data_len+max_dimensions-1))=mat_max_dim(len_d,:);
						data_len=data_len+max_dimensions;
					end
				end
				
				SamplingMode(attri,1) = "Null";
				InitialValue(attri,1) = "Null";                    
				if strcmp(categorys{num_category_cntr},'Input')||strcmp(categorys{num_category_cntr},'Output')||strcmp(categorys{num_category_cntr},'Local')||strcmp(categorys{num_category_cntr},'Nvm')
					SampleTime(attri,1)= "-1";
				else
					SampleTime(attri,1)= "Null";
				end
				DimensionsMode(attri,1) = "Null";%change
			end
			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			%Common attributes which are present in current project for every
			%compnent and data objects
			DataType=string(store_attribute{attri}.DataType);
			[BasetypeO, OffsetO, slopeO] = SlddtoUI_AbstractDataType(DataType);
			Basetype(attri,1) = string(BasetypeO);

			if ~isempty((OffsetO)) 
				Offset(attri,1) = (OffsetO);                     
			else
				Offset(attri,1) = "";
			end

			if ~isempty((slopeO))
				slope(attri,1) = (slopeO);                    
			else
				slope(attri,1) = "";
			end

			if ~isempty((store_attribute{attri}.Min)) 
				Min(attri,1)=(store_attribute{attri}.Min);                      %get 'Min'
			else
				Min(attri,1) = 1.111111111111111e+104;
			end

			if ~isempty((store_attribute{attri}.Max))
				Max(attri,1)=(store_attribute{attri}.Max);                      %get 'Max' 
			else
				Max(attri,1) = 1.111111111111111e+104;
			end
			
			Description(attri,1)=string(store_attribute{attri}.Description);          %get Description  
			Unit(attri,1)=string(store_attribute{attri}.Unit);                        %get 'Unit' 
			Complexity(attri,1)=string(store_attribute{attri}.Complexity);            %get 'Complexity'   
			Dimensions(attri,:)=string(store_attribute{attri}.Dimensions);            %get 'Dimensions'
            if isequal(ProgramName, 'E95')
                Coderinfo(attri,1)=string(store_attribute{attri}.StorageClass);
            else
			    Coderinfo(attri,1)=string(store_attribute{attri}.CoderInfo.StorageClass); %get 'StorageClass'
            end

			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
			expression = '\w*.sldd\w*';
			matchStr = regexp(sldd_path,expression,'match');
			matchStr = strtok(matchStr,'.');
			component(attri,1) = matchStr;
			category{attri,1} = categorys{num_category_cntr};
		end
		oldName=Name;
		if (length(category) ~= 1)
		    json_data{num_category_cntr,1}=table(component,category,Name,Value,Description,Basetype,Offset,slope,Min,Max,Unit,Complexity,Dimensions,DimensionsMode,SampleTime,SamplingMode,InitialValue,Coderinfo,SwCalibrationAccess,DisplayFormat,oldName,maxDimension,MemorySection);
		else
			DataFetc2{1} = component;
			DataFetc2{2} = category;
			DataFetc2{3} = Name;
			DataFetc2{4} = Value;
			DataFetc2{5} = Description;
			DataFetc2{6} = Basetype;
			DataFetc2{7} = Offset;
			DataFetc2{8} = slope;
			DataFetc2{9} = Min;
			DataFetc2{10} = Max;
			DataFetc2{11} = Unit;
			DataFetc2{12} = Complexity;
			DataFetc2{13} = Dimensions;
			DataFetc2{14} = DimensionsMode;
			DataFetc2{15} = SampleTime;
			DataFetc2{16} = SamplingMode;
			DataFetc2{17} = InitialValue;
			DataFetc2{18} = Coderinfo;
			DataFetc2{19} = SwCalibrationAccess;
			DataFetc2{20} = DisplayFormat;
			DataFetc2{21} = oldName;
			DataFetc2{22} = maxDimension;
            DataFetc2{23} = MemorySection;
		    % Storing segregated data object and respective attribute in table format        
		    json_data{num_category_cntr,1} = cell2table((DataFetc2),'VariableNames',{'component' 'category','Name' 'Value' 'Description' 'Basetype' 'Offset' 'slope' 'Min' 'Max' 'Unit' 'Complexity' 'Dimensions' 'DimensionsMode'  'SampleTime' 'SamplingMode' 'InitialValue' 'Coderinfo' 'SwCalibrationAccess' 'DisplayFormat' 'oldName' 'maxDimension' 'MemorySection' }); 
	    end
		waitbar(num_category_cntr/length(categorys),LoadingIndicator,sprintf(' %1.0f%% Completed',(num_category_cntr/length(categorys))*100))
		num_category_cntr=num_category_cntr+1;
		attri_Info={};
		dataObject_Name1 = {};
		clearvars category DisplayFormat Value1 maxDimension SwCalibrationAccess component Basetype Offset slope Fraction_Length InitialValue Coderinfo val_in Valu1 Value inc_v store_categories name_categories inp_Value DimensionsMode Name Description DataType Min Max SampleTime Unit dataObject_Name1 Complexity Dimensions b SamplingMode InitialValue oldName MemorySection;
	end
	delete(LoadingIndicator)
end


function [attributes,maxDimensionInSldd] = extractSLDDdata(allEntries,num_Of_Entries)
categorys = {'Axis','Calibration','Curve','Define','Map'};

attributes{1,num_Of_Entries} = [];
dataObjectCategories{1,1} = [];
DimensionInSldd{1,1} = [];
%Fetch data from sldd
for index=1:num_Of_Entries
    Attribute=getValue(allEntries(index));      
    attributes{index}=Attribute;                        %Store attributes
	if isobject(getValue(allEntries(index))) &&  ~isstring(Attribute) && ~ischar(Attribute)            % check Data object is object type or normal variable
		FieldPrsnt = fields(getValue(allEntries(index)));
		ObjectTypePresent = ismember(FieldPrsnt,'objectType');
		if nnz(ObjectTypePresent) > 0
			dataObjectCategories{index}=Attribute.objectType;   %Store categories
			%if nnz(contains(categorys(1:5),Attribute.objectType))
            if nnz(contains(categorys(1:5),Attribute.objectType))
			    DimensionInSldd{index}=Attribute.Dimensions;
            end 
		end
	end
end   
maxDimensionInSldd = max(cell2mat(DimensionInSldd));
end    

