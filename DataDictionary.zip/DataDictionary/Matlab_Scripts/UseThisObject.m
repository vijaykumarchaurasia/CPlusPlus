%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :UseThisObject
% MAIN PURPOSE     :Function is used to replace the attributes of all input or output present in project with
%                   selected input or output data object.  
% INPUT(S)         :1.sldd_path=(''C:\Users\shubhangim1\Music\E39_example\AirManagement\aserc\Model\aserc.sldd')
%                   2.added_data_Obj=struct('Name','CPPPP_distCruiseTrip','Min',0,'Max','1000','Description','Knob is at ON position','InitaiValue','500','category','Input')
% OUTPUT           :1.Replace the attributes of all input or output present in project with
%                     selected input or output data object.
% DATE OF CREATION :5th Aug 2019
% REVESION NO      :Rev.1.2
% STATUS           :Rev. 1.1: Tested for selected input or output data object's attributes get  
%                             replaced at every existing places in project.
%                   Rev. 1.2: num_Of_Entries evaluation is changed as program name entry is added in other data section.
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function outdata = UseThisObject(~,added_data_Obj)
 categoryfields = {'Input','Output','Local','Nvm','Define','Map','Curve','Calibration','Axis'};
if length(added_data_Obj)==1
    errorCode = "515";
    outdata = table(errorCode);
    return;
else
%Implementation of loading indicator
loadingIndicator = waitbar(0,'Please wait while replacing your selected data object','Name','Use this data object...','WindowStyle', 'modal');
frames = java.awt.Frame.getFrames();
frames(end).setAlwaysOnTop(1);
javaFrame = get(loadingIndicator,'JavaFrame');
ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));

%Loop to replace selected data object with others
for length_objNames = 2:length(added_data_Obj)
    sldd_name =  added_data_Obj(length_objNames).component;
%     Simulink.data.dictionary.closeAll
    myDictionaryObj =Simulink.data.dictionary.open(sldd_name);        %open sldd
    dDataSectObj = getSection(myDictionaryObj,'Design Data');         %get design data from sldd    
    allEntries = find(dDataSectObj);
    num_Of_Entries = length(allEntries);
    for k=1:num_Of_Entries
        dataObject_Name{k}=allEntries(k).Name;
        attributes{k}=getValue(allEntries(k));       
    end
    new_data_object=added_data_Obj(length_objNames).Name;              %store 'Name' of data object 
    [dObjPrsnt, ~] = ismember(new_data_object,dataObject_Name);

    if (nnz(dObjPrsnt)>0)
        entryObj = getEntry(dDataSectObj,new_data_object);            
        add_simulinlk_signal_obj = getValue(entryObj);
    end


    %Implementation for DataType as Compu Method
    Basetype = added_data_Obj(1).Basetype;
    expressionsep = '[a-z,A-Z]';
    DataTypIdx = regexp(Basetype,expressionsep,'split');
    Bitsize = str2num(char(DataTypIdx(end)));
    expressionsignbit = 'u';
    signbitchk = regexp(Basetype,expressionsignbit,'match');
    if isempty(signbitchk)
        intbit = '1' ;   
    else
        intbit = '0' ;  
    end
    offset = added_data_Obj(1).Offset;
    slope = str2double(added_data_Obj(1).slope);

    if isnumeric(slope)
        frsactionL = log(1/slope)/log(2);
    end

    if strcmp(added_data_Obj(1).slope,'1') && strcmp(added_data_Obj(1).Offset,'0')
        add_simulinlk_signal_obj.DataType = added_data_Obj(1).Basetype;
    elseif strcmp(added_data_Obj(1).Offset,'0')&& mod(frsactionL,1)==0
        add_simulinlk_signal_obj.DataType = strcat('fixdt','(',intbit,',',string(Bitsize),',',string(frsactionL),')');
    else
        add_simulinlk_signal_obj.DataType = strcat('fixdt','(',intbit,',',string(Bitsize),',',string(slope),',',string(offset),')');           
    end
    %end of Compu Method Details      

    add_simulinlk_signal_obj.Dimensions = str2num(added_data_Obj(1).Dimensions);
    add_simulinlk_signal_obj.Min = str2num(added_data_Obj(1).Min);                                  
    add_simulinlk_signal_obj.Max = str2num(added_data_Obj(1).Max);                              
    add_simulinlk_signal_obj.Unit = added_data_Obj(1).Unit;   
    add_simulinlk_signal_obj.Description = added_data_Obj(1).Description;                                    

    %For SwCalibrationAccess and DisplayFormat attributes of Autosar signal and parameter
    if nnz(contains(categoryfields(1:2),add_simulinlk_signal_obj.objectType))
        add_simulinlk_signal_obj.SwCalibrationAccess = added_data_Obj(1).SwCalibrationAccess;                                                  
        add_simulinlk_signal_obj.DisplayFormat = added_data_Obj(1).DisplayFormat;      
    elseif nnz(contains(categoryfields(6:end),add_simulinlk_signal_obj.objectType))
        add_simulinlk_signal_obj.SwCalibrationAccess = added_data_Obj(1).SwCalibrationAccess;                                                 
        add_simulinlk_signal_obj.DisplayFormat = added_data_Obj(1).DisplayFormat;     
    end
    % DimensionsMode and Complexity attributes for Signals 
    if nnz(contains(categoryfields(1:4),add_simulinlk_signal_obj.objectType))
        add_simulinlk_signal_obj.DimensionsMode = added_data_Obj(1).DimensionsMode;                %else assign existing value to DimensionsMode
        add_simulinlk_signal_obj.Complexity = added_data_Obj(1).Complexity;                %store 'Complexity' of data object as per from User      
        add_simulinlk_signal_obj.InitialValue = added_data_Obj(1).InitialValue;   
    else
         add_simulinlk_signal_obj.Value =  added_data_Obj(1).Value;
    end
    %Implementation of StorageClass
    if nnz(contains(categoryfields(1:2),add_simulinlk_signal_obj.objectType))
       add_simulinlk_signal_obj.CoderInfo.StorageClass=added_data_Obj(1).Coderinfo;%Set StorageClass as 'Auto'
    end

    setValue(entryObj,add_simulinlk_signal_obj)
    waitbar(length_objNames/length(added_data_Obj),loadingIndicator,sprintf('Please wait while replacing your selected data object %1.0f%%',(length_objNames/(length(added_data_Obj)))*100))
    clearvars inp_data_v Dimesnion_for_val add_simulinlk_signal_obj ;
    saveChanges(myDictionaryObj)
end
close(loadingIndicator)
end
messageCode = "510";
outdata = table(messageCode);
end