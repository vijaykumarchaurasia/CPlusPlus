%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :DataToBeResolved
% MAIN PURPOSE     :Function is used to compare and resolve the differences in the data 
%                   objects between the data dictionary and model for a given component. 
% INPUT(S)         :1.sldd_path=('C:/Users/shubhangim1/Music/Fresh_Project/E39_example/AirManagement/aserc/Model/aserc.sldd,C:/Users/shubhangim1/Music/Fresh_Project/E39_example/AirManagement')
% OUTPUT           :1.Inconsistent data object list and respective categories
%                     a. Data object list which needs to be added in sldd
%                     b. Data object list which needs to be removed from sldd
%                     c. Redundant data object list deleted from sldd OR
%                   2.If list (a) is empty, will send "errorCode:112" and 
%                     If list (b) is empty, will send "errorCode:113" OR
%                     If list (c) is empty, will send "errorCode:118" OR
%                   3.If simulink model not present on sldd path will send
%                     "errorCode:114" OR
%                   4.If same name model opened from other path
%                     then exception message has been send
% DATE OF CREATION :5th July 2019
% REVESION NO      :1.8
% STATUS           :Rev. 1.1: Tested to compare and capcture difference between  model and 
%                             sldd data object which has inconsistency.
%                             Applicable for following categories->Input,Output,Local,Nvm,Axis,Curve,Calibration,Define,Map
%                   Rev. 1.2: Tested to get data object contains in stateflow 
%                   Rev. 1.3: Tested to get data object contains in Float look up table block 
%                   Rev. 1.4: Function does not require dependancy of Naming convention of data object.(Previously Calibration(CalName_C) and define(CalName_SC) data object implemented as per naming convension)
%                   Rev. 1.5: Optimized script
%                   Rev. 1.6: Read configuration excel file, created struct data category wise using for loop, logic for add data object and delete data object in SLDD is replaced with single for loop. 
%                             num_Of_Entries evaluation is changed as program name entry is added in other data section.
%                   Rev. 1.7: 15th Sep 2021
%                             1.Added GetConfigurationData function call to get configuration data from excel. 
%                             2.OpenSldd,DesignDataSectionObject and NumOfEntries are replaced with myDictionaryObj,dDataSectObj and allEntries for naming consistency. 
%                   Rev. 1.8: 4th Apr 2022
%                             1. Added logic to list down redundant data objects and send the list to DeleteDataObject function to delete data objects from SLDD file.
%                             2. Send the list of redundant data object's name if there are any.
% FUNCTION CALL    :[Map,Curve,Axis,Inputs,Outputs,CalibrationAndDefine,Nvm,Local,Unique_Constant_First_Order_Transfer_Fcn,SeperatingPathOfSldd,StoreObjInSlddRemaining,DelObjFrmSlddRemaining,StoreDataObjToResolve,DelObjFrmSldd,SendObjToDelete,ResolvedDataObjects,SendDeleteObjInSldd,DataObjectResolved,modelData,errorCode,~]= ModelData(sldd_path,OldNameOfObj);
%                   [ConfigurationData,errorCode] = GetConfigurationData(ConfigFilePath,ProgramName);
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [SendingDataToBeResolved]= DataToBeResolved(componentData,~)

%Extract sldd_path, ConfigFilePath and ProgramName from componentData
FilePaths = split(componentData,',');
sldd_path = strcat(FilePaths{1},',',FilePaths{2});
ConfigFilePath = FilePaths{3};
ProgramName = FilePaths{4};
%Extract component name 
componentName = char(extractBetween(FilePaths{1},'Model/','.sldd')); 

%Get configuration data from excel file in table form
[ConfigurationData,errorCode] = GetConfigurationData(ConfigFilePath,ProgramName);
if strcmp(errorCode,"1006") || strcmp(errorCode,"1007") 
    SendingDataToBeResolved = table(errorCode);
    return;
end
%Category fields defined in configuration file
categorys = ConfigurationData.CategoryFields;

%Logic written for loading indicator
%LoadingIndicator starts
%Set LoadingIndicator always on top of screen
LoadingIndicator = waitbar(0,'0% Completed','Name','Resolving inconsistency with model...','WindowStyle', 'modal');
frames = java.awt.Frame.getFrames();
frames(end).setAlwaysOnTop(1);
%Set data dictionary icon on LoadingIndicator 
javaFrame = get(LoadingIndicator,'JavaFrame');
ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));

% Function call to access data objects from model
OldNameOfObj="";
[Map,Curve,Axis,Inputs,Outputs,CalibrationAndDefine,Nvm,Local,Unique_Constant_First_Order_Transfer_Fcn,SeperatingPathOfSldd,StoreObjInSlddRemaining,DelObjFrmSlddRemaining,StoreDataObjToResolve,DelObjFrmSldd,SendObjToDelete,ResolvedDataObjects,SendDeleteObjInSldd,DataObjectResolved,modelData,errorCode,~]= ModelData(sldd_path,OldNameOfObj);
%Precaution has been taken if model loaded previously, because same name model cannot open from other path 
if ~isempty(modelData)
    SendingDataToBeResolved=table(modelData);%if model loaded previously then Exception Message displsy corrective action needs to take
    close(LoadingIndicator)                  %Closing LoadingIndicator
    return;
end
%if model not available in project folder
if strcmp(errorCode,'114')
    SendingDataToBeResolved=table(errorCode);
    close(LoadingIndicator)                  %Close LoadingIndicator
    return;
end

CategoryData = {Map,Curve,Axis,Inputs,Outputs,Nvm,Local,Unique_Constant_First_Order_Transfer_Fcn,CalibrationAndDefine};
% 1st calibration category is for Unique_Constant_First_Order_Transfer_Fcn
% 2nd calibration category is for calibration values in CalibrationAndDefine as we can not conclude type of data present in CalibrationAndDefine 
Categories = {'Map','Curve','Axis','Input','Output','Nvm','Local','Calibration','Define','Calibration'};
%Creating structure of data object name and respective category
for StrctIndex = 1:length(CategoryData)
    AllStructData{StrctIndex,:}=struct2table(struct('warning','Add in DataDictionary','Name',CategoryData{StrctIndex},'category',Categories{StrctIndex}),'AsArray',true);
    %Condition to add table structure for calibration category after define as both have same data
    if strmatch('Define',Categories{StrctIndex},'exact')
        AllStructData{StrctIndex+1,:}=struct2table(struct('warning','Add in DataDictionary','Name',CategoryData{StrctIndex},'category',Categories{StrctIndex+1}),'AsArray',true);
    end
end
ModelStrct = [AllStructData{1,:};AllStructData{2,:};AllStructData{3,:};AllStructData{4,:};AllStructData{5,:};AllStructData{6,:};AllStructData{7,:};AllStructData{8,:};AllStructData{9,:};AllStructData{10,:}];

%Opening sldd
try
    myDictionaryObj = Simulink.data.dictionary.open(SeperatingPathOfSldd{1});
catch Exception
    modelData={Exception.message};  %If any error throw while opening sldd    
    SendingDataToBeResolved=table(modelData);
    close(LoadingIndicator);
    return;
end
dDataSectObj = getSection(myDictionaryObj,'Design Data');
allEntries = find(dDataSectObj);
num_Of_Entries = length(allEntries);
RedunDataList = {}; %Variable to store redundant data objects
RedunIndex = 1;
%Preallocation of memory
if num_Of_Entries > 0
    SlddData{1,num_Of_Entries} = [];
    Attributes{1,num_Of_Entries} = [];
    DataObjectCategories{1,num_Of_Entries} = [];
    storeDobj{1,num_Of_Entries}=[];
    NewSlddData={};
    %Fetching data object and category from sldd
    cntr=1;
    pattern = {'Parameter','Signal'};
    for Index2=1:num_Of_Entries
        DataObj=allEntries(Index2).Name;
        GetAttriInfo=getValue(allEntries(Index2));
        if ~isnumeric(GetAttriInfo) &&~ischar(GetAttriInfo)&&~isstring(GetAttriInfo)
            GetFields=fields(GetAttriInfo);               %Get fields of data object
            log_array = ismember(GetFields,'objectType'); %Check data object having object type
            varv = nnz(log_array);
            if varv==1
                DataObjectCategories{cntr}=GetAttriInfo.objectType;        %store categories
                storeDobj{cntr}=DataObj;                                   %store data object
                cntr=cntr+1;
            else
                DataObjClass = class(GetAttriInfo); %Get class of data object
                %Check if class of data object is of type Parameter or Signal 
                if endsWith(DataObjClass, pattern)
                    %Perform operation for components other than CPPPP
                    if ~isequal(componentName,'cpppp')
                        RedunDataList{RedunIndex} = DataObj;
                        RedunIndex = RedunIndex + 1;
                    end
                end
            end
        end
        waitbar(Index2/num_Of_Entries,LoadingIndicator,sprintf(' %1.0f%% Completed',(Index2/num_Of_Entries)*100))
    end
DataObjectCategories = DataObjectCategories(~cellfun('isempty', DataObjectCategories));
storeDobj = storeDobj(~cellfun('isempty', storeDobj));
end
%Creating structure of data object name and respective category
if ~isempty(storeDobj)
    slddDatastruct = struct2table(struct('warning','Delete from DataDictionary','Name',storeDobj,'category',DataObjectCategories));
else
    slddDatastruct = struct2table(struct('warning','Delete from DataDictionary','Name','','category',''),'AsArray',true);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Compare model data objects with sldd data objects to add and delete data object in sldd
[AddDataObjInSldd,pos] = ismember(ModelStrct(:,2),slddDatastruct(:,2)); 
[DelDataObjFrmSldd,PositionOfDelDataObjFrmSldd] = ismember(slddDatastruct(:,2),ModelStrct(:,2),'rows');
%Cell array for data objects to add and to delete from sldd
DataObj = {AddDataObjInSldd,DelDataObjFrmSldd};
ModelSlddData = {ModelStrct,slddDatastruct};
CategoryField={'Define','Calibration'};

SameNameObjects = {};
SameNameResolved = {};
counter = 1;
for DataIndex = 1:length(DataObj)   
    StoreObjInSlddRemaining={};
    ResolvedDataObjects={};
    DataObjectResolved={};
    StoreDataObjToResolve={};
    %Loop used to fetch data objects need to add in sldd/delete from sldd
    cntr=1;
    for dataNum = 1:length(DataObj{DataIndex})
        %Data will be resolved for categories defined in excel file
        if nnz(contains(categorys,ModelSlddData{DataIndex}(dataNum,:).category)) 
            if DataObj{DataIndex}(dataNum)==0
                StoreDataObjToResolve{cntr} = ModelSlddData{DataIndex}(dataNum,:);  % Storing each data object in table
                cntr=cntr+1;
            else
                if DataIndex ==1
                    CatComp{DataIndex} = {ModelStrct(dataNum,:),slddDatastruct(pos(dataNum),:)}; % Storing data objects need to be added
                else
                    CatComp{DataIndex} = {slddDatastruct(dataNum,:),ModelStrct(PositionOfDelDataObjFrmSldd(dataNum),:)}; % Storing data objects need to be deleted
                end
                if ~isequal(string(CatComp{DataIndex}{1}.category),string(CatComp{DataIndex}{2}.category))
                    if ~contains(CatComp{DataIndex}{1}.category,CategoryField(1:2))
                        %Store data objects with same name but with
                        %different category for DataIndex = 2(DeleteDataObj)
                        if (DataIndex == 2)
                            StoreObjInSlddRemaining{counter} = CatComp{DataIndex}{1};  
                            StoreObjInSlddRemaining{counter+1} = CatComp{DataIndex}{2};
                            counter=counter+2;
                        end
                    end
                end
            end
        else
            %Store data object to delete whose category is not present in defined categories 
            if (DataIndex == 2)
                StoreDataObjToResolve{cntr} = ModelSlddData{DataIndex}(dataNum,:);  % Storing each data object in table
                cntr=cntr+1;
            end
        end
    end
    
    %Used to store all data objects having same name and different category in single table   
    if ~isempty(StoreObjInSlddRemaining)
        %Removing empty cells
        StoreObjInSlddRemaining = StoreObjInSlddRemaining(~cellfun('isempty', StoreObjInSlddRemaining));
        if length(StoreObjInSlddRemaining) > 1
            SameNameObjects = [StoreObjInSlddRemaining{1};StoreObjInSlddRemaining{2}]; % First and second table combine vertically
            for index2=3:length(StoreObjInSlddRemaining)
                SameNameObjects = [SameNameObjects;StoreObjInSlddRemaining{index2}]; % Append rest of table below First and second
            end
        else
            SameNameObjects = cell2table(StoreObjInSlddRemaining).StoreObjInSlddRemaining;% If 'StoreObjInSlddRemaining' variable contains single table
        end
        SameNameResolved{1} = struct2table(struct('warning','Duplicate data objects','Name',SameNameObjects.Name,'category',SameNameObjects.category ));%Store same name with different category data objects in table format
    end
    
    %ResolvedDataObjects=[StoreDataObjToResolve';StoreObjInSlddRemaining'];% StoreObjInSlddRemaining will be stored in SameNameResolved
    ResolvedDataObjects=StoreDataObjToResolve';
    
    %Loop used to store all data objects in single table which will to add in sldd/delete from sldd('ResolvedDataObjects' variable contain data objects in separate table)
    if ~isempty(ResolvedDataObjects)
        if length(ResolvedDataObjects) > 1
            DataObjectResolved=[ResolvedDataObjects{1};ResolvedDataObjects{2}]; % First and second table combine vertically
            for index1=3:length(ResolvedDataObjects)
                DataObjectResolved=[DataObjectResolved;ResolvedDataObjects{index1}]; % Append rest of table below First and second
            end    
        else
            StoreResolvedDataObj = cell2table(ResolvedDataObjects);        % If 'ResolvedDataObjects' variable contains single table
            DataObjectResolved = StoreResolvedDataObj.ResolvedDataObjects;
        end
    end
    DataResolved{DataIndex} = DataObjectResolved;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%If Data Object to add (DataResolved{1}) list is empty
    if isempty(DataResolved{1})
        errorCode = "112";                                          
        DataResolved{1} = (table(errorCode));
    end
%If Data Object to delete (DataResolved{2}) list is empty
    if isempty(DataResolved{2})
        errorCode = "113";                                         
        DataResolved{2} = (table(errorCode));
    end 
%If SameNameResolved list is empty
    if isempty(SameNameResolved)
        errorCode = "110";                                         
        SameNameResolved{1} = (table(errorCode));
    end    
%LoadingIndicator ends
close(LoadingIndicator)

%Delete redundant data objects before sending response
if RedunIndex > 1
    %Function call to delete data objects from SLDD file
    DeleteDataObject(SeperatingPathOfSldd{1},struct('Name',RedunDataList));
    RedundantDataObj{1} = struct2table(struct('warning','Redundant Data Objects','Name',RedunDataList));
else
    %Send error code = 118 when there is no any redundant data object
    errorCode = "118";
    RedundantDataObj{1} = (table(errorCode));
end

%Storing data objects
SendingDataToBeResolved{1,:} = DataResolved{1};
SendingDataToBeResolved{2,:} = DataResolved{2};
SendingDataToBeResolved{3,:} = SameNameResolved{1};
SendingDataToBeResolved{4,:} = RedundantDataObj{1};