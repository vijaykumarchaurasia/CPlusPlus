%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FILE NAME        :AttributeValidationFile
% MAIN PURPOSE     :File is used to store value of hidden attributes present in sldd(user can modify the values)
% INPUT(S)         :-
% OUTPUT           :Value of attribute
% DATE OF CREATION :4th Aug 2020
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%Complexity%%
Complexity_Input='auto'; %User can change it to auto or real or complex
Complexity_Output='auto'; %User can change it to auto or real or complex
Complexity_Nvm='auto'; %User can change it to auto or real or complex
Complexity_Local='auto'; %User can change it to auto or real or complex
Complexity_Map='real'; %User cannot change this value because its read-only property
Complexity_Axis='real'; %User cannot change this value because its read-only property
Complexity_Curve='real'; %User cannot change this value because its read-only property
Complexity_Calibration='real'; %User cannot change this value because its read-only property
Complexity_Define='real'; %User cannot change this value because its read-only property

%%DimensionsMode%%
DimensionsMode_Input='auto'; %User can change it to auto or Fixed or Variable
DimensionsMode_Output='auto'; %User can change it to auto or Fixed or Variable
DimensionsMode_Nvm='auto'; %User can change it to auto or Fixed or Variable
DimensionsMode_Local='auto'; %User can change it to auto or Fixed or Variable

%%SampleTime%%
SampleTime_Input=-1; %User can change it to any positive integers along with decimals. Only negative number allowed is -1
SampleTime_Output=-1; %User can change it to any positive integers along with decimals. Only negative number allowed is -1
SampleTime_Nvm=-1; %User can change it to any positive integers along with decimals. Only negative number allowed is -1
SampleTime_Local=-1; %User can change it to any positive integers along with decimals. Only negative number allowed is -1

%%StorageClass%%
StorageClass_Input='Auto'; %User can change it to Auto or Model default or ExportedGlobal or ImportedExtern or ImportedExternPointer

StorageClass_Output='Auto'; %User can change it to Auto or Model default or ExportedGlobal or ImportedExtern or ImportedExternPointer

StorageClass_Nvm='Custom'; %User can change it to Auto or Custom. If changed to Auto, then set CustomStorageClass_Nvm to Default
CustomStorageClass_Nvm='ImportFromFile'; %User can change it to Volatile or ImportFromFile or ExportToFile or GetSet or Reusable if StorageClass_Nvm is set to Custom
HeaderFile_Nvm='eep.h';

StorageClass_Local='ExportedGlobal'; %User can change it to Auto or Model default or ExportedGlobal or ImportedExtern or ImportedExternPointer

StorageClass_Map='Custom'; %User can change it to Auto or Custom. If changed to Auto, then set CustomStorageClass_Map to Default
CustomStorageClass_Map='InternalCalPrm'; %User can change it to InternalCalPrm or CalPrm or SystemConstant if StorageClass_Map set to Custom

StorageClass_Axis='Custom'; %User can change it to Auto or Custom. If changed to Auto, then set CustomStorageClass_Axis to Default
CustomStorageClass_Axis='InternalCalPrm'; %User can change it to InternalCalPrm or CalPrm or SystemConstant if StorageClass_Axis set to Custom

StorageClass_Curve='Custom'; %User can change it to Auto or Custom. If changed to Auto, then set CustomStorageClass_Curve to Default 
CustomStorageClass_Curve='InternalCalPrm'; %User can change it to InternalCalPrm or CalPrm or SystemConstant if StorageClass_Curve set to Custom

StorageClass_Calibration='Custom'; %User can change it to Auto or Custom. If changed to Auto, then set CustomStorageClass_Calibration to Default
CustomStorageClass_Calibration='InternalCalPrm'; %User can change it to InternalCalPrm or CalPrm or SystemConstant if StorageClass_Calibration set to Custom

StorageClass_Define='Custom'; %User can change it to Auto or Custom. If changed to Auto, then set CustomStorageClass_Define to Default
CustomStorageClass_Define='Define'; %User can change it to BitField or Const or Volatile or ConstVolatile or Define or ImportedDefine or ImportFromFile or ExportToFile or GetSet or FileScope or Struct or CompilerFlag if StorageClass_Define set to Custom

%%SwCalibrationAccess%%
SwCalibrationAccess_Input='ReadOnly'; %User can change it to ReadOnly or ReadWrite or NotAccessible
SwCalibrationAccess_Output='ReadOnly'; %User can change it to ReadOnly or ReadWrite or NotAccessible
SwCalibrationAccess_Map='ReadOnly'; %User can change it to ReadOnly or ReadWrite or NotAccessible
SwCalibrationAccess_Curve='ReadOnly'; %User can change it to ReadOnly or ReadWrite or NotAccessible
SwCalibrationAccess_Axis='ReadOnly'; %User can change it to ReadOnly or ReadWrite or NotAccessible
SwCalibrationAccess_Calibration='ReadWrite'; %User can change it to ReadOnly or ReadWrite or NotAccessible

%%DisplayFormat%%
DisplayFormat_Input=''; %User can enter any string or keep it empty
DisplayFormat_Output=''; %User can enter any string or keep it empty
DisplayFormat_Map=''; %User can enter any string or keep it empty
DisplayFormat_Curve=''; %User can enter any string or keep it empty
DisplayFormat_Axis=''; %User can enter any string or keep it empty
DisplayFormat_Calibration=''; %User can enter any string or keep it empty