%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :TopSlddComponent
% MAIN PURPOSE     :Function is used to get sldd paths from top sldd.
% INPUT(S)         :1.sldd_name=('C:\Users\shubhangim1\Music\E39_example\AirManagement\aserc\Model\aserc.sldd')
%                   2.varargin1='';
%                   3.varargin2='';
% OUTPUT           :1.Gend sldd path from tp sldd if it is present in project folder OR
%                   2.If project folder is empty, will send "errorCode:107" 
%                   3.If top sldd not present, will send "errorCode:108" 
% DATE OF CREATION :10th May 2019
% REVESION NO      :1.1
% STATUS           :Rev. 1.1: Tested to send Sldd file path.
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [SlddFilePaths] = TopSlddComponent(componentName,~)
%Add project folder on path
addpath(genpath(componentName))
DirPath = dir(fullfile(componentName,'**\*.sldd'));
fileList = strcat({DirPath.folder}, {'\'},{DirPath.name});
%If sldd not present in project folder 
if isempty(fileList)
    errorCode = [107];
    SlddFilePaths = (table(errorCode));
    return;
end
%Checking top sldd present in project folder
if nnz(contains(fileList,'top.sldd')>0)
    fileList = {'top.sldd'}; 
else
    errorCode = [108];        %If top sldd not present send error code
    SlddFilePaths = (table(errorCode));
    return;
end
%Implementation of loading indicator
LoadingIndicator = waitbar(0,'Please wait...','Name','Loading project...','WindowStyle', 'modal');
Frames = java.awt.Frame.getFrames();
Frames(end).setAlwaysOnTop(1);
javaFrame = get(LoadingIndicator,'JavaFrame');
ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));
%Open top sldd
    try
          dicObj = Simulink.data.dictionary.open((char(fileList)));
    catch 
           errorCode = 110;        %If top sldd not present send error code 
           SlddFilePaths = (table(errorCode));
           close(LoadingIndicator);
           return;
    end
    SlddNames = dicObj.DataSources;
%Get sldd path
for indexDobj = 1:length(SlddNames)
    pathofFile(indexDobj) = string(which( char(SlddNames(indexDobj))));
     waitbar(indexDobj/length(SlddNames),LoadingIndicator,sprintf('Please wait...',((indexDobj/length(SlddNames)))*100))
       
end
close(LoadingIndicator);
SlddFilePathsData = unique(pathofFile);
componentName = SlddFilePathsData';
SlddFilePaths = array2table(componentName);