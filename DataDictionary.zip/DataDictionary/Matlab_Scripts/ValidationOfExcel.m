%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :ValidationOfExcel
% MAIN PURPOSE     :Function is used to validate excel sheet selected by user
% INPUT(S)         :1.ExcelPath=('D:\CAN_database_SLDD_example_edited.xlsx');
% OUTPUT           :1.All excel sheet data which contains following column header('DataType_Source Variable','DataType_Destination Variable','Offset_Source Variable',
%                     'Offset_Destination Variable','Slope_Source Variable','Slope_Destination Variable')
% DATE OF CREATION :20th April 2020
% REVESION NO      :Rev. 1.2
% STATUS           :Rev. 1.1:Function has been written to called in "ResolveInconsistencyImport","ResolveInconsistencyExport" script 
%                   Rev. 1.2:readcell() is used instead of xlsread, ismissing() is used instead of isnan(). 
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [Code,StoreIndexInputName,StoreIndexOutputName,StoreIndexDataTypeName_Input,StoreIndexDataTypeName_Output,StoreIndexOffsetName_Input,StoreIndexOffsetName_Output,StoreIndexSlopeName_Input,StoreIndexSlopeName_Output,StoreIndexComponentName,StoreInputDataObject1,StoreOutputDataObject1,StoreDataType_Input1,StoreDataType_Output1,StoreOffset_Input1,StoreOffset_Output1,StoreSlope_Input1,StoreSlope_Output1,StoreComponentName1]=ValidationOfExcel(ExcelPath)   
StoreInputDataObject1="";
StoreOutputDataObject1="";
StoreDataType_Input1="";
StoreDataType_Output1="";
StoreOffset_Input1="";
StoreOffset_Output1="";
StoreSlope_Input1="";
StoreSlope_Output1="";
StoreComponentName1="";
Code="4000";

ExcelData = readcell(ExcelPath);%read excel sheet
%Loop is used to replace 'NAN' cell with '#N/A'
for index_ExcelData = 1:numel(ExcelData)
      if ismissing(ExcelData{index_ExcelData})
        ExcelData{index_ExcelData} = '#N/A';
      end
end
%To find position of 'Source Variable', 'Destination Variable' and respective DataType/Offset/Slope from excel sheet
%TXT is variable which contains all data inside the Excel/Test Vector file
%Read Second Row for Headings of Column
StoreIndexInputName=strmatch('Source Variable',ExcelData(2,:),'exact');
if isempty(StoreIndexInputName) %'Source Variable' name not present in excel
   Code = "912";                        
   return;
end
StoreIndexOutputName=strmatch('Destination Variable',ExcelData(2,:),'exact');
if isempty(StoreIndexOutputName) %'Destination Variable' name not present in excel
   Code = "913";                        
   return;
end
StoreIndexDataTypeName_Input=strmatch('DataType_Source Variable',ExcelData(2,:),'exact');
StoreIndexDataTypeName_Output=strmatch('DataType_Destination Variable',ExcelData(2,:),'exact');
StoreIndexOffsetName_Input=strmatch('Offset_Source Variable',ExcelData(2,:),'exact');
StoreIndexOffsetName_Output=strmatch('Offset_Destination Variable',ExcelData(2,:),'exact');
StoreIndexSlopeName_Input=strmatch('Slope_Source Variable',ExcelData(2,:),'exact');
StoreIndexSlopeName_Output=strmatch('Slope_Destination Variable',ExcelData(2,:),'exact');
StoreIndexComponentName=strmatch('Model',ExcelData(2,:),'exact');

%To get data from found position
StoreInputDataObject1 = ExcelData((1:end),StoreIndexInputName);
StoreOutputDataObject1 = ExcelData((1:end),StoreIndexOutputName);
StoreDataType_Input1 = ExcelData((1:end),StoreIndexDataTypeName_Input);
StoreDataType_Output1 = ExcelData((1:end),StoreIndexDataTypeName_Output);
StoreOffset_Input1 = ExcelData((1:end),StoreIndexOffsetName_Input);
StoreOffset_Output1 = ExcelData((1:end),StoreIndexOffsetName_Output);
StoreSlope_Input1 = ExcelData((1:end),StoreIndexSlopeName_Input);
StoreSlope_Output1 = ExcelData((1:end),StoreIndexSlopeName_Output);
StoreComponentName1 = ExcelData((1:end),StoreIndexComponentName);

if isempty(StoreDataType_Input1)
    StoreDataType_Input1="";
end

if isempty(StoreDataType_Output1)
    StoreDataType_Output1="";
end

if isempty(StoreOffset_Input1)
    StoreOffset_Input1="";
end

if isempty(StoreOffset_Output1)
    StoreOffset_Output1="";
end

if isempty(StoreSlope_Input1)
    StoreSlope_Input1="";
end

if isempty(StoreSlope_Output1)
    StoreSlope_Output1="";
end