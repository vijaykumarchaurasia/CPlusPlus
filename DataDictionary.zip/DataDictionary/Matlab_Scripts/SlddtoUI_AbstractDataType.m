%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :SlddtoUI_AbstractDataType
% MAIN PURPOSE     :Function is used to get Basetype,Offset and slope form data type received from sldd
% INPUT(S)         :1.DataType=('fixdt(0,8,1.00000000,-0.00000000)'); OR
%                     DataType=('fixdt(0,8,4.00000000)');
% OUTPUT           :1.Get Basetype,Offset and slope
% DATE OF CREATION :20th April 2019
% REVESION NO      :-
% STATUS           :Function has been written to called in"FetchSLDD_Data", "ResolveInconsistencyImport","ResolveInconsistencyExport" script 
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [Basetype, Offset, slope] = SlddtoUI_AbstractDataType(DataType)
    Basetype = '';
    Offset = '';
    slope = '';
    exprsn = extractBetween(DataType,'(',')');
    expressionsep = ',';
    DataTypIdx = regexp(exprsn,expressionsep,'split');
    if contains(DataType,'fixdt')
        if length(DataTypIdx) == 4
            if (str2num(char(DataTypIdx(1))))
                bitavl = str2num(char(DataTypIdx(2)));
                Basetype = string(strcat('int',num2str(bitavl)));
                Offset = string(str2num(char(DataTypIdx(4))));
                slope = string(str2double(char(DataTypIdx(3))));
            else
                bitavl = str2num(char(DataTypIdx(2)));
                Basetype = string(strcat('uint',num2str(bitavl)));
                Offset = string(str2num(char(DataTypIdx(4))));
                slope = string(str2double(char(DataTypIdx(3))));
            end
        elseif length(DataTypIdx) == 3
            if (str2num(char(DataTypIdx(1))))
                bitavl = str2num(char(DataTypIdx(2)));
                Basetype = string(strcat('int',num2str(bitavl)));
                Offset = string(num2str(0));
				slopeVal = round(str2num(char(DataTypIdx(3))));
				precision = (1/(2^slopeVal));
				slope = string(precision);
            else
                bitavl = str2num(char(DataTypIdx(2)));
                Basetype = string(strcat('uint',num2str(bitavl)));
                Offset = string(num2str(0));
				slopeVal = round(str2num(char(DataTypIdx(3))));
				precision = (1/(2^slopeVal));
				slope = string(precision);
            end
        end
    else
        Basetype = DataType;
        Offset = string(num2str(0));
        slope = string(num2str(1));
    end