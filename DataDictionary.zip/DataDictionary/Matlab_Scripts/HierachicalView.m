%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :HierachicalView
% MAIN PURPOSE     :Function is used to display hierarchical view on UI. 
% INPUT(S)         :1.componentName=('C:\Users\shubhangim1\Music\Fresh_Project\E39_example')
% OUTPUT           :1.Display module name and respective sldd path present in it. OR 
%                   2.If only one module present in project folder will
%                     send "error code:"130
% DATE OF CREATION :19th Aug 2019
% REVESION NO      :1.2
% STATUS           :Rev. 1.1: Tested to send module name and Sldd name.
%                        1.2: Tested to send module name and Sldd file path.
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [structModule] = HierachicalView(componentName,~)
RemaningSldds={};
JsonArgLst={};
ModuleName='';
addpath(genpath(componentName))
DirPath = dir(fullfile(componentName,'**\*.sldd'));
fileList = strcat({DirPath.folder}, {'\'},{DirPath.name});
if isempty(fileList)
    errorCode = "126";
    structModule = (table(errorCode));
    return;
end
%If project contains more than one top.sldd then send error code(Invalid project)
if nnz(contains(fileList,'top.sldd')>0)>1
   errorCode = "127";
   structModule = (table(errorCode));
   return;    
end
% If top sldd present
if nnz(contains(fileList,'top.sldd')>0) 
    cntr2=1;
    cntr4=1;
    JsonArgLstWithoutTop=fileList(2:end);
    for j=1:length(JsonArgLstWithoutTop)
        if contains(JsonArgLstWithoutTop(j),'.sldd')
            if contains(JsonArgLstWithoutTop(j),'\Model')
               JsonArgLst(cntr2) = extractBefore(JsonArgLstWithoutTop(j),'\Model');
               cntr2=cntr2+1;
            else
               RemaningSldds(cntr4) = extractBefore(JsonArgLstWithoutTop(j),'.sldd');
               cntr4=cntr4+1;
            end
        end
    end
    if ~isempty(JsonArgLst)
        getModelName=split(JsonArgLst','\');
    else
        getModelName='';
    end
    if ~isempty(RemaningSldds)
        getModelName1=split(RemaningSldds','\');
    else
        getModelName1='';
    end
    if ~isempty(JsonArgLst)
        if length(JsonArgLst)==1
            ModuleName=unique(getModelName(end-1));
        else
            ModuleName=unique(getModelName(:,end-1));
        end
    end
     if length(ModuleName)==1
         errorCode = "130";
         structModule = (table(errorCode));
     elseif isempty(ModuleName)
           errorCode = "130";
           structModule = (table(errorCode));
     else    
          if isempty(getModelName)
             StoreHierarchicalFormat=struct('Name','NoName','component','NoComponent'); 
          else
             StoreHierarchicalFormat=struct('Name',getModelName(:,end-1),'component',getModelName(:,end));
          end
          if isempty(getModelName1)
             StoreRemainingSldd=struct('Name','OtherSldd','component','NoSldd');
          else
              if length(RemaningSldds)==1
                  StoreRemainingSldd=struct('Name','OtherSldd','component',getModelName1(end)); 
              else
                  StoreRemainingSldd=struct('Name','OtherSldd','component',getModelName1(:,end));
              end
          end
          CombineStruct=vertcat(StoreHierarchicalFormat,StoreRemainingSldd);
          structModule=struct2table(CombineStruct);
     end
% Top sldd not present
else
    cntr1=1;
    cntr3=1;
    for i=1:length(fileList)
        if contains(fileList(i),'.sldd')
            if contains(fileList(i),'\Model')
               JsonArgLst(cntr1) = extractBefore(fileList(i),'\Model');
               cntr1=cntr1+1;
            else
               RemaningSldds(cntr3) = extractBefore(fileList(i),'.sldd');
               cntr3=cntr3+1;
            end
        end
    end
    if ~isempty(JsonArgLst)
        getModelName=split(JsonArgLst','\');
    else
        getModelName='';
    end
    if ~isempty(RemaningSldds)
        getModelName1=split(RemaningSldds','\');
    else
        getModelName1='';
    end
    if ~isempty(JsonArgLst)
        if length(JsonArgLst)==1
            ModuleName=unique(getModelName(end-1));
        else
            ModuleName=unique(getModelName(:,end-1));
        end
    end
    if length(ModuleName)==1
        errorCode = "130";
        structModule = (table(errorCode));
    elseif isempty(ModuleName)
           errorCode = "130";
           structModule = (table(errorCode));
    else
        if isempty(getModelName)
           StoreHierarchicalFormat=struct('Name','NoName','component','NoComponent'); 
        else
           StoreHierarchicalFormat=struct('Name',getModelName(:,end-1),'component',getModelName(:,end));
        end
        if isempty(getModelName1)
            StoreRemainingSldd=struct('Name','OtherSldd','component','NoSldd');
        else
            if length(RemaningSldds)==1
                StoreRemainingSldd=struct('Name','OtherSldd','component',getModelName1(end));
            else
                StoreRemainingSldd=struct('Name','OtherSldd','component',getModelName1(:,end));
            end
        end
        CombineStruct=vertcat(StoreHierarchicalFormat,StoreRemainingSldd);
        structModule=struct2table(CombineStruct);
    end
end