%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :InOutNotPresentInSlddForImportExport
% MAIN PURPOSE     :Function is used to check and send error code if input and output not present in sldd
% INPUT(S)         :1.storeDobj
% OUTPUT           :1.If input and output not present in sldd will send
%                     error code:999
% DATE OF CREATION :9th June 2020
% REVESION NO      :-
% STATUS           :Function has been written to called in"ResolveInconsistencyExport", "ResolveInconsistencyImport" script 
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function errorCode=InOutNotPresentInSlddForImportExport(storeDobj)
errorCode = "99999";   
if isempty(storeDobj)
   errorCode = "999";                                          
   return;
end   