%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :ModelFoundInProjectFolder
% MAIN PURPOSE     :Function is used to gather data objects of all categories available in model   
% INPUT(S)         :1.sldd_path=('C:\Users\shubhangim1\Music\E39_example\AirManagement\aserc\Model\aserc.sldd')
% OUTPUT           :1.Fetching required data 
% DATE OF CREATION :25th May 2020
% REVESION NO      :-
% STATUS           :Function has been written to call in "ModelData" and "FindInModel" script 
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [ModelName,SeperatingPathOfSldd,errorCode,GetmodelPath] =ModelFoundInProjectFolder(sldd_path)
%initialization
errorCode="5000";
StorefileList={};
CreateModelPath={};
%Separating sldd path and project path
SeperatingPathOfSldd=split(sldd_path,',');
%Checking model is present on sldd path
MatchPatternForDefine = '\w*.sldd\w*';
SplitSlddPath = regexp(SeperatingPathOfSldd{1},MatchPatternForDefine,'split');
FileInDir=dir(SplitSlddPath{1});
StorePosOfModel = zeros(1, length(FileInDir));  %Preallocation of memory
% Loop is used to check simulink model is present on sldd path
for Index = 1:length(FileInDir)
    if ischar(FileInDir(Index).name)
        StorePosOfModel(Index) = contains(FileInDir(Index).name,'slx');
    end
end

%Creating path of model if model present on sldd path
if nnz(StorePosOfModel)>0
    strSplit=split(SeperatingPathOfSldd{1},".sldd");Appendstr='.slx';  %Split sldd path at .sldd extension
    model_path=strcat(strSplit,Appendstr);               %Append .slx in place of .sldd path to create model path
    GetmodelPath=char(model_path(1));
    MatchPatternForCalibration = '\w*.slx\w*';
    ModelName = regexp(GetmodelPath,MatchPatternForCalibration,'match');
    ModelName = strtok(ModelName,'.');                   %Get only name of model(Not full path of model)
else
        if ~nnz(StorePosOfModel)>0                     % If simulink model is present at any place inside project folder
                strSplit=split(SeperatingPathOfSldd{1},".sldd");Appendstr='.slx';  %Split sldd path at .sldd extension
                model_path=strcat(strSplit,Appendstr);               %Append .slx instead of .sldd path to create model path
                GetmodelPath=char(model_path(1));
                MatchPatternForCalibration = '\w*.slx\w*';
                ModelName = regexp(GetmodelPath,MatchPatternForCalibration,'match');
                ModelName = strtok(ModelName,'.'); 
                SplitPathOfSldd=split(SeperatingPathOfSldd{1},'/');  %Split sldd path at '/'
                SplitExtensionOfSldd=split(SplitPathOfSldd(end),'.sldd'); %Split sldd name at '.sldd'
                NameOfModel=strcat(SplitExtensionOfSldd,Appendstr); %Create model name 
                fileList = dir(strcat(SeperatingPathOfSldd{2},'\**\*.slx')); %Get list of files present in project folder
                    for CountOffileList=1:length(fileList)                       %Loop used to store path of files present in project folder
                        StorefileList{CountOffileList}=fileList(CountOffileList).name;
                        CreateModelPath{CountOffileList}=strcat(fileList(CountOffileList).folder,'\',fileList(CountOffileList).name);
                    end
                [ModelFoundInProjectFolder]=contains(StorefileList,NameOfModel(1)); %Checking model is present in project folder or not
                FindPathOfModelFromProjectFolder=find(ModelFoundInProjectFolder); %Get position of path
                  if nnz(ModelFoundInProjectFolder)                               %If model present in project folder
                     GetmodelPath=CreateModelPath(FindPathOfModelFromProjectFolder); %Get path of model
                  else
                        %if model not available in project folder
                        errorCode = "114";                        
                        return;
                  end
        end
end
end