%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :Check_Components_Inputs
% MAIN PURPOSE     :Function is used to compare inputs of single sldd with outpus of all sldd present in project folder and 
%                   1.Display a list of all the selected component�s inputs that have different 
%                     attribute values from their corresponding output.
%                   2.Display a list of all the selected component�s inputs that do not have a 
%                     corresponding output data object.
% INPUT(S)         :1.componentName=('C:\Users\shubhangim1\Music\E39_example')
%                   2.slddpath=struct('Name','D:/KPIT_SVN/Data_Dictionary_Project/E39_example/AirManagement/aserc/Model/aserc.sldd')
% OUTPUT           :1.Display following list
%                     1. Inconsistant I/Os 
%                     2. Unconnected Inputs OR
%                   2.If list (1) is empty, will send "errorCode:116" and 
%                     If list (2) is empty, will send "errorCode:117"
% DATE OF CREATION :19th July 2019
% REVESION NO      :1.5
% STATUS           :Rev. 1.1: Tested for following list 
%                             1.Inconsistant I/Os 
%                             2.Unconnected Inputs
%                        1.2: IO Compatibility checks fail to identify
%                             differences-To resolve this issue code
%                             restructuring done for list (1)
%                        1.3: IO compatibility identifies hidden attribute
%                             diff but doesn't display diff-Issue has been fixed
%                        1.4: Code refactring has been done for both lists-Storing all lists in the form of structure
%                        1.5: dicObj and dicSec are replaced with myDictionaryObj and dDataSectObj for naming consistency.
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [IODiffAttr] = Check_Components_Inputs(componentName,slddpath)
%Add project folder and subfolders to path
addpath(genpath(componentName))
DirPath = dir(fullfile(componentName,'**\*.sldd'));
fileList = strcat({DirPath.folder}, {'\'},{DirPath.name});
%If sldd path(s) not received send error code 
if isempty(fileList)
    errorCode = [102];
    IODiffAttr = (table(errorCode));
    return;
end
fields_present = {'Description','DataType','Min','Max','Unit','InitialValue','Dimensions','DimensionsMode',...
    'Complexity','SampleTime','StorageClass','SwCalibrationAccess','DisplayFormat'}';
              
sldd=slddpath.Name;
expression = '/';
SlddPathSplit = regexp(sldd,expression,'split');
sldd_name=SlddPathSplit(end);

%Checking top sldd is present or not
if nnz(contains(fileList,'top.sldd')>0)
    fileList = {'top.sldd'};
    [AllInputObjName,AllInputObjComponent, AllOutputObjName,AllOutputObjComponent, AllInputObjStrct, AllOutputObjStrct] = DataInputOutputSig(fileList,sldd_name); %Function call
else
    [AllInputObjName,AllInputObjComponent, AllOutputObjName,AllOutputObjComponent, AllInputObjStrct, AllOutputObjStrct] = DataInputOutputSig(fileList,sldd_name); %Function call
end

%If input data object is not present in sldd
if  (AllInputObjName == "")
     errorCode = "190";
     IODiffAttr = (table(errorCode));
     return;
end

%Checking for same I/O data object name
AllInputObjName = AllInputObjName';
AllInputObjComponent = AllInputObjComponent';
AllOutputObjName=AllOutputObjName';
AllOutputObjComponent=AllOutputObjComponent';

%Implementation for List (1)
% Same I/O but Diff Attribute Values
%Checking similar I/O data objects
cntr2 = 1;
StructInput=struct('warning','Inconsistent I/Os','Name',"",'component',"",'category','Input','Description',"",...
                    'Basetype',"",'Offset',"",'slope',"",'Min',0,'Max',0,...
                    'Unit',"",'Dimensions',"",...
                    'DimensionsMode',"",'Complexity',"",...
                    'SampleTime',"",'InitialValue',"",...
                    'Coderinfo','','SwCalibrationAccess',"",'DisplayFormat',"",'Value',"Null",'hidden','<consistent>');
StructOutput=struct('warning','Inconsistent I/Os','Name',"",'component',"",'category','Input','Description',"",...
                    'Basetype',"",'Offset',"",'slope',"",'Min',0,'Max',0,...
                    'Unit',"",'Dimensions',"",...
                    'DimensionsMode',"",'Complexity',"",...
                    'SampleTime',"",'InitialValue',"",...
                    'Coderinfo','','SwCalibrationAccess',"",'DisplayFormat',"",'Value',"Null",'hidden','<consistent>');

flagset = 0;
[LogclData, pos] = ismember(AllInputObjName,AllOutputObjName);
for ObjectCounter = 1:length(AllInputObjName)
    if (LogclData(ObjectCounter) > 0)
		flagset = 1;
        for fileds_Chk = 1: length(fields_present)
            if strcmp(fields_present(fileds_Chk),'Min') || strcmp(fields_present(fileds_Chk),'Max')
                if (isempty(AllInputObjStrct(ObjectCounter).SignalDet.(fields_present{fileds_Chk})) && isempty(AllOutputObjStrct(pos(ObjectCounter)).SignalDet.(fields_present{fileds_Chk})))
                    AllInputObjStrct(ObjectCounter).SignalDet.(fields_present{fileds_Chk})=1.111111111111111e+104;
                    AllOutputObjStrct(pos(ObjectCounter)).SignalDet.(fields_present{fileds_Chk})=1.111111111111111e+104;
                end
            end
            if ~isequal((AllInputObjStrct(ObjectCounter).SignalDet.(fields_present{fileds_Chk})),(AllOutputObjStrct(pos(ObjectCounter)).SignalDet.(fields_present{fileds_Chk})))%Checking the inconsistency of attribute
                if strcmp(fields_present(fileds_Chk),'Min') || strcmp(fields_present(fileds_Chk),'Max')
                    if isempty(AllInputObjStrct(ObjectCounter).SignalDet.(fields_present{fileds_Chk}))
                        AllInputObjStrct(ObjectCounter).SignalDet.(fields_present{fileds_Chk})=1.111111111111111e+104;
                    end
                    if isempty(AllOutputObjStrct(pos(ObjectCounter)).SignalDet.(fields_present{fileds_Chk}))
                        AllOutputObjStrct(pos(ObjectCounter)).SignalDet.(fields_present{fileds_Chk})=1.111111111111111e+104;
                    end

                    [BasetypeInput,OffsetIn, slopeIn] = SlddtoUI_AbstractDataType(string(AllInputObjStrct(ObjectCounter).SignalDet.DataType));         %Get BastType,slope,Offset of input
                    [BasetypeOutput,OffsetOut, slopeOut] = SlddtoUI_AbstractDataType(string(AllOutputObjStrct(pos(ObjectCounter)).SignalDet.DataType));%Get BastType,slope,Offset of output

                    StructInput(cntr2)=struct('warning','Inconsistent I/Os','Name',AllInputObjName(ObjectCounter),'component',AllInputObjComponent(ObjectCounter),'category','Input','Description',AllInputObjStrct(ObjectCounter).SignalDet.Description,...
                    'Basetype',BasetypeInput,'Offset',OffsetIn,'slope',slopeIn,'Min',AllInputObjStrct(ObjectCounter).SignalDet.Min,'Max',AllInputObjStrct(ObjectCounter).SignalDet.Max,...
                    'Unit',AllInputObjStrct(ObjectCounter).SignalDet.Unit,'Dimensions',AllInputObjStrct(ObjectCounter).SignalDet.Dimensions,...
                    'DimensionsMode',AllInputObjStrct(ObjectCounter).SignalDet.DimensionsMode,'Complexity',AllInputObjStrct(ObjectCounter).SignalDet.Complexity,...
                    'SampleTime',AllInputObjStrct(ObjectCounter).SignalDet.SampleTime,'InitialValue',AllInputObjStrct(ObjectCounter).SignalDet.InitialValue,...
                    'Coderinfo',AllInputObjStrct(ObjectCounter).SignalDet.StorageClass,'SwCalibrationAccess',AllInputObjStrct(ObjectCounter).SignalDet.SwCalibrationAccess,'DisplayFormat',AllInputObjStrct(ObjectCounter).SignalDet.DisplayFormat,'Value',"Null",'hidden','<consistent>');

                    StructOutput(cntr2)=struct('warning','Inconsistent I/Os','Name',AllOutputObjName(pos(ObjectCounter)),'component',AllOutputObjComponent(pos(ObjectCounter)),'category','Output','Description',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Description,...
                    'Basetype',BasetypeOutput,'Offset',OffsetOut,'slope',slopeOut,'Min',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Min,'Max',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Max,...
                    'Unit',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Unit,'Dimensions',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Dimensions,...
                    'DimensionsMode',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.DimensionsMode,'Complexity',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Complexity,...
                    'SampleTime',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.SampleTime,'InitialValue',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.InitialValue,...
                    'Coderinfo',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.StorageClass,'SwCalibrationAccess',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.SwCalibrationAccess,'DisplayFormat',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.DisplayFormat,'Value',"Null",'hidden','<consistent>');
                end
                if strcmp(fields_present(fileds_Chk),'DataType')
                    [BasetypeInput,OffsetIn, slopeIn] = SlddtoUI_AbstractDataType(string(AllInputObjStrct(ObjectCounter).SignalDet.(fields_present{fileds_Chk})));         %Get BastType,slope,Offset of input
                    [BasetypeOutput,OffsetOut, slopeOut] = SlddtoUI_AbstractDataType(string(AllOutputObjStrct(pos(ObjectCounter)).SignalDet.(fields_present{fileds_Chk})));%Get BastType,slope,Offset of output
                    if ~isequal(BasetypeInput,BasetypeOutput)||~isequal(OffsetIn,OffsetOut)||~isequal(slopeIn,slopeOut) %Checking BastType,slope,Offset of input and output are inconsistent or not
						
						StructInput(cntr2)=struct('warning','Inconsistent I/Os','Name',AllInputObjName(ObjectCounter),'component',AllInputObjComponent(ObjectCounter),'category','Input','Description',AllInputObjStrct(ObjectCounter).SignalDet.Description,...
						'Basetype',BasetypeInput,'Offset',OffsetIn,'slope',slopeIn,'Min',AllInputObjStrct(ObjectCounter).SignalDet.Min,'Max',AllInputObjStrct(ObjectCounter).SignalDet.Max,...
						'Unit',AllInputObjStrct(ObjectCounter).SignalDet.Unit,'Dimensions',AllInputObjStrct(ObjectCounter).SignalDet.Dimensions,...
						'DimensionsMode',AllInputObjStrct(ObjectCounter).SignalDet.DimensionsMode,'Complexity',AllInputObjStrct(ObjectCounter).SignalDet.Complexity,...
						'SampleTime',AllInputObjStrct(ObjectCounter).SignalDet.SampleTime,'InitialValue',AllInputObjStrct(ObjectCounter).SignalDet.InitialValue,...
						'Coderinfo',AllInputObjStrct(ObjectCounter).SignalDet.StorageClass,'SwCalibrationAccess',AllInputObjStrct(ObjectCounter).SignalDet.SwCalibrationAccess,'DisplayFormat',AllInputObjStrct(ObjectCounter).SignalDet.DisplayFormat,'Value',"Null",'hidden','<consistent>');
						
						StructOutput(cntr2)=struct('warning','Inconsistent I/Os','Name',AllOutputObjName(pos(ObjectCounter)),'component',AllOutputObjComponent(pos(ObjectCounter)),'category','Output','Description',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Description,...
						'Basetype',BasetypeOutput,'Offset',OffsetOut,'slope',slopeOut,'Min',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Min,'Max',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Max,...
						'Unit',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Unit,'Dimensions',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Dimensions,...
						'DimensionsMode',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.DimensionsMode,'Complexity',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Complexity,...
						'SampleTime',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.SampleTime,'InitialValue',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.InitialValue,...
						'Coderinfo',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.StorageClass,'SwCalibrationAccess',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.SwCalibrationAccess,'DisplayFormat',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.DisplayFormat,'Value',"Null",'hidden','<consistent>');
						%cntr2 = cntr2+1;
                    end
                end  
                if strcmp(fields_present(fileds_Chk),'Description') || strcmp(fields_present(fileds_Chk),'Unit') || strcmp(fields_present(fileds_Chk),'InitialValue') || strcmp(fields_present(fileds_Chk),'Dimensions')
                    DataType = AllInputObjStrct(ObjectCounter).SignalDet.DataType;
                    [BasetypeI, OffsetI, slopeI] = SlddtoUI_AbstractDataType(string(DataType));

                    StructInput(cntr2)=struct('warning','Inconsistent I/Os','Name',AllInputObjName(ObjectCounter),'component',AllInputObjComponent(ObjectCounter),'category','Input','Description',AllInputObjStrct(ObjectCounter).SignalDet.Description,...
                        'Basetype',BasetypeI,'Offset',OffsetI,'slope',slopeI,'Min',AllInputObjStrct(ObjectCounter).SignalDet.Min,'Max',AllInputObjStrct(ObjectCounter).SignalDet.Max,...
                        'Unit',AllInputObjStrct(ObjectCounter).SignalDet.Unit,'Dimensions',AllInputObjStrct(ObjectCounter).SignalDet.Dimensions,...
                        'DimensionsMode',AllInputObjStrct(ObjectCounter).SignalDet.DimensionsMode,'Complexity',AllInputObjStrct(ObjectCounter).SignalDet.Complexity,...
                        'SampleTime',AllInputObjStrct(ObjectCounter).SignalDet.SampleTime,'InitialValue',AllInputObjStrct(ObjectCounter).SignalDet.InitialValue,...
                        'Coderinfo',AllInputObjStrct(ObjectCounter).SignalDet.StorageClass,'SwCalibrationAccess',AllInputObjStrct(ObjectCounter).SignalDet.SwCalibrationAccess,'DisplayFormat',AllInputObjStrct(ObjectCounter).SignalDet.DisplayFormat,'Value',"Null",'hidden','<consistent>');

                    DataType = AllOutputObjStrct(pos(ObjectCounter)).SignalDet.DataType;
                    [BasetypeO, OffsetO, slopeO] = SlddtoUI_AbstractDataType(string(DataType));


                     StructOutput(cntr2)=struct('warning','Inconsistent I/Os','Name',AllOutputObjName(pos(ObjectCounter)),'component',AllOutputObjComponent(pos(ObjectCounter)),'category','Output','Description',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Description,...
                        'Basetype',BasetypeO,'Offset',OffsetO,'slope',slopeO,'Min',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Min,'Max',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Max,...
                        'Unit',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Unit,'Dimensions',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Dimensions,...
                        'DimensionsMode',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.DimensionsMode,'Complexity',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Complexity,...
                        'SampleTime',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.SampleTime,'InitialValue',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.InitialValue,...
                        'Coderinfo',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.StorageClass,'SwCalibrationAccess',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.SwCalibrationAccess,'DisplayFormat',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.DisplayFormat,'Value',"Null",'hidden','<consistent>');
                end
                if strcmp(fields_present(fileds_Chk),'DimensionsMode') || strcmp(fields_present(fileds_Chk),'Complexity') || strcmp(fields_present(fileds_Chk),'SampleTime') || strcmp(fields_present(fileds_Chk),'StorageClass') || strcmp(fields_present(fileds_Chk),'SwCalibrationAccess') || strcmp(fields_present(fileds_Chk),'DisplayFormat')%This if condition is needs to separate to fix "IO compatibility identifies hidden attribute diff but doesn't display diff" issue
                    DataType = AllInputObjStrct(ObjectCounter).SignalDet.DataType;
                    [BasetypeI, OffsetI, slopeI] = SlddtoUI_AbstractDataType(string(DataType));

                    StructInput(cntr2)=struct('warning','Inconsistent I/Os','Name',AllInputObjName(ObjectCounter),'component',AllInputObjComponent(ObjectCounter),'category','Input','Description',AllInputObjStrct(ObjectCounter).SignalDet.Description,...
                        'Basetype',BasetypeI,'Offset',OffsetI,'slope',slopeI,'Min',AllInputObjStrct(ObjectCounter).SignalDet.Min,'Max',AllInputObjStrct(ObjectCounter).SignalDet.Max,...
                        'Unit',AllInputObjStrct(ObjectCounter).SignalDet.Unit,'Dimensions',AllInputObjStrct(ObjectCounter).SignalDet.Dimensions,...
                        'DimensionsMode',AllInputObjStrct(ObjectCounter).SignalDet.DimensionsMode,'Complexity',AllInputObjStrct(ObjectCounter).SignalDet.Complexity,...
                        'SampleTime',AllInputObjStrct(ObjectCounter).SignalDet.SampleTime,'InitialValue',AllInputObjStrct(ObjectCounter).SignalDet.InitialValue,...
                        'Coderinfo',AllInputObjStrct(ObjectCounter).SignalDet.StorageClass,'SwCalibrationAccess',AllInputObjStrct(ObjectCounter).SignalDet.SwCalibrationAccess,'DisplayFormat',AllInputObjStrct(ObjectCounter).SignalDet.DisplayFormat,'Value',"Null",'hidden','<inconsistent>');

                    DataType = AllOutputObjStrct(pos(ObjectCounter)).SignalDet.DataType;
                    [BasetypeO, OffsetO, slopeO] = SlddtoUI_AbstractDataType(string(DataType));


                    StructOutput(cntr2)=struct('warning','Inconsistent I/Os','Name',AllOutputObjName(pos(ObjectCounter)),'component',AllOutputObjComponent(pos(ObjectCounter)),'category','Output','Description',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Description,...
                    'Basetype',BasetypeO,'Offset',OffsetO,'slope',slopeO,'Min',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Min,'Max',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Max,...
                    'Unit',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Unit,'Dimensions',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Dimensions,...
                    'DimensionsMode',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.DimensionsMode,'Complexity',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Complexity,...
                    'SampleTime',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.SampleTime,'InitialValue',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.InitialValue,...
                    'Coderinfo',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.StorageClass,'SwCalibrationAccess',"ReadOnly",'DisplayFormat',"Null",'Value',"Null",'hidden','<inconsistent>'); 
                end
            end
        end
		if flagset == 1
			cntr2 = cntr2+1;
		end
    end
	flagset = 0;
end
%Remove empty rows from structure
StructOutput( all( cell2mat( arrayfun( @(x) structfun( @isempty, x ), StructOutput, 'UniformOutput', false ) ), 1 ) ) = [];
StructInput( all( cell2mat( arrayfun( @(x) structfun( @isempty, x ), StructInput, 'UniformOutput', false ) ), 1 ) ) = [];
% Convert structures to tables
InconsistentIn=struct2table(StructInput,'AsArray',true);
InconsistentOut=struct2table(StructOutput,'AsArray',true);
%Combine both structure
CombineStruct=vertcat(InconsistentIn,InconsistentOut);
CheckStatus=CombineStruct(:,2).Name;
if CheckStatus==""
 errorCode = [116];
 IODiffAttr1 = (table(errorCode));
else
 IODiffAttr1=CombineStruct;
end  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Implementation for List(2)
%Checking list of input data objects do not have output
cntr3=1;
StructInputOutputNotFindinput=struct('warning','Unconnected Inputs','Name',"",'component',"",'category','Input','Description',"",...
                    'Basetype',"",'Offset',"",'slope',"",'Min',0,'Max',0,...
                    'Unit',"",'Dimensions',"",...
                    'DimensionsMode',"",'Complexity',"",...
                    'SampleTime',"",'InitialValue',"",...
                    'Coderinfo','','SwCalibrationAccess',"",'DisplayFormat',"",'Value',"Null",'hidden','<na>');
[InputDobj, datainp] = setdiff(AllInputObjName,AllOutputObjName,'stable');
if isempty(InputDobj)
    errorCode = "117";
    IODiffAttr2 = (table(errorCode));
else
    for ObjectCounter2 = 1:length(datainp)
        DataType = AllInputObjStrct(datainp(ObjectCounter2)).SignalDet.DataType;
        [Basetype, Offset, slope] = SlddtoUI_AbstractDataType(string(DataType));
        
        StructInputOutputNotFindinput(cntr3)=struct('warning','Unconnected Inputs','Name',AllInputObjName(datainp(ObjectCounter2)),'component',AllInputObjComponent(datainp(ObjectCounter2)),'category','Input','Description',AllInputObjStrct(datainp(ObjectCounter2)).SignalDet.Description,...
        'Basetype',Basetype,'Offset',Offset,'slope',slope,'Min',AllInputObjStrct(datainp(ObjectCounter2)).SignalDet.Min,'Max',AllInputObjStrct(datainp(ObjectCounter2)).SignalDet.Max,...
        'Unit',AllInputObjStrct(datainp(ObjectCounter2)).SignalDet.Unit,'Dimensions',AllInputObjStrct(datainp(ObjectCounter2)).SignalDet.Dimensions,...
        'DimensionsMode',AllInputObjStrct(datainp(ObjectCounter2)).SignalDet.DimensionsMode,'Complexity',AllInputObjStrct(datainp(ObjectCounter2)).SignalDet.Complexity,...
        'SampleTime',AllInputObjStrct(datainp(ObjectCounter2)).SignalDet.SampleTime,'InitialValue',AllInputObjStrct(datainp(ObjectCounter2)).SignalDet.InitialValue,...
        'Coderinfo',AllInputObjStrct(datainp(ObjectCounter2)).SignalDet.StorageClass,'SwCalibrationAccess',AllInputObjStrct(datainp(ObjectCounter2)).SignalDet.SwCalibrationAccess,'DisplayFormat',AllInputObjStrct(datainp(ObjectCounter2)).SignalDet.DisplayFormat,'Value',"Null",'hidden','<na>');
        cntr3=cntr3+1;
    end
    IODiffAttr2=struct2table(StructInputOutputNotFindinput,'AsArray',true);
end
IODiffAttr{1,:} = IODiffAttr1;
IODiffAttr{2,:} = IODiffAttr2;

function [AllInputObjName, AllInputObjComponent,AllOutputObjName,AllOutputObjComponent, AllInputObjStrct, AllOutputObjStrct] = DataInputOutputSig(fileList,sldd_name)
InputDobjCntr = 1;
OutputDobjCntr = 1;
AllInputObjName="";
AllInputObjComponent="";
AllOutputObjName="";
AllOutputObjComponent="";
AllInputObjStrct = struct('DataObjName','', 'CompName','','SignalDet','');
AllOutputObjStrct = struct('DataObjName','','CompName','','SignalDet','');
% Logic written for loading indicator
if contains(fileList,'top.sldd')
    LoadingIndicator = waitbar(0,'Please wait while data is being fetched from Top.sldd','Name','Checking component inputs...','WindowStyle', 'modal');
    frames = java.awt.Frame.getFrames();
    frames(end).setAlwaysOnTop(1);
    javaFrame = get(LoadingIndicator,'JavaFrame');
    ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
    javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));
    flag1 = 1;
else
     LoadingIndicator = waitbar(0,'Please wait while Check component inputs list is being loaded','Name','Checking component inputs...','WindowStyle', 'modal');
     frames = java.awt.Frame.getFrames();
     frames(end).setAlwaysOnTop(1);
     javaFrame = get(LoadingIndicator,'JavaFrame');
     ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
     javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));
     flag1 = 0;
end

%Fetching AUTOSAR.Signal from sldd 
for DataCntrSlddFile=1:length(fileList)
    myDictionaryObj = Simulink.data.dictionary.open((char(fileList(DataCntrSlddFile))));
    dDataSectObj = getSection(myDictionaryObj,'Design Data');
    DataObj =  find(dDataSectObj,'-value','-class','AUTOSAR.Signal');
    if isempty(DataObj)
       DataObj =  find(dDataSectObj,'-value','-class','Simulink.Signal');
    end
    % Logic written for loading indicator
    if contains(fileList,'top.sldd')
        waitbar(length(fileList),LoadingIndicator,sprintf('Please wait while data is being fetched from Top.sldd %1.0f%%',(length(fileList)*100)))  
        flag1 = 1;
        close(LoadingIndicator)
        LoadingIndicator = waitbar(0,'Please wait while Check component inputs list is being loaded ','Name','Checking component inputs...','WindowStyle', 'modal');
        frames = java.awt.Frame.getFrames();
        frames(end).setAlwaysOnTop(1);
        javaFrame = get(LoadingIndicator,'JavaFrame');
        ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
        javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));
    else
        waitbar(DataCntrSlddFile/length(fileList),LoadingIndicator,sprintf('Please wait while check component inputs list is being loaded %1.0f%%',(DataCntrSlddFile/length(fileList)*100)))  
    end

    %Loop to get all attributes of each I/O data object
    CategoryTemp1="";
    for Index = 1:length(DataObj)
        format short
        ValueStructTemp = DataObj(Index).getValue;
        if ~isnumeric(ValueStructTemp)&&~ischar(ValueStructTemp)&&~isstring(ValueStructTemp)
            GetFields=fields(ValueStructTemp);               %Get fields of data object
            log_array = ismember(GetFields,'objectType'); %Check data object having object type
            varv = nnz(log_array);
            if varv==1
                CategoryTemp = ValueStructTemp.objectType;
                CategoryTemp1(Index,1) = string(ValueStructTemp.objectType);
                if strcmp(string(DataObj(Index).DataSource),sldd_name)      
                    if ((strcmp(CategoryTemp,'Input')))
                        AllInputObjName(1,InputDobjCntr) = string(DataObj(Index).Name);  
                        AllInputObjComponent(1,InputDobjCntr) = string(strtok(DataObj(Index).DataSource,'.'));  
                        AllInputObjStrct(InputDobjCntr) = struct('DataObjName',string(DataObj(Index).Name), 'CompName',string(DataObj(Index).DataSource),'SignalDet',ValueStructTemp);
                        InputDobjCntr = InputDobjCntr + 1;    
                    end
                end
                if (strcmp(CategoryTemp,'Output'))
                    AllOutputObjName(1,OutputDobjCntr) = string(DataObj(Index).Name) ;  
                    AllOutputObjComponent(1,OutputDobjCntr) = string(strtok(DataObj(Index).DataSource,'.')); 
                    AllOutputObjStrct(OutputDobjCntr) = struct('DataObjName',string(DataObj(Index).Name),'CompName',string(DataObj(Index).DataSource),'SignalDet',ValueStructTemp);
                    OutputDobjCntr = OutputDobjCntr + 1;
                end
            end
        end
        if flag1 
            waitbar(Index/length(DataObj),LoadingIndicator,sprintf('Please wait while Check component inputs list is being loaded %1.0f%%',(Index/(length(DataObj)))*100))
        end
    end  
    close(myDictionaryObj)
end
close(LoadingIndicator);