%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :UpdateParameterType
% MAIN PURPOSE     :Script is used update parameter object type for Cal, Axis, Curve and Map in simulink data 
%                   dictionaries present in project path. 
% INPUT(S)         :1.componentData=('D:/Navistar_SVN/E95_Projects/398_funde_chwlp/ChassisControl/chwlp/Model/chwlp.sldd,C:/Users/nitind6/AppData/Roaming/MathWorks/MATLAB Add-Ons/Toolboxes/NAVISTAR MBD Toolbox(3)/MatlabScripts/DataDictionaryTool/ConfigObjectType.xlsx,E95')
% OUTPUT           :1.SuccessCode = List of updated data objects (Successful updation of parameter type)
% DATE OF CREATION :8th Mar 2022
% REVESION NO      :1.0
% STATUS           :Rev. 1.0: Tested for updating parameter type for Cal, Axis, Curve and Map to AUTOSAR4.Parameter 
% AUTHOR           :Nitin Dahyalkar
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function SuccessCode = UpdateParameterType(componentData,~)

%Spliting component path, ConfigFilePath and ProgramName from componentData
FilePaths = split(componentData,',');
componentName = FilePaths{1};
ConfigFilePath = FilePaths{2};
ProgramName = FilePaths{3};
%To check user selected project or single component
if contains(componentName,'.sldd')
    componentName = extractBefore(componentName,'/Model');
end
%To add path in the Matlab directory
addpath(genpath(componentName))
DirPath = dir(fullfile(componentName,'**\*.sldd'));
slddPath = strcat({DirPath.folder}, {'\'},{DirPath.name});

%Calling GetConfigurationData function to read attributes defined in configuration excel file 
[ConfigurationData,errorCode] = GetConfigurationData(ConfigFilePath,ProgramName);
if strcmp(errorCode,"1006") || strcmp(errorCode,"1007") 
    SuccessCode = table(errorCode);
    return;
end
%Category fields defined in configuration file
categorys = ConfigurationData.CategoryFields;

%Implementation of LoadingIndicator
if length(slddPath) == 1
    LoadingIndicator1 = waitbar(0,' 1% Completed','Name','Updating Parameter Type....','windowstyle', 'modal');
    frames = java.awt.Frame.getFrames();
    frames(end).setAlwaysOnTop(1);
    javaFrame = get(LoadingIndicator1,'JavaFrame');
    ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
    javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));
else
    LoadingIndicator = waitbar(0,' 1% Completed','Name','Updating Parameter Type....','windowstyle', 'modal');
    frames = java.awt.Frame.getFrames();
    frames(end).setAlwaysOnTop(1);
    javaFrame = get(LoadingIndicator,'JavaFrame');
    ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
    javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));
end
%Structure to store data object's name whose parameter type is getting updated
UpdatedDataObj = struct('warning','Updated Data Objects','Name',"",'category',"");
StrIndex = 1;
pat = {'_C','_X','_Y','_T','_M','_CA'};
for SlddIndex = 1 : length(slddPath)
    myDictionaryObj =Simulink.data.dictionary.open(char(slddPath(SlddIndex)));        %open sldd
    dDataSectObj = getSection(myDictionaryObj,'Design Data');         %get design data from sldd    
    allEntries = find(dDataSectObj);
    num_Of_Entries = length(allEntries);
    for ObjIndex = 1 : num_Of_Entries
        DataObjName = allEntries(ObjIndex).Name;
        AttriInfo = getValue(allEntries(ObjIndex));
        ObjFields = fields(AttriInfo);
        ObjVar = nnz(ismember(ObjFields,'objectType'));
        if ObjVar == 1
            DataObjCat = AttriInfo.objectType; %Get category of data object
            CategoryIndex = find(strcmp(categorys,DataObjCat)); %Get index of category in configuration file
            if (~isequal(class(AttriInfo), 'AUTOSAR4.Parameter') && endsWith(DataObjName, pat))
                %Store data object in structure
                UpdatedDataObj(StrIndex) = struct('warning','Updated Data Objects','Name',DataObjName,'category',DataObjCat);
                StrIndex = StrIndex + 1;
                %Updating parameter type
                add_simulinlk_signal_obj = AUTOSAR4.Parameter; %Updating object type for dat object
                add_simulinlk_signal_obj.addprop('objectType'); % Add 'objectType' property while adding data object
                add_simulinlk_signal_obj.StorageClass = ConfigurationData.StorageClass{CategoryIndex}; %Store storage class 
                add_simulinlk_signal_obj.CoderInfo.CustomAttributes.MemorySection = ConfigurationData.MemorySection{CategoryIndex}; %Store memory section attribute
    
                add_simulinlk_signal_obj.Value = AttriInfo.Value; %Store value of data object 
                add_simulinlk_signal_obj.DataType = AttriInfo.DataType; %Store data type of data object
                add_simulinlk_signal_obj.Description = AttriInfo.Description; %Store description of data object
                add_simulinlk_signal_obj.Dimensions = AttriInfo.Dimensions;
                add_simulinlk_signal_obj.Unit = AttriInfo.Unit;  %store 'Unit' value of data object
                add_simulinlk_signal_obj.objectType = AttriInfo.objectType;  %store 'category' of data object 
                add_simulinlk_signal_obj.Min = AttriInfo.Min; %Store Min value
                add_simulinlk_signal_obj.Max = AttriInfo.Max; %Store Max value
                add_simulinlk_signal_obj.Complexity = AttriInfo.Complexity; %Store Complexity of data object
                
                %SWCalibrationAccess and DisplayFormat attribute
                add_simulinlk_signal_obj.SwCalibrationAccess = ConfigurationData.SwCalibrationAccess{CategoryIndex}; %Store SWCalibration access of data object
    
                deleteEntry(dDataSectObj,DataObjName) %Delete previous entry
                addEntry(dDataSectObj,DataObjName,add_simulinlk_signal_obj) %Add updated entry
                saveChanges(myDictionaryObj) %Save changes
            end
        end
        if isequal(length(slddPath),1)
            waitbar(ObjIndex/num_Of_Entries,LoadingIndicator1,sprintf(' %1.0f%% Completed',(ObjIndex/num_Of_Entries)*100))
        end
    end
    if ~isequal(length(slddPath),1)
        waitbar(SlddIndex/length(slddPath),LoadingIndicator,sprintf(' %1.0f%% Completed',(SlddIndex/length(slddPath))*100))
    end
end
if isequal(length(slddPath),1)
    close(LoadingIndicator1)
end    
if ~isequal(length(slddPath),1)    
    close(LoadingIndicator)
end
UpdatDataTable = struct2table(UpdatedDataObj,'AsArray',true);
SuccessCode = {UpdatDataTable};