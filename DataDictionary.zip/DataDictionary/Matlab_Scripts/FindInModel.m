%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :FindInModel
% MAIN PURPOSE     :Function is used to highlight specific data object in
%                   simulink model for all categories.
% INPUT(S)         :1.sldd_path=('C:/Users/shubhangim1/Music/Fresh_Project/E39_example/AirManagement/aserc/Model/aserc.sldd,C:/Users/shubhangim1/Music/Fresh_Project/E39_example/AirManagement')
%                   2.DataObj=('ASERC_flgModeEn')
% OUTPUT           :1.Data object get highlighted in simulink model.
%                   2.Data object found successfully will send "messageCode:503" OR
%                   3.If data object not present in simulink model will send 
%                     "errorCode:109" OR
%                   4.If simulink model not present on sldd path will send
%                     "errorCode:114"
% DATE OF CREATION :10th July 2019
% REVESION NO      :1.5
%                  :Rev.1.1: Tested to highlight data objects of all categories   
%                            (one data object get highlighted at a time)
%                  :Rev.1.2: Tested to highlight data objects of stateflow
%                  :Rev.1.3: Function does not require dependancy of Naming convention of data object.(Previously Calibration(CalName_C) and define(CalName_SC) data object implemented as per naming convension)
%                  :Rev.1.4: NumOfEntries evaluation is changed as program name entry is added in other data section.
%                  :Rev.1.5: OpenSldd,DesignDataSectionObject,AllEntries and NumOfEntries are replaced with myDictionaryObj,dDataSectObj,allEntries and num_Of_Entries for naming consistency. 
% FUNCTION CALL    :
% AUTHOR:          :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [OutputFindInModel] =FindInModel(sldd_path,DataObj)
% User has to change string name if Masktype of block get changed in model
SParameter1='SParameter1';
SParameter2='SParameter2';
SParameter4='SParameter4';
%Initialization
AllPath1={};
DataObjectFix1DLookup_X_Axis={};
AllPath2={};
DataObjectFix2DLookup_X_Axis={};
DataObjectFix2DLookup_Y_Axis={};
AllPath3={};
DataObjectFloat1DLookup_X_Axis={};
AllPath4={};
DataObjectFloat2DLookup_X_Axis={};
DataObjectFloat2DLookup_Y_Axis={};
StorePath1D={};
StoreName1D={};
StorePathPreLookupCurve1={};
StorePathPreLookupCurve={};
StoreTableSpecification={};
StorePreLookupCurve1={};
StorePreLookupCurve={};
StorePath2D={};
StoreName2D={};
StorePathPreLookupMap1={};
StorePathPreLookupMap={};
StorePreLookupMap1={};
StorePreLookupMap={};
StorePreLookupAxisPath={};
StorePreLookupAxisPath1={};
StorePreLookupAxis={};
StorePreLookupAxis1={};
Store_AxisObj_1D={};
Store_Y_Axis_2D_Map={};
StorePath_2D={};
StorePath_Axis_2D={};
Store_X_Axis_2D_Map1={};
Store_X_Axis_2D_Map={};
Store_Y_Axis_2D_Map1={};
StorePath_AxisObj_1D={};
OutputFindInModel={};
DataObjCalibDef={};
UniqueDataObjCalibDef={};
FoundStateflowChart="";
StateflowChart="";
ChartTransitions="";
ChartState="";
AllPathInput="";
flag=0;

% Checking availability of simulink model on sldd's path
[ModelName,SeperatingPathOfSldd,errorCode,GetmodelPath] =ModelFoundInProjectFolder(sldd_path);
%if model not available in project folder
if strcmp(errorCode,'114')
    OutputFindInModel=table(errorCode);
    return;
else
    GetModelPath=GetmodelPath;
end

% Open sldd to fetch data from it
% Simulink.data.dictionary.closeAll
myDictionaryObj = Simulink.data.dictionary.open(SeperatingPathOfSldd{1});
dDataSectObj = getSection(myDictionaryObj,'Design Data');
allEntries = find(dDataSectObj);
num_Of_Entries = length(allEntries);
DataObjectCategories = 'NoCategory';

%Implementation of loading indicator
%LoadingIndicator start
%Set LoadingIndicator always on top of screen
LoadingIndicator = waitbar(0,' 0% Completed','Name','Finding data object in model...','WindowStyle', 'modal');
Frames = java.awt.Frame.getFrames();
Frames(end).setAlwaysOnTop(1);
%Set data dictionary icon on LoadingIndicator 
javaFrame = get(LoadingIndicator,'JavaFrame');
ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));
    
%Loop is use to get data object name and respective category
for Entry=1:num_Of_Entries
     if strcmp(allEntries(Entry).Name,DataObj)
        Attributes=getValue(allEntries(Entry));      
        DataObjectCategories=Attributes.objectType;
     end
     waitbar(Entry/num_Of_Entries,LoadingIndicator,sprintf(' %1.0f%% Completed',((Entry/num_Of_Entries))*100)) %Calculating percentage Completed on LoadingIndicator
end

%If Data object category not found will send error code:109
if strcmp(DataObjectCategories,"NoCategory")
   errorCode = 109;
   OutputFindInModel=table(errorCode); 
   close(LoadingIndicator)             %Close LoadingIndicator
   return;
end
    
%Precaution has been taken if model loaded previously, because same name model cannot open from other path 
try
    load_system(GetModelPath)
catch Message
      Exception=Message;
      modelData={Exception.message};       %if model loaded previously then Exception Message displsy corrective action needs to take
      OutputFindInModel=table(modelData);
      close(LoadingIndicator)              %Closing LoadingIndicator
      return;
end
    
%Unhighlighting previously highlighted block
HighlightedBlockes = find_system(ModelName,'BackgroundColor','yellow');
% Pass block list of hilite_system to switch 'off' color.�
hilite_system(HighlightedBlockes,'off');
SLStudio.Utils.RemoveHighlighting(get_param(bdroot,'handle'))%Remove highlighting of local data object        
%Function call to find path of all data objects present in model
[FoundStateflowChart,StateflowChart,UniqueDataObjCalibDef,~,~,LocalObjStateflow,ChartTransitions,ChartState,AllPathInput,AllPathOutput,AllPathLocal,AllPathDefineCalib,ConstantPath_First_Order_Transfer_Fcn,Fix1DLookupPath,Float1DLookupPath,Fix2DLookupPath,Float2DLookupPath,LookupPath,LookupTableName,PreLookupPathMapCurve,PreLookupTableName,PreLookupPath,NvmPath,~,~]= FindPathOfDataObject(ModelName);

% Checking category of data object needs to be found in model
    AllPath='';
    flag2=0;
    switch(DataObjectCategories)
        case 'Input'
                AllPath=AllPathInput;
                KeyToGetParameters='Name';                                  %'Name' is the key to extract Input data object
        case 'Output'   
                AllPath=AllPathOutput;
                KeyToGetParameters='Name';                                  %'Name' is the key to extract Output data object
        case 'Local'
                AllPath=AllPathLocal;
                KeyToGetParameters='Name';                                  %'Name' is the key to extract Local data object
        case 'Define'    
                AllPath=AllPathDefineCalib;
                KeyToGetParameters='Value';                                 %'Value' is the key to extract Define data object
        case 'Calibration'
                if flag2==0                                                 % If data oject present in BlockType: Constant then use this part of code
                    AllPath=AllPathDefineCalib;
                    KeyToGetParameters='Value';                             %'Value' is the key to extract Calibration data object
                    DataObject=get_param(AllPath,KeyToGetParameters);
                    [ChkDataObjIsMem, ~] = ismember(DataObject,DataObj);
                    %If data object present in model but it does not contain stateflow
                    StorePosDtObj = find(ChkDataObjIsMem,1);  % Storing first occuring position of data object in model 
                    if nnz(StorePosDtObj)                     % If position of data object in model found
                        open_system(GetModelPath)             % Open Model
                        hilite_system(AllPath(StorePosDtObj)) % Highlight data object
                        set_param(char(ModelName),'Zoomfactor','fit to view')
                        messageCode = 503;           %Data object found successfully
                        OutputFindInModel=table(messageCode);
                        close(LoadingIndicator)      %Close LoadingIndicator
                        return;
                    elseif isempty(OutputFindInModel)  % If data object present in MaskType:First Order Transfer Fcn then use below code
                            KeyToGetParameters='PoleZ';        %'PoleZ' is the key to extract Calibration data object
                            DataObject=get_param(ConstantPath_First_Order_Transfer_Fcn,KeyToGetParameters);
                            [ChkDataObjIsMem, ~] = ismember(DataObject,DataObj);
                            %If data object present in model but it does not contain stateflow
                            StorePosDtObj = find(ChkDataObjIsMem,1);  % Storing first occuring position of data object in model 
                                if nnz(StorePosDtObj)                     % If position of data object in model found
                                    open_system(GetModelPath)             % Open Model
                                    hilite_system(ConstantPath_First_Order_Transfer_Fcn(StorePosDtObj)) % Highlight data object
                                    set_param(char(ModelName),'Zoomfactor','fit to view')
                                    messageCode = 503;           %Data object found successfully
                                    OutputFindInModel=table(messageCode);
                                    close(LoadingIndicator)      %Close LoadingIndicator
                                    return;
                                else
                                   %If data object present in stateflow
                                        if ~isempty(FoundStateflowChart)
                                            StateflowDataObj=union(UniqueDataObjCalibDef,LocalObjStateflow);  %Combine Calibration,Define and local data object
                                            % Checking received data object is present in stateflow
                                            [ChkDataObjIsMemStateflow, ~] = ismember(StateflowDataObj,DataObj);
                                                if nnz(ChkDataObjIsMemStateflow)
                                                        cntr=1;
                                                        for index=1:length(ChartTransitions)
                                                            LabelStr = cellstr(ChartTransitions(index).LabelString);
                                                            LabelStr = LabelStr(~cellfun('isempty',LabelStr));
                                                            LabelStr=cellstr(string(LabelStr));  %Stateflow Data object of Calibration                             
                                                            if contains(string(cell2mat(LabelStr)),string(cellstr(DataObj)))
                                                                ChartTransitions(index).view;    
                                                                ChartTransitions(index).highlight; %Highlight Stateflow Transition
                                                                break;
                                                            end
                                                            cntr=cntr+1;
                                                        end
                                                        for index2=1:length(ChartState)
                                                            LabelStr = cellstr(ChartState(index2).LabelString);
                                                            LabelStr = LabelStr(~cellfun('isempty',LabelStr));
                                                            LabelStr=cellstr(string(LabelStr));
                                                            if contains(string(cell2mat(LabelStr)),string(cellstr(DataObj)))
                                                                State = StateflowChart.find('-isa','Stateflow.State','Name',ChartState(index2).Name);
                                                                State.view;
                                                                State.highlight;    %Highlight State of Stateflow
                                                            end
                                                        end
                                                    set_param(char(ModelName),'Zoomfactor','fit to view')
                                                    messageCode = 503;           %Data object of stateflow found successfully will send messageCode 503
                                                    OutputFindInModel=table(messageCode);
                                                    close(LoadingIndicator)
                                                    return;
                                                else
                                                    errorCode = 109;                             %If data object not found will send errorCode 109
                                                    OutputFindInModel=table(errorCode);
                                                    close(LoadingIndicator)                      %Close LoadingIndicator
                                                    return;
                                                end
                                        else
                                                errorCode = 109;                             %If data object not found will send errorCode 109
                                                OutputFindInModel=table(errorCode);
                                                close(LoadingIndicator)                      %Close LoadingIndicator
                                                return;
                                        end
                                end
                    else                                            
                        errorCode = 109;                         %If data object not found will send errorCode 109
                        OutputFindInModel=table(errorCode);
                        close(LoadingIndicator)                  %Close LoadingIndicator
                        return;
                    end
                else
                    errorCode = 109;                             %If data object not found will send errorCode 109
                    OutputFindInModel=table(errorCode);
                    close(LoadingIndicator)                      %Close LoadingIndicator
                    return;
                end
            
        case 'Curve'  
                AllPath1=Fix1DLookupPath;
                AllPath2=Float1DLookupPath;
                cntr1 = 1;
                for index4 = 1:length(LookupTableName)
                    if strcmp(char(cellstr(LookupTableName{index4})),'1')
                        StorePath1D{cntr1}=LookupPath{index4};
                        StoreName1D{cntr1} = get_param(LookupPath{index4},'Table');
                        cntr1 = cntr1+1;
                    end
                end
                for index5=1:length(PreLookupTableName)
                    if strcmp(char(cellstr(PreLookupTableName{index5})),'1')
                        StorePathPreLookupCurve1{cntr1}=PreLookupPathMapCurve{index5};
                        StorePathPreLookupCurve = StorePathPreLookupCurve1(~cellfun('isempty', StorePathPreLookupCurve1));
                        StoreTableSpecification = get_param(PreLookupPathMapCurve{index5},'TableSpecification');
                        if strcmp(StoreTableSpecification,'Explicit values')
                            StorePreLookupCurve1{cntr1} = get_param(PreLookupPathMapCurve{index5},'Table'); %For 1D (Curve using prelookup)
                            StorePreLookupCurve = StorePreLookupCurve1(~cellfun('isempty', StorePreLookupCurve1));
                        else
                            StorePreLookupCurve1{cntr1} = get_param(PreLookupPathMapCurve{index5},'LookupTableObject'); %For 1D (Curve using prelookup)
                            StorePreLookupCurve = StorePreLookupCurve1(~cellfun('isempty', StorePreLookupCurve1));
                        end
                        cntr1 = cntr1+1;
                    end
                end
                AllPathFixFloat  = vertcat(AllPath1,AllPath2);   %Concatenate Fix and Float lookup path
                AllPath  = vertcat(AllPath1,AllPath2,StorePath1D',StorePathPreLookupCurve'); % Concatenate Fix,Float,simulink lookup table path
                KeyToGetParameters=SParameter1;                     %'SParameter1' is the key to extract Curve data object
                DataObject=get_param(AllPathFixFloat,KeyToGetParameters); %Get parameter of Fix and Float lookup
                AllDataObject  = vertcat(DataObject,StoreName1D',StorePreLookupCurve'); %Concatenate Fix,Float,simulink lookup table data object
       
                % Checking received data object is present in simulink model
                [ChkDataObjIsMem, ~] = ismember(AllDataObject,DataObj);
                % Storing first occuring position of data object in model
                StorePosDtObj = find(ChkDataObjIsMem,1);
                if nnz(StorePosDtObj)                            %If position of data object in model found
                    open_system(GetModelPath)                    %Open Model
                    hilite_system(AllPath(StorePosDtObj))    %Highlight data object
                    set_param(char(ModelName),'Zoomfactor','fit to view')
                    messageCode = 503;                           %Data object found successfully will send messageCode 503
                    OutputFindInModel=table(messageCode);
                    close(LoadingIndicator)                      %Close LoadingIndicator
                    return;
                else
                    errorCode = 109;                             %If data object not found will send errorCode 109
                    OutputFindInModel=table(errorCode);
                    close(LoadingIndicator)                      %Close LoadingIndicator
                    return;
                end
        case 'Map' 
                AllPath1=Fix2DLookupPath;
                AllPath2=Float2DLookupPath;
                cntr1 = 1;
                for index4 = 1:length(LookupTableName)
                    if strcmp(char(cellstr(LookupTableName{index4})),'2')
                        StorePath2D{cntr1}=LookupPath{index4};
                        StoreName2D{cntr1} = get_param(LookupPath{index4},'Table');
                        cntr1 = cntr1+1;
                    end
                end
                for index5=1:length(PreLookupTableName)
                    if strcmp(char(cellstr(PreLookupTableName{index5})),'2')
                        StorePathPreLookupMap1{cntr1}=PreLookupPathMapCurve{index5};
                        StorePathPreLookupMap = StorePathPreLookupMap1(~cellfun('isempty', StorePathPreLookupMap1));
                        StorePreLookupMap1{cntr1} = get_param(PreLookupPathMapCurve{index5},'Table'); %For 1D (Curve using prelookup)
                        StorePreLookupMap = StorePreLookupMap1(~cellfun('isempty', StorePreLookupMap1));
                        cntr1 = cntr1+1;
                    end
                end
                AllPathFixFloat  = vertcat(AllPath1,AllPath2);   %Concatenate Fix and Float lookup path
                AllPath  = vertcat(AllPath1,AllPath2,StorePath2D',StorePathPreLookupMap'); % Concatenate Fix,Float,simulink lookup table path
                KeyToGetParameters=SParameter1;                     %'SParameter1' is the key to extract Curve data object
                DataObject=get_param(AllPathFixFloat,KeyToGetParameters); %Get parameter of Fix and Float lookup
                AllDataObject  = vertcat(DataObject,StoreName2D',StorePreLookupMap'); %Concatenate Fix,Float,simulink lookup table data object
                % Checking received data object is present in simulink model
                [ChkDataObjIsMem, ~] = ismember(AllDataObject,DataObj);
                % Storing first occuring position of data object in model
                StorePosDtObj = find(ChkDataObjIsMem,1);
                if nnz(StorePosDtObj)                            %If position of data object in model found
                    open_system(GetModelPath)                    %Open Model
                    hilite_system(AllPath(StorePosDtObj))    %Highlight data object
                    set_param(char(ModelName),'Zoomfactor','fit to view')
                    messageCode = 503;                           %Data object found successfully will send messageCode 503
                    OutputFindInModel=table(messageCode);
                    close(LoadingIndicator)                      %Close LoadingIndicator
                    return;
                else
                    errorCode = 109;                             %If data object not found will send errorCode 109
                    OutputFindInModel=table(errorCode);
                    close(LoadingIndicator)                      %Close LoadingIndicator
                    return;
                end
        case 'Axis'
            AllPath1=Fix1DLookupPath;
            DataObjectFix1DLookup_X_Axis=get_param(AllPath1,SParameter2);                      %Get X Axis DataObj for Fix 1D Lookup Table
            
            AllPath2=Fix2DLookupPath;
            DataObjectFix2DLookup_X_Axis=get_param(AllPath2,SParameter4);                      %Get X Axis DataObj for Fix 2D Lookup Table
            DataObjectFix2DLookup_Y_Axis=get_param(AllPath2,SParameter2);                      %Get Y Axis DataObj for fix 2D Lookup Table
            AllStructDataFix2DLookup_X_Axis=struct2table(struct('DataObjectFix2DLookup_X_Axis',DataObjectFix2DLookup_X_Axis,'AllPath2',AllPath2));
            AllStructDataFix2DLookup_Y_Axis=struct2table(struct('DataObjectFix2DLookup_Y_Axis',DataObjectFix2DLookup_Y_Axis,'AllPath2',AllPath2));
            
            AllPath3=Float1DLookupPath;
            DataObjectFloat1DLookup_X_Axis=get_param(AllPath3,SParameter2);                    %Get X Axis DataObj for Float 2D Lookup Table
            
            AllPath4=Float2DLookupPath;
            DataObjectFloat2DLookup_X_Axis=get_param(AllPath4,SParameter4);                    %Get X Axis DataObj for Float 2D Lookup Table
            DataObjectFloat2DLookup_Y_Axis=get_param(AllPath4,SParameter2);                    %Get Y Axis DataObj for Float 2D Lookup Table
            AllStructDataFloat2DLookup_X_Axis=struct2table(struct('DataObjectFloat2DLookup_X_Axis',DataObjectFloat2DLookup_X_Axis,'AllPath4',AllPath4));
            AllStructDataFloat2DLookup_Y_Axis=struct2table(struct('DataObjectFloat2DLookup_Y_Axis',DataObjectFloat2DLookup_Y_Axis,'AllPath4',AllPath4));
            
            cntr1 = 1;
            for index4 = 1:length(LookupTableName)
                if strcmp(char(cellstr(LookupTableName{index4})),'1') %Condition to fetch 1D lookup tables axis(X_Axis)
                    StorePath_1D{cntr1}=LookupPath{index4};
                    StorePath_AxisObj_1D = StorePath_1D(~cellfun('isempty', StorePath_1D)); %Storing path of 1D lookup tables axis(X_Axis)
                    Store_Axis_1D{cntr1}= get_param(LookupPath{index4},'BreakpointsForDimension1'); %X_Axis
                    Store_AxisObj_1D = Store_Axis_1D(~cellfun('isempty', Store_Axis_1D));   %Storing data object of 1D lookup tables axis(X_Axis)
                    cntr1 = cntr1+1;
                end
                if strcmp(char(cellstr(LookupTableName{index4})),'2') %Condition to fetch 2D lookup tables axis(X_Axis and Y_Axis)
                    StorePath_2D{cntr1}=LookupPath{index4};
                    StorePath_Axis_2D = StorePath_2D(~cellfun('isempty', StorePath_2D));
                    Store_X_Axis_2D_Map1{cntr1}= get_param(LookupPath{index4},'BreakpointsForDimension1'); %X_Axis
                    Store_X_Axis_2D_Map = Store_X_Axis_2D_Map1(~cellfun('isempty', Store_X_Axis_2D_Map1));
                    Store_Y_Axis_2D_Map1{cntr1}= get_param(LookupPath{index4},'BreakpointsForDimension2');%Y_Axis
                    Store_Y_Axis_2D_Map = Store_Y_Axis_2D_Map1(~cellfun('isempty', Store_Y_Axis_2D_Map1));
                    cntr1 = cntr1+1;
                end
            end
            for index6 = 1:length(PreLookupPath)
                StoreBreakpointsSpecification = get_param(PreLookupPath{index6},'BreakpointsSpecification');
                if strcmp(StoreBreakpointsSpecification,'Explicit values')
                    StorePreLookupAxisPath{cntr1}=PreLookupPath{index6};
                    StorePreLookupAxisPath1 = StorePreLookupAxisPath(~cellfun('isempty', StorePreLookupAxisPath));
                    StorePreLookupAxis{cntr1} = get_param(PreLookupPath{index6},'BreakpointsData');
                    StorePreLookupAxis1 = StorePreLookupAxis(~cellfun('isempty', StorePreLookupAxis));
                end
                cntr1 = cntr1+1;
            end
 
            % Concatenating data object of Axis category
            AllStructDataObject = vertcat(AllStructDataFix2DLookup_X_Axis.DataObjectFix2DLookup_X_Axis,AllStructDataFix2DLookup_Y_Axis.DataObjectFix2DLookup_Y_Axis,DataObjectFix1DLookup_X_Axis,DataObjectFloat1DLookup_X_Axis,AllStructDataFloat2DLookup_X_Axis.DataObjectFloat2DLookup_X_Axis,AllStructDataFloat2DLookup_Y_Axis.DataObjectFloat2DLookup_Y_Axis,Store_AxisObj_1D',Store_X_Axis_2D_Map',Store_Y_Axis_2D_Map',StorePreLookupAxis1');  
            AllStructPath = vertcat(AllStructDataFix2DLookup_X_Axis.AllPath2,AllStructDataFix2DLookup_Y_Axis.AllPath2,AllPath1,AllPath3,AllStructDataFloat2DLookup_X_Axis.AllPath4,AllStructDataFloat2DLookup_Y_Axis.AllPath4,StorePath_AxisObj_1D',StorePath_Axis_2D',StorePath_Axis_2D',StorePreLookupAxisPath1'); 
              
            % Checking received data object is present in simulink model
              [ChkDataObjIsMem, ~] = ismember(AllStructDataObject,DataObj);
            % Storing first occuring position of data object in model   
              StorePosDtObj = find(ChkDataObjIsMem,1);
            if nnz(StorePosDtObj)                            %If position of data object in model found
                open_system(GetModelPath)                    %Open Model
                hilite_system(AllStructPath(StorePosDtObj))  %Highlight data object
                set_param(char(ModelName),'Zoomfactor','fit to view')
                messageCode = 503;                           %Data object found successfully will send messageCode 503
                OutputFindInModel=table(messageCode);
                close(LoadingIndicator)                      %Close LoadingIndicator
                return;
            else
                errorCode = 109;                             %If data object not found will send errorCode 109
                OutputFindInModel=table(errorCode);
                close(LoadingIndicator)                      %Close LoadingIndicator
                return;
            end
            
        case 'Nvm' 
              AllPath=NvmPath;
              KeyToGetParameters='DataStoreName';                           %'DataStoreName' is the key to extract Input data object
        otherwise
              errorCode = 160;                                            %If data object other than specified category
              OutputFindInModel=table(errorCode);
              close(LoadingIndicator)                                     %Close LoadingIndicator
              return;
    end
    
% Checking received data object is present in simulink model
DataObject=get_param(AllPath,KeyToGetParameters);
[ChkDataObjIsMem, ~] = ismember(DataObject,DataObj);
% Checking received data object is present in stateflow 
if nnz(ChkDataObjIsMem)< 1
    if strcmp(DataObjectCategories,"Define") || strcmp(DataObjectCategories,"Local")
        if ~isempty(FoundStateflowChart)
            %Get Calibration and Define data object from stateflow
            %Stateflow Local data object
            StateflowDataObj=union(UniqueDataObjCalibDef,LocalObjStateflow);  %Combine Calibration,Define and local data object
            % Checking received data object is present in stateflow
            [ChkDataObjIsMemStateflow, ~] = ismember(StateflowDataObj,DataObj);
                if nnz(ChkDataObjIsMemStateflow)
                    cntr=1;
                    if ~isempty(ChartTransitions)
                        for index=1:length(ChartTransitions)
                            LabelStr = cellstr(ChartTransitions(index).LabelString);
                            LabelStr = LabelStr(~cellfun('isempty',LabelStr));
                            LabelStr=cellstr(string(LabelStr));  %Stateflow Data object of Calibration                             
                            if contains(string(cell2mat(LabelStr)),string(cellstr(DataObj)))
                                ChartTransitions(index).view;    
                                ChartTransitions(index).highlight; %Highlight Stateflow Transition
                                break;
                            end
                            cntr=cntr+1;
                        end
                    end
                    %Get path of State present Stateflow
                    if ~isempty(ChartState)
                        for index2=1:length(ChartState)
                            LabelStr = cellstr(ChartState(index2).LabelString);
                            LabelStr = LabelStr(~cellfun('isempty',LabelStr));
                            LabelStr=cellstr(string(LabelStr));
                            if contains(string(cell2mat(LabelStr)),string(cellstr(DataObj)))
                                State = StateflowChart.find('-isa','Stateflow.State','Name',ChartState(index2).Name);
                                State.view;
                                State.highlight;    %Highlight State of Stateflow
                            end
                        end
                    end
                    set_param(char(ModelName),'Zoomfactor','fit to view')
                    messageCode = 503;           %Data object of stateflow found successfully will send messageCode 503
                    OutputFindInModel=table(messageCode);
                    close(LoadingIndicator)
                    return;
                else
                      flag=1; %If data object not found
                end
        else
                      flag=1; %If data object not found
        end
    else
        flag=1; %If data object not found
    end
else
    %If data object present in model but it does not contain stateflow
    StorePosDtObj = find(ChkDataObjIsMem,1);  % Storing first occuring position of data object in model 
    if nnz(StorePosDtObj)                     % If position of data object in model found
        open_system(GetModelPath)             % Open Model
        hilite_system(AllPath(StorePosDtObj)) % Highlight data object
        set_param(char(ModelName),'Zoomfactor','fit to view')
        messageCode = 503;           %Data object found successfully
        OutputFindInModel=table(messageCode);
        close(LoadingIndicator)      %Close LoadingIndicator
        return;
    else
        flag=1;                      %If data object not found
    end
end
if flag==1
   errorCode = 109;                  %If data object not found
   OutputFindInModel=table(errorCode);
   close(LoadingIndicator)           %Close LoadingIndicator
   return;
end


