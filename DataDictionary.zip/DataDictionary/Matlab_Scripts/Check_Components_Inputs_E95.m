%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :Check_Components_Inputs_E95
% MAIN PURPOSE     :Function is used to compare inputs of single sldd with outpus of all sldd present in project folder and 
%                   1.Display a list of all the selected componentn's normal inputs that have different 
%                     attribute values from their corresponding output.
%                   2.Display a list of all the selected componentn's structured inputs that have different 
%                     attribute values from their corresponding output.
%                   3.Display a list of all the selected component3s inputs that do not have a 
%                     corresponding output data object.
% INPUT(S)         :1.ProjectPath = ('D:/Strategy/Development_Projects/Architecture/G6/ARXML/V1.0')
%                   2.slddpath=struct('Name','D:/KPIT_SVN/Data_Dictionary_Project/E39_example/AirManagement/aserc/Model/aserc.sldd')
% OUTPUT           :1.Display following list
%                       1.Inconsistent Normal I/Os
%                       2.Inconsistent Structured I/Os
%                       3.Unconnected Inputs OR
%                   2.If list (1) is empty, will send "errorCode: 203"
%                     If list (2) is empty, will send "errorCode: 204"
%                     If list (3) is empty, will send "errorCode: 117"
% DATE OF CREATION :19th Apr 2022
% REVESION NO      :1.0
% STATUS           :Rev. 1.0: Tested for following list 
%                             1.Inconsistant Normal I/Os
%                             2.Inconsistant Structured I/Os
%                             3.Unconnected Inputs 
% AUTHOR           :Nitin Dahyalkar
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [InconDataObjs] = Check_Components_Inputs_E95(ProjectPath,slddPath)

    %Add project folder and subfolders to path
    addpath(genpath(ProjectPath))
    DirPath = dir(fullfile(ProjectPath,'**\*.arxml'));
    FileList = strcat({DirPath.folder}, {'\'},{DirPath.name});
    if isempty(FileList)
        errorCode = 200;
        InconDataObjs = table(errorCode);
        return;
    end
    
    sldd = slddPath.Name;
    expression = '/';
    SlddPathSplit = regexp(sldd,expression,'split');
    compName = extractBefore(SlddPathSplit(end),'.sldd');
    %Read Inport and Outport data from ARXML
    [RPortDataObj, PPortDataObj, RPortStrDataObj, PPortStrDataObj] = ReadArxml(FileList,compName);
    
    %Structure for all input data and output data
    AllInDataIndex = 1;
    AllOutDataIndex = 1;
    AllInputDataStr = struct('Name',"",'StructureElementName',"",'component',"",'category','Input','Description',"",...
                    'Basetype',"",'Min',0,'Max',0,'Unit',"",'InitialValue',"");

    AllOutputDataStr = struct('Name',"",'StructureElementName',"",'component',"",'category','Output','Description',"",...
                    'Basetype',"",'Min',0,'Max',0,'Unit',"",'InitialValue',"");
    
    %Store all the normal input data
    if ~isequal(RPortDataObj.Name,"")
        for AllInIndex = 1 : length(RPortDataObj)
            AllInputDataStr(AllInDataIndex) = struct('Name',RPortDataObj(AllInIndex).Name,'StructureElementName',"",'component',RPortDataObj(AllInIndex).Component,'category','Input','Description',RPortDataObj(AllInIndex).Description,...
                'Basetype',RPortDataObj(AllInIndex).BaseType,'Min',RPortDataObj(AllInIndex).Min,'Max',RPortDataObj(AllInIndex).Max,'Unit',RPortDataObj(AllInIndex).Unit,'InitialValue',RPortDataObj(AllInIndex).InitialValue);
            AllInDataIndex = AllInDataIndex + 1;
        end
    end
    %Store all structure input data
    if ~isequal(RPortStrDataObj.Name,"")
        for AllStrIn = 1 : length(RPortStrDataObj)
            for StrInIndex = 1 : length(RPortStrDataObj(AllStrIn).SubSignal)
                AllInputDataStr(AllInDataIndex) = struct('Name',RPortStrDataObj(AllStrIn).Name,'StructureElementName',RPortStrDataObj(AllStrIn).SubSignal(StrInIndex).Name,'component',RPortStrDataObj(AllStrIn).Component,'category','Input',...
                    'Description',RPortStrDataObj(AllStrIn).Description,'Basetype',RPortStrDataObj(AllStrIn).SubSignal(StrInIndex).BaseType,'Min',RPortStrDataObj(AllStrIn).SubSignal(StrInIndex).Min,'Max',RPortStrDataObj(AllStrIn).SubSignal(StrInIndex).Max,...
                    'Unit',RPortStrDataObj(AllStrIn).SubSignal(StrInIndex).Unit,'InitialValue',RPortStrDataObj(AllStrIn).SubSignal(StrInIndex).InitialValue);
                AllInDataIndex = AllInDataIndex + 1;
            end
        end
    end
    %Store all the normal output data
    if ~isequal(PPortDataObj.Name,"")
        for AllOutIndex = 1 : length(PPortDataObj)
            AllOutputDataStr(AllOutDataIndex) = struct('Name',PPortDataObj(AllOutIndex).Name,'StructureElementName',"",'component',PPortDataObj(AllOutIndex).Component,'category','Output','Description',PPortDataObj(AllOutIndex).Description,...
                    'Basetype',PPortDataObj(AllOutIndex).BaseType,'Min',PPortDataObj(AllOutIndex).Min,'Max',PPortDataObj(AllOutIndex).Max,'Unit',PPortDataObj(AllOutIndex).Unit,'InitialValue',PPortDataObj(AllOutIndex).InitialValue);
            AllOutDataIndex = AllOutDataIndex + 1;
        end
    end
    %Store all structure output data
    if ~isequal(PPortStrDataObj.Name,"")
        for AllStrOut = 1 : length(PPortStrDataObj)
            for StrOutIndex = 1 : length(PPortStrDataObj(AllStrOut).SubSignal)
                AllOutputDataStr(AllOutDataIndex) = struct('Name',PPortStrDataObj(AllStrOut).Name,'StructureElementName',PPortStrDataObj(AllStrOut).SubSignal(StrOutIndex).Name,'component',PPortStrDataObj(AllStrOut).Component,'category','Output',...
                    'Description',PPortStrDataObj(AllStrOut).Description,'Basetype',PPortStrDataObj(AllStrOut).SubSignal(StrOutIndex).BaseType,'Min',PPortStrDataObj(AllStrOut).SubSignal(StrOutIndex).Min,'Max',PPortStrDataObj(AllStrOut).SubSignal(StrOutIndex).Max,...
                    'Unit',PPortStrDataObj(AllStrOut).SubSignal(StrOutIndex).Unit,'InitialValue',PPortStrDataObj(AllStrOut).SubSignal(StrOutIndex).InitialValue);
                AllOutDataIndex = AllOutDataIndex + 1;
            end
        end
    end
    %Structures for inconsistent inputs and outputs
    RPortNorIncon = struct('warning','Inconsistent Normal I/Os','Name',"",'component',"",'category','Input','Description',"",...
                    'Basetype',"",'Min',0,'Max',0,'Unit',"",'InitialValue',"",'Dimensions',"");
    PPortNorIncon = struct('warning','Inconsistent Normal I/Os','Name',"",'component',"",'category','Output','Description',"",...
                    'Basetype',"",'Min',0,'Max',0,'Unit',"",'InitialValue',"",'Dimensions',"");
    InNorIndex = 1;
    OutNorIndex = 1;
    
    %Check inconsistent normal signals
    for RPortIndex = 1 : length(RPortDataObj)
        for PPortIndex = 1: length(PPortDataObj)
            if strcmp(RPortDataObj(RPortIndex).Name, PPortDataObj(PPortIndex).Name)
                if (~strcmp(RPortDataObj(RPortIndex).Description, PPortDataObj(PPortIndex).Description) || ~isequal(RPortDataObj(RPortIndex).Min, PPortDataObj(PPortIndex).Min) || ...
                    ~isequal(RPortDataObj(RPortIndex).Max, PPortDataObj(PPortIndex).Max) || ~isequal(RPortDataObj(RPortIndex).InitialValue, PPortDataObj(PPortIndex).InitialValue) || ...
                    ~strcmp(RPortDataObj(RPortIndex).Unit, PPortDataObj(PPortIndex).Unit) || ~strcmp(RPortDataObj(RPortIndex).BaseType, PPortDataObj(PPortIndex).BaseType))
                    %Inconsistent normal input
                    RPortNorIncon(InNorIndex) = struct('warning','Inconsistent Normal I/Os','Name',RPortDataObj(RPortIndex).Name,'component',RPortDataObj(RPortIndex).Component,'category','Input','Description',RPortDataObj(RPortIndex).Description,...
                    'Basetype',RPortDataObj(RPortIndex).BaseType,'Min',RPortDataObj(RPortIndex).Min,'Max',RPortDataObj(RPortIndex).Max,'Unit',RPortDataObj(RPortIndex).Unit,'InitialValue',RPortDataObj(RPortIndex).InitialValue,'Dimensions',1);
                    %Inconsistent normal output
                    PPortNorIncon(OutNorIndex) = struct('warning','Inconsistent Normal I/Os','Name',PPortDataObj(PPortIndex).Name,'component',PPortDataObj(PPortIndex).Component,'category','Output','Description',PPortDataObj(PPortIndex).Description,...
                    'Basetype',PPortDataObj(PPortIndex).BaseType,'Min',PPortDataObj(PPortIndex).Min,'Max',PPortDataObj(PPortIndex).Max,'Unit',PPortDataObj(PPortIndex).Unit,'InitialValue',PPortDataObj(PPortIndex).InitialValue,'Dimensions',1);
                
                    InNorIndex = InNorIndex + 1;
                    OutNorIndex = OutNorIndex + 1;
                end
            end
        end
    end
        
    RPortStrIncon = struct('warning','Inconsistent Structured I/Os','Name',"",'component',"",'category','Input','Description',"",...
                    'StructureElementName',"",'Basetype',"",'Min',0,'Max',0,'Unit',"",'InitialValue',"",'Dimensions',"");
    PPortStrIncon = struct('warning','Inconsistent Structured I/Os','Name',"",'component',"",'category','Output','Description',"",...
                    'StructureElementName',"",'Basetype',"",'Min',0,'Max',0,'Unit',"",'InitialValue',"",'Dimensions',"");    
    InStrIndex = 1;
    OutStrIndex = 1;
    %Check inconsistent structured signals
    for RStrIndex = 1 : length(RPortStrDataObj)
        for PStrIndex = 1 : length(PPortStrDataObj)
            if strcmp(RPortStrDataObj(RStrIndex).Name, PPortStrDataObj(PStrIndex).Name)
                for SubStrIndex = 1 : length(RPortStrDataObj(RStrIndex).SubSignal)
                    if (~strcmp(RPortStrDataObj(RStrIndex).Description, PPortStrDataObj(PStrIndex).Description) || ...
                        ~strcmp(RPortStrDataObj(RStrIndex).SubSignal(SubStrIndex).Name, PPortStrDataObj(PStrIndex).SubSignal(SubStrIndex).Name) || ...
                        ~isequal(RPortStrDataObj(RStrIndex).SubSignal(SubStrIndex).InitialValue, PPortStrDataObj(PStrIndex).SubSignal(SubStrIndex).InitialValue) || ...
                        ~isequal(RPortStrDataObj(RStrIndex).SubSignal(SubStrIndex).Min, PPortStrDataObj(PStrIndex).SubSignal(SubStrIndex).Min) || ...
                        ~isequal(RPortStrDataObj(RStrIndex).SubSignal(SubStrIndex).Max, PPortStrDataObj(PStrIndex).SubSignal(SubStrIndex).Max) || ...
                        ~strcmp(RPortStrDataObj(RStrIndex).SubSignal(SubStrIndex).Unit, PPortStrDataObj(PStrIndex).SubSignal(SubStrIndex).Unit) || ...
                        ~strcmp(RPortStrDataObj(RStrIndex).SubSignal(SubStrIndex).BaseType, PPortStrDataObj(PStrIndex).SubSignal(SubStrIndex).BaseType))
                             
                        %Inconsistent structured input signals
                        RPortStrIncon(InStrIndex) = struct('warning','Inconsistent Structured I/Os','Name',RPortStrDataObj(RStrIndex).Name,'component',RPortStrDataObj(RStrIndex).Component,'category','Input',...
                            'Description',RPortStrDataObj(RStrIndex).Description,'StructureElementName',RPortStrDataObj(RStrIndex).SubSignal(SubStrIndex).Name,'Basetype',RPortStrDataObj(RStrIndex).SubSignal(SubStrIndex).BaseType, ...
                            'Min',RPortStrDataObj(RStrIndex).SubSignal(SubStrIndex).Min,'Max',RPortStrDataObj(RStrIndex).SubSignal(SubStrIndex).Max,'Unit',RPortStrDataObj(RStrIndex).SubSignal(SubStrIndex).Unit,'InitialValue',RPortStrDataObj(RStrIndex).SubSignal(SubStrIndex).InitialValue,'Dimensions',1);
                            %Inconsistent structured output signals
                        PPortStrIncon(OutStrIndex) = struct('warning','Inconsistent Structured I/Os','Name',PPortStrDataObj(PStrIndex).Name,'component',PPortStrDataObj(PStrIndex).Component,'category','Output',...
                            'Description',PPortStrDataObj(PStrIndex).Description,'StructureElementName',PPortStrDataObj(PStrIndex).SubSignal(SubStrIndex).Name,'Basetype',PPortStrDataObj(PStrIndex).SubSignal(SubStrIndex).BaseType, ...
                            'Min',PPortStrDataObj(PStrIndex).SubSignal(SubStrIndex).Min,'Max',PPortStrDataObj(PStrIndex).SubSignal(SubStrIndex).Max,'Unit',PPortStrDataObj(PStrIndex).SubSignal(SubStrIndex).Unit,'InitialValue',PPortStrDataObj(PStrIndex).SubSignal(SubStrIndex).InitialValue,'Dimensions',1);
                                
                        InStrIndex = InStrIndex + 1;
                        OutStrIndex = OutStrIndex + 1;
                    end
                end
            end
        end
    end
   
    %Normal inputs
    if (~isempty(RPortNorIncon) || ~isequal(RPortNorIncon.Name, ""))
        InconNorIn = struct2table(RPortNorIncon,'AsArray',true);
    end
    %Remove duplicate outputs(Normal)
    InconNorOut = struct2table(PPortNorIncon,'AsArray',true); 
    if ~isequal(PPortNorIncon.Name,"")
        InconNorOutput = struct2table(PPortNorIncon,'AsArray',true); 
        NorInconNames = InconNorOutput.Name;
        NorInconNames(cellfun('isempty',NorInconNames)) = [];
        NorInconNames = unique(NorInconNames);
        NorCntr = 1;
        for UniIndex = 1: length(NorInconNames)
            [StoreName1, NorPos] = ismember(NorInconNames(UniIndex),InconNorOutput.Name);
            if (StoreName1)
                InconUniOut{NorCntr} = InconNorOutput(NorPos,:);
                NorCntr = NorCntr + 1;
            end
        end
        if ~isempty(InconUniOut)
            if length(InconUniOut) > 1
                InconNorOut = [InconUniOut{1} ; InconUniOut{2}]; %Combine first and second table vertically
                for NorInd = 3 : length(InconUniOut)
                    InconNorOut = [InconNorOut ; InconUniOut{NorInd}]; %Append rest of table below first and second
                end
            else
                InconNorData = cell2table(InconUniOut); %If 'InconUniOut' variable contains single table
                InconNorOut = InconNorData.InconUniOut;
            end
        end
    end
    CombineNorStruct = vertcat(InconNorIn, InconNorOut); %Combine input and output tables vertically
    CheckStatus1 = CombineNorStruct(:,2).Name; %Check whether combined structured is empty
    if CheckStatus1 ==""
        errorCode = 203;
        IOAttr1 = (table(errorCode));
    else
        IOAttr1 = CombineNorStruct;
    end
    %Structured inputs
    if (~isempty(RPortStrIncon) || ~isequal(RPortStrIncon.Name,""))
        InconStrIn  = struct2table(RPortStrIncon,'AsArray',true);
    end
    %Remove duplicate outputs(Structured) from inconsistent structure
    InconStrOut = struct2table(PPortStrIncon,'AsArray',true);
    if ~isequal(PPortStrIncon.Name,"")
        InconStrOutput = struct2table(PPortStrIncon,'AsArray',true);
        CommonName = strcat(InconStrOutput.Name, InconStrOutput.StructureElementName);
        [~, UniqPos] = unique(CommonName,'stable');
        for PosIndex = 1 : length(UniqPos)
           InconStrUni{PosIndex} = InconStrOutput(UniqPos(PosIndex),:);
        end
        
        %Condition to check if there is any duplicate outputs
        if ~isequal(length(InconStrUni), length(PPortStrIncon))
            if ~isempty(InconStrUni)
                if length(InconStrUni) > 1
                    InconStrOut = [InconStrUni{1} ; InconStrUni{2}]; %Combine first and second table vertically
                    for StrInd = 3 : length(InconStrUni)
                        InconStrOut = [InconStrOut ; InconStrUni{StrInd}]; %Append rest of table below first and second
                    end
                else
                    InconStrData = cell2table(InconStrUni); %If 'InconStrUni' variable contains single table
                    InconStrOut = InconStrData.InconStrUni;
                end
            end
        end
    end
    
    CombineStrStruct = vertcat(InconStrIn, InconStrOut); %Combine input and output tables vertically
    CheckStatus2 = CombineStrStruct(:,2).Name; %Check whether combined structured is empty
    if CheckStatus2 == ""
        errorCode = 204;
        IOAttr2 = table(errorCode);
    else
        IOAttr2 = CombineStrStruct;
    end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    InputDataStr = struct2table(AllInputDataStr, 'AsArray',true);
    OutputDataStr = struct2table(AllOutputDataStr, 'AsArray',true);
    %All input ports data
    AllInputNames = strcat(InputDataStr.Name, InputDataStr.StructureElementName);
    %All output ports data
    AllOutputNames = strcat(OutputDataStr.Name, OutputDataStr.StructureElementName);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %List of input ports that do not have output port
    UnconIn = 1;
    UnconInStruct = struct('warning','Unconnected Inputs','Name',"",'StructureElementName',"",'component',"",'category','Input','Description',"",'Basetype',"",'Min',0,'Max',0,'Unit',"",'InitialValue',"",'Dimensions',"");
    
    [InputUncon, ~] = setdiff(AllInputNames,AllOutputNames,'stable');
    SameInputIndex = 0;
    %Loop for getting same inputs in sequence
    for SameIn = 1 : length(InputUncon)
        IndexUncon = find(strcmp(AllInputNames, InputUncon(SameIn)));
        SameInputIndex = [SameInputIndex ; IndexUncon]; %Updating indexes of same inputs
    end
    SameInLoc = SameInputIndex(2:end);
    if isequal(InputUncon,"") || isempty(InputUncon) %When unconnected input list is empty, send error code 203
        errorCode = 117;
        IOAttr3 =  table(errorCode);
    else
        for InputCntr = 1 : length(SameInLoc)
            UnconInStruct(UnconIn) = struct('warning','Unconnected Inputs','Name',InputDataStr.Name(SameInLoc(InputCntr)),'StructureElementName',InputDataStr.StructureElementName(SameInLoc(InputCntr)),'component',InputDataStr.component((SameInLoc(InputCntr))),...
                'category','Input','Description',InputDataStr.Description(SameInLoc(InputCntr)),'Basetype',InputDataStr.Basetype(SameInLoc(InputCntr)),'Min',InputDataStr.Min(SameInLoc(InputCntr)),'Max',InputDataStr.Max(SameInLoc(InputCntr)),...
                'Unit',InputDataStr.Unit(SameInLoc(InputCntr)),'InitialValue',InputDataStr.InitialValue(SameInLoc(InputCntr)),'Dimensions',1);
            UnconIn = UnconIn +1;
        end
        IOAttr3 = struct2table(UnconInStruct,'AsArray',true);
    end

    InconDataObjs{1,:} = IOAttr1;
    InconDataObjs{2,:} = IOAttr2;
    InconDataObjs{3,:} = IOAttr3;
end
    
function [AllInObj,AllOutObj, AllStrInObj, AllStrOutObj ] = ReadArxml(FileList,compName)
    
    %Initialization
    AllInObj = struct('Component',"",'Name',"",'Description',"",'InitialValue',[],'Unit',"",'Min',[],'Max',[],'BaseType',"");
    AllOutObj = struct('Component',"",'Name',"",'Description',"",'InitialValue',[],'Unit',"",'Min',[],'Max',[],'BaseType',"");
    AllStrInObj = struct('Component',"",'Name',"",'Description',"",'SubSignal',struct('Name',"",'InitialValue',[],'Unit',"",'Min',[],'Max',[],'BaseType',""));
    AllStrOutObj = struct('Component',"",'Name',"",'Description',"",'SubSignal',struct('Name',"",'InitialValue',[],'Unit',"",'Min',[],'Max',[],'BaseType',""));
    RDataInd = 1;
    PDataInd = 1;
    RDataStrInd = 1;
    PDataStrInd = 1;
    %Loading indicator
    LoadingIndicator = waitbar(0,'Please wait while I/O Compatibility lists is being loaded 0%','Name','I/O Compatibility checking...','WindowStyle', 'modal');
    frames = java.awt.Frame.getFrames();
    frames(end).setAlwaysOnTop(1);
    javaFrame = get(LoadingIndicator,'JavaFrame');
    ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
    javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));
    
    for FileIndex = 1 : length(FileList)
        %Condition to ignore root arxml file
        if ~contains(FileList{FileIndex},'ASW_Composition')
            %Read ARXML file
            ArxmlNode = xmlread(FileList{FileIndex});
            ARPacksNode = ArxmlNode.getElementsByTagName('AR-PACKAGES');
            ARPackNode = ARPacksNode.item(0).getElementsByTagName('AR-PACKAGE');
        
            %Commom nodes
            ConstSpecNode = ARPacksNode.item(0).getElementsByTagName('CONSTANT-SPECIFICATION');
            InterfaceNode = ARPacksNode.item(0).getElementsByTagName('SENDER-RECEIVER-INTERFACE');
            ADTPNode = ARPacksNode.item(0).getElementsByTagName('APPLICATION-PRIMITIVE-DATA-TYPE');
            ADTRNode = ARPacksNode.item(0).getElementsByTagName('APPLICATION-RECORD-DATA-TYPE');
            IDTPNode = ARPacksNode.item(0).getElementsByTagName('IMPLEMENTATION-DATA-TYPE');
            CompMethNode = ARPacksNode.item(0).getElementsByTagName('COMPU-METHOD');
            DataConstrNode = ARPacksNode.item(0).getElementsByTagName('DATA-CONSTR');
            DataTyMapNode = ARPacksNode.item(0).getElementsByTagName('DATA-TYPE-MAP');
            %Get SWCs ARPackage node index
            SWCIndex = 0;
            for ARPackIndex = 1 : ARPackNode.getLength - 1
                ARPackNameNode = ARPackNode.item(ARPackIndex).getElementsByTagName('SHORT-NAME');
                ARPackName = ARPackNameNode.item(0).getTextContent;
                if strcmp(ARPackName,'SWCs')
                    SWCIndex = ARPackIndex;
                    break;
                end
            end
            %Element node
            ElemNode = ARPackNode.item(SWCIndex).getElementsByTagName('ELEMENTS');
            %Port Node
            PortNode = ElemNode.item(0).getElementsByTagName('PORTS');
            %Component name node
            CompNameNode = ElemNode.item(0).getElementsByTagName('SHORT-NAME');
            %Input data reading
            RPortNode = PortNode.item(0).getElementsByTagName('R-PORT-PROTOTYPE');
            
            %Get ARXML file name
            expression = '\';
            ArxmlPathSplit = regexp(FileList{FileIndex},expression,'split');
            ArxmlName = extractBefore(ArxmlPathSplit(end),'.arxml');
            %Condition to store input data for selected component
            if strcmpi(ArxmlName,compName)
                for RIndex = 0 : RPortNode.getLength - 1
                    RNamenode = RPortNode.item(RIndex).getElementsByTagName('SHORT-NAME'); %Name node
                    RDescNode = RPortNode.item(RIndex).getElementsByTagName('DESC'); %Description node
                    RReqComNode = RPortNode.item(RIndex).getElementsByTagName('REQUIRED-COM-SPECS');
                    RInitValNode = RReqComNode.item(0).getElementsByTagName('INIT-VALUE');
                    RConstRefNode = RInitValNode.item(0).getElementsByTagName('CONSTANT-REFERENCE');
                    if (RConstRefNode.getLength)
                        %Component name
                        AllInObj(RDataInd).Component = string(CompNameNode.item(0).getTextContent);
                        %Data object name
                        AllInObj(RDataInd).Name = string(RNamenode.item(0).getTextContent);
                        %Description
                        AllInObj(RDataInd).Description = strip(string(RDescNode.item(0).getTextContent));
                        %Initial value
                        RIVNameNode = RConstRefNode.item(0).getElementsByTagName('CONSTANT-REF');
                        RInitValName = string(RIVNameNode.item(0).getTextContent);
                        RPortIVName = extractAfter(strip(RInitValName),'ConstantSpecification/');
                        for RIVIndex = 0 : ConstSpecNode.getLength - 1
                            %Fetching initial value name from constant specification tag 
                            RIVShortNode = ConstSpecNode.item(RIVIndex).getElementsByTagName('SHORT-NAME');
                            RIVShortName = string(RIVShortNode.item(0).getTextContent);
                            if strcmp(RIVShortName,RPortIVName)
                                RInitVal = ConstSpecNode.item(RIVIndex).getElementsByTagName('V');
                                %When 'V' tag is not present then check for 'VALUE' tag
                                if ~(RInitVal.getLength)
                                    RInitVal = ConstSpecNode.item(RIVIndex).getElementsByTagName('VALUE');
                                end
                                AllInObj(RDataInd).InitialValue = str2num(RInitVal.item(0).getTextContent);
                                break;
                            end
                        end
                        %Fetch interface name
                        RReqIntNode = RPortNode.item(RIndex).getElementsByTagName('REQUIRED-INTERFACE-TREF');
                        RInterFaceName = string(RReqIntNode.item(0).getTextContent);
                        RIFName = extractAfter(strip(RInterFaceName),'SenderReceiverInterface/');
                        %Get ADTP from interface
                        RADTPName = "";
                        for RIFIndex = 0 : InterfaceNode.getLength - 1
                            RIFShortNode = InterfaceNode.item(RIFIndex).getElementsByTagName('SHORT-NAME');
                            RIFShortname = string(RIFShortNode.item(0).getTextContent);
                            if strcmp(RIFShortname,RIFName)
                                RTypeNode = InterfaceNode.item(RIFIndex).getElementsByTagName('TYPE-TREF');
                                RIFRefName = string(RTypeNode.item(0).getTextContent);
                                RADTPName = extractAfter(strip(RIFRefName),'ApplicationDataTypes/');
                                break;
                            end
                        end
                        RCompMName = "";
                        RDataConName = "";
                        %To get compute method and data constraint from ADTP
                        for RADTPIndex = 0 : ADTPNode.getLength - 1
                            RADTPShortNode = ADTPNode.item(RADTPIndex).getElementsByTagName('SHORT-NAME');
                            RADTPShortName = string(RADTPShortNode.item(0).getTextContent);
                            if strcmp(RADTPShortName,RADTPName)
                                RSWDefNode = ADTPNode.item(RADTPIndex).getElementsByTagName('SW-DATA-DEF-PROPS-CONDITIONAL');
                                %Get Compute method name
                                RCompNode = RSWDefNode.item(0).getElementsByTagName('COMPU-METHOD-REF');
                                RCompName = string(RCompNode.item(0).getTextContent);
                                RCompMName = extractAfter(strip(RCompName),'CompuMethods/');
                                %Get Data constraint name
                                RDataConstNode = RSWDefNode.item(0).getElementsByTagName('DATA-CONSTR-REF');
                                RDataCName = string(RDataConstNode.item(0).getTextContent);
                                RDataConName = extractAfter(strip(RDataCName),'DataConstraints/');
                                break;
                            end
                        end
                        %To get Unit from compute method
                        for RCompIndex = 0 : CompMethNode.getLength - 1
                            RCMShortNode = CompMethNode.item(RCompIndex).getElementsByTagName('SHORT-NAME');
                            RCMShortName = string(RCMShortNode.item(0).getTextContent);
                            RUnitRefNode = CompMethNode.item(RCompIndex).getElementsByTagName('UNIT-REF');
                            if strcmp(RCMShortName, RCompMName) 
                                if (RUnitRefNode.getLength)
                                    RUnitName = string(RUnitRefNode.item(0).getTextContent);
                                    AllInObj(RDataInd).Unit = extractAfter(strip(RUnitName), 'Units/');
                                else
                                    AllInObj(RDataInd).Unit = ""; %Store empty string when UNIT-REF tag is not found
                                end
                                break;
                            end
                        end
                        %To get Min and Max from data constraint
                        for RDataCIndex = 0 : DataConstrNode.getLength - 1
                            RDataCShortNode = DataConstrNode.item(RDataCIndex).getElementsByTagName('SHORT-NAME');
                            RDataShortName = string(RDataCShortNode.item(0).getTextContent);
                            if strcmp(RDataShortName,RDataConName)
                                %Physical constraint node
                                RPhyConNode = DataConstrNode.item(RDataCIndex).getElementsByTagName('PHYS-CONSTRS');
                                %Min value
                                RLowerNode = RPhyConNode.item(0).getElementsByTagName('LOWER-LIMIT');
                                AllInObj(RDataInd).Min = str2num(RLowerNode.item(0).getTextContent);
                                %Max value
                                RUpperNode = RPhyConNode.item(0).getElementsByTagName('UPPER-LIMIT');
                                AllInObj(RDataInd).Max = str2num(RUpperNode.item(0).getTextContent);
                                break;
                            end
                        end
                        RIDTPName = "";
                        %To get IDTP from ADTP
                        for RDataTyIndex = 0 : DataTyMapNode.getLength - 1
                            RApplDataNode = DataTyMapNode.item(RDataTyIndex).getElementsByTagName('APPLICATION-DATA-TYPE-REF');
                            RApplDataName = string(RApplDataNode.item(0).getTextContent);
                            RMapADTPName = extractAfter(strip(RApplDataName),'ApplicationDataTypes/');
                            if strcmp(RMapADTPName,RADTPName)
                                RImpleDataNode = DataTyMapNode.item(RDataTyIndex).getElementsByTagName('IMPLEMENTATION-DATA-TYPE-REF');
                                RImpleDataName = string(RImpleDataNode.item(0).getTextContent);
                                RIDTPName = extractAfter(strip(RImpleDataName),'ImplementationDataTypes/');
                                break;
                            end
                        end
                        %To get base type from IDTP
                        for RIDTPIndex = 0 : IDTPNode.getLength - 1
                            RIDTPShortNode = IDTPNode.item(RIDTPIndex).getElementsByTagName('SHORT-NAME');
                            RIDTPShortName = string(RIDTPShortNode.item(0).getTextContent);
                            if strcmp(RIDTPShortName,RIDTPName)
                                RBaseTypeRef = IDTPNode.item(RIDTPIndex).getElementsByTagName('BASE-TYPE-REF');
                                RBaseName = string(RBaseTypeRef.item(0).getTextContent);
                                AllInObj(RDataInd).BaseType = extractAfter(strip(RBaseName),'BaseTypes/');
                                break;
                            end
                        end
                        RDataInd = RDataInd + 1;
                    else
                        %Component name
                        AllStrInObj(RDataStrInd).Component = string(CompNameNode.item(0).getTextContent);
                        %Name of data object
                        AllStrInObj(RDataStrInd).Name = string(RNamenode.item(0).getTextContent);
                        %Description
                        AllStrInObj(RDataStrInd).Description = strip(string(RDescNode.item(0).getTextContent));
                        RStrInitValNode = RInitValNode.item(0).getElementsByTagName('RECORD-VALUE-SPECIFICATION');
                        if (RStrInitValNode.getLength)
                            RStrApplValNode = RStrInitValNode.item(0).getElementsByTagName('APPLICATION-VALUE-SPECIFICATION');
                            for RSubIndex = 0 : RStrApplValNode.getLength - 1
                                %Store SubSignal name
                                RStrShortNode = RStrApplValNode.item(RSubIndex).getElementsByTagName('SHORT-LABEL');
                                AllStrInObj(RDataStrInd).SubSignal(RSubIndex + 1).Name = string(RStrShortNode.item(0).getTextContent);
                                RStrInitNode = RStrApplValNode.item(RSubIndex).getElementsByTagName('V');
                                AllStrInObj(RDataStrInd).SubSignal(RSubIndex + 1).InitialValue = str2num(RStrInitNode.item(0).getTextContent);
                            end
                            %Get interface name for data object
                            RStrReqIFNode = RPortNode.item(RIndex).getElementsByTagName('REQUIRED-INTERFACE-TREF');
                            RStrInterface = string(RStrReqIFNode.item(0).getTextContent);
                            RStrInterFaceName = extractAfter(strip(RStrInterface),'SenderReceiverInterface/');
                            %Get ADTR from interface
                            RStrADTRName = "";
                            for RStrIFIndex = 0 : InterfaceNode.getLength - 1
                                RStrIFShortNode = InterfaceNode.item(RStrIFIndex).getElementsByTagName('SHORT-NAME');
                                RStrIFShortName = string(RStrIFShortNode.item(0).getTextContent);
                                if strcmp(RStrIFShortName, RStrInterFaceName)
                                    RStrTypeNode = InterfaceNode.item(RStrIFIndex).getElementsByTagName('TYPE-TREF');
                                    RStrTypeName = string(RStrTypeNode.item(0).getTextContent);
                                    RStrADTRName = extractAfter(strip(RStrTypeName),'ApplicationDataTypes/');
                                    break;
                                end
                            end
                            %Get respective SubSignal ADTP from ADTR
                            RStrADTPName = {};
                            for RADTRIndex = 0 : ADTRNode.getLength - 1
                                RStrADTRShortNode = ADTRNode.item(RADTRIndex).getElementsByTagName('SHORT-NAME');
                                RStrADTRShrtName = string(RStrADTRShortNode.item(0).getTextContent);
                                if strcmp(RStrADTRShrtName, RStrADTRName)
                                    RStrApplRecNode = ADTRNode.item(RADTRIndex).getElementsByTagName('APPLICATION-RECORD-ELEMENT');
                                    for RApplRecIndex = 0 : RStrApplRecNode.getLength - 1
                                        RStrAppShortNode = RStrApplRecNode.item(RApplRecIndex).getElementsByTagName('SHORT-NAME');
                                        RStrApplName = string(RStrAppShortNode.item(0).getTextContent);
                                        if strcmp(RStrApplName, AllStrInObj(RDataStrInd).SubSignal(RApplRecIndex + 1).Name )
                                            RStrADTRTyNode = RStrApplRecNode.item(RApplRecIndex).getElementsByTagName('TYPE-TREF');
                                            RStrADTRTyName = string(RStrADTRTyNode.item(0).getTextContent);
                                            RStrADTPName{RApplRecIndex + 1} = extractAfter(strip(RStrADTRTyName),'ApplicationDataTypes/');
                                        end
                                    end
                                    break;
                                end 
                            end
                            %Get compute method and constraint method for respecitve ADTP
                            RStrCompName = "";
                            RStrDataConName = "";
                            for RStrNameIndex = 1 : length(RStrADTPName)
                                %Get compute method and constraint method
                                for RStrADTPIndex = 0 : ADTPNode.getLength - 1
                                    RStrADTPShort = ADTPNode.item(RStrADTPIndex).getElementsByTagName('SHORT-NAME');
                                    RStrADTPShrtName = string(RStrADTPShort.item(0).getTextContent);
                                    if strcmp(RStrADTPShrtName, RStrADTPName{RStrNameIndex})
                                        RStrSwDataNode = ADTPNode.item(RStrADTPIndex).getElementsByTagName('SW-DATA-DEF-PROPS-CONDITIONAL');
                                        %Get compute method name
                                        RStrCompNode = RStrSwDataNode.item(0).getElementsByTagName('COMPU-METHOD-REF');
                                        RStrCompRefName = string(RStrCompNode.item(0).getTextContent);
                                        RStrCompName = extractAfter(strip(RStrCompRefName),'CompuMethods/');
                                        %Get data constraint name
                                        RStrDataConNode = RStrSwDataNode.item(0).getElementsByTagName('DATA-CONSTR-REF');
                                        RStrDataRefName = string(RStrDataConNode.item(0).getTextContent);
                                        RStrDataConName = extractAfter(strip(RStrDataRefName),'DataConstraints/');
                                        break;
                                    end
                                end
                                %Get Unit from respective compute method
                                for RStrCompIndex = 0 : CompMethNode.getLength - 1
                                    RStrCompShrtNode = CompMethNode.item(RStrCompIndex).getElementsByTagName('SHORT-NAME');
                                    RStrCompShrtName = string(RStrCompShrtNode.item(0).getTextContent);
                                    RStrUnitRefNode = CompMethNode.item(RStrCompIndex).getElementsByTagName('UNIT-REF');
                                    if strcmp(RStrCompShrtName, RStrCompName)
                                        if (RStrUnitRefNode.getLength)
                                            RStrUnitRefName = string(RStrUnitRefNode.item(0).getTextContent);
                                            AllStrInObj(RDataStrInd).SubSignal(RStrNameIndex).Unit = extractAfter(strip(RStrUnitRefName), 'Units/');
                                        else
                                            AllStrInObj(RDataStrInd).SubSignal(RStrNameIndex).Unit = ""; %Store empty string when UNIT-REF tag is not found
                                        end
                                        break;
                                    end
                                end
                                %Get Min and Max value from data constraint
                                for RStrDataConIndex = 0 : DataConstrNode.getLength - 1
                                    RStrDataShrtNode = DataConstrNode.item(RStrDataConIndex).getElementsByTagName('SHORT-NAME');
                                    RStrDataShrtname = string(RStrDataShrtNode.item(0).getTextContent);
                                    if strcmp(RStrDataShrtname, RStrDataConName)
                                        RStrPhyConNode = DataConstrNode.item(RStrDataConIndex).getElementsByTagName('PHYS-CONSTRS');
                                        %Min value
                                        RStrLoweNode = RStrPhyConNode.item(0).getElementsByTagName('LOWER-LIMIT');
                                        AllStrInObj(RDataStrInd).SubSignal(RStrNameIndex).Min = str2num(RStrLoweNode.item(0).getTextContent);
                                        %Max value
                                        RStrUpperNode = RStrPhyConNode.item(0).getElementsByTagName('UPPER-LIMIT');
                                        AllStrInObj(RDataStrInd).SubSignal(RStrNameIndex).Max = str2num(RStrUpperNode.item(0).getTextContent);
                                        break;
                                    end
                                end    
                            end
                            %Get IDTR from ADTR
                            RStrIDTRName = "";
                            for RStrDataMIndex = 0 : DataTyMapNode.getLength - 1
                                RStrApplDataNode = DataTyMapNode.item(RStrDataMIndex).getElementsByTagName('APPLICATION-DATA-TYPE-REF');
                                RStrApplDataName = string(RStrApplDataNode.item(0).getTextContent);
                                RStrMapADTRName = extractAfter(strip(RStrApplDataName),'ApplicationDataTypes/');
                                if strcmp(RStrMapADTRName, RStrADTRName)
                                    RStrImplDataNode = DataTyMapNode.item(RStrDataMIndex).getElementsByTagName('IMPLEMENTATION-DATA-TYPE-REF');
                                    RStrImpleDataName = string(RStrImplDataNode.item(0).getTextContent);
                                    RStrIDTRName = extractAfter(strip(RStrImpleDataName),'ImplementationDataTypes/');
                                    break; 
                                end
                            end
                            %Get respective SubSignal IDTP from IDTR
                            RStrIDTPName = {};
                            for RStrIDTPIndex = 0 : IDTPNode.getLength - 1
                                RStrIDTRShrtNode = IDTPNode.item(RStrIDTPIndex).getElementsByTagName('SHORT-NAME');
                                RStrIDTRShrtName = string(RStrIDTRShrtNode.item(0).getTextContent);
                                if strcmp(RStrIDTRShrtName, RStrIDTRName)
                                    RStrImplElmNode = IDTPNode.item(RStrIDTPIndex).getElementsByTagName('IMPLEMENTATION-DATA-TYPE-ELEMENT');
                                    for RStrImpElmIndex = 0 : RStrImplElmNode.getLength -1 
                                        RStrImplElmShrt = RStrImplElmNode.item(RStrImpElmIndex).getElementsByTagName('SHORT-NAME');
                                        RStrImplElmName = string(RStrImplElmShrt.item(0).getTextContent);
                                        if strcmp(RStrImplElmName, AllStrInObj(RDataStrInd).SubSignal(RStrImpElmIndex + 1).Name)
                                            RStrImplRefNode = RStrImplElmNode.item(RStrImpElmIndex).getElementsByTagName('IMPLEMENTATION-DATA-TYPE-REF');
                                            RStrImplRefName = string(RStrImplRefNode.item(0).getTextContent);
                                            RStrIDTPName{RStrImpElmIndex + 1} = extractAfter(strip(RStrImplRefName),'ImplementationDataTypes/');
                                        end
                                    end
                                    break;
                                end
                            end
                            %Get base type from IDTP
                            for RStrIDTPInd = 1 : length(RStrIDTPName)
                                for RStrImplIndex = 0 : IDTPNode.getLength - 1
                                    RStrImplShrtNode = IDTPNode.item(RStrImplIndex).getElementsByTagName('SHORT-NAME');
                                    RStrImpleShortName = string(RStrImplShrtNode.item(0).getTextContent);
                                    if strcmp(RStrImpleShortName, RStrIDTPName{RStrIDTPInd})
                                        RStrBaseTyNode = IDTPNode.item(RStrImplIndex).getElementsByTagName('BASE-TYPE-REF');
                                        RStrBaseTyName = string(RStrBaseTyNode.item(0).getTextContent);
                                        AllStrInObj(RDataStrInd).SubSignal(RStrIDTPInd).BaseType = extractAfter(strip(RStrBaseTyName),'BaseTypes/');
                                        break;
                                    end
                                end
                            end
                            RDataStrInd = RDataStrInd + 1;
                        end
                    end
                end
            end
            
            %Get all the Outport data
            PPortNode = PortNode.item(0).getElementsByTagName('P-PORT-PROTOTYPE');
            for PIndex = 0 : PPortNode.getLength - 1
                
                PNamenode = PPortNode.item(PIndex).getElementsByTagName('SHORT-NAME'); %Name node
                PDescNode = PPortNode.item(PIndex).getElementsByTagName('DESC'); %Description node
                PProvComNode = PPortNode.item(PIndex).getElementsByTagName('PROVIDED-COM-SPECS');
                PInitValNode = PProvComNode.item(0).getElementsByTagName('INIT-VALUE');
                PConstRefNode = PInitValNode.item(0).getElementsByTagName('CONSTANT-REFERENCE');
                if (PConstRefNode.getLength)
                    %Component name
                    AllOutObj(PDataInd).Component = string(CompNameNode.item(0).getTextContent);
                    %Data object name
                    AllOutObj(PDataInd).Name = string(PNamenode.item(0).getTextContent);
                    %Description
                    AllOutObj(PDataInd).Description = strip(string(PDescNode.item(0).getTextContent));
                    %Initial value
                    PIVNameNode = PConstRefNode.item(0).getElementsByTagName('CONSTANT-REF');
                    PInitValName = string(PIVNameNode.item(0).getTextContent);
                    PPortIVName = extractAfter(strip(PInitValName),'ConstantSpecification/');
                    for PIVIndex = 0 : ConstSpecNode.getLength - 1
                        %Fetching initial value name from constant specification tag 
                        PIVShortNode = ConstSpecNode.item(PIVIndex).getElementsByTagName('SHORT-NAME');
                        PIVShortName = string(PIVShortNode.item(0).getTextContent);
                        if strcmp(PIVShortName,PPortIVName)
                            PInitVal = ConstSpecNode.item(PIVIndex).getElementsByTagName('V');
                            %When 'V' tag is not present then check for 'VALUE tag'
                            if ~(PInitVal.getLength)
                                PInitVal = ConstSpecNode.item(PIVIndex).getElementsByTagName('VALUE');
                            end
                            AllOutObj(PDataInd).InitialValue = str2num(PInitVal.item(0).getTextContent);
                            break;
                        end
                    end
                    %Fetch interface name
                    PProvIntNode = PPortNode.item(PIndex).getElementsByTagName('PROVIDED-INTERFACE-TREF');
                    PInterFaceName = string(PProvIntNode.item(0).getTextContent);
                    PIFName = extractAfter(strip(PInterFaceName),'SenderReceiverInterface/');
                    %Get ADTP from interface
                    PADTPName = "";
                    for PIFIndex = 0 : InterfaceNode.getLength - 1
                        PIFShortNode = InterfaceNode.item(PIFIndex).getElementsByTagName('SHORT-NAME');
                        PIFShortname = string(PIFShortNode.item(0).getTextContent);
                        if strcmp(PIFShortname,PIFName)
                            PTypeNode = InterfaceNode.item(PIFIndex).getElementsByTagName('TYPE-TREF');
                            PIFRefName = string(PTypeNode.item(0).getTextContent);
                            PADTPName = extractAfter(strip(PIFRefName),'ApplicationDataTypes/');
                            break;
                        end
                    end
                    %To get compute method and data constraint from ADTP
                    PCompMName = "";
                    PDataConName = "";
                    for PADTPIndex = 0 : ADTPNode.getLength - 1
                        PADTPShortNode = ADTPNode.item(PADTPIndex).getElementsByTagName('SHORT-NAME');
                        PADTPShortName = string(PADTPShortNode.item(0).getTextContent);
                        if strcmp(PADTPShortName,PADTPName)
                            PSWDefNode = ADTPNode.item(PADTPIndex).getElementsByTagName('SW-DATA-DEF-PROPS-CONDITIONAL');
                            %Get Compute method name
                            PCompNode = PSWDefNode.item(0).getElementsByTagName('COMPU-METHOD-REF');
                            PCompName = string(PCompNode.item(0).getTextContent);
                            PCompMName = extractAfter(strip(PCompName),'CompuMethods/');
                            %Get Data constraint name
                            PDataConstNode = PSWDefNode.item(0).getElementsByTagName('DATA-CONSTR-REF');
                            PDataCName = string(PDataConstNode.item(0).getTextContent);
                            PDataConName = extractAfter(strip(PDataCName),'DataConstraints/');
                            break;
                        end
                    end
                    %To get Unit from compute method
                    for PCompIndex = 0 : CompMethNode.getLength - 1
                        PCMShortNode = CompMethNode.item(PCompIndex).getElementsByTagName('SHORT-NAME');
                        PCMShortName = string(PCMShortNode.item(0).getTextContent);
                        PUnitRefNode = CompMethNode.item(PCompIndex).getElementsByTagName('UNIT-REF');
                        if strcmp(PCMShortName, PCompMName)
                            if (PUnitRefNode.getLength)
                                PUnitName = string(PUnitRefNode.item(0).getTextContent);
                                AllOutObj(PDataInd).Unit = extractAfter(strip(PUnitName), 'Units/');
                            else
                                AllOutObj(PDataInd).Unit = ""; %Store empty string when UNIT-REF tag is not found
                            end
                            break;
                        end
                    end
                    %To get Min and Max from data constraint
                    for PDataCIndex = 0 : DataConstrNode.getLength - 1
                        PDataCShortNode = DataConstrNode.item(PDataCIndex).getElementsByTagName('SHORT-NAME');
                        PDataShortName = string(PDataCShortNode.item(0).getTextContent);
                        if strcmp(PDataShortName,PDataConName)
                            %Physical constraint node
                            PPhyConNode = DataConstrNode.item(PDataCIndex).getElementsByTagName('PHYS-CONSTRS');
                            %Min value
                            PLowerNode = PPhyConNode.item(0).getElementsByTagName('LOWER-LIMIT');
                            AllOutObj(PDataInd).Min = str2num(PLowerNode.item(0).getTextContent);
                            %Max value
                            PUpperNode = PPhyConNode.item(0).getElementsByTagName('UPPER-LIMIT');
                            AllOutObj(PDataInd).Max = str2num(PUpperNode.item(0).getTextContent);
                            break;
                        end
                    end
                    %To get IDTP from ADTP
                    PIDTPName = "";
                    for PDataTyIndex = 0 : DataTyMapNode.getLength - 1
                        PApplDataNode = DataTyMapNode.item(PDataTyIndex).getElementsByTagName('APPLICATION-DATA-TYPE-REF');
                        PApplDataName = string(PApplDataNode.item(0).getTextContent);
                        PMapADTPName = extractAfter(strip(PApplDataName),'ApplicationDataTypes/');
                        if strcmp(PMapADTPName,PADTPName)
                            PImpleDataNode = DataTyMapNode.item(PDataTyIndex).getElementsByTagName('IMPLEMENTATION-DATA-TYPE-REF');
                            PImpleDataName = string(PImpleDataNode.item(0).getTextContent);
                            PIDTPName = extractAfter(strip(PImpleDataName),'ImplementationDataTypes/');
                            break;
                        end
                    end
                    %To get base type from IDTP
                    for PIDTPIndex = 0 : IDTPNode.getLength - 1
                        PIDTPShortNode = IDTPNode.item(PIDTPIndex).getElementsByTagName('SHORT-NAME');
                        PIDTPShortName = string(PIDTPShortNode.item(0).getTextContent);
                        if strcmp(PIDTPShortName,PIDTPName)
                            PBaseTypeRef = IDTPNode.item(PIDTPIndex).getElementsByTagName('BASE-TYPE-REF');
                            PBaseName = string(PBaseTypeRef.item(0).getTextContent);
                            AllOutObj(PDataInd).BaseType = extractAfter(strip(PBaseName),'BaseTypes/');
                            break;
                        end
                    end
                    PDataInd = PDataInd + 1;
                else
                    %Component name
                    AllStrOutObj(PDataStrInd).Component = string(CompNameNode.item(0).getTextContent);
                    %Name of data object
                    AllStrOutObj(PDataStrInd).Name = string(PNamenode.item(0).getTextContent);
                    %Description
                    AllStrOutObj(PDataStrInd).Description = strip(string(PDescNode.item(0).getTextContent));
                    PStrInitValNode = PInitValNode.item(0).getElementsByTagName('RECORD-VALUE-SPECIFICATION');
                    if (PStrInitValNode.getLength)
                        PStrApplValNode = PStrInitValNode.item(0).getElementsByTagName('APPLICATION-VALUE-SPECIFICATION');
                        for PSubIndex = 0 : PStrApplValNode.getLength - 1
                            %Store SubSignal name
                            PStrShortNode = PStrApplValNode.item(PSubIndex).getElementsByTagName('SHORT-LABEL');
                            AllStrOutObj(PDataStrInd).SubSignal(PSubIndex + 1).Name = string(PStrShortNode.item(0).getTextContent);
                            PStrInitNode = PStrApplValNode.item(PSubIndex).getElementsByTagName('V');
                            AllStrOutObj(PDataStrInd).SubSignal(PSubIndex + 1).InitialValue = str2num(PStrInitNode.item(0).getTextContent);
                        end
                        %Get interface name for data object
                        PStrProvIFNode = PPortNode.item(PIndex).getElementsByTagName('PROVIDED-INTERFACE-TREF');
                        PStrInterface = string(PStrProvIFNode.item(0).getTextContent);
                        PStrInterFaceName = extractAfter(strip(PStrInterface),'SenderReceiverInterface/');
                        %Get ADTR from interface
                        PStrADTRName = "";
                        for PStrIFIndex = 0 : InterfaceNode.getLength - 1
                            PStrIFShortNode = InterfaceNode.item(PStrIFIndex).getElementsByTagName('SHORT-NAME');
                            PStrIFShortName = string(PStrIFShortNode.item(0).getTextContent);
                            if strcmp(PStrIFShortName, PStrInterFaceName)
                                PStrTypeNode = InterfaceNode.item(PStrIFIndex).getElementsByTagName('TYPE-TREF');
                                PStrTypeName = string(PStrTypeNode.item(0).getTextContent);
                                PStrADTRName = extractAfter(strip(PStrTypeName),'ApplicationDataTypes/');
                                break;
                            end
                        end
                        %Get respective SubSignal ADTP from ADTR
                        PStrADTPName = {};
                        for PADTRIndex = 0 : ADTRNode.getLength - 1
                            PStrADTRShortNode = ADTRNode.item(PADTRIndex).getElementsByTagName('SHORT-NAME');
                            PStrADTRShrtName = string(PStrADTRShortNode.item(0).getTextContent);
                            if strcmp(PStrADTRShrtName, PStrADTRName)
                                PStrApplRecNode = ADTRNode.item(PADTRIndex).getElementsByTagName('APPLICATION-RECORD-ELEMENT');
                                for PApplRecIndex = 0 : PStrApplRecNode.getLength - 1
                                    PStrAppShortNode = PStrApplRecNode.item(PApplRecIndex).getElementsByTagName('SHORT-NAME');
                                    PStrApplName = string(PStrAppShortNode.item(0).getTextContent);
                                    if strcmp(PStrApplName, AllStrOutObj(PDataStrInd).SubSignal(PApplRecIndex + 1).Name )
                                        PStrADTRTyNode = PStrApplRecNode.item(PApplRecIndex).getElementsByTagName('TYPE-TREF');
                                        PStrADTRTyName = string(PStrADTRTyNode.item(0).getTextContent);
                                        PStrADTPName{PApplRecIndex + 1} = extractAfter(strip(PStrADTRTyName),'ApplicationDataTypes/');
                                    end
                                end
                                break;
                            end 
                        end
                        %Get compute method and constraint method for respecitve ADTP
                        PStrCompName = "";
                        PStrDataConName = "";
                        for PStrNameIndex = 1 : length(PStrADTPName)
                            %Get compute method and constraint method
                            for PStrADTPIndex = 0 : ADTPNode.getLength - 1
                                PStrADTPShort = ADTPNode.item(PStrADTPIndex).getElementsByTagName('SHORT-NAME');
                                PStrADTPShrtName = string(PStrADTPShort.item(0).getTextContent);
                                if strcmp(PStrADTPShrtName, PStrADTPName{PStrNameIndex})
                                    PStrSwDataNode = ADTPNode.item(PStrADTPIndex).getElementsByTagName('SW-DATA-DEF-PROPS-CONDITIONAL');
                                    %Get compute method name
                                    PStrCompNode = PStrSwDataNode.item(0).getElementsByTagName('COMPU-METHOD-REF');
                                    PStrCompRefName = string(PStrCompNode.item(0).getTextContent);
                                    PStrCompName = extractAfter(strip(PStrCompRefName),'CompuMethods/');
                                    %Get data constraint name
                                    PStrDataConNode = PStrSwDataNode.item(0).getElementsByTagName('DATA-CONSTR-REF');
                                    PStrDataRefName = string(PStrDataConNode.item(0).getTextContent);
                                    PStrDataConName = extractAfter(strip(PStrDataRefName),'DataConstraints/');
                                    break;
                                end
                            end
                            %Get Unit from respective compute method
                            for PStrCompIndex = 0 : CompMethNode.getLength - 1
                                PStrCompShrtNode = CompMethNode.item(PStrCompIndex).getElementsByTagName('SHORT-NAME');
                                PStrCompShrtName = string(PStrCompShrtNode.item(0).getTextContent);
                                PStrUnitRefNode = CompMethNode.item(PStrCompIndex).getElementsByTagName('UNIT-REF');
                                if strcmp(PStrCompShrtName, PStrCompName)
                                    if (PStrUnitRefNode.getLength)
                                        PStrUnitRefName = string(PStrUnitRefNode.item(0).getTextContent);
                                        AllStrOutObj(PDataStrInd).SubSignal(PStrNameIndex).Unit = extractAfter(strip(PStrUnitRefName), 'Units/');
                                    else
                                        AllStrOutObj(PDataStrInd).SubSignal(PStrNameIndex).Unit = ""; %Store empty string when UNIT-REF tag is not found
                                    end
                                    break;
                                end
                            end
                            %Get Min and Max value from data constraint
                            for PStrDataConIndex = 0 : DataConstrNode.getLength - 1
                                PStrDataShrtNode = DataConstrNode.item(PStrDataConIndex).getElementsByTagName('SHORT-NAME');
                                PStrDataShrtname = string(PStrDataShrtNode.item(0).getTextContent);
                                if strcmp(PStrDataShrtname, PStrDataConName)
                                    PStrPhyConNode = DataConstrNode.item(PStrDataConIndex).getElementsByTagName('PHYS-CONSTRS');
                                    %Min value
                                    PStrLoweNode = PStrPhyConNode.item(0).getElementsByTagName('LOWER-LIMIT');
                                    AllStrOutObj(PDataStrInd).SubSignal(PStrNameIndex).Min = str2num(PStrLoweNode.item(0).getTextContent);
                                    %Max value
                                    PStrUpperNode = PStrPhyConNode.item(0).getElementsByTagName('UPPER-LIMIT');
                                    AllStrOutObj(PDataStrInd).SubSignal(PStrNameIndex).Max = str2num(PStrUpperNode.item(0).getTextContent);
                                    break;
                                end
                            end    
                        end
                        %Get IDTR from ADTR
                        PStrIDTRName = "";
                        for PStrDataMIndex = 0 : DataTyMapNode.getLength - 1
                            PStrApplDataNode = DataTyMapNode.item(PStrDataMIndex).getElementsByTagName('APPLICATION-DATA-TYPE-REF');
                            PStrApplDataName = string(PStrApplDataNode.item(0).getTextContent);
                            PStrMapADTRName = extractAfter(strip(PStrApplDataName),'ApplicationDataTypes/');
                            if strcmp(PStrMapADTRName, PStrADTRName)
                                PStrImplDataNode = DataTyMapNode.item(PStrDataMIndex).getElementsByTagName('IMPLEMENTATION-DATA-TYPE-REF');
                                PStrImpleDataName = string(PStrImplDataNode.item(0).getTextContent);
                                PStrIDTRName = extractAfter(strip(PStrImpleDataName),'ImplementationDataTypes/');
                                break; 
                            end
                        end
                        %Get respective SubSignal IDTP from IDTR
                        PStrIDTPName = {};
                        for PStrIDTPIndex = 0 : IDTPNode.getLength - 1
                            PStrIDTRShrtNode = IDTPNode.item(PStrIDTPIndex).getElementsByTagName('SHORT-NAME');
                            PStrIDTRShrtName = string(PStrIDTRShrtNode.item(0).getTextContent);
                            if strcmp(PStrIDTRShrtName, PStrIDTRName)
                                PStrImplElmNode = IDTPNode.item(PStrIDTPIndex).getElementsByTagName('IMPLEMENTATION-DATA-TYPE-ELEMENT');
                                for PStrImpElmIndex = 0 : PStrImplElmNode.getLength -1 
                                    PStrImplElmShrt = PStrImplElmNode.item(PStrImpElmIndex).getElementsByTagName('SHORT-NAME');
                                    PStrImplElmName = string(PStrImplElmShrt.item(0).getTextContent);
                                    if strcmp(PStrImplElmName, AllStrOutObj(PDataStrInd).SubSignal(PStrImpElmIndex + 1).Name)
                                        PStrImplRefNode = PStrImplElmNode.item(PStrImpElmIndex).getElementsByTagName('IMPLEMENTATION-DATA-TYPE-REF');
                                        PStrImplRefName = string(PStrImplRefNode.item(0).getTextContent);
                                        PStrIDTPName{PStrImpElmIndex + 1} = extractAfter(strip(PStrImplRefName),'ImplementationDataTypes/');
                                    end
                                end
                                break;
                            end
                        end
                        %Get base type from IDTP
                        for PStrIDTPInd = 1 : length(PStrIDTPName)
                            for PStrImplIndex = 0 : IDTPNode.getLength - 1
                                PStrImplShrtNode = IDTPNode.item(PStrImplIndex).getElementsByTagName('SHORT-NAME');
                                PStrImpleShortName = string(PStrImplShrtNode.item(0).getTextContent);
                                if strcmp(PStrImpleShortName, PStrIDTPName{PStrIDTPInd})
                                    PStrBaseTyNode = IDTPNode.item(PStrImplIndex).getElementsByTagName('BASE-TYPE-REF');
                                    PStrBaseTyName = string(PStrBaseTyNode.item(0).getTextContent);
                                    AllStrOutObj(PDataStrInd).SubSignal(PStrIDTPInd).BaseType = extractAfter(strip(PStrBaseTyName),'BaseTypes/');
                                    break;
                                end
                            end
                        end
                        PDataStrInd = PDataStrInd + 1;
                    end
                end
            end
        end
        waitbar(FileIndex/length(FileList),LoadingIndicator,sprintf('Please wait while I/O Compatibility lists is being loaded %1.0f%%',(FileIndex/length(FileList)*100)))  
    end
    close(LoadingIndicator);
end