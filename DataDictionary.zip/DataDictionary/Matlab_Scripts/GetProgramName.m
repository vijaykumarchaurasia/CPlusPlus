%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :GetProgramName
% MAIN PURPOSE     :Function is used to send program number for configuration.
% INPUT(S)         :1.sldd_path
% OUTPUT           :1.Program name OR
%                   2.Program name is not present in sldd other data section,send errorCode = 1003,
%                   Multiple entries found in other data section, send errorCode = 1004,
% DATE OF CREATION :30th July 2021
% REVESION NO      :1.3
% STATUS           :Rev. 1.1: Tested to get program specific name from ohter data section. 
%                   Rev. 1.2: myOtherDict and Entries are replaced with myDictionaryObj and allEntries for naming consistency. 
%                   Rev. 1.3: Added condition to check whether received path is of component or project as programe name query 
%                             will be called when project is opened 
% AUTHOR           :Nitin Dahyalkar
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function ProgramName = GetProgramName(sldd_path,~)

%To check user selected project or single component
if ~contains(sldd_path,'.sldd')
    addpath(genpath(sldd_path))
    DirPath = dir(fullfile(sldd_path,'**\*.sldd'));
    slddPath = strcat({DirPath.folder}, {'\'},{DirPath.name});
    sldd_path = slddPath{1}; %Storing path of first sldd under project path
end
myDictionaryObj =Simulink.data.dictionary.open(sldd_path);       %open sldd
OtherDataSectObj = getSection(myDictionaryObj,'Other Data');         %get design data from sldd    
allEntries = find(OtherDataSectObj);

%Check if other data section is empty
if isempty(allEntries)
    %No entry found in other data section
    errorCode = "1003";
    ProgramName = table(errorCode);
    return;
else
    if (length(allEntries) > 1)
        %Multiple entries present in other data section 
        errorCode = "1004";
        ProgramName = table(errorCode);
        return;
    end
    ProgramName =struct2table(struct('Name',allEntries.Name));
end