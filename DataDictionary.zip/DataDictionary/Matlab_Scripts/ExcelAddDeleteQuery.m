%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :ExcelAddDeleteQuery
% MAIN PURPOSE     :Function is used to add and delete data objects in excel sheet 
%                   received from java.
% INPUT(S)         :1.received_data_Obj=struct('warning','Add in excel','Name','funde','Basetype','single','Offset','0','Slope','1','Component','CCTXP','category','Output','Description','D:/CAN_database_SLDD_example_edited.xlsx')
% OUTPUT           :1.If data object add and delete successfully will send
%                     message code: 920
%                   2.If data object to be added in excel is already present in it will send error code:935 
%                   3.If data object to be deleted in excel is not present
%                     in it will send error code:907
%                   4.If user clicks on cancel button while browsing excel
%                     file will send "errorCode:900"
%                   5.If user selected other than .xlsx file then send
%                   "error code:901"
%                   6. If excel sheet is open while running code will send
%                   erroe code: 921
%                   7.If column header not present in excel sheet will send following errorcode:
%                     �Source Variable� name not present in excel= errorCode:912(used as not valid excel sheet)
%                     'Destination Variable' name not present in excel= errorCode:913
% DATE OF CREATION :30th April 2020
% REVESION NO      :1.3
% STATUS           :Rev. 1.1: Tested to add and delete received data
%                             objects in excel sheet
%                             Applicable for following categories->Input,Output
%                        1.2: Tested for following column header not
%                             present in excel sheet:
%                             'DataType_Source Variable','DataType_Destination Variable','Offset_Source Variable',
%                             'Offset_Destination Variable','Slope_Source Variable','Slope_Destination Variable'
%                        1.3: 1.xlsfinfo and xlsread are replaced with sheetnames and readcell commands. 
%                             2.xlswrite is replaced with common fuction WriteData() where writecell() writes data in excel file 
%FUNCTION CALL     :1.[Code,StoreIndexInputName,StoreIndexOutputName,StoreIndexDataTypeName_Input,StoreIndexDataTypeName_Output,StoreIndexOffsetName_Input,StoreIndexOffsetName_Output,StoreIndexSlopeName_Input,StoreIndexSlopeName_Output,StoreIndexComponentName,StoreInputDataObject1,StoreOutputDataObject1,~,~,~,~,~,~,~]=ValidationOfExcel(received_data_Obj(length_objNames).Description);
%                   2.[ColumnSelect_SV,ColumnSelect_SV_DataType,ColumnSelect_SV_Offset,ColumnSelect_SV_slope,~] = FindColumnOfSourceVariable(StoreIndexInputName,StoreIndexDataTypeName_Input,StoreIndexOffsetName_Input,StoreIndexSlopeName_Input,StoreIndexComponentName);
%                   3.[ColumnSelect_DV,ColumnSelect_DV_DataType,ColumnSelect_DV_Offset,ColumnSelect_DV_slope,~] = FindColumnOfDestinationVariable(StoreIndexOutputName,StoreIndexDataTypeName_Output,StoreIndexOffsetName_Output,StoreIndexSlopeName_Output,StoreIndexComponentName);
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [SendCode]= ExcelAddDeleteQuery(~,received_data_Obj)
%Logic written for loading indicator
%LoadingIndicator starts
%Set LoadingIndicator always on top of screen
LoadingIndicator = waitbar(0,'0% Completed','Name','Adding/Deleting data object(s) from excel...','WindowStyle', 'modal');
frames = java.awt.Frame.getFrames();
frames(end).setAlwaysOnTop(1);
%Set data dictionary icon on LoadingIndicator 
javaFrame = get(LoadingIndicator,'JavaFrame');
ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));
        
 for length_objNames = 1:length(received_data_Obj)
    %To find position of 'Source Variable', 'Destination Variable' and respective DataType/Offset/Slope from excel sheet
    %TXT is variable which contains all data inside the Excel/Test Vector file
    %Read Third Row for Headings of Column
    [Code,StoreIndexInputName,StoreIndexOutputName,StoreIndexDataTypeName_Input,StoreIndexDataTypeName_Output,StoreIndexOffsetName_Input,StoreIndexOffsetName_Output,StoreIndexSlopeName_Input,StoreIndexSlopeName_Output,StoreIndexComponentName,StoreInputDataObject1,StoreOutputDataObject1,~,~,~,~,~,~,StoreComponentName1]=ValidationOfExcel(received_data_Obj(length_objNames).Description);
     if ~strcmp(Code,"4000")
         errorCode=Code;
         SendCode=table(errorCode);
         close(LoadingIndicator);
         return;
     end
    %Initialization
    AlreadyPresentDataObjIn = {};
    AlreadyPresentDataObjOut = {};
    InputNotPresentInExcel = {};
    OutputNotPresentInExcel = {};
    flag=0;
    flag2=1;
    flag3=0;
    flag4=1;
    Data1="";
    Data2="";
    Data3="";
    Data4="";
    Alphabet='A':'Z';
    
    %Delete data object from excel
    if strcmp(received_data_Obj(length_objNames).warning,'Delete from excel')
        switch(received_data_Obj(length_objNames).category)
            case  'Input'
                   %Get position of data object in excel 
                   cntr=1;
                   Data3="";
                   [DataObjFoundInExcel,~]=ismember(StoreInputDataObject1,received_data_Obj(length_objNames).Name);
                   %DataObj not present in excel
                   if ~nnz(DataObjFoundInExcel)
                        cntr5=1;
                        flag3=1;
                        Data3(cntr5,1) = string(num2str(907));
                        Data3(cntr5,2) = string(received_data_Obj(length_objNames).category);
                        Data3(cntr5,3) = string(received_data_Obj(length_objNames).Name); 
                        Data3(cntr5,4) = ('is not found in excel sheet so cannot be deleted');
                        cntr5=cntr5+1;
                    end
                   %Pre allocate memory
                    StorePositionOfDataObj1{1,length(DataObjFoundInExcel)} = [];
                    %Loop used to store exact position of data object in
                    %excel
                   for index=1:length(DataObjFoundInExcel)
                       if DataObjFoundInExcel(index)==1
                           StorePositionOfDataObj1{cntr}=index;
                           cntr=cntr+1;
                       end
                   end
                   %remove empty cell
                   StorePositionOfDataObj1 = StorePositionOfDataObj1(~cellfun('isempty', StorePositionOfDataObj1));
                   StorePositionOfDataObj = string(StorePositionOfDataObj1);

                   %Find column of Source variable/data type/offset/slope
                   %in excel
                   [ColumnSelect_SV,ColumnSelect_SV_DataType,ColumnSelect_SV_Offset,ColumnSelect_SV_slope,ColumnSelect_ModelName] = FindColumnOfSourceVariable(StoreIndexInputName,StoreIndexDataTypeName_Input,StoreIndexOffsetName_Input,StoreIndexSlopeName_Input,StoreIndexComponentName);

                     %Get sheetname from excel
                    sheets = sheetnames(received_data_Obj(length_objNames).Description);

                    %Deleting received data object name and respective DataType/Offset/slope
                    %from excel
                    for indexIn=1:length(StorePositionOfDataObj)
                        xlRange_SV=strcat(ColumnSelect_SV,StorePositionOfDataObj(indexIn));%Create range of excel sheet where user wants to write data
                         message_SV = WriteData({''},received_data_Obj(length_objNames).Description,sheets,xlRange_SV);%Replace data object name with blank
                        if ~isempty(message_SV.message)
                            if contains(message_SV.message,'may be open') %Excel sheet is open,close it and try again
                               errorCode="921";
                               SendCode=table(errorCode);
                               close(LoadingIndicator);
                               return;
                            end
                        end

                        xlRange_SV_DataType=strcat(ColumnSelect_SV_DataType,StorePositionOfDataObj(indexIn));%Create range of excel sheet where user wants to write data
                        xlRange_SV_Offset=strcat(ColumnSelect_SV_Offset,StorePositionOfDataObj(indexIn));%Create range of excel sheet where user wants to write data
                        xlRange_SV_slope=strcat(ColumnSelect_SV_slope,StorePositionOfDataObj(indexIn));%Create range of excel sheet where user wants to write data
                        %Loop used to check xlrange contains alphabet
                        for indexAlphabet=1:length(Alphabet)
                            if contains(char(xlRange_SV_DataType),Alphabet(indexAlphabet))%If column header 'DataType_Source Variable' is present in excel then only replace with empty cell
                                message_SV_DataType = WriteData({''},received_data_Obj(length_objNames).Description,sheets,xlRange_SV_DataType);%Replace data type with blank
                                if ~isempty(message_SV_DataType.message)
                                    %if contains(message_SV_DataType.message,'might be locked') %Excel sheet is open,close it and try again
                                    if contains(message_SV_DataType.message,'may be open') %Excel sheet is open,close it and try again
                                       errorCode="921";
                                       SendCode=table(errorCode);
                                       close(LoadingIndicator);
                                       return;
                                    end
                                end
                            end

                            if contains(char(xlRange_SV_Offset),Alphabet(indexAlphabet))%If column header 'Offset_Source Variable' is present in excel then only replace with empty cell
                                message_SV_Offset = WriteData({''},received_data_Obj(length_objNames).Description,sheets,xlRange_SV_Offset);%Replace Offset with blank
                                if ~isempty(message_SV_Offset.message)
                                    if contains(message_SV_Offset.message,'may be open') %Excel sheet is open,close it and try again
                                       errorCode="921";
                                       SendCode=table(errorCode);
                                       close(LoadingIndicator);
                                       return;
                                    end
                                end
                            end

                            if contains(char(xlRange_SV_slope),Alphabet(indexAlphabet))%If column header 'Slope_Source Variable' is present in excel then only replace with empty cell
                                message_SV_slope = WriteData({''},received_data_Obj(length_objNames).Description,sheets,xlRange_SV_slope);%Replace slope with blank
                                if ~isempty(message_SV_slope.message)
                                    if contains(message_SV_slope.message,'may be open') %Excel sheet is open,close it and try again
                                       errorCode="921";
                                       SendCode=table(errorCode);
                                       close(LoadingIndicator);
                                       return;
                                    end
                                end
                            end
                        end

                    end

            case  'Output'
                   cntr2=1;
                   Data4="";
                   [DataObjFoundInExcel,~]=ismember(StoreOutputDataObject1,received_data_Obj(length_objNames).Name);
                   %DataObj not present in excel
                    if ~nnz(DataObjFoundInExcel)
                        cntr6=1;
                        flag4=1;
                        Data4(cntr6,1) = string(num2str(907));
                        Data4(cntr6,2) = string(received_data_Obj(length_objNames).category);
                        Data4(cntr6,3) = string(received_data_Obj(length_objNames).Name); 
                        Data4(cntr6,4) = ('is not found in excel sheet so cannot be deleted');
                        cntr6=cntr6+1;
                    end
                   %Pre allocate memory
                    StorePositionOfDataObjOp{1,length(DataObjFoundInExcel)} = [];
                   %Loop used to store exact position of data object in
                   %excel
                   for index2=1:length(DataObjFoundInExcel)
                       if DataObjFoundInExcel(index2)==1
                           StorePositionOfDataObjOp{cntr2}=index2;
                           cntr2=cntr2+1;
                       end
                   end

                   %remove empty cell
                   StorePositionOfDataObjOp = StorePositionOfDataObjOp(~cellfun('isempty', StorePositionOfDataObjOp));
                   StorePositionOfDataObjOp1 = string(StorePositionOfDataObjOp);

                   %Find column of Destination variable/data type/offset/slope
                   %in excel
                   [ColumnSelect_DV,ColumnSelect_DV_DataType,ColumnSelect_DV_Offset,ColumnSelect_DV_slope,~] = FindColumnOfDestinationVariable(StoreIndexOutputName,StoreIndexDataTypeName_Output,StoreIndexOffsetName_Output,StoreIndexSlopeName_Output,StoreIndexComponentName);

                    %Get sheetname from excel
                    sheets = sheetnames(received_data_Obj(length_objNames).Description);

                    %Deleting recived data object name and respective DataType/Offset/slope
                    %from excel
                    for indexOut=1:length(StorePositionOfDataObjOp1)
                        xlRange_DV=strcat(ColumnSelect_DV,StorePositionOfDataObjOp1(indexOut));%Create range of excel sheet where user wants to write data
                        message_DV = WriteData({''},received_data_Obj(length_objNames).Description,sheets,xlRange_DV);%Replace data object name with blank
                        if ~isempty(message_DV.message)
                            if contains(message_DV.message,'may be open') %Excel sheet is open,close it and try again
                               errorCode="921";
                               SendCode=table(errorCode);
                               close(LoadingIndicator);
                               return;
                            end
                        end

                        xlRange_DV_DataType=strcat(ColumnSelect_DV_DataType,StorePositionOfDataObjOp1(indexOut));%Create range of excel sheet where user wants to write data
                        xlRange_DV_Offset=strcat(ColumnSelect_DV_Offset,StorePositionOfDataObjOp1(indexOut));%Create range of excel sheet where user wants to write data
                        xlRange_DV_slope=strcat(ColumnSelect_DV_slope,StorePositionOfDataObjOp1(indexOut));%Create range of excel sheet where user wants to write data
                        %Loop used to check xlrange contains alphabet
                        for indexAlphabet=1:length(Alphabet)
                            if contains(char(xlRange_DV_DataType),Alphabet(indexAlphabet)) %If column header 'DataType_Destination Variable' is present in excel then only replace with empty cell
                                message_DV_DataType = WriteData({''},received_data_Obj(length_objNames).Description,sheets,xlRange_DV_DataType);%Replace Data type with blank
                                if ~isempty(message_DV_DataType.message)
                                    if contains(message_DV_DataType.message,'may be open') %Excel sheet is open,close it and try again
                                       errorCode="921";
                                       SendCode=table(errorCode);
                                       close(LoadingIndicator);
                                       return;
                                    end
                                end
                            end

                            if contains(char(xlRange_DV_Offset),Alphabet(indexAlphabet))%If column header 'Offset_Destination Variable' is present in excel then only replace with empty cell
                                message_DV_Offset = WriteData({''},received_data_Obj(length_objNames).Description,sheets,xlRange_DV_Offset);%Replace Offset with blank
                                if ~isempty(message_DV_Offset.message)
                                    if contains(message_DV_Offset.message,'may be open') %Excel sheet is open,close it and try again
                                       errorCode="921";
                                       SendCode=table(errorCode);
                                       close(LoadingIndicator);
                                       return;
                                    end
                                end
                            end

                            if contains(char(xlRange_DV_slope),Alphabet(indexAlphabet))%If column header 'Slope_Destination Variable' is present in excel then only replace with empty cell
                                message_DV_slope = WriteData({''},received_data_Obj(length_objNames).Description,sheets,xlRange_DV_slope);%Replace slope with blank
                                if ~isempty(message_DV_slope.message)
                                    if contains(message_DV_slope.message,'may be open') %Excel sheet is open,close it and try again
                                       errorCode="921";
                                       SendCode=table(errorCode);
                                       close(LoadingIndicator);
                                       return;
                                    end
                                end
                            end
                        end
                    end
        end
    else
      %Add data objects in excel
      switch(received_data_Obj(length_objNames).category)
          case 'Input'
                %Checking received data object is already present in
                %excel will send errorcode:935
                cntr3=1;
                cntr=1;
                Data1="";Data1(:,3)="";
                [DataObjFoundInExcel,~]=ismember(StoreInputDataObject1,received_data_Obj(length_objNames).Name);

                 %Pre allocate memory
                    StorePositionOfDataObj1{1,length(DataObjFoundInExcel)} = [];
                    %Loop used to store exact position of data object in
                    %excel
                   for index=1:length(DataObjFoundInExcel)
                       if DataObjFoundInExcel(index)==1
                           StorePositionOfDataObj1{cntr}=index;
                           cntr=cntr+1;
                       end
                   end
                   %remove empty cell
                   StorePositionOfDataObj1 = StorePositionOfDataObj1(~cellfun('isempty', StorePositionOfDataObj1));
                   StorePositionOfDataObj = string(StorePositionOfDataObj1);

                   [~,~,~,~,ColumnSelect_ModelName] = FindColumnOfSourceVariable(StoreIndexInputName,StoreIndexDataTypeName_Input,StoreIndexOffsetName_Input,StoreIndexSlopeName_Input,StoreIndexComponentName);
                   %Create xlRange of component
                   GetCellOfModel=strcat(ColumnSelect_ModelName,StorePositionOfDataObj);
                   GetCellOfModel=strcat(GetCellOfModel,':',GetCellOfModel);
                   if isempty(GetCellOfModel)
                       GetCellOfModel = '';
                   end
                   %Get the name of component
                   FoundSVInOtherComponent  = readcell(received_data_Obj(length_objNames).Description,'Range',char(GetCellOfModel));
                   
                   %Cheking that received data object name is from same component
                    if strcmp(string(FoundSVInOtherComponent),string(upper(received_data_Obj(length_objNames).component)))
                        if nnz(DataObjFoundInExcel)>0
                            flag=1;
                            Data1(cntr3,1) = string(num2str(935));
                            Data1(cntr3,2) = string(received_data_Obj(length_objNames).category);
                            Data1(cntr3,3) = string(received_data_Obj(length_objNames).Name); 
                            Data1(cntr3,4) = ('is already present in excel sheet so cannot be added');
                            cntr3=cntr3+1;
                        end 
                    end

                if ~strcmp(Data1(:,3),received_data_Obj(length_objNames).Name)
                    %Find column of Source variable/data type/offset/slope in excel
                    [ColumnSelect_SV,ColumnSelect_SV_DataType,ColumnSelect_SV_Offset,ColumnSelect_SV_slope,ColumnSelect_ModelName] = FindColumnOfSourceVariable(StoreIndexInputName,StoreIndexDataTypeName_Input,StoreIndexOffsetName_Input,StoreIndexSlopeName_Input,StoreIndexComponentName);

                    %Get sheetname from excel
                    sheets = sheetnames(received_data_Obj(length_objNames).Description);

                    %Write data object and respective attribute in excel sheet
                    xlRange_SV=strcat(ColumnSelect_SV,num2str((length(StoreInputDataObject1))+1));%Create range of excel sheet where user wants to write data
                    message_SV = WriteData({received_data_Obj(length_objNames).Name},received_data_Obj(length_objNames).Description,sheets,xlRange_SV);%Replace data received from java
                    if ~isempty(message_SV.message)
                        if contains(message_SV.message,'may be open') %Excel sheet is open,close it and try again
                           errorCode="921";
                           SendCode=table(errorCode);
                           close(LoadingIndicator);
                           return;
                        end
                    end

                    %Create range of excel sheet where user wants to write data
                    xlRange_SV_DataType=strcat(ColumnSelect_SV_DataType,num2str((length(StoreInputDataObject1))+1));%Create range of excel sheet where user wants to write data
                    xlRange_SV_Offset=strcat(ColumnSelect_SV_Offset,num2str((length(StoreInputDataObject1))+1));%Create range of excel sheet where user wants to write data
                    xlRange_SV_slope=strcat(ColumnSelect_SV_slope,num2str((length(StoreInputDataObject1))+1));%Create range of excel sheet where user wants to write data
                    xlRange_ModelName=strcat(ColumnSelect_ModelName,num2str((length(StoreInputDataObject1))+1));%Create range of excel sheet where user wants to write data
                    %Loop used to check xlrange contains alphabet
                    for indexAlphabet=1:length(Alphabet)
                        if contains(char(xlRange_SV_DataType),Alphabet(indexAlphabet))%If column header 'DataType_Source Variable' is present in excel then only replace with empty cell
                            message_SV_DataType = WriteData({received_data_Obj(length_objNames).Basetype},received_data_Obj(length_objNames).Description,sheets,xlRange_SV_DataType);%Replace data received from java
                            if ~isempty(message_SV_DataType.message)
                                if contains(message_SV_DataType.message,'may be open') %Excel sheet is open,close it and try again
                                   errorCode="921";
                                   SendCode=table(errorCode);
                                   close(LoadingIndicator);
                                   return;
                                end
                            end
                        end

                        if contains(char(xlRange_SV_Offset),Alphabet(indexAlphabet))%If column header 'Offset_Source Variable' is present in excel then only replace with empty cell
                            message_SV_Offset = WriteData({str2num(received_data_Obj(length_objNames).Offset)},received_data_Obj(length_objNames).Description,sheets,xlRange_SV_Offset);%Replace data received from java
                            if ~isempty(message_SV_Offset.message)
                                if contains(message_SV_Offset.message,'may be open') %Excel sheet is open,close it and try again
                                   errorCode="921";
                                   SendCode=table(errorCode);
                                   close(LoadingIndicator);
                                   return;
                                end
                            end
                        end

                        if contains(char(xlRange_SV_slope),Alphabet(indexAlphabet))%If column header 'Slope_Source Variable' is present in excel then only replace with empty cell
                            message_SV_slope = WriteData({str2num(received_data_Obj(length_objNames).slope)},received_data_Obj(length_objNames).Description,sheets,xlRange_SV_slope);%Replace data received from java
                            if ~isempty(message_SV_slope.message)
                                if contains(message_SV_slope.message,'may be open') %Excel sheet is open,close it and try again
                                   errorCode="921";
                                   SendCode=table(errorCode);
                                   close(LoadingIndicator);
                                   return;
                                end
                            end
                        end

                        if contains(char(xlRange_ModelName),Alphabet(indexAlphabet))%If column header 'Model' is present in excel then only replace with empty cell
                            message_ModelName = WriteData({upper(received_data_Obj(length_objNames).component)},received_data_Obj(length_objNames).Description,sheets,xlRange_ModelName);%Replace data received from java
                            if ~isempty(message_ModelName.message)
                                if contains(message_ModelName.message,'may be open') %Excel sheet is open,close it and try again
                                   errorCode="921";
                                   SendCode=table(errorCode);
                                   close(LoadingIndicator);
                                   return;
                                end
                            end
                        end
                    end
                end

          case 'Output'    
                %Checking received data object is already present in
                %excel will send errorcode:935
                Data2="";Data2(:,3)="";cntr=1;cntr4=1;
                [DataObjFoundInExcel,~]=ismember(StoreOutputDataObject1,received_data_Obj(length_objNames).Name);
                %Pre allocate memory
                StorePositionOfDataObj1{1,length(DataObjFoundInExcel)} = [];
                %Loop used to store exact position of data object in
                %excel
               for index=1:length(DataObjFoundInExcel)
                   if DataObjFoundInExcel(index)==1
                       StorePositionOfDataObj1{cntr}=index;
                       cntr=cntr+1;
                   end
               end
               %remove empty cell
               StorePositionOfDataObj1 = StorePositionOfDataObj1(~cellfun('isempty', StorePositionOfDataObj1));
               StorePositionOfDataObj = string(StorePositionOfDataObj1);
               [~,~,~,~,ColumnSelect_ModelName] = FindColumnOfDestinationVariable(StoreIndexOutputName,StoreIndexDataTypeName_Output,StoreIndexOffsetName_Output,StoreIndexSlopeName_Output,StoreIndexComponentName);
               %Create xlRange of component
               GetCellOfModel=strcat(ColumnSelect_ModelName,StorePositionOfDataObj);
               GetCellOfModel=strcat(GetCellOfModel,':',GetCellOfModel);
               if isempty(GetCellOfModel)
                   GetCellOfModel = '';
               end
               %Get the name of component
               FoundSVInOtherComponent  = readcell(received_data_Obj(length_objNames).Description,'Range',char(GetCellOfModel));
               %Cheking that received data object name is from same component
               if strcmp(string(FoundSVInOtherComponent),string(upper(received_data_Obj(length_objNames).component)))
                    if nnz(DataObjFoundInExcel)>0
                        flag2=1;
                        Data2(cntr4,1) = string(num2str(935));
                        Data2(cntr4,2) = string(received_data_Obj(length_objNames).category);
                        Data2(cntr4,3) = string(received_data_Obj(length_objNames).Name); 
                        Data2(cntr4,4) = ('is already present in excel sheet so cannot be added');
                        cntr4=cntr4+1;
                    end
               end
               if ~strcmp(Data2(:,3),received_data_Obj(length_objNames).Name)
                   %Find column of Destination variable/data type/offset/slope in excel
                   [ColumnSelect_DV,ColumnSelect_DV_DataType,ColumnSelect_DV_Offset,ColumnSelect_DV_slope,ColumnSelect_ModelName] = FindColumnOfDestinationVariable(StoreIndexOutputName,StoreIndexDataTypeName_Output,StoreIndexOffsetName_Output,StoreIndexSlopeName_Output,StoreIndexComponentName);

                    %Get sheetname from excel
                    sheets = sheetnames(received_data_Obj(length_objNames).Description);

                    %Write data object and respective attribute in excel sheet
                    xlRange_DV=strcat(ColumnSelect_DV,num2str((length(StoreOutputDataObject1))+1));%Create range of excel sheet where user wants to write data
                    message_DV = WriteData({received_data_Obj(length_objNames).Name},received_data_Obj(length_objNames).Description,sheets,xlRange_DV);%Replace data received from java
                    if ~isempty(message_DV.message)
                        if contains(message_DV.message,'may be open') %Excel sheet is open,close it and try again
                           errorCode="921";
                           SendCode=table(errorCode);
                           close(LoadingIndicator);
                           return;
                        end
                    end

                    %Create range of excel sheet where user wants to write data
                    xlRange_DV_DataType=strcat(ColumnSelect_DV_DataType,num2str((length(StoreOutputDataObject1))+1));%Create range of excel sheet where user wants to write data
                    xlRange_DV_Offset=strcat(ColumnSelect_DV_Offset,num2str((length(StoreOutputDataObject1))+1));%Create range of excel sheet where user wants to write data
                    xlRange_DV_slope=strcat(ColumnSelect_DV_slope,num2str((length(StoreOutputDataObject1))+1));%Create range of excel sheet where user wants to write data
                    xlRange_ModelName=strcat(ColumnSelect_ModelName,num2str((length(StoreOutputDataObject1))+1));%Create range of excel sheet where user wants to write data
                    %Loop used to check xlrange contains alphabet
                    for indexAlphabet=1:length(Alphabet)
                        if contains(char(xlRange_DV_DataType),Alphabet(indexAlphabet))%If column header 'DataType_Destination Variable' is present in excel then only replace with empty cell
                            message_DV_DataType = WriteData({received_data_Obj(length_objNames).Basetype},received_data_Obj(length_objNames).Description,sheets,xlRange_DV_DataType);%Replace data received from java
                            if ~isempty(message_DV_DataType.message)
                                if contains(message_DV_DataType.message,'may be open') %Excel sheet is open,close it and try again
                                   errorCode="921";
                                   SendCode=table(errorCode);
                                   close(LoadingIndicator);
                                   return;
                                end
                            end
                        end

                        if contains(char(xlRange_DV_Offset),Alphabet(indexAlphabet))%If column header 'Offset_Destination Variable' is present in excel then only replace with empty cell
                            message_DV_Offset = WriteData({str2num(received_data_Obj(length_objNames).Offset)},received_data_Obj(length_objNames).Description,sheets,xlRange_DV_Offset);%Replace data received from java
                            if ~isempty(message_DV_Offset.message)
                                if contains(message_DV_Offset.message,'may be open') %Excel sheet is open,close it and try again
                                   errorCode="921";
                                   SendCode=table(errorCode);
                                   close(LoadingIndicator);
                                   return;
                                end
                            end
                        end

                        if contains(char(xlRange_DV_slope),Alphabet(indexAlphabet))%If column header 'slope_Destination Variable' is present in excel then only replace with empty cell
                            message_DV_slope = WriteData({str2num(received_data_Obj(length_objNames).slope)},received_data_Obj(length_objNames).Description,sheets,xlRange_DV_slope);%Replace data received from java
                            if ~isempty(message_DV_slope.message)
                                if contains(message_DV_slope.message,'may be open') %Excel sheet is open,close it and try again
                                   errorCode="921";
                                   SendCode=table(errorCode);
                                   close(LoadingIndicator);
                                   return;
                                end
                            end
                        end

                        if contains(char(xlRange_ModelName),Alphabet(indexAlphabet))%If column header 'Model' is present in excel then only replace with empty cell
                            message_ModelName = WriteData({upper(received_data_Obj(length_objNames).component)},received_data_Obj(length_objNames).Description,sheets,xlRange_ModelName);%Replace data received from java
                            if ~isempty(message_ModelName.message)
                                if contains(message_ModelName.message,'may be open') %Excel sheet is open,close it and try again
                                   errorCode="921";
                                   SendCode=table(errorCode);
                                   close(LoadingIndicator);
                                   return;
                                end
                            end
                        end
                    end
               end
      end
    end
    waitbar(length_objNames/length(received_data_Obj),LoadingIndicator,sprintf(' %1.0f%% Completed',(length_objNames/length(received_data_Obj))*100))%Counting of Loadingindicator
 end
%Data object already present in excel
if isequal(flag,1)||isequal(flag2,1)||isequal(flag3,1)||isequal(flag4,1)
    if ~isempty(Data1{1})
        AlreadyPresentDataObjIn = {cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'} )};
    end
    if ~isempty(Data2{1})
        AlreadyPresentDataObjOut = {cell2table(cellstr(Data2),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'} )};
    end
    if ~isempty(Data3{1})
        InputNotPresentInExcel = {cell2table(cellstr(Data3),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'} )};
    end
    if ~isempty(Data4{1})
        OutputNotPresentInExcel = {cell2table(cellstr(Data4),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'} )};
    end
        SendData=vertcat(AlreadyPresentDataObjIn,AlreadyPresentDataObjOut,InputNotPresentInExcel,OutputNotPresentInExcel);
end
if isempty(SendData)
    close(LoadingIndicator);
    messageCode = "920";
    SendCode=table(messageCode);%Add/Delete data objects succesfully in excel sheet
else
    close(LoadingIndicator);
    SendCode=SendData;  % Send data
end
end

function ErrorCode = WriteData(received_data,FilePath,sheets,xlRange)
    ErrorCode.message = [];
    try
        writecell(received_data,FilePath,'Sheet',char(sheets(1)),'Range',char(xlRange));%Replace data received from java
    catch Exception
        ErrorCode = Exception;
    end
end

