%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :SingleSlddOutput
% MAIN PURPOSE     :Function is used to display the list of outputs in the input tab at the time 
%                   of adding data objects of inputs. 
% INPUT(S)         :1.SlddPath=('C:/Users/shubhangim1/Music/Fresh_Project/E39_example/EngineAccessoryLoad/etloc/Model/etloc.sldd')
% OUTPUT           :1.Display outputs of selected sldd.
%                  :2.If output is not present in sldd will send errorCode:656
% DATE OF CREATION :3th June 2020
% REVESION NO      :1.1
% STATUS           :Rev. 1.1: Tested to get output and its attributes of
%                             selected sldd
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function Outputs = SingleSlddOutput(SlddPath,~)

StructOutputs=struct('component','','category','','Name','','Value','','Description','',...
            'Basetype','','Offset','','slope','','Min',0,'Max',0,...
            'Unit','','Dimensions','',...
            'DimensionsMode','','Complexity','',...
            'SampleTime','','InitialValue','',...
            'CoderInfo','Null','SwCalibrationAccess','','DisplayFormat','',...
            'oldName','','maxDimension','');

%Function to get output data objects and its attribute
[AllOutputObjStrct,AllOutputObj,modelData] = DataOutputSig(SlddPath);  
if ~isempty(modelData)
    Outputs=table(modelData);%If any error occurs while opening sldd will send
    return;
end
if ~(AllOutputObj == "")
    cntr=1;
    for index1=1:length(AllOutputObjStrct)
        
         [Basetype, Offset, slope] = SlddtoUI_AbstractDataType(string(AllOutputObjStrct(index1).SignalDet.DataType));
         if isempty(AllOutputObjStrct(index1).SignalDet.Min)
             AllOutputObjStrct(index1).SignalDet.Min=1.111111111111111e+104;
         end
         if isempty(AllOutputObjStrct(index1).SignalDet.Max)
             AllOutputObjStrct(index1).SignalDet.Max=1.111111111111111e+104;
         end
         StructOutputs(cntr)=struct('component',strtok(AllOutputObjStrct(index1).CompName,'.'),'category','Output','Name',AllOutputObjStrct(index1).DataObjName,'Value',"Null",'Description',AllOutputObjStrct(index1).SignalDet.Description,...
            'Basetype',Basetype,'Offset',Offset,'slope',slope,'Min',AllOutputObjStrct(index1).SignalDet.Min,'Max',AllOutputObjStrct(index1).SignalDet.Max,...
            'Unit',AllOutputObjStrct(index1).SignalDet.Unit,'Dimensions',AllOutputObjStrct(index1).SignalDet.Dimensions,...
            'DimensionsMode',AllOutputObjStrct(index1).SignalDet.DimensionsMode,'Complexity',AllOutputObjStrct(index1).SignalDet.Complexity,...
            'SampleTime',AllOutputObjStrct(index1).SignalDet.SampleTime,'InitialValue',AllOutputObjStrct(index1).SignalDet.InitialValue,...
            'CoderInfo','Null','SwCalibrationAccess',AllOutputObjStrct(index1).SignalDet.SwCalibrationAccess,'DisplayFormat',string(AllOutputObjStrct(index1).SignalDet.DisplayFormat),...
            'oldName',AllOutputObjStrct(index1).DataObjName,'maxDimension',length(AllOutputObjStrct(index1).SignalDet.InitialValue));
            cntr=cntr+1;
    end
    Outputs = (struct2table(StructOutputs,'AsArray',true));
%     Outputs = strcat('[',Outputs,']');
else
    errorCode = "656";
    Outputs = (table(errorCode));
    return;
end
end

function [AllOutputObjStrct,AllOutputObj,modelData] = DataOutputSig(SlddPath)
OutputDobjCntr = 1;
AllOutputObj="";
modelData={};
AllOutputObjStrct = struct('DataObjName','','CompName','','SignalDet','');
%Logic written for loading indicator
LoadingIndicator = waitbar(0,' 0% Completed','Name','Fetching output signals...','WindowStyle', 'modal');
frames = java.awt.Frame.getFrames();
frames(end).setAlwaysOnTop(1);
javaFrame = get(LoadingIndicator,'JavaFrame');
ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));
%If sldd throw any type of error will catch here
try
    dicObj = Simulink.data.dictionary.open(char(SlddPath));%Open sldd
catch Exception
    modelData={Exception.message};  %If any error throw while opening sldd    
    close(LoadingIndicator)
    return;
end
dicSec = getSection(dicObj,'Design Data');
DataObj =  find(dicSec,'-value','-class','AUTOSAR.Signal');
if isempty(DataObj)
   DataObj =  find(dicSec,'-value','-class','Simulink.Signal');
end

%Loop to get all attributes of each I/O data object
for Index = 1:length(DataObj)
    ValueStructTemp = DataObj(Index).getValue;
    if ~isnumeric(ValueStructTemp)&& ~ischar(ValueStructTemp)&&~isstring(ValueStructTemp)
        GetFields=fields(ValueStructTemp);               %Get fields of data object
        log_array = ismember(GetFields,'objectType'); %Check data object having object type
        varv = nnz(log_array);
        if varv==1
            CategoryTemp = ValueStructTemp.objectType;
            if (strcmp(CategoryTemp,'Output'))
                AllOutputObj(1,OutputDobjCntr) = string(DataObj(Index).Name); 
                AllOutputObjStrct(OutputDobjCntr) = struct('DataObjName',string(DataObj(Index).Name),'CompName',string(DataObj(Index).DataSource),'SignalDet',ValueStructTemp);
                OutputDobjCntr = OutputDobjCntr + 1;
            end
        end
    end
    waitbar(Index/length(DataObj),LoadingIndicator,sprintf(' %1.0f%% Completed',(Index/length(DataObj)*100)));
end
close(LoadingIndicator);
end