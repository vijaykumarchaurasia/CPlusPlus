%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :DataObjectRenameInModel
% MAIN PURPOSE     :Function is used to rename data objects of all categories available in model   
% INPUT(S)         :1.sldd_path=('C:\Users\shubhangim1\Music\E39_example\AirManagement\aserc\Model\aserc.sldd')
%                   2.Dobjoldname=('ASERC_flgModeEn')
%                   3.Dobjnewname=('Rename_Output')
%                   4.DobjCategory=('Output')
% OUTPUT           :1.Sending model path
% DATE OF CREATION :30th July 2019
% REVESION NO      :-
% STATUS           :Function has been written to called in "RenameInModel" script 
% FUNCTION CALL    :[~,StateflowChart,UniqueDataObjCalibDef,InputObjStateflow,OutputObjStateflow,LocalObjStateflow,ChartTransitions,ChartState,AllPathInput,AllPathOutput,AllPathLocal,AllPathDefineCalib,ConstantPath_First_Order_Transfer_Fcn,Fix1DLookupPath,Float1DLookupPath,Fix2DLookupPath,Float2DLookupPath,LookupPath,LookupTableName,PreLookupPathMapCurve,PreLookupTableName,PreLookupPath,NvmPath,DataStoreWritePath,DataStoreReadPath]= FindPathOfDataObject(ModelName);
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [modelSuccess] = DataObjectRenameInModel(sldd_path,Dobjoldname,Dobjnewname,DobjCategory,GetmodelPath)
categoryfields = {'Local','Input','Output','Nvm','Define','Map','Curve','Calibration','Axis'};
% User has to change string name if Masktype of block get changed in model
SParameter1='SParameter1';
SParameter2='SParameter2';
SParameter4='SParameter4';
DataStoreName='DataStoreName';
%Initialization of variables
AllPath='';
StorePath1D={};
StoreName1D={};
StorePathPreLookupCurve1={};
StorePathPreLookupCurve={};
StorePreLookupCurve1={};
StorePreLookupCurve={};
StorePath2D={};
StoreName2D={};
StorePathPreLookupMap1={};
StorePathPreLookupMap={};
StorePreLookupMap1={};
StorePreLookupMap={};
StorePath_1D={};
StorePath_AxisObj_1D={};
Store_Axis_1D={};
Store_AxisObj_1D={};
StorePath_2D={};
StorePath_Axis_2D={};
Store_X_Axis_2D_Map1={};
Store_X_Axis_2D_Map={};
Store_Y_Axis_2D_Map1={};
Store_Y_Axis_2D_Map={};
StorePreLookupAxisPath={};
StorePreLookupAxisPath1={};
StorePreLookupAxis={};
StorePreLookupAxis1={};

%Creating path of model
strSplit=split(sldd_path,".sldd");Appendstr='.slx'; %Splitting sldd path and creating model path
model_path=strcat(strSplit,Appendstr);
model_name=char(model_path(1));
expression = '\w*.slx\w*';
ModelName = regexp(model_name,expression,'match');
ModelName = strtok(ModelName,'.');                  %Creating model name
load_system(GetmodelPath) 	                        %Loading model

%Get path of all categories of data objects
[~,StateflowChart,UniqueDataObjCalibDef,InputObjStateflow,OutputObjStateflow,LocalObjStateflow,ChartTransitions,ChartState,AllPathInput,AllPathOutput,AllPathLocal,AllPathDefineCalib,ConstantPath_First_Order_Transfer_Fcn,Fix1DLookupPath,Float1DLookupPath,Fix2DLookupPath,Float2DLookupPath,LookupPath,LookupTableName,PreLookupPathMapCurve,PreLookupTableName,PreLookupPath,NvmPath,DataStoreWritePath,DataStoreReadPath]= FindPathOfDataObject(ModelName);

%Combining all Stateflow data object
combine1=union(UniqueDataObjCalibDef,InputObjStateflow);
combine2=union(combine1,OutputObjStateflow);
AllStateflowDataObj=union(combine2,LocalObjStateflow);

%Checking old data object name ismember of stateflow
[ChkDataObjIsMemStateflow, ~] = ismember(AllStateflowDataObj,Dobjoldname);
if nnz(ChkDataObjIsMemStateflow)>0     %If old data object name present in stateflow
    for index1=1:length(StateflowChart)
        ChartName=StateflowChart(index1).Name;
        sfrt = sfroot;
        StateflowChart = sfrt.find('-isa','Simulink.BlockDiagram');
        ChartName = StateflowChart.find('-isa','Stateflow.Chart','Name',ChartName);

        %Rename Parameter in model explorer
        ChartData = ChartName.find('-isa', 'Stateflow.Data','-and','Name',Dobjoldname);
        ChartData.Name = Dobjnewname;

        %Rename data objects resides in transition of stateflow
        for index=1:length(ChartTransitions)
            LabelStr = ChartTransitions(index).LabelString;
            if ismember(Dobjoldname,LabelStr)
                ChartTransitions(index).LabelString = strrep(LabelStr,Dobjoldname,Dobjnewname);
            end
        end

        %Rename data objects resides in state of stateflow
        for index=1:length(ChartState)
            LabelStr = ChartState(index).LabelString;
            if ismember(Dobjoldname,LabelStr)
                ChartState(index).LabelString = strrep(LabelStr,Dobjoldname,Dobjnewname);
            end
        end
    end
end
%Get category to find respective path of data object
flag_calib=0;
flag2=0;
flag3=0;
switch(DobjCategory)
       case 'Input'
            %Get input data objects
            AllPathInput=find_system(ModelName,'BlockType','Inport');%Get all levels paths of input data object
            InputPath=AllPathInput;                                  %Get path of input data object
            InputName=get_param(InputPath,'Name');                   %Get data object name of input
            [DobjMatch,~] = ismember(InputName,Dobjoldname);         %Checking oldName is member of input
            StorePosDtObj2 = find(DobjMatch);
            for index3= 1:length(StorePosDtObj2)
                set_param(char(InputPath(StorePosDtObj2(index3))),'Name',Dobjnewname)  %Set input data object name in model
                save_system(GetmodelPath) %Save model
                flag2=1;
            end
            %Get local data objects
            localPath=AllPathLocal;                                              %Get path of local data object
            DataObjectLocal=get_param(localPath,'Name');                   %Get data object name of local
            [InpLocalMatch,~]=ismember(DataObjectLocal,Dobjoldname);
            StorePosDtObj3 = find(InpLocalMatch);
            if ~isempty(StorePosDtObj3) %If local data object not present
                for index2= 1:length(StorePosDtObj3) %If local data object is present
                    set_param(double(localPath(StorePosDtObj3(index2))),'Name',Dobjnewname)  %Set local data object name in model
                    save_system(GetmodelPath)          %Save model
                end
            end
            if flag2==1
                modelSuccess = GetmodelPath; %Sending model path to open model at the end of renamed in model
                return;
            else
                modelSuccess = GetmodelPath; 
                return;
            end      
                
        case 'Output'   
            %Get output data objects
            AllPathOutput=find_system(ModelName,'BlockType','Outport');%Get all levels paths of output data object
            OutputPath=AllPathOutput;                                  %Get path of output data object
            OutputName=get_param(OutputPath,'Name');                   %Get data object name of output
            [DobjMatch,~] = ismember(OutputName,Dobjoldname);          %Checking oldName is member of input
            StorePosDtObj2 = find(DobjMatch);
            for index3= 1:length(StorePosDtObj2)
                set_param(char(OutputPath(StorePosDtObj2(index3))),'Name',Dobjnewname)  %Set input data object name in model
                save_system(GetmodelPath) %Save model
                flag2=1;
            end
            %Get local data objects
            localPath=AllPathLocal;                                        %Get path of local data object(Resolved signal)
            DataObjectLocal=get_param(localPath,'Name');                   %Get data object name of locakl
            [OutLocalMatch,~]=ismember(DataObjectLocal,Dobjoldname);
            StorePosDtObj3 = find(OutLocalMatch);
            if ~isempty(StorePosDtObj3) %If local data object not present
                for index2= 1:length(StorePosDtObj3) %If local data object is present
                    set_param(double(localPath(StorePosDtObj3(index2))),'Name',Dobjnewname)  %Set local data object name in model
                    save_system(GetmodelPath)          %Save model
                end
            end
            if flag2==1
                modelSuccess = GetmodelPath; %Sending model path to open model at the end of renamed in model
                return;
            else
                modelSuccess = GetmodelPath; 
                return;
            end      
                   
        case 'Local'
             DataObjectLocal1=get_param(AllPathLocal,'Name'); %Get oly resolved signal path       
             [DobjMatch1,~] = ismember(DataObjectLocal1,Dobjoldname); %Checking oldName is member of input
             StorePosDtObj1 = find(DobjMatch1);
             set_param(double(AllPathLocal(StorePosDtObj1(end))),'Name',Dobjnewname)  %Set local data object name in model
             save_system(GetmodelPath) %Save model
             
             StoreSplit1=strsplit(GetmodelPath,'/');
             StoreSplit2=strsplit(char(StoreSplit1(end)),'.');
             AllBlkPath = find_system(char(StoreSplit2(1)));%Get all path of model
             DataObjectLocal2=get_param(AllBlkPath,'Name');             
             [DobjMatch2,~] = ismember(DataObjectLocal2,Dobjoldname);   %Checking oldName is member of input
             StorePosDtObj2 = find(DobjMatch2);
             for index11= 1:length(StorePosDtObj2)
                 set_param(char(AllBlkPath(StorePosDtObj2(index11))),'Name',Dobjnewname)  %Set input data object name in model
                 save_system(GetmodelPath) %Save model
             end
                        
             GoToBlock=find_system(char(StoreSplit2(1)),'BlockType','Goto');%Get only GoTo block path
             DataObjectGoTo=get_param(GoToBlock,'GotoTag');             
             [DobjMatchGoTo,~] = ismember(DataObjectGoTo,Dobjoldname);          %Checking oldName is member of input
             StorePosDtObj2 = find(DobjMatchGoTo);
             for index12= 1:length(StorePosDtObj2)
                 set_param(char(GoToBlock(StorePosDtObj2(index12))),'GotoTag',Dobjnewname)  %Set input data object name in model
                 save_system(GetmodelPath) %Save model
             end

             FromBlock=find_system(char(StoreSplit2(1)),'BlockType','From');%Get only GoTo block path
             DataObjectFrom=get_param(FromBlock,'GotoTag');             
             [DobjMatchFrom,~] = ismember(DataObjectFrom,Dobjoldname);          %Checking oldName is member of input
             StorePosDtObj3 = find(DobjMatchFrom);
             for index13= 1:length(StorePosDtObj3)
                 set_param(char(FromBlock(StorePosDtObj3(index13))),'GotoTag',Dobjnewname)  %Set input data object name in model
                 save_system(GetmodelPath) %Save model
             end             
             
            modelSuccess = GetmodelPath; %Sending model path to open model at the end of renamed in model
            return;
             
        case 'Define'    
             AllPath=AllPathDefineCalib;                                       %Get path of Define data object
             KeyToGetParameters='Value';                                       %Key to access Define data objects name
        case 'Calibration'
             if flag_calib==0
                AllPath=AllPathDefineCalib;
                KeyToGetParameters='Value';                                    %Key to access Calibration data objects name
                DataObject=get_param(AllPath,KeyToGetParameters);              %Get data objects name
                %Checking oldName of data object is present in sldd 
                [oldNameIsPresentInSldd,pos] = ismember(DataObject,Dobjoldname);
                if ~nnz(oldNameIsPresentInSldd)
                    AllPath=ConstantPath_First_Order_Transfer_Fcn;
                    KeyToGetParameters='PoleZ';                                %'PoleZ' is the key to extract Calibration data object
                    DataObject=get_param(AllPath,KeyToGetParameters);          %Get data objects name
                    %Checking oldName of data object is present in model
                    [~,pos] = ismember(DataObject,Dobjoldname);
                end
                %Renaming data object belongs to other categories
                for index = 1:length(pos)
                    if pos(index)==1
                        set_param((char(AllPath{index})),KeyToGetParameters,Dobjnewname) %Set data object name in model
                        save_system(GetmodelPath) %Save model
                    end
                end
             end
%***************************************************************************************************************************************************************            
        case 'Curve'  
            %When Masktype is Fix1DLookup
            AllPath1=Fix1DLookupPath;                                            %Get path of 'Fix1DLookup' to access Curve data object 
            DataObjectFix1DLookup_X_Axis=get_param(AllPath1,SParameter1);        %Get Curve DataObj for Fix 1D Lookup Table
            if ~isempty(AllPath1) && ~isempty(DataObjectFix1DLookup_X_Axis)
                %Checking 'Dobjoldname' is present in model
                [~,pos] = ismember(DataObjectFix1DLookup_X_Axis,Dobjoldname);
                %Get position of data object and rename it
                for index = 1:length(pos)
                    if pos(index)==1
                        set_param((char(AllPath1{index})),SParameter1,Dobjnewname) %Set data object name in model
                        save_system(GetmodelPath)  %Save model
                        flag3=1;
                    end
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %When Masktype is Float1DLookup
            AllPath2=Float1DLookupPath;                                           %Get path of 'Float1DLookup' to access Curve data object 
            DataObjectFloat1DLookup_X_Axis=get_param(AllPath2,SParameter1);       %Get DataObj for Float 2D Lookup Table
            if ~isempty(AllPath2) && ~isempty(DataObjectFloat1DLookup_X_Axis)
                %Checking 'Dobjoldname' is present in model
                [~,pos] = ismember(DataObjectFloat1DLookup_X_Axis,Dobjoldname);
                %Get position of data object and rename it
                for index = 1:length(pos)
                    if pos(index)==1
                        set_param((char(AllPath2{index})),SParameter1,Dobjnewname) %Set data object name in model
                        save_system(GetmodelPath)  %Save model
                        flag3=1;
                    end
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            cntr1 = 1;
            if ~isempty(LookupPath)
                for index4 = 1:length(LookupTableName)
                    if strcmp(char(cellstr(LookupTableName{index4})),'1')
                        StorePath1D{cntr1}=LookupPath{index4};
                        StoreName1D{cntr1} = get_param(LookupPath{index4},'Table');
                        cntr1 = cntr1+1;
                    end
                end
            end
            if ~isempty(LookupPath)
              if ~isempty(StorePath1D) && ~isempty(StoreName1D) %Storing data object and path of X_Axis of 1D lookup
                 %Checking 'Dobjoldname' is present in model 
                 [~,pos] = ismember(StoreName1D,Dobjoldname);
                 %Get position of data object and rename it
                 for index = 1:length(pos)
                     if pos(index)==1
                        set_param((char(StorePath1D{index})),'Table',Dobjnewname) %Set data object name in model
                        save_system(GetmodelPath)  %Save model
                        flag3=1;
                     end
                 end
               end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            if ~isempty(PreLookupPathMapCurve)
                for index5=1:length(PreLookupTableName)
                    if strcmp(char(cellstr(PreLookupTableName{index5})),'1')
                        StorePathPreLookupCurve1{cntr1}=PreLookupPathMapCurve{index5};
                        StorePathPreLookupCurve = StorePathPreLookupCurve1(~cellfun('isempty', StorePathPreLookupCurve1)); %Path
                        StorePreLookupCurve1{cntr1} = get_param(PreLookupPathMapCurve{index5},'Table'); %For 1D (Curve using prelookup)
                        StorePreLookupCurve = StorePreLookupCurve1(~cellfun('isempty', StorePreLookupCurve1));%data object
                        cntr1 = cntr1+1;
                    end
                end
            end
            if ~isempty(PreLookupPathMapCurve)
                if ~isempty(StorePathPreLookupCurve) && ~isempty(StorePreLookupCurve) %Storing data object and path of X_Axis of 1D lookup
                    %Checking 'Dobjoldname' is present in model 
                    [~,pos] = ismember(StorePreLookupCurve,Dobjoldname);
                    %Get position of data object and rename it
                    for index = 1:length(pos)
                        if pos(index)==1
                            set_param((char(StorePathPreLookupCurve{index})),'Table',Dobjnewname) %Set data object name in model
                            save_system(GetmodelPath)  %Save model
                            flag3=1;
                        end
                    end
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %Send model path as output of this function
            if flag3==1
                modelSuccess = GetmodelPath;
                return;
            end
%*********************************************************************************************************************************************************            
        case 'Map' 
            %When MaskType is Fix2DLookup
            AllPath1=Fix2DLookupPath;                                       %Get path of 'Fix2DLookup' to access Map data object
            DataObjectFix2DLookup_Map=get_param(AllPath1,SParameter1);      %Get Y Axis DataObj for fix 2D Lookup Table  
            if ~isempty(AllPath1) && ~isempty(DataObjectFix2DLookup_Map)
                %Checking 'Dobjoldname' is present in model
                [~,pos] = ismember(DataObjectFix2DLookup_Map,Dobjoldname);
                %Get position of data object and rename it
                for index = 1:length(pos)
                    if pos(index)==1
                        set_param((char(AllPath1{index})),SParameter1,Dobjnewname) %Set data object name in model
                        save_system(GetmodelPath)  %Save model
                        flag3=1;
                    end
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %When MaskType is Float2DLookup
            AllPath2=Float2DLookupPath;                                    %Get path of 'Float2DLookup' to access Map data object
            DataObjectFloat2DLookup_Map=get_param(AllPath2,SParameter1);   %Get Y Axis DataObj for fix 2D Lookup Table           
            if ~isempty(AllPath2) && ~isempty(DataObjectFloat2DLookup_Map)
                %Checking 'Dobjoldname' is present in model
                [~,pos] = ismember(DataObjectFloat2DLookup_Map,Dobjoldname);
                %Get position of data object and rename it
                for index = 1:length(pos)
                    if pos(index)==1
                        set_param((char(AllPath2{index})),SParameter1,Dobjnewname) %Set data object name in model
                        save_system(GetmodelPath)  %Save model
                        flag3=1;
                    end
                end
            end
           %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
            cntr1 = 1;
            if ~isempty(LookupPath)
                for index4 = 1:length(LookupTableName)
                    if strcmp(char(cellstr(LookupTableName{index4})),'2')
                        StorePath2D{cntr1}=LookupPath{index4};
                        StoreName2D{cntr1} = get_param(LookupPath{index4},'Table');
                        cntr1 = cntr1+1;
                    end
                end
            end
            if ~isempty(LookupPath)
              if ~isempty(StorePath2D) && ~isempty(StoreName2D) %Storing data object and path of X_Axis of 1D lookup
                  %Checking 'Dobjoldname' is present in model 
                  [~,pos] = ismember(StoreName2D,Dobjoldname);
                  %Get position of data object and rename it
                  for index = 1:length(pos)
                      if pos(index)==1
                         set_param((char(StorePath2D{index})),'Table',Dobjnewname) %Set data object name in model
                         save_system(GetmodelPath)  %Save model
                         flag3=1;
                      end
                  end
               end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            if ~isempty(PreLookupPathMapCurve)  
                for index5=1:length(PreLookupTableName)
                    if strcmp(char(cellstr(PreLookupTableName{index5})),'2')
                        StorePathPreLookupMap1{cntr1}=PreLookupPathMapCurve{index5};
                        StorePathPreLookupMap = StorePathPreLookupMap1(~cellfun('isempty', StorePathPreLookupMap1));
                        StorePreLookupMap1{cntr1} = get_param(PreLookupPathMapCurve{index5},'Table'); %For 1D (Curve using prelookup)
                        StorePreLookupMap = StorePreLookupMap1(~cellfun('isempty', StorePreLookupMap1));
                        cntr1 = cntr1+1;
                    end
                end
            end
            if ~isempty(PreLookupPathMapCurve)
                if ~isempty(StorePathPreLookupMap) && ~isempty(StorePreLookupMap) %Storing data object and path of X_Axis of 1D lookup
                    %Checking 'Dobjoldname' is present in model 
                    [~,pos] = ismember(StorePreLookupMap,Dobjoldname);
                    %Get position of data object and rename it
                    for index = 1:length(pos)
                        if pos(index)==1
                            set_param((char(StorePathPreLookupMap{index})),'Table',Dobjnewname) %Set data object name in model
                            save_system(GetmodelPath)  %Save model
                            flag3=1;
                        end
                    end
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %Send model path as output of this function
            if flag3==1
                modelSuccess = GetmodelPath;
                return;
            end   
%******************************************************************************************************************************************************************************************
        case 'Axis'
             %When MaskType is Fix1DLookup
             AllPath1=Fix1DLookupPath;                                      %Get path of Axis data object form Fix1DLookup 
             DataObjectFix1DLookup_X_Axis=get_param(AllPath1,SParameter2);  %Get X Axis DataObj for Fix 1D Lookup Table           
             if ~isempty(AllPath1) && ~isempty(DataObjectFix1DLookup_X_Axis)
                %Checking 'Dobjoldname' is present in model
                [~,pos] = ismember(DataObjectFix1DLookup_X_Axis,Dobjoldname);
                %Get position of data object and rename it
                for index = 1:length(pos)
                    if pos(index)==1
                        set_param((char(AllPath1{index})),SParameter2,Dobjnewname) %Set data object name in model
                        save_system(GetmodelPath)  %Save model
                        flag3=1;
                    end
                end
             end
           %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %When MaskType is Fix2DLookup
            AllPath2=Fix2DLookupPath;
            DataObjectFix2DLookup_X_Axis=get_param(AllPath2,SParameter4);    %Get X Axis DataObj for Fix 2D Lookup Table
            DataObjectFix2DLookup_Y_Axis=get_param(AllPath2,SParameter2);    %Get Y Axis DataObj for fix 2D Lookup Table
            
            if ~isempty(AllPath2) && ~isempty(DataObjectFix2DLookup_X_Axis)
                %Checking 'Dobjoldname' is present in model
                [~,pos] = ismember(DataObjectFix2DLookup_X_Axis,Dobjoldname);
                %Get position of data object and rename it
                for index = 1:length(pos)
                    if pos(index)==1
                        set_param((char(AllPath2{index})),SParameter4,Dobjnewname) %Set data object name in model
                        save_system(GetmodelPath)  %Save model
                        flag3=1;
                    end
                end
            end
            if ~isempty(AllPath2) && ~isempty(DataObjectFix2DLookup_Y_Axis)
                %Checking 'Dobjoldname' is present in model 
                [~,pos] = ismember(DataObjectFix2DLookup_Y_Axis,Dobjoldname);
                %Get position of data object and rename it
                for index = 1:length(pos)
                    if pos(index)==1
                        set_param((char(AllPath2{index})),SParameter2,Dobjnewname); %Set data object name in model
                        save_system(GetmodelPath)  %Save model
                        flag3=1;
                    end
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %When MaskType is Float1DLookup
            AllPath3=Float1DLookupPath;                                    %Get path of Axis data object form Float1DLookup 
            DataObjectFloat1DLookup_X_Axis=get_param(AllPath3,SParameter2);%Get X Axis DataObj for Float 2D Lookup Table
            
            if ~isempty(AllPath3) && ~isempty(DataObjectFloat1DLookup_X_Axis)
                %Checking 'Dobjoldname' is present in model 
                [~,pos] = ismember(DataObjectFloat1DLookup_X_Axis,Dobjoldname);
                %Get position of data object and rename it
                for index = 1:length(pos)
                    if pos(index)==1
                        set_param((char(AllPath3{index})),SParameter2,Dobjnewname) %Set data object name in model
                        save_system(GetmodelPath)  %Save model
                        flag3=1;
                    end
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %When MaskType is Float2DLookup
            AllPath4=Float2DLookupPath;                                    %Get path of Axis data object form Float2DLookup
            DataObjectFloat2DLookup_X_Axis=get_param(AllPath4,SParameter4);%Get X Axis DataObj for Float 2D Lookup Table
            DataObjectFloat2DLookup_Y_Axis=get_param(AllPath4,SParameter2);%Get Y Axis DataObj for Float 2D Lookup Table
            
            if ~isempty(AllPath4) && ~isempty(DataObjectFloat2DLookup_X_Axis)
                %Checking 'Dobjoldname' is present in 'AllStructDataFloat2DLookup_X_Axis' 
                [~,pos] = ismember(DataObjectFloat2DLookup_X_Axis,Dobjoldname);
                %Get position of data object and rename it
                for index = 1:length(pos)
                    if pos(index)==1
                        set_param((char(AllPath4{index})),SParameter4,Dobjnewname) %Set data object name in model
                        save_system(GetmodelPath)  %Save model
                        flag3=1;
                    end
                end
            end
            
            if ~isempty(AllPath4) && ~isempty(DataObjectFloat2DLookup_Y_Axis)
                %Checking 'Dobjoldname' is present in model
                [~,pos] = ismember(DataObjectFloat2DLookup_Y_Axis,Dobjoldname);
                %Get position of data object and rename it
                for index = 1:length(pos)
                    if pos(index)==1
                        set_param((char(AllPath4{index})),SParameter2,Dobjnewname) %Set data object name in model
                        save_system(GetmodelPath)  %Save model
                        flag3=1;
                    end
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %Regarding BlockType:Lookup_n-D
            cntr1 = 1;
            if ~isempty(LookupPath)
                for index4 = 1:length(LookupTableName)
                    if strcmp(char(cellstr(LookupTableName{index4})),'1') %Condition to fetch 1D lookup tables axis(X_Axis)
                        StorePath_1D{cntr1}=LookupPath{index4};
                        StorePath_AxisObj_1D = StorePath_1D(~cellfun('isempty', StorePath_1D)); %Storing path of 1D lookup tables axis(X_Axis)
                        Store_Axis_1D{cntr1}= get_param(LookupPath{index4},'BreakpointsForDimension1'); %X_Axis
                        Store_AxisObj_1D = Store_Axis_1D(~cellfun('isempty', Store_Axis_1D));   %Storing data object of 1D lookup tables axis(X_Axis)
                        cntr1 = cntr1+1;
                    end
                    if strcmp(char(cellstr(LookupTableName{index4})),'2') %Condition to fetch 2D lookup tables axis(X_Axis and Y_Axis)
                        StorePath_2D{cntr1}=LookupPath{index4};
                        StorePath_Axis_2D = StorePath_2D(~cellfun('isempty', StorePath_2D));
                        Store_X_Axis_2D_Map1{cntr1}= get_param(LookupPath{index4},'BreakpointsForDimension1'); %X_Axis
                        Store_X_Axis_2D_Map = Store_X_Axis_2D_Map1(~cellfun('isempty', Store_X_Axis_2D_Map1));
                        Store_Y_Axis_2D_Map1{cntr1}= get_param(LookupPath{index4},'BreakpointsForDimension2');%Y_Axis
                        Store_Y_Axis_2D_Map = Store_Y_Axis_2D_Map1(~cellfun('isempty', Store_Y_Axis_2D_Map1));
                        cntr1 = cntr1+1;
                    end
                end
            end

            %Fetch data object and its path if 'nD_Lookup' block is not empty
            if ~isempty(LookupPath)
                if ~isempty(StorePath_AxisObj_1D) && ~isempty(Store_AxisObj_1D) %Storing data object and path of X_Axis of 1D lookup
                    %Checking 'Dobjoldname' is present in model 
                    [~,pos] = ismember(Store_AxisObj_1D,Dobjoldname);
                    %Get position of data object and rename it
                    for index = 1:length(pos)
                        if pos(index)==1
                            set_param((char(StorePath_AxisObj_1D{index})),'BreakpointsForDimension1',Dobjnewname) %Set data object name in model
                            save_system(GetmodelPath)  %Save model
                            flag3=1;
                        end
                    end
                end

                if ~isempty(StorePath_Axis_2D) && ~isempty(Store_X_Axis_2D_Map) %Storing data object and path of X_Axis of 2D lookup
                    %Checking 'Dobjoldname' is present in model
                    [~,pos] = ismember(Store_X_Axis_2D_Map,Dobjoldname);
                    %Get position of data object and rename it
                    for index = 1:length(pos)
                        if pos(index)==1
                            set_param((char(StorePath_Axis_2D{index})),'BreakpointsForDimension1',Dobjnewname) %Set data object name in model
                            save_system(GetmodelPath)  %Save model
                            flag3=1;
                        end
                    end
                end
                
                if ~isempty(StorePath_Axis_2D) && ~isempty(Store_Y_Axis_2D_Map)%Storing data object and path of Y_Axis of 2D lookup
                    %Checking 'Dobjoldname' is present in model 
                    [~,pos] = ismember(Store_Y_Axis_2D_Map,Dobjoldname);
                    %Get position of data object and rename it
                    for index = 1:length(pos)
                        if pos(index)==1
                            set_param((char(StorePath_Axis_2D{index})),'BreakpointsForDimension2',Dobjnewname) %Set data object name in model
                            save_system(GetmodelPath)  %Save model
                            flag3=1;
                        end
                    end
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %Regarding BlockType:PreLookup
            if ~isempty(PreLookupPath)
                for index6 = 1:length(PreLookupPath)
                    StorePreLookupAxisPath{cntr1}=PreLookupPath{index6};
                    StorePreLookupAxisPath1 = StorePreLookupAxisPath(~cellfun('isempty', StorePreLookupAxisPath));
                    StorePreLookupAxis{cntr1} = get_param(PreLookupPath{index6},'BreakpointsData');
                    StorePreLookupAxis1 = StorePreLookupAxis(~cellfun('isempty', StorePreLookupAxis));
                    cntr1 = cntr1+1;
                end
            end
            if ~isempty(PreLookupPath)
                if ~isempty(StorePreLookupAxisPath1) && ~isempty(StorePreLookupAxis1)
                    %Checking 'Dobjoldname' is present in model
                    [~,pos] = ismember(StorePreLookupAxis1,Dobjoldname);
                    %Get position of data object and rename it
                    for index = 1:length(pos)
                        if pos(index)==1
                            try
                                  set_param((char(StorePreLookupAxisPath1{index})),'BreakpointsData',Dobjnewname) %Set data object name in model
                            catch Message
                                  Exception=Message;
                                  modelSuccess={Exception.message};       %if model loaded previously then Exception Message displsy corrective action needs to take
                                  return;
                            end
                            save_system(GetmodelPath)  %Save model
                            flag3=1;
                        end
                    end
                end 
            end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%              
            %Send model path as output of this function
            if flag3==1
                modelSuccess = GetmodelPath;
                return;
            end
            
         case 'Nvm' 
               DataStoreMemoryPath=NvmPath;
               comb1=union(DataStoreWritePath,DataStoreReadPath,'stable'); %Combine read and write path
               comb2=union(comb1,DataStoreMemoryPath,'stable');            %Combine store memory path with read and write path
               AllPath=unique(comb2);                                      %Get unique path
               KeyToGetParameters=DataStoreName;                           %Key to access data object name
end
DataObject=get_param(AllPath,KeyToGetParameters);  %Get data objects name
flag=0;
%Checking oldName of data object is present in model
[oldNameIsPresentInSldd,pos] = ismember(DataObject,Dobjoldname);
%Get position of data object
StorePosDtObj = find(oldNameIsPresentInSldd);
%Renaming data object belongs to Local category 
if nnz(contains(categoryfields(1),DobjCategory))
    for index= 1:length(StorePosDtObj)
        set_param(double(AllPath(StorePosDtObj(index))),KeyToGetParameters,Dobjnewname)  %Set local data object name in model
        save_system(GetmodelPath)        %Save model
        flag=1;
    end
else
    %Renaming data object belongs to other categories
    for index = 1:length(pos)
        if pos(index)==1
            set_param((char(AllPath{index})),KeyToGetParameters,Dobjnewname) %Set data object name in model
            save_system(GetmodelPath) %Save model
            flag=1;
        end
    end
end
if flag==1
    modelSuccess = GetmodelPath; %Sending model path to open model at the end of renamed in model
else
    modelSuccess = GetmodelPath;  
end
