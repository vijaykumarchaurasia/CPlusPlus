%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :GetConfigExcelFilePathDbFiles
% MAIN PURPOSE     :Function is used to get ObjectTypeDb files path
% INPUT(S)         :
% OUTPUT           :Get Get configuration excel file path
% DATE OF CREATION :2nd July 2021
% REVESION NO      :Rev.1.1
% STATUS           :Rev.1.1: Tested to getpath of configuration excel file path.
% AUTHOR           :Nitin Dahyalkar
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function DBFiles = GetConfigExcelFilePathDbFiles()

%Find the current location of the utilities
%Assumes startupNavistarMatlabUtilities is at root
Path2File = which('startupNavistarMatlabUtilities');
InstallDir = fileparts(Path2File);

if ~isempty(InstallDir)
    % Configuration file path
    DBFilesPath = [InstallDir, '\MatlabScripts\DataDictionaryTool'];
    % get all xlsx filenames in specified dir
    DBFileNames = dir([DBFilesPath '\*.xlsx']);
    if ~isempty(DBFileNames)
        DBFileNames = string({DBFileNames.name}); %make string array
        % make fully qualified filenames
        DBFiles = fullfile(DBFilesPath, DBFileNames);
    else
        DBFiles = [];
    end
else
    DBFiles = [];
end
end