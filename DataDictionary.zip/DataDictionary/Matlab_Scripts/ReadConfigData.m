%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :ReadConfigData
% MAIN PURPOSE     :Function is used to send configuration data present in excel file. 
% INPUT(S)         :1.FilePath
%                   2.sheetName
% OUTPUT           :1.Configuration data OR
%                   2.Error message
% DATE OF CREATION :2nd July 2021
% REVESION NO      :Rev.1.2
% STATUS           :Rev.1.1 Tested to read configuration excel file data
%                   Rev.1.2 Used readtable() command instead of xlsread() to read configuration excel file. 
% AUTHOR           :Nitin Dahyalkar
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [DataInTable,Exception] = ReadConfigData(ExcelPath,sheetName)
    Exception = [];
    DataInTable = [];
    try
        DataInTable = readtable(ExcelPath,'Sheet', sheetName);
    catch Error
        Exception = Error.message;
        return;
    end
end