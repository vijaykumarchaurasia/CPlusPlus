%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :InOutCompatibility
% MAIN PURPOSE     :Function is used to compare inputs of project with outputs project and display
%                   1.List of all input and output data objects that have the same name but different attribute values
%                   2.List of all input data objects that do not have a corresponding output data object 
%                   3.List of all output data objects which carrying identical name
%                   4.List of all output data objects that do not have a corresponding input data object
% INPUT(S)         :1.componentName=('C:\Users\shubhangim1\Music\E39_example')
% OUTPUT           :1.Display following list
%                     1.Inconsistant I/Os 
%                     2.Unconnected Inputs
%                     3.Duplicate Outputs
%                     4.Unconnected Outputs OR
%                   2.If list (1) is empty, will send "errorCode:103" 
%                     If list (2) is empty, will send "errorCode:104"
%                     If list (3) is empty, will send "errorCode:105" 
%                     If list (4) is empty, will send "errorCode:106" 
% DATE OF CREATION :5th June 2019
% REVESION NO      :1.6
% STATUS           :Rev. 1.1: Tested for following list 
%                             1.Inconsistant I/Os (Initial value taken for comparision) 
%                             2.Unconnected Inputs
%                             3.Duplicate Outputs
%                             4.Unconnected Outputs
%                        1.2: IO Compatibility checks fail to identify
%                             differences-To resolve this issue code
%                             restructuring done for list (1)
%                        1.3: IO compatibility identifies hidden attribute
%                             diff but doesn't display diff-Issue has been fixed
%                        1.4: Code refactring has been done for all lists-Storing all lists in the form of structure
%                        1.5: If unconnected inputs present in multiple components now its showing in list
%                        1.6: If Inputs and outputs not present in sldd
%                             then send error code(when project contains single sldd):676767
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [IODiffAttr] = InOutCompatibility(componentName,~)
%Add project folder and subfolders to path
addpath(genpath(componentName))
DirPath = dir(fullfile(componentName,'**\*.sldd'));
fileList = strcat({DirPath.folder}, {'\'},{DirPath.name});
fields_present = {'Description','DataType','Min','Max','Unit','InitialValue','Dimensions','DimensionsMode',...
    'Complexity','SampleTime','StorageClass','SwCalibrationAccess','DisplayFormat'}';

if isempty(fileList)
    errorCode = 102;
    IODiffAttr = (table(errorCode));
    return;
end
%Checking top sldd is present or not
if nnz(contains(fileList,'top.sldd')>0)
    fileList = {'top.sldd'};
    [AllInputObjName,AllInputObjComponent, AllOutputObjName,AllOutputObjComponent, AllInputObjStrct, AllOutputObjStrct,modelData] = DataInputOutputSig(fileList);
    if ~isempty(modelData)
        IODiffAttr=table(modelData);
        return;
    end
else
    [AllInputObjName,AllInputObjComponent, AllOutputObjName,AllOutputObjComponent, AllInputObjStrct, AllOutputObjStrct,modelData] = DataInputOutputSig(fileList);
    if ~isempty(modelData)
        IODiffAttr=table(modelData);
        return;
    end
end
%If Inputs and outputs not present in sldd then send error code(when project contains single sldd)
if isequal(AllInputObjName,"") && isequal(AllOutputObjName,"")
   errorCode = 676767;
   IODiffAttr = (table(errorCode));
   return; 
end
AllInputObjName = AllInputObjName';
AllInputObjComponent = AllInputObjComponent';
AllOutputObjName=AllOutputObjName';
AllOutputObjComponent=AllOutputObjComponent';

%Implementation for List 1
%Same IO but Diff Attribute Values
cntr2 = 1;
StructInput=struct('warning','Inconsistent I/Os','Name',"",'component',"",'category','Input','Description',"",...
                    'Basetype',"",'Offset',"",'slope',"",'Min',0,'Max',0,...
                    'Unit',"",'Dimensions',"",...
                    'DimensionsMode',"",'Complexity',"",...
                    'SampleTime',"",'InitialValue',"",...
                    'Coderinfo','','SwCalibrationAccess',"",'DisplayFormat',"",'Value',"Null",'hidden','<consistent>');
StructOutput=struct('warning','Inconsistent I/Os','Name',"",'component',"",'category','Input','Description',"",...
                    'Basetype',"",'Offset',"",'slope',"",'Min',0,'Max',0,...
                    'Unit',"",'Dimensions',"",...
                    'DimensionsMode',"",'Complexity',"",...
                    'SampleTime',"",'InitialValue',"",...
                    'Coderinfo','','SwCalibrationAccess',"",'DisplayFormat',"",'Value',"Null",'hidden','<consistent>');

clearvars pos
flagset = 0;
[LogclData, pos] = ismember(AllInputObjName,AllOutputObjName);
for ObjectCounter = 1:length(AllInputObjName)
    if (LogclData(ObjectCounter) > 0)
		flagset = 1;
        for fileds_Chk = 1: length(fields_present)
            if ~isequal((AllInputObjStrct(ObjectCounter).SignalDet.(fields_present{fileds_Chk})),(AllOutputObjStrct(pos(ObjectCounter)).SignalDet.(fields_present{fileds_Chk})))%Checking the inconsistency of attribute
                if strcmp(fields_present(fileds_Chk),'Min') || strcmp(fields_present(fileds_Chk),'Max')
                    if isempty(AllInputObjStrct(ObjectCounter).SignalDet.(fields_present{fileds_Chk}))
                        AllInputObjStrct(ObjectCounter).SignalDet.(fields_present{fileds_Chk})=1.111111111111111e+104;
                    end
                    if isempty(AllOutputObjStrct(pos(ObjectCounter)).SignalDet.(fields_present{fileds_Chk}))
                        AllOutputObjStrct(pos(ObjectCounter)).SignalDet.(fields_present{fileds_Chk})=1.111111111111111e+104;
                    end

                    [BasetypeInput,OffsetIn, slopeIn] = SlddtoUI_AbstractDataType(string(AllInputObjStrct(ObjectCounter).SignalDet.DataType));         %Get BastType,slope,Offset of input
                    [BasetypeOutput,OffsetOut, slopeOut] = SlddtoUI_AbstractDataType(string(AllOutputObjStrct(pos(ObjectCounter)).SignalDet.DataType));%Get BastType,slope,Offset of output

                    StructInput(cntr2)=struct('warning','Inconsistent I/Os','Name',AllInputObjName(ObjectCounter),'component',AllInputObjComponent(ObjectCounter),'category','Input','Description',AllInputObjStrct(ObjectCounter).SignalDet.Description,...
                    'Basetype',BasetypeInput,'Offset',OffsetIn,'slope',slopeIn,'Min',AllInputObjStrct(ObjectCounter).SignalDet.Min,'Max',AllInputObjStrct(ObjectCounter).SignalDet.Max,...
                    'Unit',AllInputObjStrct(ObjectCounter).SignalDet.Unit,'Dimensions',AllInputObjStrct(ObjectCounter).SignalDet.Dimensions,...
                    'DimensionsMode',AllInputObjStrct(ObjectCounter).SignalDet.DimensionsMode,'Complexity',AllInputObjStrct(ObjectCounter).SignalDet.Complexity,...
                    'SampleTime',AllInputObjStrct(ObjectCounter).SignalDet.SampleTime,'InitialValue',AllInputObjStrct(ObjectCounter).SignalDet.InitialValue,...
                    'Coderinfo',AllInputObjStrct(ObjectCounter).SignalDet.StorageClass,'SwCalibrationAccess',AllInputObjStrct(ObjectCounter).SignalDet.SwCalibrationAccess,'DisplayFormat',AllInputObjStrct(ObjectCounter).SignalDet.DisplayFormat,'Value',"Null",'hidden','<consistent>');

                    StructOutput(cntr2)=struct('warning','Inconsistent I/Os','Name',AllOutputObjName(pos(ObjectCounter)),'component',AllOutputObjComponent(pos(ObjectCounter)),'category','Output','Description',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Description,...
                    'Basetype',BasetypeOutput,'Offset',OffsetOut,'slope',slopeOut,'Min',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Min,'Max',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Max,...
                    'Unit',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Unit,'Dimensions',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Dimensions,...
                    'DimensionsMode',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.DimensionsMode,'Complexity',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Complexity,...
                    'SampleTime',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.SampleTime,'InitialValue',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.InitialValue,...
                    'Coderinfo',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.StorageClass,'SwCalibrationAccess',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.SwCalibrationAccess,'DisplayFormat',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.DisplayFormat,'Value',"Null",'hidden','<consistent>');
                end
                if strcmp(fields_present(fileds_Chk),'DataType')
                    [BasetypeInput,OffsetIn, slopeIn] = SlddtoUI_AbstractDataType(string(AllInputObjStrct(ObjectCounter).SignalDet.(fields_present{fileds_Chk})));         %Get BastType,slope,Offset of input
                    [BasetypeOutput,OffsetOut, slopeOut] = SlddtoUI_AbstractDataType(string(AllOutputObjStrct(pos(ObjectCounter)).SignalDet.(fields_present{fileds_Chk})));%Get BastType,slope,Offset of output
                    if ~isequal(BasetypeInput,BasetypeOutput)||~isequal(OffsetIn,OffsetOut)||~isequal(slopeIn,slopeOut) %Checking BastType,slope,Offset of input and output are inconsistent or not

                        StructInput(cntr2)=struct('warning','Inconsistent I/Os','Name',AllInputObjName(ObjectCounter),'component',AllInputObjComponent(ObjectCounter),'category','Input','Description',AllInputObjStrct(ObjectCounter).SignalDet.Description,...
                        'Basetype',BasetypeInput,'Offset',OffsetIn,'slope',slopeIn,'Min',AllInputObjStrct(ObjectCounter).SignalDet.Min,'Max',AllInputObjStrct(ObjectCounter).SignalDet.Max,...
                        'Unit',AllInputObjStrct(ObjectCounter).SignalDet.Unit,'Dimensions',AllInputObjStrct(ObjectCounter).SignalDet.Dimensions,...
                        'DimensionsMode',AllInputObjStrct(ObjectCounter).SignalDet.DimensionsMode,'Complexity',AllInputObjStrct(ObjectCounter).SignalDet.Complexity,...
                        'SampleTime',AllInputObjStrct(ObjectCounter).SignalDet.SampleTime,'InitialValue',AllInputObjStrct(ObjectCounter).SignalDet.InitialValue,...
                        'Coderinfo',AllInputObjStrct(ObjectCounter).SignalDet.StorageClass,'SwCalibrationAccess',AllInputObjStrct(ObjectCounter).SignalDet.SwCalibrationAccess,'DisplayFormat',AllInputObjStrct(ObjectCounter).SignalDet.DisplayFormat,'Value',"Null",'hidden','<consistent>');

                        StructOutput(cntr2)=struct('warning','Inconsistent I/Os','Name',AllOutputObjName(pos(ObjectCounter)),'component',AllOutputObjComponent(pos(ObjectCounter)),'category','Output','Description',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Description,...
                        'Basetype',BasetypeOutput,'Offset',OffsetOut,'slope',slopeOut,'Min',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Min,'Max',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Max,...
                        'Unit',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Unit,'Dimensions',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Dimensions,...
                        'DimensionsMode',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.DimensionsMode,'Complexity',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Complexity,...
                        'SampleTime',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.SampleTime,'InitialValue',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.InitialValue,...
                        'Coderinfo',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.StorageClass,'SwCalibrationAccess',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.SwCalibrationAccess,'DisplayFormat',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.DisplayFormat,'Value',"Null",'hidden','<consistent>');
                        %cntr2 = cntr2+1;
                    end
                end  
                if strcmp(fields_present(fileds_Chk),'Description') || strcmp(fields_present(fileds_Chk),'Unit') || strcmp(fields_present(fileds_Chk),'InitialValue') || strcmp(fields_present(fileds_Chk),'Dimensions')
                    DataType = AllInputObjStrct(ObjectCounter).SignalDet.DataType;
                    [BasetypeI, OffsetI, slopeI] = SlddtoUI_AbstractDataType(string(DataType));

                    StructInput(cntr2)=struct('warning','Inconsistent I/Os','Name',AllInputObjName(ObjectCounter),'component',AllInputObjComponent(ObjectCounter),'category','Input','Description',AllInputObjStrct(ObjectCounter).SignalDet.Description,...
                        'Basetype',BasetypeI,'Offset',OffsetI,'slope',slopeI,'Min',AllInputObjStrct(ObjectCounter).SignalDet.Min,'Max',AllInputObjStrct(ObjectCounter).SignalDet.Max,...
                        'Unit',AllInputObjStrct(ObjectCounter).SignalDet.Unit,'Dimensions',AllInputObjStrct(ObjectCounter).SignalDet.Dimensions,...
                        'DimensionsMode',AllInputObjStrct(ObjectCounter).SignalDet.DimensionsMode,'Complexity',AllInputObjStrct(ObjectCounter).SignalDet.Complexity,...
                        'SampleTime',AllInputObjStrct(ObjectCounter).SignalDet.SampleTime,'InitialValue',AllInputObjStrct(ObjectCounter).SignalDet.InitialValue,...
                        'Coderinfo',AllInputObjStrct(ObjectCounter).SignalDet.StorageClass,'SwCalibrationAccess',AllInputObjStrct(ObjectCounter).SignalDet.SwCalibrationAccess,'DisplayFormat',AllInputObjStrct(ObjectCounter).SignalDet.DisplayFormat,'Value',"Null",'hidden','<consistent>');

                    DataType = AllOutputObjStrct(pos(ObjectCounter)).SignalDet.DataType;
                    [BasetypeO, OffsetO, slopeO] = SlddtoUI_AbstractDataType(string(DataType));


                     StructOutput(cntr2)=struct('warning','Inconsistent I/Os','Name',AllOutputObjName(pos(ObjectCounter)),'component',AllOutputObjComponent(pos(ObjectCounter)),'category','Output','Description',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Description,...
                        'Basetype',BasetypeO,'Offset',OffsetO,'slope',slopeO,'Min',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Min,'Max',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Max,...
                        'Unit',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Unit,'Dimensions',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Dimensions,...
                        'DimensionsMode',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.DimensionsMode,'Complexity',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Complexity,...
                        'SampleTime',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.SampleTime,'InitialValue',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.InitialValue,...
                        'Coderinfo',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.StorageClass,'SwCalibrationAccess',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.SwCalibrationAccess,'DisplayFormat',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.DisplayFormat,'Value',"Null",'hidden','<consistent>');
                end
                
                if strcmp(fields_present(fileds_Chk),'DimensionsMode') || strcmp(fields_present(fileds_Chk),'Complexity') || strcmp(fields_present(fileds_Chk),'SampleTime') || strcmp(fields_present(fileds_Chk),'StorageClass') || strcmp(fields_present(fileds_Chk),'SwCalibrationAccess') || strcmp(fields_present(fileds_Chk),'DisplayFormat') %This if condition is needs to separate to fix "IO compatibility identifies hidden attribute diff but doesn't display diff" issue
                    DataType = AllInputObjStrct(ObjectCounter).SignalDet.DataType;
                    [BasetypeI, OffsetI, slopeI] = SlddtoUI_AbstractDataType(string(DataType));

                    StructInput(cntr2)=struct('warning','Inconsistent I/Os','Name',AllInputObjName(ObjectCounter),'component',AllInputObjComponent(ObjectCounter),'category','Input','Description',AllInputObjStrct(ObjectCounter).SignalDet.Description,...
                        'Basetype',BasetypeI,'Offset',OffsetI,'slope',slopeI,'Min',AllInputObjStrct(ObjectCounter).SignalDet.Min,'Max',AllInputObjStrct(ObjectCounter).SignalDet.Max,...
                        'Unit',AllInputObjStrct(ObjectCounter).SignalDet.Unit,'Dimensions',AllInputObjStrct(ObjectCounter).SignalDet.Dimensions,...
                        'DimensionsMode',AllInputObjStrct(ObjectCounter).SignalDet.DimensionsMode,'Complexity',AllInputObjStrct(ObjectCounter).SignalDet.Complexity,...
                        'SampleTime',AllInputObjStrct(ObjectCounter).SignalDet.SampleTime,'InitialValue',AllInputObjStrct(ObjectCounter).SignalDet.InitialValue,...
                        'Coderinfo',AllInputObjStrct(ObjectCounter).SignalDet.StorageClass,'SwCalibrationAccess',AllInputObjStrct(ObjectCounter).SignalDet.SwCalibrationAccess,'DisplayFormat',AllInputObjStrct(ObjectCounter).SignalDet.DisplayFormat,'Value',"Null",'hidden','<inconsistent>');

                    DataType = AllOutputObjStrct(pos(ObjectCounter)).SignalDet.DataType;
                    [BasetypeO, OffsetO, slopeO] = SlddtoUI_AbstractDataType(string(DataType));


                     StructOutput(cntr2)=struct('warning','Inconsistent I/Os','Name',AllOutputObjName(pos(ObjectCounter)),'component',AllOutputObjComponent(pos(ObjectCounter)),'category','Output','Description',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Description,...
                        'Basetype',BasetypeO,'Offset',OffsetO,'slope',slopeO,'Min',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Min,'Max',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Max,...
                        'Unit',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Unit,'Dimensions',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Dimensions,...
                        'DimensionsMode',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.DimensionsMode,'Complexity',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.Complexity,...
                        'SampleTime',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.SampleTime,'InitialValue',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.InitialValue,...
                        'Coderinfo',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.StorageClass,'SwCalibrationAccess',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.SwCalibrationAccess,'DisplayFormat',AllOutputObjStrct(pos(ObjectCounter)).SignalDet.DisplayFormat,'Value',"Null",'hidden','<inconsistent>'); 
                end               
            end
        end
		if flagset == 1
			cntr2 = cntr2+1;
		end
    end
	flagset = 0;
end
InconsistentOut1={};
InconsistOp=struct('warning','Inconsistent I/Os','Name',"",'component',"",'category','Input','Description',"",...
                    'Basetype',"",'Offset',"",'slope',"",'Min',0,'Max',0,...
                    'Unit',"",'Dimensions',"",...
                    'DimensionsMode',"",'Complexity',"",...
                    'SampleTime',"",'InitialValue',"",...
                    'Coderinfo','','SwCalibrationAccess',"",'DisplayFormat',"",'Value',"Null",'hidden','<consistent>');

InconsistOutput=struct2table(InconsistOp,'AsArray',true);
%Remove empty rows from structure
StructOutput( all( cell2mat( arrayfun( @(x) structfun( @isempty, x ), StructOutput, 'UniformOutput', false ) ), 1 ) ) = [];
StructInput( all( cell2mat( arrayfun( @(x) structfun( @isempty, x ), StructInput, 'UniformOutput', false ) ), 1 ) ) = [];
% Convert structures to tables
if ~isempty(StructInput)|| ~isequal(StructInput.Name,"")
   InconsistentIn=struct2table(StructInput,'AsArray',true);
end
if ~isempty(StructOutput)|| ~isequal(StructOutput.Name,"")
  InconsistentOut=struct2table(StructOutput,'AsArray',true);
  StoreName=InconsistentOut.Name;     %Line number 180 to 201 is implemented to remove duplicate outputs
  StoreName(cellfun('isempty',StoreName)) = [];
  StoreName=unique(StoreName);
  cntrIncr=1;
  for index=1: length(StoreName)
      [StoreName1,Position]=ismember(StoreName(index),InconsistentOut.Name);
      if StoreName1
         InconsistentOut1{cntrIncr}=InconsistentOut(Position,:);
         cntrIncr=cntrIncr+1;
      end
  end
  if ~isempty(InconsistentOut1)
        if length(InconsistentOut1) > 1
           InconsistOutput=[InconsistentOut1{1};InconsistentOut1{2}]; % First and second table combine vertically
           for index1=3:length(InconsistentOut1)
              InconsistOutput=[InconsistOutput;InconsistentOut1{index1}]; % Append rest of table below First and second
           end  
        else
            InconsistentData=cell2table(InconsistentOut1); % If 'InconsistentOut1' variable contains single table
            InconsistOutput=InconsistentData.InconsistentOut1;
        end
  end 
end
%Combine both structure
CombineStruct=vertcat(InconsistentIn,InconsistOutput);
CheckStatus=CombineStruct(:,2).Name;
 if CheckStatus==""
     errorCode = [103];
     IODiffAttr1 = (table(errorCode));
 else
     IODiffAttr1=CombineStruct;
 end  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Same Output DataObject
cntr5=1;
clearvars OutDobjFoundPos
StructOutputIODiffAttr3=struct('warning','Duplicate Outputs','Name',"",'component',"",'category','Output','Description',"",...
        'Basetype',"",'Offset',"",'slope',"",'Min',0,'Max',0,...
        'Unit',"",'Dimensions',"",...
        'DimensionsMode',"",'Complexity',"",...
        'SampleTime',"",'InitialValue',"",...
        'Coderinfo',"",'SwCalibrationAccess',"",'DisplayFormat',"",'Value',"Null",'hidden','<na>'); 

[uniqOpName,position] = unique(AllOutputObjName,'stable');
if ~(length(uniqOpName)==length(AllOutputObjName))
	index4 = 1:length(AllOutputObjName);
    index4(position) = [];
	IdenOutObj = AllOutputObjName(index4,1);
	sameoutputsvariables = unique(IdenOutObj);
	sameoutindex =0 ;
	%for loop for getting identical outputs in sequence 
	for sameoutputlength = 1:length(sameoutputsvariables)
		Index = find(strcmp(AllOutputObjName,sameoutputsvariables(sameoutputlength)));
		sameoutindex = [sameoutindex ;Index];   %updating the indexes of same outputs
	end
	OutDobjFoundPos = sameoutindex(2:end);
    for index1_L2 = 1:length(OutDobjFoundPos)
        DataType = AllOutputObjStrct(OutDobjFoundPos(cntr5)).SignalDet.DataType;
        [Basetype, Offset, slope] = SlddtoUI_AbstractDataType(string(DataType));
        
        StructOutputIODiffAttr3(cntr5)=struct('warning','Duplicate Outputs','Name',AllOutputObjName(OutDobjFoundPos(cntr5),:),'component',AllOutputObjComponent(OutDobjFoundPos(cntr5)),'category','Output','Description',AllOutputObjStrct(OutDobjFoundPos(cntr5)).SignalDet.Description,...
        'Basetype',Basetype,'Offset',Offset,'slope',slope,'Min',AllOutputObjStrct(OutDobjFoundPos(cntr5)).SignalDet.Min,'Max',AllOutputObjStrct(OutDobjFoundPos(cntr5)).SignalDet.Max,...
        'Unit',AllOutputObjStrct(OutDobjFoundPos(cntr5)).SignalDet.Unit,'Dimensions',AllOutputObjStrct(OutDobjFoundPos(cntr5)).SignalDet.Dimensions,...
        'DimensionsMode',AllOutputObjStrct(OutDobjFoundPos(cntr5)).SignalDet.DimensionsMode,'Complexity',AllOutputObjStrct(OutDobjFoundPos(cntr5)).SignalDet.Complexity,...
        'SampleTime',AllOutputObjStrct(OutDobjFoundPos(cntr5)).SignalDet.SampleTime,'InitialValue',AllOutputObjStrct(OutDobjFoundPos(cntr5)).SignalDet.InitialValue,...
        'Coderinfo',AllOutputObjStrct(OutDobjFoundPos(cntr5)).SignalDet.StorageClass,'SwCalibrationAccess',AllOutputObjStrct(OutDobjFoundPos(cntr5)).SignalDet.SwCalibrationAccess,'DisplayFormat',AllOutputObjStrct(OutDobjFoundPos(cntr5)).SignalDet.DisplayFormat,'Value',"Null",'hidden','<inconsistent>'); 
		cntr5=cntr5+1;
    end
    IODiffAttr3=struct2table(StructOutputIODiffAttr3,'AsArray',true);
else
    errorCode = [105];
    IODiffAttr3 = (table(errorCode));
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% List of output data objects do not have input
PosnOutDobj = 0;
cntr3=1;
StructOutputIODiffAttr4=struct('warning','Unconnected Outputs','Name',"",'component',"",'category','Output','Description',"",...
        'Basetype',"",'Offset',"",'slope',"",'Min',0,'Max',0,...
        'Unit',"",'Dimensions',"",...
        'DimensionsMode',"",'Complexity',"",...
        'SampleTime',"",'InitialValue',"",...
        'Coderinfo',"",'SwCalibrationAccess',"",'DisplayFormat',"",'Value',"Null",'hidden','<na>'); 

[OutputDobj, PosnOutDobj] = setdiff(AllOutputObjName,AllInputObjName,'stable');
if isequal(OutputDobj,"") || isempty(OutputDobj)
    errorCode = [106];
    IODiffAttr4 = (table(errorCode));
else
    for ObjectCounter2 = 1:length(PosnOutDobj)        
        DataType = AllOutputObjStrct(PosnOutDobj(ObjectCounter2)).SignalDet.DataType;
        [Basetype, Offset, slope] = SlddtoUI_AbstractDataType(string(DataType));
      
        StructOutputIODiffAttr4(cntr3)=struct('warning','Unconnected Outputs','Name',AllOutputObjName(PosnOutDobj(ObjectCounter2)),'component',AllOutputObjComponent(PosnOutDobj(ObjectCounter2)),'category','Output','Description',AllOutputObjStrct(PosnOutDobj(ObjectCounter2)).SignalDet.Description,...
        'Basetype',Basetype,'Offset',Offset,'slope',slope,'Min',AllOutputObjStrct(PosnOutDobj(ObjectCounter2)).SignalDet.Min,'Max',AllOutputObjStrct(PosnOutDobj(ObjectCounter2)).SignalDet.Max,...
        'Unit',AllOutputObjStrct(PosnOutDobj(ObjectCounter2)).SignalDet.Unit,'Dimensions',AllOutputObjStrct(PosnOutDobj(ObjectCounter2)).SignalDet.Dimensions,...
        'DimensionsMode',AllOutputObjStrct(PosnOutDobj(ObjectCounter2)).SignalDet.DimensionsMode,'Complexity',AllOutputObjStrct(PosnOutDobj(ObjectCounter2)).SignalDet.Complexity,...
        'SampleTime',AllOutputObjStrct(PosnOutDobj(ObjectCounter2)).SignalDet.SampleTime,'InitialValue',AllOutputObjStrct(PosnOutDobj(ObjectCounter2)).SignalDet.InitialValue,...
        'Coderinfo',AllOutputObjStrct(PosnOutDobj(ObjectCounter2)).SignalDet.StorageClass,'SwCalibrationAccess',AllOutputObjStrct(PosnOutDobj(ObjectCounter2)).SignalDet.SwCalibrationAccess,'DisplayFormat',AllOutputObjStrct(PosnOutDobj(ObjectCounter2)).SignalDet.DisplayFormat,'Value',"Null",'hidden','<na>');        
        cntr3=cntr3+1;
    end
    IODiffAttr4=struct2table(StructOutputIODiffAttr4,'AsArray',true);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% List of input data objects do not have output
cntr4=1;
StructInputIODiffAttr2=struct('warning','Unconnected Inputs','Name',"",'component',"",'category','Input','Description',"",...
                    'Basetype',"",'Offset',"",'slope',"",'Min',0,'Max',0,...
                    'Unit',"",'Dimensions',"",...
                    'DimensionsMode',"",'Complexity',"",...
                    'SampleTime',"",'InitialValue',"",...
                    'Coderinfo','','SwCalibrationAccess',"",'DisplayFormat',"",'Value',"Null",'hidden','<na>');

[InputDobj, ~] = setdiff(AllInputObjName,AllOutputObjName,'stable');
SameInputIndex=0;
%for loop for getting identical inputs in sequence 
for SameInputLength = 1:length(InputDobj)
    IndexInp = find(strcmp(AllInputObjName,InputDobj(SameInputLength)));
    SameInputIndex = [SameInputIndex ;IndexInp];   %updating the indexes of same inputs
end
FindLocation=SameInputIndex(2:end);
if isequal(InputDobj,"") || isempty(InputDobj)%If unconnected input list is empty send error code
    errorCode = [104];
    IODiffAttr2 = (table(errorCode));
else
    for ObjectCounter3 = 1:length(FindLocation)        
        DataType = AllInputObjStrct(FindLocation(ObjectCounter3)).SignalDet.DataType;
        [Basetype, Offset, slope] = SlddtoUI_AbstractDataType(string(DataType));

        StructInputIODiffAttr2(cntr4)=struct('warning','Unconnected Inputs','Name',AllInputObjName(FindLocation(ObjectCounter3)),'component',AllInputObjComponent(FindLocation(ObjectCounter3)),'category','Input','Description',AllInputObjStrct(FindLocation(ObjectCounter3)).SignalDet.Description,...
        'Basetype',Basetype,'Offset',Offset,'slope',slope,'Min',AllInputObjStrct(FindLocation(ObjectCounter3)).SignalDet.Min,'Max',AllInputObjStrct(FindLocation(ObjectCounter3)).SignalDet.Max,...
        'Unit',AllInputObjStrct(FindLocation(ObjectCounter3)).SignalDet.Unit,'Dimensions',AllInputObjStrct(FindLocation(ObjectCounter3)).SignalDet.Dimensions,...
        'DimensionsMode',AllInputObjStrct(FindLocation(ObjectCounter3)).SignalDet.DimensionsMode,'Complexity',AllInputObjStrct(FindLocation(ObjectCounter3)).SignalDet.Complexity,...
        'SampleTime',AllInputObjStrct(FindLocation(ObjectCounter3)).SignalDet.SampleTime,'InitialValue',AllInputObjStrct(FindLocation(ObjectCounter3)).SignalDet.InitialValue,...
        'Coderinfo',AllInputObjStrct(FindLocation(ObjectCounter3)).SignalDet.StorageClass,'SwCalibrationAccess',AllInputObjStrct(FindLocation(ObjectCounter3)).SignalDet.SwCalibrationAccess,'DisplayFormat',AllInputObjStrct(FindLocation(ObjectCounter3)).SignalDet.DisplayFormat,'Value',"Null",'hidden','<na>');
        cntr4=cntr4+1;        
    end
    IODiffAttr2=struct2table(StructInputIODiffAttr2,'AsArray',true);
end
IODiffAttr{1,:} = IODiffAttr1;
IODiffAttr{2,:} = IODiffAttr2;
IODiffAttr{3,:} = IODiffAttr3;
IODiffAttr{4,:} = IODiffAttr4;

clearvars CombineStruct AllInputObjName AllInputObjComponent AllOutputObjName AllOutputObjComponent AllInputObjStrct AllOutputObjStrct ProjectPath OutputNotFindinput InpNotFndOutpt OutDiffAttr3 InconstIOList cntr2 fileList index1_L2


function [AllInputObjName,AllInputObjComponent, AllOutputObjName,AllOutputObjComponent, AllInputObjStrct, AllOutputObjStrct,modelData] = DataInputOutputSig(fileList)
InputDobjCntr = 1;
OutputDobjCntr = 1;
AllInputObjName="";
AllInputObjComponent="";
AllOutputObjName="";
AllOutputObjComponent="";
modelData={};
AllInputObjStrct = struct('DataObjName','', 'CompName','','SignalDet','');
AllOutputObjStrct = struct('DataObjName','','CompName','','SignalDet','');
%Logic written for loading indicator
if contains(fileList,'top.sldd')
    LoadingIndicator = waitbar(0,'Please wait while data is being fetched from Top.sldd','Name','I/O Compatibility checking...','WindowStyle', 'modal');
    frames = java.awt.Frame.getFrames();
    frames(end).setAlwaysOnTop(1);
    javaFrame = get(LoadingIndicator,'JavaFrame');
    ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
    javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));
    flag1 = 1;
else
     LoadingIndicator = waitbar(0,'Please wait while I/O Compatibility lists is being loaded 0%','Name','I/O Compatibility checking...','WindowStyle', 'modal');
     frames = java.awt.Frame.getFrames();
     frames(end).setAlwaysOnTop(1);
     javaFrame = get(LoadingIndicator,'JavaFrame');
     ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
     javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));
     flag1 = 0;
end

%Loop to get all attributes of each I/O data object
for DataCntrSlddFile=1:length(fileList)
    try
        dicObj = Simulink.data.dictionary.open((char(fileList(DataCntrSlddFile))));
    catch Exception
        modelData={Exception.message};  %If any error throw while opening sldd   
        close(LoadingIndicator)
        return;
    end
    dicSec = getSection(dicObj,'Design Data');
    DataObj =  find(dicSec,'-value','-class','AUTOSAR.Signal');
    if isempty(DataObj)
       DataObj =  find(dicSec,'-value','-class','Simulink.Signal');
    end
    % Logic written for loading indicator
    if contains(fileList,'top.sldd')
        waitbar(length(fileList),LoadingIndicator,sprintf('Please wait while data is being fetched from Top.sldd %1.0f%%',(length(fileList)*100)))  
        flag1 = 1;
        close(LoadingIndicator)
        LoadingIndicator = waitbar(0,'Please wait while I/O Compatibility lists is being loaded 0% ','Name','I/O Compatibility checking...','WindowStyle', 'modal');
        frames = java.awt.Frame.getFrames();
        frames(end).setAlwaysOnTop(1);
        javaFrame = get(LoadingIndicator,'JavaFrame');
        ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
        javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));
  
    else
        waitbar(DataCntrSlddFile/length(fileList),LoadingIndicator,sprintf('Please wait while I/O Compatibility lists is being loaded %1.0f%%',(DataCntrSlddFile/length(fileList)*100)))  
    end
    
    %Loop to get all attributes of each I/O data object
    for Index = 1:length(DataObj)
        ValueStructTemp = DataObj(Index).getValue;
        if ~isnumeric(ValueStructTemp)&& ~ischar(ValueStructTemp)&&~isstring(ValueStructTemp)
            GetFields=fields(ValueStructTemp);               %Get fields of data object
            log_array = ismember(GetFields,'objectType'); %Check data object having object type
            varv = nnz(log_array);
            if varv==1
                CategoryTemp = ValueStructTemp.objectType;
                if ((strcmp(CategoryTemp,'Input')))
                    AllInputObjName(1,InputDobjCntr) = string(DataObj(Index).Name);  
                    AllInputObjComponent(1,InputDobjCntr) = string(strtok(DataObj(Index).DataSource,'.'));  
                    AllInputObjStrct(InputDobjCntr) = struct('DataObjName',string(DataObj(Index).Name), 'CompName',string(DataObj(Index).DataSource),'SignalDet',ValueStructTemp);
                    InputDobjCntr = InputDobjCntr + 1;    
                end
                if (strcmp(CategoryTemp,'Output'))
                    AllOutputObjName(1,OutputDobjCntr) = string(DataObj(Index).Name);  
                    AllOutputObjComponent(1,OutputDobjCntr) = string(strtok(DataObj(Index).DataSource,'.')); 
                    AllOutputObjStrct(OutputDobjCntr) = struct('DataObjName',string(DataObj(Index).Name),'CompName',string(DataObj(Index).DataSource),'SignalDet',ValueStructTemp);
                    OutputDobjCntr = OutputDobjCntr + 1;
                end
            end
        end
        if flag1 
            waitbar(Index/length(DataObj),LoadingIndicator,sprintf('Please wait while I/O Compatibility lists is being loaded %1.0f%%',(Index/(length(DataObj)))*100))
        end
    end
    close(dicObj);
end

 close(LoadingIndicator);


