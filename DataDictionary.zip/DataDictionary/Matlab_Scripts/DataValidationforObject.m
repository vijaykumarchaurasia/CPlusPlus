%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :AddDataObject
% MAIN PURPOSE     :Function is used for validation of add or update of data object
% INPUT(S)         :1.added_data_Obj(In structure format)
%                   2.length_objNames='2';
% OUTPUT           :1.Wrong validation will send "errorCode=111","category","Data object name","Error message"
% DATE OF CREATION : 5 Oct 2019
% REVESION NO      : -
% STATUS           :All possible validation are covered in function
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function DataMsg = DataValidationforObject(added_data_Obj,length_objNames)
categoryfields = {'Input','Output','Local','Nvm','Define','Map','Curve','Calibration','Axis'};
Attribute={'Description','Basetype','Offset','slope','Min','Max','Unit','Dimensions','DimensionsMode','Complexity','SampleTime','InitialValue','SwCalibrationAccess'};
DefaultVal={'','single','','','','','','[1, 1]','auto','real','-1','','ReadOnly'};
Pattern1={'*','/','~','!','@','#','$','%','^','&','(',')','=','<','>','?','\','|','{','}','[',']'}; %For Min,Max,slope,Offset
Pattern2={'*','/','~','!','@','#','$','%','^','&','(',')','=','<','>','?','\','|','{','}'}; %Dimensions,InitialValue,Value

Data1(1,1) = string(num2str(000));
Data1(1,2) = string(added_data_Obj(length_objNames).category);
Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
Data1(1,4) = 'Message code';
DataMsg = cell2table(cellstr(Data1),'VariableNames',{'MessageCode' 'category' 'Name' 'attribute'});
            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Space not allowed in number carrying field
if nnz(contains(categoryfields(1:9),(added_data_Obj(length_objNames).category)))
    if nnz(isspace(added_data_Obj(length_objNames).Min)) || nnz(isspace(added_data_Obj(length_objNames).Max))|| nnz(isspace(added_data_Obj(length_objNames).InitialValue))||nnz(isspace(added_data_Obj(length_objNames).Value))||nnz(isspace(added_data_Obj(length_objNames).Offset))||nnz(isspace(added_data_Obj(length_objNames).slope))
        Data1(1,1) = string(num2str(111));
        Data1(1,2) = string(added_data_Obj(length_objNames).category);
        Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
        Data1(1,4) = 'Space is not allowed in this field';
        DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'} );
        return;    
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Validation for field which accept only numbers
if nnz(contains(categoryfields(1:9),(added_data_Obj(length_objNames).category)))
    if nnz(contains(added_data_Obj(length_objNames).Offset,Pattern1(1:22)))
        Data1(1,1) = string(num2str(111));
        Data1(1,2) = string(added_data_Obj(length_objNames).category);
        Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
        Data1(1,4) = 'Enter numeric value for Offset';
        DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'} );
        return;    
    end
end

if nnz(contains(categoryfields(1:9),(added_data_Obj(length_objNames).category)))
    if nnz(contains(added_data_Obj(length_objNames).slope,Pattern1(1:22)))
        Data1(1,1) = string(num2str(111));
        Data1(1,2) = string(added_data_Obj(length_objNames).category);
        Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
        Data1(1,4) = 'Enter numeric value for slope';
        DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'} );
        return;    
    end
end

if nnz(contains(categoryfields(1:9),(added_data_Obj(length_objNames).category)))
    if nnz(contains(added_data_Obj(length_objNames).Min,Pattern1(1:22)))
        Data1(1,1) = string(num2str(111));
        Data1(1,2) = string(added_data_Obj(length_objNames).category);
        Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
        Data1(1,4) = 'Enter numeric value for Min';
        DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'} );
        return;    
    end
end

if nnz(contains(categoryfields(1:9),(added_data_Obj(length_objNames).category)))
    if nnz(contains(added_data_Obj(length_objNames).Max,Pattern1(1:22)))
        Data1(1,1) = string(num2str(111));
        Data1(1,2) = string(added_data_Obj(length_objNames).category);
        Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
        Data1(1,4) = 'Enter numeric value for Max';
        DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'} );
        return;    
    end
end


if nnz(contains(categoryfields(1:9),(added_data_Obj(length_objNames).category)))
    if nnz(contains(added_data_Obj(length_objNames).InitialValue,Pattern2(1:20)))
        Data1(1,1) = string(num2str(111));
        Data1(1,2) = string(added_data_Obj(length_objNames).category);
        Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
        Data1(1,4) = 'InitialValue field should be a number';
        DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'} );
        return;    
    end
end

if nnz(contains(categoryfields(1:9),(added_data_Obj(length_objNames).category)))
    if nnz(contains(added_data_Obj(length_objNames).Value,Pattern2(1:20)))
        Data1(1,1) = string(num2str(111));
        Data1(1,2) = string(added_data_Obj(length_objNames).category);
        Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
        Data1(1,4) = 'Value field should be a number';
        DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'} );
        return;    
    end
end

if nnz(contains(categoryfields(1:9),(added_data_Obj(length_objNames).category)))
    if nnz(contains(added_data_Obj(length_objNames).Dimensions,Pattern2(1:20)))
        Data1(1,1) = string(num2str(111));
        Data1(1,2) = string(added_data_Obj(length_objNames).category);
        Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
        Data1(1,4) = 'Enter numeric value for Dimensions';
        DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'} );
        return;    
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
% Validation for BaseType, if it is empty  
if nnz(contains(categoryfields(1:9),(added_data_Obj(length_objNames).category)))
        if isempty(added_data_Obj(length_objNames).Basetype)
            Data1(1,1) = string(num2str(111));
            Data1(1,2) = string(added_data_Obj(length_objNames).category);
            Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
            Data1(1,4) = 'Enter BaseType';
            DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'} );
            return;    
        end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% If Basetype contains other than sepcified Basetype
SpecifiedDataType={'int8','uint8','int16','uint16','int32','uint32','single','boolean'};
if nnz(contains(categoryfields(1:9),(added_data_Obj(length_objNames).category)))
        if ~strcmp(SpecifiedDataType(1:8),added_data_Obj(length_objNames).Basetype)
            Data1(1,1) = string(num2str(111));
            Data1(1,2) = string(added_data_Obj(length_objNames).category);
            Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
            Data1(1,4) = 'Enter valid Basetype';
            DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'} );
            return;    
        end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Validation for attributes which accept only Numbers (For InitialValue)
if nnz(contains(categoryfields(1:4),(added_data_Obj(length_objNames).category)))
    if ~isempty(added_data_Obj(length_objNames).InitialValue)
        if isempty(str2num(added_data_Obj(length_objNames).InitialValue))
            Data1(1,1) = string(num2str(111));
            Data1(1,2) = string(added_data_Obj(length_objNames).category);
            Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
            Data1(1,4) = 'Enter numeric value for InitialValue field and multiple rows are not allowed';
            DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'} );
            return;
        end
    end
else
    % Validation for attributes which accept only Numbers (For Value)
    if((strcmp(added_data_Obj(length_objNames).Min,"")&& strcmp(added_data_Obj(length_objNames).Max,""))|| strcmp(added_data_Obj(length_objNames).Value,""))
       if (isempty(str2num(added_data_Obj(length_objNames).Min))|| isempty(str2num(added_data_Obj(length_objNames).Max)))
            Data1(1,1) = string(num2str(111));
            Data1(1,2) = string(added_data_Obj(length_objNames).category);
            Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
            Data1(1,4) = 'Enter numeric value for Min, Max and Value field(s)';
            DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'} );
            return;                    
       end
    else
        if (isempty(str2num(added_data_Obj(length_objNames).Min))|| isempty(str2num(added_data_Obj(length_objNames).Max)) ||isempty(str2num(added_data_Obj(length_objNames).Value)))
            Data1(1,1) = string(num2str(111));
            Data1(1,2) = string(added_data_Obj(length_objNames).category);
            Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
            Data1(1,4) = 'Enter numeric value for Min, Max and Value field(s)';
            DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'} );
            return;
        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Value field does not accept array for 'Define' category
if (strcmp(added_data_Obj(length_objNames).category,'Define'))
    StoreValue=str2num(added_data_Obj(length_objNames).Value);
    if ~isempty(StoreValue)
        if (length(StoreValue))>1
            Data1(1,1) = string(num2str(111));
            Data1(1,2) = string(added_data_Obj(length_objNames).category);
            Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
            Data1(1,4) = 'Multiple rows and columns are not allowed for this category';
            DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'} );
            return; 
        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Validation for all categories execpt 'Map': If Value or InitialValue received more than one array(e.g.'[][]'), then show error message
categories = {'Input','Output','Local','Nvm','Define','Curve','Calibration','Axis'};
if contains(added_data_Obj(length_objNames).category,categories(1:8))
    StoreValue1=count(added_data_Obj(length_objNames).InitialValue,'[');
    StoreInitialValue1=count(added_data_Obj(length_objNames).Value,'[');
    
    if StoreValue1>1 || StoreInitialValue1>1
        Data1(1,1) = string(num2str(111));
        Data1(1,2) = string(added_data_Obj(length_objNames).category);
        Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
        Data1(1,4) = 'Enter numeric value for this field and multiple rows are not allowed';
        DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'} );
        return; 
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Handled for blank values of attributes
for i=1:length(Attribute)
    if (strcmp((added_data_Obj(length_objNames).(Attribute{i})),""))
        added_data_Obj(length_objNames).(Attribute{i}) = DefaultVal{i};
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Validation for Min/Max Value should be in specified range
singleMin=-3.40282e+38;
singleMax=3.40282e+38;
if nnz(contains(categoryfields(1:9),(added_data_Obj(length_objNames).category)))
   if strcmp(added_data_Obj(length_objNames).Basetype,'single')
       if (~isempty(str2num(added_data_Obj(length_objNames).Min))) && (~isempty(str2num(added_data_Obj(length_objNames).Max)))
           if (str2num(added_data_Obj(length_objNames).Min)<singleMin || str2num(added_data_Obj(length_objNames).Max)>singleMax)
                Data1(1,1) = string(num2str(111));
                Data1(1,2) = string(added_data_Obj(length_objNames).category);
                Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
                Data1(1,4) = 'Min/Max Value must be within the range of selected basetype';
                DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'} );
                return;
           end
       end
   end
end

booleanMin=0;
booleanMax=1;
if nnz(contains(categoryfields(1:9),(added_data_Obj(length_objNames).category)))
   if strcmp(added_data_Obj(length_objNames).Basetype,'boolean')
       if (~isempty(str2num(added_data_Obj(length_objNames).Min))) && (~isempty(str2num(added_data_Obj(length_objNames).Max)))
           if str2num(added_data_Obj(length_objNames).Min)<booleanMin || str2num(added_data_Obj(length_objNames).Max)>booleanMax
                Data1(1,1) = string(num2str(111));
                Data1(1,2) = string(added_data_Obj(length_objNames).category);
                Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
                Data1(1,4) = 'Min/Max Value must be within the range of selected basetype';
                DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'} );
                return;
           end
       end
   end
end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Error Handling for Updating or adding Unit for DataObject with two '@' symbols
SplCharOccr=count(added_data_Obj(length_objNames).Unit,'@');
if SplCharOccr >=1
    Data1(1,1) = string(num2str(111));
    Data1(1,2) = string(added_data_Obj(length_objNames).category);
    Data1(1,3) = string(added_data_Obj(length_objNames).Name); 
    Data1(1,4) = 'Unit'; 
    DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'} );
    return;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%Check for Proper input for Complexity and Dimensionsmode
if nnz(contains(categoryfields(1:4),(added_data_Obj(length_objNames).category)))
    ChkComplexityAuto = strcmp(added_data_Obj(length_objNames).Complexity,'auto');
    ChkComplexityReal = strcmp(added_data_Obj(length_objNames).Complexity,'real');
    DimensionsMode = strcmp(added_data_Obj(length_objNames).DimensionsMode,'auto');
    if ~(ChkComplexityAuto == 0 || ChkComplexityReal == 0)
        Data1(1,1) = string(num2str(111));
        Data1(1,2) = string(added_data_Obj(length_objNames).category);
        Data1(1,3) = string(added_data_Obj(length_objNames).Name); 
        Data1(1,4) = 'Complexity';
        DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'});
        return;
    end
    if DimensionsMode == 0
        Data1(1,1) = string(num2str(111));
        Data1(1,2) = string(added_data_Obj(length_objNames).category);
        Data1(1,3) = string(added_data_Obj(length_objNames).Name);
        Data1(1,4) = 'DimensionsMode';
        DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'});
        return;
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%If Offset or Slope is empty for all Basetype except "single" and "boolean" then throw error
if nnz(contains(categoryfields(1:9),(added_data_Obj(length_objNames).category)))
    if (~strcmp(added_data_Obj(length_objNames).Basetype,"single")|| ~strcmp(added_data_Obj(length_objNames).Basetype,"boolean"))
        if (strcmp(added_data_Obj(length_objNames).Offset,"") || strcmp(added_data_Obj(length_objNames).slope,""))
             Data1(1,1) = string(num2str(111));
             Data1(1,2) = string(added_data_Obj(length_objNames).category);
             Data1(1,3) = string(added_data_Obj(length_objNames).Name);
             Data1(1,4) = 'Please enter Offset and Slope';
             DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'});
             return;
        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Check for Value provided by user. If Null then provide 0
if  nnz(contains(categoryfields(5:end),(added_data_Obj(length_objNames).category)))
    if (strcmp((added_data_Obj(length_objNames).Value),""))   
        added_data_Obj(length_objNames).Value = '0';
        add_simulinlk_signal_obj.Dimensions = '[1,1]';
    end
    ValLength = length(str2num(added_data_Obj(length_objNames).Value));
    if ValLength == 1
        % handled for "Value" should be in between Min and Max
        if ~((str2num(added_data_Obj(length_objNames).Value) >= str2num(added_data_Obj(length_objNames).Min)) && ...
            (str2num(added_data_Obj(length_objNames).Value) <= str2num(added_data_Obj(length_objNames).Max)))
            Data1(1,1) = string(num2str(111));
            Data1(1,2) = string(added_data_Obj(length_objNames).category);
            Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
            Data1(1,4) = 'Value is not in range of Min and Max value';
            DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'});
            return;

        end
    else
        for ValCheck= 1:ValLength
            valinp = str2num(added_data_Obj(length_objNames).Value);
            if ~((valinp(ValCheck) >= str2num(added_data_Obj(length_objNames).Min)) && ...
                (valinp(ValCheck) <= str2num(added_data_Obj(length_objNames).Max)))
                Data1(1,1) = string(num2str(111));
                Data1(1,2) = string(added_data_Obj(length_objNames).category);
                Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
                Data1(1,4) = 'Value is not in range of Min and Max value';
                DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'});
                return;

            end				
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Check for InitalValue provided by user. If Null then provide 0
if  nnz(contains(categoryfields(1:4),(added_data_Obj(length_objNames).category)))
    ValLength = length(str2num(added_data_Obj(length_objNames).InitialValue));
    if ValLength == 0
        if ~isempty(added_data_Obj(length_objNames).Min) 
            if  (isempty(str2num(added_data_Obj(length_objNames).Min)) || isempty(str2num(added_data_Obj(length_objNames).Max)))         
                Data1(1,1) = string(num2str(111));
                Data1(1,2) = string(added_data_Obj(length_objNames).category);
                Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
                Data1(1,4) = 'Enter numeric value for Min and Max field';
                DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'});
                return;
            end		
        elseif ~isempty(added_data_Obj(length_objNames).Max) 
            if  (isempty(str2num(added_data_Obj(length_objNames).Min)) || isempty(str2num(added_data_Obj(length_objNames).Max)))         
                Data1(1,1) = string(num2str(111));
                Data1(1,2) = string(added_data_Obj(length_objNames).category);
                Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
                Data1(1,4) = 'Enter numeric value for Min and Max field';
                DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'});
                return;
            end	                
        end
    elseif ValLength == 1
        % handled for "InitialValue" should be in between Min and Max
        if  (~isempty(str2num(added_data_Obj(length_objNames).Min)) && ~isempty(str2num(added_data_Obj(length_objNames).InitialValue)))
            if ~((str2num(added_data_Obj(length_objNames).InitialValue) >= str2num(added_data_Obj(length_objNames).Min)))         
                Data1(1,1) = string(num2str(111));
                Data1(1,2) = string(added_data_Obj(length_objNames).category);
                Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
                Data1(1,4) = 'InitialValue should be greater than Min Value';
                DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'});
                return;
            end
        else
            Data1(1,1) = string(num2str(111));
            Data1(1,2) = string(added_data_Obj(length_objNames).category);
            Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
            Data1(1,4) = 'Min Value should be a number and should not be blank';
            DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'});
            return;
        end
        if (~isempty(str2num(added_data_Obj(length_objNames).Max)) && ~isempty(str2num(added_data_Obj(length_objNames).InitialValue)))
            if ~((str2num(added_data_Obj(length_objNames).InitialValue) <= str2num(added_data_Obj(length_objNames).Max)))    
                Data1(1,1) = string(num2str(111));
                Data1(1,2) = string(added_data_Obj(length_objNames).category);
                Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
                Data1(1,4) = 'InitialValue should be less than Max Value';
                DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'});
                return;
            end
        else
            Data1(1,1) = string(num2str(111));
            Data1(1,2) = string(added_data_Obj(length_objNames).category);
            Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
            Data1(1,4) = 'Max Value should be a number and should not be blank';
            DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'});
            return;
        end
    else
        for ValCheck= 1:ValLength
            valinp = str2num(added_data_Obj(length_objNames).InitialValue);
            if  (~isempty(str2num(added_data_Obj(length_objNames).Min)) && ~isempty(valinp(ValCheck)))
                if ~(((valinp(ValCheck)) >= str2num(added_data_Obj(length_objNames).Min)))         
                    Data1(1,1) = string(num2str(111));
                    Data1(1,2) = string(added_data_Obj(length_objNames).category);
                    Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
                    Data1(1,4) = 'InitialValue should be greater than Min Value';
                    DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'});
                    return;
                end
            else
                Data1(1,1) = string(num2str(111));
                Data1(1,2) = string(added_data_Obj(length_objNames).category);
                Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
                Data1(1,4) = 'Enter numeric value for Min';
                DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'});
            end
            if (~isempty(str2num(added_data_Obj(length_objNames).Max)) && ~isempty(valinp(ValCheck)))
                if ~(valinp(ValCheck) <= str2num(added_data_Obj(length_objNames).Max))    
                    Data1(1,1) = string(num2str(111));
                    Data1(1,2) = string(added_data_Obj(length_objNames).category);
                    Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
                    Data1(1,4) = 'InitialValue should be less than Max Value';
                    DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'});
                    return;
                end
            else
                Data1(1,1) = string(num2str(111));
                Data1(1,2) = string(added_data_Obj(length_objNames).category);
                Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
                Data1(1,4) = 'Enter numeric value for Max';
                DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'});
            end
        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if  nnz(contains(categoryfields(1:9),(added_data_Obj(length_objNames).category)))
    if  (~isempty(str2num(added_data_Obj(length_objNames).Min)) && ~isempty(str2num(added_data_Obj(length_objNames).Max)))
        if ((str2num(added_data_Obj(length_objNames).Min) > str2num(added_data_Obj(length_objNames).Max)))   
            Data1(1,1) = string(num2str(111));
            Data1(1,2) = string(added_data_Obj(length_objNames).category);
            Data1(1,3) = string(added_data_Obj(length_objNames).Name);    
            Data1(1,4) = 'Min should be less than Max Value';
            DataMsg = cell2table(cellstr(Data1),'VariableNames',{'errorCode' 'category' 'Name' 'attribute'});
            return;
        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%            
clearvars inp_data_v Dimesnion_for_val add_simulinlk_signal_obj dataObject_Name  ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%