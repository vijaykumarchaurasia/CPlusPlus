%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :ModelData
% MAIN PURPOSE     :Function is used to gather data objects of all categories available in model   
% INPUT(S)         :1.sldd_path=('C:\Users\shubhangim1\Music\E39_example\AirManagement\aserc\Model\aserc.sldd')
% OUTPUT           :1.Fetching data objects of all categories available in model 
% DATE OF CREATION :30th July 2019
% REVESION NO      :-
% STATUS           :Function has been written to call in "RenameInModel" and "DataToBeResolved" script 
% FUNCTION CALL    :[~,~,UniqueDataObjCalibDef,~,~,LocalObjStateflow,~,~,AllPathInput,AllPathOutput,AllPathLocal,AllPathDefineCalib,ConstantPath_First_Order_Transfer_Fcn,Fix1DLookupPath,Float1DLookupPath,Fix2DLookupPath,Float2DLookupPath,LookupPath,LookupTableName,PreLookupPathMapCurve,PreLookupTableName,PreLookupPath,NvmPath]= FindPathOfDataObject(ModelName);
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [Map,Curve,Axis,Inputs,Outputs,CalibrationAndDefine,Nvm,Local,Unique_Constant_First_Order_Transfer_Fcn,SeperatingPathOfSldd,AddObjInSlddRemaining,DelObjFrmSlddRemaining,AddObjInSldd,DelObjFrmSldd,SendObjToDelete,SendObjToAdd,SendDeleteObjInSldd,SendAddObjInSldd,modelData,errorCode,GetmodelPath]= ModelData(sldd_path,OldNameOfObj)
%User has to change string name if Masktype of block get changed in model
SParameter1='SParameter1';
SParameter2='SParameter2';
SParameter4='SParameter4';
DataStoreName='DataStoreName';
%Initialization of variables
StoreName1D={};
Store_Axis1D={};
Map_2DLookup={};
Store_Axis2D={};
Store_Axis1_2D={};
StorePreLookupCurve={};
StorePreLookupMap={};
StorePreLookupAxis={};
DelObjFrmSlddRemaining={};
AddObjInSlddRemaining={};
SendObjToDelete={};
SendObjToAdd={};
SendDeleteObjInSldd={};
SendAddObjInSldd={};
DelObjFrmSldd={};
AddObjInSldd={};
Map="";
Curve="";
Axis="";
Inputs="";
Outputs="";
CalibrationAndDefine="";
Nvm="";
Local="";
Unique_Constant_First_Order_Transfer_Fcn="";
modelData={};

%Separating sldd path and project path
[ModelName,SeperatingPathOfSldd,errorCode,GetmodelPath] =ModelFoundInProjectFolder(sldd_path);
%if model not available in project folder
if strcmp(errorCode,'114')
    errorCode = "114";                        
    return;
end

%Precaution has been taken if model loaded previously, because same name model cannot open from other path 
try
      load_system(GetmodelPath) 
catch Message
      exception=Message;
      modelData={exception.message};                 %if model loaded previously then Exception Message displsy corrective action needs to take
      return;
end
%Function call to get path of all data objects    
[~,~,UniqueDataObjCalibDef,~,~,LocalObjStateflow,~,~,AllPathInput,AllPathOutput,AllPathLocal,AllPathDefineCalib,ConstantPath_First_Order_Transfer_Fcn,Fix1DLookupPath,Float1DLookupPath,Fix2DLookupPath,Float2DLookupPath,LookupPath,LookupTableName,PreLookupPathMapCurve,PreLookupTableName,PreLookupPath,NvmPath,~,~]= FindPathOfDataObject(ModelName);

cntr1 = 1;
%Fetching Lookup table data object based on 'BlockType' property
%For blocktype:Lookup_n-D
if ~isempty(LookupPath)
    for index4 = 1:length(LookupTableName)
        switch char(cellstr(LookupTableName{index4}))
            case '1'
                StoreName1D{cntr1} = get_param(LookupPath{index4},'Table');
                Store_Axis1D{cntr1}= get_param(LookupPath{index4},'BreakpointsForDimension1');
                cntr1 = cntr1+1;
            case '2'
                Map_2DLookup{cntr1} = get_param(LookupPath{index4},'Table');%Map objects
                Store_Axis2D{cntr1}= get_param(LookupPath{index4},'BreakpointsForDimension1');%X_Axis of Map
                Store_Axis1_2D{cntr1}= get_param(LookupPath{index4},'BreakpointsForDimension2');%Y_Axis of Map
                cntr1 = cntr1+1; 
        end
    end
end

%Implementation of PreLookUp table of Autosar block(Blocktype:Interpolation_n-D)
if ~isempty(PreLookupPathMapCurve)
    for index5=1:length(PreLookupTableName)
        switch char(cellstr(PreLookupTableName{index5}))
                case '1'
                        StoreTableSpecification = get_param(PreLookupPathMapCurve{index5},'TableSpecification'); %For 1D (Curve using prelookup)
                        if strcmp(StoreTableSpecification,'Explicit values')
                            StorePreLookupCurve{cntr1} = get_param(PreLookupPathMapCurve{index5},'Table'); %For 1D (Curve using prelookup)
                        else
                            StorePreLookupCurve{cntr1} = get_param(PreLookupPathMapCurve{index5},'LookupTableObject'); %For 1D (Curve using prelookup)
                        end
                        cntr1 = cntr1+1;

                case '2'  
                        StoreTableSpecification = get_param(PreLookupPathMapCurve{index5},'TableSpecification')
                        if strcmp(StoreTableSpecification,'Explicit values')
                            StorePreLookupMap{cntr1} = get_param(PreLookupPathMapCurve{index5},'Table'); %For 2D (Map using prelookup)
                        else
                            StorePreLookupMap{cntr1} = get_param(PreLookupPathMapCurve{index5},'LookupTableObject'); %For 2D (Map using prelookup)
                        end
                        cntr1 = cntr1+1;
        end
    end
end

%For blocktype: PreLookup
if ~isempty(PreLookupPath)
    for index6 = 1:length(PreLookupPath)
        StoreBreakpointsSpecification = get_param(PreLookupPath{index6},'BreakpointsSpecification');
        if strcmp(StoreBreakpointsSpecification,'Explicit values')
            StorePreLookupAxis{cntr1} = get_param(PreLookupPath{index6},'BreakpointsData');
        else
            StorePreLookupAxis{cntr1} = get_param(PreLookupPath{index6},'BreakpointObject');
        end
        cntr1 = cntr1+1;
    end
end

%Fetching data objects of model
%Fetching data objects of Map and Axis category

MapObj_Float2DLookup=get_param(Float2DLookupPath,SParameter1);              %Data object of Map
Y_AxisObj_Float2DLookup=get_param(Float2DLookupPath,SParameter2);           %Data object of Y-Axis
X_AxisObj_Float2DLookup=get_param(Float2DLookupPath,SParameter4);           %Data object of X-Axis

%Fetching data objects of Map and Axis category
MapObj_Fix2DLookup=get_param(Fix2DLookupPath,SParameter1);                  %Data object of Map
Y_AxisObj_Fix2DLookup=get_param(Fix2DLookupPath,SParameter2);               %Data object of Y-Axis
X_AxisObj_Fix2DLookup=get_param(Fix2DLookupPath,SParameter4);               %Data object of X-Axis

%Fetching data objects of Curve and Axis category
CurveObj_Float1DLookup=get_param(Float1DLookupPath,SParameter1);            %Data object of Curve
X_AxisObj_Float1DLookup=get_param(Float1DLookupPath,SParameter2);           %Data object of X-Axis

%Fetching data objects of Curve and Axis category
CurvePath=Fix1DLookupPath;
CurveObj_Fix1DLookup=get_param(CurvePath,SParameter1);                      %Data object of Curve
X_AxisObj_Fix1DLookup=get_param(CurvePath,SParameter2);                     %Data object of X-Axis

%All Map data object combined
% Map1=vertcat(StorePreLookupMap',Map_2DLookup',MapObj_Fix2DLookup,MapObj_Float2DLookup);
Map1=[StorePreLookupMap';Map_2DLookup';MapObj_Fix2DLookup;MapObj_Float2DLookup];
MapObj = Map1(~cellfun('isempty', Map1));
Map=unique(MapObj);

%All Curve data object combined
Curve1=[StorePreLookupCurve';StoreName1D';CurveObj_Float1DLookup;CurveObj_Fix1DLookup];
CurveObj = Curve1(~cellfun('isempty', Curve1));
Curve=unique(CurveObj);

%All Axis data object combined
% Axis1=vertcat(StorePreLookupAxis',Store_Axis1_2D',Store_Axis2D',Store_Axis1D',Y_AxisObj_Fix2DLookup,X_AxisObj_Fix2DLookup,X_AxisObj_Fix1DLookup,X_AxisObj_Float1DLookup,Y_AxisObj_Float2DLookup,X_AxisObj_Float2DLookup); %Data object of Axis 
Axis1=[StorePreLookupAxis';Store_Axis1_2D';Store_Axis2D';Store_Axis1D';Y_AxisObj_Fix2DLookup;X_AxisObj_Fix2DLookup;X_AxisObj_Fix1DLookup;X_AxisObj_Float1DLookup;Y_AxisObj_Float2DLookup;X_AxisObj_Float2DLookup]; %Data object of Axis 
Axis = Axis1(~cellfun('isempty', Axis1));

%Fetching data object of Output category
OutputPath=AllPathOutput;
OutputObjModel=get_param(OutputPath,'Name');                    
Outputs=unique(OutputObjModel); 

%Fetching Input data objects from model
InputPath=AllPathInput;
InputObjModel=get_param(InputPath,'Name');                    
Inputs=unique(InputObjModel); 

%Fetching Calibration and Define data objects from model
cntr=1;
StoreConstant={};
ConstantPath=AllPathDefineCalib;
Constant=get_param(ConstantPath,'Value');
%Loop is used to skip array and constant value of constant block
for index=1:length(Constant)
    ConvertToStr=string(Constant(index));
    ConvertStr2Num=str2num(ConvertToStr);
    if isempty(ConvertStr2Num)
        StoreConstant(cntr)= Constant(index);
        cntr=cntr+1;
    end
end

if ~isempty(StoreConstant)
    CalibrationAndDefineNoStateflow=unique(StoreConstant);
else
    CalibrationAndDefineNoStateflow={};
end

%Fetching Calibration using First order transfer function
Constant_First_Order_Transfer_Fcn=get_param(ConstantPath_First_Order_Transfer_Fcn,'PoleZ');
Unique_Constant_First_Order_Transfer_Fcn=unique(Constant_First_Order_Transfer_Fcn);

CalibrationAndDefine1=[CalibrationAndDefineNoStateflow';UniqueDataObjCalibDef'];
CalibrationAndDefine=unique(CalibrationAndDefine1);        %Calibration and Define data objects

%Fetching Local data object from model
ResSignLine=AllPathLocal;
ResolvedSignalNames=get_param(ResSignLine,'Name');
Local_unique = unique(ResolvedSignalNames);
Local_unique = Local_unique(2:end);
AllInOut=union(Inputs,Outputs);
LocalObjModel = setdiff(Local_unique,AllInOut,'stable');   
ResolvedLineLocal = [LocalObjModel;LocalObjStateflow'];
ChkMember=ismember(ResolvedLineLocal,OldNameOfObj);
%Check old name is resolved signal
if nnz(ChkMember) %If yes then get all possible location(path) of that data object from model
    StoreSplit1=strsplit(GetmodelPath,'/');
    StoreSplit2=strsplit(char(StoreSplit1(end)),'.');
    AllBlkPath = find_system(char(StoreSplit2(1)));
    DataObjectLocal=get_param(AllBlkPath,'Name');  
    GoToBlock=find_system(char(StoreSplit2(1)),'BlockType','Goto');
    DataObjectGoTo=get_param(GoToBlock,'GotoTag'); 
    FromBlock=find_system(char(StoreSplit2(1)),'BlockType','From');
    DataObjectFrom=get_param(FromBlock,'GotoTag'); 
    Local = [ResolvedLineLocal;DataObjectLocal;DataObjectGoTo;DataObjectFrom];%Data object of Local
else
    Local=ResolvedLineLocal; %otherwise send only path of resolved signal
end
%Fetching Nvm data object from model
Nvm=get_param(NvmPath,DataStoreName);                                 %Data object of Nvm