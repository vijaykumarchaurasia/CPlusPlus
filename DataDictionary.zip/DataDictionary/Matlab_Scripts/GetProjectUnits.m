%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :GetProjectUnits
% MAIN PURPOSE     :Function is used to send symbol list from UnitsDb excel file
% INPUT(S)         :-
% OUTPUT           :1.Display Symbol list with Units name OR
%                   2.Symbols not present in excel then sending error code:1000
% DATE OF CREATION :5th November 2020
% REVESION NO      :-
% STATUS           :Function has been written to get all symbols present in excel file
%FUNCTION CALL     :DatabaseFiles = GetProjectUnitsDbFiles()
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function UnitSymbols = GetProjectUnits(~,~)
Symbols={};
Names={};
try
     DatabaseFiles = GetProjectUnitsDbFiles();%Function call
catch Exception
     Error=Exception;
     if contains(Error.message, "Unrecognized function or variable 'GetProjectUnitsDbFiles'.")
        errorCode = "1000"; 
        UnitSymbols = (table(errorCode));
        return;
     end
end
if ~isempty(DatabaseFiles)
    for index1 = 1:length(DatabaseFiles)
        %[~,TextData,ExcelData] = xlsread(DatabaseFiles(index1));%Read excel
        DataInTable = readtable(DatabaseFiles(index1));%Read excel
        CellData = table2cell(DataInTable);
        ExcelData = [DataInTable.Properties.VariableNames;CellData];
        %Loop is used to replace 'NAN' cell with '#N/A'
        for index_ExcelData = 1:numel(ExcelData)
              if isnan(ExcelData{index_ExcelData})
                ExcelData{index_ExcelData} = '#N/A';
              end
        end
        SymbolIndex = find(strcmp('symbol',ExcelData(1,:)));%Get column index of excel
        NameIndex = find(strcmp('name',ExcelData(1,:)));%Get column index of excel 
        %SymbolIndex = find(strcmp('symbol',TextData(1,:)));%Get column index of excel
        %NameIndex = find(strcmp('name',TextData(1,:)));%Get column index of excel        
        if ~isempty(SymbolIndex) && ~isempty(NameIndex)
            Symbols = [Symbols; ExcelData((2:end),SymbolIndex)]; %get symbols from "symbols" column
            Names = [Names; ExcelData((2:end),NameIndex)]; %get symbols from "name" column
        end
    end
end

if (isempty(Symbols) || isempty(Names))
	errorCode = "1000"; 
	UnitSymbols = (table(errorCode));%If UnitSymbols variable is empty or throw any error then send error code
else
	UnitSymbols=struct('Name',Symbols,'Description',Names);%Send list of symbols to java
end
end