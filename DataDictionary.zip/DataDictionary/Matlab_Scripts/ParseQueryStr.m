%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :ParseQueryStr
% MAIN PURPOSE     :Function is used to parse string received from java.
% INPUT(S)         :1.json_inp_comp_name='[''{"queryName":"FetchSLDD_Data"},{"componentName":"C:/Users/shubhangim1/Music/E39_example/AirManagement/aserc/Model/aserc.sldd"}'']'
% OUTPUT           :1.queryName
%                   2.componentName
%                   3.Data received from java
% DATE OF CREATION :5th July 2019
% REVESION NO      :1.3
% STATUS           :Rev. 1.1: Tested to parse string received from java.
%                   Rev. 1.2: Tested to parse newly added string received
%                   from java for GetProgramName and GetConfigExcelFilePath
%                   Rev. 1.3: Tested to parse newly added string received
%                   from java for InOutCompatibility and Check_Components_Inputs for E95 
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [queryName, Arg1, Arg2] = ParseQueryStr(json_string_inp)
%Parsing JSON string
JsonArgLst = extractBetween(json_string_inp,'{','}');
JsonArgLst = strcat({'{'},JsonArgLst,{'}'});
JsonDecodeLst = cell(length(JsonArgLst),1);
for Index = 1:length(JsonArgLst)
    JsonDecodeLst{Index} = jsondecode(JsonArgLst{Index});
end
Arg1 = '';Arg2 = '';
switch(JsonDecodeLst{1}.queryName)
    case 'FetchSLDD_Data'
        queryName = 'FetchSLDD_Data';
        Arg1 = JsonDecodeLst{2}.componentName;
    case 'GetProjectUnits'
        queryName = 'GetProjectUnits';
    case 'GetConfigExcelFilePath'
        queryName = 'GetConfigExcelFilePath';
    case 'GetProgramName' 
        queryName = 'GetProgramName';
        Arg1 = JsonDecodeLst{2}.componentName;
    case 'ValidationOfSldd'
        queryName = 'ValidationOfSldd';
        Arg1 = JsonDecodeLst{2}.componentName;
    case 'UpdateParameterType'
        queryName = 'UpdateParameterType';
        Arg1 = JsonDecodeLst{2}.componentName;
    case 'ApplyCalibationValueFromCDFXfile'
        queryName = 'ApplyCalibationValueFromCDFXfile';
        Arg1 = JsonDecodeLst{2}.componentName;  
        Arg2 = JsonDecodeLst{3}.Name;
    case 'AddDataObject'
        queryName = 'AddDataObject';
        Arg1 = JsonDecodeLst{2}.componentName;
        Arg2 = cell2mat(JsonDecodeLst(3:end));   
    case 'InOutCompatibility'
        queryName = 'InOutCompatibility';
        Arg1 = JsonDecodeLst{2}.componentName;
        Arg2 = cell2mat(JsonDecodeLst(3:end));
    case 'InOutCompatibility_E95'
        queryName = 'InOutCompatibility_E95';
        Arg1 = JsonDecodeLst{2}.componentName;
        Arg2 = cell2mat(JsonDecodeLst(3:end));
    case 'TopSlddComponent'
        queryName = 'TopSlddComponent';
        Arg1 = JsonDecodeLst{2}.componentName;
    case 'SingleSlddOutput'
        queryName = 'SingleSlddOutput';
        Arg1 = JsonDecodeLst{2}.componentName;
    case 'FindInModel'
        queryName = 'FindInModel';
        Arg1 = JsonDecodeLst{2}.componentName;
        Arg2 = JsonDecodeLst{3}.Name;
    case 'DeleteDataObject'
        queryName = 'DeleteDataObject';
        Arg1 = JsonDecodeLst{2}.componentName;
        Arg2 = cell2mat(JsonDecodeLst(3:end)); 
    case 'DataToBeResolved'
        queryName = 'DataToBeResolved';
        Arg1 = JsonDecodeLst{2}.componentName;
    case 'ResolveInconsistencyImport'
        queryName = 'ResolveInconsistencyImport';
        Arg1 = JsonDecodeLst{2}.componentName;    
    case 'ResolveInconsistencyExport'
        queryName = 'ResolveInconsistencyExport';
        Arg1 = JsonDecodeLst{2}.componentName;
    case 'InconsistentInOutAttributes'
        queryName = 'InconsistentInOutAttributes';
        Arg1 = JsonDecodeLst{2}.componentName;
    case 'ExcelAddDeleteQuery'
        queryName = 'ExcelAddDeleteQuery';
        Arg1 = JsonDecodeLst{2}.componentName;
        Arg2 = cell2mat(JsonDecodeLst(3:end)); 
    case 'ResolveUseThisObject'
        queryName = 'ResolveUseThisObject';
        Arg1 = JsonDecodeLst{2}.componentName;
        Arg2 = cell2mat(JsonDecodeLst(3:end));
    case 'DeleteFromExcel'
        queryName = 'DeleteFromExcel';
        Arg1 = JsonDecodeLst{2}.componentName;   
    case 'DataToBeResolvedActionDobj'
        queryName = 'DataToBeResolvedActionDobj';
        Arg1 = JsonDecodeLst{2}.componentName;
        Arg2 = cell2mat(JsonDecodeLst(3:end)); 
    case 'Check_Components_Inputs'
        queryName = 'Check_Components_Inputs';
        Arg1 = JsonDecodeLst{2}.componentName;
        Arg2 = cell2mat(JsonDecodeLst(3:end));
    case 'Check_Components_Inputs_E95'
        queryName = 'Check_Components_Inputs_E95';
        Arg1 = JsonDecodeLst{2}.componentName;
        Arg2 = cell2mat(JsonDecodeLst(3:end));
    case 'SearchDataObject'
        queryName = 'SearchDataObject';
        Arg1 = JsonDecodeLst{2}.componentName;
        Arg2 = cell2mat(JsonDecodeLst(3:end));  
    case 'RenameInModel'
        queryName = 'RenameInModel';
        Arg1 = JsonDecodeLst{2}.componentName;
        Arg2 = cell2mat(JsonDecodeLst(3:end));    
	case 'UseThisObject'
        queryName = 'UseThisObject';
        Arg1 = JsonDecodeLst{2}.componentName;
        Arg2 = cell2mat(JsonDecodeLst(3:end));	
    case 'HierachicalView'
        queryName = 'HierachicalView';
        Arg1 = JsonDecodeLst{2}.componentName;
	case 'AllOutputSignal'
        queryName = 'AllOutputSignal';
        Arg1 = JsonDecodeLst{2}.componentName;
        Arg2 = JsonDecodeLst{3}.Name; 	
    otherwise
        queryName = '';
        disp('Unrecognized query');            
end
