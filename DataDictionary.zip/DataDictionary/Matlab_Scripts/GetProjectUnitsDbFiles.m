% GetProjectUnitsDbFiles.m
% this function is used by the sldd tool to gather the Units description files
% get an array of the allowed Units database files

function dbFiles = GetProjectUnitsDbFiles()

% find the current location of the utilities
% this could use toolbox functions but for now use the old startup
% script mechanism. Assumes startupNavistarMatlabUtilities is at root
path2file = which('startupNavistarMatlabUtilities');
installDir = fileparts(path2file);

% Project specific unit files
dbFilesPath = [installDir, '\MatlabScripts\Units'];

% get all xlsx filenames in specified dir
dbFileNames = dir([dbFilesPath '\*.xlsx']);
dbFileNames = string({dbFileNames.name}); %make string array

% make fully qualified filenames
dbFiles = fullfile(dbFilesPath, dbFileNames);

end