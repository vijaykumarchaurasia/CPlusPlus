%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :AllOutputSignal
% MAIN PURPOSE     :Function is used to display the list of all project�s outputs in the input tab at the time 
%                   of adding data objects of inputs. 
% INPUT(S)         :1.componentName=('C:\Users\shubhangim1\Music\Fresh_Project\E39_example')
%                   2.SelectedSlddName='aserc';
% OUTPUT           :1.Display outputs of all sldd present in project folder.Outputs of each 
%                     sldd is stored in separate array.
% DATE OF CREATION :13th Sep 2019
% REVESION NO      :1.2
% STATUS           :Rev. 1.1: Tested to get outputs from all sldd present
%                             in project folder except sldd name received as input.
%                   Rev. 1.2: dicObj and dicSec are replaced with myDictionaryObj and dDataSectObj for naming consistency. 
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [Outputs] = AllOutputSignal(componentName,SelectedSlddName)
%Add project folder on path
addpath(genpath(componentName))
DirPath = dir(fullfile(componentName,'**\*.sldd'));
fileList1 = strcat({DirPath.folder}, {'\'},{DirPath.name});
fileList = unique(fileList1);
if isempty(fileList)
    errorCode = [102];
    Outputs = (table(errorCode));
    return;
end
cntr2=1;
%Checking top sldd is present or not in project folder
if nnz(contains(fileList,'top.sldd')>0)
    OutDataObj=struct('component','','category','Output','Name','','Description','',...
            'Basetype','','Offset','','slope','','Min',0,'Max',0,...
            'Unit','','Dimensions','',...
            'DimensionsMode','','Complexity','',...
            'SampleTime','','InitialValue','','SamplingMode','auto',...
            'CoderInfo','Null','SwCalibrationAccess','','DisplayFormat','','Value',"Null",'maxDimension','','oldName','');
        
    ModifyFileList = {'top.sldd'};
    [~,RemainingSldd,~,AllOutputObjStrct] = DataOutputSig(ModifyFileList,SelectedSlddName); %Function call to get outputs
    if ~isempty(AllOutputObjStrct)
        cntr=1;
        for index2=1:length(AllOutputObjStrct)
            
            [Basetype, Offset, slope] = SlddtoUI_AbstractDataType(string(AllOutputObjStrct(index2).SignalDet.DataType));
            if isempty(AllOutputObjStrct(index2).SignalDet.Min)
               AllOutputObjStrct(index2).SignalDet.Min=1.111111111111111e+104;
            end
            if isempty(AllOutputObjStrct(index2).SignalDet.Max)
               AllOutputObjStrct(index2).SignalDet.Max=1.111111111111111e+104;
            end
            
            OutDataObj(cntr)=struct('component',strtok(AllOutputObjStrct(index2).CompName,'.'),'category','Output','Name',AllOutputObjStrct(index2).DataObjName,'Description',AllOutputObjStrct(index2).SignalDet.Description,...
            'Basetype',Basetype,'Offset',Offset,'slope',slope,'Min',AllOutputObjStrct(index2).SignalDet.Min,'Max',AllOutputObjStrct(index2).SignalDet.Max,...
            'Unit',AllOutputObjStrct(index2).SignalDet.Unit,'Dimensions',AllOutputObjStrct(index2).SignalDet.Dimensions,...
            'DimensionsMode',AllOutputObjStrct(index2).SignalDet.DimensionsMode,'Complexity',AllOutputObjStrct(index2).SignalDet.Complexity,...
            'SampleTime',AllOutputObjStrct(index2).SignalDet.SampleTime,'InitialValue',AllOutputObjStrct(index2).SignalDet.InitialValue,'SamplingMode','auto',...
            'CoderInfo','Null','SwCalibrationAccess',AllOutputObjStrct(index2).SignalDet.SwCalibrationAccess,'DisplayFormat',AllOutputObjStrct(index2).SignalDet.DisplayFormat,'Value',"Null",'maxDimension',length(AllOutputObjStrct(index2).SignalDet.InitialValue),'oldName',AllOutputObjStrct(index2).DataObjName);
            cntr=cntr+1;
        end
        DataObjTable=struct2table(OutDataObj,'AsArray',true);
        
        %Storing all data of output 
        component0=DataObjTable.component;
        category0=DataObjTable.category;
        Name0=DataObjTable.Name;
        Value0=DataObjTable.Value;
        Description0=DataObjTable.Description;
        Basetype0=DataObjTable.Basetype;
        Offset0=DataObjTable.Offset;
        slope0=DataObjTable.slope;
        Min0=DataObjTable.Min;
        Max0=DataObjTable.Max;
        Unit0=DataObjTable.Unit;
        Complexity0=DataObjTable.Complexity;
        Dimensions0=DataObjTable.Dimensions;
        DimensionsMode0=DataObjTable.DimensionsMode;
        SampleTime0=DataObjTable.SampleTime;
        SamplingMode0=DataObjTable.SamplingMode;
        InitialValue0=DataObjTable.InitialValue;
        Coderinfo0=DataObjTable.CoderInfo;
        SwCalibrationAccess0=DataObjTable.SwCalibrationAccess;
        DisplayFormat0=DataObjTable.DisplayFormat;
        oldName0=DataObjTable.oldName;
        maxDimension0=DataObjTable.maxDimension;
    end
    %Loop to get output data object wrt sldd to store in array
    for index2=1:length(RemainingSldd)
        [Logical]=ismember(component0,RemainingSldd(index2)); %Checking each sldd name in structure to fetch respective output data objects from structure
        if nnz(Logical)
           PosLogical=find(Logical);
           cntr3=1;
           for index3=1:length(PosLogical)
                component(cntr3)=cellstr(component0(PosLogical(index3))); % 1st column
                category(cntr3)=category0(PosLogical(index3));
                Name(cntr3)=cellstr(Name0(PosLogical(index3)));
                Value(cntr3)=cellstr(Value0(PosLogical(index3)));
                Description(cntr3)=Description0(PosLogical(index3));
                Basetype(cntr3)=Basetype0(PosLogical(index3));
                Offset(cntr3)=Offset0(PosLogical(index3));
                slope(cntr3)=slope0(PosLogical(index3));
                Min(cntr3)=Min0(PosLogical(index3));
                Max(cntr3)=Max0(PosLogical(index3));
                Unit(cntr3)=Unit0(PosLogical(index3));
                Complexity(cntr3)=Complexity0(PosLogical(index3));
                Dimensions(cntr3)=Dimensions0(PosLogical(index3));
                DimensionsMode(cntr3)=DimensionsMode0(PosLogical(index3));
                SampleTime(cntr3)=SampleTime0(PosLogical(index3));
                SamplingMode(cntr3)=SamplingMode0(PosLogical(index3));
                InitialValue(cntr3)=InitialValue0(PosLogical(index3));
                Coderinfo(cntr3)=Coderinfo0(PosLogical(index3));
                SwCalibrationAccess(cntr3)=SwCalibrationAccess0(PosLogical(index3));
                DisplayFormat(cntr3)=DisplayFormat0(PosLogical(index3));
                oldName(cntr3)=cellstr(oldName0(PosLogical(index3)));
                maxDimension(cntr3)=maxDimension0(PosLogical(index3));
                cntr3=cntr3+1;
           end
           for i=1:length(Basetype)
               StBasetype{i}=Basetype(i);
           end
           for i=1:length(Offset)
               StOffset{i}=Offset(i);
           end
           for i=1:length(slope)
               Stslope{i}=slope(i);
           end
           for i=1:length(Min)
               StMin{i}=Min(i);
           end
           for i=1:length(Max)
               StMax{i}=Max(i);
           end
           for i=1:length(Dimensions)
               StDimensions{i}=Dimensions(i);
           end
           for i=1:length(SampleTime)
               StSampleTime{i}=SampleTime(i);
           end
           for i=1:length(maxDimension)
               StmaxDimension{i}=maxDimension(i);
           end
           if isequal(length(PosLogical),1)
               StoreOutputs{cntr2}=table(component,category,Name,Description,StBasetype,StOffset,Stslope,StMin,StMax,Unit,StDimensions,DimensionsMode,Complexity,StSampleTime,InitialValue,SamplingMode,Coderinfo,SwCalibrationAccess,DisplayFormat,Value,StmaxDimension,oldName);
           else
               StoreOutputs{cntr2}=struct('component',component,'category',category,'Name',Name,'Description',Description,...
               'Basetype',StBasetype,'Offset',StOffset,'slope',Stslope,'Min',StMin,'Max',StMax,...
               'Unit',Unit,'Dimensions',StDimensions,...
               'DimensionsMode',DimensionsMode,'Complexity',Complexity,...
               'SampleTime',StSampleTime,'InitialValue',InitialValue,'SamplingMode',SamplingMode,...
               'CoderInfo','Null','SwCalibrationAccess',SwCalibrationAccess,'DisplayFormat',DisplayFormat,'Value',"Null",'maxDimension',StmaxDimension,'oldName',oldName);
           end
            cntr2=cntr2+1;
            clearvars StBasetype StOffset Stslope StmaxDimension Min Max Dimensions SampleTime Offset maxDimension oldName DisplayFormat SwCalibrationAccess Coderinfo StSampleTime InitialValue SamplingMode DimensionsMode StDimensions Complexity StMin StMax Unit slope component category Name Value Description Basetype Logical;
        end
    end      
    
    if isempty(StoreOutputs)
       errorCode = 4444;
       Outputs = table(errorCode);
    else
        Outputs=StoreOutputs;
    end
else
        cntr=1;
        for index_fileList=1:length(fileList)
            SplitPath=split(fileList(index_fileList),'\');
            SplitPath=SplitPath(end);
            SplitPath=split(SplitPath,'.sldd');
            SplitPath=SplitPath(1);
            StoreComponentName{cntr}=SplitPath;
            cntr=cntr+1;
        end
        ChkSelectedSlddName=ismember(cellstr(string(StoreComponentName)),string(SelectedSlddName));
        position=find(ChkSelectedSlddName);
        if nnz(ChkSelectedSlddName)>0
           ModifyFileList=setdiff(fileList,fileList(position));
        end
        [Outputs] = DataOutputSig(ModifyFileList,SelectedSlddName);    %Top sldd is not present in project folder
        if isempty(Outputs)
            errorCode = 4444;
            Outputs = table(errorCode);
        end
end

% function to create structure of output data object wrt sldd
function [Outputs,RemainingSldd,AllOutputObj,AllOutputObjStrct] = DataOutputSig(ModifyFileList,SelectedSlddName)
Slddcntr=1;
Outputs={};
AllOutputObj="";
StoreSlddName="";
OutDataObj=struct('component','','category','Output','Name','','Description','',...
            'Basetype','','Offset','','slope','','Min',0,'Max',0,...
            'Unit','','Dimensions','',...
            'DimensionsMode','','Complexity','',...
            'SampleTime','','InitialValue','','SamplingMode','auto',...
            'CoderInfo','Null','SwCalibrationAccess','','DisplayFormat','','Value',"Null",'maxDimension','','oldName','');

AllOutputObjStrct = struct('DataObjName',"",'CompName',"",'SignalDet',"");
if contains(ModifyFileList,'top.sldd')
    LoadingIndicator = waitbar(0,'Please wait while data is being fetched from Top.sldd','Name','Fetching output signals...','WindowStyle', 'modal');
    frames = java.awt.Frame.getFrames();
    frames(end).setAlwaysOnTop(1);
    javaFrame = get(LoadingIndicator,'JavaFrame');
    ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
    javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));
else
     LoadingIndicator = waitbar(0,' 0% Completed','Name','Fetching output signals...','WindowStyle', 'modal');
     frames = java.awt.Frame.getFrames();
     frames(end).setAlwaysOnTop(1);
     javaFrame = get(LoadingIndicator,'JavaFrame');
     ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
     javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));
end
    
%Loop to open each sldd at a time and fetch output data object
for DataCntrSlddFile=1:length(ModifyFileList)
    AllOutputObj="";
%     Simulink.data.dictionary.closeAll
    myDictionaryObj = Simulink.data.dictionary.open((char(ModifyFileList(DataCntrSlddFile))));
    dDataSectObj = getSection(myDictionaryObj,'Design Data');
    DataObj =  find(dDataSectObj,'-value','-class','AUTOSAR.Signal');
    if isempty(DataObj)
       DataObj =  find(dDataSectObj,'-value','-class','Simulink.Signal');
    end
    
    %Loop to get all output data object
    OutputDobjCntr = 1;
    for Index1 = 1:length(DataObj)
        ValueStructTemp = DataObj(Index1).getValue;
        if ~isnumeric(ValueStructTemp)&&~ischar(ValueStructTemp)&&~isstring(ValueStructTemp)
            GetFields=fields(ValueStructTemp);               %Get fields of data object
            log_array = ismember(GetFields,'objectType'); %Check data object having object type field
            varv = nnz(log_array);
            if varv==1
                CategoryTemp = ValueStructTemp.objectType;
                if (strcmp(CategoryTemp,'Output'))
                    AllOutputObj(1,OutputDobjCntr) = string(DataObj(Index1).Name);  
                    AllOutputObj(2,OutputDobjCntr) = string(strtok(DataObj(Index1).DataSource,'.')); 
                    AllOutputObjStrct(OutputDobjCntr) = struct('DataObjName',string(DataObj(Index1).Name),'CompName',string(DataObj(Index1).DataSource),'SignalDet',ValueStructTemp);
                    OutputDobjCntr = OutputDobjCntr + 1;
                end
            end
        end
    end
    
%Checking top sldd is present in project folder and get sldd name from data source
if contains(ModifyFileList,'top.sldd')
    FetchSlddNames = myDictionaryObj.DataSources;
    StoreSlddName=strtok(FetchSlddNames,'.');
    RemainingSldd=setdiff(StoreSlddName,SelectedSlddName); %Selected sldd excluded
else
    if ~(AllOutputObj == "") %If top sldd not present as well as skipping sldd which are not having output data object
        cntr=1;
        for index2=1:length(AllOutputObjStrct)
            
            [Basetype, Offset, slope] = SlddtoUI_AbstractDataType(string(AllOutputObjStrct(index2).SignalDet.DataType));
            if isempty(AllOutputObjStrct(index2).SignalDet.Min)
               AllOutputObjStrct(index2).SignalDet.Min=1.111111111111111e+104;
            end
            if isempty(AllOutputObjStrct(index2).SignalDet.Max)
               AllOutputObjStrct(index2).SignalDet.Max=1.111111111111111e+104;
            end
         
            OutDataObj(cntr)=struct('component',strtok(DataObj(index2).DataSource,'.'),'category','Output','Name',AllOutputObjStrct(index2).DataObjName,'Description',AllOutputObjStrct(index2).SignalDet.Description,...
            'Basetype',Basetype,'Offset',Offset,'slope',slope,'Min',AllOutputObjStrct(index2).SignalDet.Min,'Max',AllOutputObjStrct(index2).SignalDet.Max,...
            'Unit',AllOutputObjStrct(index2).SignalDet.Unit,'Dimensions',AllOutputObjStrct(index2).SignalDet.Dimensions,...
            'DimensionsMode',AllOutputObjStrct(index2).SignalDet.DimensionsMode,'Complexity',AllOutputObjStrct(index2).SignalDet.Complexity,...
            'SampleTime',AllOutputObjStrct(index2).SignalDet.SampleTime,'InitialValue',AllOutputObjStrct(index2).SignalDet.InitialValue,'SamplingMode','auto',...
            'CoderInfo','Null','SwCalibrationAccess',AllOutputObjStrct(index2).SignalDet.SwCalibrationAccess,'DisplayFormat',AllOutputObjStrct(index2).SignalDet.DisplayFormat,'Value',"Null",'maxDimension',length(AllOutputObjStrct(index2).SignalDet.InitialValue),'oldName',AllOutputObjStrct(index2).DataObjName);
            cntr=cntr+1;
        end
        DataObjTable=struct2table(OutDataObj,'AsArray',true);
        %Storing all data of output 
        component=DataObjTable.component;
        category=DataObjTable.category;
        Name=DataObjTable.Name;
        Value=DataObjTable.Value;
        Description=DataObjTable.Description;
        Basetype=DataObjTable.Basetype;
        Offset=DataObjTable.Offset;
        slope=DataObjTable.slope;
        Min=DataObjTable.Min;
        Max=DataObjTable.Max;
        Unit=DataObjTable.Unit;
        Complexity=DataObjTable.Complexity;
        Dimensions=DataObjTable.Dimensions;
        DimensionsMode=DataObjTable.DimensionsMode;
        SampleTime=DataObjTable.SampleTime;
        SamplingMode=DataObjTable.SamplingMode;
        InitialValue=DataObjTable.InitialValue;
        Coderinfo=DataObjTable.CoderInfo;
        SwCalibrationAccess=DataObjTable.SwCalibrationAccess;
        DisplayFormat=DataObjTable.DisplayFormat;
        oldName=DataObjTable.oldName;
        maxDimension=DataObjTable.maxDimension;
        Outputs{Slddcntr,1} =table(component,category,Name,Value,Description,Basetype,Offset,slope,Min,Max,Unit,Complexity,Dimensions,DimensionsMode,SampleTime,SamplingMode,InitialValue,Coderinfo,SwCalibrationAccess,DisplayFormat,oldName,maxDimension);
        Slddcntr=Slddcntr+1;
        clearvars AllOutputObj OutDataObj AllOutputObjStrct;
    end
end
     waitbar(DataCntrSlddFile/length(ModifyFileList),LoadingIndicator,sprintf(' %1.0f%% Completed',(DataCntrSlddFile/length(ModifyFileList)*100)));
end
 close(LoadingIndicator)