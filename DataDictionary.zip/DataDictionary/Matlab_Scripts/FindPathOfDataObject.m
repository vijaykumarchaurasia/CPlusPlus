%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :FindPathOfDataObject
% MAIN PURPOSE     :Function is used to find path of all data objects present in model
% INPUT(S)         :1.ModelName:'aserc'
% OUTPUT           :1.Path of data object
% DATE OF CREATION :30th April 2020
% REVESION NO      :-
% STATUS           :Function has been written to called in "ModelData","FindInModel"script 
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [FoundStateflowChart,StateflowChart,UniqueDataObjCalibDef,InputObjStateflow,OutputObjStateflow,LocalObjStateflow,ChartTransitions,ChartState,AllPathInput,AllPathOutput,AllPathLocal,AllPathDefineCalib,ConstantPath_First_Order_Transfer_Fcn,Fix1DLookupPath,Float1DLookupPath,Fix2DLookupPath,Float2DLookupPath,LookupPath,LookupTableName,PreLookupPathMapCurve,PreLookupTableName,PreLookupPath,NvmPath,DataStoreWritePath,DataStoreReadPath]= FindPathOfDataObject(ModelName)
%Initialization
UniqueDataObjCalibDef={};
InputObjStateflow={};
OutputObjStateflow={};
LocalObjStateflow={};
%&& STATEFLOW &&%
FoundStateflowChart = find_system(ModelName,'MaskType','Stateflow');
sfrt = sfroot;
ChartObj=sfrt.find('-isa','Simulink.BlockDiagram','-and','Name',char(ModelName)); %Fetching satefolw chart
StateflowChart = ChartObj.find('-isa','Stateflow.Chart');                         %Fetching data objects present in satefolw chart
%**************************************************************************************************************
%Get Calibration and Define data object from stateflow
FindParameter = StateflowChart.find('-isa','Stateflow.Data','Scope','Parameter');
if ~isempty(FindParameter)
    for index5=1:length(FindParameter)
        DataObjCalibDef{index5}=FindParameter(index5).Name;  
    end

    %Get unique Calibration and Define data object from stateflow
    UniqueDataObjCalibDef=unique(DataObjCalibDef);
end
%***************************************************************************************************************            
%Get Input from stateflow
FindInput = StateflowChart.find('-isa','Stateflow.Data','Scope','Input');
if ~isempty(FindInput)
    for index3=1:length(FindInput)
        DataObjInStore{index3}=FindInput(index3).Name; %Stateflow Input data object
    end
     %Get unique data object of input
    InputObjStateflow=unique(DataObjInStore);                                        
end
%***************************************************************************************************************
%Get Output from stateflow
FindOutput = StateflowChart.find('-isa','Stateflow.Data','Scope','Output');
if ~isempty(FindOutput)
    for index4=1:length(FindOutput)
        DataObjOutStore{index4}=FindOutput(index4).Name;   %Stateflow Output data object
    end
    %Get unique data object of output
    OutputObjStateflow=unique(DataObjOutStore);                                       
end
%***************************************************************************************************************      
%Get Local from stateflow
FindLocal = StateflowChart.find('-isa','Stateflow.Data','Scope','Local');
if ~isempty(FindLocal)
    for index5=1:length(FindLocal)
        DataObjLocalStore{index5}=FindLocal(index5).Name;  %Stateflow Local data object
    end

    %Get unique Local data object from stateflow
    LocalObjStateflow=unique(DataObjLocalStore);
end
%***************************************************************************************************************    
ChartTransitions = StateflowChart.find('-isa','Stateflow.Transition'); %Get path of Stateflow Transition

ChartState = StateflowChart.find('-isa','Stateflow.State'); %Get path of State present Stateflow
%*************************************************************************************************************** 
%&& INPUT/OUTPUT/LOCAL/DEFINE/CALIBRATION/NVM &&%
AllPathInput = find_system(ModelName,'SearchDepth',1,'BlockType','Inport'); %Get top level path of input block

AllPathOutput = find_system(ModelName,'SearchDepth',1,'BlockType','Outport'); %Get top level path of output block

AllPathLocal = find_system(ModelName,'FindAll','on','type','line'); %Get path of Local data object (Resolved signal)

AllPathDefineCalib=find_system(ModelName,'BlockType','Constant'); %Get path of Calibration and Define data object

NvmPath=find_system(ModelName,'BlockType','DataStoreMemory'); %Get path of Nvm data object

DataStoreWritePath=find_system(ModelName,'BlockType','DataStoreWrite');  %Get path of 'DataStoreWrite'

DataStoreReadPath=find_system(ModelName,'BlockType','DataStoreRead');    %Get path of 'DataStoreRead'
              
%*************************************************************************************************************** 
%&& FIRST ORDER TRANSFER FUNCTION &&%
ConstantPath_First_Order_Transfer_Fcn=find_system(ModelName,'MaskType','First Order Transfer Fcn');%Get path of First Order Transfer Fcn block
%***************************************************************************************************************
%&& LOOKUP TABLE &&%
Fix1DLookupPath = find_system(ModelName,'LookUnderMasks','on','Masktype','Fix1DLookup');    %Get path of Curve data object form Fix1DLookup  
Float1DLookupPath = find_system(ModelName,'LookUnderMasks','on','Masktype','Float1DLookup');  %Get path of Curve data object form Float1DLookup
Fix2DLookupPath = find_system(ModelName,'LookUnderMasks','on','Masktype','Fix2DLookup');    %Get path of Map data object form Fix2DLookup  
Float2DLookupPath = find_system(ModelName,'LookUnderMasks','on','Masktype','Float2DLookup');  %Get path of Map data object form Float2DLookup  

LookupPath = find_system(ModelName,'BlockType','Lookup_n-D');                      %Get path lookup table 
LookupTableName= get_param(LookupPath,'NumberOfTableDimensions');                  %Get dimension of lookup table
PreLookupPathMapCurve = find_system(ModelName,'BlockType','Interpolation_n-D'); %prelookup table path of autosar block
PreLookupTableName= get_param(PreLookupPathMapCurve,'NumberOfTableDimensions');% Get dimension of prelookup table
PreLookupPath = find_system(ModelName,'BlockType','PreLookup');                %prelookup table path of autosar block
%*****************************************************************************************************************
