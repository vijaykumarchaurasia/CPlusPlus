%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :InconsistentInOutAttributes 
% MAIN PURPOSE     :Function is used to compare attributes of same name I/O data objects 
%                   in excel vs sldd, if attributs are different then data objects and  
%                   respective attributes of excel sheet and Sldd will capture and stored
% INPUT(S)         :1.Paths=('C:/Users/shubhangim1/Music/Fresh_Project/E39_example/Communications/ccrxp/Model/ccrxp.sldd,D:/CAN_database_SLDD_example_edited - Copy.xlsx')
% OUTPUT           :1.Inconsistent data object list
%                   2.If user selected sldd(component name) not present in excel sheet 
%                     will send "error code:904"
%                   3.If column header not present in excel sheet will send following errorcode:
%                     �Source Variable� name not present in excel= errorCode:912(used as not valid excel sheet)
%                     'Destination Variable' name not present in excel= errorCode:913
%                   4.If sldd and excel does not have similar I/O
%                     will send errorCode:931
% DATE OF CREATION :29th April 2020
% REVESION NO      :1.3
% STATUS           :Rev. 1.1: Tested to compare and capture same I/O name but different attributs of excel sheet and 
%                             sldd which has inconsistency.
%                             Applicable for following categories->Input,Output
%                        1.2: Tested for following column header not
%                             present in excel sheet:
%                             'DataType_Source Variable','DataType_Destination Variable','Offset_Source Variable',
%                             'Offset_Destination Variable','Slope_Source Variable','Slope_Destination Variable'
%                        1.3: DicObj,DicSec and AllEntries are replaced with myDictionaryOb, dDataSectObj and allEntries for naming consistency. 
% FUNCTION CALL    :1.[Basetype, Offset, slope] = SlddtoUI_AbstractDataType(string(DataTypeOfObj))
%                   2.[Code,~,~,~,~,~,~,~,~,~,StoreInputDataObject1,StoreOutputDataObject1,StoreDataType_Input1,StoreDataType_Output1,StoreOffset_Input1,StoreOffset_Output1,StoreSlope_Input1,StoreSlope_Output1,StoreComponentName1]=ValidationOfExcel(ExcelPath);
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function InconsistentData=InconsistentInOutAttributes (Paths,~)
StorePath=strsplit(Paths,',');
Slddpath=char(StorePath(1));
ExcelPath=char(StorePath(2));
%Logic written for loading indicator
%LoadingIndicator starts
%Set LoadingIndicator always on top of screen
LoadingIndicator = waitbar(0,'0% Completed','Name','Inconsistent I/O list is loading...','WindowStyle', 'modal');
frames = java.awt.Frame.getFrames();
frames(end).setAlwaysOnTop(1);
%Set data dictionary icon on LoadingIndicator 
javaFrame = get(LoadingIndicator,'JavaFrame');
ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));

%To find position of 'Source Variable', 'Destination Variable' and respective DataType/Offset/Slope from excel sheet
%TXT is variable which contains all data inside the Excel/Test Vector file
%Read Third Row for Headings of Column
[Code,~,~,~,~,~,~,~,~,~,StoreInputDataObject1,StoreOutputDataObject1,StoreDataType_Input1,StoreDataType_Output1,StoreOffset_Input1,StoreOffset_Output1,StoreSlope_Input1,StoreSlope_Output1,StoreComponentName1]=ValidationOfExcel(ExcelPath);
 if ~strcmp(Code,"4000")
     errorCode=Code;
     InconsistentData=table(errorCode);
     close(LoadingIndicator);
     return;
 end

%Structure of input data object  
Allstruct1=struct2table(struct('warning','Present in excel','Name',cellstr(StoreInputDataObject1),'component',cellstr(StoreComponentName1),'category','Input','Description','','Basetype',cellstr(StoreDataType_Input1),'Offset',cellstr(string(StoreOffset_Input1)),'slope',cellstr(string(StoreSlope_Input1)),'Min','','Max','','Unit','','Dimensions','1','DimensionsMode','auto','Complexity','auto','SampleTime','','InitialValue','','Coderinfo','Auto','SwCalibrationAccess','ReadOnly','DisplayFormat','','Value','','ExcelPath',ExcelPath),'AsArray',true);
UniqueAllInput=unique(Allstruct1);
%Structure of output data object 
Allstruct2=struct2table(struct('warning','Present in excel','Name',cellstr(StoreOutputDataObject1),'component',cellstr(StoreComponentName1),'category','Output','Description','','Basetype',cellstr(StoreDataType_Output1),'Offset',cellstr(string(StoreOffset_Output1)),'slope',cellstr(string(StoreSlope_Output1)),'Min','','Max','','Unit','','Dimensions','1','DimensionsMode','auto','Complexity','auto','SampleTime','','InitialValue','','Coderinfo','Auto','SwCalibrationAccess','ReadOnly','DisplayFormat','','Value','','ExcelPath',ExcelPath),'AsArray',true);
UniqueAllOutput=unique(Allstruct2);
%Combined input and output data object structure
ExcelSheetData=union(UniqueAllInput,UniqueAllOutput);

%Component name in excel sheet is upper case and in sldd is lower case
%so making sldd component name in upper case to compare both
SplitSlddPathAtDelimiter=split(Slddpath,'/');
StotrRemainingPath=SplitSlddPathAtDelimiter(end);
SplitSlddNameAtExtension=split(StotrRemainingPath,'.sldd');
ModelName=SplitSlddNameAtExtension(1);   
component=upper(ModelName);
NameOfModel=table(component);

%Match component name from sldd and excel sheet
[MatchComponentName,~] = ismember(ExcelSheetData(:,3),NameOfModel(:,1));
%If MatchComponentName list is empty
if ~nnz(MatchComponentName)
    errorCode = "904";                                           
    InconsistentData =(table(errorCode));
    close(LoadingIndicator);
    return;
else
    %loop is used to get matched component's data(input and output data objects)
    ComponentWiseExcelSheetData{1,length(MatchComponentName)}=[];
    for index_MatchComponentName=1:length(MatchComponentName)
        if MatchComponentName(index_MatchComponentName)==1
            ComponentWiseExcelSheetData{index_MatchComponentName}=ExcelSheetData(index_MatchComponentName,:);
        end
    end
end
%Empty cells are removed
if ~isempty(ComponentWiseExcelSheetData)
    ComponentWiseExcelSheetData = ComponentWiseExcelSheetData(~cellfun('isempty', ComponentWiseExcelSheetData));
end
SelectedComponentNameData1=struct('warning','Present in excel','Name',"",'component',"",'category','Input','Description',"",...
                    'Basetype',"",'Offset',"",'slope',"",'Min',0,'Max',0,...
                    'Unit',"",'Dimensions',"",...
                    'DimensionsMode',"",'Complexity',"",...
                    'SampleTime',"",'InitialValue',"",...
                    'Coderinfo','Null','SwCalibrationAccess',"ReadOnly",'DisplayFormat',"Null",'Value',"Null",'ExcelPath',"");
SelectedComponentNameData=struct2table(SelectedComponentNameData1);                
%Check the length of 'ComponentWiseExcelSheetData' variable(Store data object in table format)
if length(ComponentWiseExcelSheetData) > 1
    SelectedComponentNameData=[ComponentWiseExcelSheetData{1};ComponentWiseExcelSheetData{2}]; % First and second table combine vertically
    for index1=3:length(ComponentWiseExcelSheetData)
        SelectedComponentNameData=[SelectedComponentNameData;ComponentWiseExcelSheetData{index1}]; % Append rest of table below First and second
    end
else
        SingleDataObjectFound=cell2table(ComponentWiseExcelSheetData); %If single data object present in table      
        SelectedComponentNameData=SingleDataObjectFound.ComponentWiseExcelSheetData;% Store input and output data object with its attribute of excel sheet
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Get data from sldd
%Structure defination
AllInputObjStrct = struct('warning','','Name','','component','','category','','Description','','Basetype','','Offset','','slope','','Min','','Max','','Unit','','Dimensions','','DimensionsMode','','Complexity','','SampleTime','','InitialValue','','Coderinfo','','SwCalibrationAccess','','DisplayFormat','','Value','','ExcelPath','');
AllOutputObjStrct = struct('warning','','Name','','component','','category','','Description','','Basetype','','Offset','','slope','','Min','','Max','','Unit','','Dimensions','','DimensionsMode','','Complexity','','SampleTime','','InitialValue','','Coderinfo','','SwCalibrationAccess','','DisplayFormat','','Value','','ExcelPath','');
% Simulink.data.dictionary.closeAll
myDictionaryObj = Simulink.data.dictionary.open(Slddpath); %Open sldd
dDataSectObj = getSection(myDictionaryObj,'Design Data');
allEntries = find(dDataSectObj);                        %Get entries of sldd
InputDobjCntr = 1;
OutputDobjCntr = 1;
%Loop to get all attributes of each I/O data object
for Index = 1:length(allEntries)
    ValueStructTemp = allEntries(Index).getValue;
    if ~isnumeric(ValueStructTemp)&&~ischar(ValueStructTemp)&&~isstring(ValueStructTemp)
        GetFields=fields(ValueStructTemp);               %Get fields of data object
        log_array = ismember(GetFields,'objectType');    %Check data object having object type
        varv = nnz(log_array);
        if varv==1
            CategoryTemp = ValueStructTemp.objectType;
            if ((strcmp(CategoryTemp,'Input')))
                NameOfComponent=string(component);             %store component name
                DescriptionOfObj=ValueStructTemp.Description;  %store Description
                MinOfObj=ValueStructTemp.Min;                  %store Min
                if isempty(MinOfObj)
                    MinOfObj="";
                end
                MaxOfObj=ValueStructTemp.Max;                  %store Max
                if isempty(MaxOfObj)
                    MaxOfObj="";
                end
                UnitOfObj=ValueStructTemp.Unit;                %store Unit
                DimensionsOfObj=ValueStructTemp.Dimensions;    %store Dimensions
                SampleTimeOfObj=ValueStructTemp.SampleTime;    %store SampleTime
                InitialValueOfObj=ValueStructTemp.InitialValue;%store InitialValue
                if isempty(InitialValueOfObj)
                    InitialValueOfObj="";
                end
                DataTypeOfObj=ValueStructTemp.DataType;
                [Basetype, Offset, slope] = SlddtoUI_AbstractDataType(string(DataTypeOfObj));%Function call
                if isempty(Basetype)
                    Basetype="";
                end
                if isempty(Offset)
                    Offset="";
                end
                if isempty(slope)
                    slope="";
                end
                AllInputObjStrct(InputDobjCntr) = struct('warning','Present in sldd','Name',string(allEntries(Index).Name),'component',NameOfComponent,'category',string(CategoryTemp),'Description',string(DescriptionOfObj),'Basetype',string(Basetype),'Offset',string(Offset),'slope',string(slope),'Min',string(MinOfObj),'Max',string(MaxOfObj),'Unit',string(UnitOfObj),'Dimensions',string(DimensionsOfObj),'DimensionsMode','auto','Complexity','auto','SampleTime',string(SampleTimeOfObj),'InitialValue',string(InitialValueOfObj),'Coderinfo','Auto','SwCalibrationAccess','ReadOnly','DisplayFormat','','Value','','ExcelPath','');
                InputDobjCntr = InputDobjCntr + 1;    
            end
            if (strcmp(CategoryTemp,'Output'))
                NameOfComponent=string(component);             %store component name
                DescriptionOfObj=ValueStructTemp.Description;  %store Description
                MinOfObj=ValueStructTemp.Min;                  %store Min
                if isempty(MinOfObj)
                    MinOfObj="";
                end
                MaxOfObj=ValueStructTemp.Max;                  %store Max
                if isempty(MaxOfObj)
                    MaxOfObj="";
                end
                UnitOfObj=ValueStructTemp.Unit;                %store Unit
                DimensionsOfObj=ValueStructTemp.Dimensions;    %store Dimensions
                SampleTimeOfObj=ValueStructTemp.SampleTime;    %store SampleTime
                InitialValueOfObj=ValueStructTemp.InitialValue;%store InitialValue
                if isempty(InitialValueOfObj)
                    InitialValueOfObj="";
                end
                DataTypeOfObj=ValueStructTemp.DataType;
                [Basetype, Offset, slope] = SlddtoUI_AbstractDataType(string(DataTypeOfObj));%Function call
                if isempty(Basetype)
                    Basetype="";
                end
                if isempty(Offset)
                    Offset="";
                end
                if isempty(slope)
                    slope="";
                end
                AllOutputObjStrct(OutputDobjCntr) = struct('warning','Present in sldd','Name',string(allEntries(Index).Name),'component',NameOfComponent,'category',string(CategoryTemp),'Description',string(DescriptionOfObj),'Basetype',string(Basetype),'Offset',string(Offset),'slope',string(slope),'Min',string(MinOfObj),'Max',string(MaxOfObj),'Unit',string(UnitOfObj),'Dimensions',string(DimensionsOfObj),'DimensionsMode','auto','Complexity','auto','SampleTime',string(SampleTimeOfObj),'InitialValue',string(InitialValueOfObj),'Coderinfo','Auto','SwCalibrationAccess','ReadOnly','DisplayFormat','','Value','','ExcelPath','');
                OutputDobjCntr = OutputDobjCntr + 1;
            end
        end
    end
    waitbar(Index/length(allEntries),LoadingIndicator,sprintf(' Please wait while inconsistent I/O list is being loaded %1.0f%%',(Index/length(allEntries))*100))%Counting of Loadingindicator
end
% Store input and output data object with its attributes of sldd
AllInOutStruct=vertcat(struct2table(AllInputObjStrct,'AsArray',true),struct2table(AllOutputObjStrct,'AsArray',true));
%Checking similar input and output data objects by name
[InOutmatched,PosInExcel]=ismember(AllInOutStruct.Name,SelectedComponentNameData.Name,'rows');
if ~nnz(InOutmatched)%If input and output of sldd and excel not matched(List is empty)
    errorCode="931";
    InconsistentData = (table(errorCode));
    close(LoadingIndicator);
    return;
else
    cntr=1;
    DeclareSendExcelData=struct('warning',{'Present in excel'},'Name',{''},'component',{''},'category',{''},'Description',{''},...
                        'Basetype',{''},'Offset',{''},'slope',{''},'Min',{''},'Max',{''},...
                        'Unit',{''},'Dimensions',{''},...
                        'DimensionsMode',{''},'Complexity',{''},...
                        'SampleTime',{''},'InitialValue',{''},...
                        'Coderinfo',{''},'SwCalibrationAccess',{'ReadOnly'},'DisplayFormat',{''},'Value',{'Null'},'ExcelPath',{''});
    SendExcelData=struct2table(DeclareSendExcelData,'AsArray',true);
    DeclareSendSlddData=struct('warning','Present in excel','Name',"",'component',"",'category',"",'Description',"",...
                        'Basetype',"",'Offset',"",'slope',"",'Min',"",'Max',"",...
                        'Unit',"",'Dimensions',"",...
                        'DimensionsMode',"",'Complexity',"",...
                        'SampleTime',"",'InitialValue',"",...
                        'Coderinfo',"",'SwCalibrationAccess',"",'DisplayFormat',"",'Value','Null','ExcelPath',"");
    SendSlddData=struct2table(DeclareSendSlddData,'AsArray',true);

    %Loop is used to fetch input and output data objects which are found different attributes(Basetype,offset,slope) in sldd and excel
    for index=1:length(InOutmatched)
        if InOutmatched(index) > 0 
            if isequal(string(SelectedComponentNameData.category(PosInExcel(index))),AllInOutStruct.category(index))
                if ~isequal(string(SelectedComponentNameData.Basetype(PosInExcel(index))) ,AllInOutStruct.Basetype(index))||~isequal(string(SelectedComponentNameData.Offset(PosInExcel(index))),AllInOutStruct.Offset(index))||~isequal(string(SelectedComponentNameData.slope(PosInExcel(index))),AllInOutStruct.slope(index))
                    SendExcelData(cntr,:)=SelectedComponentNameData(PosInExcel(index),:);%Store I/O present in excel which having different attribute
                    SendSlddData(cntr,:)=AllInOutStruct(index,:); %Store I/O present in sldd which having different attribute
                    cntr=cntr+1;
                end
            end
        end
    end
end
%LoadingIndicator ends
close(LoadingIndicator);
if ~isempty(SendExcelData)||~isempty(SendSlddData)
    InconsistentData=vertcat(SendExcelData,SendSlddData); %Combine both excel and sldd data objects to send java
end
if InconsistentData.Name==""
    errorCode="1234";
    InconsistentData = (table(errorCode));
end