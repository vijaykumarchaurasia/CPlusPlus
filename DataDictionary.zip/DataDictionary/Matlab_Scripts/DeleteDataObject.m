%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :DeleteDataObject
% MAIN PURPOSE     :Function is used to delete data object(s) from sldd.
% INPUT(S)         :1.sldd_path=('C:\Users\shubhangim1\Music\E39_example\AirManagement\aserc\Model\aserc.sldd')
%                   2.delete_data_object=('ASERC_conO2InSp')
% OUTPUT           :1.If data object(s) successfully deleted from sldd will
%                     send "messageCode=502" OR
%                   2.If data object(s) not successfully deleted from sldd will
%                     send "errorCode=108"
% DATE OF CREATION :17th June 2019
% REVESION NO      :1.1
% STATUS           :Rev. 1.1: Tested to delete multiple data objects from
%                             single sldd
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [Output] =DeleteDataObject(sldd_path,delete_data_object)
%Logic written for loading indicator
%LoadingIndicator starts
%Set LoadingIndicator always on top of screen
LoadingIndicator = waitbar(0,'0% Completed','Name','Deleting data object(s)...','WindowStyle', 'modal');
frames = java.awt.Frame.getFrames();
frames(end).setAlwaysOnTop(1);
%Set data dictionary icon on LoadingIndicator 
javaFrame = get(LoadingIndicator,'JavaFrame');
ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));

%Fetch data object(s) from sldd
% Simulink.data.dictionary.closeAll
myDictionaryObj = Simulink.data.dictionary.open(sldd_path);
dDataSectObj = getSection(myDictionaryObj,'Design Data');
allEntries = find(dDataSectObj);
tic
for index=1:length(allEntries)
    property_name{index}=allEntries(index).Name;  %get all data object's name  
    waitbar(index/length(allEntries),LoadingIndicator,sprintf(' %1.0f%% Completed',(index/length(allEntries))*100))%Counting of Loadingindicator
end
toc
for length_objNames = 1:length(delete_data_object)
    DeleteDataObject=delete_data_object(length_objNames).Name;    %store 'Name' of data object 
    %Checking received data object(s) are present in sldd
    [dObjPrsnt, ~] = ismember(DeleteDataObject,property_name);        
    if (nnz(dObjPrsnt)>0)
        deleteDataEntry =1;
        dataObj = getEntry(dDataSectObj,DeleteDataObject);
        deleteEntry(dataObj)
        messageCode = 502;
        message=table(messageCode);
    else
        errorCode=108;            %If received data object(s) are not present in sldd will send error code
        message=table(errorCode);
    end
end
saveChanges(myDictionaryObj)  %Save sldd
%LoadingIndicator ends
close(LoadingIndicator);
Output = message;
