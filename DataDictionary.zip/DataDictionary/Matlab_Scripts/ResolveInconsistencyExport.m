%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :ResolveInconsistencyExport
% MAIN PURPOSE     :Function is used to compare data objects of excel sheet and Sldd to resolve 
%                   inconsistency between them(Applicable for single
%                   component)and synchronize with excel sheet
% INPUT(S)         :1.Paths=('C:/Users/shubhangim1/Music/Fresh_Project/E39_example/Communications/ccrxp/Model/ccrxp.sldd,D:/CAN_database_SLDD_example_edited - Copy.xlsx')
% OUTPUT           :1.Inconsistent data object list and respective categories
%                     a. Data object list which needs to be added in excel sheet
%                     b. Data object list which needs to be removed from excel sheet OR
%                   2.If list (a) is empty, will send "errorCode:905" and 
%                     If list (b) is empty, will send "errorCode:906" OR
%                   3.If user selected sldd(component name) not present in excel sheet 
%                     will send "error code:904"
%                   4.If column header not present in excel sheet will send following errorcode:
%                     �Source Variable� name not present in excel= errorCode:912(used as not valid excel sheet)
%                     'Destination Variable' name not present in excel= errorCode:913
% DATE OF CREATION :27th April 2020
% REVESION NO      :1.4
% STATUS           :Rev. 1.1: Tested to compare and capture difference between excel sheet and 
%                             sldd data object which has inconsistency.
%                             Applicable for following categories->Input,Output
%                        1.2: Tested for following column header not
%                             present in excel sheet:
%                             'DataType_Source Variable','DataType_Destination Variable','Offset_Source Variable',
%                             'Offset_Destination Variable','Slope_Source Variable','Slope_Destination Variable'
%                        1.3: NumOfEntries evaluation is changed as program name entry is added in other data section.
%                        1.4: OpenSldd,DesignDataSectionObject and NumOfEntries are replaced with myDictionaryObj,dDataSectObj and num_Of_Entries for naming consistency. 
% FUNCTION CALL    :1.[Basetype, Offset, slope] = SlddtoUI_AbstractDataType(string(DataTypeOfObj))
%                   2.[Code,~,~,~,~,~,~,~,~,~,StoreInputDataObject1,StoreOutputDataObject1,StoreDataType_Input1,StoreDataType_Output1,StoreOffset_Input1,StoreOffset_Output1,StoreSlope_Input1,StoreSlope_Output1,StoreComponentName1]=ValidationOfExcel(ExcelPath);
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [InconsistentData]= ResolveInconsistencyExport(Paths,~)
StorePath=strsplit(Paths,',');
Slddpath=char(StorePath(1));
ExcelPath=char(StorePath(2)); 
    
%Logic written for loading indicator
%LoadingIndicator starts
%Set LoadingIndicator always on top of screen
LoadingIndicator = waitbar(0,'0% Completed','Name','Resolving inconsistency with excel...','WindowStyle', 'modal');
frames = java.awt.Frame.getFrames();
frames(end).setAlwaysOnTop(1);
%Set data dictionary icon on LoadingIndicator 
javaFrame = get(LoadingIndicator,'JavaFrame');
ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));

%To find position of 'Source Variable', 'Destination Variable' and respective DataType/Offset/Slope from excel sheet
%TXT is variable which contains all data inside the Excel/Test Vector file
%Read Third Row for Headings of Column
 [Code,~,~,~,~,~,~,~,~,~,StoreInputDataObject1,StoreOutputDataObject1,StoreDataType_Input1,StoreDataType_Output1,StoreOffset_Input1,StoreOffset_Output1,StoreSlope_Input1,StoreSlope_Output1,StoreComponentName1]=ValidationOfExcel(ExcelPath);
 if ~strcmp(Code,"4000")
     errorCode=Code;
     InconsistentData=table(errorCode);
     close(LoadingIndicator);
     return;
 end

%Structure of input data object  
Allstruct1=struct2table(struct('warning','Delete from excel','Name',cellstr(StoreInputDataObject1),'Basetype',cellstr(StoreDataType_Input1),'Offset',cellstr(string(StoreOffset_Input1)),'slope',cellstr(string(StoreSlope_Input1)),'component',cellstr(StoreComponentName1),'category','Input','Description',ExcelPath),'AsArray',true);
UniqueAllInput=unique(Allstruct1);
%Structure of output data object 
Allstruct2=struct2table(struct('warning','Delete from excel','Name',cellstr(StoreOutputDataObject1),'Basetype',cellstr(StoreDataType_Output1),'Offset',cellstr(string(StoreOffset_Output1)),'slope',cellstr(string(StoreSlope_Output1)),'component',cellstr(StoreComponentName1),'category','Output','Description',ExcelPath),'AsArray',true);
UniqueAllOutput=unique(Allstruct2);
%Combined input and output data object structure
ExcelSheetData=union(UniqueAllInput,UniqueAllOutput);

%Component name in excel sheet is upper case and in sldd is lower case
%so making sldd component name in upper case to compare both
SplitSlddPathAtDelimiter=split(Slddpath,'/');
StotrRemainingPath=SplitSlddPathAtDelimiter(end);
SplitSlddNameAtExtension=split(StotrRemainingPath,'.sldd');
ModelName=SplitSlddNameAtExtension(1);   
component=upper(ModelName);
NameOfModel=table(component);

%Match component name from sldd and excel sheet
[MatchComponentName,~] = ismember(ExcelSheetData(:,6),NameOfModel(:,1));
%If MatchComponentName list is empty
if ~nnz(MatchComponentName)
    errorCode = "904";                                           
    InconsistentData =(table(errorCode));
    close(LoadingIndicator);
    return;
else

    %loop is used to get matched component's data(input and output data objects)
    ComponentWiseExcelSheetData{1,length(MatchComponentName)}=[];
    for index_MatchComponentName=1:length(MatchComponentName)
        if MatchComponentName(index_MatchComponentName)==1
            ComponentWiseExcelSheetData{index_MatchComponentName}=ExcelSheetData(index_MatchComponentName,:);
        end
    end
end
%Empty cells are removed
if ~isempty(ComponentWiseExcelSheetData)
    ComponentWiseExcelSheetData = ComponentWiseExcelSheetData(~cellfun('isempty', ComponentWiseExcelSheetData));
end

%Check the length of 'ComponentWiseExcelSheetData' variable
if length(ComponentWiseExcelSheetData) > 1
    SelectedComponentNameData=[ComponentWiseExcelSheetData{1};ComponentWiseExcelSheetData{2}]; % First and second table combine vertically
    for index1=3:length(ComponentWiseExcelSheetData)
        SelectedComponentNameData=[SelectedComponentNameData;ComponentWiseExcelSheetData{index1}]; % Append rest of table below First and second
    end
else
        SingleDataObjectFound=cell2table(ComponentWiseExcelSheetData); %If single data object present in table      
        SelectedComponentNameData=SingleDataObjectFound.ComponentWiseExcelSheetData;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Get data from sldd%
%Initialization
NameOfComponent={};
BasetypeSldd={};
OffsetSldd={};
slopeSldd={};
%Opening sldd
% Simulink.data.dictionary.closeAll
myDictionaryObj = Simulink.data.dictionary.open(Slddpath);
dDataSectObj = getSection(myDictionaryObj,'Design Data');
allEntries = find(dDataSectObj);
num_Of_Entries = length(allEntries);
%Preallocation of memory
DataObjectCategories{1,num_Of_Entries} = [];
storeDobj{1,num_Of_Entries}=[];

%Fetching data object and category from sldd
 cntr1=1;
 for Index2=1:num_Of_Entries
        GetAttriInfo=getValue(allEntries(Index2));                                      %Get all fields of data object
        if ~isnumeric(GetAttriInfo) && ~ischar(GetAttriInfo) &&  ~isstring(GetAttriInfo)
            GetFields=fields(GetAttriInfo);                                             %Get fields of data object
            log_array = ismember(GetFields,'objectType');                               %Check data object having object type
            varv = nnz(log_array);
            if varv==1
                categoryOfDataObj=GetAttriInfo.objectType;        
                if strcmp(categoryOfDataObj,'Input')||strcmp(categoryOfDataObj,'Output')
                    DataObjectCategories{cntr1}=GetAttriInfo.objectType;  %store categories 
                    DataObj=allEntries(Index2).Name;
                    storeDobj{cntr1}=DataObj;                             %store data object
                    NameOfComponent{cntr1}=string(component);             %store component name
                    DataTypeOfObj=GetAttriInfo.DataType;
                    [Basetype, Offset, slope] = SlddtoUI_AbstractDataType(string(DataTypeOfObj));%Function call
                    BasetypeSldd{cntr1}=Basetype;%store Basetype
                    OffsetSldd{cntr1}=Offset;    %store Offset
                    slopeSldd{cntr1}=slope;      %store slope
                    cntr1=cntr1+1;
                end
            end
        end
        waitbar(Index2/num_Of_Entries,LoadingIndicator,sprintf(' %1.0f%% Completed',(Index2/num_Of_Entries)*100))%Counting of Loadingindicator
 end

%remove empty cells
DataObjectCategories = DataObjectCategories(~cellfun('isempty', DataObjectCategories));
storeDobj = storeDobj(~cellfun('isempty', storeDobj));
errorCode=InOutNotPresentInSlddForImportExport(storeDobj);
if strcmp(errorCode,"999")                                          
    InconsistentData = (table(errorCode));
    close(LoadingIndicator);
    return;
end
NameOfComponent = NameOfComponent(~cellfun('isempty', NameOfComponent));

%Creating structure of data object name/DataType/Offset/Slope with respect to category
Allstruct3=struct2table(struct('warning','Add in excel','Name',cellstr(storeDobj),'Basetype',cellstr(BasetypeSldd),'Offset',cellstr(string(OffsetSldd)),'slope',cellstr(string(slopeSldd)),'component',cellstr(NameOfComponent),'category',DataObjectCategories,'Description',ExcelPath),'AsArray',true);
slddDatastruct=unique(Allstruct3);

 %Compare excel sheet data objects with sldd data objects to add data object in sldd
[AddDataObjInExcel,PositionAddDataObjInExcel] = setdiff(slddDatastruct(:,2),SelectedComponentNameData(:,2));
 %If AddDataObjInExcel list is empty
if isempty(AddDataObjInExcel)
    errorCode = "905";                                          
    SendDataAddInExcel = (table(errorCode));
else
    %Loop is used to get data object need to add in sldd which are
    %present in excel
    for AddObj = 1:length(PositionAddDataObjInExcel)
       SendDataAddInExcel(AddObj,:) = (slddDatastruct(PositionAddDataObjInExcel(AddObj),:));
    end
end

%Compare excel sheet data objects with sldd data objects to delete data objects from sldd
[DelDataObjFrmExcel,PositionOfDelDataObjFrmExcel] = setdiff(SelectedComponentNameData(:,2),slddDatastruct(:,2));
%If DelDataObjFrmExcel list is empty
if isempty(DelDataObjFrmExcel)
    errorCode = "906";                                          
    DelObjFrmExcel = (table(errorCode));
else
    %Loop is used to get data object need to delete from sldd which are
    %not present in excel
    for DeleteObj = 1:length(PositionOfDelDataObjFrmExcel)
       DelObjFrmExcel(DeleteObj,:) = (SelectedComponentNameData(PositionOfDelDataObjFrmExcel(DeleteObj),:));
    end
end

%LoadingIndicator ends
close(LoadingIndicator);

%Storing Inconsistent data objects
InconsistentData{1,:}= SendDataAddInExcel;  %To add data object in sldd
InconsistentData{2,:}= DelObjFrmExcel;     %To delete data object from sldd


