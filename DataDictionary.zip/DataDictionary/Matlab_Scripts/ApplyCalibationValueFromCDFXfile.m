%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :ApplyCalibationValueFromCDFXfile
% MAIN PURPOSE     :Function is used to fetch data stoted in CDFX file 
% INPUT(S)         :1.CDFXfile='CSSoftware_Functional_VAAPPUpdate_SS_29May2020.cdfx';
% OUTPUT           :1.Data object(s) and its calibration value(s) from CDFX file OR
%                   2.If CDFX does not containd any data object will send
%                     "errorCode:972"
% DATE OF CREATION :22th June 2020
% REVESION NO      :1.1
% STATUS           :Rev.1.1: Tested to fetch data object and respective calibration value from CDFX file
% FUNCTION CALL    :-
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function StructOfData=ApplyCalibationValueFromCDFXfile(~,CDFXfile)
%Logic written for loading indicator
%LoadingIndicator starts
%Set LoadingIndicator always on top of screen
LoadingIndicator = waitbar(0,'0% Completed','Name','Fetching data from CDFX file...','WindowStyle', 'modal');
frames = java.awt.Frame.getFrames();
frames(end).setAlwaysOnTop(1);

%Set data dictionary icon on LoadingIndicator 
javaFrame = get(LoadingIndicator,'JavaFrame');
ImagePath=('C:\Program Files (x86)\KPIT\Data Dictionary\application_icon_16_8_bit.png');
javaFrame.setFigureIcon(javax.swing.ImageIcon(ImagePath));
%Initialization
DataObjName={};
CompName={};
ValueOfDataObj="";
ValueOfDataObj1="";
CaliVal={};
StructOfData=struct('Name',"",'Value',"",'component',"");

FileID1 = fopen(CDFXfile,'r');%Open cdfx file
FileData = fread(FileID1); %Read that file
fclose(FileID1); %close file
FileData = char(FileData.'); %Convert file data into character
SetOfDataObj = extractBetween(FileData,'<SW-INSTANCE>','</SW-INSTANCE>');%Get objectwise information of Data objects from CDF file
for j=1:length(SetOfDataObj)
    DataObjName{j} = extractBetween(SetOfDataObj(j),'<SHORT-NAME>','</SHORT-NAME>');%Get data object name
    CompName{j} = extractBetween(SetOfDataObj(j),'<SW-FEATURE-REF>','</SW-FEATURE-REF>');%Get component name
    SetOfValueInMap = extractBetween(SetOfDataObj(j),'<VG>','</VG>');%If file contains Map data objects
    if ~isempty(SetOfValueInMap)
        for i=1:length(SetOfValueInMap)%Loop used to get if  map's value also present in file
            CaliVal{i}=extractBetween(SetOfValueInMap(i),'<V>','</V>');
            Store=join(string(CaliVal{1,i}),',');
            ValueOfDataObj(i)=strcat('[',Store,']');
        end
        FinalVal=join(string(ValueOfDataObj),',');%Combining all values in one array
        StructOfData(j)=struct('Name',(string(DataObjName{j}))','Value',FinalVal','component',(string(CompName{j}))');%Create structure to send to java
    else %If map's value not present in file
        Data=extractBetween(SetOfDataObj(j),'<SW-VALUES-PHYS>','</SW-VALUES-PHYS>');%Get set of values
        GetVal= extractBetween(Data,'<V>','</V>');%Get set of values in simple format
        if length(GetVal)==1 %If data objects contains single value
            ValueOfDataObj1(j)=strcat('[',string(GetVal),']');
        else
            Store=join(string(GetVal),',');%If data object having array
            ValueOfDataObj1(j)=strcat('[',Store,']');
        end        
        StructOfData(j)=struct('Name',(string(DataObjName{j})),'Value',ValueOfDataObj1(j),'component',(string(CompName{j})));%Create structure to send to java
    end
end

%LoadingIndicator ends
close(LoadingIndicator);

