%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :FindColumnOfDestinationVariable
% MAIN PURPOSE     :Function is used to find Alphabet of column header of Source variable and its data type/offset/slop in excel sheet
% INPUT(S)         :1.StoreIndexOutputName='12'; (This number depends on column header present in excel sheet.The numbers written here in '' is just example)
%                   2.StoreIndexDataTypeName_Output='13';
%                   3.StoreIndexOffsetName_Output='14';
%                   4.StoreIndexSlopeName_Output='15';
%                   5.StoreIndexComponentName='16';
% OUTPUT           :1.Get Alphabet of respective column header
% DATE OF CREATION :30th April 2020
% REVESION NO      :-
% STATUS           :Function has been written to called in "ExcelAddDeleteQuery","ResolveUseThisObject"script 
% AUTHOR           :Shubhangi Mane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [ColumnSelect_DV,ColumnSelect_DV_DataType,ColumnSelect_DV_Offset,ColumnSelect_DV_slope,ColumnSelect_ModelName] = FindColumnOfDestinationVariable(StoreIndexOutputName,StoreIndexDataTypeName_Output,StoreIndexOffsetName_Output,StoreIndexSlopeName_Output,StoreIndexComponentName)
Alphabet = 'A':'Z';
if StoreIndexOutputName > 26 %Destination variable
    CheckForFirst = floor(StoreIndexOutputName/26);
    CheckForCol = mod(StoreIndexOutputName,26);
    ColumnSelect_DV = strcat(Alphabet(CheckForFirst),Alphabet(CheckForCol));
else
    ColumnSelect_DV = Alphabet(StoreIndexOutputName);
end

if StoreIndexDataTypeName_Output > 26 %Data type
    CheckForFirst = floor(StoreIndexDataTypeName_Output/26);
    CheckForCol = mod(StoreIndexDataTypeName_Output,26);
    ColumnSelect_DV_DataType = strcat(Alphabet(CheckForFirst),Alphabet(CheckForCol));
else
    ColumnSelect_DV_DataType = Alphabet(StoreIndexDataTypeName_Output);
end

if StoreIndexOffsetName_Output > 26 %Offset
    CheckForFirst = floor(StoreIndexOffsetName_Output/26);
    CheckForCol = mod(StoreIndexOffsetName_Output,26);
    ColumnSelect_DV_Offset = strcat(Alphabet(CheckForFirst),Alphabet(CheckForCol));
else
    ColumnSelect_DV_Offset = Alphabet(StoreIndexOffsetName_Output);
end

if StoreIndexSlopeName_Output > 26 %slope
    CheckForFirst = floor(StoreIndexSlopeName_Output/26);
    CheckForCol = mod(StoreIndexSlopeName_Output,26);
    ColumnSelect_DV_slope = strcat(Alphabet(CheckForFirst),Alphabet(CheckForCol));
else
    ColumnSelect_DV_slope = Alphabet(StoreIndexSlopeName_Output);
end

if StoreIndexComponentName > 26 %Model name
    CheckForFirst = floor(StoreIndexComponentName/26);
    CheckForCol = mod(StoreIndexComponentName,26);
    ColumnSelect_ModelName = strcat(Alphabet(CheckForFirst),Alphabet(CheckForCol));
else
    ColumnSelect_ModelName = Alphabet(StoreIndexComponentName);
end