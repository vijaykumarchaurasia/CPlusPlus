%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION NAME    :GetConfigExcelFilePath
% MAIN PURPOSE     :Function is used to send path of configuration excel file path 
% INPUT(S)         :
% OUTPUT           :1.Path of ObjectType excel file OR
%                   2.Excel file is not found then sending error code:1001
% DATE OF CREATION : 2nd July 2021
% REVESION NO      :Rev.1.1
% STATUS           :Rev.1.1:Function has been written to get path of configuration excel file.
% FUNCTION CALL     :FilePath = GetConfigExcelFilePathDbFiles()
% AUTHOR           :Nitin Dahyalkar
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function ConfigurationPath = GetConfigExcelFilePath(~,~)

ConfigFilePath = GetConfigExcelFilePathDbFiles();%Function call
if isempty(ConfigFilePath)
    errorCode = "1001";
    ConfigurationPath = table(errorCode);
    return;
else
    if(length(ConfigFilePath) > 1) 
        %Multiple 
        errorCode = "1002"; 
        ConfigurationPath = table(errorCode);
        return;
    else
        ConfigurationPath = table(ConfigFilePath);
    end
end
end
