//#include "FlasherTest.h"
//#include <gtest/gtest.h>
//#include "DummyClass.h"
//#include <memory>
//#include "Flasher.h"
//#include <thread>
//#include "AppManager.h"
//#include "misc.h"
//#include <EventsManagerModel.h>
//
//class FlasherTest : public testing::Test
// {
//
//
//public:
//std::vector<Record> sre;
//protected:
//
//	std::unique_ptr<AppManager>      mAppManagerPtr;
//	Flasher*       SessionTestPtr;
//	EventsManagerModel*              mEventsManagerHandler;
//
//
//	void SetUp() override
//	{
//		mAppManagerPtr = std::make_unique<AppManager>();
//		SessionTestPtr = mAppManagerPtr->GetFlasherModel();
//		mEventsManagerHandler= mAppManagerPtr->GetEventsManagerModel();
//		sleep(3);
//	}
//	void TearDown() override
//	{
//		mAppManagerPtr = nullptr;
//		SessionTestPtr = nullptr;
//		mEventsManagerHandler = nullptr;
//	}
//
//
//	States GetState()
//	{
//		return SessionTestPtr->state_;
//	}
//
//	std::chrono::steady_clock::time_point GetNextHeartbeat(void)
//	{
//		return SessionTestPtr->next_heartbeat_time_;
//	}
////
////	void CallAcceptAndProgramDataCommand()
////	{
////		SessionTest.AcceptAndProgramDataCommand();
////	}
//	void CallSendServiceHeartBeat(void)
//	{
//		SessionTestPtr->SendServiceHeartBeat();
//	}
//
//	States CallModuleIdDataRequest(void)
//	{
//		return SessionTestPtr->ModuleIdDataRequest();
//	}
//
//	States CallEnterConfigurationLoadModeCommand(void)
//	{
//		return SessionTestPtr->EnterConfigurationLoadModeCommand();
//	}
//
//	States CallEraseOperatingProgramCommand(void)
//	{
//		return SessionTestPtr->EraseOperatingProgramCommand();
//	}
//
//	States CallEraseConfigurationCommand(void)
//	{
//		return SessionTestPtr->EraseConfigurationCommand();
//	}
//
//	States CallEraseProgrammableParametersCommand(void)
//	{
//		return SessionTestPtr->EraseProgrammableParametersCommand();
//	}
//
//	States CallFlashData(void)
//	{
//		return SessionTestPtr->FlashData();
//	}
//
//	States CallSoftwareResetCommand(void)
//	{
//		return SessionTestPtr->SoftwareResetCommand();
//	}
//
//	States CallFlashSessionRetry(void)
//	{
//		return SessionTestPtr->FlashSessionRetry();
//	}
//
//	void SetResponse(CanMessage & this_response)
//	{
//		SessionTestPtr->response_.byte_0 = this_response.byte_0;
//		SessionTestPtr->response_.byte_1 = this_response.byte_1;
//		SessionTestPtr->response_.byte_2 = this_response.byte_2;
//		SessionTestPtr->response_.byte_3 = this_response.byte_3;
//		SessionTestPtr->response_.byte_4 = this_response.byte_4;
//		SessionTestPtr->response_.byte_5 = this_response.byte_5;
//		SessionTestPtr->response_.byte_6 = this_response.byte_6;
//		SessionTestPtr->response_.byte_7 = this_response.byte_7;
//	}
//
//	void PrintCanMessage(CanMessage &this_message)
//	{
//		 std::cout << "" << std::setfill('0') << std::setw(2) << std::right << std::hex << unsigned(this_message.byte_0)<<" "
//				 << "" << std::setfill('0') << std::setw(2) << std::right << std::hex <<unsigned(this_message.byte_1)<< " "
//				 << "" << std::setfill('0') << std::setw(2) << std::right << std::hex <<unsigned(this_message.byte_2)<< " "
//				 << "" << std::setfill('0') << std::setw(2) << std::right << std::hex <<unsigned(this_message.byte_3)<< " "
//				 << "" << std::setfill('0') << std::setw(2) << std::right << std::hex <<unsigned(this_message.byte_4)<< " "
//				 << "" << std::setfill('0') << std::setw(2) << std::right << std::hex <<unsigned(this_message.byte_5)<< " "
//				 << "" << std::setfill('0') << std::setw(2) << std::right << std::hex <<unsigned(this_message.byte_6)<< " "
//				 << "" << std::setfill('0') << std::setw(2) << std::right << std::hex <<unsigned(this_message.byte_7)<< " "<<std::endl;	}
//
//	void GetCanMessageSendResponse(CanMessage & send, CanMessage & response)
//	{
//
//		send.byte_0 = SessionTestPtr->send_.byte_0;
//		send.byte_1 = SessionTestPtr->send_.byte_1;
//		send.byte_2 =  SessionTestPtr->send_.byte_2;
//		send.byte_3 =  SessionTestPtr->send_.byte_3;
//		send.byte_4 =  SessionTestPtr->send_.byte_4;
//		send.byte_5 =  SessionTestPtr->send_.byte_5;
//		send.byte_6 =  SessionTestPtr->send_.byte_6;
//		send.byte_7 =  SessionTestPtr->send_.byte_7;
//
//		response.byte_0 = SessionTestPtr->response_.byte_0;
//		response.byte_1 = SessionTestPtr->response_.byte_1;
//		response.byte_2 =  SessionTestPtr->response_.byte_2;
//		response.byte_3 =  SessionTestPtr->response_.byte_3;
//		response.byte_4 =  SessionTestPtr->response_.byte_4;
//		response.byte_5 =  SessionTestPtr->response_.byte_5;
//		response.byte_6 =  SessionTestPtr->response_.byte_6;
//		response.byte_7 =  SessionTestPtr->response_.byte_7;
//
//	}
//
//	CanMessage GetCanMessageConfigLoadCommand(void)
//	{
//		CanMessage this_message;
//		this_message.byte_0 = SessionTestPtr->config_load_command_.byte_0;
//		this_message.byte_1 = SessionTestPtr->config_load_command_.byte_1;
//		this_message.byte_2 = SessionTestPtr->config_load_command_.byte_2;
//		this_message.byte_3 = SessionTestPtr->config_load_command_.byte_3;
//		this_message.byte_4 = SessionTestPtr->config_load_command_.byte_4;
//		this_message.byte_5 = SessionTestPtr->config_load_command_.byte_5;
//		this_message.byte_6 = SessionTestPtr->config_load_command_.byte_6;
//		this_message.byte_7 = SessionTestPtr->config_load_command_.byte_7;
//		return this_message;
//	}
//
//	void SetCanMessageConfigLoadCommand(CanMessage &config)
//	{
//		SessionTestPtr->config_load_command_ = config;
//	}
//
//	bool GetIdObtained(void)
//	{
//		return SessionTestPtr->id_obtained_;
//	}
//
//	int GetFlashIndex()
//	{
//		return SessionTestPtr->flash_index_;
//	}
//
//
//	bool CanMessageIsEqual(CanMessage message1, CanMessage message2)
//	{
//		if(		message1.byte_0==message2.byte_0
//				&& message1.byte_1==message2.byte_1
//				&& message1.byte_2==message2.byte_2
//				&& message1.byte_3==message2.byte_3
//				&& message1.byte_4==message2.byte_4
//				&& message1.byte_5==message2.byte_5
//				&& message1.byte_6==message2.byte_6
//				&& message1.byte_7==message2.byte_7)
//		{
//			return true;
//		}
//		else
//		{
//			return false;
//		}
//	}
//
//	void CopyFlashingAppData(std::vector<Record> &this_sre)
//	{
//		SessionTestPtr->srec_= this_sre;
//	}
//
//	void CopyFlashingConfigData()
//	{
//		SessionTestPtr->config_=xml_vin_7_003_GH211119_config;
//	}
//
//	void CopyFlashingPPData()
//	{
//		SessionTestPtr->pp_=xml_vin_7_003_GH211119_pp;
//	}
//
//
//	void CallReadOperatingProgram()
//	{
//		SessionTestPtr->ReadOperatingProgram();
//	}
//
//	void CallReadConfiguration()
//	{
//		SessionTestPtr->ReadConfiguration();
//	}
//
//	void CallReadProgrammableParameters()
//	{
//		SessionTestPtr->ReadProgrammableParameters();
//	}
//
//	void GetAcceptData(std::vector<CanMessage> &accept_data)
//	{
//		accept_data=SessionTestPtr->accept_data_;
//	}
//
//	int GetOpSRECsize()
//	{
//		return SessionTestPtr->srec_.size();
//	}
//
//	int GetConfigSRECsize()
//	{
//		return SessionTestPtr->config_.size();
//	}
//
//	int GetPpSRECsize()
//	{
//		return SessionTestPtr->pp_.size();
//	}
//
//	void ClearSREC()
//	{
//		SessionTestPtr->srec_.clear();
//		SessionTestPtr->config_.clear();
//		SessionTestPtr->pp_.clear();
//	}
//
//};
//
//TEST_F(FlasherTest, Init)
//{
//	SessionTestPtr->Init();
//    EXPECT_TRUE(GetNextHeartbeat() < std::chrono::steady_clock::now() + std::chrono::milliseconds {2500});
//	EXPECT_FALSE(GetIdObtained());
//
//}
//
//TEST_F(FlasherTest, SendServiceHeartBeat)
//{
//	CanMessage send;
//	CanMessage response;
//
//	SessionTestPtr->Init();
//	CallSendServiceHeartBeat();
//	GetCanMessageSendResponse(send,response);
//	//PrintCanMessage(send);
//
//	for(int i=0; i<10; i++)
//	{
//		sleep(3);
//		CallSendServiceHeartBeat();
//		GetCanMessageSendResponse(send,response);
//		//PrintCanMessage(send);
//		EXPECT_TRUE(CanMessageIsEqual(send,CanMessage{0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}));
//	}
//}
//
//TEST_F(FlasherTest, ModuleIdDataRequest_stateModuleIdDataRequest_SC)
//{
//	SessionTestPtr->Init();
//	CanMessage response = {0x0A, 0x01, 0x78, 0x56, 0x34, 0x12, 0x00, 0x00};
//	SetResponse(response);
//	EXPECT_EQ(CallModuleIdDataRequest() , stateModuleIdDataRequest_SC);
//	EXPECT_TRUE(GetIdObtained());
//	sleep(12);
//	EXPECT_EQ(CallModuleIdDataRequest() , stateEnterConfigurationLoadMode_SC);
//	EXPECT_TRUE(CanMessageIsEqual(GetCanMessageConfigLoadCommand(), CanMessage{0x02, 0x78, 0x56, 0x34, 0x12, 0xFF, 0xFF, 0xFF}));
//
//	SessionTestPtr->Init();
//	response = {0xFF, 0x01, 0x78, 0x56, 0x34, 0x12, 0x00, 0x00};
//	SetResponse(response);
//	EXPECT_EQ(CallModuleIdDataRequest() , stateFlashSessionRetry_SC);
//}
//
//
//TEST_F(FlasherTest, EnterConfigurationLoadModeCommand)
//{
//	//setup
//	SessionTestPtr->Init();
//	CanMessage response = {0x0A, 0x01, 0x78, 0x56, 0x34, 0x12, 0x00, 0x00};
//	SetResponse(response);
//	EXPECT_EQ(CallModuleIdDataRequest() , stateModuleIdDataRequest_SC);
//	EXPECT_TRUE(GetIdObtained());
//	sleep(12);
//	EXPECT_EQ(CallModuleIdDataRequest() , stateEnterConfigurationLoadMode_SC);
//	EXPECT_TRUE(CanMessageIsEqual(GetCanMessageConfigLoadCommand(), CanMessage{0x02, 0x78, 0x56, 0x34, 0x12, 0xFF, 0xFF, 0xFF}));
//
//	for(int i = 0; i < 9; i++)
//	{
//		response = {0x02, 0x78, 0x56, 0x34, 0x12, 0xFF, 0xFF, 0x00};
//		SetResponse(response);
//		EXPECT_EQ(CallEnterConfigurationLoadModeCommand(),stateEnterConfigurationLoadMode_SC);
//	}
//
//	response = {0x02, 0x78, 0x56, 0x34, 0x12, 0xFF, 0xFF, 0x00};
//	SetResponse(response);
//	EXPECT_EQ(CallEnterConfigurationLoadModeCommand(),stateEraseOperatingProgram_SC);
//}
//
//TEST_F(FlasherTest, EraseOperatingProgramCommand)
//{
//	SessionTestPtr->Init();
//	CanMessage send;
//	CanMessage response = {0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
//	SetResponse(response);
//	EXPECT_EQ(CallEraseOperatingProgramCommand(),statesEraseConfiguration_SC);
//	GetCanMessageSendResponse(send,response);
//	EXPECT_TRUE(CanMessageIsEqual(send, CanMessage{0x03, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}));
//
//	response = {0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
//	SetResponse(response);
//	EXPECT_EQ(CallEraseOperatingProgramCommand(),stateFlashSessionRetry_SC);
//	GetCanMessageSendResponse(send,response);
//	EXPECT_TRUE(CanMessageIsEqual(send, CanMessage{0x03, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}));
//
//	ClearSREC();
//	SessionTestPtr->Init();
//	EXPECT_EQ(CallEraseOperatingProgramCommand(),statesEraseConfiguration_SC);
//	GetCanMessageSendResponse(send,response);
//	EXPECT_TRUE(CanMessageIsEqual(send, CanMessage{0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}));
//	EXPECT_TRUE(CanMessageIsEqual(response, CanMessage{0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}));
//}
//
//TEST_F(FlasherTest, EraseConfigurationCommand)
//{
//	SessionTestPtr->Init();
//	CanMessage send;
//	CanMessage response = {0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
//	SetResponse(response);
//	EXPECT_EQ(CallEraseConfigurationCommand(),statesEraseProgrammableParameters_SC);
//	GetCanMessageSendResponse(send,response);
//	EXPECT_TRUE(CanMessageIsEqual(send, CanMessage{0x04, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}));
//
//	response = {0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
//	SetResponse(response);
//	EXPECT_EQ(CallEraseConfigurationCommand(),stateFlashSessionRetry_SC);
//	GetCanMessageSendResponse(send,response);
//	EXPECT_TRUE(CanMessageIsEqual(send, CanMessage{0x04, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}));
//
//	ClearSREC();
//	SessionTestPtr->Init();
//	EXPECT_EQ(CallEraseConfigurationCommand(),statesEraseProgrammableParameters_SC);
//	GetCanMessageSendResponse(send,response);
//	EXPECT_TRUE(CanMessageIsEqual(send, CanMessage{0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}));
//	EXPECT_TRUE(CanMessageIsEqual(response, CanMessage{0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}));
//}
//
//TEST_F(FlasherTest, EraseProgrammableParametersCommand)
//{
//	SessionTestPtr->Init();
//	CanMessage send;
//	CanMessage response = {0x05, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
//	SetResponse(response);
//	EXPECT_EQ(CallEraseProgrammableParametersCommand(),stateReadOperatingProgram_SC);
//	GetCanMessageSendResponse(send,response);
//	EXPECT_TRUE(CanMessageIsEqual(send, CanMessage{0x05, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}));
//
//	response = {0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
//	SetResponse(response);
//	EXPECT_EQ(CallEraseProgrammableParametersCommand(),stateFlashSessionRetry_SC);
//	GetCanMessageSendResponse(send,response);
//	EXPECT_TRUE(CanMessageIsEqual(send, CanMessage{0x05, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}));
//
//	ClearSREC();
//	SessionTestPtr->Init();
//	EXPECT_EQ(CallEraseProgrammableParametersCommand(),stateReadOperatingProgram_SC);
//	GetCanMessageSendResponse(send,response);
//	EXPECT_TRUE(CanMessageIsEqual(send, CanMessage{0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}));
//	EXPECT_TRUE(CanMessageIsEqual(response, CanMessage{0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}));
//
//}
//
//TEST_F(FlasherTest, ReadOperatingProgram)
//{
//
//	SessionTestPtr->Init();
////	std::cout<<"address: "<<SessionTestPtr<<std::endl;
////	std::cout<<"OP Size: "<<GetOpSRECsize()<<std::endl;
//	CallReadOperatingProgram();
//
//
//
//	std::vector<CanMessage> accept_data;
//	GetAcceptData(accept_data);
//
//	EXPECT_TRUE(accept_data.size() == 195832);
//
//
//	for(uint i=0; i<accept_data.size();i++)
//	{
//		EXPECT_TRUE(CanMessageIsEqual(accept_data[i],can_rev_729_2_0_OP[i]));
////		PrintCanMessage(accept_data[i]);
//	}
////	for (auto& data : accept_data)
////	{
////		PrintCanMessage(data);
////	}
//}
//
//TEST_F(FlasherTest, FlashData)
//{
//	SessionTestPtr->Init();
//	CallReadOperatingProgram();
//
//	std::vector<CanMessage> accept_data;
//	GetAcceptData(accept_data);
//
//	EXPECT_TRUE(accept_data.size() == 195832);
//
//
//	for(uint i=0; i<accept_data.size();i++)
//	{
//		EXPECT_TRUE(CanMessageIsEqual(accept_data[i],can_rev_729_2_0_OP[i]));
////		PrintCanMessage(accept_data[i]);
//	}
//
//
//	for (unsigned int i=0; i< accept_data.size(); i++)
//	{
//		if(accept_data[i].byte_0 == 0x07)
//		{
//			CanMessage response = {0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
//			SetResponse(response);
//
//		}
//		else
//		{
//			SetResponse(accept_data[i]);
//		}
//
//
////		std::cout<<"Flash Index: "<<GetFlashIndex()<<std::endl;
//
//		if(i< accept_data.size())
//		{
//			EXPECT_EQ(CallFlashData(),stateFlashData_SC);
////			CanMessage send;
////			CanMessage response;
////			GetCanMessageSendResponse(send,response);
////			PrintCanMessage(accept_data[i]);
////			PrintCanMessage(send);
////			PrintCanMessage(response);
//		}
//		else
//		{
//			EXPECT_EQ(CallFlashData(),stateSoftwareReset_SC);
////			CanMessage send;
////			CanMessage response;
////			GetCanMessageSendResponse(send,response);
////			PrintCanMessage(accept_data[i]);
////			PrintCanMessage(send);
////			PrintCanMessage(response);
//		}
//
//	}
//}
//
//TEST_F(FlasherTest, SoftwareResetCommand)
//{
//	CanMessage config = CanMessage{0x01, 0x78, 0x56, 0x34, 0x12, 0xFF, 0xFF, 0xFF};
//	SetCanMessageConfigLoadCommand(config);
//
//	SessionTestPtr->Init();
//	CanMessage send;
//	CanMessage response = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
//	SetResponse(response);
//	EXPECT_EQ(CallSoftwareResetCommand(),stateFlashSessionCompleted_SC);
//	GetCanMessageSendResponse(send,response);
//	EXPECT_TRUE(CanMessageIsEqual(send, CanMessage{0x01, 0x78, 0x56, 0x34, 0x12, 0xFF, 0xFF, 0xFF}));
//
//	response = {0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
//	SetResponse(response);
//	EXPECT_EQ(CallSoftwareResetCommand(),stateFlashSessionRetry_SC);
//	GetCanMessageSendResponse(send,response);
//	EXPECT_TRUE(CanMessageIsEqual(send, CanMessage{0x01, 0x78, 0x56, 0x34, 0x12, 0xFF, 0xFF, 0xFF}));
//	PrintCanMessage(send);
//}
//
//TEST_F(FlasherTest, CallReadConfiguration)
//{
//	SessionTestPtr->Init();
//	CallReadConfiguration();
//
//	std::vector<CanMessage> accept_data;
//	GetAcceptData(accept_data);
//
//	EXPECT_TRUE(accept_data.size() == 11570);
//
//
//	for(uint i=0; i<accept_data.size();i++)
//	{
//		EXPECT_TRUE(CanMessageIsEqual(accept_data[i],can_rev_729_2_0_config[i]));
//	//		PrintCanMessage(accept_data[i]);
//	}
////		for (auto& data : accept_data)
////		{
////			PrintCanMessage(data);
////		}
//}
//
//TEST_F(FlasherTest, CallReadProgrammableParameters)
//{
//
//	SessionTestPtr->Init();
//	CallReadProgrammableParameters();
//
//	std::vector<CanMessage> accept_data;
//	GetAcceptData(accept_data);
//
//	EXPECT_TRUE(accept_data.size() == 156);
//
//
//	for(uint i=0; i<accept_data.size();i++)
//	{
//		EXPECT_TRUE(CanMessageIsEqual(accept_data[i],can_rev_729_2_0_pp[i]));
//	//		PrintCanMessage(accept_data[i]);
//	}
//
////	for (auto& data : accept_data)
////	{
////		PrintCanMessage(data);
////	}
//}
//
//TEST_F(FlasherTest, FlashSessionRetry)
//{
//	SessionTestPtr->Init();
//	for(uint i=0; i<maxNumberOfProgrammmingRetries_SC;i++)
//	{
//		EXPECT_EQ(CallFlashSessionRetry(),stateModuleIdDataRequest_SC);
//	}
//	EXPECT_EQ(CallFlashSessionRetry(),stateFlashSessionFailed_SC);
//
//}
//
////TEST_F(FlasherTest, Statemachine)
////{
////	SessionTestPtr->Init();
////	EXPECT_EQ(GetState(),stateModuleIdDataRequest_SC);
////	SessionTestPtr->RunStateMachine();
////
////	CanMessage response = {0x0A, 0x01, 0x78, 0x56, 0x34, 0x12, 0x00, 0x00};
////	SetResponse(response);
////	SessionTestPtr->RunStateMachine();
////	EXPECT_EQ(GetState() , stateModuleIdDataRequest_SC);
////	EXPECT_TRUE(GetIdObtained());
////	sleep(12);
////	EXPECT_EQ(CallModuleIdDataRequest() , stateEnterConfigurationLoadMode_SC);
////	EXPECT_TRUE(CanMessageIsEqual(GetCanMessageConfigLoadCommand(), CanMessage{0x02, 0x78, 0x56, 0x34, 0x12, 0xFF, 0xFF, 0xFF}));
////
////}
