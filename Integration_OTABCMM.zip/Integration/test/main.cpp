/*
 * main.cpp
 *
 *
 * Author: Mo Chabuk
 */

#include <signal.h>
#include <execinfo.h>
#include "gtest/gtest.h"


void CrashHandler(int sig)
{
      void *array[35];
      size_t size;

      size = backtrace(array, 35);
      fprintf(stderr, "Error: signal %d:\n", sig);
      backtrace_symbols_fd(array, size, STDERR_FILENO);
      exit(1);
}

int main(int argc, char **argv)
    {
        signal(SIGSEGV, CrashHandler);
        signal(SIGABRT, CrashHandler);
        signal(SIGTERM, CrashHandler);

        ::testing::InitGoogleTest(&argc, argv);
        return RUN_ALL_TESTS();
    }
