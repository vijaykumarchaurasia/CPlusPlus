///*
// * 	FileHandlerTest.cpp
// *
// *  Author: Harsh Patel
// */
//
//#include <gtest/gtest.h>
//#include <FileHandler.h>
//#include "FileHandlerTest.h"
//#include <EventsManagerModel.h>
//#include <boost/filesystem/fstream.hpp>
//
//class FileHandlerPrivateTest : public testing::Test, protected FileHandler{
//
//protected:
//	const std::string temp_test_dir = "../test/tmp/";
//	bool all_Updates_callback_flg {false};
//	bool conf_callback_flg {false};
//	bool pp_callback_flg {false};
//
//	void SetUp()	override{
//		mAppMangerPtr = nullptr;
//		mListOfSREFiles = std::vector<boostfs::directory_entry>(MAX_SRE);
//		mReadyToFlash = false;
//		mOPUpdateAvailable = false;
//		mConfUpdateAvailable = false;
//		mPPUpdateAvailable = false;
//		mErrorInParsing = false;
//	}
//
//	void TearDown()	override{
//
//	}
//public:
//	void SignalEmmitted_UpdateAvailable(){
//		if (mReadyToFlash)
//			all_Updates_callback_flg = true;
//	}
//	void SignalEmmitted_CONF(){
//		if (mReadyToFlash)
//			conf_callback_flg = true;
//	}
//	void SignalEmmitted_PP(){
//		if (mReadyToFlash)
//			pp_callback_flg = true;
//	}
//
//	void ResetSignalEmmittedFlags(){
//		all_Updates_callback_flg = false;
//		conf_callback_flg = false;
//		pp_callback_flg = false;
//	}
//};
//
//void PrintRecord(Record rec){
//	std::cout << "Type: " << rec.record_type <<std::endl;
//	printf("Byte Count: %d\n", rec.byte_count);
//
//	std::cout << "Address: ";
//	for (auto addr:rec.address){
//		printf("0x%02x, ", addr);
//	}
//	std::cout << std::endl;
//
//	std::cout << "Data: ";
//	for (auto data:rec.data){
//		printf("0x%02x, ", data);
//	}
//	std::cout << std::endl;
//
//	printf("CheckSum: %02x\n", rec.checksum);
//}
//
//std::string CreateSREFile(const std::string& dir, const std::vector<std::string>& sreData){
//
//	boostfs::path file_path = {dir + "TempSreFile_" + std::to_string((rand()%100+1)) + ".sre"};
//
//	boostfs::ofstream ofs;
//	ofs.open(file_path);
//	if (ofs){
//		for (auto data:sreData){
//			ofs<<data << std::endl;;
//		}
//	}
//	else{
//		return "";
//	}
//	return file_path.string();
//}
//
//TEST_F(FileHandlerPrivateTest, IsDirExists){
//
//	EXPECT_TRUE(IsDirExists(FLASH_DIR));
//	EXPECT_TRUE(IsDirExists("/home"));
//	EXPECT_TRUE(IsDirExists("/home/root"));
//	EXPECT_FALSE(IsDirExists("/etc/bcmota"));
//	EXPECT_FALSE(IsDirExists("/var/bcmota.conf"));
//}
//
//TEST_F(FileHandlerPrivateTest, RecordDataType){
//
//	Record test_rec;
//	EXPECT_TRUE(test_rec.record_type.empty());
//	EXPECT_TRUE(test_rec.byte_count == 0);
//	EXPECT_TRUE(test_rec.address.empty());
//	EXPECT_TRUE(test_rec.data.empty());
//	EXPECT_TRUE(test_rec.checksum == 0);
//}
//
//TEST_F(FileHandlerPrivateTest, FindZipFile){
//	//Success Case
//	auto zip_path = FindZipFile("../test");
//
//	EXPECT_TRUE(boostfs::is_regular_file(zip_path));
//	EXPECT_TRUE(zip_path.extension() == ".zip");
//
//	//Fail Case: No Zip Found
//	zip_path = FindZipFile("/home");
//
//	EXPECT_FALSE(boostfs::is_regular_file(zip_path));
//	EXPECT_FALSE(zip_path.extension() == ".zip");
//}
//
////Extract valid zip file to destination. If successful, check if the destination folder is not empty
//TEST_F(FileHandlerPrivateTest, DISABLED_ExtractZipFile){
//	boostfs::path dest {temp_test_dir + "ZIP_Test"};
//
//	//Check if the doesn't exist
//	EXPECT_FALSE(IsDirExists(dest.string()));
//
//	//Success Case:
//	EXPECT_TRUE(ExtractZipFile("../test/test.zip", dest.string()));
//	EXPECT_TRUE(IsDirExists(dest.string()));
//	EXPECT_TRUE(!boostfs::is_empty(dest));
//
//	//Success Case: Existing Files in Dest folder
//	EXPECT_TRUE(ExtractZipFile("../test/test.zip", dest.string()));
//	EXPECT_TRUE(boostfs::remove_all(dest));
//
//	//TODO: Fail Case: No Zip File
////	EXPECT_FALSE(ExtractZipFile("test.zip", dest.string()));
////	EXPECT_FALSE(IsDirExists(dest.string()));
////	EXPECT_FALSE(boostfs::remove_all(dest));
//
//	//TODO: Fail Case: ZIP Password protected
////	EXPECT_FALSE(ExtractZipFile(temp_test_dir + "test_pass.zip", dest.string()));
////	EXPECT_FALSE(IsDirExists(dest.string()));
////	EXPECT_FALSE(boostfs::is_empty(dest));
////	EXPECT_TRUE(boostfs::remove_all(dest));
//
//}
//
//TEST_F(FileHandlerPrivateTest, FindSREFiles){
//
//	boostfs::create_directory(temp_test_dir);
//	std::vector<boostfs::path> test_sre_pass{
//					{temp_test_dir + "test1.sre"},
//					{temp_test_dir + "test2.sre"},
//					{temp_test_dir + "test3.sre"},
//					{temp_test_dir + "VCM_CF_REV.sre"},
//					{temp_test_dir + "test4.sre"},
//					{temp_test_dir + "VCM_KERNEL_REV.sre"},
//					{temp_test_dir + "VCM_PP_REV.sre"},
//					{temp_test_dir + "test5.sre"},
//					};
//
//	for (auto sre:test_sre_pass){
//		boostfs::ofstream ofs{sre};
//		ofs.close();
//	}
//
//	FindSREFiles(temp_test_dir);
//
//	EXPECT_EQ(MAX_SRE, mListOfSREFiles.size());
//
//	for (auto found_sre:mListOfSREFiles){
//		EXPECT_NE( test_sre_pass.begin()+MAX_SRE, std::find(test_sre_pass.begin(), test_sre_pass.begin()+MAX_SRE, found_sre.path()) );
//
//		EXPECT_EQ( test_sre_pass.end(), std::find(test_sre_pass.begin()+MAX_SRE, test_sre_pass.end(), found_sre.path()) );
//	}
//
//	boostfs::remove_all(temp_test_dir);
//}
//
//TEST_F(FileHandlerPrivateTest, SetUpdateAvailableFlag){
//
//	mOPUpdateAvailable = false;
//	mConfUpdateAvailable = false;
//	mPPUpdateAvailable = false;
//
//	SetUpdateAvailableFlag(FileType::invalidFile);
//	EXPECT_FALSE(mOPUpdateAvailable);
//	EXPECT_FALSE(mConfUpdateAvailable);
//	EXPECT_FALSE(mPPUpdateAvailable);
//
//	SetUpdateAvailableFlag((FileType)54);
//	EXPECT_FALSE(mOPUpdateAvailable);
//	EXPECT_FALSE(mConfUpdateAvailable);
//	EXPECT_FALSE(mPPUpdateAvailable);
//
//	SetUpdateAvailableFlag(FileType::confFile);
//	EXPECT_TRUE(mConfUpdateAvailable);
//	EXPECT_FALSE(mPPUpdateAvailable);
//	EXPECT_FALSE(mOPUpdateAvailable);
//
//	SetUpdateAvailableFlag(FileType::opFile);
//	EXPECT_TRUE(mConfUpdateAvailable);
//	EXPECT_TRUE(mOPUpdateAvailable);
//	EXPECT_FALSE(mPPUpdateAvailable);
//
//	SetUpdateAvailableFlag(FileType::ppFile);
//	EXPECT_TRUE(mConfUpdateAvailable);
//	EXPECT_TRUE(mOPUpdateAvailable);
//	EXPECT_TRUE(mPPUpdateAvailable);
//}
//
//TEST_F(FileHandlerPrivateTest, GetAddressSizeInBytes){
//
//	std::unordered_map<std::string, uint8_t> test_data = {	//{Input, Expected Result}
//														{"S0", 2},
//														{"S1", 2},
//														{"S2", 3},
//														{"S3", 4},
//														{"S4", 0},
//														{"S5", 2},
//														{"S6", 3},
//														{"S7", 4},
//														{"S8", 3},
//														{"S9", 2},
//														{"ABC", 0},
//														{"sdjknsdifun5132", 0},
//														{"", 0},
//														{"\n", 0},
//
//	};
//
//	for (auto data:test_data){
//		EXPECT_EQ(data.second, GetAddressSizeInBytes(data.first));
//	}
//}
//
//TEST_F(FileHandlerPrivateTest, ConvertStringToByteVector){
//	std::unordered_map<std::string, std::vector<uint8_t>> test_data = {
//		{"B053D1", 							{0xB0, 0x53, 0xD1}},
//		{"E000043462052455120303244396", 	{0xE0, 0x00, 0x04, 0x34, 0x62, 0x05, 0x24, 0x55, 0x12, 0x03, 0x03,
//												0x24, 0x43, 0x96}},
//		{"F7FB679FDCFDFB7D18D193", 			{0xF7, 0xFB, 0x67, 0x9F, 0xDC, 0xFD, 0xFB, 0x7D, 0x18, 0xD1, 0x93}},
//		{"2402C6407B54584B7824397C0D9694C0D9F89453818A1AF301F689B564F86A701AA22A2CC",
//											{0x24, 0x02, 0xC6, 0x40, 0x7B, 0x54, 0x58, 0x4B, 0x78, 0x24, 0x39,
//												0x7C, 0x0D, 0x96, 0x94, 0xC0, 0xD9, 0xF8, 0x94, 0x53, 0x81, 0x8A,
//												0x1A, 0xF3, 0x01, 0xF6, 0x89, 0xB5, 0x64, 0xF8, 0x6A, 0x70, 0x1A,
//												0xA2, 0x2A, 0x2C, 0x0C}},
//		{"53A",								{0x53, 0xA}},
//		{"C", 								{0xC}},
//		{"F", 								{0xF}},
//		{"C4DG1W;S5ZBT4N", 					{}},
//		{"abc;?f", 							{}},
//		{"", 								{}},
//		{"...",								{}},
//		{"S22402C6000A3E57A8F5AECD9513164D3D328EC39F7E7F6ACA0B8F3994DFBE6DEE6BA35B7B7E",
//											{}},
//		{"20w2xuna20s", 					{}},
//		{"205245S51P", 						{}},
//		{"202LH6VAna20s", 					{}},
//	};
//
//	for (auto data:test_data){
//		EXPECT_EQ(data.second, ConvertStringToByteVector(data.first));
//	}
//}
//
//TEST_F(FileHandlerPrivateTest, WriteDataBuffer){
//	Record test_rec;
//
//	WriteDataBuffer(FileType::confFile, test_rec);
//	WriteDataBuffer(FileType::ppFile, test_rec);
//	WriteDataBuffer(FileType::ppFile, test_rec);
//	WriteDataBuffer(FileType::confFile, test_rec);
//	WriteDataBuffer(FileType::ppFile, test_rec);
//	WriteDataBuffer(FileType::ppFile, test_rec);
//	WriteDataBuffer(FileType::confFile, test_rec);
//	WriteDataBuffer(FileType::opFile, test_rec);
//	WriteDataBuffer(FileType::ppFile, test_rec);
//	WriteDataBuffer(FileType::opFile, test_rec);
//
//
//	EXPECT_EQ(3, mFlashDataMap.at(FileType::confFile).size());
//	EXPECT_EQ(5, mFlashDataMap.at(FileType::ppFile).size());
//	EXPECT_EQ(2, mFlashDataMap.at(FileType::opFile).size());
//}
//
//TEST_F(FileHandlerPrivateTest, ClearDataBuffer){
//	Record test_rec;
//
//	WriteDataBuffer(FileType::confFile, test_rec);
//	WriteDataBuffer(FileType::ppFile, test_rec);
//	WriteDataBuffer(FileType::ppFile, test_rec);
//	WriteDataBuffer(FileType::confFile, test_rec);
//	WriteDataBuffer(FileType::ppFile, test_rec);
//	WriteDataBuffer(FileType::ppFile, test_rec);
//	WriteDataBuffer(FileType::confFile, test_rec);
//	WriteDataBuffer(FileType::opFile, test_rec);
//	WriteDataBuffer(FileType::ppFile, test_rec);
//	WriteDataBuffer(FileType::opFile, test_rec);
//
//
//	EXPECT_EQ(3, mFlashDataMap.at(FileType::confFile).size());
//	EXPECT_EQ(5, mFlashDataMap.at(FileType::ppFile).size());
//	EXPECT_EQ(2, mFlashDataMap.at(FileType::opFile).size());
//
//	ClearDataBuffer(FileType::confFile);
//	ASSERT_TRUE(mFlashDataMap.find(FileType::confFile) == mFlashDataMap.end());
//	EXPECT_EQ(5, mFlashDataMap.at(FileType::ppFile).size());
//	EXPECT_EQ(2, mFlashDataMap.at(FileType::opFile).size());
//
//	ClearDataBuffer(FileType::ppFile);
//	ASSERT_TRUE(mFlashDataMap.find(FileType::confFile) == mFlashDataMap.end());
//	ASSERT_TRUE(mFlashDataMap.find(FileType::ppFile) == mFlashDataMap.end());
//	EXPECT_EQ(2, mFlashDataMap.at(FileType::opFile).size());
//
//	ClearDataBuffer(FileType::opFile);
//	ASSERT_TRUE(mFlashDataMap.find(FileType::confFile) == mFlashDataMap.end());
//	ASSERT_TRUE(mFlashDataMap.find(FileType::ppFile) == mFlashDataMap.end());
//	ASSERT_TRUE(mFlashDataMap.find(FileType::opFile) == mFlashDataMap.end());
//
//}
//
//TEST_F(FileHandlerPrivateTest, ParseSREData){
//
//	Record test_rec;
//	//****************************** Test 1 ****************************************//
//	mErrorInParsing = false;
//	test_rec = ParseSREData("S00B56A24346205354415254C5");
//
//	EXPECT_FALSE(mErrorInParsing);
//	EXPECT_EQ("S0", 									test_rec.record_type);
//	EXPECT_EQ(0x0B, 									test_rec.byte_count);
//	EXPECT_EQ((std::vector<uint8_t>{0x56, 0xA2}), 		test_rec.address);
//	EXPECT_EQ((std::vector<uint8_t>{0x43, 0x46, 0x20,
//									0x53, 0x54, 0x41,
//									0x52, 0x54}), 		test_rec.data);
//	EXPECT_EQ(0xC5, 									test_rec.checksum);
//	//******************************************************************************//
//
//	//****************************** Test 2 ****************************************//
//	mErrorInParsing = false;
//	test_rec = ParseSREData("S624021240000F00770007F05900010002000F007C0007F05A00010002000F007B0007F05BF3");
//
//	EXPECT_FALSE(mErrorInParsing);
//	EXPECT_EQ("S6", 											test_rec.record_type);
//	EXPECT_EQ(0x24,												test_rec.byte_count);
//	EXPECT_EQ((std::vector<uint8_t>{0x02, 0x12, 0x40}), 		test_rec.address);
//	EXPECT_EQ((std::vector<uint8_t>{0x00, 0x0f, 0x00, 0x77,
//									0x00, 0x07, 0xf0, 0x59,
//									0x00, 0x01, 0x00, 0x02,
//									0x00, 0x0f, 0x00, 0x7c,
//									0x00, 0x07, 0xf0, 0x5a,
//									0x00, 0x01, 0x00, 0x02,
//									0x00, 0x0f, 0x00, 0x7b,
//									0x00, 0x07, 0xf0, 0x5b}),	test_rec.data);
//	EXPECT_EQ(0xF3, 											test_rec.checksum);
//	//******************************************************************************//
//
//	//****************************** Test 3 ****************************************//
//	mErrorInParsing = false;
//	test_rec = ParseSREData("S5030018E4");
//
//	EXPECT_FALSE(mErrorInParsing);
//	EXPECT_EQ("S5", 											test_rec.record_type);
//	EXPECT_EQ(0x03, 											test_rec.byte_count);
//	EXPECT_EQ((std::vector<uint8_t>{0x00, 0x18}), 				test_rec.address);
//	EXPECT_EQ((std::vector<uint8_t>{}),							test_rec.data);
//	EXPECT_EQ(0xE4, 											test_rec.checksum);
//	//******************************************************************************//
//
//	//****************************** Test 4 ****************************************//
//	mErrorInParsing = false;
//	test_rec = ParseSREData("S8040A882841");
//
//	EXPECT_FALSE(mErrorInParsing);
//	EXPECT_EQ("S8", 											test_rec.record_type);
//	EXPECT_EQ(0x04, 											test_rec.byte_count);
//	EXPECT_EQ((std::vector<uint8_t>{0x0A, 0x88, 0x28}), 		test_rec.address);
//	EXPECT_EQ((std::vector<uint8_t>{}), 						test_rec.data);
//	EXPECT_EQ(0x41, 											test_rec.checksum);
//	//******************************************************************************//
//
//	//****************************** Test 5 ****************************************//
//	mErrorInParsing = false;
//	test_rec = ParseSREData("S2140B7EB079FFFDC7C501009020F100047108E001B1");
//
//	EXPECT_FALSE(mErrorInParsing);
//	EXPECT_EQ("S2", 											test_rec.record_type);
//	EXPECT_EQ(0x14,												test_rec.byte_count);
//	EXPECT_EQ((std::vector<uint8_t>{0x0B, 0x7E, 0xB0}), 		test_rec.address);
//	EXPECT_EQ((std::vector<uint8_t>{0x79, 0xFF, 0xFD, 0xC7,
//									0xC5, 0x01, 0x00, 0x90,
//									0x20, 0xF1, 0x00, 0x04,
//									0x71, 0x08, 0xE0, 0x01}),	test_rec.data);
//	EXPECT_EQ(0xB1, 											test_rec.checksum);
//	//******************************************************************************//
//
//	//****************************** Test 6 ****************************************//
//	//Checksum Mismatch
//	mErrorInParsing = false;
//	test_rec = ParseSREData("S2140B7EB079FFFDC7C501009020F100047108E001B5");
//
//	EXPECT_TRUE(mErrorInParsing);
//	EXPECT_EQ("S2", 											test_rec.record_type);
//	EXPECT_EQ(0x14,												test_rec.byte_count);
//	EXPECT_EQ((std::vector<uint8_t>{0x0B, 0x7E, 0xB0}), 		test_rec.address);
//	EXPECT_EQ((std::vector<uint8_t>{0x79, 0xFF, 0xFD, 0xC7,
//									0xC5, 0x01, 0x00, 0x90,
//									0x20, 0xF1, 0x00, 0x04,
//									0x71, 0x08, 0xE0, 0x01}),	test_rec.data);
//	EXPECT_EQ(0xB5, 											test_rec.checksum);
//
//	//******************************************************************************//
//
//	//****************************** Test 7 ****************************************//
//	//"S4" type is not a valid format...skip data
//	mErrorInParsing = false;
//	test_rec = ParseSREData("S40500A21454B0D6");
//
//	EXPECT_FALSE(mErrorInParsing);
//	EXPECT_EQ("S4", 											test_rec.record_type);
//	EXPECT_EQ(0x00,												test_rec.byte_count);
//	EXPECT_EQ((std::vector<uint8_t>{}), 						test_rec.address);
//	EXPECT_EQ((std::vector<uint8_t>{}),							test_rec.data);
//	EXPECT_EQ(0x00, 											test_rec.checksum);
//	//******************************************************************************//
//
//	//****************************** Test 8 ****************************************//
//	//Empty line
//	mErrorInParsing = false;
//	test_rec = ParseSREData("");
//
//	EXPECT_FALSE(mErrorInParsing);
//	EXPECT_EQ("",	 											test_rec.record_type);
//	EXPECT_EQ(0x00,												test_rec.byte_count);
//	EXPECT_EQ((std::vector<uint8_t>{}), 						test_rec.address);
//	EXPECT_EQ((std::vector<uint8_t>{}),							test_rec.data);
//	EXPECT_EQ(0x00, 											test_rec.checksum);
//	//******************************************************************************//
//
//	//****************************** Test 9 ****************************************//
//	//Invalid String Characters
//	mErrorInParsing = false;
//	test_rec = ParseSREData("S052ad65a1sd615dvasv");
//
//	EXPECT_TRUE(mErrorInParsing);
//	EXPECT_EQ("S0",	 											test_rec.record_type);
//	EXPECT_EQ(0x00,												test_rec.byte_count);
//	EXPECT_EQ((std::vector<uint8_t>{}), 						test_rec.address);
//	EXPECT_EQ((std::vector<uint8_t>{}),							test_rec.data);
//	EXPECT_EQ(0x00, 											test_rec.checksum);
//
//	//******************************************************************************//
//
//	//****************************** Test 10 ***************************************//
//	//Specified Data length mismatch
//	mErrorInParsing = false;
//	test_rec = ParseSREData("S008ad65a16d615d553aE3");
//
//	EXPECT_TRUE(mErrorInParsing);
//	EXPECT_EQ("S0",	 											test_rec.record_type);
//	EXPECT_EQ(0x8,												test_rec.byte_count);
//	EXPECT_EQ((std::vector<uint8_t>{}), 						test_rec.address);
//	EXPECT_EQ((std::vector<uint8_t>{}),							test_rec.data);
//	EXPECT_EQ(0x00, 											test_rec.checksum);
//	//******************************************************************************//
//
//}
//
//TEST_F(FileHandlerPrivateTest, GetSREFileType){
//
//	boostfs::create_directory(temp_test_dir);
//
//	std::string conf_temp_sre =  CreateSREFile(temp_test_dir, confData);
//	ASSERT_FALSE(conf_temp_sre.empty());
//	EXPECT_EQ(FileType::confFile, GetSREFileType(conf_temp_sre));
//
//	std::string op_temp_sre =  CreateSREFile(temp_test_dir, opData);
//	ASSERT_FALSE(op_temp_sre.empty());
//	EXPECT_EQ(FileType::opFile, GetSREFileType(op_temp_sre));
//
//	std::string pp_temp_sre =  CreateSREFile(temp_test_dir, ppData);
//	ASSERT_FALSE(pp_temp_sre.empty());
//	EXPECT_EQ(FileType::ppFile, GetSREFileType(pp_temp_sre));
//
//	for (auto inv_data:invalidData){
//		std::string invalid_temp_sre =  CreateSREFile(temp_test_dir, inv_data);
//		ASSERT_FALSE(invalid_temp_sre.empty());
//		EXPECT_EQ(FileType::invalidFile, GetSREFileType(invalid_temp_sre));
//	}
//
//	boostfs::remove_all(temp_test_dir);
//
//}
//
////Input: mListOfSRE map with SRE file paths
///*
// * Output:
// * 1. Converted Data buffer for filetype
// * 2. Error flag if something goes wrong, clear data buffer
// * 3. Can't open file, does nothing
// * 4. Skips invalid data line
// * 5. Sets update available flag if everything goes smooth
// */
//TEST_F(FileHandlerPrivateTest, ProcessAllFiles_AllFiles){
//
//	boostfs::create_directory(temp_test_dir);
//
//	std::string conf_temp_sre =  CreateSREFile(temp_test_dir, confData);
//	ASSERT_FALSE(conf_temp_sre.empty());
//	mListOfSREFiles.at((int)FileType::confFile) = (boostfs::directory_entry {boostfs::path{conf_temp_sre}});
//
//	std::string op_temp_sre =  CreateSREFile(temp_test_dir, opData);
//	ASSERT_FALSE(op_temp_sre.empty());
//	mListOfSREFiles.at((int)FileType::opFile) = (boostfs::directory_entry {boostfs::path{op_temp_sre}});
//
//	std::string pp_temp_sre =  CreateSREFile(temp_test_dir, ppData);
//	ASSERT_FALSE(pp_temp_sre.empty());
//	mListOfSREFiles.at((int)FileType::ppFile) = (boostfs::directory_entry {boostfs::path{pp_temp_sre}});
//
//	ProcessAllFiles();
//
//	EXPECT_FALSE(mErrorInParsing);
//	EXPECT_TRUE(mOPUpdateAvailable);
//	EXPECT_TRUE(mPPUpdateAvailable);
//	EXPECT_TRUE(mConfUpdateAvailable);
//
//	ASSERT_TRUE(mFlashDataMap.find(FileType::confFile) != mFlashDataMap.end());
//	ASSERT_TRUE(mFlashDataMap.find(FileType::opFile) != mFlashDataMap.end());
//	ASSERT_TRUE(mFlashDataMap.find(FileType::ppFile) != mFlashDataMap.end());
//
//	EXPECT_EQ(confData.size(), mFlashDataMap.at(FileType::confFile).size());
//	EXPECT_EQ(opData.size(), mFlashDataMap.at(FileType::opFile).size());
//	EXPECT_EQ(ppData.size(), mFlashDataMap.at(FileType::ppFile).size());
//
//	//ConfData Check
//	//"S624021240000F00770007F05900010002000F007C0007F05A00010002000F007B0007F05BF3"
//	Record rec = mFlashDataMap.at(FileType::confFile).at(8);
//
//	EXPECT_EQ("S6", 											rec.record_type);
//	EXPECT_EQ(0x24,												rec.byte_count);
//	EXPECT_EQ((std::vector<uint8_t>{0x02, 0x12, 0x40}), 		rec.address);
//	EXPECT_EQ((std::vector<uint8_t>{0x00, 0x0f, 0x00, 0x77,
//									0x00, 0x07, 0xf0, 0x59,
//									0x00, 0x01, 0x00, 0x02,
//									0x00, 0x0f, 0x00, 0x7c,
//									0x00, 0x07, 0xf0, 0x5a,
//									0x00, 0x01, 0x00, 0x02,
//									0x00, 0x0f, 0x00, 0x7b,
//									0x00, 0x07, 0xf0, 0x5b}),	rec.data);
//	EXPECT_EQ(0xF3, 											rec.checksum);
//
//	//OPData Check
//	//"S2140B7EB079FFFDC7C501009020F100047108E001B1"
//	rec = mFlashDataMap.at(FileType::opFile).at(2);
//	EXPECT_EQ("S2", 											rec.record_type);
//	EXPECT_EQ(0x14,												rec.byte_count);
//	EXPECT_EQ((std::vector<uint8_t>{0x0B, 0x7E, 0xB0}), 		rec.address);
//	EXPECT_EQ((std::vector<uint8_t>{0x79, 0xFF, 0xFD, 0xC7,
//									0xC5, 0x01, 0x00, 0x90,
//									0x20, 0xF1, 0x00, 0x04,
//									0x71, 0x08, 0xE0, 0x01}),	rec.data);
//	EXPECT_EQ(0xB1, 											rec.checksum);
//
//	//PPData Check
//	//"S00B56A24346205354415254C5"
//	rec = mFlashDataMap.at(FileType::ppFile).at(4);
//	EXPECT_EQ("S0", 									rec.record_type);
//	EXPECT_EQ(0x0B, 									rec.byte_count);
//	EXPECT_EQ((std::vector<uint8_t>{0x56, 0xA2}), 		rec.address);
//	EXPECT_EQ((std::vector<uint8_t>{0x43, 0x46, 0x20,
//									0x53, 0x54, 0x41,
//									0x52, 0x54}), 		rec.data);
//	EXPECT_EQ(0xC5, 									rec.checksum);
//
//	boostfs::remove_all(temp_test_dir);
//
//}
//
//TEST_F(FileHandlerPrivateTest, ProcessAllFiles_ConfFile){
//	boostfs::create_directory(temp_test_dir);
//
//	std::string conf_temp_sre =  CreateSREFile(temp_test_dir, confData);
//	ASSERT_FALSE(conf_temp_sre.empty());
//	mListOfSREFiles.at((int)FileType::confFile) = (boostfs::directory_entry {boostfs::path{conf_temp_sre}});
//
//	ProcessAllFiles();
//
//	EXPECT_FALSE(mErrorInParsing);
//	EXPECT_FALSE(mOPUpdateAvailable);
//	EXPECT_FALSE(mPPUpdateAvailable);
//	EXPECT_TRUE(mConfUpdateAvailable);
//
//	ASSERT_TRUE(mFlashDataMap.find(FileType::confFile) != mFlashDataMap.end());
//	ASSERT_FALSE(mFlashDataMap.find(FileType::opFile) != mFlashDataMap.end());
//	ASSERT_FALSE(mFlashDataMap.find(FileType::ppFile) != mFlashDataMap.end());
//
//	EXPECT_EQ( confData.size(), mFlashDataMap.at(FileType::confFile).size() );
//
//	//ConfData Check
//	//"S624021240000F00770007F05900010002000F007C0007F05A00010002000F007B0007F05BF3"
//	Record rec = mFlashDataMap.at(FileType::confFile).at(8);
//
//	EXPECT_EQ("S6", 											rec.record_type);
//	EXPECT_EQ(0x24,												rec.byte_count);
//	EXPECT_EQ((std::vector<uint8_t>{0x02, 0x12, 0x40}), 		rec.address);
//	EXPECT_EQ((std::vector<uint8_t>{0x00, 0x0f, 0x00, 0x77,
//									0x00, 0x07, 0xf0, 0x59,
//									0x00, 0x01, 0x00, 0x02,
//									0x00, 0x0f, 0x00, 0x7c,
//									0x00, 0x07, 0xf0, 0x5a,
//									0x00, 0x01, 0x00, 0x02,
//									0x00, 0x0f, 0x00, 0x7b,
//									0x00, 0x07, 0xf0, 0x5b}),	rec.data);
//	EXPECT_EQ(0xF3, 											rec.checksum);
//
//	boostfs::remove_all(temp_test_dir);
//
//}
//
//TEST_F(FileHandlerPrivateTest, ProcessAllFiles_opFile){
//	boostfs::create_directory(temp_test_dir);
//
//	std::string op_temp_sre =  CreateSREFile(temp_test_dir, opData);
//	ASSERT_FALSE(op_temp_sre.empty());
//	mListOfSREFiles.at((int)FileType::opFile) = (boostfs::directory_entry {boostfs::path{op_temp_sre}});
//
//	ProcessAllFiles();
//
//	EXPECT_FALSE(mErrorInParsing);
//	EXPECT_TRUE(mOPUpdateAvailable);
//	EXPECT_FALSE(mPPUpdateAvailable);
//	EXPECT_FALSE(mConfUpdateAvailable);
//
//	ASSERT_FALSE(mFlashDataMap.find(FileType::confFile) != mFlashDataMap.end());
//	ASSERT_TRUE(mFlashDataMap.find(FileType::opFile) != mFlashDataMap.end());
//	ASSERT_FALSE(mFlashDataMap.find(FileType::ppFile) != mFlashDataMap.end());
//
//	EXPECT_EQ( opData.size(), mFlashDataMap.at(FileType::opFile).size() );
//
//	//ConfData Check
//	//"S2140B7EB079FFFDC7C501009020F100047108E001B1"
//	Record 	rec = mFlashDataMap.at(FileType::opFile).at(2);
//
//	EXPECT_EQ("S2", 											rec.record_type);
//	EXPECT_EQ(0x14,												rec.byte_count);
//	EXPECT_EQ((std::vector<uint8_t>{0x0B, 0x7E, 0xB0}), 		rec.address);
//	EXPECT_EQ((std::vector<uint8_t>{0x79, 0xFF, 0xFD, 0xC7,
//									0xC5, 0x01, 0x00, 0x90,
//									0x20, 0xF1, 0x00, 0x04,
//									0x71, 0x08, 0xE0, 0x01}),	rec.data);
//	EXPECT_EQ(0xB1, 											rec.checksum);
//
//	boostfs::remove_all(temp_test_dir);
//}
//
//TEST_F(FileHandlerPrivateTest, ProcessAllFiles_ppFile){
//	boostfs::create_directory(temp_test_dir);
//
//	std::string pp_temp_sre =  CreateSREFile(temp_test_dir, ppData);
//	ASSERT_FALSE(pp_temp_sre.empty());
//	mListOfSREFiles.at((int)FileType::ppFile) = (boostfs::directory_entry {boostfs::path{pp_temp_sre}});
//
//	ProcessAllFiles();
//
//	EXPECT_FALSE(mErrorInParsing);
//	EXPECT_FALSE(mOPUpdateAvailable);
//	EXPECT_TRUE(mPPUpdateAvailable);
//	EXPECT_FALSE(mConfUpdateAvailable);
//
//	ASSERT_FALSE(mFlashDataMap.find(FileType::confFile) != mFlashDataMap.end());
//	ASSERT_FALSE(mFlashDataMap.find(FileType::opFile) != mFlashDataMap.end());
//	ASSERT_TRUE(mFlashDataMap.find(FileType::ppFile) != mFlashDataMap.end());
//
//	EXPECT_EQ( ppData.size(), mFlashDataMap.at(FileType::ppFile).size() );
//
//	//PPData Check
//	//"S00B56A24346205354415254C5"
//	Record rec = mFlashDataMap.at(FileType::ppFile).at(4);
//	EXPECT_EQ("S0", 									rec.record_type);
//	EXPECT_EQ(0x0B, 									rec.byte_count);
//	EXPECT_EQ((std::vector<uint8_t>{0x56, 0xA2}), 		rec.address);
//	EXPECT_EQ((std::vector<uint8_t>{0x43, 0x46, 0x20,
//									0x53, 0x54, 0x41,
//									0x52, 0x54}), 		rec.data);
//	EXPECT_EQ(0xC5, 									rec.checksum);
//
//	boostfs::remove_all(temp_test_dir);
//}
//
//TEST_F(FileHandlerPrivateTest, ProcessAllFiles_InvalidFiles){
//	boostfs::create_directory(temp_test_dir);
//
//	//Invalid File
//	for (auto inv_data:invalidData){
//		std::string invalid_temp_sre =  CreateSREFile(temp_test_dir, inv_data);
//		ASSERT_FALSE(invalid_temp_sre.empty());
//		mListOfSREFiles.at(0) = (boostfs::directory_entry {boostfs::path{invalid_temp_sre}});
//
//		ProcessAllFiles();
//
//		//EXPECT_TRUE(mErrorInParsing);
//		EXPECT_FALSE(mOPUpdateAvailable);
//		EXPECT_FALSE(mPPUpdateAvailable);
//		EXPECT_FALSE(mConfUpdateAvailable);
//
//		ASSERT_FALSE(mFlashDataMap.find(FileType::confFile) != mFlashDataMap.end());
//		ASSERT_FALSE(mFlashDataMap.find(FileType::opFile) != mFlashDataMap.end());
//		ASSERT_FALSE(mFlashDataMap.find(FileType::ppFile) != mFlashDataMap.end());
//
//	}
//
//	boostfs::remove_all(temp_test_dir);
//}
//
//TEST_F(FileHandlerPrivateTest, ProcessAllFiles_InvalidConf){
//	boostfs::create_directory(temp_test_dir);
//
//	std::string conf_temp_sre =  CreateSREFile(temp_test_dir, confInvalidData);
//	ASSERT_FALSE(conf_temp_sre.empty());
//	mListOfSREFiles.at((int)FileType::confFile) = (boostfs::directory_entry {boostfs::path{conf_temp_sre}});
//
//	ProcessAllFiles();
//
//	EXPECT_TRUE(mErrorInParsing);
//	EXPECT_FALSE(mOPUpdateAvailable);
//	EXPECT_FALSE(mPPUpdateAvailable);
//	EXPECT_FALSE(mConfUpdateAvailable);
//
//	ASSERT_FALSE(mFlashDataMap.find(FileType::confFile) != mFlashDataMap.end());
//	ASSERT_FALSE(mFlashDataMap.find(FileType::opFile) != mFlashDataMap.end());
//	ASSERT_FALSE(mFlashDataMap.find(FileType::ppFile) != mFlashDataMap.end());
//
//	boostfs::remove_all(temp_test_dir);
//
//}
//
//TEST_F(FileHandlerPrivateTest, ProcessAllFiles_InvalidOP){
//	boostfs::create_directory(temp_test_dir);
//
//	std::string op_temp_sre =  CreateSREFile(temp_test_dir, opInvalidData);
//	ASSERT_FALSE(op_temp_sre.empty());
//	mListOfSREFiles.at((int)FileType::opFile) = (boostfs::directory_entry {boostfs::path{op_temp_sre}});
//
//	ProcessAllFiles();
//
//	EXPECT_TRUE(mErrorInParsing);
//	EXPECT_FALSE(mOPUpdateAvailable);
//	EXPECT_FALSE(mPPUpdateAvailable);
//	EXPECT_FALSE(mConfUpdateAvailable);
//
//	ASSERT_FALSE(mFlashDataMap.find(FileType::confFile) != mFlashDataMap.end());
//	ASSERT_FALSE(mFlashDataMap.find(FileType::opFile) != mFlashDataMap.end());
//	ASSERT_FALSE(mFlashDataMap.find(FileType::ppFile) != mFlashDataMap.end());
//
//	boostfs::remove_all(temp_test_dir);
//
//}
//
//TEST_F(FileHandlerPrivateTest, ProcessAllFiles_InvalidPP){
//	boostfs::create_directory(temp_test_dir);
//
//	std::string pp_temp_sre =  CreateSREFile(temp_test_dir, ppInvalidData);
//	ASSERT_FALSE(pp_temp_sre.empty());
//	mListOfSREFiles.at((int)FileType::ppFile) = (boostfs::directory_entry {boostfs::path{pp_temp_sre}});
//
//	ProcessAllFiles();
//
//	EXPECT_TRUE(mErrorInParsing);
//	EXPECT_FALSE(mOPUpdateAvailable);
//	EXPECT_FALSE(mPPUpdateAvailable);
//	EXPECT_FALSE(mConfUpdateAvailable);
//
//	ASSERT_FALSE(mFlashDataMap.find(FileType::confFile) != mFlashDataMap.end());
//	ASSERT_FALSE(mFlashDataMap.find(FileType::opFile) != mFlashDataMap.end());
//	ASSERT_FALSE(mFlashDataMap.find(FileType::ppFile) != mFlashDataMap.end());
//
//	boostfs::remove_all(temp_test_dir);
//
//}
//
//TEST_F(FileHandlerPrivateTest, getOPFlashingData){
//
//	EXPECT_TRUE(getOPFlashingData().empty());
//
//	mReadyToFlash = true;
//	EXPECT_TRUE(getOPFlashingData().empty());
//
//	Record rec;
//	WriteDataBuffer(FileType::opFile, rec);
//	EXPECT_FALSE(getOPFlashingData().empty());
//}
//
//TEST_F(FileHandlerPrivateTest, getConfFlashingData){
//	EXPECT_TRUE(getConfFlashingData().empty());
//
//	mReadyToFlash = true;
//	EXPECT_TRUE(getConfFlashingData().empty());
//
//	Record rec;
//	WriteDataBuffer(FileType::confFile, rec);
//	EXPECT_FALSE(getConfFlashingData().empty());
//}
//
//TEST_F(FileHandlerPrivateTest, getPPFlashingData){
//	EXPECT_TRUE(getPPFlashingData().empty());
//
//	mReadyToFlash = true;
//	EXPECT_TRUE(getPPFlashingData().empty());
//
//	Record rec;
//	WriteDataBuffer(FileType::ppFile, rec);
//	EXPECT_FALSE(getPPFlashingData().empty());
//}
//
//TEST_F(FileHandlerPrivateTest, EmitUpdateAvailableSignal){
//
//	mEventsManagerPtr = new EventsManagerModel();
//
//	ResetSignalEmmittedFlags();
//
//	ASSERT_TRUE( mEventsManagerPtr->ConnectToSignal("UpdateAvailable",
//					boost::bind(&FileHandlerPrivateTest::SignalEmmitted_UpdateAvailable,this)) );
//
//	ASSERT_TRUE( mEventsManagerPtr->ConnectToSignal("ConfUpdateAvailable",
//					boost::bind(&FileHandlerPrivateTest::SignalEmmitted_CONF,this)) );
//
//	ASSERT_TRUE( mEventsManagerPtr->ConnectToSignal("PPUpdateAvailable",
//					boost::bind(&FileHandlerPrivateTest::SignalEmmitted_PP, this)) );
//
//	EXPECT_FALSE(all_Updates_callback_flg);
//	EXPECT_FALSE(conf_callback_flg);
//	EXPECT_FALSE(pp_callback_flg);
//
//	//0-0-0
//	mOPUpdateAvailable = mConfUpdateAvailable = mPPUpdateAvailable = false;
//	EmitUpdateAvailableSignal();
//
//	EXPECT_FALSE(all_Updates_callback_flg);
//	EXPECT_FALSE(conf_callback_flg);
//	EXPECT_FALSE(pp_callback_flg);
//
//	ResetSignalEmmittedFlags();
//
//	//0-0-1
//	mOPUpdateAvailable = mConfUpdateAvailable = false;
//	mPPUpdateAvailable = true;
//	EmitUpdateAvailableSignal();
//
//	EXPECT_FALSE(all_Updates_callback_flg);
//	EXPECT_FALSE(conf_callback_flg);
//	EXPECT_TRUE(pp_callback_flg);
//
//	ResetSignalEmmittedFlags();
//
//	//0-1-0
//	mOPUpdateAvailable = mPPUpdateAvailable = false;
//	mConfUpdateAvailable = true;
//	EmitUpdateAvailableSignal();
//
//	EXPECT_FALSE(all_Updates_callback_flg);
//	EXPECT_TRUE(conf_callback_flg);
//	EXPECT_FALSE(pp_callback_flg);
//
//	ResetSignalEmmittedFlags();
//
//	//0-1-1
//	mConfUpdateAvailable = mPPUpdateAvailable = true;
//	mOPUpdateAvailable = false;
//	EmitUpdateAvailableSignal();
//
//	EXPECT_FALSE(all_Updates_callback_flg);
//	EXPECT_TRUE(conf_callback_flg);
//	EXPECT_TRUE(pp_callback_flg);
//
//	ResetSignalEmmittedFlags();
//
//	//1-0-0
//	mOPUpdateAvailable = true;
//	mConfUpdateAvailable = mPPUpdateAvailable = false;
//	EmitUpdateAvailableSignal();
//
//	EXPECT_FALSE(all_Updates_callback_flg);
//	EXPECT_FALSE(conf_callback_flg);
//	EXPECT_FALSE(pp_callback_flg);
//
//	ResetSignalEmmittedFlags();
//
//	//1-0-1
//	mOPUpdateAvailable = mPPUpdateAvailable = true;
//	mConfUpdateAvailable = false;
//	EmitUpdateAvailableSignal();
//
//	EXPECT_FALSE(all_Updates_callback_flg);
//	EXPECT_FALSE(conf_callback_flg);
//	EXPECT_FALSE(pp_callback_flg);
//
//	ResetSignalEmmittedFlags();
//
//	//1-1-0
//	mOPUpdateAvailable = mConfUpdateAvailable = true;
//	mPPUpdateAvailable = false;
//	EmitUpdateAvailableSignal();
//
//	EXPECT_FALSE(all_Updates_callback_flg);
//	EXPECT_FALSE(conf_callback_flg);
//	EXPECT_FALSE(pp_callback_flg);
//
//	ResetSignalEmmittedFlags();
//
//	//1-1-1
//	mOPUpdateAvailable = mConfUpdateAvailable = mPPUpdateAvailable = true;
//	EmitUpdateAvailableSignal();
//
//	EXPECT_TRUE(all_Updates_callback_flg);
//	EXPECT_FALSE(conf_callback_flg);
//	EXPECT_FALSE(pp_callback_flg);
//
//	ResetSignalEmmittedFlags();
//
//	delete mEventsManagerPtr;
//
//}
//
//TEST_F(FileHandlerPrivateTest, Integrate){
//	mEventsManagerPtr = new EventsManagerModel();
//
//	ResetSignalEmmittedFlags();
//
//	ASSERT_TRUE( mEventsManagerPtr->ConnectToSignal("UpdateAvailable",
//					boost::bind(&FileHandlerPrivateTest::SignalEmmitted_UpdateAvailable,this)) );
//
//	ASSERT_TRUE( mEventsManagerPtr->ConnectToSignal("ConfUpdateAvailable",
//					boost::bind(&FileHandlerPrivateTest::SignalEmmitted_CONF,this)) );
//
//	ASSERT_TRUE( mEventsManagerPtr->ConnectToSignal("PPUpdateAvailable",
//					boost::bind(&FileHandlerPrivateTest::SignalEmmitted_PP, this)) );
//
//	Init();
//
//	EXPECT_FALSE( mErrorInParsing );
//	EXPECT_TRUE( mOPUpdateAvailable );
//	EXPECT_TRUE( mConfUpdateAvailable );
//	EXPECT_TRUE( mPPUpdateAvailable );
//
//
//	EmitUpdateAvailableSignal();
//
//	ASSERT_TRUE( all_Updates_callback_flg );
//
//	EXPECT_TRUE( getOPFlashingData().size() != 0 );
//	EXPECT_TRUE( getConfFlashingData().size() != 0 );
//	EXPECT_TRUE( getPPFlashingData().size() != 0 );
//
//}
//
//
//
//
