#include "gtest/gtest.h"
#include "DummyClass.h"
#include <memory>



class DummyClassTest : public testing::Test
 {

protected:

    std::shared_ptr<DummyClass> DummyClassPtr;

	void SetUp() override
	{
        DummyClassPtr = std::make_shared<DummyClass>();
	}

	void TearDown() override {	}
};

TEST_F(DummyClassTest, FuncRetunsOne)
{
    EXPECT_EQ(1, DummyClassPtr->FuncRetunsOne());
    EXPECT_TRUE(1 == true);
    EXPECT_FALSE(10 == DummyClassPtr->FuncRetunsOne());
}

TEST_F(DummyClassTest, FuncRetunsName)
{
    EXPECT_EQ("squirrel", DummyClassPtr->FuncRetunsName()); //Expect equal
    EXPECT_TRUE("squirrel" == DummyClassPtr->FuncRetunsName()); //expect true
    EXPECT_NE("lion", DummyClassPtr->FuncRetunsName()); // expect not equal
    EXPECT_FALSE("lion" == DummyClassPtr->FuncRetunsName()); // expect false
}



