#include <gtest/gtest.h>
#include <ecu/test/mock_transportclient.h>
#include <ecu/rt/signaladapter.h>
#include "VehicleStateModel.h"

using namespace ecu::lapi;

class VehicleStateModelTest : public testing::Test
{
protected:

    std::shared_ptr<ecu::lapi::MockSubOnlyTransportClient> mFakeTransportClientPtr;
    VehicleStateModel* mVehicleStateModelPtr;
    void SetUp() override
    {
        mFakeTransportClientPtr = std::make_shared<ecu::lapi::MockSubOnlyTransportClient>();
        mVehicleStateModelPtr   = new VehicleStateModel(mFakeTransportClientPtr);
    }

    void TearDown() override
    {
        delete mVehicleStateModelPtr;
    }

public:

    ecu::lapi::com::Message getFakeMessage(const std::string& topic,const std::string& signal_name, double scaled_value)
    {
        ecu::lapi::com::Message msg;
        //create a signal to mock
        auto& signal_adapter = ecu::lapi::rt::SignalAdapter::instance();
        auto sg_create_result = signal_adapter.create_sg(topic);
        if ( sg_create_result.ok() )
            {
                auto signal_group = sg_create_result.take_val();

                if ( signal_group.set_signal_scaled_value(signal_name, scaled_value) )
                    {

                        // pack SignalGroup into com::Message instance
                        auto pack_result = signal_adapter.pack(signal_group);
                        if ( pack_result.ok() )
                            {

                                return pack_result.take_val();
                            }
                    }
            }

        else
            {
                ecu::lapi::logging::WARNING << "Invalid Signal for topic: " << topic
                                            << std::endl;
            }
            return msg;
    }
};


TEST_F(VehicleStateModelTest, EngineRunning)
{
    //Set engineSpeed = 1000  = RUNNING

    auto EngineSpeedMsg = getFakeMessage("rt/telcan/e_eec1","enginespeed",1000);
    mFakeTransportClientPtr->message_arrived("rt/telcan/e_eec1", EngineSpeedMsg);

    EXPECT_FALSE(mVehicleStateModelPtr->GetConditionState("enginespeed"));
}

TEST_F(VehicleStateModelTest, EngineNotRunning)
{
    //Set engineSpeed = 0  = NOT RUNNING
    auto EngineSpeedMsg = getFakeMessage("rt/telcan/e_eec1","enginespeed",0);
    mFakeTransportClientPtr->message_arrived("rt/telcan/e_eec1", EngineSpeedMsg);
    EXPECT_TRUE(mVehicleStateModelPtr->GetConditionState("enginespeed"));
}

TEST_F(VehicleStateModelTest, IgnitionKeyOn)
{
    //Set voltage > 0  =  ignition key is on
    auto BatteryVoltage = getFakeMessage("rt/telcan/e_vep1_21","battery_potential_21",6);
    mFakeTransportClientPtr->message_arrived("rt/telcan/e_vep1_21", BatteryVoltage);
    EXPECT_TRUE(mVehicleStateModelPtr->GetConditionState("battery_potential_21"));
}

TEST_F(VehicleStateModelTest, IgnitionKeyOff)
{
    //Set voltage  = 0  =  ignition key is Off
    auto BatteryVoltage = getFakeMessage("rt/telcan/e_vep1_21","battery_potential_21",0);
    mFakeTransportClientPtr->message_arrived("rt/telcan/e_vep1_21", BatteryVoltage);
    EXPECT_FALSE(mVehicleStateModelPtr->GetConditionState("battery_potential_21"));
}

TEST_F(VehicleStateModelTest, VehicleMoving)
{
    //Moving, speed = 69;
    auto VehicleSpeed = getFakeMessage("rt/telcan/e_ccvs1","WheelBasedVehicleSpeed",69);
    mFakeTransportClientPtr->message_arrived("rt/telcan/e_ccvs1",VehicleSpeed);
    EXPECT_FALSE(mVehicleStateModelPtr->GetConditionState("WheelBasedVehicleSpeed"));
}

TEST_F(VehicleStateModelTest, VehicleStopped)
{
    //NotMoving, speed = 0;
    auto VehicleSpeed = getFakeMessage("rt/telcan/e_ccvs1","WheelBasedVehicleSpeed",0);
    mFakeTransportClientPtr->message_arrived("rt/telcan/e_ccvs1",VehicleSpeed);
    EXPECT_TRUE(mVehicleStateModelPtr->GetConditionState("WheelBasedVehicleSpeed"));
}

TEST_F(VehicleStateModelTest, ParkingSwitchNotReady)
{
    //BrakeSwitchNotSet = 0
    auto BrakeSwitchMsg = getFakeMessage("rt/telcan/e_ccvs1","ParkingBrakeSwitch",0);
    mFakeTransportClientPtr->message_arrived("rt/telcan/e_ccvs1",BrakeSwitchMsg);
    EXPECT_FALSE(mVehicleStateModelPtr->GetConditionState("ParkingBrakeSwitch"));
}

TEST_F(VehicleStateModelTest, ParkingSwitchReady)
{
    //BrakeSwitchSet = 1
    auto BrakeSwitchMsg = getFakeMessage("rt/telcan/e_ccvs1","ParkingBrakeSwitch",1);
    mFakeTransportClientPtr->message_arrived("rt/telcan/e_ccvs1",BrakeSwitchMsg);
    EXPECT_TRUE(mVehicleStateModelPtr->GetConditionState("ParkingBrakeSwitch"));
}

TEST_F(VehicleStateModelTest, GridIsOff)
{
    //Grid is off = 0
    auto GridMsg = getFakeMessage("rt/telcan/propb_vehicle_state_bcm","Acc_GridState",0);
    mFakeTransportClientPtr->message_arrived("rt/telcan/propb_vehicle_state_bcm",GridMsg);
    EXPECT_FALSE(mVehicleStateModelPtr->GetConditionState("Acc_GridState"));
}

TEST_F(VehicleStateModelTest, GridIsOn)
{
    //Grid is on = 1
    auto GridMsg = getFakeMessage("rt/telcan/propb_vehicle_state_bcm","Acc_GridState",1);
    mFakeTransportClientPtr->message_arrived("rt/telcan/propb_vehicle_state_bcm",GridMsg);
    EXPECT_TRUE(mVehicleStateModelPtr->GetConditionState("Acc_GridState"));
}

TEST_F(VehicleStateModelTest, StartStopEnabled)
{
    //SS is on = 1
    auto SSSwitchMsg = getFakeMessage("rt/telcan/propb_vehicle_state_bcm","vehicle_autoss_status",1);
    mFakeTransportClientPtr->message_arrived("rt/telcan/propb_vehicle_state_bcm",SSSwitchMsg);
    EXPECT_FALSE(mVehicleStateModelPtr->GetConditionState("vehicle_autoss_status"));
}

TEST_F(VehicleStateModelTest, StartStopDisabled)
{
    //SS is on = 0
    auto SSSwitchMsg = getFakeMessage("rt/telcan/propb_vehicle_state_bcm","vehicle_autoss_status",0);
    mFakeTransportClientPtr->message_arrived("rt/telcan/propb_vehicle_state_bcm",SSSwitchMsg);
    EXPECT_TRUE(mVehicleStateModelPtr->GetConditionState("vehicle_autoss_status"));
}

TEST_F(VehicleStateModelTest, VehicleReady)
{
    auto Msg = getFakeMessage("rt/telcan/e_eec1","enginespeed",0);
    mFakeTransportClientPtr->message_arrived("rt/telcan/e_eec1", Msg);
    EXPECT_FALSE(mVehicleStateModelPtr->IsVehicleReady());

    Msg = getFakeMessage("rt/telcan/e_vep1_21","battery_potential_21",6);
    mFakeTransportClientPtr->message_arrived("rt/telcan/e_vep1_21", Msg);
    EXPECT_FALSE(mVehicleStateModelPtr->IsVehicleReady());

    Msg = getFakeMessage("rt/telcan/e_ccvs1","WheelBasedVehicleSpeed",0);
    mFakeTransportClientPtr->message_arrived("rt/telcan/e_ccvs1",Msg);
    EXPECT_FALSE(mVehicleStateModelPtr->IsVehicleReady());

    Msg = getFakeMessage("rt/telcan/propb_vehicle_state_bcm","vehicle_autoss_status",0);
    mFakeTransportClientPtr->message_arrived("rt/telcan/propb_vehicle_state_bcm",Msg);
    EXPECT_FALSE(mVehicleStateModelPtr->IsVehicleReady());

    Msg = getFakeMessage("rt/telcan/propb_vehicle_state_bcm","Acc_GridState",1);
    mFakeTransportClientPtr->message_arrived("rt/telcan/propb_vehicle_state_bcm",Msg);
    EXPECT_FALSE(mVehicleStateModelPtr->IsVehicleReady());

    Msg = getFakeMessage("rt/telcan/e_ccvs1","ParkingBrakeSwitch",1);
    mFakeTransportClientPtr->message_arrived("rt/telcan/e_ccvs1",Msg);
    EXPECT_TRUE(mVehicleStateModelPtr->IsVehicleReady());
}


