

#include <cstring>
#include <ecu/logging.h>

#include "SwVer.h"


namespace
{
    auto logmod = ecu::lapi::logging::module("BCMOTA.SwVer");
}

SwVer::SwVer(AppManager* passed):
mAppManagerPtr(passed),
mCallBackHelper(new CallBackHelper(this))
{
    LOG_MOD(NOTICE, logmod) << "Creation: SwVer";

}

SwVer::~SwVer()
{

}


void SwVer::message(const std::string& topic, const Message& msg)
{


}


uint8_t* SwVer::GetOpVer()
{

}
uint8_t* SwVer::GetPpVer()
{

}
uint8_t* SwVer::GetCfVer()
{

}


