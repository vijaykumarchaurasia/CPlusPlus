#include <ecu/logging.h>
#include "DriverInteractionModel.h"
#include "AppManager.h"
#include "VehicleStateModel.h"
#include "ClusterInterface.h"
#include "EventsManagerModel.h"
#include "NotificationMessage.h"
#include <string>

using namespace BCMOTA;

namespace
{
    auto logmod = ecu::lapi::logging::module("BCMOTA.DriverInteractionModel");
}

DriverInteractionModel::DriverInteractionModel(AppManager* appMgr):
mAppManger(appMgr),
mVehicleStateModel(appMgr->GetVehicleStateModel()),
mClusterInterface(appMgr->GetClusterInterface()),
mEventsManagerModel(appMgr->GetEventsManagerModel())
{
     LOG_MOD(NOTICE, logmod)<<"Creation: DriverInteractionModel";
     mEventsManagerModel->AddSignal("StartFlashing");
}

DriverInteractionModel::~DriverInteractionModel()
{
    LOG_MOD(NOTICE, logmod)<<"Destruction: DriverInteractionModel";
}

void DriverInteractionModel::CheckFlashingPreConditions()
{
    LOG_MOD(NOTICE, logmod)<<"CheckFlashingPreConditions()...";

    //Check 3 times if the vehicle is ready or not
    int counter = 3;
    do
    {
        if(mVehicleStateModel->IsVehicleReady()) // if vehicle is ready
        {
            LOG_MOD(NOTICE, logmod)<<"Emitting StartFlashing signal...";
            //Emit the update ready signal
            mEventsManagerModel->EmitSignal("StartFlashing");
            break;
        }
        counter--;
    } while (counter != 0);

    if(0 == counter) // if vehicle is not ready after 3 attempts, then send message to clusture
    {
        std::vector<std::string> failedConditions = mVehicleStateModel->GetFailedConditions();
        // As per cluster message length, compacted below flasher error message
        std::string failedConditionsMsg = "Failed conditions : \n";

        for(const auto& condition : failedConditions)
        {
            failedConditionsMsg += condition + " ";
        }

        NotificationMessage notifyMsg;
        notifyMsg.command = "startQuerySession";
        notifyMsg.msg = failedConditionsMsg.c_str();
        notifyMsg.queryOpt = "";
        notifyMsg.cancelOpt = "";
        notifyMsg.dispTime = "1";
        mClusterInterface->FormatAndSendMsgToCluster(notifyMsg);
    }
}
