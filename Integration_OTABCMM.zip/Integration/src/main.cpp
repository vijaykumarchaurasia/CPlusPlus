/*
 * main.cpp
 *
 *
 * Author: Mo Chabuk
 */
#include <signal.h>
#include <execinfo.h>
#include <memory>
#include <fstream>
#include "AppManager.h"
#include "ClientManagerModel.h"
#include "EventsManagerModel.h"
#include <ecu/logging.h>

void SetUpConfig();
void CrashHandler(int);

int main()
{
    signal(SIGSEGV, CrashHandler);
    signal(SIGABRT, CrashHandler);
    signal(SIGTERM, CrashHandler);
    SetUpConfig();
    std::unique_ptr<AppManager> BCMApp = std::make_unique<AppManager>();
    BCMApp->StartApp();
    for(;;)
    {
        std::this_thread::sleep_for(std::chrono::seconds(1000));
    };

    return 0 ;
}

void SetUpConfig()
{
    std::string configPath("../BCMOTA.conf");
    std::ifstream cf;

    #ifndef EMULATOR
    //Actual box
    configPath = "/home/root/BCMOTA.conf";
    #endif
    ecu::lapi::config::Configuration_ptr config(new ecu::lapi::config::Configuration());


    cf.open(configPath);
    if (cf.is_open())
        {
            ecu::lapi::config::set_config_from_input(config, cf);
        }
    else
        {
            LOG(ERROR) << "Failed to find configuration file. Exiting!";
            throw std::invalid_argument("Can't start the app without a configuration file");
        }
    ecu::lapi::logging::set_from_config(config);

}

void CrashHandler(int sig)
{
      void *array[35];
      size_t size;

      size = backtrace(array, 35);
      fprintf(stderr, "Error: signal %d:\n", sig);
      backtrace_symbols_fd(array, size, STDERR_FILENO);
      exit(1);
}
