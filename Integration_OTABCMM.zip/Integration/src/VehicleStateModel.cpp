/*
 * VehicleStateModel.cpp
 *
 *
 * Author: Mo Chabuk
 */

#include <iterator>
#include <string>
#include <vector>
#include <ecu/logging.h>
#include <ecu/rt/signaladapter.h>
#include "VehicleStateModel.h"

namespace
{
    auto logmod = ecu::lapi::logging::module("BCMOTA.VehicleStateModel");
}

using namespace ecu::lapi::rt;

VehicleStateModel::VehicleStateModel(ecu::lapi::com::ITransportClient_ptr passedClientPtr):
mClient(passedClientPtr),
mCallBackHelper(new CallBackHelper(this))
{
    LOG_MOD(NOTICE, logmod) << "Creation: VehicleStateModel";
    if(mClient)
    {
        LOG_MOD(NOTICE, logmod) << "iTransport client is VALID, subscribing to topics . . ."<<std::endl;
        for (const auto& condition : mVehicleConditions)
            {
                mClient->subscribe(condition.second.first, 0, mCallBackHelper);
                LOG_MOD(NOTICE, logmod) << "Subscribed to " <<condition.second.first <<std::endl;
            }
    }
    else
    {
        LOG_MOD(ERROR, logmod) << "Got INVALID iTransport client ptr, can't subscribe to topics . . ."<<std::endl;
    }
}

VehicleStateModel::~VehicleStateModel()
{
    LOG_MOD(NOTICE, logmod) << "Destruction: VehicleStateModel";
}

void VehicleStateModel::message(const std::string& passedTopic, const Message& msg)
{
    SignalAdapter::UnpackResult unpack = SignalAdapter::instance().unpack(passedTopic,msg);
    SignalGroup receivedGroup_ = unpack.take_val();

    //Engine RPMs
    if(passedTopic == "rt/telcan/e_eec1")
    {
        const Signal *extracted = receivedGroup_.signal("enginespeed");
        Signal::ScaleResult scaledData = extracted->value_scaled();
        mVehicleConditions.at("enginespeed").second = !scaledData.take_val();

    }

    //KeyOn
    else if(passedTopic == "rt/telcan/e_vep1_21")
    {
        const Signal *extracted = receivedGroup_.signal("battery_potential_21");
        Signal::ScaleResult scaledData = extracted->value_scaled();
        mVehicleConditions.at("battery_potential_21").second = !!scaledData.take_val();
    }

    //Accessories / grid state = ON = 1 , SSOff = 0
    else if(passedTopic == "rt/telcan/propb_vehicle_state_bcm")
    {
        const Signal *extracted = receivedGroup_.signal("Acc_GridState");
        Signal::ScaleResult scaledData = extracted->value_scaled();
        mVehicleConditions.at("Acc_GridState").second = !!scaledData.take_val();

        extracted = receivedGroup_.signal("vehicle_autoss_status");
        scaledData = extracted->value_scaled();
        mVehicleConditions.at("vehicle_autoss_status").second = !scaledData.take_val();
    }

    //Vehicle speed = 0
    //Parking brake switch = ON (0 not set , 1 set)
    else if(passedTopic == "rt/telcan/e_ccvs1")
    {
        const Signal *extracted = receivedGroup_.signal("WheelBasedVehicleSpeed");
        Signal::ScaleResult scaledData = extracted->value_scaled();
        mVehicleConditions.at("WheelBasedVehicleSpeed").second = !scaledData.take_val();

        extracted = receivedGroup_.signal("ParkingBrakeSwitch");
        scaledData = extracted->value_scaled();
        mVehicleConditions.at("ParkingBrakeSwitch").second = !!scaledData.take_val();
    }

    else
    {
        LOG_MOD(ERROR, logmod) << "Got INVALID topic!! = "  <<passedTopic<<std::endl;
    }
}

bool VehicleStateModel::IsVehicleReady()
{
    for(const auto& condition : mVehicleConditions)
    {
        if (condition.second.second == false)
        {
            LOG_MOD(INFO, logmod) << " Vehicle NOT READ due to "<<condition.first<<std::endl;
            return false;
        }
    }
    return true;
}

std::vector<std::string> VehicleStateModel::GetFailedConditions()
{
    std::vector<std::string> temp;
    for(const auto& condition : mVehicleConditions)
    {
        if (condition.second.second == false)
        {
            temp.push_back(condition.first);
        }
    }
    return temp;
}

bool VehicleStateModel::GetConditionState(std::string passedSignalName)
{
    const auto& iter = mVehicleConditions.find(passedSignalName);
    if(iter != mVehicleConditions.end())
    {
        return iter->second.second;
    }

    else
    {
        LOG_MOD(ERROR, logmod) << " No such signal/condition found, returning FALSE!! "<<std::endl;
        return false;
    }
}
