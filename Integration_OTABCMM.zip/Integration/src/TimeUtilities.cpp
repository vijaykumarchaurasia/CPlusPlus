/*
 * TimeUtilities.cpp
 *
 *
 * Author: Mo Chabuk
 */
#include <chrono>
#include <string>
#include <date/date.h>
#include <iomanip>
#include "TimeUtilities.h"

unsigned long int TimeUtilities::mThreadID = 0;

TimeUtilities::TimeUtilities() noexcept:
mStartedAt(TimeNow())
    {
    }

TimeUtilities::~TimeUtilities()
    {
    }

void TimeUtilities::init() noexcept
    {
        mStartedAt = TimeNow();
    }

void TimeUtilities::PrintDuration() noexcept
    {
        auto timePoint = TimeNow();
        mDuration = (std::chrono::duration_cast<ms>(timePoint - mStartedAt).count());
        std::cout<< "It took "<< mDuration << " MilliSeconds to execute this operation"<<std::endl;
        mDuration = (std::chrono::duration_cast<us>(timePoint - mStartedAt).count());
        std::cout<< "It took "<< mDuration << " MicroSeconds to execute this operation"<<std::endl;
        mDuration = (std::chrono::duration_cast<ns>(timePoint - mStartedAt).count());
        std::cout<< "It took "<< mDuration << " Nano Seconds to execute this operation"<<std::endl;
    }

ms TimeUtilities::GetDuration() noexcept
    {
        const std::lock_guard<std::mutex> lock(mMutex);
        mDuration = (std::chrono::duration_cast<ms>(TimeNow() - mStartedAt).count());
        return ms(mDuration);
    }

void TimeUtilities::PrintTime()
    {
        const long int currentTime = std::chrono::system_clock::to_time_t(TimeNow());
        std::cout << ctime(&currentTime) << std::endl;
    }


void TimeUtilities::ReleaseTick(TickId passedID)
    {
		const std::lock_guard<std::mutex> lock(mMutex);
		if(passedID > 0)
			{
				mFuncRef.erase(passedID);
			}
    }

bool TimeUtilities::IsActiveCall(TickIdPtr passed)
    {
        const std::lock_guard<std::mutex> lock(mMutex);
        bool DoesExist = false;
        for(auto it = mFuncRef.begin(); it != mFuncRef.end(); ++it)
            {
                if(it->second == passed)
                    {
                        DoesExist = true;
                        break;
                    }
            }
        return DoesExist;
    }

std::map<TickId, TickIdPtr>* TimeUtilities::GetFunctionMap()
    {
        return &mFuncRef;
    }
