#include <ecu/logging.h>
#include <ecu/rt/signaladapter.h>
#include "CanHandler.h"
#include "AppManager.h"
#include "ClientManagerModel.h"
#include "CallBackHelper.h"
#include <cstring>

using namespace ecu::lapi::rt;
namespace
{
    auto logmod = ecu::lapi::logging::module("BCMOTA.Can");
}

Can::Can(AppManager* appMgr):
mAppManger(appMgr),
mClientManagerModel(appMgr->GetClientManagerModel()),
mTransportClient(mClientManagerModel->GetMainClient()),
mSdkCallBackPtr(new CallBackHelper(this))
{
     LOG_MOD(NOTICE, logmod)<<"Creation: Can";
     mTransportClient->subscribe(BCM_TOPIC_NAME, 0, mSdkCallBackPtr);
}

Can::~Can()
{
    mTransportClient->unsubscribe(BCM_TOPIC_NAME,mSdkCallBackPtr);
    LOG_MOD(NOTICE, logmod)<<"Destruction: Can";
}

void Can::message(const std::string &topic, const Message &message)
{
    SignalAdapter::UnpackResult unpack = SignalAdapter::instance().unpack(BCM_TOPIC_NAME, message);
    SignalGroup receivedGroup = unpack.take_val();
    const Signal* dataSignal = receivedGroup.signal("data");
    m_Response = dataSignal->data();
    LOG_MOD(NOTICE, logmod)<<"m_Response.size() -> " << m_Response.size();
    if(m_Response.size() >= 8)
    {
        m_CanMessage->byte_0 = m_Response.at(0);
        m_CanMessage->byte_1 = m_Response.at(1);
        m_CanMessage->byte_2 = m_Response.at(2);
        m_CanMessage->byte_3 = m_Response.at(3);
        m_CanMessage->byte_4 = m_Response.at(4);
        m_CanMessage->byte_5 = m_Response.at(5);
        m_CanMessage->byte_6 = m_Response.at(6);
        m_CanMessage->byte_7 = m_Response.at(7);
    }
}

void Can::SendandGetCanMessage(CanMessage & send, CanMessage & receive)
{
    LOG_MOD(NOTICE, logmod) << "SendandGetCanMessage()...";
    m_CanMessage = &receive;
    ecu::lapi::com::Message message;
    message.set_buffer(GetDataBuffer(send));

    if(mTransportClient->publish(BCM_TOPIC_NAME, message) > 0)
    {
        LOG_MOD(ERROR, logmod)<< "CanHandler successfully published the message for topic : " << BCM_TOPIC_NAME;
    }
    else
    {
        LOG_MOD(ERROR, logmod)<< "CanHandler failed to publish the message for topic : " << BCM_TOPIC_NAME;
    }
}

ecu::lapi::com::Message::DataBuffer Can::GetDataBuffer(CanMessage bcmData)
{
    LOG_MOD(NOTICE, logmod) << "GetDataBuffer()...";
    ecu::lapi::com::Message::DataBuffer dataBuf;
    dataBuf.reserve(8);
    dataBuf.push_back(bcmData.byte_0);
    dataBuf.push_back(bcmData.byte_1);
    dataBuf.push_back(bcmData.byte_2);
    dataBuf.push_back(bcmData.byte_3);
    dataBuf.push_back(bcmData.byte_4);
    dataBuf.push_back(bcmData.byte_5);
    dataBuf.push_back(bcmData.byte_6);
    dataBuf.push_back(bcmData.byte_7);

    return dataBuf;
}

