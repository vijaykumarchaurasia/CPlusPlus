#include "DummyClass.h"
#include <string>



DummyClass::DummyClass()
    {

    }

DummyClass::~DummyClass()
    {

    }

int DummyClass::FuncRetunsOne()
{
    return 1;
}

std::string DummyClass::FuncRetunsName()
{
    return "squirrel" ;

}
