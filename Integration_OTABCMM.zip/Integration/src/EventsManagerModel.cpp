/*
 * EventsManagerModel.cpp
 *
 *
 * Author: Mo Chabuk
 */

#include <ecu/logging.h>
#include <EventsManagerModel.h>

namespace
{
    auto logmod = ecu::lapi::logging::module("BCMOTA.EventsManagerModel");
}



EventsManagerModel::EventsManagerModel()

    {
		InitSignals();
        LOG_MOD(NOTICE, logmod)<<"Creation: EventsManagerModel";
    }

EventsManagerModel::~EventsManagerModel()
    {
        DisconnectAll();
        mDynamicSignalsMap.clear();
        LOG_MOD(NOTICE, logmod)<<"Destruction: EventsManagerModel";
    }

void EventsManagerModel::InitSignals()
{
 for(const auto& signal :mBcmSignals)
 {

    AddSignal(signal);
 }

}

void EventsManagerModel::AddSignal(std::string SignalName)
    {
        auto Iter = mDynamicSignalsMap.find(SignalName);
        if(  Iter == mDynamicSignalsMap.end())
            {
                mDynamicSignalsMap.insert(std::pair<std::string,std::unique_ptr<EventSignal>>(SignalName,std::make_unique<EventSignal>()));
            }
        else
            {
                LOG_MOD(ERROR, logmod)<<"EventsManagerModel: signal " << SignalName << " has already been added";
            }
    }

bool EventsManagerModel::ConnectToSignal(std::string SignalName,const EventSignal::slot_type& slot)
    {
        bool res{false};
        auto Iter = mDynamicSignalsMap.find(SignalName);
        if( Iter == mDynamicSignalsMap.end())
            {
                LOG_MOD(ERROR, logmod)<<"EventsManagerModel: signal " << SignalName << " not found, hence can not be connected";
                return res;
            }
        else
            {
                Iter->second->connect(slot);
                res=true;
            }
        return res;
    }

bool EventsManagerModel::DisconnectFromSignal(std::string SignalName,void (*slotToDisconnect)())
    {
        bool res{false};
        auto Iter = mDynamicSignalsMap.find(SignalName);
        if( Iter  == mDynamicSignalsMap.end())
            {
                LOG_MOD(ERROR, logmod)<<"EventsManagerModel: signal " << SignalName << " not found, hence can not be disconnected";
                return res;
            }
        else
            {
                Iter->second->disconnect(slotToDisconnect);
                res=true;
            }
        return res;
    }

void EventsManagerModel::EmitSignal(std::string SignalName)
    {
        //const std::lock_guard<std::mutex> lock(mSignalMtx);
        auto Iter = mDynamicSignalsMap.find(SignalName);
        if( Iter== mDynamicSignalsMap.end())
            {
                LOG_MOD(ERROR, logmod)<<"EventsManagerModel: signal " << SignalName << " not found, hence can not be emitted";
            }
        else
        {
            (*(Iter->second))();
        }
    }

void EventsManagerModel::DisconnectAll()
    {
        for (const auto& signalPtr : mDynamicSignalsMap)
            {
                signalPtr.second->disconnect_all_slots();
            }
    }
