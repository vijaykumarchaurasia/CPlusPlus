/*
 * ClientManagerModel.cpp
 *
 *
 * Author: Mo Chabuk
 */

#include <ecu/logging.h>
#include "ClientManagerModel.h"

namespace
{
    auto logmod = ecu::lapi::logging::module("BCMOTA.ClientManagerModel");
}

ClientManagerModel::ClientManagerModel():
mCfgMainClient          (new ecu::lapi::config::Configuration())
    {
        LOG_MOD(NOTICE, logmod) << "Creation: ClientManagerModel"  ;
        SetUpClientManager();
    }

ClientManagerModel::~ClientManagerModel()
{
    if(mMainClientPtr)
    {
        mMainClientPtr->stop();
        mMainClientPtr->disconnect();
    }
    LOG_MOD(NOTICE, logmod) << "Destruction: ClientManagerModel";
}

void ClientManagerModel::SetUpClientManager()
    {
        CreateMainClient(); //WIP
    }

bool ClientManagerModel::CreateMainClient()
{
    mCfgMainClient->set("client_name", "BCMOTA")     ;
    if(mCfgMainClient->verify())
    {
        LOG_MOD(NOTICE, logmod) << "Main client configuration is valid" ;
        mMainClientPtr = create_client(mCfgMainClient,ecu::lapi::com::TransportType::TYPE_MQTT);
        if (nullptr != mMainClientPtr)
        {
            LOG_MOD(NOTICE, logmod) << "Created main client" ;
            mMainClientPtr->connect();
            mMainClientPtr->start();
            return true;
        }
        else
        {
            LOG_MOD(ERROR, logmod) << "Failed to create main client" ;
            return false;
        }

    }
    else
    {
        LOG_MOD(ERROR, logmod) << "Failed to create main client, configuration invalid !" ;
        return false ;
    }
}


ecu::lapi::com::ITransportClient_ptr ClientManagerModel::GetMainClient()
{
	return mMainClientPtr;
}

