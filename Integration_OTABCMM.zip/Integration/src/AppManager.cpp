/*
 * AppManager.cpp
 *
 *
 * Author: Mo Chabuk
 */
#include <assert.h>
#include <chrono>
#include <ecu/logging.h>
#include "AppManager.h"
#include "EventsManagerModel.h"
#include "ClientManagerModel.h"
#include "Flasher.h"
#include "FileHandler.h"
#include "VehicleStateModel.h"
#include "DriverInteractionModel.h"

namespace
    {
       auto logmod = ecu::lapi::logging::module("BCMOTA.AppManager");
    }

AppManager::AppManager():
mTimeUtilitiesPtr		(std::make_unique<TimeUtilities>()),
mEventsManagerModelPtr  (std::make_unique<EventsManagerModel>()),
mClientManagerModelPtr  (std::make_unique<ClientManagerModel>()),
mClusterInterfacePtr        (std::make_unique<ClusterInterface>(this)),
mVehicleStateModelPtr   (std::make_unique<VehicleStateModel>(mClientManagerModelPtr->GetMainClient())),
mDriverInteractionModelPtr  (std::make_unique<DriverInteractionModel>(this)),
mFileHandlerModelPtr	(std::make_unique<FileHandler>(this)),
mFlasherModelPtr        (std::make_unique<Flasher>(this))
    {
        LOG_MOD(NOTICE, logmod) << "Creation: AppManager done creating models";
    }

AppManager::~AppManager()
    {
        LOG_MOD(NOTICE, logmod) << "Destruction: AppManager";
    }

void AppManager::StartApp()
    {
        #ifndef EMULATOR
        GetClientManagerModel()->SetUpClientManager();
        #endif
    }

TimeUtilities* AppManager::GetTimeUtilities()
	{
		assert(nullptr != mTimeUtilitiesPtr);
		return mTimeUtilitiesPtr.get();
	}

EventsManagerModel* AppManager::GetEventsManagerModel()
    {
        assert(nullptr != mEventsManagerModelPtr);
        return mEventsManagerModelPtr.get();
    }


ClientManagerModel* AppManager::GetClientManagerModel()
    {
        assert(nullptr != mClientManagerModelPtr);
        return mClientManagerModelPtr.get();
    }

FileHandler* AppManager::GetFileHandlerModel()
	{
		assert(nullptr != mFileHandlerModelPtr);
		return mFileHandlerModelPtr.get();
	}

Flasher* AppManager::GetFlasherModel()
	{
		assert(nullptr != mFlasherModelPtr);
		return mFlasherModelPtr.get();
	}

VehicleStateModel* AppManager::GetVehicleStateModel()
{
    assert(nullptr != mVehicleStateModelPtr);
    return mVehicleStateModelPtr.get();
}

DriverInteractionModel* AppManager::GetDriverInteractionModel()
{
    assert(nullptr != mDriverInteractionModelPtr);
    return mDriverInteractionModelPtr.get();
}

ClusterInterface* AppManager::GetClusterInterface()
{
    assert(nullptr != mClusterInterfacePtr);
    return mClusterInterfacePtr.get();
}
