

#include <cstring>
#include <ecu/logging.h>
#include "ServiceMode.h"
#include <ecu/rt/signaladapter.h>
#include "ClientManagerModel.h"


using namespace ecu::lapi::rt;

namespace
{
    auto logmod = ecu::lapi::logging::module("BCMOTA.ServiceMode");
}


ServiceMode::ServiceMode(AppManager* passed):
mAppManagerPtr(passed)
{
    LOG_MOD(NOTICE, logmod) << "Creation: ServiceMode";

}

ServiceMode::~ServiceMode()
{

}


bool ServiceMode::SetOpertingMode(uint8_t mode){


   printf("SetOpertingMode.\n");

   auto& signal_adapter = rt::SignalAdapter::instance();
   auto sg_create_result = signal_adapter.create_sg(TOPIC_SET_OP_MODE);
   if (sg_create_result.nok()){
      //error
      printf("Unable to create SignalGroup for topic: %s\n", TOPIC_SET_OP_MODE);
      return (false);
   }
   auto signal_group = sg_create_result.take_val();


   if (!signal_group.set_signal_scaled_value("set_n2_operating_mode", mode)){
      printf("Failed to set data!\n");
   }


   auto pack_result = signal_adapter.pack(signal_group);
   if (pack_result.nok()){
      printf("Packing failed: [%d] [%s]\n", pack_result.err_val().code, pack_result.err_val().details.c_str());
      return false;
   }

   auto message = pack_result.take_val();

   if (mAppManagerPtr->GetClientManagerModel()->GetMainClient()->publish(TOPIC_SET_OP_MODE, message) > 0){
      printf("Successfully sent msg '%s'.\n", TOPIC_SET_OP_MODE);
      return (true);
   } else {
      printf("Failed to send '%s'.\n", TOPIC_SET_OP_MODE);
      return (false);
   }
}






