
/* ClusterInterface.cpp
 *
 *
 * Author: Vijay Kr
 */

#include <cstring>
#include <ecu/logging.h>
#include "AppManager.h"
#include "ClientManagerModel.h"
#include "ClusterInterface.h"

namespace
{
    auto logmod = ecu::lapi::logging::module("BCMOTA.ClusterInterface");
}

int ClusterInterface::mRejectionCount = 0;

ClusterInterface::ClusterInterface(AppManager* passed):
mAppManagerPtr(passed),
mCallBackHelper(new CallBackHelper(this)),
mClient(passed->GetClientManagerModel()->GetMainClient())
{
    LOG_MOD(NOTICE, logmod) << "Creation: ClusterInterface";
    if(mClient)
    {
        mClient->subscribe(TOPIC_CLUSTER_TO_OTA, 0, mCallBackHelper);
        LOG_MOD(NOTICE, logmod) << "Subscribed to the topic:" <<TOPIC_CLUSTER_TO_OTA <<std::endl;

    }
    else
    {
        LOG_MOD(ERROR, logmod) << "INVALID ITransportClient_ptr, can't subscribe to the topic:" << TOPIC_CLUSTER_TO_OTA;
    }
}

ClusterInterface::~ClusterInterface()
{
     mClient->unsubscribe(TOPIC_CLUSTER_TO_OTA,mCallBackHelper);
     LOG_MOD(NOTICE, logmod)<<"unsubscribe the topic: "<< TOPIC_CLUSTER_TO_OTA << " Destruction: ClusterInterface" ;
}


bool ClusterInterface::SendMessageToCluster(char* msg)
{
    com::Message message;
    message.set_buffer(getDataBuffer((uint8_t *)msg, std::strlen(msg)));
    if (mClient->publish(TOPIC_OTA_TO_CLUSTER, message) > 0)
    {
        //success
        logging::DEBUG << "ClusterInterface::Message sent successfully: " << msg;
        return true;
    }
    else
    {      //fail
        LOG_MOD(ERROR, logmod) << "ClusterInterface::Failed to send message: " << msg;
        return false;
    }
}


char* ClusterInterface::FormatClusterMessage(BCMOTA::NotificationMessage& msgData)
{
    char* body = nullptr;

    if(std::strcmp( msgData.command, SESSION_INFO) == 0)
    {

        int length = 2 + std::strlen(msgData.command) + std::strlen(msgData.msg) + std::strlen(msgData.dispTime);
        body = new char[length + 1];

        // Copy Comand
        copyMsg(body, (char*)msgData.command, 0);
        body[std::strlen(msgData.command)] = ',';

        //copy msg
        copyMsg(body, (char*)msgData.msg, 1 + std::strlen(msgData.command));
        body[1 + std::strlen(msgData.msg) + std::strlen(msgData.command)] = ',';

        // Copy Info display time
        copyMsg(body, (char*)msgData.dispTime, 2 + std::strlen(msgData.command) + std::strlen(msgData.msg));
        body[length] = '\0';
    }
    else if(std::strcmp(msgData.command, SESSION_QUERY) == 0)
    {
        int length = 2 + std::strlen(msgData.command) + std::strlen(msgData.msg) + std::strlen(msgData.queryOpt);

        // For Premium Cluster
        if(std::strcmp(msgData.cancelOpt, "NA") != 0)
        {
            length = length + std::strlen(msgData.cancelOpt) + 1;
        }

        body = new char[length + 1];

        // Copy Comand
        copyMsg(body, (char*)msgData.command, 0);
        body[std::strlen(msgData.command)] = ',';

        //copy msg
        copyMsg(body, (char*)msgData.msg, 1 + std::strlen(msgData.command));
        body[1 + std::strlen(msgData.msg) + std::strlen(msgData.command)] = ',';

        // Copy Query options
        copyMsg(body, (char*)msgData.queryOpt, 2 + std::strlen(msgData.command) + std::strlen(msgData.msg));
        if(std::strcmp(msgData.cancelOpt, "NA") != 0)
        {
        // Copy Cancel option for Premium Cluster
            body[2 + std::strlen(msgData.msg) + std::strlen(msgData.command) + std::strlen(msgData.queryOpt)] = ',';
            copyMsg(body, (char*)msgData.cancelOpt, 3 + std::strlen(msgData.command) + std::strlen(msgData.msg) + std::strlen(msgData.queryOpt));
        }
        body[length] = '\0';

    }
    else if((std::strcmp(msgData.command, SESSION_STATUS) == 0) ||
            (std::strcmp(msgData.command, SESSION_CANCEL) == 0) ||
            (std::strcmp(msgData.command, SESSION_CULSTER_TYPE) == 0))
    {
        int length = std::strlen(msgData.command);
        body = new char[length + 1];

        // Copy Comand
        copyMsg(body, (char*)msgData.command, 0);
        body[length] = '\0';

    }
    else
    {
        LOG_MOD(ERROR, logmod) << "ClusterInterface::Invalid Command: " << msgData.command;
    }

    return body;
}

com::Message::DataBuffer ClusterInterface::getDataBuffer(uint8_t *data, int size) {
	com::Message::DataBuffer dataBuf;

	copy(&data[0], &data[size], back_inserter(dataBuf));

	return dataBuf;
}

void ClusterInterface::copyMsg(char* target, char* str, int start){
    for (int i = 0; i < (int)strlen(str); i++){
        target[start + i] = str[i];
    }
}

void ClusterInterface::message(const std::string& topic, const Message& message)
{
    if(topic.compare(TOPIC_CLUSTER_TO_OTA)==0)
    {
        std::string reply;
		reply.assign(message.get_buffer().begin(), message.get_buffer().end());
        logging::INFO << "Query Reply: " << reply;

        // Check rejection count
        if(reply.find("queryReply,2") != std::string::npos)
        {
            ClusterInterface::mRejectionCount++;
        }
        else
        {
            // Reset rejection count value
            ClusterInterface::mRejectionCount = 0;
        }
    }
}

bool ClusterInterface::FormatAndSendMsgToCluster(BCMOTA::NotificationMessage& msg)
{
    char* send = FormatClusterMessage(msg);
    if(nullptr!=send)
    {
        return SendMessageToCluster(send);
    }
    else
    {
        LOG_MOD(ERROR, logmod) << "ClusterInterface::Invalid notification msg ";
        return false;
    }

}

