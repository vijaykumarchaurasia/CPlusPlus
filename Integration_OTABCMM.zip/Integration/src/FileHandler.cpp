
#include <ecu/logging.h>

#include <fstream>
#include <ios>
#include <iterator>
#include "AppManager.h"
#include "EventsManagerModel.h"
#include "FileHandler.h"

//Add get update type "MO"

namespace
{
   auto logmod = ecu::lapi::logging::module("BCMOTA.FileHandler");
}

FileHandler::FileHandler(AppManager* passed):
mAppMangerPtr(passed),
mEventsManagerPtr(passed->GetEventsManagerModel()),
mReadyToFlash(false),
mOPUpdateAvailable(false),
mConfUpdateAvailable(false),
mPPUpdateAvailable(false),
mListOfSREFiles(MAX_SRE),
mSignalEmitTick(0)
{
	LOG_MOD(NOTICE, logmod) << "Creation: FileHanlder";
    Init();
}

/*
 * Delete extracted SRE files when the app is finished running.
 */
FileHandler::~FileHandler()
{
	if (nullptr != mAppMangerPtr){
		mAppMangerPtr->GetTimeUtilities()->ReleaseTick(mSignalEmitTick);
	}
	for (auto file:mListOfSREFiles){
		LOG_MOD(NOTICE, logmod) << "~FileHandler(): Deleting file - " << file.path().filename().string();
		boostfs::remove(file.path());
	}
}

/*
 * 1. Find Zip File in Default Flash directory.
 * 2. If zip file is present, extract it into Flash directory
 * 3. Find SRE files
 * 4. Identify and Parse each SRE found in Flash directory folder. Write its data into mFlashDataMap buffer.
 * 5. If all data is loaded successfully, Emit Update Available signal, based on the SRE file type found.
 * 6. Provide data using accessors
 */
void FileHandler::Init()
{
	const boost::filesystem::path zipFilePath = FindZipFile(FLASH_DIR);

	if (!boostfs::is_regular_file(zipFilePath)){
		mListOfSREFiles.resize(0);
		return;
	}

	if ( !ExtractZipFile(zipFilePath.string(), FLASH_DIR) ){
		LOG_MOD(ERROR, logmod) << "Failed To Extract Zip File";
		mListOfSREFiles.resize(0);
		//TODO: Delte Zip File??
		return;
	}

	FindSREFiles(FLASH_DIR);
	ProcessAllFiles();

	if (nullptr != mAppMangerPtr){
		mSignalEmitTick = mAppMangerPtr->GetTimeUtilities()->Tick(ms(2000), Redundancy::DoOnce, &FileHandler::EmitUpdateAvailableSignal, this);
	}
}

void FileHandler::ProcessAllFiles(){

	for (auto file:mListOfSREFiles){
		FileType file_type = GetSREFileType(file.path().string());

		if (file_type != FileType::invalidFile){
			std::ifstream ifs(file.path().string(), std::ifstream::in);

			if (!ifs)	continue;	//If Error in opening file, skip it

			std::string line;
			line.clear();
			while (std::getline(ifs, line)){

				mErrorInParsing = false;
				Record parsed_rec = ParseSREData(line);

				if (mErrorInParsing == true){
					//TODO: If error is in OP File, clear and stop everything (Check if this applies to other files)
					//Delete Zip File??
					ClearDataBuffer(file_type);
					break;
				}
				else if (mErrorInParsing == false && parsed_rec.address.empty() && parsed_rec.data.empty() ){
					continue;
				}
				else{
					WriteDataBuffer(file_type, parsed_rec);
				}

				line.clear();
			}

			if (mErrorInParsing != true){
				SetUpdateAvailableFlag(file_type);
			}
		}
	}
}

Record FileHandler::ParseSREData(std::string line){
	/*
	 * Format of Data: RecordType(like "S0"), Byte Count, Address, Data, Checksum
	 */
	Record rec;

	rec.record_type = line.substr(0,2);
	uint8_t addressSizeInBytes = GetAddressSizeInBytes(rec.record_type);

	if (addressSizeInBytes == 0)	return rec;		//Skip this data line if there is no address in data

	std::vector<uint8_t> lineData = ConvertStringToByteVector(line.substr(2, line.size()));

	if (lineData.empty()){
		LOG_MOD(ERROR, logmod) << "ParseSREData(): File Data Have Invalid String Character";
		mErrorInParsing = true;
		return rec;
	}

	std::vector<uint8_t>::iterator itr = lineData.begin();
	rec.byte_count = *itr;

	uint8_t sum = 0;
	sum += *itr;

	if ((rec.byte_count + 1) != (uint8_t)lineData.size()){
		LOG_MOD(ERROR, logmod) << "ParseSREData(): Specified data length not matching given data";
		mErrorInParsing = true;
		return rec;
	}

	itr = itr+1;

	while (itr < lineData.end()){

		auto itr_pos = std::distance(lineData.begin(), itr);

		if((itr_pos >= 1) && (itr_pos <= addressSizeInBytes)){
			rec.address.push_back(*itr);
			sum += *itr;
		}
		else{
			//If byte count is greater than address size and checksum byte, it contains data
			if (rec.byte_count > (addressSizeInBytes + 1)){
				if (itr_pos > addressSizeInBytes && (itr_pos < ((uint8_t)lineData.size()-1))){
					rec.data.push_back(*itr);
					sum += *itr;
				}
				else{
					rec.checksum = *itr;
				}

			}
			else{
				rec.checksum = *itr;
			}
		}

		itr = itr+1;
	}

	sum = 0xFF - sum;

	if (sum != rec.checksum){
		LOG_MOD(ERROR, logmod) << "ParseSREData(): Checksum Not Matching!";
		mErrorInParsing = true;
		return rec;
	}

	return rec;

}

uint8_t FileHandler::GetAddressSizeInBytes(std::string record_type)
{
	uint8_t rtnValue;

	//16-bit Address
	if ((record_type == "S0") || (record_type == "S1") || (record_type == "S5") || (record_type == "S9")){
		rtnValue = 2;
	}
	//24-bit Address
	else if ((record_type == "S2") || (record_type == "S6") || (record_type == "S8")){
		rtnValue = 3;
	}
	//32-bit Address
	else if ((record_type == "S3") || (record_type == "S7")){
		rtnValue = 4;
	}
	else{
		rtnValue = 0;	//"S4" type
	}
	return rtnValue;
}

void FileHandler::WriteDataBuffer(FileType type, Record rec){
	if (mFlashDataMap.find(type) != mFlashDataMap.end())
	{
		mFlashDataMap.at(type).push_back(rec);
	}
	else{
		mFlashDataMap.insert(std::pair<FileType ,std::vector<Record>>(type, {rec}));
	}
}

void FileHandler::ClearDataBuffer(FileType type){
	if (mFlashDataMap.find(type) != mFlashDataMap.end())
	{
		mFlashDataMap.erase(type);
	}
}

void FileHandler::SetUpdateAvailableFlag(FileType type){
	switch (type){

		case FileType::opFile:
			mOPUpdateAvailable = true;
			break;

		case FileType::confFile:
			mConfUpdateAvailable = true;
			break;

		case FileType::ppFile:
			mPPUpdateAvailable = true;
			break;

		default:
			break;

	}
}

void FileHandler::EmitUpdateAvailableSignal(){
	if ( (nullptr != mEventsManagerPtr) ){

		if ( (mOPUpdateAvailable == true) && (mConfUpdateAvailable == true) &&(mPPUpdateAvailable == true) ){

			LOG_MOD(NOTICE, logmod) << "All three Updates Available";
			mReadyToFlash = true;
			mEventsManagerPtr->EmitSignal("UpdateAvailable");
		}
		else if ( mOPUpdateAvailable != true ){
			if ( mConfUpdateAvailable == true ){

				LOG_MOD(NOTICE, logmod) << "Configuration Update Available";
				mReadyToFlash = true;
				mEventsManagerPtr->EmitSignal("ConfUpdateAvailable");
			}
			if ( mPPUpdateAvailable == true ){

				LOG_MOD(NOTICE, logmod) << "PP Update Available";
				mReadyToFlash = true;
				mEventsManagerPtr->EmitSignal("PPUpdateAvailable");
			}
		}
	}
	else{
		LOG_MOD(ERROR, logmod) << "Events Manager Not Available. Can't Emit Update Signal";
	}

}

std::vector<uint8_t> FileHandler::ConvertStringToByteVector(std::string strToConvert){
	std::vector<uint8_t> rtnValue;
	uint16_t i = 0;
	std::string::size_type sz = 0;

	//If string is terminated with CR, remove it so it doesn't throw STOI exception
	if (*(strToConvert.end()-1) == '\r')
		strToConvert.pop_back();

	while (i < (strToConvert.size())){
		try{
			rtnValue.push_back( (uint8_t)std::stoi(strToConvert.substr(i, 2), &sz, 16) );

			//If Odd number element is not a valid character, throw error
			if (sz < strToConvert.substr(i, 2).size()){
				throw -1;
			}
		}
		catch(...) {
			LOG_MOD(ERROR, logmod) << "ConvertStringToByteVector(): Invalid Character";
			rtnValue.clear();
			break;
		}

		i+= 2;
	}
	return rtnValue;
}


boostfs::path FileHandler::FindZipFile(const std::string& dir)
{
	boostfs::path rtnValue;
	rtnValue.clear();

	if (IsDirExists(dir))
	{
        const boostfs::directory_iterator end_itr;
        const auto found_zip = std::find_if(boostfs::directory_iterator(dir), end_itr,
                                [](const boostfs::directory_entry& e) {
                                return e.path().extension().string() == ".zip";
                              });

        if (found_zip == end_itr)
		{
			LOG_MOD(NOTICE, logmod)<<  "No Zip file found in the directory";
		}
        else
		{
			rtnValue = found_zip->path();
		}
	}
	else{
		LOG_MOD(NOTICE, logmod)<< "Directory " << dir << " does not exist.";
	}

	return rtnValue;
}

bool FileHandler::IsDirExists(const std::string& dir)
{
	boostfs::path dirName{dir};
	return (boostfs::exists(dirName) && boostfs::is_directory(dirName));
}

bool FileHandler::ExtractZipFile(const std::string& zip_path, const std::string& dest)
{
	if (!IsDirExists(dest)){
		if (!boostfs::create_directories(dest)){
			LOG_MOD(ERROR, logmod)<< "ExtractZipFile::Cannot create Destination Directory.";
			return false;
		}
	}

    std::string unzipcmd = "unzip -q -o " + zip_path + " -d " + dest;
    int status = system(unzipcmd.c_str());
    if (status < 0)
        {
            LOG_MOD(ERROR, logmod)<< "Error in execution of Unzip system command " << status;
            return false;
        }
    else
        {
            if (WIFEXITED(status))
            {
                LOG_MOD(WARNING, logmod)<<  "File Unzip Successful. Exit code : " << WEXITSTATUS(status);
                return true;
            }
            else
            {
                LOG_MOD(ERROR, logmod)<<  "Unzip command exited abnormaly";
                return false;
            }
        }
}

void FileHandler::FindSREFiles(const std::string& dir){
	if (IsDirExists(dir))
	{
        const boostfs::directory_iterator end_itr;
        int countSRE = 0;

		(void)std::copy_if(boostfs::directory_iterator(dir), end_itr,
						mListOfSREFiles.begin(),
						[&countSRE](const boostfs::directory_entry& e){
							if ((e.path().extension().string() == ".sre")){

								if (countSRE < MAX_SRE){
									countSRE++;
									return true;
								}
								else{
									LOG_MOD(ERROR, logmod)<<  "More than " << MAX_SRE << " SRE files found";
									return false;
								}
							}
							else{
								return false;
							}
						});

		mListOfSREFiles.resize(countSRE);
	}
}

FileType FileHandler::GetSREFileType(const std::string& filePath){

	std::ifstream ifs(filePath, std::ifstream::in);
	std::string line;
	line.clear();

	if (!ifs)	return FileType::invalidFile;	//If Error in opening file, skip it

	while (std::getline(ifs, line)){

		mErrorInParsing = false;
		Record rec = ParseSREData(line);

		if (mErrorInParsing == true){
			break;
		}
		else if (mErrorInParsing == false && rec.address.empty() && rec.data.empty() ){
			continue;
		}
		else{
			if (rec.record_type == "S2"){

				switch (rec.address[0]){

					case PP_START_ADDR_MSB:
						LOG_MOD(NOTICE, logmod)<<  filePath << " is PP Data. ";
						return FileType::ppFile;

					case CONF_START_ADDR_MSB:
						LOG_MOD(NOTICE, logmod)<<  filePath << " is Conf Data. ";
						return FileType::confFile;

					case OP_START_ADDR_MSB:
						LOG_MOD(NOTICE, logmod)<<  filePath << " is OP Data. ";
						return FileType::opFile;

					default:
						break;
				}
			}
		}

		line.clear();
	}

	return FileType::invalidFile;
}


bool FileHandler::isReadyToFlash(){
	return mReadyToFlash;
}

const std::vector<Record>& FileHandler::getOPFlashingData(){
	mEmptyData.clear();

	if ( (mReadyToFlash == true) && (mFlashDataMap.find(FileType::opFile) != mFlashDataMap.end()) )
	{
		return mFlashDataMap.at(FileType::opFile);
	}

	return mEmptyData;
}

const std::vector<Record>& FileHandler::getConfFlashingData(){
	mEmptyData.clear();

	if ( (mReadyToFlash == true) && (mFlashDataMap.find(FileType::confFile) != mFlashDataMap.end()) )
	{
		return mFlashDataMap.at(FileType::confFile);
	}

	return mEmptyData;
}

const std::vector<Record>& FileHandler::getPPFlashingData(){
	mEmptyData.clear();

	if ( (mReadyToFlash == true) && (mFlashDataMap.find(FileType::ppFile) != mFlashDataMap.end()) )
	{
		return mFlashDataMap.at(FileType::ppFile);
	}

	return mEmptyData;
}
