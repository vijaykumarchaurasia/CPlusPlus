/*
 * Flasher.cpp
 *
 *  Created on: Dec 1, 2021
 *      Author: U01B759
 */

#include <ecu/logging.h>
#include "Flasher.h"
#include "AppManager.h"
#include "EventsManagerModel.h"
#include "FileHandler.h"
#include <thread>

using namespace ecu::lapi::rt;

namespace
{
    auto logmod = ecu::lapi::logging::module("BCMOTA.Flasher");
}

Flasher::Flasher(AppManager* passed):
mAppMangerPtr(passed),
mFileHandlerPtr(passed->GetFileHandlerModel()),
mEventsManagerModel(passed->GetEventsManagerModel())
{
    LOG_MOD(NOTICE, logmod)<<"Creation: Flasher";
	mEventsManagerModel->ConnectToSignal("UpdateAvailable",boost::bind(&Flasher::OpSreCallback,this));
	mEventsManagerModel->ConnectToSignal("UpdateAvailable",boost::bind(&Flasher::ConfigSreCallback,this));
	mEventsManagerModel->ConnectToSignal("UpdateAvailable",boost::bind(&Flasher::PpSreCallback,this));

	mEventsManagerModel->ConnectToSignal("ConfUpdateAvailable",boost::bind(&Flasher::ConfigSreCallback,this));
	mEventsManagerModel->ConnectToSignal("PPUpdateAvailable",boost::bind(&Flasher::PpSreCallback,this));
	mEventsManagerModel->ConnectToSignal("PPUpdateAvailable",boost::bind(&Flasher::PpSreCallback,this));
	mEventsManagerModel->ConnectToSignal("StartFlashing",boost::bind(&Flasher::RunStateMachine,this));
	Init();
}

Flasher::~Flasher()
{
    LOG_MOD(NOTICE, logmod)<<"Destruction: Flasher";
}

void Flasher::Init()
{
    LOG_MOD(NOTICE, logmod)<<"Init()...";
	state_ = stateModuleIdDataRequest_SC;
	next_heartbeat_time_ = std::chrono::steady_clock::now() + heartbeat_period_ms_;
	id_obtained_ = false;
	number_of_config_request_count_ = 0;
	number_of_programmming_retries_= 0;

	mCanPtr = std::make_shared<Can>(mAppMangerPtr);

	flash_index_ = 0;

	ClearCanMessage(send_);
	ClearCanMessage(response_);
	accept_data_.clear();
}


void Flasher::OpSreCallback()
{
    LOG_MOD(NOTICE, logmod)<<"OpSreCallback()...";
	srec_ = mFileHandlerPtr->getOPFlashingData();
}

void Flasher::ConfigSreCallback()
{
    LOG_MOD(NOTICE, logmod)<<"ConfigSreCallback()...";
	config_ = mFileHandlerPtr->getConfFlashingData();
}

void Flasher::PpSreCallback()
{
    LOG_MOD(NOTICE, logmod)<<"PpSreCallback()....";
	pp_ = mFileHandlerPtr->getPPFlashingData();
}

//TODO: Skip this if no files.
void Flasher::RunStateMachine()
{
    LOG_MOD(NOTICE, logmod)<<"RunStateMachine()...";
	switch(state_)
	{
		case stateModuleIdDataRequest_SC:
			state_= ModuleIdDataRequest();
			break;

		case stateEnterConfigurationLoadMode_SC:
			state_= EnterConfigurationLoadModeCommand();
			break;

		case stateEraseOperatingProgram_SC:
			state_=  EraseOperatingProgramCommand();
			break;

		case statesEraseConfiguration_SC:
			state_ = EraseConfigurationCommand();
			break;

		case statesEraseProgrammableParameters_SC:
			state_ = EraseProgrammableParametersCommand();
			break;

		case stateReadOperatingProgram_SC:
			state_ = ReadOperatingProgram();
			break;

		case stateReadConfiguration_SC:
			state_ = ReadConfiguration();
			break;

		case stateReadProgrammableParameters_SC:
			state_= ReadProgrammableParameters();
			break;

		case stateFlashData_SC:
			state_ = FlashData();
			break;

		case stateSoftwareReset_SC:
			break;

		case stateFlashSessionCompleted_SC:
			break;

		case stateFlashSessionRetry_SC:
			state_ = FlashSessionRetry();
			break;

		case stateFlashSessionFailed_SC:
			break;

		default:
			//do nothing;
			break;
	}
	SendServiceHeartBeat();
}

States Flasher::FlashSessionRetry()
{
    LOG_MOD(NOTICE, logmod)<<"FlashSessionRetry()...";
	if(number_of_programmming_retries_< maxNumberOfProgrammmingRetries_SC)
	{
		id_obtained_ = false;
		number_of_config_request_count_ = 0;

		flash_index_ = 0;

		ClearCanMessage(send_);
		ClearCanMessage(response_);
		accept_data_.clear();
		number_of_programmming_retries_++;
		return stateModuleIdDataRequest_SC;
	}
	else
	{
		return stateFlashSessionFailed_SC;
	}
}

//                            0  1  2  3  4  5  6  7
//	CFF22F9x        Rx   d 8 0A 01 FF FF FF FF FF FF
//	18FFF921x       Rx   d 8 0A 01 78 56 34 12 00 00
//	CFF22F9x        Rx   d 8 02 78 56 34 12 FF FF FF
States Flasher::ModuleIdDataRequest()
{
    LOG_MOD(NOTICE, logmod)<<"ModuleIdDataRequest()...";
	send_ = idRequestMsg_SC;
	mCanPtr->SendandGetCanMessage(send_,response_);

	if( !id_obtained_  && response_.byte_0 == 0x0A && response_.byte_1 == 0x01)
	{
		config_load_command_.byte_0  = 0x02;
	    config_load_command_.byte_1 = response_.byte_2;
	    config_load_command_.byte_2 = response_.byte_3;
	    config_load_command_.byte_3 = response_.byte_4;
	    config_load_command_.byte_4 = response_.byte_5;
	    config_load_command_.byte_5 = 0xFF;
	    config_load_command_.byte_6 = 0xFF;
	    config_load_command_.byte_7 = 0xFF;

	    id_wait_time_ = std::chrono::steady_clock::now() + id_period_ms_;
	    id_obtained_ = true;
	}

	if(id_obtained_)
	{
		//* floating point duration, no cast needed */
		std::chrono::duration<double, std::milli> elapsed_time_ms = std::chrono::steady_clock::now() - id_wait_time_;

		//* Calculate if wait time surpassed	*/
		if(elapsed_time_ms.count() >= 0)
		{
			return stateEnterConfigurationLoadMode_SC;
		}
		else
		{
			return stateModuleIdDataRequest_SC;
		}
	}
	else
	{
		return stateFlashSessionRetry_SC;
	}
}

//CFF22F9x        Rx   d 8 02 78 56 34 12 FF FF FF
//18FFF921x       Rx   d 8 02 78 56 34 12 FF FF 00
States Flasher::EnterConfigurationLoadModeCommand()
{
    LOG_MOD(NOTICE, logmod)<<"EnterConfigurationLoadModeCommand()...";
	mCanPtr->SendandGetCanMessage(config_load_command_, response_);
	if( response_.byte_0 == 0x02
			&& response_.byte_1 == config_load_command_.byte_1
			&& response_.byte_2 == config_load_command_.byte_2
			&& response_.byte_3 == config_load_command_.byte_3
			&& response_.byte_4 == config_load_command_.byte_4
			&& response_.byte_5 == 0xFF
			&& response_.byte_6 == 0xFF
			&& response_.byte_7 == 0x00)
	{
		number_of_config_request_count_++;
	}
	else
	{
		return stateFlashSessionRetry_SC;
	}

	if(number_of_config_request_count_ < number_of_config_request_min)
	{
		return stateEnterConfigurationLoadMode_SC;
	}
	else
	{
		return stateEraseOperatingProgram_SC;
	}
}

//	CFF22F9x        Rx   d 8 03 FF FF FF FF FF FF FF
//	18FFF921x       Rx   d 8 03 00 00 00 00 00 F8 FB
States Flasher::EraseOperatingProgramCommand()
{
    LOG_MOD(NOTICE, logmod)<<"EraseOperatingProgramCommand()...";
	if (srec_.size() > 0)
	{
		send_ = eraseOperatingProgramMsg_SC;
		mCanPtr->SendandGetCanMessage(send_, response_);
		if( response_.byte_0 == 0x03)
		{
			return statesEraseConfiguration_SC;
		}
		else
		{
			return stateFlashSessionRetry_SC;
		}
	}
	else
	{
		return statesEraseConfiguration_SC;
	}
}

//CFF22F9x        Rx   d 8 04 FF FF FF FF FF FF FF
//18FFF921x       Rx   d 8 04 00 00 00 00 00 F5 F7
States Flasher::EraseConfigurationCommand()
{
    LOG_MOD(NOTICE, logmod)<<"EraseConfigurationCommand()...";
	if (config_.size() > 0)
	{
		send_ = eraseConfigurationMsg_SC;
		mCanPtr->SendandGetCanMessage(send_, response_);
		if( response_.byte_0 == 0x04)
		{
			return statesEraseProgrammableParameters_SC;
		}
		else
		{
			return stateFlashSessionRetry_SC;
		}
	}
	else
	{
		return statesEraseProgrammableParameters_SC;
	}
}

//CFF22F9x        Rx   d 8 05 FF FF FF FF FF FF FF
//18FFF921x       Rx   d 8 05 00 00 00 00 00 F3 F4
States Flasher::EraseProgrammableParametersCommand()
{
    LOG_MOD(NOTICE, logmod)<<"EraseProgrammableParametersCommand()...";
	if (pp_.size() > 0)
	{
		send_ = eraseProgrammableParametersMsg_SC;
		mCanPtr->SendandGetCanMessage(send_, response_);
		if( response_.byte_0 == 0x05)
		{
			return stateReadOperatingProgram_SC;
		}
		else
		{
			return stateFlashSessionRetry_SC;
		}
	}
	else
	{
		return stateReadOperatingProgram_SC;
	}

}

//CFF22F9x        Rx   d 8 01 78 56 34 12 FF FF FF
//Format 5 unsuccessful response
States Flasher::SoftwareResetCommand()
{
    LOG_MOD(NOTICE, logmod)<<"SoftwareResetCommand()...";
	send_.byte_0 = 0x01;
	send_.byte_1 = config_load_command_.byte_1;
	send_.byte_2 = config_load_command_.byte_2;
	send_.byte_3 = config_load_command_.byte_3;
	send_.byte_4 = config_load_command_.byte_4;
	send_.byte_5 = 0xFF;
	send_.byte_6 = 0xFF;
	send_.byte_7 = 0xFF;

	mCanPtr->SendandGetCanMessage(send_, response_);
	if( response_.byte_0 == 0xFF) //
	{
		return stateFlashSessionRetry_SC;
	}
	else
	{
		return stateFlashSessionCompleted_SC;
	}
}

States Flasher::ReadOperatingProgram()
{
    LOG_MOD(NOTICE, logmod)<<"ReadOperatingProgram()...";
	//getFlashingData(std::vector<Record>&srec_);
	//TODO:: add checks, range checks for elements

//						 	  0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15
//0			S2	14	 080000	 18 21 06 B0 D9 31 7C 7B 8A A6 D4 31 7C 7C 8A A6 	96
//1			S2140800107C7C8BA6D8017000E00B7014C644008365
//2			S214080020D2317C6102A6D53100A3D6317C60002689
//3			S214080030D731DA41DB51DC61DD71550100385521D5

	uint i=0;
	while(i < srec_.size())
	{
		if((srec_[i].record_type.compare("S2")==0) &&
				(!(srec_[i].data[0] == 0xFF
				&&srec_[i].data[1] == 0xFF
				&&srec_[i].data[2] == 0xFF
				&&srec_[i].data[3] == 0xFF
				&&srec_[i].data[4] == 0xFF
				&&srec_[i].data[5] == 0xFF
				&&srec_[i].data[6] == 0xFF
				&&srec_[i].data[7] == 0xFF
				&&srec_[i].data[8] == 0xFF
				&&srec_[i].data[9] == 0xFF
				&&srec_[i].data[10] == 0xFF
				&&srec_[i].data[11] == 0xFF
				&&srec_[i].data[12] == 0xFF
				&&srec_[i].data[13] == 0xFF
				&&srec_[i].data[14] == 0xFF
				&&srec_[i].data[15] == 0xFF)) )
		{
			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x01;
			 send_.byte_2  = srec_[i].address[2];
			 send_.byte_3  = srec_[i].address[1];
			 send_.byte_4  = srec_[i].address[0];
			 send_.byte_5  = 0x00;
			 send_.byte_6  = srec_[i].data[0];
			 send_.byte_7  = srec_[i].data[1];
			 accept_data_.push_back(send_); //CFF22F9x        Rx   d 8 06 01 00 00 08 00 18 21

			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x02;
			 send_.byte_2  = srec_[i].data[2];
			 send_.byte_3  = srec_[i].data[3];
			 send_.byte_4  = srec_[i].data[4];
			 send_.byte_5  = srec_[i].data[5];
			 send_.byte_6  = srec_[i].data[6];
			 send_.byte_7  = srec_[i].data[7];
			 accept_data_.push_back(send_); //CFF22F9x        Rx   d 8 06 02 06 B0 D9 31 7C 7B

			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x03;
			 send_.byte_2  = srec_[i].data[8];
			 send_.byte_3  = srec_[i].data[9];
			 send_.byte_4  = srec_[i].data[10];
			 send_.byte_5  = srec_[i].data[11];
			 send_.byte_6  = srec_[i].data[12];
			 send_.byte_7  = srec_[i].data[13];
			 accept_data_.push_back(send_);//CFF22F9x        Rx   d 8 06 03 8A A6 D4 31 7C 7C

			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x04;
			 send_.byte_2  = srec_[i].data[14];
			 send_.byte_3  = srec_[i].data[15];
			 send_.byte_4  = srec_[i+1].data[0];
			 send_.byte_5  = srec_[i+1].data[1];
			 send_.byte_6  = srec_[i+1].data[2];
			 send_.byte_7  = srec_[i+1].data[3];
			 accept_data_.push_back(send_);//CFF22F9x        Rx   d 8 06 04 8A A6 7C 7C 8B A6

			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x05;
			 send_.byte_2  = srec_[i+1].data[4];
			 send_.byte_3  = srec_[i+1].data[5];
			 send_.byte_4  = srec_[i+1].data[6];
			 send_.byte_5  = srec_[i+1].data[7];
			 send_.byte_6  = srec_[i+1].data[8];
			 send_.byte_7  = srec_[i+1].data[9];
			 accept_data_.push_back(send_);//CFF22F9x        Rx   d 8 06 05 D8 01 70 00 E0 0B

			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x06;
			 send_.byte_2  = srec_[i+1].data[10];
			 send_.byte_3  = srec_[i+1].data[11];
			 send_.byte_4  = srec_[i+1].data[12];
			 send_.byte_5  = srec_[i+1].data[13];
			 send_.byte_6  = srec_[i+1].data[14];
			 send_.byte_7  = srec_[i+1].data[15];
			 accept_data_.push_back(send_);//CFF22F9x        Rx   d 8 06 06 70 14 C6 44 00 83

			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x07;
			 send_.byte_2  = srec_[i+2].data[0];
			 send_.byte_3  = srec_[i+2].data[1];
			 send_.byte_4  = srec_[i+2].data[2];
			 send_.byte_5  = srec_[i+2].data[3];
			 send_.byte_6  = srec_[i+2].data[4];
			 send_.byte_7  = srec_[i+2].data[5];
			 accept_data_.push_back(send_);//CFF22F9x        Rx   d 8 06 07 D2 31 7C 61 02 A6

			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x08;
			 send_.byte_2  = srec_[i+2].data[6];
			 send_.byte_3  = srec_[i+2].data[7];
			 send_.byte_4  = srec_[i+2].data[8];
			 send_.byte_5  = srec_[i+2].data[9];
			 send_.byte_6  = srec_[i+2].data[10];
			 send_.byte_7  = srec_[i+2].data[11];
			 accept_data_.push_back(send_);//CFF22F9x        Rx   d 8 06 08 D5 31 00 A3 D6 31

			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x09;
			 send_.byte_2  = srec_[i+2].data[12];
			 send_.byte_3  = srec_[i+2].data[13];
			 send_.byte_4  = srec_[i+2].data[14];
			 send_.byte_5  = srec_[i+2].data[15];
			 send_.byte_6  = srec_[i+3].data[0];
			 send_.byte_7  = srec_[i+3].data[1];
			 accept_data_.push_back(send_);//CFF22F9x        Rx   d 8 06 09 7C 60 00 26 D7 31

			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x0A;
			 send_.byte_2  = srec_[i+3].data[2];
			 send_.byte_3  = srec_[i+3].data[3];
			 send_.byte_4  = srec_[i+3].data[4];
			 send_.byte_5  = srec_[i+3].data[5];
			 send_.byte_6  = srec_[i+3].data[6];
			 send_.byte_7  = srec_[i+3].data[7];
			 accept_data_.push_back(send_);//CFF22F9x        Rx   d 8 06 0A DA 41 DB 51 DC 61

			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x0B;
			 send_.byte_2  = srec_[i+3].data[8];
			 send_.byte_3  = srec_[i+3].data[9];
			 send_.byte_4  = srec_[i+3].data[10];
			 send_.byte_5  = srec_[i+3].data[11];
			 send_.byte_6  = srec_[i+3].data[12];
			 send_.byte_7  = srec_[i+3].data[13];
			 accept_data_.push_back(send_);//CFF22F9x        Rx   d 8 06 0B DD 71 55 01 00 38

			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x0C;
			 send_.byte_2  = srec_[i+3].data[14];
			 send_.byte_3  = srec_[i+3].data[15];
			 send_.byte_4  = 0xFF;
			 send_.byte_5  = 0xFF;
			 send_.byte_6  = 0xFF;
			 send_.byte_7  = 0xFF;
			 accept_data_.push_back(send_);//CFF22F9x        Rx   d 8 06 0C 55 21 FF FF FF FF

			 accept_data_.push_back(programDataMsg_SC);
			 i=i+4;
		}
		else
		{
			i++;
		}
	}
	return stateReadConfiguration_SC;
}

States Flasher::ReadConfiguration()
{
    LOG_MOD(NOTICE, logmod)<<"ReadConfiguration()...";
	//TODO:: add checks, range checks for elements
	uint i=0;
	while(i < config_.size())
	{
		//          0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32
		//02 00 00 A5 A5 00 00 DE 00 00 01 02 D9 FF 30 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 A6
		//02 00 20 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 B9

		if((config_[i].record_type.compare("S2")==0))
		{

			// 06 01 00 00 02 00 A5 A5
			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x01;
			 send_.byte_2  = config_[i].address[2];
			 send_.byte_3  = config_[i].address[1];
			 send_.byte_4  = config_[i].address[0];
			 send_.byte_5  = 0x00;
			 send_.byte_6  = config_[i].data[0];
			 send_.byte_7  = config_[i].data[1];
			 accept_data_.push_back(send_);

			 //	06 02 00 00 DE 00 00 01
			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x02;
			 send_.byte_2  = config_[i].data[2];
			 send_.byte_3  = config_[i].data[3];
			 send_.byte_4  = config_[i].data[4];
			 send_.byte_5  = config_[i].data[5];
			 send_.byte_6  = config_[i].data[6];
			 send_.byte_7  = config_[i].data[7];
			 accept_data_.push_back(send_);

			 //	06 03 02 D9 FF 30 00 00
			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x03;
			 send_.byte_2  = config_[i].data[8];
			 send_.byte_3  = config_[i].data[9];
			 send_.byte_4  = config_[i].data[10];
			 send_.byte_5  = config_[i].data[11];
			 send_.byte_6  = config_[i].data[12];
			 send_.byte_7  = config_[i].data[13];
			 accept_data_.push_back(send_);

			 //	06 04 00 00 00 00 00 00
			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x04;
			 send_.byte_2  = config_[i].data[14];
			 send_.byte_3  = config_[i].data[15];
			 send_.byte_4  = config_[i].data[16];
			 send_.byte_5  = config_[i].data[17];
			 send_.byte_6  = config_[i].data[18];
			 send_.byte_7  = config_[i].data[19];
			 accept_data_.push_back(send_);

			 //	06 05 00 00 00 00 00 00
			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x05;
			 send_.byte_2  = config_[i].data[20];
			 send_.byte_3  = config_[i].data[21];
			 send_.byte_4  = config_[i].data[22];
			 send_.byte_5  = config_[i].data[23];
			 send_.byte_6  = config_[i].data[24];
			 send_.byte_7  = config_[i].data[25];
			 accept_data_.push_back(send_);

			 //	06 06 00 00 00 00 00 00
			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x06;
			 send_.byte_2  = config_[i].data[26];
			 send_.byte_3  = config_[i].data[27];
			 send_.byte_4  = config_[i].data[28];
			 send_.byte_5  = config_[i].data[29];
			 send_.byte_6  = config_[i].data[30];
			 send_.byte_7  = config_[i].data[31];
			 accept_data_.push_back(send_);


			 //	06 07 00 00 00 00 00 00
			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x07;
			 send_.byte_2  = config_[i+1].data[0];
			 send_.byte_3  = config_[i+1].data[1];
			 send_.byte_4  = config_[i+1].data[2];
			 send_.byte_5  = config_[i+1].data[3];
			 send_.byte_6  = config_[i+1].data[4];
			 send_.byte_7  = config_[i+1].data[5];
			 accept_data_.push_back(send_);

			 //	06 08 00 00 00 00 00 00
			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x08;
			 send_.byte_2  = config_[i+1].data[6];
			 send_.byte_3  = config_[i+1].data[7];
			 send_.byte_4  = config_[i+1].data[8];
			 send_.byte_5  = config_[i+1].data[9];
			 send_.byte_6  = config_[i+1].data[10];
			 send_.byte_7  = config_[i+1].data[11];
			 accept_data_.push_back(send_);

			 //	06 09 00 00 00 00 00 00
			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x09;
			 send_.byte_2  = config_[i+1].data[12];
			 send_.byte_3  = config_[i+1].data[13];
			 send_.byte_4  = config_[i+1].data[14];
			 send_.byte_5  = config_[i+1].data[15];
			 send_.byte_6  = config_[i+1].data[16];
			 send_.byte_7  = config_[i+1].data[17];
			 accept_data_.push_back(send_);

			 //	06 0A 00 00 00 00 00 00
			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x0A;
			 send_.byte_2  = config_[i+1].data[18];
			 send_.byte_3  = config_[i+1].data[19];
			 send_.byte_4  = config_[i+1].data[20];
			 send_.byte_5  = config_[i+1].data[21];
			 send_.byte_6  = config_[i+1].data[22];
			 send_.byte_7  = config_[i+1].data[23];
			 accept_data_.push_back(send_);

			 //	06 0B 00 00 00 00 00 00
			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x0B;
			 send_.byte_2  = config_[i+1].data[24];
			 send_.byte_3  = config_[i+1].data[25];
			 send_.byte_4  = config_[i+1].data[26];
			 send_.byte_5  = config_[i+1].data[27];
			 send_.byte_6  = config_[i+1].data[28];
			 send_.byte_7  = config_[i+1].data[29];
			 accept_data_.push_back(send_);

			 //	06 0C 00 00 FF FF FF FF
			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x0C;
			 send_.byte_2  = config_[i+1].data[30];
			 send_.byte_3  = config_[i+1].data[31];
			 send_.byte_4  = 0xFF;
			 send_.byte_5  = 0xFF;
			 send_.byte_6  = 0xFF;
			 send_.byte_7  = 0xFF;
			 accept_data_.push_back(send_);

			 accept_data_.push_back(programDataMsg_SC);
			 i = i + 2;
		}
		else
		{
			i++;
		}

	}
	return stateReadProgrammableParameters_SC;

}

States Flasher::ReadProgrammableParameters()
{
    LOG_MOD(NOTICE, logmod)<<"ReadProgrammableParameters()...";
	//TODO:: add checks, range checks for elements
	uint i=0;
	while(i < pp_.size())
	{
		if((pp_[i].record_type.compare("S2")==0))
		{
			// 0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35
			//01 00 00 A5 A5 00 00 02 80 00 00 00 01 FF 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 0E

			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x01;
			 send_.byte_2  = pp_[i].address[2];
			 send_.byte_3  = pp_[i].address[1];
			 send_.byte_4  = pp_[i].address[0];
			 send_.byte_5  = 0x00;
			 send_.byte_6  = pp_[i].data[0];
			 send_.byte_7  = pp_[i].data[1];
			 accept_data_.push_back(send_);

			 //	06 02 00 00 DE 00 00 01
			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x02;
			 send_.byte_2  = pp_[i].data[2];
			 send_.byte_3  = pp_[i].data[3];
			 send_.byte_4  = pp_[i].data[4];
			 send_.byte_5  = pp_[i].data[5];
			 send_.byte_6  = pp_[i].data[6];
			 send_.byte_7  = pp_[i].data[7];
			 accept_data_.push_back(send_);

			 //	06 03 02 D9 FF 30 00 00
			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x03;
			 send_.byte_2  = pp_[i].data[8];
			 send_.byte_3  = pp_[i].data[9];
			 send_.byte_4  = pp_[i].data[10];
			 send_.byte_5  = pp_[i].data[11];
			 send_.byte_6  = pp_[i].data[12];
			 send_.byte_7  = pp_[i].data[13];
			 accept_data_.push_back(send_);

			 //	06 04 00 00 00 00 00 00
			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x04;
			 send_.byte_2  = pp_[i].data[14];
			 send_.byte_3  = pp_[i].data[15];
			 send_.byte_4  = pp_[i].data[16];
			 send_.byte_5  = pp_[i].data[17];
			 send_.byte_6  = pp_[i].data[18];
			 send_.byte_7  = pp_[i].data[19];
			 accept_data_.push_back(send_);

			 //	06 05 00 00 00 00 00 00
			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x05;
			 send_.byte_2  = pp_[i].data[20];
			 send_.byte_3  = pp_[i].data[21];
			 send_.byte_4  = pp_[i].data[22];
			 send_.byte_5  = pp_[i].data[23];
			 send_.byte_6  = pp_[i].data[24];
			 send_.byte_7  = pp_[i].data[25];
			 accept_data_.push_back(send_);

			 //	06 06 00 00 00 00 00 00
			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x06;
			 send_.byte_2  = pp_[i].data[26];
			 send_.byte_3  = pp_[i].data[27];
			 send_.byte_4  = pp_[i].data[28];
			 send_.byte_5  = pp_[i].data[29];
			 send_.byte_6  = pp_[i].data[30];
			 send_.byte_7  = pp_[i].data[31];
			 accept_data_.push_back(send_);


			 //	06 07 00 00 00 00 00 00
			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x07;
			 send_.byte_2  = pp_[i+1].data[0];
			 send_.byte_3  = pp_[i+1].data[1];
			 send_.byte_4  = pp_[i+1].data[2];
			 send_.byte_5  = pp_[i+1].data[3];
			 send_.byte_6  = pp_[i+1].data[4];
			 send_.byte_7  = pp_[i+1].data[5];
			 accept_data_.push_back(send_);

			 //	06 08 00 00 00 00 00 00
			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x08;
			 send_.byte_2  = pp_[i+1].data[6];
			 send_.byte_3  = pp_[i+1].data[7];
			 send_.byte_4  = pp_[i+1].data[8];
			 send_.byte_5  = pp_[i+1].data[9];
			 send_.byte_6  = pp_[i+1].data[10];
			 send_.byte_7  = pp_[i+1].data[11];
			 accept_data_.push_back(send_);

			 //	06 09 00 00 00 00 00 00
			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x09;
			 send_.byte_2  = pp_[i+1].data[12];
			 send_.byte_3  = pp_[i+1].data[13];
			 send_.byte_4  = pp_[i+1].data[14];
			 send_.byte_5  = pp_[i+1].data[15];
			 send_.byte_6  = pp_[i+1].data[16];
			 send_.byte_7  = pp_[i+1].data[17];
			 accept_data_.push_back(send_);

			 //	06 0A 00 00 00 00 00 00
			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x0A;
			 send_.byte_2  = pp_[i+1].data[18];
			 send_.byte_3  = pp_[i+1].data[19];
			 send_.byte_4  = pp_[i+1].data[20];
			 send_.byte_5  = pp_[i+1].data[21];
			 send_.byte_6  = pp_[i+1].data[22];
			 send_.byte_7  = pp_[i+1].data[23];
			 accept_data_.push_back(send_);

			 //	06 0B 00 00 00 00 00 00
			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x0B;
			 send_.byte_2  = pp_[i+1].data[24];
			 send_.byte_3  = pp_[i+1].data[25];
			 send_.byte_4  = pp_[i+1].data[26];
			 send_.byte_5  = pp_[i+1].data[27];
			 send_.byte_6  = pp_[i+1].data[28];
			 send_.byte_7  = pp_[i+1].data[29];
			 accept_data_.push_back(send_);

			 //	06 0C 00 00 FF FF FF FF
			 send_.byte_0  = 0x06;
			 send_.byte_1  = 0x0C;
			 send_.byte_2  = pp_[i+1].data[30];
			 send_.byte_3  = pp_[i+1].data[31];
			 send_.byte_4  = 0xFF;
			 send_.byte_5  = 0xFF;
			 send_.byte_6  = 0xFF;
			 send_.byte_7  = 0xFF;
			 accept_data_.push_back(send_);

			 accept_data_.push_back(programDataMsg_SC);
			 i = i + 2;
		}
		else
		{
			i++;
		}

	}
	return stateFlashData_SC;
}

States Flasher::FlashData()
{
    LOG_MOD(NOTICE, logmod)<<"FlashData()...";
	if(flash_index_<accept_data_.size())
	{
		send_ = accept_data_[flash_index_];
		mCanPtr->SendandGetCanMessage(send_, response_);
		if(accept_data_[flash_index_].byte_0 == 0x07)
		{
			if(response_.byte_0 == 0x07
				&& response_.byte_1 == 0x00
				&& response_.byte_2 == 0x00
				&& response_.byte_3 == 0x00
				&& response_.byte_4 == 0x00
				&& response_.byte_5 == 0x00
				&& response_.byte_6 == 0x00
				&& response_.byte_7 == 0x00)
			{
				//proceed
				flash_index_++;
				return stateFlashData_SC;
			}
			else
			{
				//error
				return stateFlashSessionRetry_SC;
			}
		}
		else
		{
			if(accept_data_[flash_index_].byte_0 == response_.byte_0
				&& accept_data_[flash_index_].byte_1 == response_.byte_1
				&& accept_data_[flash_index_].byte_2 == response_.byte_2
				&& accept_data_[flash_index_].byte_3 == response_.byte_3
				&& accept_data_[flash_index_].byte_4 == response_.byte_4
				&& accept_data_[flash_index_].byte_5 == response_.byte_5
				&& accept_data_[flash_index_].byte_6 == response_.byte_6
				&& accept_data_[flash_index_].byte_7 == response_.byte_7)
			{
				//proceed
				flash_index_++;
				return stateFlashData_SC;
			}
			else
			{
				//error
				return stateFlashSessionRetry_SC;
			}
		}

	}
	else
	{
		return stateSoftwareReset_SC;
	}

}

//CanMessage this_program_data_msg = programDataMsg_SC;
//mCanPtr->SendandGetCanMessage(this_program_data_msg,response_);
//
//if( response_.byte_0 == 0x05
//	&& response_.byte_1 == 0x00
//	&& response_.byte_2 == 0x00
//	&& response_.byte_3 == 0x00
//	&& response_.byte_4 == 0x00
//	&& response_.byte_5 == 0x00)
//{
//	//do something
//}


void Flasher::SendServiceHeartBeat()
{
    LOG_MOD(NOTICE, logmod)<<"SendServiceHeartBeat()...";
	//* floating point duration, no cast needed */
	std::chrono::duration<double, std::milli> elapsed_time_ms = std::chrono::steady_clock::now() - next_heartbeat_time_;

	//* Calculate the next heartbeat update time	*/
	if(elapsed_time_ms.count() >= 0)
	{
		next_heartbeat_time_ = std::chrono::steady_clock::now() + heartbeat_period_ms_;
//		ClearCanMessage(send_);
//		ClearCanMessage(response_);
		send_ = heartbeatMsg_SC;
		mCanPtr->SendandGetCanMessage(send_, response_);
	}
}


void Flasher::ClearCanMessage(CanMessage& this_message)
{
    LOG_MOD(NOTICE, logmod)<<"ClearCanMessage()...";
	this_message.byte_0 = 0xFF;
	this_message.byte_1 = 0xFF;
	this_message.byte_2 = 0xFF;
	this_message.byte_3 = 0xFF;
	this_message.byte_4 = 0xFF;
	this_message.byte_5 = 0xFF;
	this_message.byte_6 = 0xFF;
	this_message.byte_7 = 0xFF;
}
