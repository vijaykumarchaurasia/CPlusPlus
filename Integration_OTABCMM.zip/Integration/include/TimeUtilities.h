/*
 * TimeUtilities.cpp
 *
 *
 * Author: Mo Chabuk
 */

# pragma once
#include <functional>
#include <thread>
#include <mutex>
#include <string>
#include <iostream>
#include <map>
#include <algorithm>


using hr          = std::chrono::hours        ;
using mn          = std::chrono::minutes      ;
using sec         = std::chrono::seconds      ;
using ms          = std::chrono::milliseconds ;
using us          = std::chrono::microseconds ;
using ns          = std::chrono::nanoseconds  ;
using  ClockTime  = std::chrono::time_point<std::chrono::system_clock>;
using TickId      = unsigned long int;
using TickIdPtr   = uintptr_t;
inline ClockTime TimeNow() noexcept{ return std::chrono::high_resolution_clock::now();}
inline void      PauseThread(ms duration) {std::this_thread::sleep_for(duration);}
enum class Redundancy:short int {DoOnce, Infinite};
enum class DateTime:short int {TxtDate, TxtTime};
//________________________________________________________________________________________

class TimeUtilities final
{
    public:
        TimeUtilities()                             noexcept;
        TimeUtilities(const TimeUtilities&)                 = delete;
        TimeUtilities(TimeUtilities&&)                      = delete;
        TimeUtilities & operator    =(const TimeUtilities&) = delete;
        virtual ~TimeUtilities();
        void PrintTime();
        void PrintDuration()                  noexcept;
        ms GetDuration()                      noexcept;
        const std::string GetTimeDate()       noexcept;
        const std::string GetTimeDate(DateTime);
        void init()                           noexcept;
        void ReleaseTick(TickId);
        std::map<TickId, TickIdPtr>* GetFunctionMap();
    private:
        bool IsActiveCall(TickIdPtr);
        std::map<TickId, TickIdPtr> mFuncRef;
        ClockTime                   mStartedAt;
        unsigned long long int      mDuration;
        std::mutex                  mMutex;
        static unsigned long int    mThreadID;
    public:
        template <class className, class Object, class... Args>TickId
        Tick(ms duration,Redundancy redundancy, className&& functionName, Object&& object, Args&&... args)
        {
            TickId Int = ++mThreadID;
            std::function<void()> x(std::bind(std::forward<className>(functionName), std::forward<Object>(object), std::forward<Args>(args)...));
            std::thread([this,Int, x,redundancy,duration]()
                {
                    TickIdPtr Ext = reinterpret_cast<TickIdPtr>(&x);
                    {
                        const std::lock_guard<std::mutex> lock(mMutex);
                        this->mFuncRef.insert({Int,Ext});
                    }
                    if(redundancy == Redundancy::Infinite)
                        {
                            for(;;)
                                {
                                    PauseThread(duration);
                                    if(this && IsActiveCall(Ext))
                                        { x();}
                                    else
                                        {break;}
                                }
                        }
                    else if(redundancy == Redundancy::DoOnce)
                        {
                            PauseThread(duration);
                            if(IsActiveCall(Ext))
                                { x();}
                        }
                }
                        ).detach();
            return Int;
        }
};
