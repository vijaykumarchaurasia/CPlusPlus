
//Create after Client manager model
//once the SW version is obtained , call the CloudComLib and send the software version


#include <ecu/com/messageadapter.h>
#include <ecu/com/observer.h>
#include <ecu/com/client.h>
#include <ecu/pb/ecu.pb.h>
#include "AppManager.h"
#include "CallBackHelper.h"
#include "FileHandler.h"


using namespace ecu::lapi;
using namespace ecu::lapi::com;

class AppManager;

class SwVer:public ISubscriptionObserver
{
    public:

        SwVer (AppManager*);
        SwVer(const SwVer&)            = delete;
        SwVer& operator=(const SwVer&) = delete;
        SwVer(SwVer&&)                 = delete;
        virtual ~SwVer();
		bool RequestBcmVer();
		uint8_t* GetOpVer();
		uint8_t* GetPpVer();
		uint8_t* GetCfVer();


    private:

    void message(const std::string& , const ecu::lapi::com::Message& ) override;

    AppManager*                             mAppManagerPtr;
    ISubscriptionObserver_ptr 				mCallBackHelper;
	uint8_t OP_Sw_ver[];
	uint8_t PP_Sw_ver[];
	uint8_t CP_Sw_ver[];


    static constexpr const char* TOPIC_BCM_TO_OTA = "rt/sercan/propbbcmrx_f9_21";
	static constexpr const char* TOPIC_OTA_TO_BCM = "rt/sercan/propbbcmtx_21_f9";


};

