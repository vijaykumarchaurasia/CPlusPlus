
#pragma once
#include "misc.h"
#include <string>
#include <sstream>
#include <unordered_map>
#include <boost/filesystem.hpp>
#include "TimeUtilities.h"

enum class FileType:int
{
	invalidFile = -1,
	opFile = 0,
	confFile,
	ppFile
};

/**	Directory Containing Flashing Files	**/
static const int MAX_SRE = 3;

/**	Array Containing Flashing Files Types	**/
static const FileType ALL_FILE_TYPES[MAX_SRE] = {FileType::opFile, FileType::confFile, FileType::ppFile};

/**	Directory Containing Flashing Files	**/
//static const std::string FLASH_DIR = "/home/root/test/ZIP";
static const std::string FLASH_DIR = "../test";

/**	OP Flash Data Start Address Most Sig. Byte. OP Data Starts at 0x080000	**/
static const std::uint8_t OP_START_ADDR_MSB = 0x08;

/**	CONF Flash Data Start Address Most Sig. Byte. CONF Data Starts at 0x020000	**/
static const std::uint8_t CONF_START_ADDR_MSB = 0x02;

/**	PP Flash Data Start Address Most Sig. Byte. PP Data Starts at 0x010000	**/
static const std::uint8_t PP_START_ADDR_MSB = 0x01;

namespace boostfs = boost::filesystem;

class AppManager;
class EventsManagerModel;

class FileHandler
{
		public:

#ifdef UNIT_TEST
			FileHandler()								=default;
#else
            FileHandler()							   = delete;
#endif

			FileHandler(AppManager*);
            ~FileHandler();


            FileHandler(const FileHandler&)            = delete;
            FileHandler& operator=(const FileHandler&) = delete;
            FileHandler(FileHandler&&)                 = delete;

			bool isReadyToFlash();
			const std::vector<Record>& getOPFlashingData();
			const std::vector<Record>& getConfFlashingData();
			const std::vector<Record>& getPPFlashingData();

#ifdef UNIT_TEST
		protected:
#else
		private:
#endif

			AppManager* mAppMangerPtr;
			EventsManagerModel* mEventsManagerPtr;
			bool mReadyToFlash;
			bool mOPUpdateAvailable;
			bool mConfUpdateAvailable;
			bool mPPUpdateAvailable;
			bool mErrorInParsing;
			std::vector<Record> mEmptyData;							//Empty return data if there's error and someone requests data
			std::map<FileType,std::vector<Record>> mFlashDataMap;
			std::vector<boostfs::directory_entry> mListOfSREFiles;
			TickId mSignalEmitTick;

			void Init();
			boostfs::path FindZipFile(const std::string& dir);		//
			bool ExtractZipFile(const std::string& zip_path, const std::string& dest);	//
			void FindSREFiles(const std::string& dir);		//
			void ProcessAllFiles();
			void SetUpdateAvailableFlag(FileType type);		//
			void EmitUpdateAvailableSignal();

			Record ParseSREData(std::string line);	//
			uint8_t GetAddressSizeInBytes(std::string record_type);		//
			std::vector<uint8_t> ConvertStringToByteVector(std::string strToConvert); //
			void WriteDataBuffer(FileType type, Record rec);	//
			void ClearDataBuffer(FileType type);	//
			bool IsDirExists(const std::string& dir);		//
			FileType GetSREFileType(const std::string& filePath);
	};


