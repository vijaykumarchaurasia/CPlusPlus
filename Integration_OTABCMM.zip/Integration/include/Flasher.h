/*
 * Flasher.h
 *
 *  Created on: Nov 30, 2021
 *      Author: U01B759
 */

#pragma once

#include <chrono>
#include <vector>
#include <iomanip>
#include <memory>
#include "misc.h"
#include "CanHandler.h"


class FlasherTest;

	enum States
	{
		stateModuleIdDataRequest_SC,
		stateEnterConfigurationLoadMode_SC,
		stateEraseOperatingProgram_SC,
		statesEraseConfiguration_SC,
		statesEraseProgrammableParameters_SC,
		stateReadOperatingProgram_SC,
		stateReadConfiguration_SC,
		stateReadProgrammableParameters_SC,
		stateFlashData_SC,
		stateSoftwareReset_SC,
		stateFlashSessionCompleted_SC,
		stateFlashSessionRetry_SC,
		stateFlashSessionFailed_SC

	};

	/// software execution time (ms)
	const int msSoftwareExecutionTime_SC = 100;

	/// heartbeat retrigger count (ms)
	const int msHeartbeatTime_SC = 2500;

	const int maxNumberOfProgrammmingRetries_SC = 3;

	const CanMessage idRequestMsg_SC = {0x0A, 0x01, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
	const CanMessage heartbeatMsg_SC = {0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
	const CanMessage eraseOperatingProgramMsg_SC = {0x03, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
	const CanMessage eraseConfigurationMsg_SC = {0x04, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
	const CanMessage eraseProgrammableParametersMsg_SC = {0x05, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
	const CanMessage programDataMsg_SC = {0x07, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
	const CanMessage softwareResetMsg_SC = {0x01, 0x78, 0x56, 0x34, 0x12, 0xFF, 0xFF, 0xFF};

	class AppManager ;
	class FileHandler ;
	class EventsManagerModel;

	class Flasher
	{
		public:
			friend class ::FlasherTest;

			Flasher(AppManager*);
            ~Flasher();

            Flasher(const Flasher&)            = delete;
            Flasher& operator=(const Flasher&) = delete;
            Flasher(Flasher&&)                 = delete;

			void Init(void);
			void RunStateMachine();

			void OpSreCallback();
			void ConfigSreCallback();
			void PpSreCallback();

			//KL15: Pointer to Observer object
			std::shared_ptr<Can> mCanPtr;

			void SendServiceHeartBeat();

		private:
			AppManager*         mAppMangerPtr;
			FileHandler*        mFileHandlerPtr;
			EventsManagerModel* mEventsManagerModel;

			/// heartbeat interval
			const std::chrono::milliseconds heartbeat_period_ms_{msHeartbeatTime_SC};

			/// next heartbeat kick time
			std::chrono::steady_clock::time_point next_heartbeat_time_;

			/// id wait period
			const std::chrono::milliseconds id_period_ms_{11000};

			/// id wait time
			std::chrono::steady_clock::time_point id_wait_time_;

			/// minimum number of config command repeat
			const int number_of_config_request_min = 10;

			/// configuration request count
			int number_of_config_request_count_;

			/// programming attempt
			int number_of_programmming_retries_;

			enum States state_;
			std::vector<CanMessage> accept_data_;
			CanMessage send_;
			CanMessage response_;
			CanMessage config_load_command_;
			CanMessage accept_data_resonse_;
			std::vector<Record> config_;
			std::vector<Record> pp_;
			std::vector<Record> srec_;
			bool id_obtained_;
			unsigned int flash_index_;

			States ModuleIdDataRequest();
			States EnterConfigurationLoadModeCommand();
			States EraseOperatingProgramCommand();
			States EraseConfigurationCommand ();
			States EraseProgrammableParametersCommand();
			States FlashData();
			States SoftwareResetCommand();
			States FlashSessionRetry();
			States ReadOperatingProgram();
			States ReadConfiguration();
			States ReadProgrammableParameters();
			void ClearCanMessage(CanMessage& this_message);
	};

