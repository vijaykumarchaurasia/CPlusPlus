
# pragma once
#include <string>

namespace BCMOTA
{
    struct NotificationMessage
    {
        const char* command;
        const char* msg;
        const char* queryOpt;
        const char* cancelOpt;
        const char* dispTime;


        NotificationMessage():
        command ("NA"),
        msg  ("NA"),
        queryOpt ("NA"),
        cancelOpt ("NA"),
        dispTime  ("NA")

        {}
    };
}//End of BCMOTA NS
