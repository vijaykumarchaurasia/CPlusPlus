
#include <ecu/com/messageadapter.h>
#include <ecu/com/client.h>
#include <ecu/pb/ecu.pb.h>
#include "AppManager.h"


using namespace ecu::lapi;
using namespace ecu::lapi::com;

class AppManager;
class ClientManagerModel;

class ServiceMode
{
    public:

        ServiceMode (AppManager*);
        ServiceMode(const ServiceMode&)            = delete;
        ServiceMode& operator=(const ServiceMode&) = delete;
        ServiceMode(ServiceMode&&)                 = delete;
        virtual ~ServiceMode();
		bool SetOpertingMode(uint8_t mode);

    private:
    AppManager*                             mAppManagerPtr;

	static constexpr const char* TOPIC_SET_OP_MODE = "rt/system/set_n2_operating_mode";


};

