// If you are wondering why is this needed/exists, thank/ask StoneRidge

/*
 * CallBackHelper.h
 *
 *
 * Author: Mo Chabuk
 */
#pragma once

#include <string>
#include <ecu/com/observer.h>

using namespace ecu::lapi::com;

class CallBackHelper : public ecu::lapi::com::ISubscriptionObserver
{
public:
   explicit CallBackHelper(ecu::lapi::com::ISubscriptionObserver* passedObserverPtr) :
      mObserver(passedObserverPtr) {};
      ~CallBackHelper() = default;
   void message(const std::string& topic, const ecu::lapi::com::Message& message) override
    {
      mObserver->message(topic, message);
    }

private:
   ISubscriptionObserver* mObserver;
};

