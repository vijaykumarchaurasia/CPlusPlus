
/*
 * ClusterInterface.h
 *
 *
 * Author: Vijay Kr
 */

#pragma once

#include <ecu/com/messageadapter.h>
#include <ecu/com/observer.h>
#include <ecu/com/client.h>
#include <ecu/pb/ecu.pb.h>
#include "CallBackHelper.h"
#include "NotificationMessage.h"


using namespace ecu::lapi;
using namespace ecu::lapi::com;

class AppManager;

class ClusterInterface:public ISubscriptionObserver
{
    public:

        ClusterInterface (AppManager*);
        ClusterInterface(const ClusterInterface&)            = delete;
        ClusterInterface& operator=(const ClusterInterface&) = delete;
        ClusterInterface(ClusterInterface&&)                 = delete;
        virtual ~ClusterInterface();
        bool FormatAndSendMsgToCluster(BCMOTA::NotificationMessage& msg);

    private:

        char* FormatClusterMessage(BCMOTA::NotificationMessage& msg);
        bool SendMessageToCluster(char* msg);
        com::Message::DataBuffer getDataBuffer(uint8_t *data, int size);
        void copyMsg(char* target, char* str, int start);
        void message(const std::string& , const ecu::lapi::com::Message& ) override;


        AppManager*                             mAppManagerPtr;
        ISubscriptionObserver_ptr 				mCallBackHelper;
        ecu::lapi::com::ITransportClient_ptr 	mClient;

        static constexpr const char* TOPIC_CLUSTER_TO_OTA = "app/cluster/ota";
        static constexpr const char* TOPIC_OTA_TO_CLUSTER = "app/ota/cluster";

        static constexpr const char* SESSION_INFO = "startInfoSession";
        static constexpr const char* SESSION_QUERY = "startQuerySession";
        static constexpr const char* SESSION_STATUS = "getSessionStatus";
        static constexpr const char* SESSION_CANCEL = "cancelSession";
        static constexpr const char* SESSION_CULSTER_TYPE = "getClusterType";
        static int mRejectionCount;

};



