/*
 * DriverInteractionModel.h
 *
 *  Created on: April 22, 2022
 *      Author: Neeta Jawale
 */

#pragma once

class AppManager;
class VehicleStateModel;
class ClusterInterface;
class EventsManagerModel;

class DriverInteractionModel
{
    public:

        DriverInteractionModel(AppManager*);
        DriverInteractionModel (const DriverInteractionModel&)    = delete;
        DriverInteractionModel& operator=(const DriverInteractionModel&) = delete;
        DriverInteractionModel(DriverInteractionModel&&) = delete;
        ~DriverInteractionModel();
        void CheckFlashingPreConditions();

    private :

        AppManager*         mAppManger;
        VehicleStateModel*  mVehicleStateModel;
        ClusterInterface*   mClusterInterface;
        EventsManagerModel* mEventsManagerModel;
};


