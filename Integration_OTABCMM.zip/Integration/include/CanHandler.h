/*
 * CanHandler.h
 *
 *  Created on: April 20, 2022
 *  Author: Neeta Jawale
 */

#ifndef INCLUDE_CANHANDLER_H_
#define INCLUDE_CANHANDLER_H_
#include <ecu/rt/signaladapter.h>
#include <string>
#include <ecu/com/client.h>
#include <ecu/com/message.h>

using namespace ecu::lapi::com;


class AppManager;
class ClientManagerModel;

struct CanMessage
{
    uint8_t byte_0;
    uint8_t byte_1;
    uint8_t byte_2;
    uint8_t byte_3;
    uint8_t byte_4;
    uint8_t byte_5;
    uint8_t byte_6;
    uint8_t byte_7;
};

class Can : public ISubscriptionObserver
{
    public:

        Can(AppManager*);
        Can (const Can&)    = delete;
        Can& operator=(const Can&) = delete;
        Can(Can&&) = delete;
        ~Can();

        void message(const std::string&, const Message&);
        void SendandGetCanMessage(CanMessage & send, CanMessage & receive);
        CanMessage* m_CanMessage;

    private :
        ecu::lapi::com::Message::DataBuffer GetDataBuffer(CanMessage);


        AppManager*                             mAppManger;
        ClientManagerModel*                     mClientManagerModel;
        ecu::lapi::com::ITransportClient_ptr    mTransportClient;
        ISubscriptionObserver_ptr               mSdkCallBackPtr;
        std::string BCM_TOPIC_NAME              = "PropBbcmTX_21_F9";
        ecu::lapi::rt::Signal::DATA             m_Response;
};


#endif /* INCLUDE_CANHANDLER_H_ */
