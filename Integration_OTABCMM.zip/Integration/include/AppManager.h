/*
 * AppManager.h
 *
 *
 * Author: Mo Chabuk
 */
#pragma once

#include <memory>
#include "FileHandler.h"
#include "ClusterInterface.h"

class EventsManagerModel;
class ClientManagerModel;
class ClusterInterface;
class DriverInteractionModel;
class FileHandler;
class Flasher;
class VehicleStateModel;
class TimeUtilities;

class AppManager
{
    public:
        AppManager();
        AppManager(const AppManager&)              = delete ;
        AppManager& operator = (const AppManager&) = delete ;
        AppManager(AppManager&&)                       = delete ;
        ~AppManager();
        void StartApp();

        TimeUtilities*				GetTimeUtilities();
        EventsManagerModel*       	GetEventsManagerModel();
        ClientManagerModel*       	GetClientManagerModel();
        ClusterInterface*           GetClusterInterface();
        FileHandler*			   	GetFileHandlerModel();
        Flasher*                   	GetFlasherModel();
        VehicleStateModel*          GetVehicleStateModel();
        DriverInteractionModel*     GetDriverInteractionModel();

        const std::string NOSUFFICIENTSPACE = "No_Sufficeint_Space";

    private:

        std::unique_ptr <TimeUtilities>				mTimeUtilitiesPtr;
        std::unique_ptr <EventsManagerModel>        mEventsManagerModelPtr;
        std::unique_ptr <ClientManagerModel>        mClientManagerModelPtr;
        std::unique_ptr <ClusterInterface>          mClusterInterfacePtr;
        std::unique_ptr <VehicleStateModel>         mVehicleStateModelPtr;
        std::unique_ptr <DriverInteractionModel>    mDriverInteractionModelPtr;
        std::unique_ptr <FileHandler>				mFileHandlerModelPtr;
        std::unique_ptr <Flasher>                   mFlasherModelPtr;

};


