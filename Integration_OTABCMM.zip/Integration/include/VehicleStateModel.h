/*
 * VehicleStateModel.h
 *
 *
 * Author: Mo Chabuk
 */
#pragma once

#include <ecu/com/observer.h>
#include <ecu/com/client.h>
#include "CallBackHelper.h"

class AppManager;

class VehicleStateModel: public ecu::lapi::com::ISubscriptionObserver
{
    public:
        VehicleStateModel(ecu::lapi::com::ITransportClient_ptr);
        virtual ~VehicleStateModel();

        bool IsVehicleReady();
        std::vector<std::string> GetFailedConditions();
        bool GetConditionState(std::string);

    protected:

    private:

    void message(const std::string& , const Message& ) override;
    ecu::lapi::com::ITransportClient_ptr mClient;
    ISubscriptionObserver_ptr mCallBackHelper;


      std::map<const std::string ,std::pair<const std::string, bool>>
      mVehicleConditions{
      {"enginespeed",           {"rt/telcan/e_eec1",false}},
      {"battery_potential_21",  {"rt/telcan/e_vep1_21",false}},
      {"Acc_GridState",         {"rt/telcan/propb_vehicle_state_bcm",false}},
      {"vehicle_autoss_status", {"rt/telcan/propb_vehicle_state_bcm",false}},
      {"WheelBasedVehicleSpeed",{"rt/telcan/e_ccvs1",false}},
      {"ParkingBrakeSwitch",    {"rt/telcan/e_ccvs1",false}}
      };
};

