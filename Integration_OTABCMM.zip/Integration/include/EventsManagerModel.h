/*
 * EventsManagerModel.h
 *
 *
 * Author: Mo Chabuk
 */
#pragma once

#include <mutex>
#include <vector>
#include <boost/signals2.hpp>


using EventSignal = boost::signals2::signal<void ()>;
class EventsManagerModel
{
    public:
        explicit EventsManagerModel();
        ~EventsManagerModel();
        EventsManagerModel(const EventsManagerModel& other)            = delete;
        EventsManagerModel& operator=(const EventsManagerModel& other) = delete;
        EventsManagerModel(EventsManagerModel&&)                       = delete;


        bool GetEventStatus(std::string);
        void AddSignal(std::string);
        bool ConnectToSignal(std::string,const EventSignal::slot_type&);
        bool DisconnectFromSignal(std::string,void (*slotToDisconnect)());
        void EmitSignal(std::string);
        void DisconnectAll();
    private:
        void InitSignals();
        std::map<std::string,std::unique_ptr<EventSignal>> mDynamicSignalsMap;
        std::mutex                                          mSignalMtx;
        const std::vector<std::string>mBcmSignals {"UpdateAvailable",
        										   "ConfUpdateAvailable",
												   "PPUpdateAvailable",
                                                   "UpdateNotAvailable",
                                                   "VehicleReady",
                                                   "VehicleNotReady",
                                                   "NotifyDriver"};

};

