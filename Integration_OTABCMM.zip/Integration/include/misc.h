/*
 * misc.h
 *
 *  Created on: Nov 15, 2021
 *      Author: U01B759
 */
#pragma once
#include <string>
#include <vector>

struct Record
{
	std::string record_type;
	std::uint8_t byte_count;
	std::vector<uint8_t> address;
	std::vector<uint8_t> data;
	std::uint8_t checksum;

	Record():
	byte_count(0),
	checksum(0)
	{
		record_type.clear();
		address.clear();
		data.clear();
	}
};


//TX
/** Flash Loader Topic Name - 65314 PropB_22**/
static constexpr const char* ptrTopicFlashLoader_SC = "CFF22F9x";

/**DM13 57088(DF00) **/
static constexpr const char* ptrTopicDM13_SC = "18DFFFF9x";

//** Address Claim - 60928 **//
static constexpr const char* ptrTopicAddressClaim_SC = "18EEFFF9x";

//** Request to Body Controller - **//
static constexpr const char* ptrTopicRequestToBC_SC = "18EA21F9x";

//RX
/** ESC Topic Name - 65529 PropB_F9 **/
static constexpr const char* ptrTopicPropB_SC = "18FFF921x";


//18EF17F9x prop cluster?
//18DA17F9x cluster uds?
//18DA21F9x bcm uds?
//18EA17F9x instrument cluster request?
//CEA17F9x  instrument cluster request?
//CEAFFF9x ?
