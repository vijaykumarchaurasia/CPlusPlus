/*
 * ClientManagerModel.h
 *
 *
 * Author: Mo Chabuk
 */
#pragma once
#include <ecu/com/client.h>
#include <ecu/variables.h>
#include <ecu/sysparams.h>
#include <ecu/diag/uds.h>

class ClientManagerModel
{
    public:
        explicit ClientManagerModel();
        ~ClientManagerModel();
        ClientManagerModel(const ClientManagerModel&)            = delete;
        ClientManagerModel& operator=(const ClientManagerModel&) = delete;
        ClientManagerModel(ClientManagerModel&&)                 = delete;

        void SetUpClientManager();
        bool CreateMainClient();

        ecu::lapi::com::ITransportClient_ptr GetMainClient();

    private:

        ecu::lapi::config::Configuration_ptr mCfgMainClient;
        ecu::lapi::com::ITransportClient_ptr mMainClientPtr       = nullptr;
};
