#pragma once

#include <string>


class DummyClass
{
    public:
        DummyClass();
        DummyClass(const DummyClass&)              = delete ;
        DummyClass& operator = (const DummyClass&) = delete ;
        DummyClass(DummyClass&&)                   = delete ;
        ~DummyClass();

        int FuncRetunsOne();
        std::string FuncRetunsName();


    private:
};


